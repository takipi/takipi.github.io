package generated.jgye.cou;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsWhiobyn
{
	 public static final int classId = 419;
	 static final Logger logger = LoggerFactory.getLogger(ClsWhiobyn.class);

	public static void metXwjaxynlz(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valEmlnbreghls = new LinkedList<Object>();
		Map<Object, Object> valQktrchnjqvc = new HashMap();
		int mapValKfnxahufmaz = 143;
		
		boolean mapKeyYzaudqzdbzz = false;
		
		valQktrchnjqvc.put("mapValKfnxahufmaz","mapKeyYzaudqzdbzz" );
		
		valEmlnbreghls.add(valQktrchnjqvc);
		List<Object> valQzyixrdbprg = new LinkedList<Object>();
		String valPjqycougugu = "StrCqijyefonok";
		
		valQzyixrdbprg.add(valPjqycougugu);
		boolean valBhlwdozzxgh = true;
		
		valQzyixrdbprg.add(valBhlwdozzxgh);
		
		valEmlnbreghls.add(valQzyixrdbprg);
		
		root.add(valEmlnbreghls);
		Map<Object, Object> valBjzsfjcjasf = new HashMap();
		Map<Object, Object> mapValYknyygcnpks = new HashMap();
		long mapValSrrzfamiord = 3111592826799435144L;
		
		int mapKeyQkyfmbsmjns = 340;
		
		mapValYknyygcnpks.put("mapValSrrzfamiord","mapKeyQkyfmbsmjns" );
		
		Object[] mapKeyWahzsoxdnav = new Object[9];
		String valOorsqqplqrn = "StrAuthqaldcol";
		
		    mapKeyWahzsoxdnav[0] = valOorsqqplqrn;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyWahzsoxdnav[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBjzsfjcjasf.put("mapValYknyygcnpks","mapKeyWahzsoxdnav" );
		
		root.add(valBjzsfjcjasf);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Pzarivwncs 9Ubtheqtcee 10Ngelyrfkyxt 7Kggekcoo 3Opxw 10Yvyzejlpvry 5Jvwmmc 11Wfcwdczyxkce 6Qooiiho ");
					logger.info("Time for log - info 9Bbronzlpyr 8Exmiggnrf 8Tvjowiqul 8Xjsukdpnt 11Vechkfpkmikb ");
					logger.info("Time for log - info 7Aoygalyk 12Ujfuxatustotx 5Omhokz ");
					logger.info("Time for log - info 5Texuvf 5Oammre 8Bkgnulxpk 11Vudppdzhukap 10Frzoffkiibt 4Btjvn 8Mtuxdssrs 4Jmrly 6Kkmqlyv 3Ndyn 10Pazgywhyvuz 4Vltdb 3Lgwq 10Ghqvmcombhn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Ycimvuitj 10Bnuzyrkyrjw 11Hsuqadvtklpq 5Mncziz 10Alitpevsbfk 4Kxyaf 5Ksadxq 11Maopztlkqyjs ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.opcr.jgy.rftd.rkx.ClsJjouwg.metSumjtrup(context); return;
			case (1): generated.mbf.jauhv.phe.sowu.arz.ClsAtgovrsbvzxguw.metNzrbcudifbng(context); return;
			case (2): generated.lhhp.jdgtq.lkhh.mkg.wzb.ClsZnuut.metLrcocicqjkqlv(context); return;
			case (3): generated.livfd.xzg.uuzce.mske.ClsRchbllfcclbcum.metGcwjtzaskn(context); return;
			case (4): generated.fkbuh.vawj.ClsXsqsadsvdke.metGrquryhkwyi(context); return;
		}
				{
			long varZsvcgrkhzeh = (Config.get().getRandom().nextInt(79) + 2);
		}
	}


	public static void metIqwafqpmmq(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valNukexszxngn = new Object[5];
		Object[] valGvjbllavxdl = new Object[6];
		long valWgiautllitz = -5977696053794492936L;
		
		    valGvjbllavxdl[0] = valWgiautllitz;
		for (int i = 1; i < 6; i++)
		{
		    valGvjbllavxdl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valNukexszxngn[0] = valGvjbllavxdl;
		for (int i = 1; i < 5; i++)
		{
		    valNukexszxngn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valNukexszxngn);
		Object[] valWtifdkvphqc = new Object[8];
		Map<Object, Object> valUxyfdbvivfn = new HashMap();
		boolean mapValXfckcylxxoy = false;
		
		long mapKeyDsvvbqkyeaa = -6869966608539013766L;
		
		valUxyfdbvivfn.put("mapValXfckcylxxoy","mapKeyDsvvbqkyeaa" );
		boolean mapValAsyibndsaik = false;
		
		long mapKeyPggmknginvx = -1667259501793308238L;
		
		valUxyfdbvivfn.put("mapValAsyibndsaik","mapKeyPggmknginvx" );
		
		    valWtifdkvphqc[0] = valUxyfdbvivfn;
		for (int i = 1; i < 8; i++)
		{
		    valWtifdkvphqc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valWtifdkvphqc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Wwekfh 3Essx 12Yvxuytnneprkk 6Yznabkx 5Roinbc 6Vkzsmpz 5Phwdrk 8Seionjwff 5Bbfuni 4Mjsll 9Npacpapqxs 4Ioobf 3Xnbh 9Zsaqmaeazl 4Sfbzq 3Ndsb 11Xmyxyrjdtxui 10Zzpfxhacixr 3Oqtg 8Hdxevwzhb 6Ogznsms 4Jqwtg 10Bjvgzqfaptk 12Cdukjuqsdfage 12Uehsexpopkaoi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Pfzwdcssw 7Qcobsxif 8Hvpdgqlvc 10Qxejfibldsh 11Iurofdmsjagh 5Dmdrbc 8Ierdsyosr 9Tcgforxrps 8Poyjxecit 6Xnewlmf 10Wnrvgqhjtxh 8Hfkuttyuv 5Rypaor ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kkru.kkr.eff.wedv.ClsTciibuckxmwxc.metEofuqsp(context); return;
			case (1): generated.lxrj.lts.csk.iew.ClsCagmzsja.metMsmzpyezeb(context); return;
			case (2): generated.ueynf.ovqsn.bjpnz.bhq.ClsPrqva.metOannw(context); return;
			case (3): generated.mrfat.adk.zch.ClsYwqlnetu.metCadvvicigiy(context); return;
			case (4): generated.liyl.sfhr.ClsNilzqakfd.metDymwfdjjlcu(context); return;
		}
				{
			long whileIndex27038 = 0;
			
			while (whileIndex27038-- > 0)
			{
				java.io.File file = new java.io.File("/dirXlgnbdfdfhg/dirIjkgmirkvyv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((5083) + (whileIndex27038) % 716855) == 0)
			{
				java.io.File file = new java.io.File("/dirDzgssddwdtp/dirQzyjgtjkwve/dirPxxxislmmlc/dirYfxfstldokr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(344) + 4) % 966614) == 0)
			{
				java.io.File file = new java.io.File("/dirFmzvaqojxqe/dirIxczcgeyrwn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numDiniyccwiuv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varHncwgkullfq = (8212);
		}
	}


	public static void metQbdzxppzc(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valBgaostbtssh = new HashMap();
		List<Object> mapValIeljhfchwoe = new LinkedList<Object>();
		boolean valWouxdvelxrg = true;
		
		mapValIeljhfchwoe.add(valWouxdvelxrg);
		
		Object[] mapKeyNmwgwtjdjsr = new Object[9];
		String valQwhdrzrhdcj = "StrHbxpgcaybfk";
		
		    mapKeyNmwgwtjdjsr[0] = valQwhdrzrhdcj;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyNmwgwtjdjsr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBgaostbtssh.put("mapValIeljhfchwoe","mapKeyNmwgwtjdjsr" );
		
		root.add(valBgaostbtssh);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Jlwcvxafpldyt 9Oyacrmeebd 12Stvcrertffnmy 5Hbwwyt 4Diedo 8Hyiyrdhlx 11Dbgmczvzbrbv 12Rqciffkmnfzwo 9Ogiovotrtl 3Ggqa 9Bayxwbsamc 5Jjedwj 7Zzvgtjss 11Ilwhvnkpilra 12Hadhnrhkofyst 3Xszo 4Emnsq 7Rhmjybkz 12Mikeqccdzhxzk 5Enuusc 7Bgkfcoao 6Tavrhhr 5Lsbiyj 7Irwtywna 6Bzngccn 10Npsoizanprw 8Bvztffvbp 8Kwvivbsnf 4Fbyxm 5Bfypld ");
					logger.warn("Time for log - warn 11Htnhohlywops 6Smorvgn 12Gtnppezegwfch 5Sqlsne 12Xyoyydrosupgi 8Qqzchugcj 6Ezvyfab 10Sivzuvgkxkf 8Onqxibdty 4Ihnez 8Yzryjrhkl 11Anjuoifkflnx 3Nbwf 12Nsngfhognddpr 3Bgyq 7Gsapuyrl 4Odzyk 11Cpngntcjhpmc 7Hwbrjlpl 5Cmpupy 3Csbq 11Gxephvtxxayw 6Dntpyte 8Poccswlde 8Hewrxjzcs 7Ozylipdz 12Eokbkmudpwrrb 8Kspbghzkt 3Dbyk 7Panfufgs 7Mfftenyl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Ujtkhsj 4Ihdvl 4Jbwtg 8Tcwbshelr 5Peruml 7Yabnmdzx 9Bjtxzaaube 12Scgpgxilaedjg 7Hfzmclzw 3Ymkc 4Acaix 4Kilwv 5Ucnfnh 12Prxjlammqnzkc 7Znvmhipx 9Kqlsqbzkzt 12Azcwforybwkom 4Jkmns 7Qpkefuqm 6Gqiquuj 5Rykomc 3Mdqm 11Svmxgzkimrqm 12Cqghohqwbpvrp 5Gqpdva 12Briljdhphqzme 3Hukj 12Mpjdftsmqatlt 4Azfwv ");
					logger.error("Time for log - error 11Qgyuwwljpykb 5Cpjxvv 12Ldeksbfqyjkpq 4Yglhj 7Ildfsuwm ");
					logger.error("Time for log - error 9Lhnznijvqh 3Jwah 5Matrmh 6Gkwqdsi 3Gcaa 7Sezylhbh 10Ekohqxrmnjq 9Llipbdwknh 9Fsjmfwmtpz 7Efvxgxck 12Drqgozuprgtnv 12Eknskqymginbv 12Qumugpfjfsiwb 5Egfqum 5Gsuttp 5Pvtxlk 4Cbulm ");
					logger.error("Time for log - error 12Zdazxrqrezdey 8Gncvmqpph 6Tdezize 4Grubn 3Kren 4Zemmw 7Oqiiifen 11Dnbyyrdageom 7Toopihqt 11Ymfvjcypurkg 12Xajzdztflmjwj 10Zjypdvajozd 3Osvo 6Zeznvum 8Eestqdczl 9Ebtcsormeh 5Cnolwu 10Helgwpwagnt 8Ggmmdfysb 12Pjdbaodxhfiro 8Yghujuyrj 7Zpdaamgi 4Hnxxq 7Xoigxcvd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gar.mdz.moh.znab.ymyxm.ClsZduvwawzb.metIltzdkawhx(context); return;
			case (1): generated.aea.iom.ClsOvjtnlwnmq.metKmfjrmgcij(context); return;
			case (2): generated.hzldn.tyqka.jujr.chcpl.ClsNxkmsnjozqsvm.metOzhtrhcipg(context); return;
			case (3): generated.agyh.aakn.unf.yzvm.uvtp.ClsPvvezxsnka.metStsgzfp(context); return;
			case (4): generated.byxi.uzy.rgdf.nzlsj.fbg.ClsCwwdznsfknncdl.metUlygc(context); return;
		}
				{
			if (((4379) + (4946) % 432796) == 0)
			{
				try
				{
					Integer.parseInt("numFwewohejavq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((9399) * (6903) % 382909) == 0)
			{
				java.io.File file = new java.io.File("/dirCgepalnhzvl/dirBwyfrskacge/dirSffajnoqmon/dirQlhjjanwazm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metGldtri(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valWkbgsrnjnyp = new HashSet<Object>();
		Map<Object, Object> valSzoqbpurzhn = new HashMap();
		String mapValDbtbbzoeefp = "StrUklgtewjbvp";
		
		boolean mapKeyNnorrqurgks = false;
		
		valSzoqbpurzhn.put("mapValDbtbbzoeefp","mapKeyNnorrqurgks" );
		
		valWkbgsrnjnyp.add(valSzoqbpurzhn);
		
		root.add(valWkbgsrnjnyp);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Mfwusbkkk 4Reiuu 4Fzcsa 6Ngzsrln 10Tztouyxopub 9Qxexluiytg 7Ttzpmppm 6Iuzjbjk 3Oylt 4Xkauv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Efgcafanlapm 3Cqvq 8Xlcncgzvf 12Stqanfsidjvfa 12Obcedwfamnvdk 6Hnmqgzg 11Tdnkwgbtueft 8Slazhppsv 4Okugd 5Dxyzfl 12Tuzchfdyjnsik 5Siwgsz 3Yxoo 5Glxjmd 3Bqud 9Mnflychinn 7Teungmed 3Hshw 3Pdhr 10Pbfycxqvrde 6Seehtub 11Msproirfakfz 10Twixaeagnom 4Ujeww 6Civcado 11Hccykwrsmsmq ");
					logger.warn("Time for log - warn 8Zjxqixrko 12Nwbzwchrtunrm 6Tvjokuo 6Kiggwcj 8Msraesdal 12Yscwzhvmrxqid 10Rfdroipzvsq 10Wghqsmyyhpw 10Qhzbtvrsfox 7Lyoazssw 8Rygnqnrnw 7Bwjpxtho 9Afviwffdye 10Rtvotuqasgx 4Ylfto 7Etzzrjpi 10Ckkdatfmiyh 8Kjcstklso 12Tmpyjmvnrhahj ");
					logger.warn("Time for log - warn 10Vynnejtjqad 10Mhnevucryfc 3Xffp 12Mxlfyxqphtdfh 12Ougmphqyoedvp ");
					logger.warn("Time for log - warn 12Umklqkiifihpq 7Hyllmewv 6Hsfzpif 12Tqsbnxjyeezzf 8Sqsznmeua 7Uctouvan 8Ylsapaqcu 11Qwkqsvikrwtf 5Nzkoaz 6Pgmhdyc 10Obgxjfttsmo 8Uihpeqaiw 7Voqwiprv 6Xbhqucc 10Pwgvufflcmx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Yvutir 6Btunxrf 9Wvdaxdapwg 3Xocj 6Tjjrbrs 7Wsukxigm 6Svwrxlr 8Bmzthrvyi 9Mwugjuxiwn 11Tlihecxokehk 4Qttzv 6Zcyhmsm 4Zirqx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ongb.lkxvg.dfa.pkoz.kbky.ClsZpuulcqafhvqyy.metSvcpwlc(context); return;
			case (1): generated.rkfhx.ntcs.qoe.lasd.nzzym.ClsDftkqmvmp.metVydzwrio(context); return;
			case (2): generated.lkx.jvoz.ClsUgthzii.metEemhoq(context); return;
			case (3): generated.rnt.ihen.ClsUnbfdq.metGtesoym(context); return;
			case (4): generated.ifyrm.rwj.ajr.gkqyg.ClsSfeshwgdectgpm.metUdqxpeng(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirAhlmwefaoqw");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metUoalicwnco(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		Object[] valSanknrkxosd = new Object[8];
		Set<Object> valRdjfaxkgowc = new HashSet<Object>();
		int valEidefmuqihx = 226;
		
		valRdjfaxkgowc.add(valEidefmuqihx);
		
		    valSanknrkxosd[0] = valRdjfaxkgowc;
		for (int i = 1; i < 8; i++)
		{
		    valSanknrkxosd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valSanknrkxosd);
		Set<Object> valFtvhcwyzdsr = new HashSet<Object>();
		Map<Object, Object> valMqfulpmxppm = new HashMap();
		int mapValFnphidxwrez = 937;
		
		String mapKeyMlmntkfvgzg = "StrWkpfrikhjwc";
		
		valMqfulpmxppm.put("mapValFnphidxwrez","mapKeyMlmntkfvgzg" );
		
		valFtvhcwyzdsr.add(valMqfulpmxppm);
		
		root.add(valFtvhcwyzdsr);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Yobrfqn 10Myzorzmppsx 10Ttbtublulbu 3Pwfl 7Wougolge 10Yvlrtzwtiai 9Fygbstaoyc 6Zsycxcm 5Yccfrk 8Yuzbxqcdy 9Zmzagrmmjr 3Vunx 9Ocyicomnay 6Hccgpsd 12Qqloesvzzujir 9Oqkwkycyzq 10Gsdduqakhiw 3Etff 10Zmefxbnmtxx 8Ztsosjlwc ");
					logger.info("Time for log - info 10Vbkptuurakt 9Dximsatgga 9Zkzuehgojk 5Gmzigo 7Ycfqzytg 9Agqusyewkz 10Myxbjdvyffd 7Lktsfvyx 5Agazia 8Ynjjiqxow 5Ccqmaa 7Wssjetjo 5Rztlic 5Ggmlby 10Iegxotjqlvk 8Ecolpjpbx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Jeuzrjgvv 4Udcqh 10Qwxexhyusbu ");
					logger.warn("Time for log - warn 6Mxlerep 11Ivaastdwargw 11Zsqerozzhcyg 10Aodsdjiimsr 5Bhyfmv 12Llpakfjovtxew 5Nzdkih 8Wjpqbqzgp 7Nhuzpcll 9Mztmeeawgs 11Rhivnuhsdrgz 3Akfz 4Xphsn 7Zacaiwtu 5Bpluwl ");
					logger.warn("Time for log - warn 5Pmctbx 11Ddohzpvmregv 10Rgkbphqrnas 5Pslciu 12Yzonevspvnqmp 6Euwvvhh 4Fbekx 9Ptxvvuvyvg 12Ovqtdmwrdravk 5Adyvxz 3Gecg 10Gfaehkucwxa 7Qfggpldl 12Glxemtezrppqw ");
					logger.warn("Time for log - warn 11Gcxcunwjqnyn 12Yigvbdaopcmfl 10Whibipgxwoc 8Excqisypq 4Tcqhf 12Zyiskcftqypsu 9Rnssxonsoq 3Yhov 11Prdeivzltvuy 5Khgemn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bde.vdlp.frn.zsrjp.eqwxd.ClsMvedn.metBrdejrtmmvqjyb(context); return;
			case (1): generated.xajsm.xnlym.ClsUmfzchfskds.metGwtzcndljxhwes(context); return;
			case (2): generated.kivyr.smd.affpo.ClsEqlzjivgvsoafb.metFtrfvpusk(context); return;
			case (3): generated.lfb.pwad.aey.ClsGmnfes.metQfgeyandauqd(context); return;
			case (4): generated.fdf.qdha.fywc.gjubl.dtsb.ClsBinezgxhqjfe.metNesscjpt(context); return;
		}
				{
			long whileIndex27060 = 0;
			
			while (whileIndex27060-- > 0)
			{
				java.io.File file = new java.io.File("/dirJkvvjcizskb/dirKwjpanwzyis/dirMdlsolablbi/dirVymjwfafmgx/dirIhjsalacenq/dirWntgcebxzll/dirJpvnobxsves/dirNatycvobdxc/dirMpyfzssmxrt");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
