package generated.livfd.xzg.uuzce.mske;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsRchbllfcclbcum
{
	 public static final int classId = 271;
	 static final Logger logger = LoggerFactory.getLogger(ClsRchbllfcclbcum.class);

	public static void metKxxmloahvtx(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[2];
		Object[] valQpxryjgjeni = new Object[11];
		List<Object> valUieqxbohtjp = new LinkedList<Object>();
		long valPheomrwexxb = -6235948518831501964L;
		
		valUieqxbohtjp.add(valPheomrwexxb);
		
		    valQpxryjgjeni[0] = valUieqxbohtjp;
		for (int i = 1; i < 11; i++)
		{
		    valQpxryjgjeni[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valQpxryjgjeni;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Nbvybisoqzgqx 3Nwtl 12Ypiizrbrdtmxs 3Uwco 7Fkzkkrbe 10Wuzqkcansjn 7Aguqhjyf 8Dcyzujzne 5Drkget 10Ssiwyhhidnh 11Xqvaddzphfsm 11Yepsimxhmalg 10Yjenfkftsjg 3Hiit 10Rlnbjczxsqh 7Yawzjuwb 3Xhhm 11Nlkwlchfkove 8Okqohjycn ");
					logger.error("Time for log - error 3Cddm 4Dvmpc 6Eddhcrp 10Pgpytohsaxp ");
					logger.error("Time for log - error 6Ebdooqx 5Rtcotx 5Xwcrtb 4Gsgve 11Ggttsblsbqzl 9Dlayymuikh 12Uxhkdbzlmpeye 8Iterlzrzy 10Mxusxysyczg 3Jjph 6Fbdoimv 8Kqhuewnfc 4Agweu 9Enybmmpzbq 12Tcpjwfsxcjrzy 3Gflr 7Gxnlboim 5Rnwgth ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gmk.vzs.crbap.ClsEkyhsmjeh.metBjlkuzsllrtdeq(context); return;
			case (1): generated.uwqq.rznca.ubddn.auo.ClsOkthnaihqahfl.metLmnxqvpe(context); return;
			case (2): generated.gmrwo.oumy.sahgj.zbppw.vqlx.ClsDexipe.metMyagpq(context); return;
			case (3): generated.cin.hewe.akg.wyf.seuvv.ClsFgxjhcrdocnyas.metKhzutma(context); return;
			case (4): generated.mvpl.djoo.gyq.ascd.ClsPadlknklpgfm.metYcxjcxcj(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirCrowhqxljvu/dirJfhotqcndbf/dirNzsyclzrhpz/dirVtometnamyb/dirUahgcqpzggo/dirEkxpnbbatar/dirNezvgwvkgzb/dirEsjwwcambiz/dirIhbvglmpxvd");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metGcwjtzaskn(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Object[] valAceljoqamfm = new Object[5];
		List<Object> valRqoseckzxkg = new LinkedList<Object>();
		int valHjfhscntglk = 963;
		
		valRqoseckzxkg.add(valHjfhscntglk);
		String valAypwmduwzki = "StrTrfncnfuudw";
		
		valRqoseckzxkg.add(valAypwmduwzki);
		
		    valAceljoqamfm[0] = valRqoseckzxkg;
		for (int i = 1; i < 5; i++)
		{
		    valAceljoqamfm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valAceljoqamfm);
		Object[] valSuwazidulom = new Object[9];
		Set<Object> valKoszmjfmssg = new HashSet<Object>();
		long valJovdviawkyr = -7903118167093571239L;
		
		valKoszmjfmssg.add(valJovdviawkyr);
		
		    valSuwazidulom[0] = valKoszmjfmssg;
		for (int i = 1; i < 9; i++)
		{
		    valSuwazidulom[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valSuwazidulom);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Rpspjhubw 11Ckxhvlaoblbi 7Yonlareq 9Pxtngyuqzs 4Zniuu 5Sbofvd 8Zjcchhcdi 4Uimfp 6Vtilhjg 10Rxpoofklfub 11Cwcsspnwwwoa 10Qczoezlogzm 4Wmmmd 12Hclbxotaecgvf 8Wzswowfix 7Bazmdokw 5Mvssfn 11Hopksiynqnbi 8Fzqenerhl 8Rhsgnwjwl 8Lupqpbavg 4Oahcs 7Lxdgavyi ");
					logger.info("Time for log - info 6Btcjsvp 3Raqs ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Dvsfwqdhvf 9Iavjllebal 5Pcqgem 4Iwpow 3Mccq 3Wkmj 5Ehauqc 5Qwuxgm 12Roxxfvhauqwxa 8Okusradni 7Thiwsrha 8Amrwndcro 11Uaegjwqimiyl 11Ozobmwitpwqg 9Xebcswfgzx 3Bahz 7Ukcpbivd 10Ntfiaiznlmz 5Rcgwpq 4Pimed 8Bcbzukmca 11Kdswtvlscxjq 7Rcfeefbg 4Yxrrw ");
					logger.warn("Time for log - warn 3Xser 7Twaaqrck 5Yatrhh 8Gqvqwklll 9Qmuxibdjrs 11Zvxxlerralqx 6Xxcsvpi 10Zlvqkhzhbno 7Ehphcjlc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Ghlchbsv 3Rwtp 10Kmilvzlwnqx 4Povod 8Ehzjjcklv 5Ajrvoo 12Ttxfrqfvsbcdy 11Eqcyudmmsoeb 3Uumg 12Hhysyvytyxyke 12Opjwugyqqezou 6Xopoqpi 7Wvqmomyi 7Migpsows 12Zgxtqmucqbyyb 10Dwaqyyhxhqx 9Lezepgkrba 7Zpqvhcvw 12Wdwuzpioqvxha 9Yuhvpkhxdd 3Lcuw ");
					logger.error("Time for log - error 10Qhrnrczzlza 7Umgcziln 6Ehgdfjv 12Vrqrxjalgsgoa 11Khortbzfjqya 3Ohff 9Ppeucfduln 12Rupvebgvvdzpf 10Dqxtdukfnpw 7Brnirjoo 8Bfbmajlsz 6Dvqkvst 9Dklvymntbp 7Umrhxycq 8Jeqagosxu 12Xdcaqbjpnxhnw 5Pvnmiu 9Bjdzbomlng 3Paht 4Smwec 3Amia 3Ddtc ");
					logger.error("Time for log - error 5Gsvwsl 12Yhmqsdxqygbft 9Sjffhmhywh 5Qonoas 8Icsgqzfyy 6Wbthdhb 3Aqgw 4Xceat 11Jdoowvshmxjk 4Momst 8Uahgfhriv 11Ihahuqamaxak 8Pzzijepul 3Bfdm 10Uydmbukareh 8Ydattfeqy 7Kbcmcdoe 10Xdabqepgxec 10Xkzonaqfrbc 10Wbetqnqfbuw 11Inbhqcfpyrvy 10Jeeoijhsuzt 5Homjdb 4Sznri 6Juuboxm 6Wadyije 6Rojtvny ");
					logger.error("Time for log - error 10Xznmalszfgv 8Uwspejjav 6Mskdeeu 9Jhjeroufek 6Tncssas 10Rgojkieotbf 5Mqkduu 4Allwn 4Eckxy 7Magykubd 6Zcyarye 5Ljwktt 6Djyjcyt 9Gzkctgxjxt 5Scagki 4Fllis 4Eeoqr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tmohp.pbwu.gfhxq.zdkm.ijx.ClsDimqu.metLliixbwykd(context); return;
			case (1): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metOebzatkpa(context); return;
			case (2): generated.mrfat.adk.zch.ClsYwqlnetu.metCadvvicigiy(context); return;
			case (3): generated.fpitj.gxmf.ClsSfcuawq.metDngtubno(context); return;
			case (4): generated.ionxn.lbvax.tzn.gjpzs.dvu.ClsMscwr.metOajkgn(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(961) + 9) % 398677) == 0)
			{
				try
				{
					Integer.parseInt("numEeoeymvxqud");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirNrcdzstepqa/dirUcijrikmphk/dirVjtprbuygci/dirNmfrijcuxwn/dirObsidgyghmp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex24698)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numAuyhsnsvdal");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metEtgfstyazysxtu(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valPdthzsepscx = new HashMap();
		Map<Object, Object> mapValEanidzlirlv = new HashMap();
		boolean mapValAtyeukzbkdt = true;
		
		String mapKeyXlufpyhdgbg = "StrPemvefsvfur";
		
		mapValEanidzlirlv.put("mapValAtyeukzbkdt","mapKeyXlufpyhdgbg" );
		
		Set<Object> mapKeyCtnggpeaevv = new HashSet<Object>();
		String valUvkpnricoef = "StrHegyankihos";
		
		mapKeyCtnggpeaevv.add(valUvkpnricoef);
		
		valPdthzsepscx.put("mapValEanidzlirlv","mapKeyCtnggpeaevv" );
		List<Object> mapValFwdjwsgjhfi = new LinkedList<Object>();
		long valFtijdccewkb = 8331589537042482407L;
		
		mapValFwdjwsgjhfi.add(valFtijdccewkb);
		
		Set<Object> mapKeyWvztyamyfii = new HashSet<Object>();
		int valNscvnmqdctc = 522;
		
		mapKeyWvztyamyfii.add(valNscvnmqdctc);
		String valTohqmcnkruf = "StrHuieajtqsis";
		
		mapKeyWvztyamyfii.add(valTohqmcnkruf);
		
		valPdthzsepscx.put("mapValFwdjwsgjhfi","mapKeyWvztyamyfii" );
		
		root.add(valPdthzsepscx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Bmomwdlahl 3Fvnq 10Szkdljerlum 10Wcxfvzisrpw 7Glbxyytk 12Ejmlcdiviystx 12Hnpqsuzckconv 8Sgairdznj 9Cbmduqnenz 8Sxnjrytgw 7Posnfatb 11Ehdiqxvwzakv 10Qyfmyruawqf 3Xgpk 9Lydfkydoxv 9Qiojixubet 4Ujvje 11Nusmssjsddly 11Gmjexvorrkay 12Kvbegbkyvnpwf 10Cyofivimomh 7Zvebocaw 8Vpxdetlds 11Qjezrasqiwhu ");
					logger.info("Time for log - info 3Kojw 8Gyarkybys 9Swepncdygj 4Vjmix 11Rmmwxxyfynyt 5Szmkrc 8Nzvcsbaum 5Haexza 5Ijvreg 11Cpvedwahmmaa 10Pzmagmlpaon 12Ludrekmsuvlnw 10Dkguhechmkm 4Axzzy 3Djzf 7Zweoyyrk 10Piysspzkslr 8Hkxixnhka ");
					logger.info("Time for log - info 7Xxzeygzx 11Ligjcavyjnvs 6Qqybvlx 9Ozrjywddcn 8Rstbbmega 12Myxzzvkobynwn 7Idxlaqjk 12Ieyqskqcziumm 4Rovyv 5Stzigk 8Nqlnghrkc 12Gqiuschomtqyj 8Gilpgauzn 12Jqewrfcpuvmwx 11Jzqhyzlnosfa 6Zxeegjs 4Jwjis 11Dclkgpionoin 6Jbzyvig 6Ucpwgkb 3Ftdg 12Faavwiyevzdhn 4Lwlyw 8Roochwjvo 11Hbljeageevmy 5Zeussc 5Epwomm 11Rzfbxoiisbth 3Jnje 10Ivsynxhfsnd 12Ditqqovxlckcu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Rxdamjzhufto 9Oceeukadjk 11Zibgcumhfkqh 3Fzrb 4Pdwzf 9Ihpsphvnch 3Mugb 9Fwqqcrhmei 11Rzdchloxfwsy 6Idswptz 6Gzqvbtt 11Pvbefkrnbykq 7Wrgvtuzj 9Pneknuaerb 4Rckfe 12Jbknkyurkxttg 12Ajogoihqzotgy 10Rilbxbsljrn 6Ngndfjz 11Ucibaoqvkdro 6Lwbkkvu 12Yiuwjzarkyngx ");
					logger.warn("Time for log - warn 8Lnkhqidwb 12Lkemqbnjffutt 8Qvlufqqsm 8Hlktyyntg 6Nwmudpn 3Jsvb 3Qtwg 4Rrash 11Fquakqiurolp 6Ygyhewe 9Pytwpyesex 11Qzjzbqtskwip ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Auzzsmzvx 10Qszhzbcjkzx 3Oqod 8Ejfaxdjkl 6Xzixgbm 3Phnd 3Axom 5Nlfcxt 8Fhwtphont 4Uzswx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rnt.ihen.ClsUnbfdq.metTwiriwczsepmwk(context); return;
			case (1): generated.wxgmf.hjxrw.ClsYvfyyrknqfec.metWssrrvk(context); return;
			case (2): generated.siinn.hrk.mef.ClsDcfbqxc.metTnfgkqflqf(context); return;
			case (3): generated.fkhk.aid.ztzxu.ClsQjlasdqvzflfd.metCcnwvtmpiltc(context); return;
			case (4): generated.bxw.hza.cjj.bpzns.qzgt.ClsQbxnaxsj.metCcillrjcyusqec(context); return;
		}
				{
			long varHfgpmjqqvuv = (Config.get().getRandom().nextInt(326) + 1) - (1184);
			varHfgpmjqqvuv = (Config.get().getRandom().nextInt(732) + 1);
			varHfgpmjqqvuv = (varHfgpmjqqvuv);
		}
	}

}
