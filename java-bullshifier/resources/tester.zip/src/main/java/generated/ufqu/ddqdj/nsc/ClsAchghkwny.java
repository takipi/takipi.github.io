package generated.ufqu.ddqdj.nsc;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsAchghkwny
{
	 public static final int classId = 269;
	 static final Logger logger = LoggerFactory.getLogger(ClsAchghkwny.class);

	public static void metKntxpyoov(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Object[] valQuzswstnjns = new Object[2];
		Object[] valUpdnihafspr = new Object[11];
		boolean valGzvkhmplbwu = false;
		
		    valUpdnihafspr[0] = valGzvkhmplbwu;
		for (int i = 1; i < 11; i++)
		{
		    valUpdnihafspr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valQuzswstnjns[0] = valUpdnihafspr;
		for (int i = 1; i < 2; i++)
		{
		    valQuzswstnjns[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valQuzswstnjns);
		List<Object> valDfcoubqgoxj = new LinkedList<Object>();
		Set<Object> valVszqtopzuln = new HashSet<Object>();
		long valJolxturgaug = 5254435205445366605L;
		
		valVszqtopzuln.add(valJolxturgaug);
		
		valDfcoubqgoxj.add(valVszqtopzuln);
		
		root.add(valDfcoubqgoxj);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Usdhgaxxfjg 7Byxyoklb 12Sfpxhrlltrpgp 5Qsznqy 6Umqytbh 7Xviixhib ");
					logger.info("Time for log - info 6Fmoyfkr 6Gniuuox 11Dmgzfckgmuix 6Dqdbrgw 9Tstndjnjfv 3Djro 9Tahcanoiwz 6Yhnjijj 7Qtgogzzg 12Ifonckqogvclc ");
					logger.info("Time for log - info 10Thwgdvlljyg 3Phew 9Rbpcchpdmf 9Pubxjzrupi 6Cfsiump 11Hucnaxlwfntf 5Abcjqp 11Afnccnhsytzp 5Urzfck 7Uxdpwllz 5Easoai 5Qxgilx 12Gftpmxopgyeli 12Etgnhdymnrhws 9Gqlxlivayx 11Ycqcqnlciubo 10Jettesazsho 7Aectdewo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Uwdmuvvth 3Diuc 9Gshtmekolj 9Zjhyaereie 9Qndioadpum 7Nhhhnbvo 11Titdztghvuwy 6Oylhfgh 12Bnlmzbffbiqeo 11Irnmjeefhngh 8Depwznipt 7Slliyotx 11Hyfxooafyort 11Koozvsmkuojm 5Kucujf 12Dxwyvsxhubpor 12Itfugklkwyahh 6Vtkemlf 10Gzmouanfryj 5Xxhyfc 12Rnpuibcpmzjto 10Qmdirypijwt 5Dcuxbm 11Pwbjrdyvhdrw 4Bttki 12Qjpzuemqaklhr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Qfjgqrcbjsc 8Vuhznuizf 3Jwur 6Vxngsss 5Ccxzla 11Zdepzfnhonhl 5Ugnsjq 5Mksocd 11Tdpbekjkjbqz 11Rwkrwarljbil 9Zhernchksk 4Xkzrc 5Kolvjk 9Dvejxlnrdr 6Lbycvwx 8Ovctrftqk 11Jtrmfihlhzfm 10Uaajilahjzo 3Ybnu 10Qfktxyovlon 10Fzulmmxqthg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.uqvko.bvdt.pbjo.abize.rep.ClsVzpniirg.metEfcladeulohz(context); return;
			case (1): generated.opcr.jgy.rftd.rkx.ClsJjouwg.metKtdrtpazip(context); return;
			case (2): generated.kbkqc.quu.lvl.ClsGhopbakrik.metQqkgixgrx(context); return;
			case (3): generated.nrwq.xlmuw.ClsJifahbhi.metWahxogsbzqn(context); return;
			case (4): generated.afllp.gwt.xvrk.rxvp.rryr.ClsQsqze.metJjhfwnwz(context); return;
		}
				{
			long varBhuaufjwmzn = (5698) + (Config.get().getRandom().nextInt(831) + 4);
		}
	}

}
