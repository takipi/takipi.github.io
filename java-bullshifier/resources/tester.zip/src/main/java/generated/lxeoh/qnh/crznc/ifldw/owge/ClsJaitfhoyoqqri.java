package generated.lxeoh.qnh.crznc.ifldw.owge;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJaitfhoyoqqri
{
	 public static final int classId = 402;
	 static final Logger logger = LoggerFactory.getLogger(ClsJaitfhoyoqqri.class);

	public static void metElosoop(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valRqrurvhvykp = new HashMap();
		Map<Object, Object> mapValDcwbzagwwfa = new HashMap();
		int mapValBrjwtdssrbc = 580;
		
		int mapKeyYwjzkqyyenw = 340;
		
		mapValDcwbzagwwfa.put("mapValBrjwtdssrbc","mapKeyYwjzkqyyenw" );
		boolean mapValBpactlntdgv = true;
		
		long mapKeyCgrpcpawipg = 6132419481855958611L;
		
		mapValDcwbzagwwfa.put("mapValBpactlntdgv","mapKeyCgrpcpawipg" );
		
		List<Object> mapKeyAavwrkgawhc = new LinkedList<Object>();
		String valQfnfxaehxkz = "StrIuesqihojzp";
		
		mapKeyAavwrkgawhc.add(valQfnfxaehxkz);
		
		valRqrurvhvykp.put("mapValDcwbzagwwfa","mapKeyAavwrkgawhc" );
		
		root.add(valRqrurvhvykp);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Okixejg 12Xvdoirjslcpld 6Wptaier 11Rodswxwnpzlu 10Jtiwbzlrlvr 3Ivgj 5Kybjmt 7Nbqtlcmo 8Yugybmjaa 11Gmpgphkuiffb 5Evwsmt 3Nxrc 8Jswnvrttv 5Wllrdk 8Efoswwtqz 7Zbpygzvl 5Wektda 8Mwyloswrr 6Ppeckiy 6Bgnjyrp 5Vrphxu 6Fmqmzcf ");
					logger.info("Time for log - info 8Wfttploxu 4Oszrq 10Hoziszzrhjc 7Fcwetowd 7Wqhizjsm 12Iyeqzkeroxcqy 9Rzqelciawk 11Fxpaelqrssqe 8Gonrdzmzt 3Wnzd 6Geplukv 7Qxrguogt 9Vfynaccweg 11Khggciwvdvhd 4Mmbci 6Omuxioq 4Xnpgk 5Naarzu 11Ccrnsutwqirl 10Fqtijattkrk 4Slmhe 3Lzzn 3Pilj 3Ljmr 8Fyjxtfvwg 5Hpbvpf 12Qjadiacaoclfg 8Xgqgfctnd 11Pbnqvqluxegp ");
					logger.info("Time for log - info 7Gwaqxmgv 11Zuhxbpksxknf 8Cxmgqdbqa 11Oxeiloslfnjp 11Cocbgguzoxhq 6Gfappfc 8Lepaiiiib 12Kilxyqnxjvoep 7Ddnabkpo 5Mlrdid 7Jaggiioz 12Ugvongofdctic 5Kqqlzd 8Xijdwsugu ");
					logger.info("Time for log - info 8Ulloelgxu 8Dpccabofw 12Uswcbzuoxfmff 6Eiavpei 3Deww 6Dskdopg 7Tzuwlqnm 7Puggtimk 3Zpar 9Zagottrynu 11Fwhbhrdhxjqd ");
					logger.info("Time for log - info 6Vonzxwh 8Mosefbmdz 4Lgtkc 7Vnxxryse 8Dngwwrkgp 8Lopdaejcp 5Drfohl 7Xutxqxwc 7Xzlnqszz 9Duiyzjcqsx ");
					logger.info("Time for log - info 3Ptgu 5Amzdhr 9Phmftbcpqv 8Hnaekgaym 10Csmyxsukiwi 3Zqmh 9Ffwlwcuyfk 11Kpltqyklvqzy 5Eeeyzt 9Titwgweiad 3Bwtg 9Rgxlunftqt 12Zizwzwufaqldu 4Rqzqv 11Ysnstibjgmgb ");
					logger.info("Time for log - info 10Tbqrshrhjva 10Zrmvgpmbdjb 9Zqprqxzcgw 8Sftxmspiv 12Egcohasxlrsqe 4Lsegi 10Jicaqdwgaeb 6Egqwpvd 10Bogptbrsmyw 6Rrvtvhy 10Nlnilevhvuz 5Xapydx 11Czvkysveqgmy 12Ewtkpuxwpmeng 5Hpqchi 11Hixjyjefinnd 6Xlqutua 10Fvtuklpfgmb 11Npbhlioxwran 7Pxibfvqq 6Chblxdc 7Spkgabbe 9Euursgzguh 10Rnvcrrofpzf 7Zjnarbyn 12Hmdwhpdlsibzn 6Zktborm 8Fskzebskr 12Tskdljhfpnltc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Hqgzf 8Whljwbkmz 8Rvaytdsxa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rorl.wuo.lqgdf.ClsUltodfmiuq.metZqbkch(context); return;
			case (1): generated.pgfis.zew.ikgq.ClsEgsupkocifpi.metYobadnrmqm(context); return;
			case (2): generated.hehz.xzg.akn.rdsvf.ClsKsukcv.metYviizisnunbnph(context); return;
			case (3): generated.nle.etupm.unno.jlzdn.uik.ClsNynvcklxtmhfla.metVlaejrvj(context); return;
			case (4): generated.idk.jvavb.vjuwp.iuzf.fawz.ClsRtwkffyfhbvpjl.metFydywnh(context); return;
		}
				{
			long whileIndex26774 = 0;
			
			while (whileIndex26774-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((Config.get().getRandom().nextInt(758) + 9) % 275444) == 0)
			{
				try
				{
					Integer.parseInt("numXkkrnrarhdw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(909) + 6) * (1377) % 192643) == 0)
			{
				java.io.File file = new java.io.File("/dirMrtnzdtyrmp/dirKejlnpsqehl/dirRcganysgqao/dirPzdbedomrat/dirRratymsqnfb/dirVbzmremcrzi/dirRvnqxaholec/dirOmfvcbdzqmb/dirPjekugxhkgb");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((1735) * (6343) % 311675) == 0)
			{
				java.io.File file = new java.io.File("/dirKflnflnnmzx/dirRbdoamgycdp/dirCtnljxdaggv/dirKrbctmawmdv/dirDvybuyabixd/dirApbichxvogr/dirImbxhyglsnu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metWxvdhhdzs(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[3];
		Object[] valVwyygyatycq = new Object[9];
		Set<Object> valHftnryqtyvp = new HashSet<Object>();
		String valEhvpeggxnrd = "StrWwbpbgaefbh";
		
		valHftnryqtyvp.add(valEhvpeggxnrd);
		
		    valVwyygyatycq[0] = valHftnryqtyvp;
		for (int i = 1; i < 9; i++)
		{
		    valVwyygyatycq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valVwyygyatycq;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Weyguzttbk 7Pxdfmgjd 4Zoqpl 4Sfmra 7Puhdrisr 11Rkgkdismaohd 4Yespv 11Wrnsmkqkuwzh 9Xjbfkdhafe 12Duqqyoinncvoi ");
					logger.info("Time for log - info 9Yjltkukipx 8Alyojfnrl 12Ouszkiuesnlmx 11Oxhgixadfkyr 4Afjxc 9Nvnmmxwkhk 6Jmdjnli 3Wzex 5Lxiaju 8Khrabhovt 9Bihkwlxevl 7Djqoinut 4Jrtfj ");
					logger.info("Time for log - info 6Zqiqtjh 6Dfkkmxh 6Pbtmruo 6Kavogce 8Utwfbtjde 4Ajjpk 9Osjhtjlcvt 11Nfabynerqdwd 5Jfqdfc 10Lmrzbsojlzp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Idqedmwrm 5Lhzfho 6Mgkllhc 3Skss 12Gihhigjadxqqy 6Cingire 12Baiakrocytsyw 8Bmveliltp ");
					logger.warn("Time for log - warn 9Scylskkmet 6Vofvumf 10Zjuiostjxqf 8Splsfskmh 4Opigd 7Hplfhtkh 10Leimdduxynz 12Xymhswoqwfkhq 4Qqvrj 7Bhonwthh 11Dflyykyoeswv 7Lclpznnh 11Naxtwvdwyegl 12Mvpgygwpvmkbz 4Zyktr 7Vbefxxtn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Hrquod 3Lolc 6Hghfehe 7Zelvzhqf 8Zwhfzxjnr 3Aoro 11Hiopfexsgxsh 4Qayqv 7Oodjjmty 6Ozneyae 3Ocyp 6Zcpxuxz 4Ggbzk 8Uzxkasvuo 12Gwothslvpfrbu 3Ohfj 4Hicgb 5Jxaizx 8Zygkxvyca 4Mlqsr 4Rbald 10Nnctghqpnel 7Pigffflm 6Qjteezg 5Ttmbey ");
					logger.error("Time for log - error 10Aquerwlbmnv 10Locsvmrccjj 8Oilccywcg ");
					logger.error("Time for log - error 6Kbupfqg 7Tjpokyib 7Whfabjzf 12Jjudbytphdram 8Tpdywmxto 8Uwbrqukik 7Sinjzowp 11Pfjilmiedync 3Cwhq 10Ngxxvmgvexa 3Lelh 4Cxkzd 3Fzvf 6Dqkwwye 7Bwidwqdf 10Jdmdojwzdab 10Nodijisbtbl 11Yveqjeffbcdn 7Jfkevkcr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tmohp.pbwu.gfhxq.zdkm.ijx.ClsDimqu.metDaefjy(context); return;
			case (1): generated.rnt.ihen.ClsUnbfdq.metAtneflmvgcprd(context); return;
			case (2): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metEwxuvzwhpbpte(context); return;
			case (3): generated.duzy.rxrsw.ClsQbnde.metHjjrnpbeaq(context); return;
			case (4): generated.ueynf.ovqsn.bjpnz.bhq.ClsPrqva.metVbfejgaald(context); return;
		}
				{
			int loopIndex26783 = 0;
			for (loopIndex26783 = 0; loopIndex26783 < 1942; loopIndex26783++)
			{
				java.io.File file = new java.io.File("/dirYnuywpnbohq/dirRqlbdnjwxqp/dirFuxukwjhnno/dirSqowngfrerf/dirPimuuurpqhz/dirBycjtccktfs");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex26784 = 0;
			for (loopIndex26784 = 0; loopIndex26784 < 9468; loopIndex26784++)
			{
				java.io.File file = new java.io.File("/dirOusoyiswqsc/dirKigyhiagjsw/dirSsktqexyack/dirExhabftozas/dirNjaxzjqcxgv/dirWlyxxveciyv/dirYaenzszbtnj/dirNyzdpripgyz/dirSqtjbsqgqit");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
