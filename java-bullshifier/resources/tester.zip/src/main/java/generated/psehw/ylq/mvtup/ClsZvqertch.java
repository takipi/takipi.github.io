package generated.psehw.ylq.mvtup;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsZvqertch
{
	 public static final int classId = 366;
	 static final Logger logger = LoggerFactory.getLogger(ClsZvqertch.class);

	public static void metDwzjtryendoov(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValHlugtcnyjqe = new HashSet<Object>();
		Map<Object, Object> valSakmcewgtym = new HashMap();
		boolean mapValKispaqamvvm = true;
		
		boolean mapKeyZrojtbvkjhg = true;
		
		valSakmcewgtym.put("mapValKispaqamvvm","mapKeyZrojtbvkjhg" );
		long mapValEzetmscofcp = -208991163269739252L;
		
		boolean mapKeyGfophukokfn = true;
		
		valSakmcewgtym.put("mapValEzetmscofcp","mapKeyGfophukokfn" );
		
		mapValHlugtcnyjqe.add(valSakmcewgtym);
		List<Object> valTpuwwffylfe = new LinkedList<Object>();
		boolean valGhntrretbnr = false;
		
		valTpuwwffylfe.add(valGhntrretbnr);
		String valZdbafmfejyb = "StrNfgnjfylpeb";
		
		valTpuwwffylfe.add(valZdbafmfejyb);
		
		mapValHlugtcnyjqe.add(valTpuwwffylfe);
		
		Map<Object, Object> mapKeyJydfrmwebjd = new HashMap();
		Map<Object, Object> mapValUmlcwfwcpqq = new HashMap();
		int mapValVqigjtcxxhz = 936;
		
		boolean mapKeyDqvjgyevjgl = true;
		
		mapValUmlcwfwcpqq.put("mapValVqigjtcxxhz","mapKeyDqvjgyevjgl" );
		String mapValEkvlqrgbxff = "StrAgulfvnvprj";
		
		boolean mapKeyWyqlhdzkesy = false;
		
		mapValUmlcwfwcpqq.put("mapValEkvlqrgbxff","mapKeyWyqlhdzkesy" );
		
		Map<Object, Object> mapKeyFlkhqgyhiyq = new HashMap();
		String mapValZbuvdyoadnb = "StrKayhzzhbkdw";
		
		boolean mapKeyDngmxydclhg = true;
		
		mapKeyFlkhqgyhiyq.put("mapValZbuvdyoadnb","mapKeyDngmxydclhg" );
		
		mapKeyJydfrmwebjd.put("mapValUmlcwfwcpqq","mapKeyFlkhqgyhiyq" );
		List<Object> mapValEeqesmvopri = new LinkedList<Object>();
		boolean valIqzgxdebnpb = true;
		
		mapValEeqesmvopri.add(valIqzgxdebnpb);
		
		List<Object> mapKeyYcbbkhgjsvj = new LinkedList<Object>();
		String valQkyyyonllmt = "StrDpgtrfgezpm";
		
		mapKeyYcbbkhgjsvj.add(valQkyyyonllmt);
		
		mapKeyJydfrmwebjd.put("mapValEeqesmvopri","mapKeyYcbbkhgjsvj" );
		
		root.put("mapValHlugtcnyjqe","mapKeyJydfrmwebjd" );
		Set<Object> mapValOtoqbvjttwe = new HashSet<Object>();
		Map<Object, Object> valDgimstjcxku = new HashMap();
		int mapValQfmnpumgoxz = 747;
		
		long mapKeyGpbdwvzepdh = -6742043494188037239L;
		
		valDgimstjcxku.put("mapValQfmnpumgoxz","mapKeyGpbdwvzepdh" );
		boolean mapValXwhjbzijtry = true;
		
		long mapKeyMpoougscllp = 4960222212073104952L;
		
		valDgimstjcxku.put("mapValXwhjbzijtry","mapKeyMpoougscllp" );
		
		mapValOtoqbvjttwe.add(valDgimstjcxku);
		Set<Object> valPgtramcndqy = new HashSet<Object>();
		long valHtucoggvutb = -3801600254056486591L;
		
		valPgtramcndqy.add(valHtucoggvutb);
		long valGuwsxiomyyi = 6707142009331322932L;
		
		valPgtramcndqy.add(valGuwsxiomyyi);
		
		mapValOtoqbvjttwe.add(valPgtramcndqy);
		
		List<Object> mapKeyOlybbsjbfaq = new LinkedList<Object>();
		Object[] valCfcrcyliioi = new Object[5];
		boolean valObhnxcgmlsf = false;
		
		    valCfcrcyliioi[0] = valObhnxcgmlsf;
		for (int i = 1; i < 5; i++)
		{
		    valCfcrcyliioi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyOlybbsjbfaq.add(valCfcrcyliioi);
		Object[] valUnioqklaghw = new Object[11];
		String valGncsnrsnatw = "StrJjgfzahtrjc";
		
		    valUnioqklaghw[0] = valGncsnrsnatw;
		for (int i = 1; i < 11; i++)
		{
		    valUnioqklaghw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyOlybbsjbfaq.add(valUnioqklaghw);
		
		root.put("mapValOtoqbvjttwe","mapKeyOlybbsjbfaq" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Xurcawbn 5Fzucvo 7Vfdlexnz 11Kucwkpcysnef 4Hqdlt 3Cvad 8Jvsblfoif 8Bhsaxuktn 8Fqiuhsrvq 10Ljfvkdgcydo 4Vwtan 11Fmfqvfqfkwrd 5Fhffzh 10Vrimobxwlfj 10Spjodkvlyil 5Jlsujq 11Wziwjsqbeume 8Txfxnrquw 7Xqbmkjqm 3Oied 11Foawvtohtrvx 8Eicfvwkjg 9Auyccuktgn 4Vecid ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Iqyozswdppyxc 8Lxakamshw 7Vzqcivnf 7Wwujjupr 6Lulpajc 5Iwqxwh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Lxzwijtnugo 4Cuhoa 4Urixi 6Uuknwue 8Ogymoamgv 6Tvjeyht 5Wdxduq 8Bicvmhjig 6Fwxxipf 9Adxmmdvvfo 3Ppqm 12Apbikdzahdguq 5Eucyyt 11Teopjnezcjxb 5Trmsxw 9Bihiqcmvor 10Ubkuvrqxfdc 12Nqbwuukzpmphp 6Wzijoef 11Sokstblnftsc 5Xnbmgo 8Zjoddizku 7Zcqzcogz 5Rryzvk 8Snhapvdny ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cymhf.zmxu.aqlat.ClsTwlvztmhvdbz.metJxghyc(context); return;
			case (1): generated.rnt.ihen.ClsUnbfdq.metKnfoolueiovk(context); return;
			case (2): generated.rsu.hmuld.jzssz.bjyy.fod.ClsQixayqsiydaxm.metIpckuqrkv(context); return;
			case (3): generated.lmq.wwll.mcjoz.ClsBqjxdpu.metGccfwaiyfrrux(context); return;
			case (4): generated.livfd.xzg.uuzce.mske.ClsRchbllfcclbcum.metEtgfstyazysxtu(context); return;
		}
				{
		}
	}


	public static void metUscfx(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[7];
		Map<Object, Object> valPrthlbmjrym = new HashMap();
		List<Object> mapValAbligntsuhh = new LinkedList<Object>();
		boolean valLgfmojqtxkt = true;
		
		mapValAbligntsuhh.add(valLgfmojqtxkt);
		
		List<Object> mapKeyAcdhsjdxuhg = new LinkedList<Object>();
		String valBelyfftshte = "StrUzxwbhcsoyn";
		
		mapKeyAcdhsjdxuhg.add(valBelyfftshte);
		
		valPrthlbmjrym.put("mapValAbligntsuhh","mapKeyAcdhsjdxuhg" );
		
		    root[0] = valPrthlbmjrym;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Lotzrqywwtg 4Vaajg 9Hlfmxldfxp 9Olqannfucy 11Gdsgiepgxhkt 10Bxidflxjvze 5Lcibip 3Haal 6Orrzimx 6Ometusp 9Jwhniujucd 11Vxwpzmkevsko ");
					logger.info("Time for log - info 10Zdxrfigaltl 5Gcfmbl 6Fbkwkaz 6Qrungkg 10Btpszrnvztf 3Dnlc 6Wvqxrmd 6Jyytcde 7Oxgmdyrz 8Nvapjgukh 12Iijoscnfgrgwn 5Gdgcaa 10Weqrpogowgy 5Tlyhcz 7Pwewfdot 5Nqomos 5Zfzdca 6Dbdlxrh 11Kvqsvaieuawf 12Wsndkyebfpjxp 8Iwnvjwbxl 10Lgipyagpyym ");
					logger.info("Time for log - info 5Bcgnic 7Pgkopwqn 9Ihnzwugcmh 10Frzgwqljtso 9Hataydqsrk 7Zequjosf 8Cymbfenwb 8Uodhbbjov 12Okwphzdhkikhm 10Kexsckhzhcl 4Zszrv 12Nuxqrhtgavbie 3Ibji 12Dcfnjxmmazzjc 11Rqlblbtcocnt 9Ahwqhxjvuh 6Jxcbifm 12Maqywmwxqbsib 7Narywvjx 9Oesrsqvbgn 10Iatkzecfzkl ");
					logger.info("Time for log - info 8Deovjidni 12Twvcuhgcemtpf 8Uneeyjzvy 9Vtqfoguvpn 8Zkwswyhme 5Nzvuhy 3Jefv 10Zofdkzhgksa 5Vvvdeh 12Wdemdacbpbgbq 3Wbgm 12Rqlcfoortwhir 3Psrv ");
					logger.info("Time for log - info 12Cneuexzptsbne 7Mhtzmvla 12Kcawebongcezd 10Fozztlozgee 7Gryfaamk 11Lveokqqdqjtc 7Hnftzlww 11Tyaevoyqmlvh 10Pciwrqpozha 4Ijyrl 4Qaxie 12Jvwdadxhiwves 6Jdmwhlc 9Yasbrfsieu 11Sbhrwtcqmgnl 3Nlop 3Zqsi 11Yvjizhtnhaqo 6Cxmxxao 3Nzkd 11Zdyxwoatoahz 5Koyhnc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Xgenwpbo 8Rufagryfz 6Exnyixe 3Mufy 4Dakip 4Aulzw 12Exxjjiyutcccl 8Tnrfkvpcb 12Kugcavvnhglfo 10Tfhibhpdhxr 7Cfyyojma 3Tahu 6Rewjipk 5Emwpxp 5Tjqpit 5Ywrsne 8Hvqwxdfgd 9Ujmrxvfovm 11Efmkqqgbtcbi 12Wntgylvbsknsh 7Pqkslihx 11Cpejlwtncllh 9Smxrtmxwve 6Wwwovtu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Yadjim 10Yvouluangby 11Iqorjdwtbxuz 6Vougnpz 7Yyehocob 9Rghjscyikc 4Atard 3Yfln ");
					logger.error("Time for log - error 12Dlggmcoqilxcl 6Eqheija 12Pfvbnxbwekyak 12Nimjtqgewnlsy 5Crkgqx 11Mllkfjelyrst 4Tykwr 12Ctyeuknobyoxn 8Pvmgcolmv 7Kfmcyaaj 6Dykbrcm 4Bwkwp 3Zlgp 7Nrqmqjst 10Fjzcmijkthv 11Yojyomqpuxib 11Djnjkaxuavox 8Egftinbjk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wyah.shgd.ClsOoifqzin.metOdxfuenha(context); return;
			case (1): generated.bhfun.zpnwj.czfe.augg.ClsEdcxpvndelttu.metUlhmbyyc(context); return;
			case (2): generated.tmb.nbu.txg.feeq.pmbxg.ClsRpabqs.metMwyinnavvuhwn(context); return;
			case (3): generated.rnr.pwsrq.cbi.tat.ClsQsqavl.metRlyadlfqaso(context); return;
			case (4): generated.maoc.ohm.nwzbx.efqn.ClsOzonhytosc.metIeedbzcj(context); return;
		}
				{
		}
	}


	public static void metWvhxsckimqa(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		List<Object> valTbgpuuknzuu = new LinkedList<Object>();
		Map<Object, Object> valObcstlpjkif = new HashMap();
		String mapValLtsgdkoapdr = "StrMgajzwlicrk";
		
		boolean mapKeyIzazhfjsgpx = true;
		
		valObcstlpjkif.put("mapValLtsgdkoapdr","mapKeyIzazhfjsgpx" );
		
		valTbgpuuknzuu.add(valObcstlpjkif);
		
		root.add(valTbgpuuknzuu);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Cxnwuoxcmrm 8Kzzavazfu 7Hujctexg 3Viaj ");
					logger.info("Time for log - info 5Xvrbhf 8Vsrtzxzht 11Zhlxfmovctua 6Mhekkpp 4Atpri 4Gvmdo 6Cewttyv 11Ndrzqupuymgx 7Slkzgotn 4Qhyjs 3Kprn 10Lqgaqqvssmz 12Mcoxkbksxgczw 10Hxmlrsnhmbr 6Ykffsqe 9Wscodgzfif 11Pzdapjcnygbj 8Imsisbnms 7Ykxkgekq 8Qrzpgrfrv 5Fwzrex 6Wloamnm 8Lojveqfjy 8Atrxkmugt 5Vpjlig 8Ncmrtkbnv ");
					logger.info("Time for log - info 12Cznsgtrajzmkl 10Cigmbiuovna 3Hmmx 8Xeuuhhjoz 11Qpvevvcipxhc 8Ckambpmra 4Hepqn 11Ilrvkppfijnt 5Thwfps 6Wxwarzf 3Tcqa 12Zuscrdtapwldu 7Nggtnqur 8Mshaibcvm 11Xpycvbfhdpum 8Txftlrpgz 6Jzdiqkn 3Zjoc 12Ilrolyzsrbzjz 4Kxssh 12Chsqsybsmhmyo 4Laxxd 12Dlqkpcsxgztcp 3Fljo 8Nxlhgcisn 6Gjsrkqo 3Mdrd 11Prcxaazkskww 7Adihzrcc 11Nxcskvohwjfb 12Vtgvaxqyxdomh ");
					logger.info("Time for log - info 10Kgheawwwsuq 3Wzkw 3Mdze 8Enlwyvcox 12Rhkebosqxdsul 3Gfrr 3Aoiv 10Jtvcmugbqrj 12Awjufhjjxhzsr 6Gnimjsq 5Relxkz 7Ulqpiduq 8Bhqwjftvr 8Tyctpdouk 8Bthofjfmg 7Hwhfwdbm 11Akddlafgxwnr 6Xhsmfho 10Ywnaapbnibx 10Emmpbakrjal 10Vszkmssbmeg 5Telhml ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Sqoe 4Psqzt 4Gphnl 5Cqhnwq 8Dzxmhabtm 8Wwngctqre 6Onukoss 12Hoaprxfvujrgg 3Zome 11Hjxodfywvytc 4Eyvjj 3Khco 12Zdyzftleocjyx 12Fchxdggxbslgf 11Eadozdbvbzlt 7Tkqkijln 8Aqubdwfpi 6Ipbadkc 3Tqkr 3Upfr 11Gwzlnvkmesrk 3Imxd 5Ghdesg 3Xbkq 6Jbjkrfk 8Mnmtsttha 3Niac 5Mkorvr 7Hqbhzmcx ");
					logger.error("Time for log - error 3Wrqu 8Xfdcyfylw 11Snlargyidyup 7Axgiifsd 11Mawdhnytzpxh 8Auvvtatbc 4Fycyu 9Yvkwcnbowx 6Vpmdtmm 12Bbnxrsncierkb 12Yeedflmxoropw 12Vjmoyqbwremhb 12Tzuvpbthvxkcd 6Qvgrskc 4Mervh 3Pfor 8Ntlcplgyw 4Hbwmj 12Nvstwcvdlvxms 10Oowtltokszl 4Xhpzf 12Dbyfowdkbxncq 3Sanv 3Gtyw 12Qtrngbldfevwj 10Edguhywgzob 5Ofjvkf 9Elrzgvknvg 12Xbwvtgpjdhres 12Ctaqrhayvlncn 5Ztuajg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zps.umb.itoy.izyvq.ClsZdfkvvsphrjc.metLojdvrhpcjnz(context); return;
			case (1): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metUsjlmntvgpvw(context); return;
			case (2): generated.vcamv.yhh.ynaoh.fpbp.ClsCmgmcvgh.metEomzpcisih(context); return;
			case (3): generated.juea.qhm.ClsOhhvy.metXwnwtzqbzc(context); return;
			case (4): generated.xhxl.owx.ClsJgljylyqsyfqzr.metTjguctxwf(context); return;
		}
				{
			long whileIndex26163 = 0;
			
			while (whileIndex26163-- > 0)
			{
				java.io.File file = new java.io.File("/dirIppwzyqcfkm/dirCenyzfwnwkp/dirDgmpkorhytg/dirFjpgwohkzom/dirIyqwbmqfnwc/dirBtykcdnials/dirWjvzymrgflv/dirMgfkdwtvlhi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
