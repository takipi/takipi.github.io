package generated.afllp.gwt.xvrk.rxvp.rryr;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQsqze
{
	 public static final int classId = 495;
	 static final Logger logger = LoggerFactory.getLogger(ClsQsqze.class);

	public static void metJjhfwnwz(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[9];
		Set<Object> valYeeklshqlqf = new HashSet<Object>();
		Set<Object> valFbextipplth = new HashSet<Object>();
		String valJrnlclnipbv = "StrFlpyrfmqlca";
		
		valFbextipplth.add(valJrnlclnipbv);
		
		valYeeklshqlqf.add(valFbextipplth);
		
		    root[0] = valYeeklshqlqf;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Olahvfpdsyj 6Tmmbakk 11Eufxptdejocr 7Rrgfizmp 6Adftije 12Vtlbdncpyfaid 5Qpekeu 3Pfup ");
					logger.info("Time for log - info 7Cblepmuc 10Ogkpcelhmdj 4Awdqn 5Hbvlqs 6Escmnmk 10Wanahffuojw 8Davcvgmdk 6Sfuvmoq 6Xtlceie 4Pjxar 10Ezvkpkgpdzy 9Kdpacutthj 9Vhvvqmdmwf 8Dlvyxbusf 4Itluk 6Rehafyg 10Ytcrhfcdabg 4Zwpvp 10Wkpnxntaodf 3Kjpo 9Orogbcoqqo 5Tizuld ");
					logger.info("Time for log - info 12Dytqfcrnweafh 3Cxmb 12Dmytvokyjlmnk 6Tvmwbcg 11Dsatppfpoykc 5Srdjgo 5Qsggov 10Iusreoupznd 10Ijmejkbdspo 9Mbuglmjjgb ");
					logger.info("Time for log - info 6Ewjjrrd 6Dieoomz 12Sdsqjpbmvqlsg 10Bhgctwdxfod 3Ttxh 12Qxulkxhevaxic 12Goiautswanrzt 4Zgaqr 12Roemthrdgettu 3Aqkw 9Apmxawlkvf 9Knvvjeoqhy 8Ususqagtv 10Npipcriptyr 6Kirrzmx 10Qntgyliblea 10Xnjlvacociq 3Pgrz 3Dasp 12Sqztwwqnhynci ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Rsqnugbtoiot 5Bvcfxi 5Heglhc 6Xqajeux 11Ksnmprpbytcz 7Kfazcuog 5Dhezst 12Acgxgatmyqlib 9Pplffxochv 3Duky 5Zvicfy 7Teidmltl 9Jzqyvidryl 6Mybozci 3Hmlc 11Clfgvsvjqkjx 12Lkrtqoizyqmyz 5Ejvxjc 9Umsfcfxppo 12Owgjpdvvzxfch ");
					logger.error("Time for log - error 7Szwsehic 10Xfqgbvtmrdz 5Hypbgz 10Faollfvrzhd 12Ydtkwtngzgdfq 9Pjodrnixsy 12Gjetiqairzcqa ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hdrlt.jxdm.bjqs.pupxs.ClsZoyaigxdyb.metNiaan(context); return;
			case (1): generated.ajbel.dvbe.pmx.gfhen.qjvpo.ClsFwkvrnv.metXipxiwvyvncxvi(context); return;
			case (2): generated.yudi.kwckr.ClsDwmxwqmygi.metIhnyn(context); return;
			case (3): generated.rprz.twb.ozdl.ClsMnahuieydv.metLsuejvaasjahy(context); return;
			case (4): generated.sik.dyw.jmm.xdu.omh.ClsVarjcvcyur.metByqfmiwdnyl(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirEwqlztolhos/dirWqmrqqmrzsw/dirPaazbadvctu/dirUtpfsdyglfs/dirPplmwilazrt/dirTejcjgosykz/dirBakaobiilml/dirWbetduqlyqw");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex28330)
			{
			}
			
			int loopIndex28328 = 0;
			for (loopIndex28328 = 0; loopIndex28328 < 4449; loopIndex28328++)
			{
				java.io.File file = new java.io.File("/dirMupwemltwza");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metAhakkvuwvxdcqo(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValCygllocxauz = new LinkedList<Object>();
		List<Object> valDbpsfeqkrhy = new LinkedList<Object>();
		int valAplobtpaxdx = 804;
		
		valDbpsfeqkrhy.add(valAplobtpaxdx);
		boolean valNcuvewdcoqc = false;
		
		valDbpsfeqkrhy.add(valNcuvewdcoqc);
		
		mapValCygllocxauz.add(valDbpsfeqkrhy);
		Map<Object, Object> valYsagyrayafd = new HashMap();
		int mapValYyaeambpcwu = 490;
		
		boolean mapKeyNpmdpldbleg = true;
		
		valYsagyrayafd.put("mapValYyaeambpcwu","mapKeyNpmdpldbleg" );
		int mapValUgajbwwfkka = 267;
		
		int mapKeyFxzqaseqnkl = 315;
		
		valYsagyrayafd.put("mapValUgajbwwfkka","mapKeyFxzqaseqnkl" );
		
		mapValCygllocxauz.add(valYsagyrayafd);
		
		Map<Object, Object> mapKeyHvdcukmltaj = new HashMap();
		List<Object> mapValMdmllfuwgcf = new LinkedList<Object>();
		String valVdhbeguajiv = "StrBxnvmkmmcyd";
		
		mapValMdmllfuwgcf.add(valVdhbeguajiv);
		long valJrgnwurgmuv = -1862297475796012443L;
		
		mapValMdmllfuwgcf.add(valJrgnwurgmuv);
		
		Object[] mapKeyWvypowtcdlw = new Object[2];
		boolean valQmehjmbzooi = true;
		
		    mapKeyWvypowtcdlw[0] = valQmehjmbzooi;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyWvypowtcdlw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyHvdcukmltaj.put("mapValMdmllfuwgcf","mapKeyWvypowtcdlw" );
		
		root.put("mapValCygllocxauz","mapKeyHvdcukmltaj" );
		List<Object> mapValRecvijohfuv = new LinkedList<Object>();
		Object[] valJozxabegjfo = new Object[6];
		boolean valIzhfcirmvhy = true;
		
		    valJozxabegjfo[0] = valIzhfcirmvhy;
		for (int i = 1; i < 6; i++)
		{
		    valJozxabegjfo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValRecvijohfuv.add(valJozxabegjfo);
		
		List<Object> mapKeyKgcqjtahgpb = new LinkedList<Object>();
		Set<Object> valPzaizkqahuy = new HashSet<Object>();
		int valSanofrgvkvt = 275;
		
		valPzaizkqahuy.add(valSanofrgvkvt);
		int valVoigesqseyj = 630;
		
		valPzaizkqahuy.add(valVoigesqseyj);
		
		mapKeyKgcqjtahgpb.add(valPzaizkqahuy);
		
		root.put("mapValRecvijohfuv","mapKeyKgcqjtahgpb" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Snqtfmuyyxaos 5Jwltpq 7Kxdrffxf 6Maudpka 5Nsmjzv 8Hpjjrwsjn 5Ryrznx 11Yjpyxomseycq 10Eebbuupacsq 4Olbdv 3Boxp 12Xugdlbvcearsy 4Iwvbr 11Zsvjogwwnmtg 7Mexgyijs 8Waqhxdffu 4Embma 8Wklledhxq 5Mglzur 9Cktsnrvebk 7Ejgzqzvx 8Qrmfktzeq 6Aisgvou 7Ywejamoa 5Xjvfkh 10Xuzuojsohyj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Ppvhewtepj 11Lsebymodabfu 10Ukcdfvxgwaw 3Dkai 10Oyhcnlrrisc 10Avvygbysvpj 3Qihk 8Yunfezdws 9Hjsliddfbl 10Jkbqqqzljqn 12Nfcrunitndhwp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zps.umb.itoy.izyvq.ClsZdfkvvsphrjc.metYvhtzzazeiso(context); return;
			case (1): generated.dyv.vxo.ClsWrwpfswr.metBamfflypcsi(context); return;
			case (2): generated.ddlri.xli.qud.ytlvf.ClsNvsmjkbfbxcsj.metIasfjtbluwvaig(context); return;
			case (3): generated.jugrx.qsp.hjtfe.ClsIaayunfezbzpm.metEilzljhjnznyt(context); return;
			case (4): generated.lxeoh.qnh.crznc.ifldw.owge.ClsJaitfhoyoqqri.metWxvdhhdzs(context); return;
		}
				{
			int loopIndex28333 = 0;
			for (loopIndex28333 = 0; loopIndex28333 < 8037; loopIndex28333++)
			{
				try
				{
					Integer.parseInt("numXzcrztolxoa");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirObruygytyla/dirOzbrjasnqov");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numIyocdyretbs");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metUgmauegqryzcz(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valIxjwxhniyer = new HashMap();
		Set<Object> mapValMcydiqufamq = new HashSet<Object>();
		int valVgzevzkbiya = 363;
		
		mapValMcydiqufamq.add(valVgzevzkbiya);
		String valOnhmpbhssai = "StrRevhhbanblj";
		
		mapValMcydiqufamq.add(valOnhmpbhssai);
		
		Set<Object> mapKeyPotjkanwoiy = new HashSet<Object>();
		int valAhgtgicxtbm = 796;
		
		mapKeyPotjkanwoiy.add(valAhgtgicxtbm);
		String valExbuwcaouph = "StrRmfrmoyvgot";
		
		mapKeyPotjkanwoiy.add(valExbuwcaouph);
		
		valIxjwxhniyer.put("mapValMcydiqufamq","mapKeyPotjkanwoiy" );
		
		root.add(valIxjwxhniyer);
		Set<Object> valTuwitwdlswm = new HashSet<Object>();
		Map<Object, Object> valCnvqyzaaehr = new HashMap();
		String mapValUxvbpruhowd = "StrHbojagdsmoo";
		
		boolean mapKeyEksltyrnsdq = true;
		
		valCnvqyzaaehr.put("mapValUxvbpruhowd","mapKeyEksltyrnsdq" );
		int mapValYcwmqszioji = 583;
		
		String mapKeyGknbbebkqtq = "StrGstpcnrypan";
		
		valCnvqyzaaehr.put("mapValYcwmqszioji","mapKeyGknbbebkqtq" );
		
		valTuwitwdlswm.add(valCnvqyzaaehr);
		Object[] valQhjtukfnssu = new Object[2];
		long valBxsyvhwluwg = 8105138787968591630L;
		
		    valQhjtukfnssu[0] = valBxsyvhwluwg;
		for (int i = 1; i < 2; i++)
		{
		    valQhjtukfnssu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valTuwitwdlswm.add(valQhjtukfnssu);
		
		root.add(valTuwitwdlswm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Rpcrhdschmx 6Mvqcmhz 12Iftyetqsdnaoj 8Mjtayshsd 5Uihiti ");
					logger.info("Time for log - info 9Lmrilagipr 9Pcokkeqssp 8Iowkrlqbj 4Pvjne 4Ziwwl ");
					logger.info("Time for log - info 6Lqfxaou 10Mxsgbbwxscc 5Dfgzwt 11Awqkrgwwdvpo 3Mqsl 8Bdulostzb 6Mkcunbr 12Zacrqtlytrijh 7Dxftujez 10Baoduvcjhli ");
					logger.info("Time for log - info 8Ualqimmws 12Dxxjpkxudvuha 6Solpnbc 3Xchs 4Hultj 11Mpymgyauqpmn 3Hqpf 3Tjko 7Jikecvvd 7Efebiuxq 3Cqii 7Vxzbbqyp 3Acda 11Mupoogoykfmh 8Nwpjrsivc 12Gvinvssidiloa 12Ntftafavtqrzw 9Vgcsjuyfbv 12Obimkhafrmfjj 12Iusirzrafsljm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Ihcblyrpvha 3Wwzk 6Biuugnr 6Nhxxrnp 4Bmztg 9Kflpsehffv 11Tgmkwwqtlnxw 5Yijfcy 11Ncgsgvhqzazq 7Yivyohmx 7Fjxgvvua 4Jisam 5Btvawa 11Hkmweknnvswg 6Ykgxiun 10Wsupspixtgi 7Qxjegxyt 10Cvpqjaifnfz 9Vndnjlllql 12Ngyyhjnjvfwjt 5Hcboin 5Jiftlg 12Ttjizwdooihsl 9Ryajqkudwh 5Ktfbpv ");
					logger.warn("Time for log - warn 6Nccvebl 12Egbggbpoiqlln 10Icohsmgobud 4Rldcn 11Nxfvvjiicjjn 4Sbdrl 4Wzasn 11Nfiyjkpgtwxj 4Udrhu 12Oiauozoprdzku 5Qzfqcx 11Kwqrnmzsmmfs 8Rsmflepaj 4Kmigc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wtc.bgb.gahv.mul.rts.ClsUeuxdzs.metGmiqxl(context); return;
			case (1): generated.crkmz.uuny.smq.vvmxn.khxb.ClsQbvzuhroxdituh.metVqzfw(context); return;
			case (2): generated.yaahc.bwx.upsjn.ClsIxadk.metNgwdnrzldyl(context); return;
			case (3): generated.pli.sac.lcrkw.ery.xwlo.ClsIghyijbnkvoubq.metJbowqxymhh(context); return;
			case (4): generated.joeal.ovr.nvb.kqkl.kegr.ClsNehitk.metGvuga(context); return;
		}
				{
		}
	}


	public static void metHxgvbl(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[9];
		List<Object> valQytoyxrbtyi = new LinkedList<Object>();
		Object[] valTzvevuirqzt = new Object[11];
		long valKyuolifvoxk = 5373754417515586047L;
		
		    valTzvevuirqzt[0] = valKyuolifvoxk;
		for (int i = 1; i < 11; i++)
		{
		    valTzvevuirqzt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valQytoyxrbtyi.add(valTzvevuirqzt);
		
		    root[0] = valQytoyxrbtyi;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Kftdftlm 8Lmttgqhwn 9Diincvzhuh 6Kgdthbg 12Yriiwryhjgioc 11Pajgbcznkfem 5Quyhwg 11Wnxbyfozuyiv 10Lqzbssfljdw 11Aihztjcjmmak 4Kxlqa 4Hvxsx ");
					logger.info("Time for log - info 11Jijjjivfzhiv 4Tfbic 7Wskqamxw 12Fasrdcipagexx 4Snftt 12Fcyupwcdjmvao 4Amvhr 7Bewczhmq 3Kzdo 3Rnod 7Bkszadob 11Yodayztannre 11Ellzjpjclrtr 5Uxwiie 10Czdknmuugiy 12Gkwbjluvizkfn 8Saxvkoamb 7Gblwrwey 5Njwbln 7Glezowml 12Uvhttzqcjwatw 9Hfqbysasrj 9Gvdrcdvhon 8Jfywwoszp 5Lfbjdw 8Nauohdlxh ");
					logger.info("Time for log - info 3Gdis 10Tdtblblaceu 4Zudek 3Wyjn 11Xcvtwvbcylsm 7Wgppgabg 3Lkpg 12Papxsnclcztqu 6Dbtwhdl 10Mpsxdokhwzr 12Jpgfnuhcklagd 5Ymheuo 10Ytxrrquuyuq 3Snlo 7Utpkpsbb 6Nwyiqvw 8Vivnihqoe 6Qghprfl 8Qbvcfubde 7Tmrvfkdj 4Ritas 10Yduoyvimbcd 6Bpoaosx 6Hchngfq 8Znjhjycbw 4Abfdw 11Eorlwriamtzs 6Ihdmsja 9Msefqudgxx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Absyuljgabdn 11Znpghpsiufvd 12Vbvifmldvdeqb 10Szsgyzfizrh 3Xzxo 9Nfofibevou 4Yclpf 6Bcvwngt 12Kizhrdwbtiytk 8Jpvdvhyge 7Nuffonbc 10Rrikoqaqqpw 5Mzzflt 10Nemezwvdrgv 5Sejwrk 10Rfjbfyfkksg 3Qvgd ");
					logger.warn("Time for log - warn 5Mwmcjw 12Ptpyflvkbzttv 6Yqrqwtv 7Cioqbohk 10Qikxcwdfaoq 3Bgbk 8Kztmknpka 10Gksvofmuiqi 5Lbtfrx 10Soplmnvzhaj 5Pnvnsk 4Ijehh 8Hcedpqtsu 8Quaoiheeq 4Kysqc 11Aalwwgmxfxkj 7Lvtenscc 6Krezfdd 9Hakxdxbjkd 6Tkbvypd 7Flgoehjs 10Ahszedwketd 7Hhvjpxwv 8Foehuapod 5Upazmw 8Jvgluybjb 5Rsioxn 7Gezxpwyo 11Ykszirexfipr 10Txwiommociq 11Obkkfllpjfgt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Rldpwg 12Igfuauneessth ");
					logger.error("Time for log - error 10Uaewqcwwfca 10Xickwvsxslc 8Cgoliucpx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hgr.jgeh.ast.ClsBwtgykt.metBmeyjwcjjjikwl(context); return;
			case (1): generated.zps.umb.itoy.izyvq.ClsZdfkvvsphrjc.metAnxtjbnxsdbeg(context); return;
			case (2): generated.fkbuh.vawj.ClsXsqsadsvdke.metGrquryhkwyi(context); return;
			case (3): generated.dyv.vxo.ClsWrwpfswr.metCedzccdg(context); return;
			case (4): generated.bhfun.zpnwj.czfe.augg.ClsEdcxpvndelttu.metLjdhznxjbmt(context); return;
		}
				{
			long whileIndex28344 = 0;
			
			while (whileIndex28344-- > 0)
			{
				try
				{
					Integer.parseInt("numVkloqjwpxyj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numXthtinrjsge");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex28348)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
