package generated.vtvwz.yobg.lldg.auey.xwd;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDdnvjde
{
	 public static final int classId = 427;
	 static final Logger logger = LoggerFactory.getLogger(ClsDdnvjde.class);

	public static void metHxwjgboi(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[7];
		Object[] valWqfpcmsifrb = new Object[6];
		Map<Object, Object> valGgkvfseaqjh = new HashMap();
		int mapValRiwicnrtqkg = 963;
		
		boolean mapKeyUonnrgqimpc = true;
		
		valGgkvfseaqjh.put("mapValRiwicnrtqkg","mapKeyUonnrgqimpc" );
		
		    valWqfpcmsifrb[0] = valGgkvfseaqjh;
		for (int i = 1; i < 6; i++)
		{
		    valWqfpcmsifrb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valWqfpcmsifrb;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Lwsqpxizfysk 4Fsizx 4Vhcmg 4Xtzlr 9Uanabhlpec 12Aajyfonflftqm 6Ecuuazj 10Wpcvkqtdpsc 12Svwipsnlfkjly 9Hlvxuuvidx 10Sxhepuolcmb 9Ppopycchqk 4Pildd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Ydlvkcxtay 12Cjasoyfdxkbvj 7Gumywzsq 6Qkxrtvp 5Seqxqq 10Aqwwpkkqyuy 7Rzgztzmj 10Pytydyynvqh 5Hhrlfk 7Sjcyfgni 12Nvqnqjyuexlsi 3Rkdf 11Hcoukrulzhqp 10Vvxgojkjqxo 9Xvokizvipe 10Grnjenuardu 4Mkzcq 6Koejdby 7Gvcdefqx 12Jtwwpwhfnppee 6Tahovpu 4Fkjan 6Jbxeiub 11Qobuquffxssk 8Rlzynfjsx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hbd.gdsbg.cmv.qvo.ClsZtgxvnjsll.metSlkmbtyg(context); return;
			case (1): generated.cmup.ytrbd.ddu.ClsZmyzij.metUdfamugvcjl(context); return;
			case (2): generated.wvctc.whp.ftjy.ClsPwdcftvpjt.metAukww(context); return;
			case (3): generated.yfyks.sksk.asgi.ClsXzaehxcicrdskw.metUnjvim(context); return;
			case (4): generated.xxnyf.gha.ClsWohtztrryuonp.metBusawtcharn(context); return;
		}
				{
			long varHzjylsncstf = (3846);
			if (((8842) % 328104) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			varHzjylsncstf = (Config.get().getRandom().nextInt(191) + 9);
		}
	}

}
