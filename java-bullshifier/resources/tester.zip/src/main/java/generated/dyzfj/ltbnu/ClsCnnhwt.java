package generated.dyzfj.ltbnu;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsCnnhwt
{
	 public static final int classId = 187;
	 static final Logger logger = LoggerFactory.getLogger(ClsCnnhwt.class);

	public static void metAwrkzvmc(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valVumjrbqwyiv = new LinkedList<Object>();
		Object[] valCpxblmdyyya = new Object[9];
		String valYzcqyewylxv = "StrEwxomgmwhat";
		
		    valCpxblmdyyya[0] = valYzcqyewylxv;
		for (int i = 1; i < 9; i++)
		{
		    valCpxblmdyyya[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valVumjrbqwyiv.add(valCpxblmdyyya);
		
		root.add(valVumjrbqwyiv);
		List<Object> valFmfaahtknot = new LinkedList<Object>();
		Object[] valCuqdkgmlkvl = new Object[3];
		String valTufqwoqdphl = "StrFhilbtxwoxw";
		
		    valCuqdkgmlkvl[0] = valTufqwoqdphl;
		for (int i = 1; i < 3; i++)
		{
		    valCuqdkgmlkvl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valFmfaahtknot.add(valCuqdkgmlkvl);
		Map<Object, Object> valFpdojokxvmo = new HashMap();
		boolean mapValLiodhfvrfvr = false;
		
		boolean mapKeyCmgriftmttm = true;
		
		valFpdojokxvmo.put("mapValLiodhfvrfvr","mapKeyCmgriftmttm" );
		
		valFmfaahtknot.add(valFpdojokxvmo);
		
		root.add(valFmfaahtknot);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Llsorwdxjf 6Olcmmhn 3Xxia ");
					logger.info("Time for log - info 11Ahakvvscvowg 4Pwabc 10Crldxwbtwcx 10Egmgvmmivux 5Zwqjcf 10Xaupdvgxfyf 6Ifxkbrh 6Blnffuo 9Gzlssiagqf 11Arhsxrnmcffp 11Foilhmqrzehg 7Hhezdzjo 10Yonhmtqrlfv 3Heyd 7Zxzvanmw ");
					logger.info("Time for log - info 9Qangvdixki 8Eegmqrhuc 6Eiybkoh 11Pzczywjzqrrf 11Bbfigithpixi 10Xflgzcldfho 5Vxmomn 6Aottnyb 8Djsfhkugy 6Mfcsnvs 12Qbdwsibaczuju ");
					logger.info("Time for log - info 7Vsccmzgt 11Viljamrpajdm 11Cktiyduwauid 11Gyyqsdmzqmji 11Iydlksraemhw 12Nslvyxmgscfiu 11Xknvjiabvync 4Emnnu 5Ggeqoo 7Baeykubn 10Ugxmhfpufah 7Dknkrwlp 11Ybqyuazdyjov 5Mzizhs 11Hiuvddfevjsf 7Bwxecpjs 5Rtwpfu 9Rnhffenlcw 10Qmfxdxtboui 12Welfnzuhypwsr ");
					logger.info("Time for log - info 3Kkjg 11Cwcdeajpbzpu 10Aphxeojjwdc 7Rqypgypk 12Vtgjawepnaxbv 3Qdik 4Tbuzb 8Wnoeoxbxn 4Ieewa 3Nyto 10Vsdvrckuhxb 7Uvykiqcn 10Vqspjxhsfns 8Nfubxrvxw 5Qreztn 6Tskoiok 6Wwjggvn 9Dktajfczqs 9Pkcdlkqced 3Bkvv 12Ahaizpljtwdmz 5Nkulgl 12Pfbbexvxtoign 7Xyzlhsmw 4Mmzzu 9Cifbhjgcou ");
					logger.info("Time for log - info 8Vhpojoaxl 3Uywf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Wlquevikyqzgq 9Ayfrrvdppp 6Mteattc 11Znwznbeoadgw 3Ooeh 6Vgxrqkb 7Vbczdasq 8Ottjwitdf 10Aqzfywzetoh 12Ohsxafddupbmq 6Occdhvc 11Oiimbqmuolpy 10Bpxehkcpujb 10Bxhandzwgax 9Hkdmqsxpgi 4Pfvaz 4Owtih 6Hdgupoy 11Lvolejzbcovc 3Oaul 12Irnyrfaalsztb 6Ogttuue 6Mqcnuaw 11Bzfhpsehocum 7Rcenbfuc 5Eyuupb 5Vnkcmq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Bftt 5Ytcrpt 8Fimxazuar 3Ovfi 8Ljjxwuzfq 4Buzyx 11Wzcmrkxodyqh 10Aaswragaqhw 8Qkdhqbomu 9Wfagvmlngf 4Ajrbs 10Dhylqkmyjxt 12Zpjtiavdrwkbi 8Gmeirtvhs 4Kclks 4Svvnw 12Nigyyicxqgxuf 7Kbjmzgke 12Koaoletnejepx 4Slfgb 5Gkytjl 8Oikviglkx 11Ssoiuvlufwng 11Ovxrbguxwlzv 7Evafiijh 3Ljfb 12Wjvizeirsqdjc 4Htaqj 12Moufgmgzkmhbz 9Mckcgwvali ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wier.vwsz.frtoe.zpo.ClsRwhkekxcsmjus.metDnxwcgye(context); return;
			case (1): generated.javqv.ttek.ClsJqite.metZuokvxyfddpvoh(context); return;
			case (2): generated.qny.ksq.ClsEbyoh.metHkmkfawxahv(context); return;
			case (3): generated.vntk.clexr.ClsYpzzbhceuihjz.metZikaf(context); return;
			case (4): generated.dyn.peov.bqa.fptp.ClsXhblgjpkehiigi.metEiaaqrx(context); return;
		}
				{
			if (((2287) + (Config.get().getRandom().nextInt(483) + 5) % 116408) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((7527) + (5472) % 779545) == 0)
			{
				java.io.File file = new java.io.File("/dirAaphwgvulod/dirIpbifhisiea/dirBkrifkyxlka/dirOkveivnqvui/dirMuwsudxbpil/dirIctsubwselb/dirXfxnpantvec/dirQuwcybjjapy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metTzpco(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valMgekkbsnrrr = new HashMap();
		List<Object> mapValOvmpazjlbvi = new LinkedList<Object>();
		int valCkyhxuprucz = 707;
		
		mapValOvmpazjlbvi.add(valCkyhxuprucz);
		String valTstsvyjdbih = "StrGdpjrqzepwv";
		
		mapValOvmpazjlbvi.add(valTstsvyjdbih);
		
		List<Object> mapKeyJygukroqgrk = new LinkedList<Object>();
		long valDhokhroxnhg = 912842722495760607L;
		
		mapKeyJygukroqgrk.add(valDhokhroxnhg);
		
		valMgekkbsnrrr.put("mapValOvmpazjlbvi","mapKeyJygukroqgrk" );
		
		root.add(valMgekkbsnrrr);
		Map<Object, Object> valXnvxccgumks = new HashMap();
		Map<Object, Object> mapValKebwmcgpobg = new HashMap();
		boolean mapValTnkojgzputn = false;
		
		long mapKeyXjpadtjervp = -1182256442193896158L;
		
		mapValKebwmcgpobg.put("mapValTnkojgzputn","mapKeyXjpadtjervp" );
		long mapValXddqqqxgzaa = -5321716663107679338L;
		
		long mapKeyQnetljihejs = 4373846666082378972L;
		
		mapValKebwmcgpobg.put("mapValXddqqqxgzaa","mapKeyQnetljihejs" );
		
		Map<Object, Object> mapKeyKakflitanao = new HashMap();
		int mapValGyjeiyxcehy = 629;
		
		String mapKeyKzkonfjoung = "StrOhrpkqvmeug";
		
		mapKeyKakflitanao.put("mapValGyjeiyxcehy","mapKeyKzkonfjoung" );
		
		valXnvxccgumks.put("mapValKebwmcgpobg","mapKeyKakflitanao" );
		List<Object> mapValUcjgsovfexr = new LinkedList<Object>();
		long valXsdzooszwfh = 3832335785112995927L;
		
		mapValUcjgsovfexr.add(valXsdzooszwfh);
		String valHbawybpzfbt = "StrDwvqgnoqoac";
		
		mapValUcjgsovfexr.add(valHbawybpzfbt);
		
		Set<Object> mapKeyIpctzszsrna = new HashSet<Object>();
		int valVrfjfbvbpct = 638;
		
		mapKeyIpctzszsrna.add(valVrfjfbvbpct);
		int valKyoohsrqrvw = 238;
		
		mapKeyIpctzszsrna.add(valKyoohsrqrvw);
		
		valXnvxccgumks.put("mapValUcjgsovfexr","mapKeyIpctzszsrna" );
		
		root.add(valXnvxccgumks);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Jaarbgn 8Gtsujhiqt 8Dzepmwtec 4Eddty 9Tweuxmrjxi 4Icruk 11Nahtluyqiczh 9Igaispyjmj ");
					logger.info("Time for log - info 7Ooirolvj 9Alkxqqfnzx 4Dnuwb 7Cqbpnvkz 10Bxocmzvgjgj 10Cgdfhxfsfhv 12Hwpvoqqziohnu 9Yieeutyqlg 9Lbrbkpdead 12Fbekpmjcufoov 11Djmwugnuyerr 5Qzjigd ");
					logger.info("Time for log - info 11Albwbkywdmom 9Ninlpufffs 11Ntnkzcisvmuk 3Swfq 12Svrygyypzrywx 11Uaqgcstuswzd 7Zuxamgtr ");
					logger.info("Time for log - info 9Hrwxqpwyyz 5Ljwcqo 3Czkq 12Atigsyhfukbgx 9Srivkelzns 6Vzsobip 5Dmcifg 9Cnmpkqnqxz 5Uxvvzp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Ccqnyt 12Igosvvlmhqeyx 3Qvyr 5Gukske 3Nqgu ");
					logger.warn("Time for log - warn 10Hfackdrlrcl 3Axfk 9Goojhcwhhp 3Xdus 4Rxhfz 5Wvtjnl 7Yuisimli 12Ysfbdvrjgvjrc 5Jdbytg 5Bxmzcc 8Pwqkvbrab 5Hhxetm 12Vkultgalkxtko 6Gaqdvsv 12Scmvsudlmmmjt 7Pilqezrj 8Qhnfevcei 10Sxeasxxcidv 9Vyyeznmblr 7Cuhhfvvq 10Ghplhfdbpgx 12Dgwbvpxsjduzn 5Gkavek 7Kzgkvovs 8Eeacsuxza 11Lxywpmcxylth ");
					logger.warn("Time for log - warn 6Zcjwkpt 9Idmyetlizm 5Pzzymg 8Lbsnekdjq 4Lwcax 8Iwjbilekr 12Yijshcngjqgnt 3Wfdi 6Lcmbchx 6Vkqnyoj 4Immyx 12Fqqlolyofgyeb 6Orfcgot 12Hdgviaufubmsg 8Zsyqrzynl 12Xwsieyiqinhxg 6Ykpvtko 11Mjgxcxrppxza 6Icmqpaz 11Osanvklcspfo 6Uslkuhb 4Ctkaa 12Zugjbklltpbxy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vqli.xqs.ist.rcg.ClsUlfrrjkk.metUracnapyxnrd(context); return;
			case (1): generated.qpe.ifudp.xgatn.jzg.qau.ClsJymdeqopgpbo.metZmvopmy(context); return;
			case (2): generated.ojyuy.hdvu.yij.nuf.ClsJtdiu.metTlubvqwqs(context); return;
			case (3): generated.zps.umb.itoy.izyvq.ClsZdfkvvsphrjc.metYvhtzzazeiso(context); return;
			case (4): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metKlgcwsafmqppr(context); return;
		}
				{
			long varCwvymoktwhu = (9925) * (4674);
			try
			{
				try
				{
					Integer.parseInt("numJeczunmqkoj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirKbawioxqxsb/dirNqhpiwwjrqd");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
