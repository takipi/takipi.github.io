package generated.hbd.gdsbg.cmv.qvo;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsZtgxvnjsll
{
	 public static final int classId = 81;
	 static final Logger logger = LoggerFactory.getLogger(ClsZtgxvnjsll.class);

	public static void metQvkbrrhkdtwqhx(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valEwoaaidnuii = new HashSet<Object>();
		Object[] valOpvkunlvzab = new Object[8];
		long valNhglazcgkec = 8953045387242651630L;
		
		    valOpvkunlvzab[0] = valNhglazcgkec;
		for (int i = 1; i < 8; i++)
		{
		    valOpvkunlvzab[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valEwoaaidnuii.add(valOpvkunlvzab);
		
		root.add(valEwoaaidnuii);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Vdjnhsmldfatk 12Sdvmgszslncbg 3Oszu 7Evyiytpf 8Lpzjkniau 9Adobqyngwa 5Vrklbi 3Tyqe ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Iiiakfwveexh 7Xmwvvdmf 12Lxjclyxxdvohp 8Otlmgcehl 7Scekvjev 10Xelfpypnrlq 11Ggfwhdxxkiuf 6Hdorzqi 9Lbdrzgeibr 12Azrnxlpblcwbq ");
					logger.warn("Time for log - warn 12Uzparowoybxcd 5Nmmirt 7Tqtvhsge 5Uavotk 3Biqj 11Itqswdkpymii 11Ewzpqsdvoxau 4Xwxye 4Ixbdh 11Hzojkdbltxnq 4Gbkin 12Fvjbzsvmdbsoe 8Dttqanoeq 6Crlavse 7Dbhqcsyx 10Gabhfidorro 9Uapailsqaj 9Mjliaevipj 4Eguxg 11Tsmwywmofgpx 10Ijyfnnvfsep 7Nvqaydae 11Vzengwfqvvlm 3Egpf 9Xksztcyuin 7Ozroayiu 12Itazpggkipnuk ");
					logger.warn("Time for log - warn 9Sqxjujxesh 10Xlrskyiqemh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Femulmhur 10Gftqehhvgxr 6Ctwtigb 3Mgqt 8Ktjdkadoy 6Yidwdjb 11Lkafxgbwqwaq 9Batdlerkan 9Cihfkbpglg 7Jucmclhj 5Hxsbmm 6Arakick 3Mrkc 3Fhjf 8Amashaobo 7Ossxajzd 9Hcqrxchlqc 4Fvobh 8Hbyztgkuo 6Bawtgtz 10Sktvgjxmhty 10Yojwuykcqqf 6Ijdssyw ");
					logger.error("Time for log - error 4Ictqu 6Skkacpq 3Gzzk 11Yabqjgmrpzds 6Eapharu 7Fjkogtis 8Rfumlnzfp 10Kemujomwyfz ");
					logger.error("Time for log - error 5Xdkrvm 9Ydcwwhuwsg 9Iwziwfxzrt 12Whfhbrodoonao 4Lwmav 11Rnznxwlodfrt 5Yabvhi 12Sppnuxabdsjan 9Zbemxihicp 3Unaf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pgfis.zew.ikgq.ClsEgsupkocifpi.metYobadnrmqm(context); return;
			case (1): generated.gpnn.qul.pdexl.hxjph.zmndq.ClsIcvyndtrplxfkf.metNldde(context); return;
			case (2): generated.dvks.jsbpi.ClsXlatniflz.metIhawpoyjsfgfom(context); return;
			case (3): generated.zhzbs.ylhl.ytr.cges.stvq.ClsYeenuinrut.metRuxodvwf(context); return;
			case (4): generated.yfo.dls.qwny.cqaxf.ClsDosmbrrv.metNtnwha(context); return;
		}
				{
			int loopIndex21449 = 0;
			for (loopIndex21449 = 0; loopIndex21449 < 9693; loopIndex21449++)
			{
				java.io.File file = new java.io.File("/dirQystztmtijm/dirJbhdjgawuos/dirZmkxkqndsgu/dirLgssfpgpmct/dirAqumjttaebc/dirAurgxtehwdy/dirAgcnmmmauji/dirZqzcodophwg/dirKntffaxwqzz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex21450 = 0;
			for (loopIndex21450 = 0; loopIndex21450 < 9108; loopIndex21450++)
			{
				java.io.File file = new java.io.File("/dirYnbfgqzjhay/dirYucgvqqovgx/dirHodcdjspbgf/dirMpsmgifxvqt/dirXdqgcittvvm/dirRvkapoxbhjl/dirSyvxqixjtri/dirXbmepqamqmr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metSlkmbtyg(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valYkxorxwewlp = new HashSet<Object>();
		Set<Object> valGpdymukkwho = new HashSet<Object>();
		long valJnioqmrcgoh = 1480011633202757203L;
		
		valGpdymukkwho.add(valJnioqmrcgoh);
		boolean valQczvvvprrht = false;
		
		valGpdymukkwho.add(valQczvvvprrht);
		
		valYkxorxwewlp.add(valGpdymukkwho);
		
		root.add(valYkxorxwewlp);
		List<Object> valLwosnosxeyq = new LinkedList<Object>();
		Object[] valEomnrgmlari = new Object[4];
		String valThetluhdzsg = "StrQqujfmyzqtc";
		
		    valEomnrgmlari[0] = valThetluhdzsg;
		for (int i = 1; i < 4; i++)
		{
		    valEomnrgmlari[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valLwosnosxeyq.add(valEomnrgmlari);
		
		root.add(valLwosnosxeyq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Ixcd 7Wcmwmihn 8Dsmmiansi 10Ticxziwwnve ");
					logger.info("Time for log - info 3Hqiq 12Qijxcdqzmegnu 3Zbgd 6Hgdtwin 10Gxqoxjckmpw 8Erwqxdbsg 8Vveqaptcb 11Lxakzribvdpl 9Yoktakqpdr 7Dwutajks 6Oykfiif 12Mvakruuxjdnjd 4Turhi 10Ighnzbhyhgh 12Dbpurskahipwh 9Ttlxypkwbd 9Yzmxafkqjw 8Hzomolwxt 12Zhioxfagxfyfh 11Aspwnnhwgeom 12Akdpsjiocylit 10Qquhsrayywt 6Vvjeckq 3Impw 7Rqhvncto 3Khgw 10Ggqwyionqjh 8Rrzosishm ");
					logger.info("Time for log - info 4Vbwjy 3Msph 8Xsbyheytp 10Relsjzgpvrn 7Ajeazppr 9Wggmsxagwb 3Yfin 7Cullvnhf 8Dnxkgackj 5Yxyfws ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Inivwahb 4Xjoyb 8Qxebfpsgi 7Ljlxpxow 3Ckmw 3Cheg 7Szdponop 10Vyjviohhini 3Yjpg 5Jjcxtx 11Tmwxbglbtrba 4Sunum 11Avscnaypcvuf 9Twmxwwrlco 6Yjsatas 11Ojmkwvmzekux 9Mmcewwpbdv 3Anse 6Wkdqgtv 6Lpptbeb 10Mutprqhmqtt 7Pdyzwdfa 3Ifiw 12Enhxhzdchlrhj ");
					logger.warn("Time for log - warn 3Wwcr 3Jwhh 10Xxzggxvpgih 11Iwheiqhaggqt 8Vgvtluzsv 6Nznwfjg 8Trbjtgqex 5Ziuoly 8Wzqvnmxru 9Skhygxsjpb 8Umxvarfki 4Kgekw 9Hdvvkndulo 11Qtzoogdubpyt 9Spynsvoasp 11Lfqonkfoxitu 7Qgurzozd 6Cpleiao 12Liqxrhxynupag 9Nbgrzwshrm 9Oessoujnvq ");
					logger.warn("Time for log - warn 12Kkwyuokbgevhf 3Cfgl ");
					logger.warn("Time for log - warn 10Csfpyoywsmd 12Oawhtotzyicym 10Ibgynmkhagw 11Pcpxrxbsxznt 11Zlrcsiojuilb 10Wnruqhbgfoi 11Tegboutxusjd 8Vwvewhbcd 9Tjnouqjhzd 5Tlodbc 8Ftqnvxkop 12Essskhmoprwqv 12Acalvcbljstyd 12Cicnyovymchkj 7Wnzwkspq 5Rgigic 7Cdszckvi 5Qbzavw 9Thkvbhaigf 4Jgwmi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Hviaury 11Dtjdqlunnmrt 10Uztfobsrkdy 8Cyqdrydyy 5Qpbthu ");
					logger.error("Time for log - error 11Onlrvqhxxxzr 11Hmldjkndxpnn 9Cmwejmzimq 12Vwubeocqbonga 7Alufrflu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gapuh.cesf.ClsXyxpazfgwk.metNunfetlxuqsy(context); return;
			case (1): generated.ebdo.cied.ClsIqlmeepdcmuqo.metKtzhn(context); return;
			case (2): generated.hioa.tbao.juo.tlh.zgppg.ClsZtwfn.metIybrdbhypesv(context); return;
			case (3): generated.nhgg.zrfev.xud.glekl.ClsBewmjgrswbo.metWsxyvoaooe(context); return;
			case (4): generated.afz.qen.lrlj.ClsTvxlbccvg.metBrsibddpey(context); return;
		}
				{
			long varQjrrbyobwec = (3263);
			if (((1911) * (5197) % 539424) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numVmkxsuuajnj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metEkyqdfizfim(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValHunkdivavru = new HashSet<Object>();
		List<Object> valNwnjshlrpxk = new LinkedList<Object>();
		int valBuiqprxhynj = 680;
		
		valNwnjshlrpxk.add(valBuiqprxhynj);
		
		mapValHunkdivavru.add(valNwnjshlrpxk);
		List<Object> valCyrraquajht = new LinkedList<Object>();
		int valCqfizacfsir = 740;
		
		valCyrraquajht.add(valCqfizacfsir);
		
		mapValHunkdivavru.add(valCyrraquajht);
		
		List<Object> mapKeyQhqbezphxax = new LinkedList<Object>();
		Set<Object> valHldtxjeayqs = new HashSet<Object>();
		long valQxryrnpdghl = 4079447044715283139L;
		
		valHldtxjeayqs.add(valQxryrnpdghl);
		long valLgtvxdggvzf = -603023508678846796L;
		
		valHldtxjeayqs.add(valLgtvxdggvzf);
		
		mapKeyQhqbezphxax.add(valHldtxjeayqs);
		
		root.put("mapValHunkdivavru","mapKeyQhqbezphxax" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Yaumxeiwqzfll 12Hhxehdogfohia 10Hkmjiyujifw 8Ebafszvlv 9Tctjcjamrl 5Ogwrkw 10Wrshbxcwfxn 8Blmmoxwag 11Qxlqzsrgcyax 12Oxveslauihwwv 10Ltqkrbeydaq 9Zykckeuqtk 9Gaipyjafvl 5Tmsfmj 12Mijfhhzuhohke 7Xxvrgugi 5Hgohov 12Radywcjewtpvo 9Ymmkzlpxao 12Lrnoyyjxjydpt 5Hrkzei 9Sazphawviv 5Qihzgq 5Jvoxvq 6Tdgoweh 10Abjxjkplkyj 5Gigbue 9Dtmakijycz 4Qdwxr 6Jvnbzyx ");
					logger.info("Time for log - info 7Qxpdvykb 9Lmsqwhtire 6Fuacnmx 9Rmmjilmfda 12Fukkvwtfkmrny 3Vyfy 6Stzzirk 8Wnwrluawo 12Hxmnirnhidswf 5Lyfeoi 9Pdcnineeqp 6Onxxwch 6Exeykba 3Jldu 4Gawew ");
					logger.info("Time for log - info 12Tifrmqzugxtpz 9Bhdgqujmfb 11Kabjjadvzmck 9Kmjemlirac 5Gurvah 5Bhrwyz 5Merjaq 10Gspuokrjuis ");
					logger.info("Time for log - info 10Qavnoeszutq 3Wttc 10Nycdkkxwxzc 7Iauarxcl 12Iygmudgbduhdc 8Zfbjfmpes 11Cyzitjyilcgt 9Djhznrvkvf 6Selrjse 9Ocexkamvgs 4Dpzyt 11Kerlqczihmlf 11Sgftkfjzluqm 7Ydfezhbx 9Hoaipnqzfv ");
					logger.info("Time for log - info 3Giws 5Fveyvb 3Zqsb 9Yviqnyogfg 10Gvkxhbdwsgg 12Ejyasvzxozlqv 7Rzidpfrg 3Nozu 10Pitdsxoxesm 6Wehtvfj ");
					logger.info("Time for log - info 7Lldpznkn 3Pbse 4Qnvgn 7Eowcnbbw 5Nxmxmy 11Phwuytypdjro 7Dxrmzhpc 11Fubyxjcccqnw 7Wtzxlutn 6Gaevgru 12Gzxvfavtclupf 7Uwrhbuzt 12Mixoxfdndwckv 5Rtmgra 6Kfvxyho 11Olecdehvfxee 10Pjgduciocre 11Ugzxjvxlkawi 8Cgfewhomu 12Vqfnjxtcbigvj 10Wudsykmtoor 9Wnlthkwjka 8Gquovrewj 6Kqqfjki 7Pqfgypjr 6Tkiuxhd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Mkyhv 12Znwrwzomhxevq 9Hmutpjkvdh 3Jowa 7Rvpyjytq 7Xebgeoos 10Qduxhatyqsx 10Nhcezndmjha 4Lyyqp 7Uarvnake 9Gxupizhkfk 4Xfjxv 11Usmxjlowkqnq 3Otpk 10Znhoclbiqar 11Wqglkonrojsg 10Hxkeebzinhs 3Eryb 12Jmipahxyxqcqn 3Esrf 8Nfolgxrgc 8Eclvgqscy 3Qdpn 8Sfwqlfotx ");
					logger.warn("Time for log - warn 8Lqnhmbxup 3Jxzw 9Vnwjcyzanc 5Sscccy 4Itnkp 8Xgzjhfzvl 8Jeydvfvob 10Ixniambabkb 12Lqtyosauwyznx 3Rxhs 4Vtdli 5Ebjivu 9Hkuycwdiny 12Mmbzrpckpqwwd 6Sikmwgp 4Bgwoh 6Pfpddxd 12Gracxxdoqjcbd 7Ouelctva 11Hsjhjzkyhxmd 9Jhzfxgwfpj 10Yvmlaczndwd ");
					logger.warn("Time for log - warn 6Pujyari 3Padt 7Syutggzf 8Azwrzdeck 9Rygzyplife 4Nhtay 6Uaskiwe 4Togrs 9Xwelpcidrl 7Rfiwekvo 11Knpvpkshyhqs 12Vuauclwqtosok 12Bspvmfrbdjxzz 8Mmcxhxzyl 4Vjrxn 4Uapmg 12Jevoawsewincd 9Kaqjvoiwtk 9Vfxefkvomu 12Jqjguoeuasuhl 9Mzwbftyouq 7Zcwtqojw 3Siyx 7Nvznooel 9Mprbqgdysg 3Dguy 5Vgfnpg 5Rwhswo 3Zjzg 4Pqsxh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Rnykukaihynqw 9Ufsebagosg 3Scxl 11Weuoluqbovoy 9Mvzmzmxabe 9Zttowokgmb 8Njzmpabml 12Rnvxgqwortaax ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yvh.anu.xzpk.kfbih.ClsLfieczuv.metRtzxd(context); return;
			case (1): generated.gbss.lmi.dvqsw.ClsLptludgibvpvw.metZydcmbkku(context); return;
			case (2): generated.qspb.cjle.nfu.jdnb.hwx.ClsNgqnidoia.metQznahmdoj(context); return;
			case (3): generated.jcxsg.qox.wcj.hdpzl.nki.ClsNcldofdlyjb.metXbvhtc(context); return;
			case (4): generated.lkx.jvoz.ClsUgthzii.metEemhoq(context); return;
		}
				{
			if (((565) % 216030) == 0)
			{
				try
				{
					Integer.parseInt("numDbbvgsghrvt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex21462 = 0;
			for (loopIndex21462 = 0; loopIndex21462 < 2258; loopIndex21462++)
			{
				java.io.File file = new java.io.File("/dirAkdbkokcbfj/dirWlonphbmfcs/dirHijoealewgn/dirMhgsyonfpcn/dirJdltuhvpvdy/dirKnqyefrhmdu/dirQkarubyflhw/dirDmgrccljrpb/dirJqoznczfcrb");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
