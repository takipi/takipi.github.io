package generated.nclk.lhd.awxff;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsWzypoogjnr
{
	 public static final int classId = 281;
	 static final Logger logger = LoggerFactory.getLogger(ClsWzypoogjnr.class);

	public static void metXvtfzticubdsik(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valFuglbsdkuud = new HashMap();
		Set<Object> mapValAvyaklbiahc = new HashSet<Object>();
		boolean valGdthyjcppsj = true;
		
		mapValAvyaklbiahc.add(valGdthyjcppsj);
		int valFchzvdpenpc = 480;
		
		mapValAvyaklbiahc.add(valFchzvdpenpc);
		
		Set<Object> mapKeyQxpborhnxex = new HashSet<Object>();
		long valRboeamxiqrz = 6128154015572668754L;
		
		mapKeyQxpborhnxex.add(valRboeamxiqrz);
		boolean valJlxnwfhzndi = false;
		
		mapKeyQxpborhnxex.add(valJlxnwfhzndi);
		
		valFuglbsdkuud.put("mapValAvyaklbiahc","mapKeyQxpborhnxex" );
		List<Object> mapValSmldcvogacb = new LinkedList<Object>();
		boolean valPuzmhyxcbyg = true;
		
		mapValSmldcvogacb.add(valPuzmhyxcbyg);
		long valJfeoocjwhig = 8185874559362203729L;
		
		mapValSmldcvogacb.add(valJfeoocjwhig);
		
		Map<Object, Object> mapKeyOouvoycqtkc = new HashMap();
		long mapValLzmxdjibwch = 2528737989451722073L;
		
		boolean mapKeyXxanyqwaizb = false;
		
		mapKeyOouvoycqtkc.put("mapValLzmxdjibwch","mapKeyXxanyqwaizb" );
		boolean mapValSmkwooshoqc = true;
		
		String mapKeyOvppetqzxcw = "StrOvwtnezyrxq";
		
		mapKeyOouvoycqtkc.put("mapValSmkwooshoqc","mapKeyOvppetqzxcw" );
		
		valFuglbsdkuud.put("mapValSmldcvogacb","mapKeyOouvoycqtkc" );
		
		root.add(valFuglbsdkuud);
		Object[] valWjefitkbiaj = new Object[10];
		Set<Object> valBrwopltfzpf = new HashSet<Object>();
		String valXtbbnthgzpf = "StrSazyrkazovq";
		
		valBrwopltfzpf.add(valXtbbnthgzpf);
		
		    valWjefitkbiaj[0] = valBrwopltfzpf;
		for (int i = 1; i < 10; i++)
		{
		    valWjefitkbiaj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valWjefitkbiaj);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Wqdetdef 5Qhvger 7Cznypmlv 6Kusjmli 9Comivcezhy 9Pdykuzvamx 3Krvv 9Wbmrbdaqzu 8Qplbzwpxj 11Bykbkbqxwvgg 5Ahmurq 3Sxcr 12Cqydzxfsehuwa 7Iqvfucnd 3Lbwk 5Izltuj 12Jhqpxwpizhxvo 11Gmyticfzivgf 6Nkryptk 4Qlswu 3Taky 7Xyefgmgf 11Ujgskggkwjvr 10Dvnmvhzkory 5Ykapbl 11Plylzmyeypys 12Akbhononrddfm 9Mrkbpedbtv ");
					logger.info("Time for log - info 5Mbqylz 10Skvnemqhtvw 4Rdinv 8Exqfiumel 11Aoqigevfuykv 6Qefmagh 11Eanjtwpzjhov 5Qclbyi 3Thyt 6Ebpuphp 3Lrtu 3Lrvt 10Usjxsdzdshs 7Vaskuesc 7Chesxxks 11Xujpwxiasolw ");
					logger.info("Time for log - info 9Zsmknqwhya 11Mimifnfgsvbm 4Hvbsk 8Azjvtiggn 7Zouagmon 5Sactho 12Abnmbystecdcd ");
					logger.info("Time for log - info 10Kztfwwigjpp 9Fkbzhugfnz 6Zyvllqo 10Qsrrtmttoqa 9Kmesnrlhbs 8Acmnwudfz 4Zuzrt 5Fulyzq 12Gvheidtkvtyga 3Pfxx 3Pxmn 3Wmax 4Ltwbo 5Ajuslu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Nyqi 10Xdjxhpnfbxv 4Mlcbp 9Ejslbegmgm 11Uzhaxahhxyiu 12Lzvuowaqchmkt 12Sfgjcagullxgl 8Awotbuvxc 7Rqnzdxrd 7Hbhuqkyj 8Attkyuqfs 5Vydpxf 9Mpuuuzcrrm 5Gjabxy ");
					logger.warn("Time for log - warn 3Jpls 9Zgxdbrmngt 10Yulslvmvnuq 8Frtbqaorq 7Pmqxynjv 12Dadymgerrekxw 10Bbpbcavacdd 9Hxuyfhggzf 8Biwksjizh 9Zthktazpxv 6Iagdqxb 6Etpnbsb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Dmjmqo 7Exvqbycl 12Zckayymcbpxhe 11Uzeuhdchfydg 11Prdgvoyxmyiy 11Yowbhxtotxyz 4Exszw 3Eigt 3Ddbd 11Gsglszycihnv 8Tdpswzfit 10Qimggrlmszo 3Ghvm 9Xtslursxns 4Alyno 10Xjjhvlnyofu 9Jjdbdoyhji 8Fhqofjqgl 8Nkmbcffqp 7Dhuwvgts 6Jedartq ");
					logger.error("Time for log - error 9Vyvxfmqsmm 6Pivrafj 12Qmfxgbwtimbfe 8Fcmdddmah 6Ltrlgyz 6Ntnuzhk 3Ippn 4Azzkg 5Ztfvoa 10Dhiroiwijhx 9Ccyorwqqsp 9Vexkuavrid 4Rlkkg 7Ovbcjzgh 10Doiqfufulal 11Gijwpfkkdhvp 12Plbzlhzfdwoyo 10Wmmohsvbteq 8Iqygixank 9Qxsczotvzy 9Fmvrzimmnb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fzd.qgqjp.ClsVzqqvdhb.metMsjbhqpplani(context); return;
			case (1): generated.exhp.ngeqz.saycv.ClsTbfjaj.metOqtzak(context); return;
			case (2): generated.kyd.fxg.ClsVvcevjvyz.metAvlkamwowqupb(context); return;
			case (3): generated.bvvh.vrkq.ClsCiivqtifsuv.metImwfpxpepgga(context); return;
			case (4): generated.cfolx.abg.ClsZqloaugvusc.metCyqznhoatvwef(context); return;
		}
				{
			int loopIndex24862 = 0;
			for (loopIndex24862 = 0; loopIndex24862 < 6953; loopIndex24862++)
			{
				try
				{
					Integer.parseInt("numGerzncvyper");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex24863 = 0;
			
			while (whileIndex24863-- > 0)
			{
				java.io.File file = new java.io.File("/dirMpclhqkcyxf/dirCrouhqjsgup/dirEiuwkvxmisf/dirGnesvscvxse");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metPywfi(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valZuwyuhovzfs = new HashSet<Object>();
		Object[] valVphbtyydmcb = new Object[10];
		int valLpsvcoixobo = 784;
		
		    valVphbtyydmcb[0] = valLpsvcoixobo;
		for (int i = 1; i < 10; i++)
		{
		    valVphbtyydmcb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZuwyuhovzfs.add(valVphbtyydmcb);
		Map<Object, Object> valCxcapeokxvj = new HashMap();
		int mapValMmgjqgnlbgi = 220;
		
		int mapKeyOwedcdveiaz = 847;
		
		valCxcapeokxvj.put("mapValMmgjqgnlbgi","mapKeyOwedcdveiaz" );
		int mapValMtxrpfakhkd = 120;
		
		int mapKeyPgqomxgbaiu = 761;
		
		valCxcapeokxvj.put("mapValMtxrpfakhkd","mapKeyPgqomxgbaiu" );
		
		valZuwyuhovzfs.add(valCxcapeokxvj);
		
		root.add(valZuwyuhovzfs);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Hqlgsruzuije 7Gngroeqm 5Onguff 8Crefqonaz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Rinhesytz 3Jmgx 10Ofgeggbmxww 12Ketfyzsrrsfzs ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Brycnpyrcy 5Tfstdy 11Hwoviivggjtm 12Nxdduqpaixadq 9Xqzwvempcd 8Pwpiafzxw 12Eoiurkrtnsbfc 8Wenqdauoc 4Tneob 6Lkljzmj 9Wtfvkzbsgp 10Hdvdkwjpmom ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rlg.pxdte.svn.clv.ClsMkagt.metEsbkjtdvlylqyw(context); return;
			case (1): generated.gjcdq.ygxj.ClsOmksrfdawprnyq.metSuflbdydm(context); return;
			case (2): generated.wkucr.ukst.umm.xsqx.ClsEjxfeypurpufwd.metOatblxssahe(context); return;
			case (3): generated.mipzp.qfu.axrt.ClsJkbbmhkrxeo.metUvsxqnes(context); return;
			case (4): generated.aea.iom.ClsOvjtnlwnmq.metKmfjrmgcij(context); return;
		}
				{
			if (((484) + (Config.get().getRandom().nextInt(374) + 7) % 497942) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numFasnowjvuhi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((836) % 653473) == 0)
			{
				try
				{
					Integer.parseInt("numIkvtndwfitb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numVnrzllosywf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex24869 = 0;
			for (loopIndex24869 = 0; loopIndex24869 < 5690; loopIndex24869++)
			{
				java.io.File file = new java.io.File("/dirHjyiblshekq/dirOmrifjxumgf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
