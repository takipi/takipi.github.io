package generated.yfo.dls.qwny.cqaxf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDosmbrrv
{
	 public static final int classId = 215;
	 static final Logger logger = LoggerFactory.getLogger(ClsDosmbrrv.class);

	public static void metNtnwha(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValInmbdzjradr = new HashSet<Object>();
		Object[] valKszyugeevny = new Object[10];
		String valSnxenkfvkkb = "StrPyfesavldbh";
		
		    valKszyugeevny[0] = valSnxenkfvkkb;
		for (int i = 1; i < 10; i++)
		{
		    valKszyugeevny[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValInmbdzjradr.add(valKszyugeevny);
		
		List<Object> mapKeyTlqhlbdfzmv = new LinkedList<Object>();
		Set<Object> valNkjoepihilv = new HashSet<Object>();
		boolean valEuoghnttgkw = true;
		
		valNkjoepihilv.add(valEuoghnttgkw);
		
		mapKeyTlqhlbdfzmv.add(valNkjoepihilv);
		
		root.put("mapValInmbdzjradr","mapKeyTlqhlbdfzmv" );
		Set<Object> mapValFndnffkxttc = new HashSet<Object>();
		Set<Object> valJteqdkxefrj = new HashSet<Object>();
		int valPootvqaviqh = 781;
		
		valJteqdkxefrj.add(valPootvqaviqh);
		boolean valPjzdsbkknbx = true;
		
		valJteqdkxefrj.add(valPjzdsbkknbx);
		
		mapValFndnffkxttc.add(valJteqdkxefrj);
		Set<Object> valJxykiiohmyy = new HashSet<Object>();
		boolean valRrmsvabqygk = true;
		
		valJxykiiohmyy.add(valRrmsvabqygk);
		int valRssijgcubts = 497;
		
		valJxykiiohmyy.add(valRssijgcubts);
		
		mapValFndnffkxttc.add(valJxykiiohmyy);
		
		Object[] mapKeyFeclhfkggks = new Object[6];
		Set<Object> valUvakaxyzlqb = new HashSet<Object>();
		long valSflnyhrsmlc = -5748397102889132977L;
		
		valUvakaxyzlqb.add(valSflnyhrsmlc);
		int valFeeqinixajb = 487;
		
		valUvakaxyzlqb.add(valFeeqinixajb);
		
		    mapKeyFeclhfkggks[0] = valUvakaxyzlqb;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyFeclhfkggks[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValFndnffkxttc","mapKeyFeclhfkggks" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Sgvsoess 7Nvcymejg 10Aveuxyjpbxv 12Nsqfmkzmuuubp 5Uqodpq 11Igctichcklnz 6Cosutcm 9Kvmfqrimcq 11Qtbafsjbcajp 10Kkcjcowsixg 9Lcxskkmrng 10Byihktsvuzf 6Zblyetb 5Kpfhqd 11Usnqminhhuax 11Yevdksbmctvb 5Idckej 5Rlwrue 7Pphqltdj ");
					logger.info("Time for log - info 4Jestl 12Pwqglpcfvfctd 7Utpmratj 7Alekdaye ");
					logger.info("Time for log - info 10Oafrjjyjocn 4Nstoa 10Gzscsptoydd 9Acwvcfkwub 7Gwwctzle 7Zmigufdz 11Fbcklvoolatm 5Qegiof 4Bgnyj 3Zaof 10Xkiszinbqug 12Yqselbxdwywpa 6Nhwwgrh 10Wvxpiegfmly ");
					logger.info("Time for log - info 11Aixvhcsuefqz 10Hdgjdatjedz 12Vjuxrbnxvlzlg 6Mejvavt 10Ohacfvaewkl 12Semrjvdguhgiy 8Aminmzplb 8Oivmaffht ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Geodqsrsep 7Qfhpfguk 4Mptwi 3Yqmi ");
					logger.warn("Time for log - warn 8Uwxbiwipp 7Hesvnisz 3Goxv 6Beoqtac 7Ydbkecnk 10Nfobjzintyb 5Hbslmu ");
					logger.warn("Time for log - warn 10Hhebtnojhrf 6Fdukjxa 5Kwudop 10Mnjnqbsfeit 11Faqemcyfjyxi 6Kjcuyqg 5Xbvjos 12Zhndvptdpyypt 9Mtgouwdudn 8Ryiyubofa 11Tgailhcgefbe 11Urugyjckmekp 3Fgbc 5Ukajyr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Emrcibwarouw 5Qqrlwc 5Dckfhj 7Tgkktupn 9Mecusveszu 5Lvjzuz 3Duuu 5Mzrave 5Uzjcmk 5Yamvgo 3Iuyh 3Tssx 11Njdmxlacudrt 6Lvbhddf 10Gzmzkiasbkc 3Pqzx 8Wnddghkrb 8Ytycuuzlm 11Wrgdkqbvhvls 12Pqgdcimqgzegf 5Gevxtt 10Sakwhhiapfk 11Vvxarpuwvtsc 3Qzni 7Xvudcgkw 7Wqxhntdl 9Owlugpxdxh 9Nournbkgns 5Cgadgc ");
					logger.error("Time for log - error 6Snxgumq 3Bqbn 10Xwvcwmnlnfc 9Ilctrgfqhw 10Ontqbctpcqf 5Zvvqwl 8Docanjgcn 6Elgullr 8Qleucgntm 12Wdkqikxqjmjkb 9Dwuhabhsjz 6Zduaocj 11Uetfdsydgzfz 10Dteiuiiyeld 6Arziyvj 8Zmimyokug 6Mhzjekv 4Jgfmi 12Sylbdvdrnsqsy 10Smdpsdkomnv 9Irxqsnburw 12Xauiwmxdsdeai 3Ujia 5Umwbck 6Vzjldvb 4Oesgi 3Bbdz 4Nllth 3Kabf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qpe.ifudp.xgatn.jzg.qau.ClsJymdeqopgpbo.metNcpaipo(context); return;
			case (1): generated.mrfat.adk.zch.ClsYwqlnetu.metCadvvicigiy(context); return;
			case (2): generated.bolg.tnlb.nmug.ClsHstaiufsowx.metPapexcx(context); return;
			case (3): generated.ahr.cnut.ztcbc.ClsUicrpogixv.metIynrmqpfnjegr(context); return;
			case (4): generated.bvvh.vrkq.ClsCiivqtifsuv.metImwfpxpepgga(context); return;
		}
				{
			long whileIndex23815 = 0;
			
			while (whileIndex23815-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex23816 = 0;
			
			while (whileIndex23816-- > 0)
			{
				try
				{
					Integer.parseInt("numKxfqriajxsf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metEzcdmyjxgzcl(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValUhphaqcsloa = new LinkedList<Object>();
		Object[] valMaljofwnnta = new Object[4];
		long valHqxakkyemug = 4984118805706854481L;
		
		    valMaljofwnnta[0] = valHqxakkyemug;
		for (int i = 1; i < 4; i++)
		{
		    valMaljofwnnta[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValUhphaqcsloa.add(valMaljofwnnta);
		
		Map<Object, Object> mapKeyHksbrfiprlx = new HashMap();
		Object[] mapValZyonxkvdqxs = new Object[11];
		boolean valSoxltgydwiu = true;
		
		    mapValZyonxkvdqxs[0] = valSoxltgydwiu;
		for (int i = 1; i < 11; i++)
		{
		    mapValZyonxkvdqxs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyTlepborngza = new HashSet<Object>();
		boolean valTxatrzcqrum = true;
		
		mapKeyTlepborngza.add(valTxatrzcqrum);
		
		mapKeyHksbrfiprlx.put("mapValZyonxkvdqxs","mapKeyTlepborngza" );
		Object[] mapValLkrrkbidbpz = new Object[4];
		String valJumgjsvaojs = "StrOdshjtfsniz";
		
		    mapValLkrrkbidbpz[0] = valJumgjsvaojs;
		for (int i = 1; i < 4; i++)
		{
		    mapValLkrrkbidbpz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyJyzjyomgptb = new Object[5];
		String valTfhrraewqln = "StrCdxeonpifxr";
		
		    mapKeyJyzjyomgptb[0] = valTfhrraewqln;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyJyzjyomgptb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyHksbrfiprlx.put("mapValLkrrkbidbpz","mapKeyJyzjyomgptb" );
		
		root.put("mapValUhphaqcsloa","mapKeyHksbrfiprlx" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Cwzfwupcbwb 3Sowz 5Timmqw 4Nawua 6Bldvoio 10Drhuhwovlpb 8Spmscvhhy 3Wvzl 6Azfrcpc 3Mrxc 12Twdbsfcbzjout 9Hvrjrczucv 9Saywhfzckp 9Xldnydahpg 12Bgjftiedsnqlp 8Qhllyunaf 3Ttwz 7Vdqeciod 4Zcaeo ");
					logger.info("Time for log - info 5Wohvdo 3Mrfv 3Htxp 4Wfesd 7Utiraprr 8Mzlgswdwj 7Xndtyszk 9Oukntkgrwr 8Xxenzzclf 12Bpcmlzhvvrttv 3Ttoo 8Agvbugyhs 12Zktlzithwhjxb 8Xobngcisw 9Xsqrijnkcc 10Wfdcgteycyr 9Swrmixcxhy 5Cgxege 4Npmpu 6Fwaealo 5Yvsyid 3Isrj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zyq.cql.abcyr.bxocy.ClsPzdxphao.metBqhsdqlrug(context); return;
			case (1): generated.wxgmf.hjxrw.ClsYvfyyrknqfec.metWssrrvk(context); return;
			case (2): generated.afba.qbfns.sure.ykux.syv.ClsCqlibdmm.metYjsgjmdmtzt(context); return;
			case (3): generated.rub.wtuur.cpewn.fdq.jektc.ClsLiscwkily.metFxfyfwekmvvpv(context); return;
			case (4): generated.vuj.qjcvs.phb.poi.ueh.ClsHxaaaxntrhq.metHrwdn(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numTlfyblmqjgn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex23823)
			{
			}
			
			if (((Config.get().getRandom().nextInt(427) + 0) - (Config.get().getRandom().nextInt(747) + 7) % 252726) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metZhoqh(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[2];
		Set<Object> valTgoqbmanjrf = new HashSet<Object>();
		Object[] valBztjvqektwe = new Object[7];
		String valRhwtchojecs = "StrQfdprgyhyqr";
		
		    valBztjvqektwe[0] = valRhwtchojecs;
		for (int i = 1; i < 7; i++)
		{
		    valBztjvqektwe[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valTgoqbmanjrf.add(valBztjvqektwe);
		
		    root[0] = valTgoqbmanjrf;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Wiaw 9Dvxtrlebim 9Hkrydykfqu 10Qmbkvxavxaw 7Ovrdpbtt 8Uhjrepknj 11Jzthevmwxfee 3Ubyc 6Buhlxxt 12Cbirupsemypjp 8Ghwrjgvba 9Usykzljrcl 9Igrzpysvas 4Ztbps 5Lvgvgo 10Rnzatkgbdbi 6Lzwqbbj 12Tmnsnzhephtkx 10Njhdldelwrb 7Fhfnghcz 4Xdrwd 11Koeolxwfujnt 12Nvjcqesnmyxvn 11Sgiemxgqarzc 12Kvsyzzqmizguw ");
					logger.info("Time for log - info 7Vsaptjti 5Mahvra 10Kejeulttghy 7Qvjcqynk 12Dlbfruqwbhkyl 10Kujdqmrhtlc 7Tdgesoic 4Tsyyq 4Ytgjy 3Polz 3Mczz 10Hqibgykcsdl 5Cjuvsl 8Bngmwpzze 4Gxvdc 6Ghndcel 5Cpvahh 7Aowficop 10Pphzqntjgra 7Mlkiujjm 4Uakon 7Ogbfawuq 8Lattagimn 4Tiree 10Moywujenzrs 8Majahcdyb 9Lyudytzaqz ");
					logger.info("Time for log - info 3Icao 9Ivbzcczqku 9Tmmbsfqifl 5Tswxro 10Vxaxjcxhgpj 8Jycsgcmwl 8Fzoribhsf 12Dtllktcppvoav 3Smge 3Bpng 3Zbat 4Nzvvp 12Revigyjpdahgv 9Jhhjkxxeqo 6Uzueqjp 12Rzkbboszrpeis 4Zzjya 12Ysyixwszedzvd 10Glyiwomuekt 10Auctnbkxnal 6Stihgzi 12Vfebxlazlxvxz ");
					logger.info("Time for log - info 7Oisynnue 6Tyysrdu 9Brubmmzhko 6Ygnuihj 3Ydte 11Kchreunzetqa 6Xcsbawj 12Ffxzvnrunerdo 5Cfofki 9Nkuvdqjhkp 11Bjzlknaedqhn 11Urwoiliavidl 10Pkmxkqwsxur 11Rxexvndresqa 9Ozhzeoybfj 5Ksrket 11Hxlkjzkbffeb 3Gxog 4Ofeur ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Fjxbirekiauo 11Hcwxzaojmkzh 7Kjlacfvo 3Jouy 12Chjwabglncraq 4Agmhb 11Ubonusujkcbn 11Puubmolbttyt 4Eprdg 12Flcwyxceggmeu 12Wnysmydctrapg 3Edwz 12Efqclqozavbaf 5Bltkoq 6Umsguml 6Dpggxlr 4Hgrqm 3Rjhx 3Kofo 8Kibcfhkcg 5Unsajy 5Wqtekt 6Lrtkmvf 9Mmnztehrth ");
					logger.warn("Time for log - warn 8Nujovoudt 10Hdekxvokwxs 11Tquhabljrgvf 3Psvl 6Iwdmigf 8Gonuxulyj 3Xlet 8Rikdhkrcz 4Uugsh 6Kvlchrf ");
					logger.warn("Time for log - warn 8Blujfcvxg 8Ngumrquks 4Avbtn 4Izsme 7Vdamnake 5Dnxtrt 12Wckkuwymqnxff 9Genhvkrsya 5Hjkwmi 11Szromkywfgdc ");
					logger.warn("Time for log - warn 8Floxjvuon 10Njyryaputwr 7Vfrpbeev 11Hzsyxsojgnni 3Gfdd 11Uyuhlqhfsfgy 3Ziwe 11Lukjmyujvxkl 5Bdbehf 7Zvaweyef 6Alxzknu 5Dbjjkx 9Lbxrerrdwh 3Xfpt 12Uibvacdztyhuc 4Spikv 12Itwnzkeukgzln 10Dkcisvywoyt 10Nigbiztkcrt 6Ovwkibj 10Bhpzvysivex 11Uzqutdhaqbdy 5Hxiuqo 12Lzvsiyjmxdari 9Nnxkowndoc 4Hphuf 11Hqeditoddfad 5Lpsxyr ");
					logger.warn("Time for log - warn 12Akcngzsmmswbl 11Mcwgcmjbaysu 9Taylqhtorg 11Scdescpvcnjd 6Xqcehca 12Znpzsweiczjkk 6Qafqemi 5Xuwxzx 9Hvfxiebvnj 7Njfaogpe 8Eqjbqzzef 12Wchrkshlgajpu 5Eilzbd 9Weohvgiuah 6Ifhwqmk 8Djkkeiyjr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Epstmj 4Wzsjo 6Hmzeadl 7Ymwbwzlm 6Aksrjrk 9Pygnobcntv 4Ezzvn 7Lhmgtupq 5Khemee 8Ovubuckmc 3Kosv 12Ouqbjudwgsvcn 11Fesvvracjloi 7Irywpupe 3Mhzr 11Wverkxueqnaq 7Lkmzidch 10Oifgpelphts 4Bhzzv 8Byovhlbgv 10Ywcrhoiqhig 10Kdeoifajjsz 8Eycvtedvi 5Htbxll 3Wufs 11Nicayuctajfw 8Rvegsdqiy 9Mcaysqvpfd 9Xjmshhcwlw 4Tvzyy ");
					logger.error("Time for log - error 11Igzeqdmddwkr 8Qohqzilpw 12Arfukipwliear 7Hipucrlw 4Kgbos 9Xylaoewgmu 12Meadzomascbng 7Bkqvgila 12Jmaelkvinoese 5Tfxbbz 5Yypksy 11Lripnqfhriyy 12Sizwiatrvddyi 6Tdldgea 11Foufugzcqoof 12Jromsvanhrrxo 4Moikq 4Brcqg 10Cewursdhqyv 6Sxgjvoq 3Nxgw 8Sskjrefda 3Ncqn 5Wtrmow 3Iqxt 12Qyjuqtigszpzl 7Nsahhczz 11Owbwwicwgxna 8Rsgyhdbtl 9Lnjlqvqmfo 7Cehsyosq ");
					logger.error("Time for log - error 6Lkvvqlg 8Erzkclcem 4Vugzz 6Wdfyhav 9Kdtgpxmnkq 8Yodxzqbrd ");
					logger.error("Time for log - error 5Myeimp 10Rsygvpzqxyi 11Qazlrpocnsdu 4Nreea 5Jkoogs 9Unkumtqlsv 11Cdcaerfgrefp 8Qjlmruauo 9Lwilzhgmrx 11Plbkezwbxmbv 3Lhht 9Fhfcinnpxt 8Tukfqrsnc 6Fbkafkv 3Rhnx 4Dceic 10Temokaaqedn 5Lxahbz 12Nruwftairvtom 9Aswcjjcasx 9Segyffivxp 7Txdzsjip 6Wrpnozh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.afba.qbfns.sure.ykux.syv.ClsCqlibdmm.metOvhcjl(context); return;
			case (1): generated.ldtgt.vdfx.cdz.lkx.ClsLvvwnymti.metOdzdjwutrxtvu(context); return;
			case (2): generated.mrz.embg.gydr.vls.fvllv.ClsYrxhq.metEadyyddxiay(context); return;
			case (3): generated.ymhs.ivq.mlr.cezkl.gzyiv.ClsKvdrph.metIszbhwn(context); return;
			case (4): generated.lbx.ujwf.wayq.ClsEtipntwjjs.metYkgppbepgd(context); return;
		}
				{
			long varPyqcxjvzngw = (Config.get().getRandom().nextInt(115) + 8) - (Config.get().getRandom().nextInt(823) + 0);
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numGtxkftohdfm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varFfqcblzsmlg = (1186) - (Config.get().getRandom().nextInt(957) + 5);
		}
	}

}
