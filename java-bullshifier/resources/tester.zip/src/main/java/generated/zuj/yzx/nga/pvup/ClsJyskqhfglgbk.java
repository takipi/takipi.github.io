package generated.zuj.yzx.nga.pvup;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJyskqhfglgbk
{
	 public static final int classId = 229;
	 static final Logger logger = LoggerFactory.getLogger(ClsJyskqhfglgbk.class);

	public static void metCxwonkfw(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValSaqatojtqtc = new HashMap();
		Set<Object> mapValGxdkoecbbcz = new HashSet<Object>();
		long valBatgysirutz = -5915830091958342591L;
		
		mapValGxdkoecbbcz.add(valBatgysirutz);
		
		Object[] mapKeyHbwpzuvbmzf = new Object[9];
		long valYlutqjjwmln = -3620455094647646970L;
		
		    mapKeyHbwpzuvbmzf[0] = valYlutqjjwmln;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyHbwpzuvbmzf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValSaqatojtqtc.put("mapValGxdkoecbbcz","mapKeyHbwpzuvbmzf" );
		Map<Object, Object> mapValPqwzjckeigh = new HashMap();
		long mapValJgfhydlrnhl = 7950374454816307035L;
		
		boolean mapKeyXgdqimhvclc = true;
		
		mapValPqwzjckeigh.put("mapValJgfhydlrnhl","mapKeyXgdqimhvclc" );
		long mapValXrjrabcjuoy = -1405321674511562987L;
		
		int mapKeyHrorevnjicb = 958;
		
		mapValPqwzjckeigh.put("mapValXrjrabcjuoy","mapKeyHrorevnjicb" );
		
		Set<Object> mapKeyXutcvlzamdg = new HashSet<Object>();
		long valGkvlmzfxkzv = 3536977571893110098L;
		
		mapKeyXutcvlzamdg.add(valGkvlmzfxkzv);
		boolean valOxcnfzrnisb = true;
		
		mapKeyXutcvlzamdg.add(valOxcnfzrnisb);
		
		mapValSaqatojtqtc.put("mapValPqwzjckeigh","mapKeyXutcvlzamdg" );
		
		List<Object> mapKeyXrgadovaryf = new LinkedList<Object>();
		Object[] valEnxfdoyjbxl = new Object[9];
		String valOrwscsrmyja = "StrTqpkokkozaj";
		
		    valEnxfdoyjbxl[0] = valOrwscsrmyja;
		for (int i = 1; i < 9; i++)
		{
		    valEnxfdoyjbxl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyXrgadovaryf.add(valEnxfdoyjbxl);
		Object[] valXzwhfjcvngj = new Object[3];
		int valZmtvkplupav = 12;
		
		    valXzwhfjcvngj[0] = valZmtvkplupav;
		for (int i = 1; i < 3; i++)
		{
		    valXzwhfjcvngj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyXrgadovaryf.add(valXzwhfjcvngj);
		
		root.put("mapValSaqatojtqtc","mapKeyXrgadovaryf" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Kwfeqao 7Rsummwxb 6Pnqeoka 7Jwddlqyy 12Gwawgxnuyllsj 3Osnz 11Ivqcgiclvlzf 12Oykibmtvfkqej 10Ijmnbrcrpje 7Rfdzhrfm 6Oasyeyr 7Fwgmtuco 5Cbinyp 4Hjehd 5Oubnif 4Qldep 6Ibwxkry 6Wfyzrfe 7Yijqlhhy 5Hivdzq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Qwgi 11Waywaxalccar 3Deqv 9Ndhafvsamb 5Wiwegm 5Kcudol 6Rcyawvt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.egtuf.tby.poy.tetgn.cnw.ClsOidjvegh.metTjmqwo(context); return;
			case (1): generated.ldtgt.vdfx.cdz.lkx.ClsLvvwnymti.metSmshnclxqxhvn(context); return;
			case (2): generated.ueynf.ovqsn.bjpnz.bhq.ClsPrqva.metWqdhwnlfsbba(context); return;
			case (3): generated.vbpvl.ppexe.hnrdr.zcxzm.ClsCvshjbmkqrb.metJcfyp(context); return;
			case (4): generated.ooziu.gzrop.rbg.ClsFthgefv.metTwnpyf(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numTwljwjajpnk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metUwrvr(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[10];
		Set<Object> valWyuisqihbzi = new HashSet<Object>();
		Map<Object, Object> valRrupnfcvmea = new HashMap();
		String mapValKpkvxastpbu = "StrXxicxfemvji";
		
		int mapKeyMcjpakgxglm = 44;
		
		valRrupnfcvmea.put("mapValKpkvxastpbu","mapKeyMcjpakgxglm" );
		String mapValBakrlffmxjv = "StrKtqhgkqtpfe";
		
		int mapKeyQczijtorclp = 170;
		
		valRrupnfcvmea.put("mapValBakrlffmxjv","mapKeyQczijtorclp" );
		
		valWyuisqihbzi.add(valRrupnfcvmea);
		Object[] valPrvicyihuna = new Object[3];
		int valFmebflreytw = 0;
		
		    valPrvicyihuna[0] = valFmebflreytw;
		for (int i = 1; i < 3; i++)
		{
		    valPrvicyihuna[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valWyuisqihbzi.add(valPrvicyihuna);
		
		    root[0] = valWyuisqihbzi;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Faemufxjd 7Allrofyh 4Sspkw 6Ldmzjsl 10Ibptmozweow 8Fcuxxycpl 11Mvsiuxyexogm 10Ymxiivrfrys 4Lnmtc 10Ruwendpibde 3Cdci 7Oyrxyuak 8Rxwwnmrds 5Nrnayc 11Yvgcghopehkn 7Juqqoiag 6Ghhxkhf 11Jhrgmaajtfkx 12Kbvtoiyyfkxpz 9Hiorusxdoi 6Dprsehn 10Xfcfbrfjhcp 3Qelz 11Fqmgvnfpxvdy 12Trpxgjxdxtseu ");
					logger.info("Time for log - info 6Gzhkqrf 7Wtwjromk 9Nioivjfpnd ");
					logger.info("Time for log - info 6Zubwngq 10Ubikcufejtc 8Atailukrn 6Fhnvbqn 10Wityticnmqv 7Vqkpuwxk 12Dbevirslkileg 8Dibxjwpyn 12Dryvlweldbohm 5Zxdeva 8Esmaoamwv 6Xkpigyw ");
					logger.info("Time for log - info 4Iqlzg 9Gcgllwaheg 10Tjuezetpsjd 6Tzcytbk 6Npxvohu 4Kjffg 3Mzhq 12Gllsyyfdkyzvq 4Xehem 12Btnghcmprdhdn 4Pfxoz 11Rwmkxxxevisb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Pzjsafhpesn 5Ivenfu 9Ekzcuwsyjk 8Uhuoqpusj 5Srafwe 10Wkxnanaduwp 9Vywxrrulbg 9Wtulopverd 10Yfaqmsiqmtv 10Bbhygeuaugy 7Besvvgwq 3Uuaw 3Fhsm 4Tsdke 4Bgkkv ");
					logger.warn("Time for log - warn 8Piyosgnhe 4Goqut 7Qhtoeuog 4Wgnal 11Echtqnzvcbpm 10Fqrxaznnshe 3Urxr 8Rnefcyfwu 4Cimqf 6Xuciflq 7Apmrdpwj 8Hsxuvofmd 7Xlimzhmk 12Buhlkchrcsqhm 12Oabtbfvmawtka 4Xounb 9Njwyypvtzd 3Fnim 9Qbiztgytzl 9Dcktfijsja 5Oybktq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Nqvehd 3Pzhy 4Akxhm 9Schwpxohhf 5Fayqrl 5Jqiiwi 12Bnishdtjkqurb 7Dcbgduex 4Lakau 10Yaxyhkspulm 10Jenkhbywzzz 9Vorxzjdgpo 5Gcxxzk 6Uutgvih 11Dlilybnndwdb 6Enasmaa 9Yiozfgjrck 6Ltsbdvk 8Wbdxifpgo 10Smyoxyxtbdy 11Pwiyudqevapi 3Ftnt 3Xyag 8Xvcvvwvgo 3Enyt 11Pvkrykufydit 8Ucipcoptc 12Oneiuyasqsozg 9Istieansbt 10Euqwchtucrx 7Suzvivit ");
					logger.error("Time for log - error 3Bwpq 8Ytynhowap 5Druikd 11Wrnyhndiolxc 4Sapru 11Xyzlekoynszz 7Wcuncpxe 8Nzibfhbsi 4Mflyk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kklo.eog.twpb.eja.vmrt.ClsCtkkdlrnk.metMzowgzzffz(context); return;
			case (1): generated.eob.tzj.qiec.ClsEnjcnowop.metRglvwndsjd(context); return;
			case (2): generated.xhxl.owx.ClsJgljylyqsyfqzr.metTjguctxwf(context); return;
			case (3): generated.tcf.quma.ClsZzrrflp.metZjejbmakhczdx(context); return;
			case (4): generated.tjmm.euxn.jmtp.ClsNhugjkj.metQafbogfqlngiyk(context); return;
		}
				{
			long varAwqnyjqiprl = (Config.get().getRandom().nextInt(632) + 0);
			if (((varAwqnyjqiprl) % 105751) == 0)
			{
				java.io.File file = new java.io.File("/dirZnwmzdyfedu/dirLlnhlraavbn/dirHjaferwhezj/dirSkythccszrh/dirEfzmvygsvuf/dirDbilwjaqguw/dirOrttxkhxmol");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((3957) % 684390) == 0)
			{
				try
				{
					Integer.parseInt("numWqyhkanutxb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metBegxo(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valFfuxdgdzsbl = new HashSet<Object>();
		Map<Object, Object> valTqjnikukalw = new HashMap();
		boolean mapValAoowkwxniep = true;
		
		int mapKeyZtjxvveitgn = 650;
		
		valTqjnikukalw.put("mapValAoowkwxniep","mapKeyZtjxvveitgn" );
		String mapValVdmwilxeaka = "StrLcvjdiwluim";
		
		int mapKeyNuhmobzqxco = 469;
		
		valTqjnikukalw.put("mapValVdmwilxeaka","mapKeyNuhmobzqxco" );
		
		valFfuxdgdzsbl.add(valTqjnikukalw);
		Object[] valXkncxootqwt = new Object[2];
		boolean valCtsrdbwllfw = true;
		
		    valXkncxootqwt[0] = valCtsrdbwllfw;
		for (int i = 1; i < 2; i++)
		{
		    valXkncxootqwt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valFfuxdgdzsbl.add(valXkncxootqwt);
		
		root.add(valFfuxdgdzsbl);
		Object[] valMgsgpmbfuhk = new Object[8];
		Object[] valTfdctkvhehw = new Object[8];
		boolean valMjmpteurqhd = true;
		
		    valTfdctkvhehw[0] = valMjmpteurqhd;
		for (int i = 1; i < 8; i++)
		{
		    valTfdctkvhehw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valMgsgpmbfuhk[0] = valTfdctkvhehw;
		for (int i = 1; i < 8; i++)
		{
		    valMgsgpmbfuhk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valMgsgpmbfuhk);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Iqadsnl 6Suxmkrv 6Ugzjsiu 10Mizrwxygaty 11Vekacgqmyhch 12Fsscmwvojjgyg 11Ckqelacnrzii 3Qtve 9Aejukixhdv 11Plvblpcvthxs ");
					logger.info("Time for log - info 4Pljzw 8Lzqwdvwrv 6Twifbhz 8Cgysjvcyf 7Clobraox 7Mskbcmgl 6Bmudpeu 4Jvgzy 8Lukxxpxtj 3Ebhr 12Jktvuzxiyxvka 10Sxqsibbxjdv 3Fwmn 7Ujzgwgkm 11Umruqfximgts 8Lwbcgdbwc 6Gqedhrv 11Digncmzewgqu 12Yhtfclbtlwide ");
					logger.info("Time for log - info 10Xwgcmilxgbj 9Wrcukleyfj 12Tljtxnbpfejjs 9Qwfnwsapno 9Sstqokxqfo 3Dibw 6Rftbary 4Esljb 4Upoci 12Ccsgaphgyfjqp 4Syfan 4Thwue 12Fhehxdxzyhssd 7Uwvamzgi 5Lfygym 9Ishwtmqvej 11Xdmnzjsdlkfl 7Djoarpie 4Fdmfc 12Fhzpiobxciqyv 10Drzwzpixwmp 10Enpjmqgdmyf 4Lkvab 4Vibib 8Hyjqjtuzh 9Wikxhdrxik 6Qizurdu ");
					logger.info("Time for log - info 6Aipvvmt 6Awpzsjr 6Ftezcbc 3Ombt 8Mrgjtdkrq 10Nhjtmloeciu 7Oodydsdz 6Picjbyu 12Hgljsmrnthbho ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Lpcxlktv 7Vxqojpwm 5Abrswv 5Apbxzz 3Szlh 4Qyhaw 12Fkmgtmgrnapyk 10Gngjmxpqwfq 3Bspt 7Oxswhegr 5Dnjjio 8Uqpyysjof 5Bmlmsj 5Wpjcbm 4Enihf 6Eqnaamg 6Wtnrjnp 8Ugofwesnh ");
					logger.warn("Time for log - warn 8Gpgfpuxms 7Yghximkw 9Uudddwmlvh 3Lyus 11Xutmkcktpgqz 4Zwmvh 5Xoqksj 3Jkrg 3Lkrw 8Pwxbfucrd 10Exfktdeorgj 12Jrsdqwomcjolf 12Htvjbyhobuoic 9Sndswxolwd 7Uhsyevux 12Bctoifjantkfq 12Coqzgljeurndn 11Jibdyvwguapa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Crzhiemythmd 11Srewezbcewko 9Aqzdqajrav 5Dktdin 3Srts 5Wqnukh 7Yockmwzf 5Hjblyv 3Dmrc 5Tveifd 6Cuhokqz 7Fihqsjho 10Eccundmblux 10Cuyvcgsfpkm 7Yisrvwbz 3Bcnr 4Pdhzw 5Gpzcdq 3Bvfi ");
					logger.error("Time for log - error 8Nmriftpnc 8Annljaqgt 12Lvxsuazsdrmhy 6Txtosgr 10Emcbvqsmafw 6Hxcnrbl 9Aewfwfuxlh 3Wqvi 3Qlix 8Twxxkauqa 9Cvsqaigcij 8Zfgejotel 3Adjh 10Zewvxddaeod 6Wvzfely 3Nomu 3Gqfr 9Rgmkqubkio 8Fhkaawchj 6Evvsbvt 4Cekri 3Wxba 6Ikliljv ");
					logger.error("Time for log - error 12Sxfeimacpsqsf 11Rzxjgluxfrzh 9Rexidjeizv 9Molixvmhzq 11Wsusiulcylss 11Blrnqhspicwl 6Jdcbayr 3Rcoc 12Aclhcykbnvmcv 5Swkfcw 6Kavtnre 9Mqijbpxsgl 7Tcamlpwi 7Qfyzollk 9Enwujtojqe 7Cjxedbrv 7Odeysidr 3Bpda 3Kqxv 9Ivrtgxqvbk 6Raynfhq 9Lrkjrzaoah 9Rnydjiqxig 7Ymteonub 4Etwsz 7Dxwuvypy 6Ngrkcnc 12Ovwhacxeuuebg 9Bkagcoewrz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nsbl.xxor.rsxq.aixva.einq.ClsJcyofzflum.metRqhzthy(context); return;
			case (1): generated.jyd.enpnr.ClsZxueqcgpd.metEwimth(context); return;
			case (2): generated.ndkx.exo.qju.brvd.ClsMxlcse.metDczdeozbrswoav(context); return;
			case (3): generated.prq.bplky.nxkb.ClsOpjmpjfimau.metKcvsmcfaqhw(context); return;
			case (4): generated.fzi.whyx.ClsLwqmexgqswx.metOkmaagzzibm(context); return;
		}
				{
			long whileIndex24076 = 0;
			
			while (whileIndex24076-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
