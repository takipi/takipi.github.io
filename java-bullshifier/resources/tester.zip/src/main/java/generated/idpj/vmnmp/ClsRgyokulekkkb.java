package generated.idpj.vmnmp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsRgyokulekkkb
{
	 public static final int classId = 61;
	 static final Logger logger = LoggerFactory.getLogger(ClsRgyokulekkkb.class);

	public static void metRovgxbargonqf(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[11];
		Object[] valBirnrrxehcs = new Object[2];
		Object[] valLffsttgucff = new Object[7];
		int valXnhwvxvjuja = 849;
		
		    valLffsttgucff[0] = valXnhwvxvjuja;
		for (int i = 1; i < 7; i++)
		{
		    valLffsttgucff[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valBirnrrxehcs[0] = valLffsttgucff;
		for (int i = 1; i < 2; i++)
		{
		    valBirnrrxehcs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valBirnrrxehcs;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Zbamyedgv 9Jhribacpis 9Mjgihfbqgv 10Snsowigybiy 7Yagfkuex 4Kpdxn 8Pkrujauef 11Yntqlflnfluy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Aantnuhooj 5Yarweo 5Uyeqyh 12Xgpuhqcblxvsx 5Givglm 3Dwzn 9Qdzroryueg 10Utvxqjzljsf 7Dcfusokb 4Nrrgg 4Kiodp 11Bxcvmqgpsxuy 8Rknizuebp 10Hmgqfxwqigd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hfhsc.dtsm.exj.akcxm.ClsEggbq.metGkdrqysenzt(context); return;
			case (1): generated.sttvf.uvyp.navra.vntc.wlw.ClsLyfkosygvnxgsh.metWuyudxzkmbkah(context); return;
			case (2): generated.hcl.ivd.nxcam.ClsQkvrtnftml.metUkmqfsqzjz(context); return;
			case (3): generated.mebcr.ggzz.ClsIauvxr.metPzfdv(context); return;
			case (4): generated.vhkgi.kzbju.ClsAkkdrnlxagwy.metUkjjzsaxomm(context); return;
		}
				{
			long varEtpyuiltyqh = (Config.get().getRandom().nextInt(798) + 9);
		}
	}

}
