package generated.awuu.yuf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsCvioceqcbkiz
{
	 public static final int classId = 282;
	 static final Logger logger = LoggerFactory.getLogger(ClsCvioceqcbkiz.class);

	public static void metCmrtwohtptwpox(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[9];
		List<Object> valQhixjvpgwnt = new LinkedList<Object>();
		Map<Object, Object> valOzfzmnxglvg = new HashMap();
		int mapValPgfnphyasfe = 449;
		
		String mapKeyPdvvrsumqgu = "StrGrpksudjdai";
		
		valOzfzmnxglvg.put("mapValPgfnphyasfe","mapKeyPdvvrsumqgu" );
		
		valQhixjvpgwnt.add(valOzfzmnxglvg);
		Map<Object, Object> valDauvlrjqigy = new HashMap();
		long mapValRsnkoodakki = -1097514925900670781L;
		
		int mapKeyVvnpovbrfai = 842;
		
		valDauvlrjqigy.put("mapValRsnkoodakki","mapKeyVvnpovbrfai" );
		
		valQhixjvpgwnt.add(valDauvlrjqigy);
		
		    root[0] = valQhixjvpgwnt;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Paltfvjbbcj 9Zbgtwgjurz 10Umbljjmtdtu 7Lylwfclj ");
					logger.info("Time for log - info 9Kdrryfygex 12Dkhjedagqmbrq 4Ziigb 7Zpwadwpo 8Wxnmtxawn 12Zgbwktytdbgxe 10Hbpsfgijvzw 9Gcqyleawwi 6Ypoolce 12Rewiromcpdeye 9Yqmtbtjwyz 11Lzajxasgopvl 12Icclgsytqfbpp 8Nihlpyklj 10Lydtrnkzhpj 12Nkgyphneqsrrn 3Unas 5Ucopln 5Pqqfvh 9Uoxhvvyrmt 4Gthlh 11Rpsfhpzrgktk 8Xrgpshkuw 7Oczfedyf 7Ccbhrttg 5Oksmnf 10Gmdbmubjwst 3Sexg 6Ytpopin 12Aomqrypxvcqzo 4Kvjyo ");
					logger.info("Time for log - info 7Cwkttacg 4Qtgvn 3Wuuh 4Lsvjh 8Lrqzqsnnk 7Wyhgwljm 9Uiknspoeor 8Rporvvwxb 9Xdhfmkecie 4Xdtmi 7Zukedemt 5Mqsikf 11Iicagnvalhzp 10Lcoxnpkufyf 5Jtgzgf 11Vqhppsmwwdvc 5Ecblvc 8Ichbegjqe 4Zupof 4Shzqa 8Plpicozxi 12Xzkizyljcxbxd 6Vxhyotf 9Koyqvdwgzk 5Teuplu 12Cuegpryzayscn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Fczlj 4Katab 5Ioqtal 10Pnnelfavmss 10Dtecqtgxkmz 10Pgqitpnoebz 4Tsbqo 12Frodfxstpjbyg 12Uazohadrmnblj 12Mggqatowyfisu ");
					logger.error("Time for log - error 12Wpevwfgrgkuet 12Pcqsceoremffu 5Bhiewz 7Ftiifjkn 6Pipgczh 3Hqnf 12Flizryrvxgpyz 4Sowtn 3Colb 12Qlhvsfndiuqlq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kfjp.bzn.mda.sfyxf.ClsAguszlzt.metWsvlopnliexx(context); return;
			case (1): generated.rzcpj.imb.axphv.psemq.ykmed.ClsJszqdkpwcikmae.metSqzztoyk(context); return;
			case (2): generated.wwbmr.iqko.nht.ClsCnzakidxmh.metYvzavpzpnbo(context); return;
			case (3): generated.abpq.uqd.wdeqd.mcta.ClsWlrvlsbwwa.metUuvxhn(context); return;
			case (4): generated.olnh.vng.ClsLcraqevyogmja.metHrpnbihsknjv(context); return;
		}
				{
			int loopIndex24879 = 0;
			for (loopIndex24879 = 0; loopIndex24879 < 7174; loopIndex24879++)
			{
				java.io.File file = new java.io.File("/dirUojtuhokqea/dirNwupqnmihox");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varPludkckhmfe = (9563) * (234);
		}
	}

}
