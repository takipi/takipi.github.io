package generated.ocg.pnhd.assci;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsEkxxqpavkqxkay
{
	 public static final int classId = 279;
	 static final Logger logger = LoggerFactory.getLogger(ClsEkxxqpavkqxkay.class);

	public static void metDpnizequfd(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[8];
		Set<Object> valDyhcwxnnmfb = new HashSet<Object>();
		Object[] valQqcqnhzpkmc = new Object[4];
		String valQurnfzeqooi = "StrYphgrxunxjc";
		
		    valQqcqnhzpkmc[0] = valQurnfzeqooi;
		for (int i = 1; i < 4; i++)
		{
		    valQqcqnhzpkmc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDyhcwxnnmfb.add(valQqcqnhzpkmc);
		Map<Object, Object> valRwkttxbtzlf = new HashMap();
		String mapValWqitlaxowwg = "StrKbonpbihiyo";
		
		int mapKeyKyiqpynllfa = 773;
		
		valRwkttxbtzlf.put("mapValWqitlaxowwg","mapKeyKyiqpynllfa" );
		boolean mapValQdmxoqidrql = true;
		
		int mapKeyHgdfpbhuwrx = 366;
		
		valRwkttxbtzlf.put("mapValQdmxoqidrql","mapKeyHgdfpbhuwrx" );
		
		valDyhcwxnnmfb.add(valRwkttxbtzlf);
		
		    root[0] = valDyhcwxnnmfb;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Strryt 4Exgym 11Dyxwxkpjinwo 4Rcvnj 12Zcwoxaoqfyvyj 10Hougmkkvzei 5Lcpwwc 7Cjrwrnvk 5Nycrgd 11Lhzradkyrfti 5Qwuesr 12Wjbsjoilxhspr 4Tmehg 10Qdzyqoklfnb 11Ranhgsbacrjs 5Nzltba ");
					logger.info("Time for log - info 6Vxcnwgm 7Vdejcmib 12Bqnxjgxpilexs 12Zvplaaeadjntp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ogy.ayf.aijxy.ClsNdoxmvj.metCsqrhmq(context); return;
			case (1): generated.wvtjl.ppaeb.ClsGdkttp.metTgqpaqsi(context); return;
			case (2): generated.rkfhx.ntcs.qoe.lasd.nzzym.ClsDftkqmvmp.metEliwmlxsgnolka(context); return;
			case (3): generated.oue.dqjq.ClsSjudu.metOcoveezijltpk(context); return;
			case (4): generated.lsv.svu.ClsVsswgqo.metKnakkpce(context); return;
		}
				{
		}
	}


	public static void metCmxzsyw(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valHgaxrjtkvxw = new LinkedList<Object>();
		Map<Object, Object> valFzbndcuwjse = new HashMap();
		long mapValPxfsvvyjiea = 5996942985073551078L;
		
		long mapKeyWgkbifuvrgj = -2941960021804715537L;
		
		valFzbndcuwjse.put("mapValPxfsvvyjiea","mapKeyWgkbifuvrgj" );
		boolean mapValGklfvwnqrxm = true;
		
		long mapKeyMgigfckacvc = -2293778985749389614L;
		
		valFzbndcuwjse.put("mapValGklfvwnqrxm","mapKeyMgigfckacvc" );
		
		valHgaxrjtkvxw.add(valFzbndcuwjse);
		Set<Object> valAmqckfzgixk = new HashSet<Object>();
		int valLhqwpcaxgdd = 419;
		
		valAmqckfzgixk.add(valLhqwpcaxgdd);
		
		valHgaxrjtkvxw.add(valAmqckfzgixk);
		
		root.add(valHgaxrjtkvxw);
		Object[] valVdnewraynvn = new Object[8];
		Map<Object, Object> valUsapeorerrq = new HashMap();
		int mapValNwshwghuvst = 902;
		
		String mapKeyNrrsegrsuud = "StrSdtuozgkqsa";
		
		valUsapeorerrq.put("mapValNwshwghuvst","mapKeyNrrsegrsuud" );
		
		    valVdnewraynvn[0] = valUsapeorerrq;
		for (int i = 1; i < 8; i++)
		{
		    valVdnewraynvn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valVdnewraynvn);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Iyyrramyabhl 5Gwcwrc 4Hhnum 7Uyvichnm 11Rylvvmgiquzq 9Afzpdrxpor 9Zrnvsrvfqp 6Bedkmnc 9Znybutkkeg 12Kzwqjlkodytjy 9Izdgpaofbe 8Ppsjewcnl 10Tfgcheebabi 7Vvpqrvsp 8Qawgjuake 11Keaohjicinwa 6Ivfonaz 7Pxsawfcy 12Kkzcuzlvjpszu 8Chzqoxfne 8Unhwahkkj 10Bchaiazcvsr 10Fbnbqhapizm 7Lvqobqpz 4Iwrxm 8Wlljvrane 6Tbxpekh 7Tctvccsx 7Lrnxvsbg 10Writsrjvrzx ");
					logger.info("Time for log - info 10Zrhiwqcfibh 4Ojlod 8Cpqdsshss 10Xgupquoeemv 10Qzfygrxvokv 12Yupmpxmujriie 11Xqtijbmbsyoz 6Yhmwkwc 9Pfeysmjkgh 12Khdyqciovuoix 6Ueochxa 7Zlrmfyyz 10Geqwkrqaygf 4Uvctd 4Lllmc 4Nnrhq 10Dacubsqypud 4Hnhmu 7Baxjovzc 5Pejrdv ");
					logger.info("Time for log - info 3Ljuf 7Zlzfxhxc 4Vacat 11Npndzubtalxt ");
					logger.info("Time for log - info 8Lzkysefzm 4Qwnyv 9Jqmmmobkzb 7Dhdlhfqb 8Haghtthzd 6Mntqyja 6Bvlhodq 11Eudobwjffkzs 11Hbtnmagdyhvb 3Khrg 8Tyyrjukgq 10Fowtkuixfmw 8Kjqpngosp 10Ejfwlyulxfl ");
					logger.info("Time for log - info 3Zyko 11Abfvjqqackuf 10Ouawvlhiwuh 5Mqcary 11Jtturcijlujp 8Etbbfoqsw 12Lnmzvmgrdvqsu 8Woldjqejf 12Ucpblewvarosw 7Hjdwuyqp 5Wwczlo 3Didk 7Jhgehqyi 11Nqixcvbxkkmx 7Qmeebaxg 8Ckluzrhpc 10Vesbymqzxzh 3Riqq 10Zyjftzaabli 4Kaoks 3Bqpy 9Ddyanrsdnu 9Xxlabhmlad 10Xivucukfxqk 3Qebd 5Onsaky 10Vsuhmcpimxp 9Vgyxzjeubh 4Wkbvg ");
					logger.info("Time for log - info 3Amfy 8Ggfperyeg 11Speadkkmrafy 6Xdpsahp 11Portltqnjmym 4Ghcnk 11Pchhzxephdga 12Zfpnrjewlytks 9Rhmrovzqrz 11Iczskgklmtau 7Mynmjfgo 5Lxlegv 5Ygfupv 10Kvjcstvrvnr 7Gvvzdctw 8Cueyrglsn 12Riadjpiyuufja 10Oiadqkmjfbz 6Igksqbp 3Vril 8Axrnnvwbz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Grjnfex 10Xjdonwxsodb 5Tpgtsi 4Zlndc 7Bwowxwqx 11Yslqnxsgzkqc 11Hyujafuoiinx 5Axgoiq 3Inrb 5Otiros 7Ilauvhlr 11Xvwwxvxvqshl 7Knwezrkw 9Gtstrkpaim ");
					logger.warn("Time for log - warn 7Iejumswu 6Bjrvloc ");
					logger.warn("Time for log - warn 9Viownucubf 12Jmwgtmmbhkmck 12Vqwfykynhjxwl 9Nopruvqxkd 3Baqf 12Lzwhahfkbhyhp 12Ivpnzdgistppx 6Txkhipq 7Gcaevzwt 8Quyforbls 10Xngnadybcut 9Kiikucvkid 3Zclt 4Bmata 10Dfozgswddoe 9Irkyzkwpjl 12Jwyccroyelgxb 5Zedapj 10Ihhunykggqz 8Sgpfqedrb 4Iazir 10Fmjctuegvfp 7Xizooeic 7Njikrylw 3Tvop 11Emwughxntpmp 10Owcqwuhnqhl 5Sjczmn ");
					logger.warn("Time for log - warn 11Qipulubikmkf 10Yqftujzxgiu 6Hckqrsc 11Dboitujyedno 5Zsdoaz 9Gmdcsyczvg 4Mzqie 6Hhqpcyb 3Njbj 6Pddmnik 12Fehjnervgycwn 8Uhdnnklig 5Dfhlve 7Ibnvqgcv 11Gzzjahbmqpib 9Rdtednijsn 12Obeeqthhjuyvr 3Dwss 4Xocon 5Ncvbou 5Gwjptd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Hhhspotj 10Pwqgwymevqc 9Azqeieqccx 7Kfofzczo 3Webu 5Wjxbku 5Fvalwy 3Ygub 4Wxudo 3Suyu 12Klclmcjqhjiph ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
			case (1): generated.xam.emsw.ClsNwmpfankaxgqb.metVftvklava(context); return;
			case (2): generated.yfwg.zmane.bbbip.wqsm.tbdz.ClsSzekb.metZjimsrct(context); return;
			case (3): generated.iyxve.emn.dzc.ClsAggygwujkgt.metWmlfsxai(context); return;
			case (4): generated.mccr.hhayo.cgyp.gjrvj.ClsTjitk.metEzejeawgiswo(context); return;
		}
				{
			if (((3614) % 138222) == 0)
			{
				try
				{
					Integer.parseInt("numHaluczasfnw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numMwlwrcndimk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metTiqnjmdqil(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[9];
		Map<Object, Object> valJhfevkhrrrb = new HashMap();
		Set<Object> mapValFzybovuvhxv = new HashSet<Object>();
		long valZvpoylevvuq = -6929191758587658039L;
		
		mapValFzybovuvhxv.add(valZvpoylevvuq);
		
		Set<Object> mapKeyKnglzyxheqi = new HashSet<Object>();
		long valZpmekzzayke = 7273347174945622825L;
		
		mapKeyKnglzyxheqi.add(valZpmekzzayke);
		
		valJhfevkhrrrb.put("mapValFzybovuvhxv","mapKeyKnglzyxheqi" );
		List<Object> mapValCkviuganlgy = new LinkedList<Object>();
		boolean valWequzjdrlpd = false;
		
		mapValCkviuganlgy.add(valWequzjdrlpd);
		boolean valTdivuhhnyja = false;
		
		mapValCkviuganlgy.add(valTdivuhhnyja);
		
		Set<Object> mapKeyKmtjtbdscpr = new HashSet<Object>();
		int valToivfqosrcw = 584;
		
		mapKeyKmtjtbdscpr.add(valToivfqosrcw);
		String valNekbmxqzone = "StrWkbbkazmwjy";
		
		mapKeyKmtjtbdscpr.add(valNekbmxqzone);
		
		valJhfevkhrrrb.put("mapValCkviuganlgy","mapKeyKmtjtbdscpr" );
		
		    root[0] = valJhfevkhrrrb;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Txnukf 3Noie 4Yiosa 12Txscyrxkubdew 5Eiamrv 7Rndhsdhk 6Addaqwe 7Cbfotkol 12Qqtvpcqeelftw 4Ckjjj 4Xpgwo 6Miwcsnb 5Nuuntk 7Nerxumpx 11Vfriwzbpmeby 7Dyppertn 6Quaxkla 12Tskfmbatnkhtg 4Fefkx 3Yvds 12Vcxvcayrcrnpd 12Bpvglzsuapflf 8Pkoyrnfjp 8Klsclqopi 3Wypc 12Qdbvhzwbqhvlu 9Cyrfrrfezt ");
					logger.info("Time for log - info 8Yjkdsdopu 10Ytfclhixdcb 4Zsgjf 10Xuwmvyhuqdg 5Lsmdnj 4Lobcg 9Tjzwuyoqul 3Ghre 7Joxjgyst 5Gjuovy 8Pugikvuyg 10Yesvjwfmzgj 12Dnecikopkwaiy 10Vlmjdyodhld 9Scwdjzotti 6Psdeasx 12Ergelqdpjpbla ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Oddw 10Mndpxaabges 3Ubov 3Xygp 4Bwzta 8Chrhgjbho 9Akmomizijm 12Bbldfuturvuhh 11Gaotfibtecea 6Pistfzt 9Yvvcdlmxjz 8Jktrsrdmk 11Lwrchkvdojrc 8Yclcxdnbk 12Zpwxlrrtrvicq 8Yopgwhrox 5Azwtzu 11Qgvikijnnaze 6Exrwmoi 9Keujtrelvu 12Frgmllejctrgg 7Xawrayad 4Evhrp 12Xmeulldtfksop ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xluq.wys.lexvj.ClsEsonclfnnvbg.metAvsgvixigx(context); return;
			case (1): generated.ctymn.uic.kza.ClsBochsrrjh.metGygnvmjatcdvgy(context); return;
			case (2): generated.rqcl.nvc.nixtb.fedm.ClsWjomfkmimge.metOdnmynznpwczd(context); return;
			case (3): generated.kcrh.cmo.yws.ClsBlekldezyl.metLtlpxelwrxf(context); return;
			case (4): generated.vvl.eygsr.pmv.fzat.xuhvb.ClsRspudgdgeelrz.metKpypbtozts(context); return;
		}
				{
			long whileIndex24827 = 0;
			
			while (whileIndex24827-- > 0)
			{
				java.io.File file = new java.io.File("/dirPngqubbcysz/dirIniwfdlxyth/dirBjzmbwnydlo/dirLmjwwxddtwl/dirUdjgezwarbe/dirBkayhfygqyf/dirIztqnxdhaui");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metChyppmprgvzqeo(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValKjlbsqpkcuk = new LinkedList<Object>();
		Set<Object> valFbfeyuezken = new HashSet<Object>();
		boolean valLzxtnphqvry = false;
		
		valFbfeyuezken.add(valLzxtnphqvry);
		
		mapValKjlbsqpkcuk.add(valFbfeyuezken);
		
		Map<Object, Object> mapKeyIggllgtmnto = new HashMap();
		Map<Object, Object> mapValGernxvcsefx = new HashMap();
		int mapValOnxpcwhkzbj = 628;
		
		String mapKeyShceydehica = "StrGlvlegrupus";
		
		mapValGernxvcsefx.put("mapValOnxpcwhkzbj","mapKeyShceydehica" );
		boolean mapValFgvnlkzuflg = false;
		
		boolean mapKeyDxjhrxcqgcw = false;
		
		mapValGernxvcsefx.put("mapValFgvnlkzuflg","mapKeyDxjhrxcqgcw" );
		
		Map<Object, Object> mapKeyKlssnlwoqeu = new HashMap();
		String mapValJtdzjunilyh = "StrNpmozgerynv";
		
		String mapKeyXsxpvwdyjwk = "StrXnsphuqdcul";
		
		mapKeyKlssnlwoqeu.put("mapValJtdzjunilyh","mapKeyXsxpvwdyjwk" );
		
		mapKeyIggllgtmnto.put("mapValGernxvcsefx","mapKeyKlssnlwoqeu" );
		Set<Object> mapValFcrcivgkefw = new HashSet<Object>();
		int valNnqdixnuhce = 619;
		
		mapValFcrcivgkefw.add(valNnqdixnuhce);
		boolean valHrcycaunwfj = false;
		
		mapValFcrcivgkefw.add(valHrcycaunwfj);
		
		Set<Object> mapKeyUulrbirgniv = new HashSet<Object>();
		int valKcaaztqjnti = 281;
		
		mapKeyUulrbirgniv.add(valKcaaztqjnti);
		
		mapKeyIggllgtmnto.put("mapValFcrcivgkefw","mapKeyUulrbirgniv" );
		
		root.put("mapValKjlbsqpkcuk","mapKeyIggllgtmnto" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Ldthpjspaqdn 4Fhred 12Vyixetyysyxaq 12Rseahknlmooku 12Xxdyldfvitdyb ");
					logger.info("Time for log - info 12Vqqoxnqdmende 10Kerqpnzamzs 4Wcevd 10Zitxozdscnv 6Oodcpda 6Nvkzjaf 3Mfue 10Fldhnwydfow 7Klraqjfx 4Yjmpk 9Tabgaagyue 5Tsbkaa 6Tfdiwpy 12Mvoujvzzwvxdi ");
					logger.info("Time for log - info 9Fshbitqkyd 6Rzxtwsi 11Kgsemkbdskzf 3Lchi 10Tekokupdnqh 8Adhwtkktq 12Hiftpknaidmyx 11Lzdnhcsklszl 9Xemwovullg 3Ydio 8Skzqhreic 7Ngqdsnbq 7Hdeppmqr 11Sehtwmhwpfpv 11Gnmktpqpobbd 3Enxg 7Zozjyico 7Hvptfxbh 9Syaytmmwlx 11Ksiriawacvpc 6Veqzqtg 4Zqhoh 5Oxdgum 4Epbna 8Tzxdaxdix 4Dixmv 7Ufrdwyrd 6Iazyehn 12Xgwfxehjlskpt ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Hviizm 6Jupwocp 6Sngtlhc 3Fzpf 10Ewjsfqfwdnw 12Tisouwjnevlow 3Kwat 11Kxwdmauqwvau 9Uljexcgthx 10Vyoxvszmgfe 6Ducfwhz 6Vtqubtp 7Viwtnmwl 8Ljxxstbet 5Gtgjrq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Svfufhsoygc 7Teqxbgec 9Ucnvrwbgvy 10Hsrukifftws 6Grdybgq 11Urhnsaideoif 6Zzcdhpw 4Kxjny ");
					logger.error("Time for log - error 5Eydqoz 3Xwbg 9Oneaiyzute 4Shbxd 7Gaubwvwo 3Gajx 4Vtrjy 6Ijrllmp 7Wclmqylo 9Jgnapwloyu 5Dwmnbf 8Gkfmhumcx 7Isfuajle 3Ajol 10Cjlzkppysva 3Miyk 8Gtmcecamu 8Wkbrqkuxf ");
					logger.error("Time for log - error 6Lohscxw 12Mprxvxpssbisy 6Ooolbsi 5Lixvex 5Onwayb 6Lyjstaz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wwtht.wyffd.ClsDnoox.metFwosjn(context); return;
			case (1): generated.mtq.flhse.ygibh.yfs.ClsSzzuamch.metIuxgxgafdnqnhh(context); return;
			case (2): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metWzqrqrjxhdrs(context); return;
			case (3): generated.vqvzb.mlzv.dxgr.ClsUgxxgr.metAqgou(context); return;
			case (4): generated.yudi.kwckr.ClsDwmxwqmygi.metIhnyn(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(717) + 0) - (5180) % 52422) == 0)
			{
				try
				{
					Integer.parseInt("numJfwzsdhqnij");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((6540) + (2223) % 665735) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metAxxkcrttpcwrw(Context context) throws Exception
	{
				int methodId = 4;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValYcvghctpkoq = new HashSet<Object>();
		Map<Object, Object> valGbfkttvrjkk = new HashMap();
		boolean mapValXztsvpkbgwh = true;
		
		long mapKeyQrknasrbytd = -8275162431933347021L;
		
		valGbfkttvrjkk.put("mapValXztsvpkbgwh","mapKeyQrknasrbytd" );
		int mapValVuyzxpfulwm = 773;
		
		int mapKeyTbqlsocilbu = 571;
		
		valGbfkttvrjkk.put("mapValVuyzxpfulwm","mapKeyTbqlsocilbu" );
		
		mapValYcvghctpkoq.add(valGbfkttvrjkk);
		Set<Object> valEmghecucfhg = new HashSet<Object>();
		int valZopjkkvfpxf = 977;
		
		valEmghecucfhg.add(valZopjkkvfpxf);
		
		mapValYcvghctpkoq.add(valEmghecucfhg);
		
		Object[] mapKeyJbyejbbbkth = new Object[2];
		Set<Object> valNgvpdovtaca = new HashSet<Object>();
		boolean valKiggolhguga = false;
		
		valNgvpdovtaca.add(valKiggolhguga);
		long valKskwomojicm = -5922617193758018008L;
		
		valNgvpdovtaca.add(valKskwomojicm);
		
		    mapKeyJbyejbbbkth[0] = valNgvpdovtaca;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyJbyejbbbkth[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValYcvghctpkoq","mapKeyJbyejbbbkth" );
		Map<Object, Object> mapValPwrelmtqovb = new HashMap();
		Map<Object, Object> mapValUjlckyvxvji = new HashMap();
		int mapValZlseiamcsdc = 157;
		
		boolean mapKeyKhsznnddpkl = false;
		
		mapValUjlckyvxvji.put("mapValZlseiamcsdc","mapKeyKhsznnddpkl" );
		
		List<Object> mapKeyKbajckdznxe = new LinkedList<Object>();
		boolean valPgftntadauy = true;
		
		mapKeyKbajckdznxe.add(valPgftntadauy);
		long valElbfxmjsfai = 6472525098716545296L;
		
		mapKeyKbajckdznxe.add(valElbfxmjsfai);
		
		mapValPwrelmtqovb.put("mapValUjlckyvxvji","mapKeyKbajckdznxe" );
		Map<Object, Object> mapValLpbpqsbkdno = new HashMap();
		long mapValCdrfacrogpw = -5169259018900635473L;
		
		long mapKeyWopazxmdibi = 2980654659044455569L;
		
		mapValLpbpqsbkdno.put("mapValCdrfacrogpw","mapKeyWopazxmdibi" );
		int mapValKhkwdzorezg = 656;
		
		boolean mapKeyXrzrylhzxzf = true;
		
		mapValLpbpqsbkdno.put("mapValKhkwdzorezg","mapKeyXrzrylhzxzf" );
		
		Object[] mapKeyDvwgeiqxiwb = new Object[6];
		String valHkonwqxbzvf = "StrVjpruuhrdxl";
		
		    mapKeyDvwgeiqxiwb[0] = valHkonwqxbzvf;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyDvwgeiqxiwb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValPwrelmtqovb.put("mapValLpbpqsbkdno","mapKeyDvwgeiqxiwb" );
		
		Object[] mapKeyPckavxediiv = new Object[9];
		List<Object> valHhaklwiflhl = new LinkedList<Object>();
		int valVnesatwxyjl = 567;
		
		valHhaklwiflhl.add(valVnesatwxyjl);
		boolean valLwpebaypdjy = false;
		
		valHhaklwiflhl.add(valLwpebaypdjy);
		
		    mapKeyPckavxediiv[0] = valHhaklwiflhl;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyPckavxediiv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValPwrelmtqovb","mapKeyPckavxediiv" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Gsyixwlfkdk 3Ihre 7Zozmnpjf 4Kremu 10Ayqnserpybw 10Himzfyjddzx 7Tcpsxbit 9Ahmxbhxygj 7Xqfaelyv 6Tyjocws 5Uwpyts 3Tsbw 6Sqefwwy 10Xwsqsequxcj 11Abdlwkgdswny 5Otljja 7Hgufccfb 7Liihbkkh ");
					logger.info("Time for log - info 6Tdujoak 11Yujxbhfhvmae 6Cdaeczc 5Ybobij 4Yhiba 4Zqjud 9Uagfniofkt 7Hvzctrzx 12Wlvadoakvpunr 7Pqqwjaev 4Lucqn ");
					logger.info("Time for log - info 3Etnx 10Kqxgrzilasp 3Atmn 11Wxklvtcdjlez 7Dbvrigdf 3Zejf 10Dfpbmvmzyhn 11Mbidfdwajntu 4Kzdyf 4Jhjjs 4Wavel 10Cawnpxviekw ");
					logger.info("Time for log - info 11Nefhizyaoopw 3Xpoq 8Wdmzvlhuv 6Gmezcrp 5Milmzh 12Znxrafcewfzff 4Btwqy 12Caeitnfrvpbeo 11Mnttvyzbrpam 4Seoqs 9Onggodgdiu 11Cqwjwjogtvvk 9Fgivkpejrp 10Ypzuvtrowlf 9Pblczdkgqc 6Vscjvee 12Urhbpcvduvdle 8Mxcefwich 6Nokwddb 11Qlffpmriqjdg 10Gflmjfhckbs 9Yyrctnomhw ");
					logger.info("Time for log - info 3Mint 9Oqiyosbhsd 10Mpabzzfspfv 10Bfrxdeurgof 10Gaqfqwybhsg 9Nkbeqrdicm 8Pxvlkkscm 8Ncmqfsdbt 3Ikil 12Dskvmckpqpfge 7Jdiwgpfh 6Iewujei 8Dzgvzfnwf 6Lbabprn 6Ieetvbs 12Jzknavijybaws 6Hjbfxbj 6Seniwml 6Swoiney 10Arupcbmebox 9Eleunilbtr 8Nttnjdzlf 6Eteofrj 8Zlrqiaakn 5Licapz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Aakpjqw 8Dpsdytzyw 6Fkaaonu 10Cyjfbcppjos 8Igvnqxbtb 12Tpftfhjzgodoh 4Giwye 5Yffyff 10Nuovymnzfgw 4Evhnv 9Ytoskzsasv 12Prpznxhgjbwas 7Elufrzzv ");
					logger.warn("Time for log - warn 6Vgenopl 6Gsnhpon 5Zjntjx 9Lyowxfjcof 6Lovavmz 8Fkmzhfsim 9Hrqjtldpup 11Kzfxifoqgkjh 12Arrugvidmdcgy 8Vaossskil 3Skrz 6Xgzwlpp 12Gjlimfihaiacc 4Gaojo 7Tqddxsfg 12Tokxyjtmagqkp 3Nzgx 12Esdhfofaduyvy 8Iihvpkgaq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Xwudqexwp 6Efhfmom 11Kljpiyvqwrzf 4Crccr 4Ioene 4Waixy 10Cmvhsrvtnye 6Zzeekza 6Rrgbarb 10Nljdtlvfgkr 6Ykbkxep 11Sqqezuiwslnd 6Niydsns 4Nhfbf 5Ylpepf 11Aiwdlgztlhie 7Lscqadao 11Zbecmywqqflk 6Uwaxonf 7Yjamckxt 10Jjpclaedcmj 9Xrutinjhex 10Rogtvlaouck 3Ftym 3Njah 7Jppatgrq ");
					logger.error("Time for log - error 8Ekksxhpce 8Iuezoxxgu 4Davxi 6Zzdgdae 9Iuhcsoqxws 11Oeurstgjbgrx 12Hvmcritzgwpqx 3Ydvc 8Xmvslnnem 9Ayaqonizts 8Kbmamnxpr 12Sgmqtfffpgkmc 3Eips ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.njly.vbegw.ClsZmoko.metJwavcrjhvbybi(context); return;
			case (1): generated.rnv.dtvl.uhnk.ClsTzqkdsb.metSeczfqzvcdesmp(context); return;
			case (2): generated.vuj.qjcvs.phb.poi.ueh.ClsHxaaaxntrhq.metHrwdn(context); return;
			case (3): generated.aoa.azm.ClsTnwlnxjluoc.metDtywcweejrgwcl(context); return;
			case (4): generated.xam.emsw.ClsNwmpfankaxgqb.metVftvklava(context); return;
		}
				{
			int loopIndex24835 = 0;
			for (loopIndex24835 = 0; loopIndex24835 < 9100; loopIndex24835++)
			{
				java.io.File file = new java.io.File("/dirYbtnzjvusut/dirXczwteyocuq/dirNnemxzwzfwz/dirJgeyeydebny/dirQaylwuqrxjf/dirRwtpzqjqctf/dirWrsjjthcymk/dirDdjwzplacpp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((Config.get().getRandom().nextInt(349) + 3) % 296499) == 0)
			{
				try
				{
					Integer.parseInt("numZonppcnsspk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirBxezwnasevn/dirJbshsfgukry/dirYwrlwkdfagf/dirIafvdamhpyf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
