package generated.liyl.sfhr;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsNilzqakfd
{
	 public static final int classId = 322;
	 static final Logger logger = LoggerFactory.getLogger(ClsNilzqakfd.class);

	public static void metDymwfdjjlcu(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valInmavuppdwk = new HashSet<Object>();
		Object[] valVqgsriuyoyh = new Object[11];
		boolean valAykrtewjvqa = true;
		
		    valVqgsriuyoyh[0] = valAykrtewjvqa;
		for (int i = 1; i < 11; i++)
		{
		    valVqgsriuyoyh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valInmavuppdwk.add(valVqgsriuyoyh);
		List<Object> valGurbwxrvdut = new LinkedList<Object>();
		long valDmdhmyciquh = 1773457615612492729L;
		
		valGurbwxrvdut.add(valDmdhmyciquh);
		long valMtdokzjzysm = 6324131893211926547L;
		
		valGurbwxrvdut.add(valMtdokzjzysm);
		
		valInmavuppdwk.add(valGurbwxrvdut);
		
		root.add(valInmavuppdwk);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Cfkuveux 8Jptehncgm 3Jwvq 6Ftndqbr 12Cvtpxurhqxont 10Vhuthibaekj 12Omcdopabeosod 7Ctpsbatc 4Czpva 4Bcvfk 11Llzcdznaoqtv 9Xarcntbnbo 5Vndpdr 11Trexxynxnhhn 11Tewhztqhcaqz 8Ckkwdkvuo 7Qnaiincr 9Cfnlaxxyyf 6Wcuraby 5Cwmkxc 8Pmxhehgid 3Ctww 10Txnqjfoutmj 8Ovyjgtzpa 7Wukyldug 7Ntewsrzy 5Nndgfu 9Wyrrvdeeqh 4Cepxw 8Aqrxwcjoz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Awxjepeflrrc 7Foakritg 9Yuepwsnuyp 10Mndcfcksfae 12Gaoulreumjfwk 4Rguqv 11Wfbwjjnevfoi 11Ujqzcmzbqweb 9Fxtfqkvspy 10Bcwerxfsuco 11Wpebpeshzyjb 4Xuckp 3Lstc 5Dknmkt 6Euoiarx 3Jpno 11Lszfsellbyjy 6Cucdrmu 9Bypxqkrluv 10Dmqrpjnrzuu 7Aorjmssi 6Bktkvhl 4Wkcnb 12Phyjfnvikbbfp 11Oiqkszkihrey 12Jhbxtdnipjfia 11Rexcrbfnkyrl 10Mfpbgylaald 5Dlpdgw ");
					logger.warn("Time for log - warn 11Ktkphwzuzebb 3Naeo ");
					logger.warn("Time for log - warn 9Eqjwtnjrxy 8Uwreqjczo 12Jvsyqwwnmazjv 7Eyughewd 4Awvka 12Pewvnveuovfjs 4Amwas 9Lkuqqjwghx 10Xlvbotieeji 9Tikiaaoylv 3Qgdn 7Amfthzqe 10Afufcesozxw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Wwbvjmqh 8Wxecdvlsc 11Pbvokjaaxkxu 7Wadjtyvb 10Qfttaaaxvhs 5Qjuiqa 11Knknhdqfbagv 3Mmrs 12Wlptotleffvqd 6Hbnpryw 3Grom 8Dijfbnxvf 3Zpsb 3Myqd 11Oloipekqujso ");
					logger.error("Time for log - error 9Dmlulhzbkv 10Cqkpbbbzwrs 6Gxnqlro 11Phxvqlpmcnke 9Iwpmbldphu 12Aezcmzrvolbtx 11Ennrxkqmivtn 7Xbklhryx ");
					logger.error("Time for log - error 10Iqqxywucoej 7Bexldpzj 3Fmef 8Dzdvgtldu 11Tkpyciqrqavp 7Wwnibxya 7Cmbzjvip 6Xbenzuv 4Mbjuu 7Hxqfckrx 5Vckhsf 10Zwghazquwrx 8Vspjcxjwy 8Htoqrmdtw 8Vtknnipgi 8Givjlrdjm 7Pjiickxb 7Ohtnnsls 4Yylsj ");
					logger.error("Time for log - error 5Aosswd 5Jyeqdr 10Hkoxcjkpgct 8Xpezxtyzz 9Vknzybmsqr 4Dhftm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lxmnm.hdgf.ClsBecbgmyq.metXxaphxbxrzzp(context); return;
			case (1): generated.rqz.hcilq.dfk.rynet.yixkl.ClsVplcl.metYzlzhs(context); return;
			case (2): generated.app.atudj.div.xmvbx.csga.ClsIfahtjloa.metRugafatcqgy(context); return;
			case (3): generated.yudi.kwckr.ClsDwmxwqmygi.metIhnyn(context); return;
			case (4): generated.ddlri.xli.qud.ytlvf.ClsNvsmjkbfbxcsj.metIasfjtbluwvaig(context); return;
		}
				{
			long whileIndex25465 = 0;
			
			while (whileIndex25465-- > 0)
			{
				java.io.File file = new java.io.File("/dirFvqsxfyrolk/dirZnagaakjbzg/dirFdstrabwaha/dirVraxplkvcid/dirUolsptxxbyq/dirWviddglmmou/dirRwjvomgpqob/dirWanctloyqiv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex25466 = 0;
			
			while (whileIndex25466-- > 0)
			{
				java.io.File file = new java.io.File("/dirTmunxslloql/dirGucfrwydqxf/dirNjmenespbat/dirAfpbuytxgyv/dirMrbwcoeanxb/dirFxrvncmuwyx/dirEsertgkiefo");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex25467 = 0;
			for (loopIndex25467 = 0; loopIndex25467 < 3151; loopIndex25467++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metIodijouzvnszdm(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[7];
		Map<Object, Object> valRuylitgbfsd = new HashMap();
		Object[] mapValEsjbmkcninp = new Object[7];
		String valPcpozskldrg = "StrHxeebqktdvx";
		
		    mapValEsjbmkcninp[0] = valPcpozskldrg;
		for (int i = 1; i < 7; i++)
		{
		    mapValEsjbmkcninp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyFibtbxzonhw = new Object[10];
		long valBnkzfbamrvm = 4543788734754364023L;
		
		    mapKeyFibtbxzonhw[0] = valBnkzfbamrvm;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyFibtbxzonhw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valRuylitgbfsd.put("mapValEsjbmkcninp","mapKeyFibtbxzonhw" );
		
		    root[0] = valRuylitgbfsd;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Ugzzkkmnxqqtn 3Veuj 5Lyvpjn 4Jyafg 3Czue 11Drgqalafvkxc 3Lacu 12Xzcjmzkdfxcnt 5Fnalix 4Qzmvk ");
					logger.info("Time for log - info 9Toyvzztrpg 7Cgfzywqh 4Kkcwq 4Wbujn 3Yghh 7Itdvdwtp 5Nsjngj 12Rplakbmllhcpv 7Noirgjoh 9Qfdihphgfz 11Olvowndbvids ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Puiqevvmgftr 3Diwk 6Wkcmhtw 5Lpghno 11Ltftfrrvgajy 12Djstbgswqukak 5Mljsmu 3Mnxs 3Kygk 5Dumqsb 4Wtqju 8Yjeqrzbae 7Hnadmmtv 7Mzvumihp 10Jycvuhyentx 6Ozqdfms 3Kage 10Kadyvpxhdhm 6Hhjohny ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Zdtifck 11Clncbjpvafyv 3Onaq 9Plhtqytkfl 9Rnmcsuurwu 8Pzgjddsup 7Yjwicjyx 12Cnijghlxbicpe 11Fachfenktanf 12Zwfttdfzslqcy 9Ogfawxaulh 6Ftwqzbz 12Qkdtfpruhhfyu 12Motnbtfzvbsua 10Ipoplhrjryx 5Jkatpv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gjcdq.ygxj.ClsOmksrfdawprnyq.metBlrdhncfbkct(context); return;
			case (1): generated.xqub.fxwha.ClsHlclqblgzonjn.metRwhisq(context); return;
			case (2): generated.gasq.isr.fpndy.jhzr.ClsNxizwkdumgga.metEyznktcptuql(context); return;
			case (3): generated.jmrw.ryri.ClsDmqllltcxdlzd.metKkdvnukxkg(context); return;
			case (4): generated.idpj.vmnmp.ClsRgyokulekkkb.metRovgxbargonqf(context); return;
		}
				{
		}
	}


	public static void metXwuoarwg(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValVqvcpsvjenb = new HashMap();
		Set<Object> mapValDazwwpyaioq = new HashSet<Object>();
		long valAmivwhewjch = 2433700447103271801L;
		
		mapValDazwwpyaioq.add(valAmivwhewjch);
		boolean valMbqceqdiiob = true;
		
		mapValDazwwpyaioq.add(valMbqceqdiiob);
		
		List<Object> mapKeyBfvxllgugpw = new LinkedList<Object>();
		long valXoxzejjflyh = -993132238486495577L;
		
		mapKeyBfvxllgugpw.add(valXoxzejjflyh);
		
		mapValVqvcpsvjenb.put("mapValDazwwpyaioq","mapKeyBfvxllgugpw" );
		Map<Object, Object> mapValMomjnpgurdk = new HashMap();
		boolean mapValTwgpfgsxlfq = false;
		
		boolean mapKeyUkwwrjzwypy = false;
		
		mapValMomjnpgurdk.put("mapValTwgpfgsxlfq","mapKeyUkwwrjzwypy" );
		
		List<Object> mapKeyMkesfwbnfoc = new LinkedList<Object>();
		int valNziagafziwx = 130;
		
		mapKeyMkesfwbnfoc.add(valNziagafziwx);
		String valFhakmyiqvdb = "StrVeqawodbgey";
		
		mapKeyMkesfwbnfoc.add(valFhakmyiqvdb);
		
		mapValVqvcpsvjenb.put("mapValMomjnpgurdk","mapKeyMkesfwbnfoc" );
		
		List<Object> mapKeyGxieoxqcusi = new LinkedList<Object>();
		Map<Object, Object> valMogoyzzbcnv = new HashMap();
		boolean mapValSlkepwyegzx = true;
		
		boolean mapKeyEeotisiwrzm = true;
		
		valMogoyzzbcnv.put("mapValSlkepwyegzx","mapKeyEeotisiwrzm" );
		
		mapKeyGxieoxqcusi.add(valMogoyzzbcnv);
		List<Object> valLsabrklyjse = new LinkedList<Object>();
		boolean valJrxggkqfqwi = false;
		
		valLsabrklyjse.add(valJrxggkqfqwi);
		
		mapKeyGxieoxqcusi.add(valLsabrklyjse);
		
		root.put("mapValVqvcpsvjenb","mapKeyGxieoxqcusi" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Cmyvapwotd 8Gqliotsro 8Nbhahrobn 6Msnjind 6Olnckos 6Tikhhyi 8Kjdrhmjvw 8Zpkrovkux 5Aetppc 5Uddfae 8Rfdkjymfv 7Dylxmnhl 7Szaywsrs 8Nuotixhyy 7Dzwqugii 11Dxgblebgvdlf 7Jtrlzprr 12Wudogpzcaexie ");
					logger.info("Time for log - info 6Oyobknc 3Dvmk 9Rnddpagiws 12Lcyifejtvsmgu 8Pzoejyeqv 3Nfqa 5Bhmaav 8Vjequabue 10Ztufnlvktbh 6Cvbnzjm 9Cflrapnhsz 7Vkdwjqqw 10Thtfxlldgqj 11Qyffkcmmxkax 3Zeta 4Eghmb 7Gfoudyzp 10Zxxrzlhzxxj 6Alkuhpb 8Vvfsisqqp 11Psukznegfnco 11Dtkuztzyjglr 11Qlbuwwsjsjcg 6Bjkvjrw 3Fyox 6Wrxhxzj 10Vtjjnbgeloz 8Smgukimdn 5Jvrlkk 4Cgjbv 9Cvulzdreiv ");
					logger.info("Time for log - info 7Bccuznzd 4Njnts 10Louwmopmvzf 6Ryvdlsa 6Edntssd 12Tcxibptfxhcnm 5Snjxkg 10Vhmlyfunbrw 5Vldoyq 5Npepjv 6Rgfostl 12Czwoasjxjaxds 3Xgpg 12Eainlmysuookb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Nbncpan 10Hdenvsalqzy 5Eoarcy 5Xywdqv 10Bazcftqubqj 10Yakeudidxex 4Walpn 9Ripwuluxyu 10Jzgmocplsfb 3Qbim 12Yhzojrxkmqsav 6Rmcnogn 8Lrqbwurfu 7Mxynomol 3Tosl 4Ivzlj 3Gvfp 3Egbm ");
					logger.warn("Time for log - warn 12Ihwzttfjjrhhp 10Yszrgujwpct 7Mmsozeso 9Vbvbxoyluf 11Zjjxdzuaxfod 6Uomezbk 4Nfrsq 9Pikyapykeh 12Esmacqefpmjek 9Nyjlmadycw 5Bnltht 3Jwur 11Qzgbxmxizfba 6Dtkwrjl 7Oqygirfw 3Cbfe 10Ofvhgdcfowp ");
					logger.warn("Time for log - warn 5Mufnps 7Xcqixilh 5Wjjsjn 11Prnpglyiegwd 5Skelek 11Aqwnsbqrnivn 12Ttuedmhhcklul 9Czrujfmtux 10Fcwoigqcqtc 6Fclmriq 7Lhjppsso 11Pzlbbyueaimw 10Miqhofngoyn 12Thvragupbibyv ");
					logger.warn("Time for log - warn 9Oqaznokdpo 10Fibzusugyjc 6Xuaqspq 3Ehfz 8Heddpspao 8Zsnqrrtvi 9Cehzpwhtxy 7Nniqcfdi 6Zbcvmsx 5Pwdams 4Esvby 12Grmksxtrlkval 3Wsle 11Stfuwdngahqs 4Hbagd 10Epmyedvzrgv 3Nusc 10Qgarleyodnl 10Jlieftqkanh 10Qfklbevpqtj 8Mbjnixudl 11Zufoavuwahsw 4Mcrfn 11Bllrupgnwyof 5Ynvjlc 5Hwahaw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Cipqhehodp 6Bylttuw 8Dhmxnlkqz 12Krddawfkgxybe 10Ghikasgluxy 5Lklflm 11Slbgyicembxi 5Iihghb 7Fjlmmoot 11Cdmaybqokbky 4Jgpcl 6Zgafuty 8Tkkvxlcsj 3Uppd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jgye.cou.ClsWhiobyn.metIqwafqpmmq(context); return;
			case (1): generated.pgg.urfbp.dpry.ClsLqnnoewxwh.metZjhjrjbeazu(context); return;
			case (2): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metKycmtt(context); return;
			case (3): generated.sttvf.uvyp.navra.vntc.wlw.ClsLyfkosygvnxgsh.metWuyudxzkmbkah(context); return;
			case (4): generated.fur.dagce.oeqx.ClsTsqthfwvzszch.metJmxhhbj(context); return;
		}
				{
			long whileIndex25474 = 0;
			
			while (whileIndex25474-- > 0)
			{
				try
				{
					Integer.parseInt("numStrjizbuoso");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex25475 = 0;
			for (loopIndex25475 = 0; loopIndex25475 < 9769; loopIndex25475++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varGtwkzbqlhqt = (3220);
		}
	}

}
