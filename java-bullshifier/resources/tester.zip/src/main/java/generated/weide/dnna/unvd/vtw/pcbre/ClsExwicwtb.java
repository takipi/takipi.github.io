package generated.weide.dnna.unvd.vtw.pcbre;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsExwicwtb
{
	 public static final int classId = 297;
	 static final Logger logger = LoggerFactory.getLogger(ClsExwicwtb.class);

	public static void metGhpnegncduu(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[9];
		List<Object> valJshriucwvst = new LinkedList<Object>();
		Set<Object> valBurashotbla = new HashSet<Object>();
		String valAobugpuknrr = "StrFncotuwlpmn";
		
		valBurashotbla.add(valAobugpuknrr);
		
		valJshriucwvst.add(valBurashotbla);
		
		    root[0] = valJshriucwvst;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Vgcsoigrhsur 5Eetufp 3Qwgx 4Rgpjg 5Vdnzpv 3Chxl 9Obyqbiwkyi 4Vuxmp 10Lpjrirmpkvc 7Cbqysbxm 9Twxjxkkbsb 12Hddeakhpswhdd 11Chrvxgbqokmi 6Lcrbvuq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Hntorsmgrmr 4Wmgpd 7Vasbmhqe 4Bgzuf 3Bhft ");
					logger.warn("Time for log - warn 8Phnlqbdaz 12Lgwptyprsfocl 9Tuadddxxqr 8Bebmthffr 4Jmcwe 12Lkgwgxjbplfmi 11Xeugejibfskf 3Thgm 3Lnla 8Nlezrtkcb 6Zteucpr 6Rgcyhhm 5Uyuomz 3Avwb 4Kxkcl 9Qakcqscyyj 9Mfolrqbbku 7Tjpaalni 11Nofivhlrzckc 6Yifrsws 3Qehu 5Kylzbx 6Pleueat 4Kszix 6Pqcpkch ");
					logger.warn("Time for log - warn 10Otetlzzmlzt 6Scrbmzr 5Zkomdo 5Lzpvdf 4Xeeyg 11Gxsegfobwtzf 10Hlkrnnfduso 9Kkqjyvgehs 12Zihaofawanaxi 12Tvnzvuwhwsqdl ");
					logger.warn("Time for log - warn 7Tfyocuvb 11Prgmidigsedh 6Ztlqwvo 8Lyhueltof 8Rhwzqiaci 7Ieajifqo 3Gvlr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Zlqsijxsh 9Kakbkdvurz 12Oaeprzzibnmla ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdupg.slw.vpest.ClsBfbtvkikd.metGyqtk(context); return;
			case (1): generated.awuu.yuf.ClsCvioceqcbkiz.metCmrtwohtptwpox(context); return;
			case (2): generated.aisq.ykt.yfxh.ClsRqviupmemczv.metQirovjexgq(context); return;
			case (3): generated.mtq.flhse.ygibh.yfs.ClsSzzuamch.metIuxgxgafdnqnhh(context); return;
			case (4): generated.tcpo.xhov.ClsRfokukcdi.metFyxdxe(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirEemnvbaohrf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metHqnibperro(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valLvwyyeeetpm = new HashSet<Object>();
		Set<Object> valNfqpzxxaric = new HashSet<Object>();
		boolean valFxcdkpujrtl = true;
		
		valNfqpzxxaric.add(valFxcdkpujrtl);
		String valBmhchewsmsq = "StrLqsalfcqdez";
		
		valNfqpzxxaric.add(valBmhchewsmsq);
		
		valLvwyyeeetpm.add(valNfqpzxxaric);
		
		root.add(valLvwyyeeetpm);
		List<Object> valLpotjricybz = new LinkedList<Object>();
		List<Object> valAjpvjmeqgac = new LinkedList<Object>();
		long valHkcrgdtevqe = -7829761991657483009L;
		
		valAjpvjmeqgac.add(valHkcrgdtevqe);
		String valEwdyurwkfwb = "StrNupyccmdkfp";
		
		valAjpvjmeqgac.add(valEwdyurwkfwb);
		
		valLpotjricybz.add(valAjpvjmeqgac);
		
		root.add(valLpotjricybz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Rmbquyopcm 8Twkdvbauu 3Myhk 4Odyod 6Mkbtgsv 11Dsshnoeteqel 6Rfbqzdg 4Twzbr 4Atupd 12Sdatrpsjlunel 5Zcldat 9Ldcscjgiwt 8Jdmnpilqc 12Cxoerkpfxoirk 8Zcewvvvqa 9Zkthypehiv 11Xedmrdzpiejs 4Xyoau 5Rednmk 5Wfuxts 7Whityjsl 8Vypejpyjk 7Hlsuwrij 4Jarie 8Tljdnbizo 6Fxhlxes 8Vgrjrlgoj ");
					logger.info("Time for log - info 12Nocqwehkmuaiz 8Wtymaxcuf 12Rhjdybeqobomu 4Pzwwg 6Agrqvnu 7Rlwxgqxb 5Sbuigt 6Mqhfogb 7Tbvnsjqa 5Cmepik 11Eftscghmaati 4Qlcar 11Lorujwsgpfik 7Atquvjlx 8Ayrbvtquq 3Zpor 6Uxktgee 5Xdlewy 4Zmpzv 7Elwbvavs 4Iywix 3Icxq 6Sbfsksc 10Yponvjwyhxr 3Rvbu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Kzmzmijnls 7Inkvgqwj 5Rrskyw 7Yybrhqcv 6Oeygufz 12Bsbdsjkdijeab 8Kadbkwdcj 6Bqcbcul 7Vcqljqwt 7Gvqqpfit 6Cnpacxw 4Xtpgn 11Mntrchiemqba 8Jrklrchuv 11Typdsjbqwbbv 3Pppm 10Ricwlxborqo 11Lanvzgfldiws 3Rdmm 9Xyykjfeqon 9Mbhwcloeio ");
					logger.warn("Time for log - warn 8Nqufortpr 5Ybgnaf 6Rnoyzbc 8Dyboafxww 10Ufneeqpvjmo 10Hzvmluazzrk 12Ftegufpdzbflg 9Omoycuhqjt 5Kvbrnb 9Gicurvszsu 6Nfmigov 4Pwpiv 9Dcmqusaqil 6Gurvqsj 5Mxyvzn 12Pvsfrtqjlhuur 4Erimq 6Qokfrvl 10Vpxfofiwpoo 10Kyitzphfbne 12Xwutvarmrtvjq 4Pgysc 7Pnwmfayq 10Vwogzlkemnk 9Codfaxrbet ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.sttvf.uvyp.navra.vntc.wlw.ClsLyfkosygvnxgsh.metWdbuefks(context); return;
			case (1): generated.kyd.fxg.ClsVvcevjvyz.metAvlkamwowqupb(context); return;
			case (2): generated.abpq.uqd.wdeqd.mcta.ClsWlrvlsbwwa.metRclnhtyvwiwwcq(context); return;
			case (3): generated.obwsb.fweao.vluj.ClsLnkmgpfh.metNbeuqlcmickmxa(context); return;
			case (4): generated.wrwx.jsm.hgij.abg.imgx.ClsRhzgz.metLbqpyboy(context); return;
		}
				{
			long whileIndex25075 = 0;
			
			while (whileIndex25075-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirWcquvhvwqwb/dirTdipguyrfev");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex25080)
			{
			}
			
		}
	}


	public static void metBepkcxgkgvlun(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValLpgvjgvmrrr = new HashMap();
		Map<Object, Object> mapValZqkrggumybo = new HashMap();
		String mapValOqsdefqrolv = "StrOesypcpwofq";
		
		String mapKeyWzhjptvlsjm = "StrXyagfugirwh";
		
		mapValZqkrggumybo.put("mapValOqsdefqrolv","mapKeyWzhjptvlsjm" );
		
		Map<Object, Object> mapKeyMoahbhieecu = new HashMap();
		int mapValLtdhifnpmyg = 15;
		
		long mapKeyHyuemusvplb = 7782837265657833016L;
		
		mapKeyMoahbhieecu.put("mapValLtdhifnpmyg","mapKeyHyuemusvplb" );
		
		mapValLpgvjgvmrrr.put("mapValZqkrggumybo","mapKeyMoahbhieecu" );
		
		Map<Object, Object> mapKeySmjyudrzkrr = new HashMap();
		List<Object> mapValVgszmkqstjw = new LinkedList<Object>();
		int valIktqeenmcwv = 670;
		
		mapValVgszmkqstjw.add(valIktqeenmcwv);
		
		Object[] mapKeyIcyiraqsrou = new Object[9];
		long valOncyiptijvx = -7269329734570359908L;
		
		    mapKeyIcyiraqsrou[0] = valOncyiptijvx;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyIcyiraqsrou[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeySmjyudrzkrr.put("mapValVgszmkqstjw","mapKeyIcyiraqsrou" );
		
		root.put("mapValLpgvjgvmrrr","mapKeySmjyudrzkrr" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wwbmr.iqko.nht.ClsCnzakidxmh.metYvzavpzpnbo(context); return;
			case (1): generated.flwv.kjeus.ClsAhjobcsyb.metWdbwrxqdjbtpud(context); return;
			case (2): generated.mebcr.ggzz.ClsIauvxr.metDhujie(context); return;
			case (3): generated.plye.kjczy.bmku.wrxrk.zek.ClsNtetu.metAmeedefvfwaa(context); return;
			case (4): generated.zadtu.owlhb.qsd.bfzb.ClsWgiwrqnvyw.metJmapoligglq(context); return;
		}
				{
		}
	}

}
