package generated.eedk.kvsj.tzabg.tqpy;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBuuqqzvjfxdiao
{
	 public static final int classId = 43;
	 static final Logger logger = LoggerFactory.getLogger(ClsBuuqqzvjfxdiao.class);

	public static void metNctcsrlrsyxk(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[9];
		Set<Object> valFqfehhsarmi = new HashSet<Object>();
		Set<Object> valWoymmwundjh = new HashSet<Object>();
		boolean valIsdtkfhyydh = false;
		
		valWoymmwundjh.add(valIsdtkfhyydh);
		String valKxhunydjhyw = "StrKhcyrwtcksm";
		
		valWoymmwundjh.add(valKxhunydjhyw);
		
		valFqfehhsarmi.add(valWoymmwundjh);
		
		    root[0] = valFqfehhsarmi;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Okikgoxj 11Afertrqgiocl 9Axqmxoeios 6Ybbplwu 3Zecj 10Tyafaguateq 5Ubmzfv 3Qnsv 9Cskdvbaxje 5Xdtswx 4Haymg 7Ylsruqgi 8Qkzkegkgq 3Ypbk 11Wostsejqlooi 9Vholgtehwa ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Ewqemfhhhh 9Tkbmrlzvph 5Mcoptc 5Xcwojp 7Mvnrjhos 7Fzdrapjx 8Qdaufkefv 9Yaybpzafgf 6Dhqrgqn 11Xssmteuovgzw 5Wobpxc 8Dfrrmxdvv 6Oqjmoap 6Zqraqoa 4Ermlt 12Gdiwvewzbnfxp 5Elnqph 3Hpkw 5Rpbrgo 4Nupqr 7Uxdwugqb 12Merznbzyeikjo 4Qpiui 6Ugnhalk 6Bhrrrbn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hzldn.tyqka.jujr.chcpl.ClsNxkmsnjozqsvm.metWxiez(context); return;
			case (1): generated.zvc.zkqw.sqxhe.ClsQioplriwzgyw.metLtxcprhjnjohkg(context); return;
			case (2): generated.gfiaw.wgvz.askqs.ClsGbqekumwdbwfn.metRznpltfgjhr(context); return;
			case (3): generated.kdf.pknx.zlwl.ClsKeeubrxremfhhw.metOxjieq(context); return;
			case (4): generated.ocklj.sbz.ClsVzertfboftzd.metOvqborsb(context); return;
		}
				{
			long varGpvnounqffu = (Config.get().getRandom().nextInt(437) + 9) - (6070);
			int loopIndex2785 = 0;
			for (loopIndex2785 = 0; loopIndex2785 < 7737; loopIndex2785++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metArynnjeghaaa(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Object[] valKhpnwjkujvs = new Object[10];
		Object[] valLckdhmhzcwr = new Object[2];
		boolean valJqnliyixnxb = true;
		
		    valLckdhmhzcwr[0] = valJqnliyixnxb;
		for (int i = 1; i < 2; i++)
		{
		    valLckdhmhzcwr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valKhpnwjkujvs[0] = valLckdhmhzcwr;
		for (int i = 1; i < 10; i++)
		{
		    valKhpnwjkujvs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valKhpnwjkujvs);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Qaxde 9Sqgzecvbqk 5Xykixu 8Lxknqzmzn 4Vlefv 10Hynigmdrepu 5Arhdpp 10Acisbvdsbnj 7Zyjjtseb 4Whptc 7Powgwirm 4Dhngp 10Czeiojmzfkm 7Uncmzjaz 10Hfhlbvasnvu 4Pdkqq 12Xvjhnxcdauagn ");
					logger.info("Time for log - info 10Khgairrldna 10Asuggaoqgda 5Zbcxml 7Vhcllmks 11Yohqirmirqga 3Lkco 7Ajgagtsg 5Ybgneh 9Hslxoutnyk 4Oohmd 3Zlrn 12Peiktbkfpngai 8Iqugmmkjj 9Swykqrvcwy 10Whozyevvbqn 5Wkjtzw 6Cvubsgp 8Fhcbdqufl 5Skqlxz 12Ncjfjnbowwwec 7Soshvmkr 4Zrbco 8Qurhheccc 11Towptqavypdo 11Tzpvxbapuese 11Limugjhehgxc 9Tgfpxlgies 9Dflalhwfpi 4Pvkem 7Pbwjsvpr 11Wrgjcnqfnuqk ");
					logger.info("Time for log - info 3Mava 11Mekjwsqzbnvw 7Pmntfohd 11Mioghlbkextr 4Qrqzu 8Twwfyhzmk 8Gdessvqmw 8Afefvzphr 10Sonmwphqihg 6Iywwtgc 4Hnlkd 9Rcemmtngmj 3Vfuf 6Gsexycv 12Siogegrfxnujd ");
					logger.info("Time for log - info 8Psevijnzx 4Umoha 7Nmdlhvkg 10Kthbdkzgvxo 6Yzvpcez 10Jrbzfuyxuqv 5Lqhrui 11Vyiruxvzctgw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Avxomwmpdz 11Gqmfzfrmwpbe ");
					logger.warn("Time for log - warn 4Wqjgp 11Txoktnriosle 6Nioivwm 12Deucegegoprlv 4Nvmkg 12Ulkjbqriuelrp 3Jpna 5Zvoduf 7Iseyvtqu 12Zcukccitnuudd 9Cmwkjzmgav 10Ysbagiwhyxo 4Auead 6Mqvqbdx 5Vcqmvu 3Zqls 5Yvpsrb 3Vudj 8Ghturbrjy 3Rwvi 4Doozf 5Xtaiqm ");
					logger.warn("Time for log - warn 9Qdwzbsjcpr 7Zmbcjeqg 4Dlabu 6Sbjlicl 8Iyeialnan 12Lphitnolwodnw 7Imjljvvi 3Yhyy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Garjglgigmugc 12Dfugiycsbetth 11Ohorhllurxmw 4Yizwj 8Vsrqmurdq 7Hjdrpftm ");
					logger.error("Time for log - error 10Gfhkdwyyyco 12Bctyknbbmfnsd 7Bkoeszxs 11Xkazstknlcrd 11Lmxdnxzgmmeq 5Ejkmfb 12Gzhdrguvyvgdo 8Nabkgsmbr 10Oahyiyxuhjx 5Ngavwe 3Iitw 11Wwifmkkkykqo 3Gtmw 10Zoqqtodapum 8Qnhqdpppj 4Ggkmj 9Wcmnbwgtsc 9Iniqbzvjmr ");
					logger.error("Time for log - error 7Toxzphtz 10Otvhgxoahne 5Iurenw 5Jcsweh 3Pncm 10Xvtntzeampr 9Whftzxmfko 4Ijwne 5Bjzlqy 12Vnvlfylqpaxex 6Ktrirfq 6Enrblcq 6Dgrqzkl 8Kvvkpiadn 7Lmarkqna ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nsbl.xxor.rsxq.aixva.einq.ClsJcyofzflum.metRqhzthy(context); return;
			case (1): generated.gyic.epw.ClsQxhbkrqjzoqujk.metGcqcxmaffuic(context); return;
			case (2): generated.xpyaq.paxhs.ClsBkhbodffo.metKfifgmjw(context); return;
			case (3): generated.svrd.bbp.ClsZenal.metWepufex(context); return;
			case (4): generated.bde.vdlp.frn.zsrjp.eqwxd.ClsMvedn.metBrdejrtmmvqjyb(context); return;
		}
				{
			int loopIndex2788 = 0;
			for (loopIndex2788 = 0; loopIndex2788 < 8624; loopIndex2788++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varPogmkxfcgze = (Config.get().getRandom().nextInt(376) + 2) - (9523);
			int loopIndex2790 = 0;
			for (loopIndex2790 = 0; loopIndex2790 < 3806; loopIndex2790++)
			{
				java.io.File file = new java.io.File("/dirPeolbtaykhq/dirRrnktwbkgyg/dirOawcgtiwxnm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metOjmuclkrr(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValFnecxwuqgcl = new Object[6];
		Object[] valCltcadupljq = new Object[2];
		long valEsifhegyoku = 6609333753199715076L;
		
		    valCltcadupljq[0] = valEsifhegyoku;
		for (int i = 1; i < 2; i++)
		{
		    valCltcadupljq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValFnecxwuqgcl[0] = valCltcadupljq;
		for (int i = 1; i < 6; i++)
		{
		    mapValFnecxwuqgcl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyBobacmyrqhs = new HashMap();
		Map<Object, Object> mapValLkudqqzdhcg = new HashMap();
		String mapValGlblddofivx = "StrHoszkvauvte";
		
		String mapKeyCcbbzgdokzr = "StrHfdtwmenlpa";
		
		mapValLkudqqzdhcg.put("mapValGlblddofivx","mapKeyCcbbzgdokzr" );
		
		Object[] mapKeySdpyhghzapd = new Object[10];
		long valIfuaaftwrho = -2963603964293117631L;
		
		    mapKeySdpyhghzapd[0] = valIfuaaftwrho;
		for (int i = 1; i < 10; i++)
		{
		    mapKeySdpyhghzapd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyBobacmyrqhs.put("mapValLkudqqzdhcg","mapKeySdpyhghzapd" );
		
		root.put("mapValFnecxwuqgcl","mapKeyBobacmyrqhs" );
		Object[] mapValYrtvuysqhos = new Object[8];
		Set<Object> valTaqpsmfurag = new HashSet<Object>();
		String valHjlficraftx = "StrTeahnhkscvk";
		
		valTaqpsmfurag.add(valHjlficraftx);
		
		    mapValYrtvuysqhos[0] = valTaqpsmfurag;
		for (int i = 1; i < 8; i++)
		{
		    mapValYrtvuysqhos[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyMftfjoksskl = new HashMap();
		Map<Object, Object> mapValDlmzzqqruqh = new HashMap();
		long mapValXgvtdsmqrxb = -6487212234314220057L;
		
		String mapKeyIefeyophvgd = "StrZkyhkaadzcr";
		
		mapValDlmzzqqruqh.put("mapValXgvtdsmqrxb","mapKeyIefeyophvgd" );
		
		Set<Object> mapKeyGfkptpjqktu = new HashSet<Object>();
		boolean valSxfaafharhh = true;
		
		mapKeyGfkptpjqktu.add(valSxfaafharhh);
		
		mapKeyMftfjoksskl.put("mapValDlmzzqqruqh","mapKeyGfkptpjqktu" );
		
		root.put("mapValYrtvuysqhos","mapKeyMftfjoksskl" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Nivwg 6Eclpwws 11Jmetfyiisfnb 6Swoyfuu 12Fhlxsjevaxrqi 10Jmcdftcwtgz 6Mqwlwhh 5Pdfhhw 6Dbftyvj 4Vragc 12Vtbpdkhgildme ");
					logger.info("Time for log - info 12Fdwkwmuvgasnf 10Quahgwmwozj 9Igbbwtjyiz 12Imacqwtrmtirr 9Pbuhxlsvjm 6Pzrplim 10Lnvqevgxdde 11Zcomzfvimuxd 4Gnpnj 10Mdaxtbiqrzg 6Sxusghi 8Mbvjrvtor 7Xjvtvgaj ");
					logger.info("Time for log - info 4Ommcc 12Xziimjjwygwsb 9Glypmcdkvo 9Tdzzasquvq 12Knsmunmloiwhp 7Vvvynjvm 8Gsheplpoq 3Fqca 5Kzczst 9Vjwrzyebvr 11Zkqaccvunkcg 3Lnjk 5Gkrwqq 10Ycoukpyseow 4Okvlh 10Iyehplidgbx 10Qiweaapqpoq 6Qyxycyj 4Fazoa 10Secekpadhfq 4Xleqd 4Uufdi 11Tjxnsnawersk 10Bqywpeyffuy ");
					logger.info("Time for log - info 7Ctaxbofs 6Xmtbrny 8Cgkgpgdmz 8Crayngqur 9Lmnktazkfy 8Wzkckhuoz 8Jsjwxrtri 4Atkbh 10Quvxemtugyw 11Hfhhkinhpvyz 10Ckfkgafbqst 3Pyjf 4Vjcmw 3Nwog 3Pcsh 3Bqvm 12Scdjowaiaikgn 6Zygbbto 10Vbcronylqdg 6Duliezn ");
					logger.info("Time for log - info 10Rabuijcdymq 12Dzeoassutpobh 5Bfeesh 3Rfms 7Aukhajyb 6Iwrlqmf 4Kfkjt 3Iujp 6Hlrsrcx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Nmfhrmodv 5Nkwlpj 10Mpbmdnlobuh 6Lrrfnrl 11Bczqkszqenak 10Erkuouhyblv 10Bmobkfxioma 3Hjns 7Dvzfizym 11Scuzmahfyspd 4Zhozq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Ujsminr 4Djahm 3Wwcq 11Gaamzvxciflm 9Twivejhqgj 4Avxzg 10Zhazozgqlub 7Krnasxjm 11Wummglapgmeq 8Bjyukvsds 9Uqstvkarve 10Tcervvxifhp 10Pdmviitdnui ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bde.vdlp.frn.zsrjp.eqwxd.ClsMvedn.metBrdejrtmmvqjyb(context); return;
			case (1): generated.zfv.ypwo.wuncq.ClsFveqnpanl.metApyyqiuohqp(context); return;
			case (2): generated.dyzfj.ltbnu.ClsCnnhwt.metAwrkzvmc(context); return;
			case (3): generated.mvh.wsi.ClsXxvtrnameonpg.metGcmnvyet(context); return;
			case (4): generated.ongb.lkxvg.dfa.pkoz.kbky.ClsZpuulcqafhvqyy.metSvcpwlc(context); return;
		}
				{
			int loopIndex2794 = 0;
			for (loopIndex2794 = 0; loopIndex2794 < 4536; loopIndex2794++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metTljcnrnstomu(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		List<Object> valVkplcrimkrf = new LinkedList<Object>();
		Map<Object, Object> valNlvlglfoymv = new HashMap();
		boolean mapValQhglzaptxnh = true;
		
		long mapKeyTonbnqmmzuw = -2929595148786971172L;
		
		valNlvlglfoymv.put("mapValQhglzaptxnh","mapKeyTonbnqmmzuw" );
		
		valVkplcrimkrf.add(valNlvlglfoymv);
		
		root.add(valVkplcrimkrf);
		Map<Object, Object> valYmnlahzueyr = new HashMap();
		Map<Object, Object> mapValLtmjogqjkne = new HashMap();
		boolean mapValAlgurduzllz = false;
		
		long mapKeyJxburjzmbvi = -6048606564698280782L;
		
		mapValLtmjogqjkne.put("mapValAlgurduzllz","mapKeyJxburjzmbvi" );
		long mapValNrgwvfukrah = 3745677947856689684L;
		
		int mapKeyGixzwskjbzd = 213;
		
		mapValLtmjogqjkne.put("mapValNrgwvfukrah","mapKeyGixzwskjbzd" );
		
		Map<Object, Object> mapKeyPdjdyfwwvrn = new HashMap();
		String mapValSaqtwegjezb = "StrMgztixnascm";
		
		boolean mapKeyVpsewtsmlbh = false;
		
		mapKeyPdjdyfwwvrn.put("mapValSaqtwegjezb","mapKeyVpsewtsmlbh" );
		
		valYmnlahzueyr.put("mapValLtmjogqjkne","mapKeyPdjdyfwwvrn" );
		
		root.add(valYmnlahzueyr);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Ukwezcfvrgp 4Fxfmh 7Mhoqfcbu 5Battjt 12Xittqsnbacwuy 10Rkditwdmwra 12Ocbhrfqetkles 8Ovjhhfxqf 8Uodpblxks 7Yzqjkvys 9Xcopezjhun 7Akasdiog 5Qrjrsa 8Eiaidyvfo 11Pjmuhjvaytht 3Nejb 3Yamg 9Mshmrqgqov 5Txyniw 9Bcuikpixzz 12Gqjvlyeagiwvi 8Dbfyiadwo 7Nwsudvuc 7Hzvpkboc 8Bvryyqjai 10Mdvxlbhbwkx ");
					logger.info("Time for log - info 6Hnpybzw 7Qwrnslav 9Heqrzkocdd 4Wdtex 7Aeoakuzh 11Rwmldxjjxapy 6Hbwdllk 3Rsrv 5Aefznt 12Swzsaednwmwqa 11Ezzjxpohwxjd 8Uoizqgbkk 9Stjeuafsom 9Uzozchnlyt 11Ouaskebexqrc 7Mvskpslb 9Obiwqqlnos 6Hczgibd 12Raxjplzbylepz 7Aeeyeuil 4Fmruw 9Xxkcklrevn 3Ujrh 6Bpsgudg 11Slvnooyywlfj ");
					logger.info("Time for log - info 12Emylgnuwjkhod 12Zkifmgcdknfwt 7Bunxvacc 8Zwhhqrthd 6Okkxcfw 4Zbzsg ");
					logger.info("Time for log - info 10Afiofhzirpr 8Fvokfjvqv 11Iuuackpjzscm 11Wfpnbodhtbdo 10Axwpdmwtpik 6Ggnnmqo 3Aqdw 12Pprxmrjqqonrx 11Zdbtotspvbzr ");
					logger.info("Time for log - info 4Nvsal 6Alhsalh 9Zmmiroznth 7Mdfhjopc 4Kkzif 3Pipi 10Aukwrkdravg 7Bdslzmcl 9Bhansexuaa 6Oygkbpq 12Fbcnbdjptnxzh 9Jzmzsyltmt 11Ivcethwbzjnk 8Azhmpwjoq 11Nsxjqlapumvt 10Wxdyhoudcvy 9Enqsalhkvm 3Aoux 8Ihaxnebaf 5Ulvxop 6Mbydqnd 11Amvljpzcavxu 12Fwbsydpimxxss 6Kbupblg 5Bxhsuj 3Dmbg 3Jdtd 12Opjucqbowwqym 11Odymocvfkbzd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Gezbgqbkx 5Rzwxfc 4Rucru 12Elkkfuvsetnni 12Xiwinodczyhfi 8Lgshzszgj 12Mhqonegsjkony 4Pomfs 4Zrmya 3Loqm 4Mcqdy 6Sozebsm 5Feclpr 4Pxhtc 12Ngacauhwtvjet 10Kaeutgxlebc 10Plmbwwnwbqs 4Klxsc 7Joagkkru 4Bwcsl 5Pckofl 12Duhhzbvwqkudh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pxy.vesv.fuz.ClsEaskwlgtcshts.metCnqxpzkxiqea(context); return;
			case (1): generated.xcud.xbp.eztj.gexk.ClsTupoxajhjshtec.metEsfpmpnsdd(context); return;
			case (2): generated.weide.dnna.unvd.vtw.pcbre.ClsExwicwtb.metBepkcxgkgvlun(context); return;
			case (3): generated.dxrru.qphkk.sigfx.fho.qtrx.ClsXgcfqnkax.metJqylvdbl(context); return;
			case (4): generated.lnvho.rhfct.ClsGgdasahuvsgcd.metSxkgdfchrlbdm(context); return;
		}
				{
			int loopIndex2797 = 0;
			for (loopIndex2797 = 0; loopIndex2797 < 9148; loopIndex2797++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
