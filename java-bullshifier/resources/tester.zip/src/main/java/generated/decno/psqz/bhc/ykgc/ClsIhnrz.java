package generated.decno.psqz.bhc.ykgc;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsIhnrz
{
	 public static final int classId = 142;
	 static final Logger logger = LoggerFactory.getLogger(ClsIhnrz.class);

	public static void metNfknyrmpq(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valEacruywjsbu = new Object[2];
		List<Object> valNhjgdgpszvh = new LinkedList<Object>();
		String valUdvxdqknlrt = "StrLrgznyudxah";
		
		valNhjgdgpszvh.add(valUdvxdqknlrt);
		int valMpcrjywzyjf = 619;
		
		valNhjgdgpszvh.add(valMpcrjywzyjf);
		
		    valEacruywjsbu[0] = valNhjgdgpszvh;
		for (int i = 1; i < 2; i++)
		{
		    valEacruywjsbu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valEacruywjsbu);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Abbg 5Arzsnr 9Khogwlcifv 5Mbzrni 10Kdsoyfeevrd 7Jpnzgouq ");
					logger.info("Time for log - info 4Uqehy 10Xaktvpbhnhp 3Waqf 9Fusywzqpps 12Bbvthenrsobbu 5Fgkbok 7Rsitibex 5Thtuzv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Ppsnbbkn 12Erefilzksadxe 8Durpwlvtj 11Gnfnpmpotrkc 8Ugalxmltm 12Merbbkgshimef 12Yzttapakpdizg 8Lymhoqcwj 8Eiksyrqvn 5Tlkkih 5Ysqtlh 8Voqqrkyjh 3Hssz 11Jgegsfxvzlkc 9Kyoipamjei 12Ewkqicfxoldoa 3Hkwn 12Cychmcnlcwxqv 3Sgtg 3Bwqk 10Jschswzlsim 6Mfefesy 11Kdnseyrwqteq 10Fevodfltzxq 11Byxkpbfzprku ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ncx.nab.ijte.fihzp.ClsYfnojfmzyj.metDgypcmpwyxb(context); return;
			case (1): generated.wspiu.cmqv.pvdxy.isdgi.ljwn.ClsZpnvzubxm.metVqngzt(context); return;
			case (2): generated.vspck.scvf.gxvmo.ClsBudbedmvgnjpa.metRtbqqjsh(context); return;
			case (3): generated.rorl.wuo.lqgdf.ClsUltodfmiuq.metQslafqderta(context); return;
			case (4): generated.opb.bkhm.vos.ClsExbhmceyku.metWznsfybdfmiist(context); return;
		}
				{
			long varBomzyzqydck = (6226) - (548);
			long varFnvljctnmpm = (Config.get().getRandom().nextInt(666) + 4) * (Config.get().getRandom().nextInt(939) + 5);
			long varClliogpfwhg = (Config.get().getRandom().nextInt(673) + 4) + (3147);
		}
	}


	public static void metWxnztwbdh(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valDenbhrlxmes = new Object[9];
		Set<Object> valVrsvoekxwoo = new HashSet<Object>();
		long valTrpohqbvimc = 991753188313097189L;
		
		valVrsvoekxwoo.add(valTrpohqbvimc);
		String valYrgitpklydc = "StrIjcdvzshffr";
		
		valVrsvoekxwoo.add(valYrgitpklydc);
		
		    valDenbhrlxmes[0] = valVrsvoekxwoo;
		for (int i = 1; i < 9; i++)
		{
		    valDenbhrlxmes[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valDenbhrlxmes);
		List<Object> valUlbkhtssack = new LinkedList<Object>();
		Map<Object, Object> valXjjabwnrqoa = new HashMap();
		int mapValDhoqqhawyxh = 29;
		
		int mapKeyKkfcxwbrsqz = 697;
		
		valXjjabwnrqoa.put("mapValDhoqqhawyxh","mapKeyKkfcxwbrsqz" );
		
		valUlbkhtssack.add(valXjjabwnrqoa);
		Object[] valMxvlbckzewi = new Object[7];
		int valKkqbgnjamae = 74;
		
		    valMxvlbckzewi[0] = valKkqbgnjamae;
		for (int i = 1; i < 7; i++)
		{
		    valMxvlbckzewi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valUlbkhtssack.add(valMxvlbckzewi);
		
		root.add(valUlbkhtssack);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Mxrmtwwrc 4Isnho 5Urhfqo 5Dwtvqp 12Lacqsdkoyzybn 6Yyhujbe 3Tuqk 12Euhbiunoomyuu 8Uglsgkhag 5Tnsnsi 6Wwfkfyu 6Fdwkjit 3Qfnk 6Xupzhjh 3Fjgl 5Cxkmaf 5Vyketa 9Brjairxcva 5Ygkdyt 10Tbspvpwxutr 11Kkrdvhdzntbi 6Pvxujwk 6Mrpjzxe 3Idpt 3Efgg 11Bgqqzvnywnsb 9Rjvosbswro 10Cqpllrorvvt ");
					logger.info("Time for log - info 11Thxogphgdufp 5Snsate 8Vgssjzsjw 3Inuo 8Lnfzzzplo 10Ecystzstadm 9Sttbcovpkh ");
					logger.info("Time for log - info 7Kazgcmxx 5Pjkwav 4Agfje 12Ygyghnsmqvpkx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Novzu 12Xfgzqhbljtdzn 10Bnujybqsggr 6Dqxjhsm 8Sgfijhxki 8Diuzafipi 10Lazrmopbnil 12Bfgfodfsbmthg 3Cami 12Iievjnjniixwb 5Avmeje ");
					logger.warn("Time for log - warn 5Krvvue 7Iepsvzel 5Tduwkf 11Mpiotmeblidz 5Rygrjz 10Slqnfvrqyfv 7Efxmtnzu 8Bkztrvzth 10Nfzsjezwyfh 3Vgrs 5Oudzpq 8Fdahtdpsi 5Acmoru 7Rmexmesa 8Zzmymojry 8Hyrqydbbb 11Homsmmdzbqpa 4Zgiyw 8Puuoneqsd ");
					logger.warn("Time for log - warn 9Uvnuhkcpws 10Tnamcnrbffd 3Ygzk 9Rzewjbbznh 12Leqehluklmdyq 3Yeev 12Rcrcevwxchkah 10Tkuocyzguij 3Gzwn 8Ehojvrghp 10Iytdrbndxcx 4Wyrjf 10Xaohodsednn 4Lnwvk 3Yrdo 12Wiitipjrqfekk 10Kcveokmbhbg 4Wsyuj 11Veggatatyzqw 7Wjdmeygw 5Rjevvq 11Arplyfkrmrvn 8Xhdphrbkr 6Jeohdzb 6Tsxeonr 5Smhexx 6Tuwroou 8Qphmvwuld 7Ygnlygpr 11Jfonibsweaih 5Lquwjj ");
					logger.warn("Time for log - warn 4Sgwpz 7Jbjxqerc 9Ufexzwzeef 11Mtqpjjcpoual 5Dkdjnj 11Eojxfcyscofj 8Hszfyekbx 3Fugm 6Ixqekyd 7Sngbifkm 7Kpzuqmsw 8Ywjxbgxmn 3Kmmh 12Yrvhmiisagtgb 10Emsktcndyri 3Ecvy 5Sdcfnh 3Iflp ");
					logger.warn("Time for log - warn 9Owmwqbrtce 7Jvvszwsy 11Dqvbplrhkoch 6Uhydjvd 12Rmbbtfexqcykn 6Xaxxqsm 8Inlkqvtxa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Aqnfvxkp 6Bdpfmcj 7Djulbcaa 8Tprjozzcn 7Aihthexo 5Veyuzk 3Eumq 3Ptpt 11Nkeofcfrbwna 5Losdpa 4Xgjab 9Rehbxgsbfk 9Jpveafwxti 10Iyzwygxgumv 11Fbgssotounuz 12Yduwpgiwlfefk 12Nofdntwerujdz 4Vnlhq 7Jzqtyghj 4Wnyqh 12Zizpahtzjhdxf 5Fauxrz 4Sckvv 6Mtvswrx 10Lxbcivwggen 11Oxazizzjofso ");
					logger.error("Time for log - error 4Hcwip 12Bqmkovkamqtws 12Zkcxxzsgjwxrn 10Ywovvfghgmr 5Istwyc 7Gifknveu 7Xxgyxxjq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.afllp.gwt.xvrk.rxvp.rryr.ClsQsqze.metHxgvbl(context); return;
			case (1): generated.vyac.iqbj.guc.ClsYpwwsvx.metJtvstyrjix(context); return;
			case (2): generated.zdn.ayby.ClsMelkmphvwjkgwh.metAcvmturnoh(context); return;
			case (3): generated.rub.wtuur.cpewn.fdq.jektc.ClsLiscwkily.metFxfyfwekmvvpv(context); return;
			case (4): generated.wrwx.jsm.hgij.abg.imgx.ClsRhzgz.metLbqpyboy(context); return;
		}
				{
			if (((591) + (7621) % 867990) == 0)
			{
				java.io.File file = new java.io.File("/dirIlzhfpshqhu/dirWllhkwvnbto/dirXxoqxipgdvm/dirSzfyabcmqyn/dirXiqxprgmdml/dirIeqnwcpplxs/dirYhbyyggryli/dirBkuojtixlxt/dirWwtlwncoegm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varWztpqocghyp = (5161);
			long varMrutwlabewk = (4492);
		}
	}

}
