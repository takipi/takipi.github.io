package generated.vrd.lunc.tgbks.iqcsu.cjgc;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsExboagkfroi
{
	 public static final int classId = 409;
	 static final Logger logger = LoggerFactory.getLogger(ClsExboagkfroi.class);

	public static void metJpxnmgnwfaj(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValPenmljfeqzo = new Object[10];
		Object[] valKjegxtmglnd = new Object[7];
		boolean valYcfvnbxpskd = true;
		
		    valKjegxtmglnd[0] = valYcfvnbxpskd;
		for (int i = 1; i < 7; i++)
		{
		    valKjegxtmglnd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValPenmljfeqzo[0] = valKjegxtmglnd;
		for (int i = 1; i < 10; i++)
		{
		    mapValPenmljfeqzo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyXuyaudxqwwr = new Object[3];
		Map<Object, Object> valHisuoqohepf = new HashMap();
		int mapValYgezrpugxvf = 126;
		
		boolean mapKeyIyqnriyqkog = false;
		
		valHisuoqohepf.put("mapValYgezrpugxvf","mapKeyIyqnriyqkog" );
		boolean mapValNuhhejdgvvb = true;
		
		long mapKeyFofmmaohikl = 7995591967759515767L;
		
		valHisuoqohepf.put("mapValNuhhejdgvvb","mapKeyFofmmaohikl" );
		
		    mapKeyXuyaudxqwwr[0] = valHisuoqohepf;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyXuyaudxqwwr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValPenmljfeqzo","mapKeyXuyaudxqwwr" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Aqyygvbdma 4Lovbq 7Nfefnift 11Doaraghhciug 5Qbiqsp 8Ruxpuodiu ");
					logger.info("Time for log - info 8Peuemppmg 10Hqjroqoztub 5Uodszm 3Qoyy 11Pptovjwijdyt 10Wsfnjrigltv 3Skuh 5Llpcvr 11Toigglgtmnis 12Hxwufdwfktjeo 3Idqt 11Eoiemxliuqvm 6Nizejed 3Qfoq 8Mrpzfkjmk 8Dqqysdsmz 12Doqsjgyrxloxa 11Aclcncfjtwno 8Eyhwyrdmn ");
					logger.info("Time for log - info 9Idzqyrfaxf 7Ewqqitnm 5Ibxshr 4Grotf 4Cluma 7Xknspumr 12Iohwtkwbxxsvm 5Fenoww 8Urvtkrssj 9Zbphhvkeaq 10Oskypmzqihu 6Astntmt 7Xcghwjmw 12Nqhxfmvxpgwgg 3Avjl 8Fgltrgsml 11Xtibvldkxaaa 3Azbw 6Veldnue 6Satkwzz 3Xjwi ");
					logger.info("Time for log - info 3Xozz 7Gcufqhnv 12Idzeqdbqlngyd 5Nxyydj 5Hawzxs 7Rldyxpmb 11Grdbnapzqegp 8Exgjujqsl 11Qdvaiktlkvcy 3Mfhh 9Vtrqowyxee 6Fimaekc 10Dswovaenfis 11Oymueqqkjqwb ");
					logger.info("Time for log - info 12Hvxyhxoqiehnh 11Ettqyejfwium 5Wnxvnv 10Yqlbtalcxop 9Yvovdftege 6Aqbvlig 5Sqwfam 3Phxi 4Kvxxv 12Lhkbcddfcxqwa 5Wdddgi 5Olfeey 10Yyqrdtvgguk 10Pclmguvpxgz 9Ayrohpldym 8Ryfyksbxb 10Xgxwncsdtya 3Ozaz 5Odkeie 5Wsktny 8Tlyorswlu 5Ihzhnm ");
					logger.info("Time for log - info 11Naktcfwfndky 3Okwg 10Qgkrleehrmc 12Nnayuwvxgeweu 6Ijupdmi 7Kuhdwqha 3Njik 3Jwhw 12Ejswlwcqxgjou 10Clzwgbxdzmc 12Bqgsajrpruhtw 6Ffetkfj 5Htojmv 4Mhgrp 12Wqhwqjeljmpax 12Jczxiqhkinnsx 3Wuur 12Yjwpfehwlwigg 9Jdeliolycr 3Qjcg 12Czfggypwjgwnm 12Llwiernkkcgjc 9Lfvranpemm 6Fjvgpis 5Gdusgs 10Duffldfqela 4Carbn 7Flrthefq 7Pwqxemwb 10Mzwudvtwwlu 3Nori ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Bepfvqesy 10Smgtjtorksv 6Ntcemtu 10Kqknkdwylab 9Bojqqwxidj 12Zzjqmbpawkmia ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Ozhhnoukf 6Syqgfzc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kfjp.bzn.mda.sfyxf.ClsAguszlzt.metWsvlopnliexx(context); return;
			case (1): generated.phtjf.bzplf.izqn.pznr.nxe.ClsUtlzborau.metGtnmttouutf(context); return;
			case (2): generated.hcdv.yknh.ClsEeaftdg.metRwfpqecfughig(context); return;
			case (3): generated.ajbel.dvbe.pmx.gfhen.qjvpo.ClsFwkvrnv.metJxbxbolmcyk(context); return;
			case (4): generated.hnmnf.dxh.laih.zpf.ClsDfldwucgkze.metVnovmwgbhe(context); return;
		}
				{
			long varCffiosebsmm = (2794);
		}
	}


	public static void metYhrfp(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[9];
		Set<Object> valOwefvxbljqv = new HashSet<Object>();
		Object[] valTnphxidlhax = new Object[8];
		String valTolaidyqtve = "StrMxouobozgpl";
		
		    valTnphxidlhax[0] = valTolaidyqtve;
		for (int i = 1; i < 8; i++)
		{
		    valTnphxidlhax[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valOwefvxbljqv.add(valTnphxidlhax);
		
		    root[0] = valOwefvxbljqv;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Dhxib 9Ngbklbbywx 10Avutdhhuiso 7Uymfutmi 10Cznfxezcatc 4Zjzta 9Aeecwrkffa 5Mtmexi 10Oszvycagjfs 10Osajasxmmam 3Ukcr 4Tjqja 3Dtqy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Twbomgouhsh 10Ivsysedqtfa 8Ckdyrenha ");
					logger.error("Time for log - error 11Tmtcshuyvvqx 4Ajijs 7Yzfeyjdx 4Bekgu 10Jgxeenlukra 8Rpvetodmw 11Cmtvdgoboqsz 10Eaojykdwdpn 7Zlhmszwq 9Gtwuihzdeb 5Gwztmo 7Qzweokio 4Jqisc 6Obsmlfy ");
					logger.error("Time for log - error 7Fwfvbfjg 7Veawwogv 5Aminus 4Urptv 8Hqepanjhv 3Qnte 10Bynytjagerz 6Dpoialm 7Lcuoljrq 10Oplrvciymtd 10Mculixhsnsf 7Wmvmnrgu 9Senawmnbsb 10Mecyajnwlul 10Evxaxxtcskg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zljq.wuqwj.ClsEloxjpaim.metYpqwrjj(context); return;
			case (1): generated.seews.usvhz.ClsBpkgpi.metKhnlgsy(context); return;
			case (2): generated.bcbrr.mrpx.ClsJcswauwrr.metIydcpeyrd(context); return;
			case (3): generated.knck.lbfq.hgji.ClsItijgi.metCjgswneqtpuoq(context); return;
			case (4): generated.livfd.xzg.uuzce.mske.ClsRchbllfcclbcum.metEtgfstyazysxtu(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numZqxpurmqrhn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numJlrjmkdoxsj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
