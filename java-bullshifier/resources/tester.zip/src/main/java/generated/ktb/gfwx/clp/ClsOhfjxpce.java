package generated.ktb.gfwx.clp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsOhfjxpce
{
	 public static final int classId = 462;
	 static final Logger logger = LoggerFactory.getLogger(ClsOhfjxpce.class);

	public static void metBhcnwfttekmyi(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValBmmudyfnryb = new Object[4];
		Map<Object, Object> valMtolutirtaz = new HashMap();
		int mapValAbnilknxnhr = 430;
		
		String mapKeyQofrnjmxexk = "StrSivhpysjvkq";
		
		valMtolutirtaz.put("mapValAbnilknxnhr","mapKeyQofrnjmxexk" );
		
		    mapValBmmudyfnryb[0] = valMtolutirtaz;
		for (int i = 1; i < 4; i++)
		{
		    mapValBmmudyfnryb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyEzvcpeqyvpv = new HashSet<Object>();
		List<Object> valHfqvghgngqk = new LinkedList<Object>();
		String valZgywqcxhuyy = "StrWcnwhoiaoah";
		
		valHfqvghgngqk.add(valZgywqcxhuyy);
		long valGkrggcwxgum = 2756234435013377351L;
		
		valHfqvghgngqk.add(valGkrggcwxgum);
		
		mapKeyEzvcpeqyvpv.add(valHfqvghgngqk);
		
		root.put("mapValBmmudyfnryb","mapKeyEzvcpeqyvpv" );
		Set<Object> mapValLqfaubsqiox = new HashSet<Object>();
		Map<Object, Object> valLoxuytyabik = new HashMap();
		long mapValFdeaknampnl = -657464039683630729L;
		
		String mapKeyAetezxmxdva = "StrKhbbqyefskn";
		
		valLoxuytyabik.put("mapValFdeaknampnl","mapKeyAetezxmxdva" );
		
		mapValLqfaubsqiox.add(valLoxuytyabik);
		
		Map<Object, Object> mapKeyVrvdmtaakgc = new HashMap();
		Object[] mapValXqjqfrdvyns = new Object[8];
		String valKxbupchaygt = "StrJxnxvsxnyll";
		
		    mapValXqjqfrdvyns[0] = valKxbupchaygt;
		for (int i = 1; i < 8; i++)
		{
		    mapValXqjqfrdvyns[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyTzdvivgcieg = new LinkedList<Object>();
		String valRehwzkvatwa = "StrKkgapzrgebq";
		
		mapKeyTzdvivgcieg.add(valRehwzkvatwa);
		
		mapKeyVrvdmtaakgc.put("mapValXqjqfrdvyns","mapKeyTzdvivgcieg" );
		
		root.put("mapValLqfaubsqiox","mapKeyVrvdmtaakgc" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Ovwlvugmdqm 4Kcohz 11Npfjlrjnzvfc 3Tjsp 3Gqxn 10Gmtgqnvmjdm 6Vqmibix ");
					logger.info("Time for log - info 6Yofshld 12Buamudrrkzpvy 9Jgwignnjju 7Bzymomqu 9Ajwsfxwrel 3Bgdp 8Thbvdnkop 12Mbfufltygdyci 9Bzzqkvguhw 6Budeztz 3Fnbw 12Dfrbzqaedpsla 3Odpe 9Ytsgmeplrt 12Jwxzeagjqhwzb 4Boltq 9Jjubjzlkrc 3Eewp 8Sphglfnyi 7Tdtcnbfr 10Hfovmbdkleb 3Tjyy 11Pkwimzvvbkgw 7Xtfwtpzg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Pjnvirzoely 3Leug 6Qjhgsqw 9Qgwfuvpjcc 8Oljtjrxnb 3Fmiu 11Zxpbqlkggjcj 12Jcjexyhcnhdkg 6Oirmcmk 7Jhwkdrne 5Byumpm 9Hvvjkfldjl 12Rfzoghojhweia 11Hjjsyqdfdoet 7Dwdszvit 4Wyjls ");
					logger.warn("Time for log - warn 7Bywugcua 4Sgkjv 11Prnljmscoqks ");
					logger.warn("Time for log - warn 10Madzeeresxh 12Mevmjuidgwbtz 6Pahxfxs 8Npzcnmuij 3Iobn 8Xblpdzant ");
					logger.warn("Time for log - warn 6Faztgec 7Sfhhqzhm 3Sneh 3Ttyy 10Ckvktgkurvd 6Zoigkez 6Iwlevzr 11Gxgnniuqwhiq 3Aqza 3Nlug 8Clsmklkzv ");
					logger.warn("Time for log - warn 6Vtaagoh 6Qvkwibg 6Qrteezj 3Yxqm 9Wzsjjtnnfo 8Xpwxorqvy 11Piecngxhiady 4Wzfkv 9Jgdpdhpuuo 6Gpflxef 9Pyaltcvzuf 11Kgkncovskugb 7Brllvahq 12Fptdvhbbnfovh 12Xvoenysonzhso 5Eqvsin 8Vtcwuinbg 11Kftpuwpejewn 5Yhuyzq 9Pljkrfycpj 10Hsqgiswgahy 6Lnxrryg 12Eqnpnuvobincr 11Vjsmlflgbbjc 5Knakoa 4Tywuq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Coxkrgzxm 8Tbflplsec 3Yttp 10Vruewgfgzpb 9Ujpviwzvjy 11Ldykxyxrokxa 6Iijmgds 5Ndpdlu 5Ttaaaw 8Rghuyfssw 5Dbhcvi 12Sudfxmbiixoxa 8Fcvrpahdh 6Dvqktfa 12Jqcphrdqmlkzv 10Xgyptdizgib 9Verucydnez 10Hihehlqbwwv 10Gzxyrwvytbj 9Mgzcrqtwoi 3Ltny 5Mkwycm 5Gzfxgu 4Vddox 4Qdzfg ");
					logger.error("Time for log - error 4Zbvxb 3Rdss 4Rlxjh 4Auldw 11Hnqcuwbqbmgx 10Gfiolykvexe 12Iblmfutngaenc 3Mjcz 10Mptellwtyap 10Mqdyoweqfro 8Uimbolcnn 5Asexne ");
					logger.error("Time for log - error 7Jqkpdhsw 12Rtbhsuzczoejg 9Aygjrdbuan 4Vokkx 3Pchm 11Ahgmeeyrpfph 6Yhzepxl 8Jfhszmdja 7Battargv 12Zqnweneegwfgv 10Pxbyyhlfyko 5Drtsnk 9Jisqxnyydf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.weide.dnna.unvd.vtw.pcbre.ClsExwicwtb.metBepkcxgkgvlun(context); return;
			case (1): generated.weide.dnna.unvd.vtw.pcbre.ClsExwicwtb.metGhpnegncduu(context); return;
			case (2): generated.ifyrm.rwj.ajr.gkqyg.ClsSfeshwgdectgpm.metUdqxpeng(context); return;
			case (3): generated.dnnlu.krjt.bhw.ClsLntkclh.metGsqabraqx(context); return;
			case (4): generated.bkbep.bjvph.skry.qijli.gfl.ClsFlycqobnxjszt.metXjavkvvpbkkxo(context); return;
		}
				{
			long varUwbcwimftrl = (3057);
		}
	}

}
