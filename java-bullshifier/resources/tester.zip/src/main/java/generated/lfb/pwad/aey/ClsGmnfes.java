package generated.lfb.pwad.aey;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsGmnfes
{
	 public static final int classId = 107;
	 static final Logger logger = LoggerFactory.getLogger(ClsGmnfes.class);

	public static void metTraqetzdedskqj(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValBhfwdmrxxvy = new HashSet<Object>();
		Object[] valQbuanhojnsz = new Object[3];
		long valWqymtohmgkv = -7869074950891906430L;
		
		    valQbuanhojnsz[0] = valWqymtohmgkv;
		for (int i = 1; i < 3; i++)
		{
		    valQbuanhojnsz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValBhfwdmrxxvy.add(valQbuanhojnsz);
		
		List<Object> mapKeyNbxzwbfchxx = new LinkedList<Object>();
		Map<Object, Object> valIfffpcqabbu = new HashMap();
		int mapValWqvhuywgcmc = 79;
		
		boolean mapKeyDgmadpiqkod = true;
		
		valIfffpcqabbu.put("mapValWqvhuywgcmc","mapKeyDgmadpiqkod" );
		
		mapKeyNbxzwbfchxx.add(valIfffpcqabbu);
		Set<Object> valMypfvntusgx = new HashSet<Object>();
		int valSsuubkbjdkz = 146;
		
		valMypfvntusgx.add(valSsuubkbjdkz);
		
		mapKeyNbxzwbfchxx.add(valMypfvntusgx);
		
		root.put("mapValBhfwdmrxxvy","mapKeyNbxzwbfchxx" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Ekcl 6Xveyale 12Aovjioezehskb 7Acabbrfa 10Uehfljameuu 9Yekecqtssr 8Tugqvzccw 11Pyvhzfdhewqk 6Xjzsgfb 10Opjltmgnazs 12Bjdmjhwtkfyig 6Medzigf 10Vbhygazfthy 4Zxzxa 9Ydbtkvbbqn 10Kszlzixkxoo 6Zftmglh 7Xyuxmsdu 6Lmwuuxc 9Maygiwvcca 8Hxmiqqukr 7Sxwjelbc 10Ariiwfoismh 5Byrdxs 10Shgtrinxlsv 7Hvkukuaz 8Mqtpurgos ");
					logger.warn("Time for log - warn 9Fxyivdliec 9Fdletdbbul 3Maeg 8Kdgwimseh 12Fcmuqhmqqikzc ");
					logger.warn("Time for log - warn 3Vuej 12Ylydobumitwqs 4Cltnz 12Onciuslrbnict 6Cjfzxie 4Cxjhc 6Cajpmon 11Dmqrpxvxpnbg 5Kjgzti 4Hcoeu 8Vzzmsclwr 10Cfismgnrnni 12Wihylbwxchpat 7Ljuqtubg 5Xttibm 8Suenwwjvd 8Wlmlsclvp ");
					logger.warn("Time for log - warn 12Ksbolgkhxxoxk 5Ralsls 4Qxrse ");
					logger.warn("Time for log - warn 6Typjpix 3Nepk 7Slmzrerq 4Jiyxw 10Fenvqwhmfzk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Dulyrjdbrul 10Wrklgfeoslq 9Vjjglvurvf 6Igphfoc 10Ktsuyricutr 10Hncdrdwrjkv 9Depezakxfa 3Xikv 3Lgzu 8Aemwyqwka 3Snup 8Hupxkzhwt 8Fjbwdzxkx 7Otdtvtrp 9Dqpwdgnvca 4Iqots 11Qcuznblgifzj 11Yihpqhenxjnp 3Klii 7Hkzpljqk 9Snlhxottjw 4Yeymy ");
					logger.error("Time for log - error 7Lirnqpaq 9Ejyjpeclrn 6Yggvbwl 8Abgbeishv 4Serai 8Pccchlxqz 3Gogd 11Ojimmedrixqg 6Aasjqvy 11Ttouviedrctx 9Dramtewzie 11Dmmsrkpnxxef 9Xaliqtsaty 5Xechia 12Nacjczdlswikx 6Ubjihbo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gyic.epw.ClsQxhbkrqjzoqujk.metCxlwimqqzxfd(context); return;
			case (1): generated.gar.mdz.moh.znab.ymyxm.ClsZduvwawzb.metYcebrjtxrz(context); return;
			case (2): generated.krka.pbdp.kxfhk.gqt.tfv.ClsAdvwmtrn.metDvriulzpcrhbb(context); return;
			case (3): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metXtcge(context); return;
			case (4): generated.rxif.wckg.ncsqv.pmlox.ClsRkhayrnqgfzod.metYpvtqzicvr(context); return;
		}
				{
			long varFvjcfllfztu = (895) * (Config.get().getRandom().nextInt(177) + 2);
		}
	}


	public static void metRujsenpfl(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValQqertlrckvx = new LinkedList<Object>();
		List<Object> valQbsnrfvomxw = new LinkedList<Object>();
		String valGvmsvtevhsy = "StrUzgrdhkgfwt";
		
		valQbsnrfvomxw.add(valGvmsvtevhsy);
		
		mapValQqertlrckvx.add(valQbsnrfvomxw);
		
		List<Object> mapKeyNfpendxtnkv = new LinkedList<Object>();
		Set<Object> valElyddfpjlcn = new HashSet<Object>();
		long valXdkfnbktnjt = -6296651702099925987L;
		
		valElyddfpjlcn.add(valXdkfnbktnjt);
		
		mapKeyNfpendxtnkv.add(valElyddfpjlcn);
		
		root.put("mapValQqertlrckvx","mapKeyNfpendxtnkv" );
		Map<Object, Object> mapValYmvncskhqxc = new HashMap();
		Set<Object> mapValJtsqynvfjny = new HashSet<Object>();
		boolean valMmscvsvneak = false;
		
		mapValJtsqynvfjny.add(valMmscvsvneak);
		
		Set<Object> mapKeyOysjntshnqn = new HashSet<Object>();
		long valBkouorursqh = -198950012870404652L;
		
		mapKeyOysjntshnqn.add(valBkouorursqh);
		String valCiaterqsdde = "StrHnispbaobwh";
		
		mapKeyOysjntshnqn.add(valCiaterqsdde);
		
		mapValYmvncskhqxc.put("mapValJtsqynvfjny","mapKeyOysjntshnqn" );
		
		Set<Object> mapKeyWufgeudtnhj = new HashSet<Object>();
		List<Object> valZsepignjviq = new LinkedList<Object>();
		boolean valDpabwlmimpr = true;
		
		valZsepignjviq.add(valDpabwlmimpr);
		long valWedhqufddeb = 4061446436057852922L;
		
		valZsepignjviq.add(valWedhqufddeb);
		
		mapKeyWufgeudtnhj.add(valZsepignjviq);
		Object[] valKghfdbgywvp = new Object[5];
		boolean valQmoszobksfz = false;
		
		    valKghfdbgywvp[0] = valQmoszobksfz;
		for (int i = 1; i < 5; i++)
		{
		    valKghfdbgywvp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyWufgeudtnhj.add(valKghfdbgywvp);
		
		root.put("mapValYmvncskhqxc","mapKeyWufgeudtnhj" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Zavoy 8Suquqztkm ");
					logger.info("Time for log - info 11Qlqarkdvkhsu 8Byzppirjb 11Mczdtyxwnvdn 3Xgnx 4Tuobd 7Iwbzcmtd 6Ujlpxmr 4Cssef 7Degvnixk 10Vkoqjcelurw 4Gilao 11Wxwzylwnveqh 6Utbyeoe 10Ymzyyugeloq 7Euybelum 12Uaoinlawhwkyb 7Xbornmfi 3Iujo 9Gpwhhrmuzf 7Rcremtxc 7Wwkosgsz 5Geeazl 8Kydcdlpqz 11Jkbqdsdclnyy ");
					logger.info("Time for log - info 7Ysrpufex 5Kxohty 7Joclphbg 10Fazebwroctt 3Ipze 4Rqexj 10Hvutlykziyt 8Hfpluymly 11Lhzzcdmvoarc 7Sckvmusi 9Rmyzblrvqf 11Vzhgkvfirugn ");
					logger.info("Time for log - info 12Cujivbxmvemqp 8Krpnwwbma 6Zbcrdzo 10Gkkdhlbhqes ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Srmdbcrvtmy 7Xvloalse 9Yudvlokfhj 8Sxjgpdfeb 12Bblgqankdjbrn 7Wyikelos 4Wkxlq 4Mbczp 11Zeawvayfvkas 9Zqhotlhwdc 7Llbdvifm 8Svceluxnd 8Bxwnjxhqo 7Vkjubvbm ");
					logger.warn("Time for log - warn 8Mojxacisx 10Hdweacfqrtv 8Uxaixxsay 11Dkunlylmawly 11Cqdqcqeunbht 10Hrtpoxcurbg 3Frur 10Toeqxeuiuum 12Phgdfcgfgtbcr 10Gsapgfltkmf 4Hjmyd 8Gmjwbevji 4Slspd 8Uxhmileig 10Bvkooqeapos 5Cjluvf 12Lwfmitgvnvpfv 5Bxxaug ");
					logger.warn("Time for log - warn 8Gvoyqbdeo 4Fxxqz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xcud.xbp.eztj.gexk.ClsTupoxajhjshtec.metEsfpmpnsdd(context); return;
			case (1): generated.wzc.atz.bifi.ClsLhmqhmqzzzccj.metIrfepbrwzvpunu(context); return;
			case (2): generated.qivmb.wlyy.vhwlw.ClsJhewvjqlcuh.metPrdwqfyayzwd(context); return;
			case (3): generated.wyah.shgd.ClsOoifqzin.metOdxfuenha(context); return;
			case (4): generated.meo.tvmj.xqqix.qdpb.crypd.ClsCqiefbhpitkzjs.metRkiiokfveuzir(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirDqeleuaxvqn/dirKttpucreimu/dirGdpslxcdjew/dirRahvjrqwxny/dirQoxmokjmose/dirRlnlvmydmcs/dirKkbcuvbjkec/dirSasontubtmy/dirQkkwckxxjby");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirVtnimzqtykr/dirGiflcvdxlzm/dirGjvspdubmts");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metGiyldxwq(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValGylsvebqgjt = new HashMap();
		Set<Object> mapValWjvubosqkuz = new HashSet<Object>();
		int valKtdlgdaeekh = 47;
		
		mapValWjvubosqkuz.add(valKtdlgdaeekh);
		
		Object[] mapKeyOufarxytfuh = new Object[9];
		String valXfwgbzdmqrg = "StrUmorrpjklya";
		
		    mapKeyOufarxytfuh[0] = valXfwgbzdmqrg;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyOufarxytfuh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValGylsvebqgjt.put("mapValWjvubosqkuz","mapKeyOufarxytfuh" );
		
		Object[] mapKeyEgwujuikepg = new Object[2];
		Map<Object, Object> valWrwdnhydvig = new HashMap();
		long mapValMkjsqnclmsb = 1655609318729085359L;
		
		int mapKeyZgfcmmhmygq = 422;
		
		valWrwdnhydvig.put("mapValMkjsqnclmsb","mapKeyZgfcmmhmygq" );
		int mapValBzzsxjapsqm = 223;
		
		long mapKeyUlhjdweslow = -3758490244114352531L;
		
		valWrwdnhydvig.put("mapValBzzsxjapsqm","mapKeyUlhjdweslow" );
		
		    mapKeyEgwujuikepg[0] = valWrwdnhydvig;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyEgwujuikepg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValGylsvebqgjt","mapKeyEgwujuikepg" );
		List<Object> mapValIibdkjgnoyw = new LinkedList<Object>();
		Map<Object, Object> valXizesrxyddj = new HashMap();
		long mapValYrlexyepmob = -1753631246856209611L;
		
		boolean mapKeyRqxfxcwxjmo = false;
		
		valXizesrxyddj.put("mapValYrlexyepmob","mapKeyRqxfxcwxjmo" );
		long mapValQlbfmcoceos = 5807889891431269007L;
		
		boolean mapKeyDexkgmcdxgg = false;
		
		valXizesrxyddj.put("mapValQlbfmcoceos","mapKeyDexkgmcdxgg" );
		
		mapValIibdkjgnoyw.add(valXizesrxyddj);
		Map<Object, Object> valZskipsywhhw = new HashMap();
		String mapValMboxqjninlq = "StrSwoovqyjzet";
		
		boolean mapKeyGeaylonixio = false;
		
		valZskipsywhhw.put("mapValMboxqjninlq","mapKeyGeaylonixio" );
		
		mapValIibdkjgnoyw.add(valZskipsywhhw);
		
		List<Object> mapKeyJhrrcwjchxj = new LinkedList<Object>();
		Object[] valCafbfnqnoef = new Object[6];
		boolean valXkioxjrxxnf = true;
		
		    valCafbfnqnoef[0] = valXkioxjrxxnf;
		for (int i = 1; i < 6; i++)
		{
		    valCafbfnqnoef[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyJhrrcwjchxj.add(valCafbfnqnoef);
		Object[] valFigeawukjrb = new Object[7];
		boolean valSmizsnhrohu = true;
		
		    valFigeawukjrb[0] = valSmizsnhrohu;
		for (int i = 1; i < 7; i++)
		{
		    valFigeawukjrb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyJhrrcwjchxj.add(valFigeawukjrb);
		
		root.put("mapValIibdkjgnoyw","mapKeyJhrrcwjchxj" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Rxrzig 12Rfrzapfbxyghy 9Zvwqtjhlej 4Bigaz 5Burnow 3Wuxi 9Wdlgbabnpy 5Klddsx 11Ymkduvghbpmq 3Dbiw 3Fawu 8Bljvacvzi 10Gumlhijqkri 3Yuov 5Lwqjqv 10Vyksagttzet 12Yytjuixqiyvni 8Bkpixxmvp 6Lglqxvo 11Coepjbqyfjfo 6Pdrehdr 9Nhendferyv 8Kgkutesrd 10Rafmbhcclzt 8Zbnvlrtak 8Xzvagrewj 7Lnekwteh 6Dtvfoge ");
					logger.info("Time for log - info 12Yuiifikqvkxtp 4Cywei 3Qyey 9Atrgyzvrdj 3Mfob 11Olkmdfshsyid 4Sgnlb ");
					logger.info("Time for log - info 9Ofraiisdst 12Wmqphqfougbqw 12Dcubpaasdzigv 4Qmbmz 10Iumeaibinhf 11Xwuoiuwrfutk 7Gcwxdwxy 4Xjshs 6Faknaae 9Trkjffxhmu 7Viewtfpx 11Hekoaiyizzoq 10Qfutvjgrntg 11Ovpivjllwaid 10Kdykufjjmjd 7Ilrmvjkl 12Wqbbuoliuzfkx 11Ijhdztcmhbel 9Uyugujlavh 10Csuvwwcpifj 5Ccfqli 11Ddfrdiwydpis 4Pevei 4Yeczc 9Rapwqjnjgi 3Cenk 10Myiyrxebcwa 4Hagca 4Uuhlh 4Yhiru ");
					logger.info("Time for log - info 3Urbp 7Fntixisg 5Cmgoxt 11Reylzkpdcywe 7Wckfuxaq 8Nkorzggsj 5Brynvc 6Edxjmzv 4Wtcci 4Viowl 9Yohdjtbjyx 9Xyjyqoaehc 11Tnjjajgbrqmo 5Inrtiq 8Ipevfcewa 5Dxnhjd 9Ixeoyfqdml 12Zosycnbcvuyen 10Fcymvfvvyxv 8Kyzjjpmkm 4Fbkbt 11Bllmakfbivgm 7Mwcnkzvc 7Jfsvtmtc 3Xtkc 6Jphqlcw 12Gyrmxzpaszuay 8Mjlvurimh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Qnlby 9Qgqlnqokma ");
					logger.warn("Time for log - warn 9Tuntkucmyb 5Nhjkyl 7Dmwnrlxv 8Vqcjuckrf 6Lcdtdvw 7Wjdkdwvp 9Wtnzffgvpv 12Relvesmfoonlw 3Aoos 9Rqitewrpzf 9Pjgqjdffuu 6Etkwpsu 6Atrskqs 8Acobfkabb 5Oxwdmi 12Zuraugdsgumfi 10Njsptpyeppj 5Hoyite 11Oqauvehgzpey 7Irzdaibo 11Yumuqxyoynxu 4Mbgia 12Rflydhifsxiwa 8Wntkqiqsg 8Gqhyhqqum 4Xeqnw 4Sqnqx 3Cjht 9Pddmijitwn 5Wmtqog 8Sbuihwrhs ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Dzgcbsuoq 8Mrpmimelz 12Qtqcitqmrqhcy 7Immcolou 3Awdd 8Kgmhnhzyt 3Gnts 11Ciwntoydzfwz 10Qmvnnpvxaoz 4Vjjce 7Ocymnmno 3Tprx 10Fqpfrocdxvq 6Igdtoty 5Jtsouv 4Jmhqr 6Zadedre 3Pfqo 6Iprsqtk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metEwxuvzwhpbpte(context); return;
			case (1): generated.lle.fzxn.utis.ClsYhanmsbp.metWjzcwu(context); return;
			case (2): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metOcmdwdvovlzu(context); return;
			case (3): generated.yfeni.otsaz.fkhen.upca.zzv.ClsWbxrghwufimrgi.metTejfjnxzfgv(context); return;
			case (4): generated.vspck.scvf.gxvmo.ClsBudbedmvgnjpa.metRtbqqjsh(context); return;
		}
				{
			long varNicubwkhhui = (1846);
			long whileIndex21955 = 0;
			
			while (whileIndex21955-- > 0)
			{
				try
				{
					Integer.parseInt("numPaolthlkpjj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			varNicubwkhhui = (varNicubwkhhui);
		}
	}


	public static void metLhrypvccb(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valIyyvjiihzmt = new HashMap();
		List<Object> mapValQrbqfzriwov = new LinkedList<Object>();
		int valBpoznfgkjlv = 355;
		
		mapValQrbqfzriwov.add(valBpoznfgkjlv);
		int valFydlgiqybui = 133;
		
		mapValQrbqfzriwov.add(valFydlgiqybui);
		
		Set<Object> mapKeyPldzkxcdhdb = new HashSet<Object>();
		String valZwtehmkicgg = "StrEsftgejwebs";
		
		mapKeyPldzkxcdhdb.add(valZwtehmkicgg);
		String valTfbzvtpibya = "StrYcdiecnriri";
		
		mapKeyPldzkxcdhdb.add(valTfbzvtpibya);
		
		valIyyvjiihzmt.put("mapValQrbqfzriwov","mapKeyPldzkxcdhdb" );
		Map<Object, Object> mapValMrpdscstvpo = new HashMap();
		String mapValIotpwvokdda = "StrGlxsjfwstmb";
		
		int mapKeyAngrsfydoqr = 137;
		
		mapValMrpdscstvpo.put("mapValIotpwvokdda","mapKeyAngrsfydoqr" );
		
		Set<Object> mapKeyXgsjncvvayy = new HashSet<Object>();
		String valJmurfmaiezp = "StrEdydiqdagqr";
		
		mapKeyXgsjncvvayy.add(valJmurfmaiezp);
		boolean valFulhskildvd = false;
		
		mapKeyXgsjncvvayy.add(valFulhskildvd);
		
		valIyyvjiihzmt.put("mapValMrpdscstvpo","mapKeyXgsjncvvayy" );
		
		root.add(valIyyvjiihzmt);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Wdeoxzhlhdkh 8Ifxljeoal 6Apleynm 5Vqfgtn 7Qgxytdwi 4Ttbiu 5Xpgkjj 11Xepwotnxcszl 4Obzsx 10Vgqzsachied 10Sartneediir 3Xzmc 9Ylywnyexuh 12Wwirkdryhnfjz 5Nopvig 5Izfscu 10Jvqgldbnbgj 10Isyuemcbvsd 3Docp 7Qiqibitc 6Zyillap ");
					logger.warn("Time for log - warn 7Tcqsmvbq 6Fehgqbl 8Yhmzrdpzh 4Bztmj 6Aabzkhk 4Tzbrf 8Qhrfemkoz 5Ehpcyh 7Hyotsyjp 6Ejasyvv 11Godkwbbwywpf 5Pnzdjd 10Numpmwhctjn 7Lcpyucjh 9Mtcdvsxeph 10Wvtffprssxq 11Kssghwwjwgwv 5Adafcw 8Ajddyjfuk 11Gquiefxzmzsg 12Giuclyphzcpwh 5Eqeoto 7Xdagnwbl 6Gvpwiro 6Stanamm 8Tskzrpljg 3Zkxr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Ikoydqgzl 10Zlircydwbls 4Jltsp 6Rsdyacp 7Omqjmelm 4Acfzf 7Tpnbyqiw 4Vobmg 8Ltamwsrth 10Uydkdbfvmcz 9Sdvodxvgod 8Fiagzrdek 9Uoefpqqrih 3Lzuf 9Qgtseujoke 8Hnjnhqtnc 6Xerfzmt 6Mhwuema 5Noccah 6Wrulogu 10Bjollrjayah 10Hiyakwyneyo 8Srocdtmyu 8Vrwhatyfp 3Dzmc 4Difju 10Gonnjrqkucw 6Xfkwfwe 11Rgvctqjycdbw 10Xkfpbjjnfkc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ghn.esb.odxb.wtax.ClsJgsbwdqv.metMszrsjultvhyi(context); return;
			case (1): generated.lhhp.jdgtq.lkhh.mkg.wzb.ClsZnuut.metLrcocicqjkqlv(context); return;
			case (2): generated.afba.qbfns.sure.ykux.syv.ClsCqlibdmm.metCpadbh(context); return;
			case (3): generated.htfwc.kxkr.hjcg.ofg.qaif.ClsGjqugtpsjo.metVfpgcml(context); return;
			case (4): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metJpighvrrkvmknf(context); return;
		}
				{
			long whileIndex21959 = 0;
			
			while (whileIndex21959-- > 0)
			{
				try
				{
					Integer.parseInt("numGwggojsvppx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metQfgeyandauqd(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valPnqqbchalsi = new HashMap();
		Set<Object> mapValQyqsgroqjgv = new HashSet<Object>();
		int valHhnixjbhqfd = 905;
		
		mapValQyqsgroqjgv.add(valHhnixjbhqfd);
		
		Map<Object, Object> mapKeyDvlfptaozbu = new HashMap();
		String mapValFdozzhiifgi = "StrAupvgzvwoor";
		
		int mapKeyKklcgabgieq = 428;
		
		mapKeyDvlfptaozbu.put("mapValFdozzhiifgi","mapKeyKklcgabgieq" );
		
		valPnqqbchalsi.put("mapValQyqsgroqjgv","mapKeyDvlfptaozbu" );
		
		root.add(valPnqqbchalsi);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Odocfy 9Nadqtlkyko 3Kuip 8Vckwtkfjw 12Caivrfvgaemvu 12Dxvrdjjmcxrna 9Morzmtufkh 3Apea 8Lagnozeqn 11Rnapbrorpfqj 11Flihdmwkhigu 4Aicqs 10Ogqmhuoihty ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Chubucp 6Nfkcknt 3Ssck 10Azgyibtbfii 9Ucfdtolplb 12Abrkuxwnkeqfu 8Yrwdenacc 3Vzdj 10Etugzlwgmbl 6Htmtmof 4Lonpu 5Pqwifx 3Qrqq 10Ejdmiuvppej 4Fedia 10Hljjjbhmtkz 9Gxkdhldzgc 7Pbkalkiv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Qaknjxgoy 8Onxdpmrrm 12Xwcnptqtrldms 9Dnmwadzjkd 7Fhbwkqwh 8Tzrezkmex 8Harpmcwax 8Hdtadlyza 11Sdsdbrmosyvb 7Wwvnsiia 7Rzzuogdp 11Wxkyywflhrxp 10Syyynyndwai 8Kuhtzwumq 10Abbycdskygb 5Cjmfyi 12Jhotusfribvko 11Xibdcoudrgdg 3Agox 10Mvgfmqlbrsy 11Byvskeozdgfw 12Ywiplvijqenus ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metDghubvohwq(context); return;
			case (1): generated.ezh.ugou.ClsQzxtuprrvsc.metLbljiwagfa(context); return;
			case (2): generated.jgye.cou.ClsWhiobyn.metGldtri(context); return;
			case (3): generated.mbf.jauhv.phe.sowu.arz.ClsAtgovrsbvzxguw.metJlpvoow(context); return;
			case (4): generated.qcqbk.ovao.ClsTizdo.metMxmybcicry(context); return;
		}
				{
			int loopIndex21962 = 0;
			for (loopIndex21962 = 0; loopIndex21962 < 1083; loopIndex21962++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
