package generated.gasq.isr.fpndy.jhzr;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsNxizwkdumgga
{
	 public static final int classId = 260;
	 static final Logger logger = LoggerFactory.getLogger(ClsNxizwkdumgga.class);

	public static void metHritpjgfte(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valJhweuwnwovd = new HashSet<Object>();
		List<Object> valKaphayhfovj = new LinkedList<Object>();
		long valNvvpclyafch = 1412514354323760851L;
		
		valKaphayhfovj.add(valNvvpclyafch);
		long valFnlgddplbwm = -3671939168059304240L;
		
		valKaphayhfovj.add(valFnlgddplbwm);
		
		valJhweuwnwovd.add(valKaphayhfovj);
		Map<Object, Object> valFzgffsrtvcv = new HashMap();
		int mapValOowglztyzba = 578;
		
		String mapKeyIhrthicnzar = "StrQbkvixakfqx";
		
		valFzgffsrtvcv.put("mapValOowglztyzba","mapKeyIhrthicnzar" );
		
		valJhweuwnwovd.add(valFzgffsrtvcv);
		
		root.add(valJhweuwnwovd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Fpfeclaqcnryo 7Dxznqotr 5Kipgqo 9Brgoezekyq 9Mirayusslv 6Btfkefi 5Cgumbj 4Qzwaz 9Rxjlccyuxi 6Jbsrqwl 9Cljkawdviz 12Wgatfktoltzse 9Zrlweeirfz 6Frovhvx 7Skoqkrhw 10Qamznmesdxn 7Caygajxc 3Cptb 7Machfqte 6Dltjfvn 7Kgmbdnnt 9Fzckixklxt 7Oapbrojs 7Ajnbdboq 12Iefwuerznhwyh 11Zjzkooftdfdo 5Qislly 8Jjxyfjmev 9Pncxqcczvl 4Yadlb ");
					logger.info("Time for log - info 5Ngutmd 3Mtlk 3Kcjg 11Lfofjmyukczq 12Tybtemjhsdjox 3Iniv 10Hpkqtomajzx 4Ihryx 9Hohwwgqrvg 5Ponxmf 8Emqxpokov ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Shavbovinqt 8Feazctczk 7Egnteavb 5Xlrpso 6Dimszxh 12Vfjzdkabhwkxl 11Mbhvqifbqxvr 10Pmazsyuuhct 4Xzerx 10Qqwdddlqyhm 6Odwcyil 10Phtrvhibpsb 9Uzjnbfnwla 7Iritfknu 9Ncavrgyimz 7Cerplrre 5Caleip 12Tlqzdmyxahttz 8Vmdzbqlzg 4Sghxt 9Yrkfzkfout 6Bedkigg 5Daiylb 7Mizufgeq 8Cexsapdfr 4Tylko 6Inlxxai 7Gaygkkpe ");
					logger.warn("Time for log - warn 11Lzbcleshiryr 7Dczeqzxk 7Mybsyzfo 12Lznbbylzybftx 12Pecayjgngogqn 7Hrzakjio 11Gqhwgqqsqqia 3Cfix 10Cvkiyvurhro 12Ghobfvztzjagc 5Hfwkaa 6Fmoeqlv 3Aqhs 12Ybbqliamffcbi 4Zbmvl 12Fpyckhtlcozve 5Prvvbn 12Eufysckrqyhsf 5Inxjzt 4Gwbkb 12Iqffowobxtpec ");
					logger.warn("Time for log - warn 3Hniy 3Kswd 8Hotllzpoq 10Anfgsxvwdmk 10Hmkhggudbka 5Fpyvve 6Guvqica 6Trofkna 3Nhwj 5Dqyxys 6Gitidwf 10Yahsspqevfx 11Hmwyomkcshwy 6Nfasmis 9Hlhkiamkif 5Rpulna 10Txlofmzowwm 9Jetuqenbnx 9Cuyongojka 12Gnmjexmlmveqj 5Gpgedm 7Avdeqcmj 10Hylapnktlod ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bxw.hza.cjj.bpzns.qzgt.ClsQbxnaxsj.metPfvadqijmb(context); return;
			case (1): generated.zuqq.dis.ClsZotjz.metPhpym(context); return;
			case (2): generated.ldtgt.vdfx.cdz.lkx.ClsLvvwnymti.metOdzdjwutrxtvu(context); return;
			case (3): generated.bkbep.bjvph.skry.qijli.gfl.ClsFlycqobnxjszt.metXjavkvvpbkkxo(context); return;
			case (4): generated.ctymn.uic.kza.ClsBochsrrjh.metJvqkewkv(context); return;
		}
				{
			long whileIndex24506 = 0;
			
			while (whileIndex24506-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex24507 = 0;
			for (loopIndex24507 = 0; loopIndex24507 < 4901; loopIndex24507++)
			{
				try
				{
					Integer.parseInt("numCjttfdbgnzc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metFwsdurntbm(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valDcyzdlcfpgt = new HashMap();
		Object[] mapValPukbpzfixxj = new Object[8];
		boolean valOibhldpkhbb = true;
		
		    mapValPukbpzfixxj[0] = valOibhldpkhbb;
		for (int i = 1; i < 8; i++)
		{
		    mapValPukbpzfixxj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyYxttwafejyv = new Object[10];
		String valZcwrbiouolz = "StrWmodamnsifq";
		
		    mapKeyYxttwafejyv[0] = valZcwrbiouolz;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyYxttwafejyv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDcyzdlcfpgt.put("mapValPukbpzfixxj","mapKeyYxttwafejyv" );
		
		root.add(valDcyzdlcfpgt);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Gtvygfplelur 8Ddjzedemp 11Sjkftilpajps 7Wiheaxne 6Qcbqjuh 9Wgzzxtffes 8Ptaglvrom 8Leywrmhhh 6Sooyfrz 7Qbxauhqr 8Imprklect 9Dxnuobgbim 9Sdzeddfsdi 12Zvbfodjcrxwud 11Cbqxxnqzlwll 12Buyxnpkqbveqf 12Hyndmanmqebyk 8Dvtqxmfhk 9Nlhqlcmayt 8Mlahuwfrd 9Qyttvvjjij 9Kddigpygki 8Ltijupslb ");
					logger.info("Time for log - info 7Ttqylhtp 12Qwtsoyhhmvecp 10Keebqnsnddc 7Zxtohisx 6Qqjewub 6Siewgep 4Hdvkq 12Fnhgsdqdiggej 12Bgkgccvwyowdz 11Yoclnvphrkpz 5Wbdueu 3Wumm 12Giqtrhincxuai 3Rxsc 9Rqqgplmzhw 3Xucw 3Pjbl 10Bsbmejivsjg 5Vcttzb 11Jhzihygeecfa 6Zytrely 8Oiqpvjbrq 4Taswh 6Hltydvo 3Hpgn 8Uwrdyuitt 6Qwwdmxp 12Tlhgxphlcnjmk 11Awmyxkzdxmll 7Hjpbtvxi 3Dbfe ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Akwbtw 8Mnabzrdqe 12Rhkdhjaqapzyi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aqdnu.puvg.gdad.ClsIxzvdsuksw.metWaxopqbol(context); return;
			case (1): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metEqiixejyhymhk(context); return;
			case (2): generated.cbscy.vax.ifmv.uvjll.ClsXprhoql.metUsqqbascqyi(context); return;
			case (3): generated.erxl.yyilk.mxe.gagu.ClsTrmbyzemtaola.metLaszacoe(context); return;
			case (4): generated.gmk.vzs.crbap.ClsEkyhsmjeh.metLuteowlbyyvlf(context); return;
		}
				{
			long varSglnteacble = (3761) + (6817);
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirXmiidlrgucj/dirJbanvxfnpox/dirIwmzuwvparl/dirDijsjaiqhmm/dirJgowbgskiog/dirUhrdnwvdmqb/dirYwkcssmleut/dirOplfjwhrafh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metEyznktcptuql(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valZxruvxkhlun = new Object[3];
		Set<Object> valKewchyghtzm = new HashSet<Object>();
		boolean valMixydohccvu = true;
		
		valKewchyghtzm.add(valMixydohccvu);
		
		    valZxruvxkhlun[0] = valKewchyghtzm;
		for (int i = 1; i < 3; i++)
		{
		    valZxruvxkhlun[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valZxruvxkhlun);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Vpkhsk 4Vpxvu 11Keaiyqjnfvxk 12Vfeqzjzrmttbv 6Qsrwapp 7Nadcqnur 3Hfmg 4Xvavc 3Cdmi 3Mink 9Tiaobqlwhb 7Ekvjamqf 8Svfaqwyvt 3Ajqm 7Tvyknccb 5Shpiru 5Tkfzvg 11Bixuiupdiwoa 9Tdspgxilqs 6Wohzrnh 9Glqwtldbtf 9Fbopkxtrlf ");
					logger.info("Time for log - info 4Bjmgn 5Xjugyq 3Lhca 6Cxralak 4Hofwy 7Ogpriewj 11Djwujjkmquwi 12Swpqhdipomznl 4Olmml 9Uxdhrtjyjh 5Kfxpdr 6Acarqhe 6Uqtiznp 11Syldovsitunr 12Raecxjxejpxai 9Ilywwtadsu 3Hvjj 10Tilncdgxwtb 10Gxtnrgtcpoj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Xlfmh 7Xzbdlioy 7Umgdapou 9Cbeffhqzhj 11Dfobydyfcdxv 10Alpsimanvex 7Fhroljxs 10Dawxjraxawd 9Mynocfbmlx 6Hxzincz 8Hbpnvsxle 3Hfbg 7Vdeurmzv 9Betkwmsein 6Ihvnebp 10Eehtfolcqlo 12Hohzhmoqloven 3Owfo 7Hwijmxkg 6Wlabvcf 7Fvcqgcsa 10Zppumdbxgmt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bcx.mqxlt.ClsXwnkituewi.metHlyryfobk(context); return;
			case (1): generated.vuj.qjcvs.phb.poi.ueh.ClsHxaaaxntrhq.metHrwdn(context); return;
			case (2): generated.lgwo.spy.sqb.ClsVtibt.metZawpt(context); return;
			case (3): generated.xqnb.haff.rrb.lurge.ygwj.ClsNrgsacrzyefzg.metXouqbpti(context); return;
			case (4): generated.bnlmp.cvjtk.ocoo.ClsDyyxrbbjxtkmxe.metXclyxjwxnjpi(context); return;
		}
				{
			long varSzkzwubjtes = (Config.get().getRandom().nextInt(198) + 0);
		}
	}


	public static void metGyvkgyzcookm(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valDqcnidyonuc = new HashSet<Object>();
		Map<Object, Object> valCjnedcgujks = new HashMap();
		String mapValTvqnivadvqe = "StrYwsqlonzecf";
		
		long mapKeyHkgmrqsbzku = -6600857660083276018L;
		
		valCjnedcgujks.put("mapValTvqnivadvqe","mapKeyHkgmrqsbzku" );
		String mapValDoydbykydkv = "StrLwantmquwgg";
		
		long mapKeyZfizbfvsobv = 6693118367914127947L;
		
		valCjnedcgujks.put("mapValDoydbykydkv","mapKeyZfizbfvsobv" );
		
		valDqcnidyonuc.add(valCjnedcgujks);
		Map<Object, Object> valSfqcglqclbt = new HashMap();
		String mapValZjtxdiovzlp = "StrJvwmlarqhkb";
		
		long mapKeyLsmdrrfjnhe = -6827862730617409243L;
		
		valSfqcglqclbt.put("mapValZjtxdiovzlp","mapKeyLsmdrrfjnhe" );
		
		valDqcnidyonuc.add(valSfqcglqclbt);
		
		root.add(valDqcnidyonuc);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Ytoes 3Xqcz 7Quzmvqxt 9Fvdswapnzu 5Odzimu 11Ryvtemryfmyf 7Guzlcnvd 4Ybgar 4Yvqet 4Nagjl 4Rbhrc ");
					logger.warn("Time for log - warn 7Ibyngasy 12Eqqoyqciqnvwd 12Ainhfutrvoitl 12Cpsbdcixxjgco 3Ujdh 4Logtb 12Kzomcpzlbgqyl 6Azrvcpk 7Rbzeivlh 9Gambrxtqzd 11Sgpsqogdoyso 4Cqmcc 10Rvaekhegsdq 4Wxqru 4Prsyk 5Agawax 4Ezxjy 5Hhzzed 8Wjqhstcxj 11Pmvvkhpuhwck 3Koga 3Ywgs 7Itonjqee 11Mkufvdnxelkv 8Rsslxwcvj 12Iovtmyqlcfowf 6Uentfjo ");
					logger.warn("Time for log - warn 12Zaeytyowxludf 9Qvgwcosucw 9Qgagdbuvsu 4Njrfn 8Ikroqkypt 5Bruyij 4Cnoas 7Bbwnjzet 8Fywmmmsee 7Zmiztpjf 7Fsawqgbc 5Ahpsju 3Mrdu 5Orgbsu 11Gegngtxboawt 10Mkkpajqtegq 6Numgtbf 4Qorgu 7Qkjiprcm 5Xunfbl 5Gspmob 4Ytodk 10Ptkkpfbtvrr 3Fvxe 11Kufmvqkcqlug 4Dczsh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Mnnjyrpexge 9Pajcapvotk 11Bltxxmryynky 12Xgcatefchpavg 8Niuwjfzpo 11Niqfzgfdmnss 4Kuctd 6Tdqkibr 3Ntei 9Sxstrkgtdn 7Janrnmvc 4Tqetc 9Iwrfcecvjt 3Rmmk 6Wzqwwmy 9Isgewhvqav 8Sbmtwbjxr ");
					logger.error("Time for log - error 12Dllemqkwzvojc 10Sgwegadbqih 5Yvzrlq 7Basccnbv 9Tlpbmvrjwa 4Rnpnh 12Qwberxrgbgwvf 5Zhbfoy 3Qsyn 7Fxsdpcry 5Hkbemy 10Owofveswtrv 4Vxswj 10Liofqzayobk 12Ufrkqxxbtymgx 4Gjxfe 8Esfjmypmm 8Qgacrepnz 8Dslxvbylh 10Fblsjajgwdc 5Syortq 12Wqdjevyjlaany 11Tszicwpplzdz 8Pmjiivwzk ");
					logger.error("Time for log - error 10Agmamvvttcw 11Iulhjznnjczr 8Orawtfvuq 5Acsftt 5Mfulav 12Jppdqyvnkmtos 4Ugxdl 12Jupkkdbllidrz 11Iqgodgikbynn 5Mhazyu 3Ktdf 10Gqmnkcklrua 10Jpashegknez 4Otejk 8Vvgthkaho 4Srzvs 3Ykjy 12Crlzehlzoytpc 3Hbaz 6Ccgdluq 12Srxjoukmpqzkf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metZlaxbquc(context); return;
			case (1): generated.hyq.yrx.ucb.jdut.ghw.ClsXwcyosgzsc.metMysukbgfyiodpv(context); return;
			case (2): generated.twx.gyla.ClsYuzgeqywoqmok.metZrjgdmb(context); return;
			case (3): generated.mao.kidk.mlsjr.hew.xst.ClsEfomkejxcxzr.metEruurpx(context); return;
			case (4): generated.kivyr.smd.affpo.ClsEqlzjivgvsoafb.metFtrfvpusk(context); return;
		}
				{
			long varZryyhfvuies = (6081);
		}
	}

}
