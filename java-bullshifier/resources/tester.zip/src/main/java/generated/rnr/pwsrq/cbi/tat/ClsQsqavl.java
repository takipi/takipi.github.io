package generated.rnr.pwsrq.cbi.tat;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQsqavl
{
	 public static final int classId = 21;
	 static final Logger logger = LoggerFactory.getLogger(ClsQsqavl.class);

	public static void metNujgqvqobxeyw(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valUdkgbceqxos = new LinkedList<Object>();
		Map<Object, Object> valBifolwhrzxl = new HashMap();
		long mapValErbqzjwvjrd = 4227725465152943298L;
		
		int mapKeyHobdhrligab = 91;
		
		valBifolwhrzxl.put("mapValErbqzjwvjrd","mapKeyHobdhrligab" );
		String mapValSiduhxgnoba = "StrQhsovpyalzf";
		
		long mapKeyPzshfwrtcwb = -7535709545332490304L;
		
		valBifolwhrzxl.put("mapValSiduhxgnoba","mapKeyPzshfwrtcwb" );
		
		valUdkgbceqxos.add(valBifolwhrzxl);
		
		root.add(valUdkgbceqxos);
		Set<Object> valSjboprholal = new HashSet<Object>();
		List<Object> valYxpmaxbdemi = new LinkedList<Object>();
		boolean valGgcdhfkmjdp = false;
		
		valYxpmaxbdemi.add(valGgcdhfkmjdp);
		int valZpjynjsqjbs = 545;
		
		valYxpmaxbdemi.add(valZpjynjsqjbs);
		
		valSjboprholal.add(valYxpmaxbdemi);
		Set<Object> valWdqvlwhjngn = new HashSet<Object>();
		int valJomzitxusry = 804;
		
		valWdqvlwhjngn.add(valJomzitxusry);
		
		valSjboprholal.add(valWdqvlwhjngn);
		
		root.add(valSjboprholal);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Ijdxg 12Kpzzpprwfbsgo 10Grmrxuxujiv 3Crou 4Fnymz 7Xpecdgbh 6Nuzstrk 6Lmghynq 5Ryinsf 6Byqvrcg 4Ufjta 7Jaifxqbz 11Bhabbagxeoeu 3Pnqv 6Mbijnuj ");
					logger.info("Time for log - info 5Ptwxaq 9Bqvtaqclgn 10Fjixymiziqn 9Jjsheftrnm 7Idxyambs 7Wvstjqyw 10Wkjpyoewiiv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Bfibvgkzy 9Wnjxruqjgq 11Colpknpomhsn 7Zoxlaqus ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qpya.todk.woo.rrzxr.ClsQlmcomguvtqu.metVbgwaaycr(context); return;
			case (1): generated.agl.duqt.yfyli.jnv.jpizl.ClsQbgwqgmsxm.metEmnhch(context); return;
			case (2): generated.eddt.homo.syk.wqll.dyeuq.ClsYzlmjqrjjp.metCwoimorcxixd(context); return;
			case (3): generated.gfhvs.nuhuq.qbk.rwbku.erqpl.ClsOuzdnnqrt.metYemauozpyth(context); return;
			case (4): generated.tyg.mzcly.ClsYmwmvdb.metNppiiobv(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numDxlmkxuqwak");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirKabmricddgo/dirLwpxptlkrkc/dirOlxzesjaipg/dirHsaqijdwacq/dirLgegfqgdycb/dirVwgrykimfft/dirQtoesombdtz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metUgatrdxyhn(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valMtszgfuypvn = new LinkedList<Object>();
		Object[] valInfqvlcusmf = new Object[7];
		int valHwlcfwvhvqh = 539;
		
		    valInfqvlcusmf[0] = valHwlcfwvhvqh;
		for (int i = 1; i < 7; i++)
		{
		    valInfqvlcusmf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valMtszgfuypvn.add(valInfqvlcusmf);
		Object[] valGqychwscovr = new Object[3];
		boolean valVchivdboppq = false;
		
		    valGqychwscovr[0] = valVchivdboppq;
		for (int i = 1; i < 3; i++)
		{
		    valGqychwscovr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valMtszgfuypvn.add(valGqychwscovr);
		
		root.add(valMtszgfuypvn);
		List<Object> valBoomjtypxfd = new LinkedList<Object>();
		Set<Object> valGeyaxpnggzg = new HashSet<Object>();
		boolean valJmvfnoxrdwo = false;
		
		valGeyaxpnggzg.add(valJmvfnoxrdwo);
		
		valBoomjtypxfd.add(valGeyaxpnggzg);
		
		root.add(valBoomjtypxfd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Nwelm 5Nmmras 10Xsfzskzogbm 6Fjsqupg 12Cbmdgqnvzcmid 5Ehaeaa 7Vlnpndta 12Gjipxnkqryvpy 9Ukqkvjedea 5Jpdtpa ");
					logger.info("Time for log - info 3Aknf 11Hpywxlxnnwpt 4Troky ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Sznajxmewo 6Yhxzrzu 6Pjoalvo 11Myhgacshgalz 3Uhdi 9Vpriunrxyp 3Jycj 8Lsbdktpar 11Fwdyznohkosp 3Ghxm 6Yqmggjn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Rfcqfd 11Bvzaenhmtshs 9Hbyzcivbwk 10Cykhvhuhzom 12Bzmdmxnifjvyc 9Dgbqhhoxra 7Cpalfnof 5Ukbjfh 3Rxkw 10Yqrpsaevibo 9Vslopzubyc 7Gduylmgc 3Waab ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.eob.tzj.qiec.ClsEnjcnowop.metHjaxbe(context); return;
			case (1): generated.qku.vho.jtvuy.nvgy.zmvk.ClsVjaehh.metEpucadc(context); return;
			case (2): generated.flvo.tuwfx.wlpxx.jysnd.tuk.ClsFuuvt.metQxwuot(context); return;
			case (3): generated.flvo.tuwfx.wlpxx.jysnd.tuk.ClsFuuvt.metQxwuot(context); return;
			case (4): generated.wte.xgtr.bgy.yncq.pkef.ClsWcqetwudvh.metMkywussdywwg(context); return;
		}
				{
			int loopIndex2387 = 0;
			for (loopIndex2387 = 0; loopIndex2387 < 4610; loopIndex2387++)
			{
				try
				{
					Integer.parseInt("numOzqesjleieo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex2389 = 0;
			
			while (whileIndex2389-- > 0)
			{
				java.io.File file = new java.io.File("/dirNytiluvgsra/dirJnmuunmjrbq/dirWmdiehippnd/dirAmlmyzprsjg/dirWbvihetkpso/dirRkmlxweihyd/dirNcrqistcxok/dirGanindgyoxf/dirPjzdqdjblba");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metUzhol(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		List<Object> valQflsgbvnsdd = new LinkedList<Object>();
		Object[] valGrpvnldbmio = new Object[3];
		int valLqvmwvgyhdn = 438;
		
		    valGrpvnldbmio[0] = valLqvmwvgyhdn;
		for (int i = 1; i < 3; i++)
		{
		    valGrpvnldbmio[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valQflsgbvnsdd.add(valGrpvnldbmio);
		
		root.add(valQflsgbvnsdd);
		Map<Object, Object> valAwfztwhxlat = new HashMap();
		Object[] mapValWwuidqkalfs = new Object[6];
		long valWcnnfaisxth = -5248852697460900125L;
		
		    mapValWwuidqkalfs[0] = valWcnnfaisxth;
		for (int i = 1; i < 6; i++)
		{
		    mapValWwuidqkalfs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyCkgfoocqpie = new Object[8];
		long valZbdnfdwuepa = 5253986151377904524L;
		
		    mapKeyCkgfoocqpie[0] = valZbdnfdwuepa;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyCkgfoocqpie[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valAwfztwhxlat.put("mapValWwuidqkalfs","mapKeyCkgfoocqpie" );
		Object[] mapValAxlvawuudsd = new Object[6];
		String valQustnstiqqd = "StrGjbzfjzcehk";
		
		    mapValAxlvawuudsd[0] = valQustnstiqqd;
		for (int i = 1; i < 6; i++)
		{
		    mapValAxlvawuudsd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeySstucwudqsf = new HashMap();
		int mapValRtleqesovjj = 86;
		
		String mapKeyVbrkaanjqod = "StrGprvqnmbosn";
		
		mapKeySstucwudqsf.put("mapValRtleqesovjj","mapKeyVbrkaanjqod" );
		boolean mapValKreclrdbknu = true;
		
		String mapKeyGgfjkzyzyaj = "StrJziudnpgver";
		
		mapKeySstucwudqsf.put("mapValKreclrdbknu","mapKeyGgfjkzyzyaj" );
		
		valAwfztwhxlat.put("mapValAxlvawuudsd","mapKeySstucwudqsf" );
		
		root.add(valAwfztwhxlat);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Cycklvbjha 12Vlyzxwafduebp 9Imdfwhyqze 10Lvfvdfejxze 11Tmyprhkjnzaa 7Lppvvlqg 9Mmmwipbejj 9Bfdlctpxfg 6Spdsemi 4Hhfvp 10Nkaeqarzwbw 5Bgonvu 4Cjmft 9Ujupmcaftz 11Dqafzituiqqj 12Usgfvavslinmv 12Piitoorxdwbrr ");
					logger.warn("Time for log - warn 6Zdkskfv 7Ujuahjqx 3Wwul 4Ujjas 8Rbehknaad 5Phmtdf 5Eawjwr 4Ndlkr 11Bnvkmlrzqmww 8Dzpfjyryi 10Oojfqiibsvm 6Qpyuoxt 7Hllbghdj 11Wjfbckjumahq 10Xucncxckcit 8Tytvsfhlj 6Klholwj 12Togqhbamyxxfm 6Rsppfvx 4Eczho 3Kcmj 8Oueprhmeb 4Bthcx 10Jafoeixhjct 10Ktlfdkrnhsz ");
					logger.warn("Time for log - warn 11Wszejrdmtmdy 7Eouoxhdx 3Gych 9Bqivfniknj 7Lokjgtqu 5Gdplfs 9Ozaivybzbl 3Cvlo 10Izuncytweue 3Wvao 8Oiskdhpen 3Jzza 3Cful 10Mrbwwijlnyb 9Sxgpvixfwb 4Phgnm 7Ipxhkzju 7Yzvsqgbc 10Thmskiijyjw 10Fsxbrzesegq 3Sllo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Dsnbwclpiagat 5Fdiciq 10Lslmqhohiqc 3Kzqo 7Vqsgfbbq 12Lweixudpzigfe 8Fbpdamaih 12Jmflzfkiqxlxl 3Cvko 7Ypgadjnt 9Lguoiqyxrt 8Jmebozyli 12Ocyhgtfucnhfn 8Rajxxzhyj 11Vttzaxhujabe 10Hxzsyveqvdg 12Gnejbvbpxdane 5Ggjhii 12Graykqxdtybaj 7Rbgcgfig 5Nyqrje 3Ckei ");
					logger.error("Time for log - error 9Qmosqpnvhh 8Nqeusprxk 8Scselegxc 3Kwao 8Gpltvlmlj 3Uhpk 10Huygvawglng 8Mrmwxmwra 4Frzer 6Soqxlxj 6Yuyjuuk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kfjp.bzn.mda.sfyxf.ClsAguszlzt.metWsvlopnliexx(context); return;
			case (1): generated.gnqi.cix.ClsQxfsbpts.metKsqjpoe(context); return;
			case (2): generated.rub.wtuur.cpewn.fdq.jektc.ClsLiscwkily.metAyhva(context); return;
			case (3): generated.pmny.tmdlo.mfapc.ruez.fnhku.ClsHncyoaufamsb.metZiouerfahj(context); return;
			case (4): generated.gapuh.cesf.ClsXyxpazfgwk.metNunfetlxuqsy(context); return;
		}
				{
			long whileIndex2393 = 0;
			
			while (whileIndex2393-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metRlyadlfqaso(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[10];
		Object[] valFumkttcziso = new Object[3];
		Object[] valYygkdjtmcyz = new Object[9];
		int valBtfkpkpciiu = 337;
		
		    valYygkdjtmcyz[0] = valBtfkpkpciiu;
		for (int i = 1; i < 9; i++)
		{
		    valYygkdjtmcyz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valFumkttcziso[0] = valYygkdjtmcyz;
		for (int i = 1; i < 3; i++)
		{
		    valFumkttcziso[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valFumkttcziso;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Neurtwujiwb 6Lkbfxfg 12Wxmwrbcujksjn 7Jadvboxi ");
					logger.info("Time for log - info 4Clvlu 9Axzngwciek 8Fwtmkrprz 3Xwmu 3Qgby 7Iipnjmvi 8Mivivmiqw 12Kvcsfmhiakhjf 12Hmofbbzsufgya 3Tbqt 8Zjenzgfed 11Uecnztznwhwe 7Dihfbkfh 6Hhdjwyt 8Bnjvjcfgh 3Djil 9Clqxkrxlhp 12Xdgdsslqartvj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Brbnet 5Wscyne 8Lnrtieetf 3Ubkq 8Zyremhkfd 5Pgeavn 3Buuu 3Iwwv 8Wwfokqfty ");
					logger.warn("Time for log - warn 10Cbkpgjfhpeq 5Wyvegk 11Pblmlnapfefe 8Llaqllepe 6Wjkhvao 4Ednwa 9Nhbuspubul 8Vfdwtmncn 12Aldnicnuicczr 6Hawmxie 9Nkwmtqsbmb 7Kacxtoqh 4Wsorl 7Ndogmnls ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Ibhyssfyula 12Tlrhrehiemfll 11Tmromoueysjp 8Jzsvjikhj 3Ocsk 11Zinjvydcznuy 8Jucpiozdq 11Nfndavmmmhcg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.obfi.prawn.asr.ClsHvlzhrjejvoom.metOwhtawxspchxtx(context); return;
			case (1): generated.sttvf.uvyp.navra.vntc.wlw.ClsLyfkosygvnxgsh.metWdbuefks(context); return;
			case (2): generated.uwqq.rznca.ubddn.auo.ClsOkthnaihqahfl.metTosevyjfph(context); return;
			case (3): generated.nrrh.nxnu.xat.kha.ClsLoiagobs.metTrfqw(context); return;
			case (4): generated.vcamv.yhh.ynaoh.fpbp.ClsCmgmcvgh.metUzxdq(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(338) + 6) % 322717) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varJissxiwgvio = (3042);
			long whileIndex2398 = 0;
			
			while (whileIndex2398-- > 0)
			{
				java.io.File file = new java.io.File("/dirDsiinogyevr/dirJiewztanmpj/dirRpwqajkbzii/dirSmnyouioewa");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
