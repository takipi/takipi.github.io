package generated.cymhf.zmxu.aqlat;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsTwlvztmhvdbz
{
	 public static final int classId = 101;
	 static final Logger logger = LoggerFactory.getLogger(ClsTwlvztmhvdbz.class);

	public static void metXepcrhrku(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[10];
		Object[] valXgafxbeyrea = new Object[2];
		Set<Object> valLdxhtqyjakw = new HashSet<Object>();
		long valGpdfombmmoa = 991045382700076394L;
		
		valLdxhtqyjakw.add(valGpdfombmmoa);
		
		    valXgafxbeyrea[0] = valLdxhtqyjakw;
		for (int i = 1; i < 2; i++)
		{
		    valXgafxbeyrea[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valXgafxbeyrea;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Bllcuov 5Fgtnqj 3Hznz 4Cbozo 11Pohnncmskbnw 3Kvsu 12Gwtpjodnvuait 10Zvdonkjmsny ");
					logger.info("Time for log - info 3Ywau 6Dxxokcp 8Dtelpfqqz 11Ymwvjmsrljwx 8Nxsjhqwnk 6Xqgyffb 9Wjqehjhgfe 11Wtvylyunstbb 3Fxje 3Wcup 9Jwmhhclnuo 8Tdthbfsuy 3Tcpx 11Mniuvnawtgqh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kfvy.ymxa.end.hazk.nwqfn.ClsXakhsfoyrlse.metSihzklw(context); return;
			case (1): generated.kivyr.smd.affpo.ClsEqlzjivgvsoafb.metFtrfvpusk(context); return;
			case (2): generated.jczh.tiox.sfe.qsygg.ClsFcpmoenzb.metMdeingizamgtx(context); return;
			case (3): generated.ulj.ogxe.vbwy.ClsQmshqdjff.metNngxyjxf(context); return;
			case (4): generated.jzpii.ixwl.ClsCvgimgq.metBcgopgf(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirYvgzduxcpbr/dirVrzbjqpuoje/dirYgzykqueuwi/dirUjxcmwurkmd");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numHursdyqilkp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex21822 = 0;
			for (loopIndex21822 = 0; loopIndex21822 < 1456; loopIndex21822++)
			{
				try
				{
					Integer.parseInt("numXrvbgouryya");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex21823 = 0;
			
			while (whileIndex21823-- > 0)
			{
				java.io.File file = new java.io.File("/dirGlhvkydejhe/dirVjpdlsxszev/dirTiwiabbmhbh/dirSyldfrbfeci");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metQxzvxpynrcfku(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[8];
		List<Object> valOysugkewyrc = new LinkedList<Object>();
		Set<Object> valKgehrenqqhn = new HashSet<Object>();
		boolean valKrusdrcliua = false;
		
		valKgehrenqqhn.add(valKrusdrcliua);
		long valGofaluayewb = -4482795559305147719L;
		
		valKgehrenqqhn.add(valGofaluayewb);
		
		valOysugkewyrc.add(valKgehrenqqhn);
		Object[] valWtaladrkuuj = new Object[3];
		boolean valLsenqlzeztm = false;
		
		    valWtaladrkuuj[0] = valLsenqlzeztm;
		for (int i = 1; i < 3; i++)
		{
		    valWtaladrkuuj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valOysugkewyrc.add(valWtaladrkuuj);
		
		    root[0] = valOysugkewyrc;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Spjlem 7Wclkzovp 5Clvsdq 8Tepywsaam ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Wjebtemllpi 7Uvccvxvl 12Ahrzwfypqemhw 7Iucmdgkw 5Touraj 10Rvwzrckkskj 3Lprw 9Smoaaemrya 6Dwlwzdq 3Zxfi 6Pmebrks 9Bysawdujly 9Wkteyboopa 6Wxfjpnc 7Xjimvbdi 12Qizohyiqghqdw 5Pwqyof 4Bcffw ");
					logger.error("Time for log - error 3Ftwx 9Lnjvvehicc 3Iyxb 5Fljehm 3Cwgy 4Efocq 9Kitcmqifnh 8Pdlcqlaby 7Fyywyrzr 3Kyst 6Mlneldf 7Ugwvepmp 8Zaxuadqkm 7Hyyxxhoc 12Lytsoiouipawe 9Wgrecetvip 8Rftdqzmdy 7Edeinjct 4Lltni 11Qryyiqjtpuda 9Fkoqjccmky 5Yiulnr 7Foxeqpnj 6Aduyqls 10Quhizzgqlnd 5Fuioef 9Lrtsllxlsf 9Xazqacythv ");
					logger.error("Time for log - error 9Ylksqzrypj 7Tggazsfw 5Plezej ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yfyks.sksk.asgi.ClsXzaehxcicrdskw.metEpcsazywkgm(context); return;
			case (1): generated.tmohp.pbwu.gfhxq.zdkm.ijx.ClsDimqu.metSwhvdjgcvud(context); return;
			case (2): generated.lgwo.spy.sqb.ClsVtibt.metQsyszdgtltoif(context); return;
			case (3): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
			case (4): generated.ldtgt.vdfx.cdz.lkx.ClsLvvwnymti.metFkrjypkkw(context); return;
		}
				{
			long varKsibxuaayht = (Config.get().getRandom().nextInt(523) + 0) - (Config.get().getRandom().nextInt(152) + 6);
			if (((7845) % 183712) == 0)
			{
				try
				{
					Integer.parseInt("numQgnfdljmjrm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metIzesypeo(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valGicfchedwkk = new HashMap();
		Set<Object> mapValPcgikvoftxy = new HashSet<Object>();
		boolean valBdzskypoyiv = true;
		
		mapValPcgikvoftxy.add(valBdzskypoyiv);
		long valGobbuozgggn = -2936253678420833389L;
		
		mapValPcgikvoftxy.add(valGobbuozgggn);
		
		Map<Object, Object> mapKeyIjkbdfqaoic = new HashMap();
		boolean mapValJkbwoicnieb = false;
		
		long mapKeyIxrtclqwhjl = -8423893509383693529L;
		
		mapKeyIjkbdfqaoic.put("mapValJkbwoicnieb","mapKeyIxrtclqwhjl" );
		
		valGicfchedwkk.put("mapValPcgikvoftxy","mapKeyIjkbdfqaoic" );
		Set<Object> mapValQoeawcuezno = new HashSet<Object>();
		String valSobmhdlpuyy = "StrMjdragkeyhq";
		
		mapValQoeawcuezno.add(valSobmhdlpuyy);
		
		Object[] mapKeyAdcemfjruck = new Object[11];
		int valLbjbtjrcxju = 588;
		
		    mapKeyAdcemfjruck[0] = valLbjbtjrcxju;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyAdcemfjruck[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valGicfchedwkk.put("mapValQoeawcuezno","mapKeyAdcemfjruck" );
		
		root.add(valGicfchedwkk);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Jpbimscxves 10Lzkvxulshwo 6Vsqwvfv 3Vcij 4Xixlo 3Rzpz 6Hbheqke 3Mclh 8Clwluyhkr 8Romcjqmgv 4Gavmh 7Hjpbdgin 10Oibdtrzlgiz 4Istvn 8Duyzzpyyp 4Gvnnf 7Fsvclnhr 7Kznszcss 10Mxvzcnnozqv 10Lgkdmclmtkm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Dwqiuljc 6Uneeplq 11Vsgnzdrchbzu 12Smxufaqvovgvm 8Fjaayxsts 8Ceurfqyjd 4Pdkid 7Wiyepqcl 11Vbumxpvnasmk 3Tldm 8Tivhkprac 12Gnzzxxzfusaln 8Lbjmncsgf 12Khmewabiafhkh 4Wpwec 6Mnllgqf 6Gyugyew 10Ulyxoczixlf 6Pziutwh 10Qeapygtsbwd 10Txkoxhoddyx 3Vyyf 9Adkticyccb 6Jnbnted 8Cguxuysih 6Mpwzaly 5Fibpbv 7Gapxyxhv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Knkrbm 8Jdzxmrrpp 8Ypblzbrhf 4Nmffk 5Jnvqhk 6Ctfqlsa 8Iqiuuyrxp 10Ezbvhcsdvyb 4Hrctv 5Geitay ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.crkmz.uuny.smq.vvmxn.khxb.ClsQbvzuhroxdituh.metAiybrixueywscr(context); return;
			case (1): generated.vqli.xqs.ist.rcg.ClsUlfrrjkk.metUracnapyxnrd(context); return;
			case (2): generated.cymhf.zmxu.aqlat.ClsTwlvztmhvdbz.metQxzvxpynrcfku(context); return;
			case (3): generated.vbpvl.ppexe.hnrdr.zcxzm.ClsCvshjbmkqrb.metJcfyp(context); return;
			case (4): generated.kmvk.gapzv.hffa.xaqj.opr.ClsXtcqpna.metRbrfxbrd(context); return;
		}
				{
			if (((5527) - (5064) % 727749) == 0)
			{
				java.io.File file = new java.io.File("/dirAqkydeqojed/dirHqelnrhgfyz/dirFaxxdvenckl/dirFemcqeygrdx/dirQqnroggmwhu/dirLfyhofwfbic/dirCwnjaqemgsz/dirKpybytyevmc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metGeiteeydip(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valYnyjogtacnk = new Object[9];
		Map<Object, Object> valAshwldkvrib = new HashMap();
		String mapValWzohmvsbaxv = "StrAaoxkqhfssk";
		
		int mapKeyTnmeblensad = 977;
		
		valAshwldkvrib.put("mapValWzohmvsbaxv","mapKeyTnmeblensad" );
		boolean mapValEvuyubgrsfr = false;
		
		long mapKeyRpvxdbxqhdm = 3223801103122592441L;
		
		valAshwldkvrib.put("mapValEvuyubgrsfr","mapKeyRpvxdbxqhdm" );
		
		    valYnyjogtacnk[0] = valAshwldkvrib;
		for (int i = 1; i < 9; i++)
		{
		    valYnyjogtacnk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valYnyjogtacnk);
		Set<Object> valUhhwznpntqy = new HashSet<Object>();
		List<Object> valDpflkxqrpvz = new LinkedList<Object>();
		long valVboraacdxnn = 4612758426139929789L;
		
		valDpflkxqrpvz.add(valVboraacdxnn);
		int valPdvvjvdqjht = 615;
		
		valDpflkxqrpvz.add(valPdvvjvdqjht);
		
		valUhhwznpntqy.add(valDpflkxqrpvz);
		
		root.add(valUhhwznpntqy);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Kmscxcdf 9Owsqlocmrm 12Zojoihxtcmspy 3Mfly 4Lopaj 12Yzycwckwvxrvv 5Gfrocr 4Mrljd 7Chdlrgta 4Cspkx 8Tjljkjdts 9Zoqabeicct 3Rbwn 5Ooqhdv 8Wzylowlrf 10Ooptzgmjomt 5Dobilv 7Cgfeuzkv 5Hgydvj 9Mtwxlsocqy 11Qevwomnjqnjl 10Yyvltlliwtp 8Paownucvj 3Ryeb 7Coudsdbz 7Muyysnld 7Xfdecvgt 5Mpibnw 4Ismfy 4Ekxyv ");
					logger.info("Time for log - info 12Sdjjozcuamkel 11Ntmpsngsucng 11Mutwekqfzuju 6Xrvtfmx 11Sygwkcovbgpb 9Lxxxdctpfe 6Bkgkkua 8Iimwedwjs 5Dffvzn 3Fnus 12Kmqddfyqloerh 7Abbpqzkr 9Jjzvlohyni 4Picos 4Jibtt 7Zvmswwop 11Xjqobtyiouam 4Vuaox 10Nqqvvlktefw ");
					logger.info("Time for log - info 6Uznxsjb 4Empit 10Rehmaopsref 6Jyqavxp 6Inguslo 11Aitwdjerfxwt 5Zlveoa 11Vminpylftabt 8Dkkkjlklf 12Cbejhkxvynpvu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Wvvpdgzfw 11Syacnmquwxwh 11Synaouldngwu 8Djvodmwpe 3Ukot 5Avaaxn 7Ierpwohz 8Ltlacvmdu 9Fmpylubkyq 8Gcotzbrdl 4Vozqm 8Hiqcmzwfi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mao.kidk.mlsjr.hew.xst.ClsEfomkejxcxzr.metEruurpx(context); return;
			case (1): generated.aby.eyq.viq.flsc.ijccw.ClsKeovzqbtjs.metTizqtcinnozd(context); return;
			case (2): generated.lxrj.lts.csk.iew.ClsCagmzsja.metOondcg(context); return;
			case (3): generated.vbpvl.ppexe.hnrdr.zcxzm.ClsCvshjbmkqrb.metJcfyp(context); return;
			case (4): generated.yfeni.otsaz.fkhen.upca.zzv.ClsWbxrghwufimrgi.metMmhojtteok(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metJxghyc(Context context) throws Exception
	{
				int methodId = 4;
		Object[] root = new Object[11];
		Object[] valIroawskolna = new Object[5];
		List<Object> valXxezkilvlbi = new LinkedList<Object>();
		String valRqlbjbuzuqr = "StrTkdmtiwwnrl";
		
		valXxezkilvlbi.add(valRqlbjbuzuqr);
		int valIahfxacmgmw = 331;
		
		valXxezkilvlbi.add(valIahfxacmgmw);
		
		    valIroawskolna[0] = valXxezkilvlbi;
		for (int i = 1; i < 5; i++)
		{
		    valIroawskolna[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valIroawskolna;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Hlfuhwebse 7Cqyvwken 4Xatne 9Ikwvvlzqmv 7Qpbhqfgi 5Hgbrjq 4Ybqug 9Nulfuggnjf 11Tlwifemwwcoq 6Sgufiup 5Jcgstg ");
					logger.info("Time for log - info 4Hcapx 7Fkxvkgvb 4Swwak 10Rxtcwubrvva 6Hpidkqy 7Prjaxnao 3Tubt 11Ursontnfehuc 11Ighzlmawlphb 3Mxsr 6Jzcdbiv 8Bgtcnfttn 9Ngoiwudzzc 10Ilmnpoqazsl 12Zwvriypecwbfh 11Bnbdmpqkzssk 9Oxuynrtqcp 6Ccsvjzz 6Xigpviz 4Uvuvh 9Vcidzfxsyy 5Jcevoe 5Uhodne 3Gmfy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Inza 8Wjrcjcumb 12Hgtvimihldqsi 3Lkry 5Zbhptx 3Cxii 10Hexlwhsjiqm 12Toiyssijoepks 5Uprgfl 9Zofuwscgxt 7Ogqhrfhr 12Cychsqdtkkncd 9Olzpqhyyyp 6Jqkzrsg 3Kzye 8Fxigwgozm 11Dwpzqvrncxqu 3Dydw 11Rnqawjjqqjyh 5Kfcbbf 4Qxudr 3Rpfg 6Qmtaxbu 6Rphswqe 6Sgdfxwg 4Tlgot 7Pibquims 8Yqzocemik 12Jjrjiscaeqzwb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zljq.wuqwj.ClsEloxjpaim.metYpqwrjj(context); return;
			case (1): generated.pgfis.zew.ikgq.ClsEgsupkocifpi.metYobadnrmqm(context); return;
			case (2): generated.lgws.kxkr.zse.myye.ClsAnryfbudqi.metYtmxrfk(context); return;
			case (3): generated.laaxy.myh.ClsSglobn.metCwzfwuxvrtwmm(context); return;
			case (4): generated.qrzc.frg.utv.itv.ClsGoyvsxo.metOllflngqrpzh(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numOojeeaqdwsb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex21849)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
