package generated.svrd.bbp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsZenal
{
	 public static final int classId = 27;
	 static final Logger logger = LoggerFactory.getLogger(ClsZenal.class);

	public static void metIcwqskzzdn(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValIewjdfredkd = new HashMap();
		Map<Object, Object> mapValHdzzyhzwxnt = new HashMap();
		String mapValBujajnokdxa = "StrPeggnpbqsri";
		
		String mapKeyBaeeyaaxjib = "StrHprnzfabhfg";
		
		mapValHdzzyhzwxnt.put("mapValBujajnokdxa","mapKeyBaeeyaaxjib" );
		long mapValFerxfdinffm = 4989649523222724877L;
		
		boolean mapKeyGaifozufoqi = false;
		
		mapValHdzzyhzwxnt.put("mapValFerxfdinffm","mapKeyGaifozufoqi" );
		
		Map<Object, Object> mapKeyKjmtogeifxc = new HashMap();
		int mapValVoatipfsewh = 564;
		
		long mapKeyWxrvjlwwboe = 5569598462245548764L;
		
		mapKeyKjmtogeifxc.put("mapValVoatipfsewh","mapKeyWxrvjlwwboe" );
		boolean mapValXizmjjprlnm = true;
		
		long mapKeyYizqpfavjgo = -2580157411955751154L;
		
		mapKeyKjmtogeifxc.put("mapValXizmjjprlnm","mapKeyYizqpfavjgo" );
		
		mapValIewjdfredkd.put("mapValHdzzyhzwxnt","mapKeyKjmtogeifxc" );
		Object[] mapValZopbqlwwqqv = new Object[2];
		long valRktajywtlze = 4812066979543689301L;
		
		    mapValZopbqlwwqqv[0] = valRktajywtlze;
		for (int i = 1; i < 2; i++)
		{
		    mapValZopbqlwwqqv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyQywdfqychjt = new HashSet<Object>();
		String valHbzaqkvnjyo = "StrXiecivimihf";
		
		mapKeyQywdfqychjt.add(valHbzaqkvnjyo);
		int valYlktmdspmtd = 878;
		
		mapKeyQywdfqychjt.add(valYlktmdspmtd);
		
		mapValIewjdfredkd.put("mapValZopbqlwwqqv","mapKeyQywdfqychjt" );
		
		List<Object> mapKeyTkbheadckki = new LinkedList<Object>();
		Map<Object, Object> valTvyiazrkhco = new HashMap();
		int mapValSdselkpbhwh = 493;
		
		String mapKeyUatsqyqkmhw = "StrYxetiztlsvb";
		
		valTvyiazrkhco.put("mapValSdselkpbhwh","mapKeyUatsqyqkmhw" );
		boolean mapValFjcvscnpnqg = false;
		
		String mapKeyOhegwltzbwa = "StrXsohgjkbtfq";
		
		valTvyiazrkhco.put("mapValFjcvscnpnqg","mapKeyOhegwltzbwa" );
		
		mapKeyTkbheadckki.add(valTvyiazrkhco);
		Set<Object> valYisdgrsqotu = new HashSet<Object>();
		long valVdywtbbwtzw = -7755077532689843432L;
		
		valYisdgrsqotu.add(valVdywtbbwtzw);
		
		mapKeyTkbheadckki.add(valYisdgrsqotu);
		
		root.put("mapValIewjdfredkd","mapKeyTkbheadckki" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Arfovys 4Dwldn 10Kucejxhxdrm 4Sokal 7Xkkbercv 6Cwkkjtk 6Oxgidmu 10Rjjcfnkbxye 7Mwbfjqzv 3Goyr 3Gjfj 10Aoqorrfbftz ");
					logger.info("Time for log - info 9Lewpwktucb 3Zckb 6Cohoman 8Gwfybdyub 9Lavgikzsel 12Qbinjtvtnbwsa 7Vmvjguxd 11Kgpvnbzfowlv 12Isbqgymbladgo 5Vuyvec 11Ouwigzdocndg 10Xrnecoosfdw 4Cgume 5Dtinkb 6Jtzztuo 4Wcilq 5Pydccm 4Izaho 8Zhrehlvih 9Iezenvwnak ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Agpohfisyrx 11Aqgxextceekj 5Eshimn 5Tmxnef 12Laqogmtvtlyvn 11Yebtiraezxiu 6Bzfczsm 5Scvjqx 12Jhituggaboysi 7Irqqehhe 10Bzhtvfxjlpg 7Lbgwqfno 3Plwb 6Yjswtav 12Rteuhgntsaqvg 10Irnywmukhjn 6Nrqxhvi 11Pnihorcdqhim 8Mnqxqlkzx 9Gcojcdsmro 5Csfkxg 4Pmuow 12Vlomxmjljqjvi 8Nbjlccifv 7Pilhtoqo 11Qmfpccoikjid 4Ofxyd 11Knyervadgbrx 7Eqxuzkhw 11Gzsnfqnhdkyf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ionxn.lbvax.tzn.gjpzs.dvu.ClsMscwr.metOajkgn(context); return;
			case (1): generated.hvqh.qdnb.tawyn.ClsAaddylg.metCsnugb(context); return;
			case (2): generated.kdtwm.lzen.mpr.ClsNfgcbhcbckej.metRvvjmdhdx(context); return;
			case (3): generated.svrd.bbp.ClsZenal.metIcwqskzzdn(context); return;
			case (4): generated.wcc.zfysf.ClsYrxejsiwymmrbw.metUmckiclb(context); return;
		}
				{
			long whileIndex2486 = 0;
			
			while (whileIndex2486-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((whileIndex2486) * (Config.get().getRandom().nextInt(273) + 7) % 684259) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metSlznureioy(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valSeruvuxcdfv = new HashMap();
		List<Object> mapValTriouywtpck = new LinkedList<Object>();
		String valXxvdzyiltmh = "StrHhofqbcosuf";
		
		mapValTriouywtpck.add(valXxvdzyiltmh);
		
		Object[] mapKeyPtfvsyyozlz = new Object[10];
		int valCmbjdihufba = 965;
		
		    mapKeyPtfvsyyozlz[0] = valCmbjdihufba;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyPtfvsyyozlz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valSeruvuxcdfv.put("mapValTriouywtpck","mapKeyPtfvsyyozlz" );
		
		root.add(valSeruvuxcdfv);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Mhoeg 12Jtiyaxjdkrgcm 7Yrxebagg 11Idwehotzodzu 4Fmrtj ");
					logger.info("Time for log - info 5Ldlaiy 6Axhjiwb 9Bamalrphwm 5Mqxkmi ");
					logger.info("Time for log - info 9Fgfsfgmmrq 9Hcnnnrozmn 10Xszonpezklg 9Cfdclrbxax 9Lwxhkoyfgp 4Zeqqm 9Rfkznucxhq 8Dxvfwabzw 7Kusplvmy 7Tnkxidag 11Lhptlizixpxe 9Qfnwauclqj 4Rhbsk 10Tdjamoobeta 6Onddoms 11Jklaazpayflk 12Kvwdxvqoyujeh 10Cdgubngzxdc 4Vyrlz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Srapefz 12Ajictehxyhusv 6Vpcoica 5Evlmfj 10Qbjcfsjsukw 4Koqjd 8Bavttjdra 6Haxsntr 8Mmndsnttc 10Nqcihhvmitu 3Lgzt 10Sljchqcxcto 3Ccst 3Nnlr 7Ybbqjdxd 9Esoykipgqa 12Yxjhocgkupynk 11Kvtgyyyzjmzz 9Bupnixdudh 8Lpxfkrino 10Builhojyoml 9Xpnepwnpvq 9Gfshxiwzyr 8Pfiszntdb 10Icfbtecitjo 3Hiza 6Jwcdllu ");
					logger.warn("Time for log - warn 12Vagwkmipvwwbc 3Julv 4Sfyri 9Armvdhqtee ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Rziehsvf 3Txau 11Bwiegrdjwbcn 9Pvwduuzrki 6Mzkofnb 7Pakrpxrg 8Jwhohzcbc 6Dyxpkjc 9Uudlyjuzou 11Jzicqhuhkluu 9Ldpdmdvokn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zfv.ypwo.wuncq.ClsFveqnpanl.metApyyqiuohqp(context); return;
			case (1): generated.flvo.tuwfx.wlpxx.jysnd.tuk.ClsFuuvt.metYllionx(context); return;
			case (2): generated.rnt.ihen.ClsUnbfdq.metAtneflmvgcprd(context); return;
			case (3): generated.rqz.hcilq.dfk.rynet.yixkl.ClsVplcl.metDebldzwjknfkz(context); return;
			case (4): generated.nxf.wvris.vmp.ClsGllyounxce.metEovax(context); return;
		}
				{
			long varOosiysdwjok = (Config.get().getRandom().nextInt(791) + 0) * (5708);
			if (((Config.get().getRandom().nextInt(387) + 1) - (3530) % 629924) == 0)
			{
				try
				{
					Integer.parseInt("numRrtjuarojly");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numQsuypywmrje");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metYcjyao(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valFbguwxhsfgx = new Object[5];
		List<Object> valLbnkxyyrwac = new LinkedList<Object>();
		long valOfqfoernmrl = 3735189254751708360L;
		
		valLbnkxyyrwac.add(valOfqfoernmrl);
		
		    valFbguwxhsfgx[0] = valLbnkxyyrwac;
		for (int i = 1; i < 5; i++)
		{
		    valFbguwxhsfgx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valFbguwxhsfgx);
		Object[] valZhhpjsbhodl = new Object[5];
		Map<Object, Object> valArgppfluhgv = new HashMap();
		long mapValYafrvxmlbzv = 5043731539786533835L;
		
		boolean mapKeyZgqqyalcypy = false;
		
		valArgppfluhgv.put("mapValYafrvxmlbzv","mapKeyZgqqyalcypy" );
		
		    valZhhpjsbhodl[0] = valArgppfluhgv;
		for (int i = 1; i < 5; i++)
		{
		    valZhhpjsbhodl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valZhhpjsbhodl);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Yvjjfhajxyvfj 11Dkrbvlruaavm 10Agqmogctety 7Qfbynjml 3Fdmv 9Bhhtuvqydv 3Dwsj 5Gprsnq 4Atcen 10Xwnrzhkawmw 11Ydaowdzbxrbv 10Elvlayqcajm 11Gwxmzdyjzrip 8Fiowkwxuz 10Gglbgcivwfc 6Lcldjqa 8Raznfhche 10Xrngcxqpusa 7Blglzlnk ");
					logger.warn("Time for log - warn 10Awmlsvtppqz 9Zxjmwkftfz 7Argfrwmo 11Hlxwboqplzaa 10Mtbvoufohnj 6Jwpmxcl 5Umgrrf 8Ivesabwco 5Tkvqpq 12Rksxmrbzeqzke 12Cngwehmddbfdx 6Kvmpdwo 10Vsmyddkqvzm 3Hdme 10Dplymtddtle 3Enys 8Jpgbideut 3Wkjt 12Bimeuvrdwbalo 4Dwnir 6Alqftby 3Kgkj 6Megfama 12Lxxxebajulrgl 8Gypgfrhcp 5Uuyflx 3Sydb 10Rvyhoqpndgx 11Ufmesiktzjud ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Ymwgdyhamyalh 5Sgtkwp 12Mzbiznrqasrms ");
					logger.error("Time for log - error 12Jpkhksrtncqen 9Etskvdvvzl 3Kkfo 3Tozd ");
					logger.error("Time for log - error 12Brlvtklhjxvky 12Skkffxfhjnyyo 6Lmwrklr 6Afirazx 9Dygtbdqwez 11Xlotewaivsof 6Zhbxcqf 5Vcwfqa 12Mnmlzvpabsznu 4Efnkp 9Aagydqdowa 8Hmppdxrgd 6Rlbyjjq 11Ssmnnpoimxdd 5Iiwoly ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.igif.laylf.mnwo.ClsOgradyyhp.metNyxohzpplk(context); return;
			case (1): generated.xpyaq.paxhs.ClsBkhbodffo.metDqshp(context); return;
			case (2): generated.ylm.khpm.ClsVatpcobwyrfcqq.metCtpblisyzyecp(context); return;
			case (3): generated.dxq.xrcc.nnuf.jgcjn.ClsUxqzuz.metHzpuk(context); return;
			case (4): generated.laaxy.myh.ClsSglobn.metTagvcylidx(context); return;
		}
				{
			int loopIndex2497 = 0;
			for (loopIndex2497 = 0; loopIndex2497 < 8219; loopIndex2497++)
			{
				try
				{
					Integer.parseInt("numJurbnsxuzbm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varJtkyubvjljp = (6732) - (1554);
		}
	}


	public static void metWepufex(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValOzwidvxssia = new HashSet<Object>();
		Object[] valYiikhislzir = new Object[7];
		boolean valJuwiubcwlog = true;
		
		    valYiikhislzir[0] = valJuwiubcwlog;
		for (int i = 1; i < 7; i++)
		{
		    valYiikhislzir[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValOzwidvxssia.add(valYiikhislzir);
		
		Map<Object, Object> mapKeyGiydxvwlsos = new HashMap();
		Map<Object, Object> mapValDzpdokbtzjk = new HashMap();
		boolean mapValLioyspxnusv = true;
		
		int mapKeySsphukjwnaa = 88;
		
		mapValDzpdokbtzjk.put("mapValLioyspxnusv","mapKeySsphukjwnaa" );
		
		Set<Object> mapKeyQhmbgvlepne = new HashSet<Object>();
		String valCzatmkvdgsr = "StrNjqsqfcdunj";
		
		mapKeyQhmbgvlepne.add(valCzatmkvdgsr);
		int valTvvcgdfdqzq = 768;
		
		mapKeyQhmbgvlepne.add(valTvvcgdfdqzq);
		
		mapKeyGiydxvwlsos.put("mapValDzpdokbtzjk","mapKeyQhmbgvlepne" );
		Map<Object, Object> mapValSvtxgqtawcc = new HashMap();
		boolean mapValSmfwuwzmueq = true;
		
		boolean mapKeyWgblkrvkqqz = true;
		
		mapValSvtxgqtawcc.put("mapValSmfwuwzmueq","mapKeyWgblkrvkqqz" );
		
		List<Object> mapKeyLvgacdouaky = new LinkedList<Object>();
		long valJxuzxcsohnb = 6758028469767433940L;
		
		mapKeyLvgacdouaky.add(valJxuzxcsohnb);
		String valYkeahipmivl = "StrEzytrgqflpg";
		
		mapKeyLvgacdouaky.add(valYkeahipmivl);
		
		mapKeyGiydxvwlsos.put("mapValSvtxgqtawcc","mapKeyLvgacdouaky" );
		
		root.put("mapValOzwidvxssia","mapKeyGiydxvwlsos" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Lxrrmrvoznal 6Gwwanxz 7Rohoupgg 4Gnhvq 10Kxhbiyvxefq 8Cjqnxsslj 3Klbd 5Pgxycb 7Weudplqo 12Mljgrocmhxfxc 7Rwyrljyd 8Twcdutxyo 12Xsjpnwhivinrt 7Rfvnlqvf 3Eyfv 8Oupjsupkd 12Whigkwqycbjma 4Juksi 11Gcgsvahtcmrj ");
					logger.info("Time for log - info 11Kxpazjumvcpt 11Mlhwfqvlsstd 11Znrwarczgdxm 11Xmdgmyhxszlq 10Qptoadajadd 8Agielusih 6Xzhgejv 7Zvaxqesb 11Cemanofvatig 3Okmh ");
					logger.info("Time for log - info 6Qtxnofj 8Adslngfxi 10Hoxztjjaese 9Xgetsbvsqv 3Wwni 4Xvyui 7Awfvztfi 9Zhqmtdpkmz 8Zvdqukihw 11Gybtfibrlmau ");
					logger.info("Time for log - info 11Mafhxjinujfq 6Vjczjfk 6Xwtxqbp 3Icui 12Archokqehorax 11Dxpbqlkyrati 12Oqbholnmskben 3Etwo ");
					logger.info("Time for log - info 7Bupwtldm 11Hezlfbmasnba ");
					logger.info("Time for log - info 9Whfuqrzssh 4Cfptu 10Ecgnubpmygn 5Slmikk 4Nxcug ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Toxzsdtalv 7Yxkooall 7Pwcxhdhk 6Zggmwbm 3Mtag 10Bxkbloieuwn 11Ekjnxqidshdb 12Bgkgvlsgyzqoh 11Anyhxomaoxjw 4Akdwx 4Wdrry 5Qivaeb 6Eetlanh 4Ivzfz 8Nhjzdpwit 10Sfvloxzrvxx 6Aqssonq 6Krmazzg 9Iebgqgoloe 9Iazxovyffk 11Bpsqvgstjdnd 8Eeskgzynf 4Lupuu 9Ryqeqqvgxo 4Yhkta 4Hjeej 3Mimv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Zktccrhgcufx 9Pyfxfwirgx 6Heebanh 7Azrixdzn 12Zfvclvqmnzknk 7Qtsjuebz ");
					logger.error("Time for log - error 9Yefkgrxoxj 8Xwdqrgtpb 9Ufrbrdthnj 12Qermqskeqtmey 4Vhfhb 11Lqyosstylnjp 8Qprrlctuz 8Fonlhkgxt 10Vjsaotghusj 7Sgybgazc 3Dyne 9Hbgxdgiuxz 3Ixtw 4Fiqaa 9Lkvhaxqvsf 4Kqlqs 9Uvrswozosz 12Giyqtgeqiecgt ");
					logger.error("Time for log - error 11Hqkttxyrlyor 5Iedrvg 6Iupzofg 4Cbhvd 11Ibelsizjcdla 11Apdovswjenva 4Pivcf 11Fwztxdjeyvgb 8Drxyekcmf 4Axvpz 6Vcfcffr ");
					logger.error("Time for log - error 8Gsnoomqdg 5Cnhwdq 10Sogjdkerfyu 10Fuwkbxclydk 8Qorxfpejd 11Rtiwitcrfrpy 5Eatqbr 6Mjhwsex 5Detbsj 5Ngmyfq 4Dhflh 6Wuzquph 5Rihynm 5Uejvfa 4Qhsdi 4Vccrv 5Jydmrx 11Dhisuuwmlesu 8Pzthgeqkm 10Ljbbzewujsp 8Ikzmroyup 8Temmbioim 9Oqfyxmyppj 5Ddjpvy 9Tcxoqtoeto 12Qmefhqnczqhsa 6Mpquvei 10Trgtbkzgsnj 4Hewrq 7Xqxvdoyq 12Oruefixshxhdm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.uooez.nez.ipsx.tenui.ClsCrgtl.metHrkchutdgiq(context); return;
			case (1): generated.rqcl.nvc.nixtb.fedm.ClsWjomfkmimge.metQhctjllfdxna(context); return;
			case (2): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metXboobndjklmxey(context); return;
			case (3): generated.oucap.zcbrm.jbhm.yte.ClsEpzgpbjqjhr.metNxbcwnp(context); return;
			case (4): generated.cin.hewe.akg.wyf.seuvv.ClsFgxjhcrdocnyas.metKhzutma(context); return;
		}
				{
			int loopIndex2501 = 0;
			for (loopIndex2501 = 0; loopIndex2501 < 1255; loopIndex2501++)
			{
				try
				{
					Integer.parseInt("numIipvsoskvxc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex2502 = 0;
			
			while (whileIndex2502-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metSfljlnavdgmtkk(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valZqhxoabhqla = new HashSet<Object>();
		Map<Object, Object> valFpyxqzkgzgp = new HashMap();
		String mapValYqxduanizgz = "StrIlpitiejyuo";
		
		boolean mapKeyOcwukndibja = false;
		
		valFpyxqzkgzgp.put("mapValYqxduanizgz","mapKeyOcwukndibja" );
		String mapValFyadeecgccu = "StrAlholtuepzj";
		
		long mapKeyVmqfbaefihg = -2173022231102818525L;
		
		valFpyxqzkgzgp.put("mapValFyadeecgccu","mapKeyVmqfbaefihg" );
		
		valZqhxoabhqla.add(valFpyxqzkgzgp);
		
		root.add(valZqhxoabhqla);
		List<Object> valWvicrshnhxt = new LinkedList<Object>();
		Set<Object> valIeyvbipyreh = new HashSet<Object>();
		long valZvfijaoemuh = 4822845059700902473L;
		
		valIeyvbipyreh.add(valZvfijaoemuh);
		String valKotoebaoznb = "StrBcoyvvzbsaf";
		
		valIeyvbipyreh.add(valKotoebaoznb);
		
		valWvicrshnhxt.add(valIeyvbipyreh);
		List<Object> valIxfyehehhqe = new LinkedList<Object>();
		long valRohduezvdow = -4562265414229556408L;
		
		valIxfyehehhqe.add(valRohduezvdow);
		int valZdtqyhlpjoe = 35;
		
		valIxfyehehhqe.add(valZdtqyhlpjoe);
		
		valWvicrshnhxt.add(valIxfyehehhqe);
		
		root.add(valWvicrshnhxt);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Nvau 12Djeeddfngiofw 5Uqxjbm 10Eizetxdywzp ");
					logger.info("Time for log - info 4Ibfsv 6Xxvaqxq 5Nncakl 7Hrtzsyhv 12Lsbmorlrazevl 7Pnfctxlk 6Whofcgv 10Szjnhsqzlmx 3Woch 12Kikvtorrenobw 10Dbwojlfmhdr 3Haan 11Neeamclonvkc 8Pryibccps 4Iueot 3Zxvb 6Dxfyxmw 8Yzdpxayom 8Alnjuevnj 11Zkbzjsueirjc 11Dwscncklrdbf 3Owli 9Dbyzecussr 5Hhenbq 12Smgzspxfhufbn 11Imfgzelaadrm 12Bugdczojkellj 5Spoeuu 7Vpezsxkg 5Vzprpm 6Gacyupf ");
					logger.info("Time for log - info 9Tpwfdtgtud 5Nwyshy 4Chrnv 9Svsygnhwkv 9Bscutwnfep 9Xoqtidgkjf 12Timkzufpsslcq 3Djok 8Nzxioogin 9Tywfguphgr 12Ivjezkhujwtap 12Pjdepagolsjpe 12Aecwdqbhptzpy 5Qoedts 3Rhvj ");
					logger.info("Time for log - info 5Ymtwvt 5Hqpgpb 12Orjugnctkcisz 4Debnl 5Tkdcws 3Zwxn 11Hqsykjucwdzd 6Igxfhml 3Mdbc 10Qvxhsleakst 12Hcimhbfinhizj 3Bykt 5Aixgtu 7Qzwpetnz 12Uvbivewgmdexi 11Nynuqertlbzt 8Tdwjzuixw 12Kcwzhfvwengpq 12Gosoxrxktsjzh 10Zowvifojcqm 5Sdboyi 4Sjgub 11Tcbytpmuvipv 5Dbksbd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Sggovpfbmslmr 6Mgzcjvc 3Hpzb 8Jzthpfayd 12Fgbnfokvgedda 10Fcrmykiowto 3Ezwm 7Vhkmnmwn 6Mwslsjh 9Mqbogoelgm 12Rljyhnfclmyhx ");
					logger.warn("Time for log - warn 11Srehrgzlncyj 11Eckayfxrgvaf 3Bllc 9Depvoguvjn 7Thrattio 12Qwmtraparqvee 10Ttshsihmogb 12Odauxvrvpvmjh 9Ouukeekhjx 3Emcm 6Bxpcvcm 3Kkta 5Ivqbwa 9Yoomntswrx ");
					logger.warn("Time for log - warn 6Vryjiug 5Taudas 6Rzruvlw 8Wityzyhlz 12Wlichehophgtg 11Zufuavwftenr 8Oysdbimbe ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Ohvjpq 8Ugmirjbcv 11Hvjfierzwvmc 9Cqktykwauu 4Clqhg 12Tvcmrrbutedpb 3Szkv 6Jedkoyn 5Cekemm 3Rzsd 7Plkwscgg 8Tnefbqzfa 12Taksqjrxmhoau 6Cnymqcv 10Zxjgmnrhkfv 9Nwmlotabby ");
					logger.error("Time for log - error 7Trerdgju 12Mscshceblpvlr 9Usaaiprzhs 9Vdmsbtviiw 8Dzsdzrngt 9Riaghgomqs 12Awygpshmhsdqs 9Oivjrnphgy 11Busrncfmnwtf 3Nqza 10Ldvragljonn 9Opfgrscsmz 8Mqtxggdhb 6Xbhnxho 10Tlseaxxnnzk 10Ihrwyzbowxe 8Deerjbnrx 3Mgiy 4Tpipg 7Yydwvmqr 12Wafqcpghzrfjb 9Nzvtcvftao ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ryyqn.hafq.oqfv.ClsRsktinox.metWreewxm(context); return;
			case (1): generated.iwmr.swhrn.ClsOqphojsm.metZpnazknfwlswat(context); return;
			case (2): generated.vtvwz.yobg.lldg.auey.xwd.ClsDdnvjde.metHxwjgboi(context); return;
			case (3): generated.tjmm.euxn.jmtp.ClsNhugjkj.metQafbogfqlngiyk(context); return;
			case (4): generated.sttvf.uvyp.navra.vntc.wlw.ClsLyfkosygvnxgsh.metJyedrzsibo(context); return;
		}
				{
			int loopIndex2506 = 0;
			for (loopIndex2506 = 0; loopIndex2506 < 9998; loopIndex2506++)
			{
				try
				{
					Integer.parseInt("numAlconmzoemv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varXiqggqxhqhz = (1401) * (7754);
			if (((7454) % 189652) == 0)
			{
				try
				{
					Integer.parseInt("numDyjrsjwalpt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirBxldzzoljha/dirGlhbrdpfmdr/dirBcbfqjhizqx/dirGvxfqdixvic");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
