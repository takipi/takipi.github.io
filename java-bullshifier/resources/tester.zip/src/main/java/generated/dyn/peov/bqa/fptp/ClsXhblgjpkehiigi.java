package generated.dyn.peov.bqa.fptp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsXhblgjpkehiigi
{
	 public static final int classId = 90;
	 static final Logger logger = LoggerFactory.getLogger(ClsXhblgjpkehiigi.class);

	public static void metEiaaqrx(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[10];
		Map<Object, Object> valAuoldsakfxo = new HashMap();
		Object[] mapValGsrtylctrbt = new Object[10];
		String valAndqzofymle = "StrPytwetrsskr";
		
		    mapValGsrtylctrbt[0] = valAndqzofymle;
		for (int i = 1; i < 10; i++)
		{
		    mapValGsrtylctrbt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyPgpdknealxe = new Object[6];
		long valRnqiuveqnnc = 5263210254379117415L;
		
		    mapKeyPgpdknealxe[0] = valRnqiuveqnnc;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyPgpdknealxe[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valAuoldsakfxo.put("mapValGsrtylctrbt","mapKeyPgpdknealxe" );
		
		    root[0] = valAuoldsakfxo;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Hzypu 11Ohpfcrjtowbp 9Cjqxhyiqup 11Hvbbpofsoadm 3Ucxz 6Azotzqf 10Slowftqhofq 5Osncgo 12Jxupzsrumewqq 12Yqsjyideujddr 12Hkgfjpplqtlzj 8Yizguodwg 11Ewedyjpxkkda 11Kyvvfzatyrtc 12Lwqbqnaltgaks 7Xhfqhtir 10Copekocjopg 4Gqmty 11Vjtrlihsidqw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Rmbizwoo 8Yinansviv 10Jexsgqjemki 4Ncrrn 11Pmkrgnwqvznm 8Clogtgtee 4Culsm 10Iuviearzfpb 4Rclhh 10Bmbrvrmgaqd 8Rzegczybd 11Vngmigpcicil 10Klzetpqdupz 10Iebpamaofua 3Ealn 6Pxizlgv 10Zctzwikeboa 8Wzftivwiw 7Pmfsxzjv 7Ttwefyfo 3Rivc 9Icqzcukhuf 5Dimrgx 8Igxnpdzqc 4Vyhth 10Hhdwknwmcmr 4Hoaxj 12Veufjwciocrxy 12Zpgxgivwhnxal 7Bgqhgxqq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Lnbepftlbgfgm 12Zbljrkcjvpmgc 7Geuagnac 7Krckbsbs 9Lpxwxahrbk 10Uffdxpmvpkr 5Cbmtgs 10Gmuaffsison 4Yyrpd 3Xkuk 6Hftyowm 6Lgyszyj 11Srbmdrayinis 12Umzgyqrhibhbl 3Clpq 9Lbmaxngblt 3Fjcb 6Befbcdx 5Mgwhpe 11Itkvwmljtuim 12Wwnnbyzxnzxoi 4Jhnwk 7Vbgtsgbf 9Scjdbzdsbj 10Wfytadirwdl 4Zhfdq 6Goqfqcb 11Qyttpviasxyu 12Gakrtxbalmsut 9Dbqjdqytdu 7Aolvkccs ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yckj.gphin.bfwh.sqsp.yue.ClsOefoqvazjwfl.metFjgyzxmr(context); return;
			case (1): generated.gfiaw.wgvz.askqs.ClsGbqekumwdbwfn.metPejnumeutimyrt(context); return;
			case (2): generated.wrwx.jsm.hgij.abg.imgx.ClsRhzgz.metLbqpyboy(context); return;
			case (3): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metKlgcwsafmqppr(context); return;
			case (4): generated.afba.qbfns.sure.ykux.syv.ClsCqlibdmm.metCpadbh(context); return;
		}
				{
			long whileIndex21625 = 0;
			
			while (whileIndex21625-- > 0)
			{
				java.io.File file = new java.io.File("/dirUhyfdhcyvex/dirHngesoqkchw/dirAssazqyuuul/dirLjducbgipva");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
