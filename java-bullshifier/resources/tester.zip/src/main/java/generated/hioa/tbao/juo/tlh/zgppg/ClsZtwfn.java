package generated.hioa.tbao.juo.tlh.zgppg;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsZtwfn
{
	 public static final int classId = 67;
	 static final Logger logger = LoggerFactory.getLogger(ClsZtwfn.class);

	public static void metIuvwdmma(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[11];
		Object[] valIydprtilyht = new Object[9];
		Set<Object> valJibgowhdenx = new HashSet<Object>();
		String valSwxvnmylhax = "StrJjbfjjlskzg";
		
		valJibgowhdenx.add(valSwxvnmylhax);
		int valZfebuxljlyi = 249;
		
		valJibgowhdenx.add(valZfebuxljlyi);
		
		    valIydprtilyht[0] = valJibgowhdenx;
		for (int i = 1; i < 9; i++)
		{
		    valIydprtilyht[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valIydprtilyht;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Ogojf 12Brekhvatpkreq 3Ngkw 5Snwzzc 6Uoakkyp 5Ynardx 3Zdni 10Sxrebbwhluf 12Xftyksogbcovk 4Vauno 7Ktovbtee 5Oekthx ");
					logger.info("Time for log - info 3Ulxc 5Zlrkyd 6Vjdosiq 8Eigirzpet 4Vscwk 11Komprtpatwtd 7Rndwzlbe 8Nsvvcpboo 5Wkpqxo 8Aaiibyvwr 5Bpphkd 3Ydyp 3Pcon 12Khbyiujuleune 5Xeihkl 7Zzxesjat 6Frksetb 11Hrsexncqzjiu 8Vaznhghsy 3Vett 9Oshswdkqoy 12Dpwispajwrkxr 7Dbybtgcx 5Cuklda 10Gaddbjsxlua 3Afuo 9Hsyptvuhvu ");
					logger.info("Time for log - info 9Kjqacvttus 4Abhzf 10Kyehlycofyy 10Wgdkfhikmcj 6Aheyxyn 12Yxphgimixeelp 5Ytzslr 12Enbndpjbbbzby 3Ddkl 4Dcxjz 8Bpvamical 11Xkzmybrokwen 3Ockt 9Iiiofbwpip 8Gmdryebsk 4Fdbrx 5Okkezw 6Rvlkzcc 7Hsoqcelk 4Avqpg 12Yxdlgmpiwasjj 11Gwfozmabxuww 6Hgfaxtp 5Wzmbvf 7Ydozjeen 4Ctflf ");
					logger.info("Time for log - info 8Vezfawnri 10Emixkbeovlz 7Ugypusdl 11Xtndcjevixld 5Ethrxx 8Nbhbuaxsu 7Ekmrcaeh 8Vvxjqbuuc 7Mtihrplh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Puhmljdstzdua 6Tdrjqqu 8Wvimjweoi 4Mipcu 10Crqkrvsrnqu 9Blyothkdpg 3Cyqh 7Plmtenmp 10Yktacogrfqa 7Dsybhcga 11Pwmuwqkkrona 8Ialzxarlk 5Xgukvd 12Mlqohbqjizapx 10Pacduhqgdbg 4Zuukz 4Irgqh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Hhgjojcf 3Bfxb 4Actwx 4Tvdew 11Wmjfcjphnbng 4Qnfxx 10Zymvimaupyq 11Jxevgveewtdq 9Bdgkzxoccz ");
					logger.error("Time for log - error 6Qbmbyyn 10Nnyfxwxroyq 6Gfzfbui 11Qlmffduttwaq 4Mtgzz 7Hohaeyty 10Znltptwqtig 10Hargtcxkssu 12Bbctspezsxbws 4Twxwl 9Hnshfwkios 7Ngakrhrn 8Kciiurftb 10Reoqpurxkun 5Pmgynz 4Yioju 11Qceqwxetskfv 12Efvjnzicvypkw 8Eibcfkiut 12Grcrkrwovshes 6Kwfvrih 10Uleqprzbmwd 7Yvelphiq 9Tkpsofadyp 6Ttoepge 7Ozamlpoq ");
					logger.error("Time for log - error 12Jyftmlwjbsjsv 12Iaxdqhkhczdkh 3Veud 11Lutwsnbsqfmz 7Bqcueypx 3Rpkf 3Onhu 6Wgbkueu 8Ursufigug 3Yahc 9Bjqgzgbupv 7Vfmbxkih 6Xknbhen 11Uxutxlljlgua 5Jbgrsr 11Pqpxbtylguoi 11Xzhrwoyneenu 7Hlbdaxcu 9Hxfhmqnoxr 5Cvapzu 5Xszyzt 3Ithh 3Mlun 3Brtc 7Zxtnmgas 10Fgcaioqtuvm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metSkbraqotkaceil(context); return;
			case (1): generated.ryyqn.hafq.oqfv.ClsRsktinox.metKcbbyaslqqejp(context); return;
			case (2): generated.gpnn.qul.pdexl.hxjph.zmndq.ClsIcvyndtrplxfkf.metNldde(context); return;
			case (3): generated.wvctc.whp.ftjy.ClsPwdcftvpjt.metRruqnnklvvnmp(context); return;
			case (4): generated.jsgq.prz.gbdn.gmbz.fsq.ClsVccwchvmrutt.metJtnvvvb(context); return;
		}
				{
			long whileIndex21197 = 0;
			
			while (whileIndex21197-- > 0)
			{
				java.io.File file = new java.io.File("/dirGpurznokdnr/dirYsfqumncxtr/dirSrybbvvgycy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metIybrdbhypesv(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valIfndzavswuk = new HashMap();
		Set<Object> mapValCchntmouxbk = new HashSet<Object>();
		long valDaclmveuinr = 8936520075460554960L;
		
		mapValCchntmouxbk.add(valDaclmveuinr);
		long valTpgocbptket = -1867733177561681876L;
		
		mapValCchntmouxbk.add(valTpgocbptket);
		
		Set<Object> mapKeyMkahycdfeqn = new HashSet<Object>();
		long valOxehedeilev = -7294308477796587643L;
		
		mapKeyMkahycdfeqn.add(valOxehedeilev);
		
		valIfndzavswuk.put("mapValCchntmouxbk","mapKeyMkahycdfeqn" );
		
		root.add(valIfndzavswuk);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Ehmrulaodlgll 10Nmqdpmlueci 6Ziyihjq ");
					logger.info("Time for log - info 5Jgpoln 12Oohbhejfzmjey 10Gleaeamvkbr 7Ktxnsihi 7Fcvmcmgn 11Dfhhfzpfkfim 12Qttnfqicexkjf 12Uwtfhipejlfek 3Yvdw 9Zcgapqkxdv 8Xawozcyfv ");
					logger.info("Time for log - info 3Ukkq 6Wzvqjvc 10Msszaplrxev 8Bamgtylqt 9Utvyrlaqhe 4Qjcgz 12Fcwpcmaaihjqh 7Luomfdhd 6Wjuiyqi 6Rczmrry 4Bbyta 6Enumsjo 10Uhxttogvkki 6Xiozcrg 5Mbkxfy 8Ghucngtao 12Tvpemohsttekb 9Mgbnamzvpx 5Smyyds 4Wqhmc 12Bubxehbkpqtcj 5Fibfbt 6Sboqgbm 6Lufuqce 10Mhztpnzqukc 3Dbuk 12Dffmcsaazuvru 4Slmrf 8Stnewlmvu 7Qqtbxirj 12Gzkbmyucrirlu ");
					logger.info("Time for log - info 9Mqnwqmhpzh 5Arndmz 9Sztubybrpg 12Eaeozdvgsgzhf 7Ndojbadc 7Pkikvgjo 11Ezmvuhhjxafz 3Dqmw 11Termqrodsqwn 4Dbpnb ");
					logger.info("Time for log - info 7Trsczqte 9Cplbbccnuf 3Zqwg 5Nnzeba 8Tjjbqwhwf 5Lcqysi 4Rgkav 3Viuz 9Psfajjaqla ");
					logger.info("Time for log - info 3Rxgw 12Tcpdhywkkprxf 11Srkdbmobuvxu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Hbfxddrnqodpj 3Hdly 9Toyrtknzwd 11Ecagspmowfuk 5Dhsqrk 9Lxqymjytny 3Qvgc 11Whsgrrnbmfzf 9Zearpnwqcl 3Lbof 6Hmaxyee 9Syllnshcry 12Hbialcphikinh 10Yzlfujjeglc 7Alvqruxi 10Kynvtwrgodi 3Khzw 8Qwfjlvrtq 12Ncucgmsyyjftq 9Mwonvbzwho 5Gicvsy 11Dafykokkksff 11Shtlvznpynic 3Chqk 10Qalfxtkfdyd 7Uzkfcvvb 12Gdyipmxwjbqxm 5Vuxmqf 3Tlkh ");
					logger.warn("Time for log - warn 7Kchhosly 7Dwacnxvh 9Dogeuxjvun 11Jrhdaupditai 3Yaul 9Aueoozyjkf 3Jjtg ");
					logger.warn("Time for log - warn 4Tkbgf 8Vyeryhlvk 6Umwfewc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Kdfubulb 7Iucyoxft 3Ldsj 6Mxrewwy 6Tbyziqq 6Ahwqimb 8Jdfimxblc 10Nonwkhifgpr 7Sksnvcnf 7Zghcaoif 5Ofttvp 6Qequgwr 10Ztewzxcsldd 9Oqvfjafhbr 11Hmtwkkvumaeu 8Equmtsdux 7Roqcuslz 6Tdrescb 5Appizq 12Edlyzyfkdhftx 11Odvwvjketvcv 11Egcppwyzpekl ");
					logger.error("Time for log - error 4Trhzf 10Iphzmksdzfz 8Ozutpuavj 11Cvirxysxvdbl 8Gyciynfzk 6Iacyxsf 3Qjpo 9Taojipzljd 8Cpddbydtz 11Mnijwfbhoive 5Rqnksy 8Wktcckiqp 4Ejrpt 4Uiyxa 8Honjkzest ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.svs.oxvq.ClsHqpfa.metBgvjclpbm(context); return;
			case (1): generated.ahr.cnut.ztcbc.ClsUicrpogixv.metNaysjnfmv(context); return;
			case (2): generated.evl.qnyx.qnt.hnkpr.mua.ClsPqzytqp.metUawoukuahbtfc(context); return;
			case (3): generated.lzrmm.bjgfs.ClsQdamrbuivuq.metUnbxmbilwl(context); return;
			case (4): generated.wkucr.ukst.umm.xsqx.ClsEjxfeypurpufwd.metWmlpl(context); return;
		}
				{
			int loopIndex21200 = 0;
			for (loopIndex21200 = 0; loopIndex21200 < 2237; loopIndex21200++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex21201 = 0;
			
			while (whileIndex21201-- > 0)
			{
				java.io.File file = new java.io.File("/dirPppxitrloqj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
