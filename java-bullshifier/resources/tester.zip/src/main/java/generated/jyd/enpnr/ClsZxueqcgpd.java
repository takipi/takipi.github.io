package generated.jyd.enpnr;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsZxueqcgpd
{
	 public static final int classId = 284;
	 static final Logger logger = LoggerFactory.getLogger(ClsZxueqcgpd.class);

	public static void metEwimth(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Object[] valIrdywintijo = new Object[9];
		Map<Object, Object> valQtblumwvvdd = new HashMap();
		boolean mapValMxfbtldjumr = false;
		
		String mapKeyUsdfxiqditz = "StrTbtupyasody";
		
		valQtblumwvvdd.put("mapValMxfbtldjumr","mapKeyUsdfxiqditz" );
		
		    valIrdywintijo[0] = valQtblumwvvdd;
		for (int i = 1; i < 9; i++)
		{
		    valIrdywintijo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valIrdywintijo);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Tmucwlyubtgtq 10Jlnnxvrktob 11Wnzlreabqtom 9Opvwzktbog 7Febsvqgf 5Rupxgp 4Gumrs 8Vskbzoovm 4Idknl 6Uxahqps 4Rykem 8Ljsngdjjw 6Kgvyrkr 11Geyjpcrgpqmi ");
					logger.warn("Time for log - warn 5Ptlkmv 4Mnmke 4Qsjdr 11Pymqkemenfyt 10Cgroupvvxgr 8Pkiafkprg 7Irjxyxpt 3Ikyw 5Tacrqb 7Cwsmzdep 7Rjteulom 7Tjqehgud 5Gudvai 11Anpusdlugaha 4Uuszh 11Zdqodeotanzs 7Uaskfheb 8Ggukmnkpf 9Zpkbxbnlve 12Oeykkpwtzocfu 5Dctjpb 6Xneldtc 5Pnlwge 9Yozcywhkgb 6Zfyxwmu 6Tuulwbu 6Jamerjg 8Lrlwaikor 8Udxrlopwc 3Tzqf 6Zxeiwge ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Qcjze 12Mwzuqxwsvsewt 5Fmdgdl 6Veykqni 6Owartje 10Vmlqjjkdvpt 7Qnwhebzu 6Xinuliq 11Poodhhrbasyd 8Xtllerird 7Sfkhdqfc 7Ooujzlay 6Dizgmat 6Euwryxz 12Rkgjfbatztoyp 7Vyrpigce 8Ukajxhrwx 4Dsgyp 5Fqbahr 12Nkdholsbzcmix 12Rmdlnmipmhnjd 10Ekklarlcqxm 12Irfpgvuoinkmd 3Jvpf 3Gnbb 3Lomm 7Klyyiidp 10Zbjiyaqzsmb 3Yxis ");
					logger.error("Time for log - error 8Ybvfhladi 3Ztxk 11Fcokkpscpmuj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aqdnu.puvg.gdad.ClsIxzvdsuksw.metWaxopqbol(context); return;
			case (1): generated.ucgs.cys.qrt.ClsGwmfnzjfaj.metIstktlsqgkgixg(context); return;
			case (2): generated.ulj.ogxe.vbwy.ClsQmshqdjff.metXvyria(context); return;
			case (3): generated.idpj.vmnmp.ClsRgyokulekkkb.metRovgxbargonqf(context); return;
			case (4): generated.mipzp.qfu.axrt.ClsJkbbmhkrxeo.metJhzcshfps(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numMbzqopzykeh");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex24913 = 0;
			
			while (whileIndex24913-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
