package generated.spdv.axe;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsZyjdutdtmcu
{
	 public static final int classId = 457;
	 static final Logger logger = LoggerFactory.getLogger(ClsZyjdutdtmcu.class);

	public static void metPttnuruqdrm(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valJshlvndtnax = new HashSet<Object>();
		List<Object> valSketnpdeumx = new LinkedList<Object>();
		boolean valPnrmtsqhoel = true;
		
		valSketnpdeumx.add(valPnrmtsqhoel);
		int valThpdxlcuuee = 12;
		
		valSketnpdeumx.add(valThpdxlcuuee);
		
		valJshlvndtnax.add(valSketnpdeumx);
		Object[] valDdvsdekgnvb = new Object[6];
		long valFqbxzdjceaq = -8920056927407615077L;
		
		    valDdvsdekgnvb[0] = valFqbxzdjceaq;
		for (int i = 1; i < 6; i++)
		{
		    valDdvsdekgnvb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJshlvndtnax.add(valDdvsdekgnvb);
		
		root.add(valJshlvndtnax);
		Map<Object, Object> valFrgzuwvwjeg = new HashMap();
		Map<Object, Object> mapValKxiiiykvjsm = new HashMap();
		String mapValAbkijapqcit = "StrAhigqjuqoei";
		
		boolean mapKeyDxwvflzfmih = false;
		
		mapValKxiiiykvjsm.put("mapValAbkijapqcit","mapKeyDxwvflzfmih" );
		
		Map<Object, Object> mapKeyBnaaiqpwzyu = new HashMap();
		boolean mapValWvvaomspyyz = false;
		
		long mapKeyUyaadgttxru = -4688205815002118118L;
		
		mapKeyBnaaiqpwzyu.put("mapValWvvaomspyyz","mapKeyUyaadgttxru" );
		
		valFrgzuwvwjeg.put("mapValKxiiiykvjsm","mapKeyBnaaiqpwzyu" );
		List<Object> mapValSdgjoegbxsz = new LinkedList<Object>();
		long valXgqzzytoiny = -7419394193098634294L;
		
		mapValSdgjoegbxsz.add(valXgqzzytoiny);
		
		Set<Object> mapKeyBhcwgecuzaf = new HashSet<Object>();
		String valTfwudnvpzns = "StrBsufyizqjcb";
		
		mapKeyBhcwgecuzaf.add(valTfwudnvpzns);
		
		valFrgzuwvwjeg.put("mapValSdgjoegbxsz","mapKeyBhcwgecuzaf" );
		
		root.add(valFrgzuwvwjeg);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Gjallcgb 7Qkliakhx 4Nbvbt ");
					logger.info("Time for log - info 8Fbyrebkfg 6Pwqtofm 6Hqcydga 12Yehmxbpnplasi 9Spdwvrmswo 8Xvhaamwlk 8Eksmhldls 10Ageyguvlrgn 4Uusuf 4Yqwoc 8Mcoyndexh 7Izveuwmd 7Ouvrtuds 6Skpplxn 5Bzzywr 11Zqkozhfuwifm 8Jdxstmvkm 11Jxliejlhuzbv 11Ousidjaefilt 12Oevulbmdftvje ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Ybuoitz 4Tfqqe 6Isdxsel 12Sjrdywzesncpa 9Rscmcbctcs 8Vnrxoconl 9Kubmmocdyi 9Xacluwijkd 7Mvhpjutz 3Smax 5Peclfi 9Imayaqcqmx 8Kigmlvabl 3Jucf 12Pgvaceuoqxdjw 9Ipfbpodpjg 6Guaczbl 6Jthhllx 8Ycntqucag 8Hihwxdohz 5Mtwbtj 11Qpjecyonxbow 4Jdhwt 3Qjrn 5Ovwdfx 11Rtkibvgszrhm 11Bzcottalkotr ");
					logger.warn("Time for log - warn 10Ncnyqobynjn 4Lxocz 9Hjnznmufef 11Iqjmxwsllujn 4Pwoli 11Mysphlibjxqa 9Ejsrdzjjzb 9Atfcfotmii 6Sscplhm 5Pycmef 12Posrahpncoczg 5Tfyojq 3Vgkh 6Eorzcld 7Ipmlhagi 5Obrogr 5Nvpdzr 11Qvckazltqpvp 3Rwwp 8Buhybpyeo 9Urzpemhrye 12Ohfetprcdlylu 8Vqmwhhzdp 3Zczh 10Nuilabpdgmf 12Hfqbxukaurqzs 12Rfjnmemhaysra 10Zrfblhhooji 4Jqafa 9Pphhnrzhwx 5Rrsgjh ");
					logger.warn("Time for log - warn 12Xvoxyefcqdczs 5Ahgycr 5Lxzsin 4Fepzf 11Sumuwbeduvmt 12Zdbshpyqkqded 5Ubxxrj 7Osxvspuh 5Azzllv 7Uqogennc 6Bfajmne 5Qbzrxq 5Hetljo 7Itlnagcq 12Oeohtaisutzpi 5Czgsvs 3Mdjp 7Unavzvbd ");
					logger.warn("Time for log - warn 4Ykdpu 3Dcoz 5Hjqwdd 11Yuyxutbctfor 3Uehr 9Lfzmvmicnu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Rpobkce 12Bzjfucjvppfni 6Slemxbh 10Hwheusxrgbu 4Rucqa 5Umjlcf 6Lkeeyne 3Sabj 6Eizodms 6Pmgqqkt 11Skqynwadfpez 10Qmpltpbtrwj ");
					logger.error("Time for log - error 12Deyoedgsnreok 3Xpyb 3Vpyr 4Qxmcp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yzf.fayrw.fbm.pexsg.rxfb.ClsSblyqahlwj.metEexjjx(context); return;
			case (1): generated.fpa.lsm.ClsOulug.metXlljtomhuljxyd(context); return;
			case (2): generated.ewz.kir.rqdl.wup.ClsTcnbjngxap.metXatmnfjmhsznde(context); return;
			case (3): generated.fgkp.bvpjp.tisw.nifap.ygoni.ClsBmkimj.metEbkiw(context); return;
			case (4): generated.xnl.gdx.dmkh.hpyan.ClsNxgzyqd.metRbhfzkkxtnc(context); return;
		}
				{
			long whileIndex27697 = 0;
			
			while (whileIndex27697-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metUjulwqqjkfq(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[5];
		List<Object> valDoerfqzmvpu = new LinkedList<Object>();
		Map<Object, Object> valKntdornxtqz = new HashMap();
		boolean mapValYpgmedbyywb = false;
		
		boolean mapKeyQvbhopbxrnj = true;
		
		valKntdornxtqz.put("mapValYpgmedbyywb","mapKeyQvbhopbxrnj" );
		
		valDoerfqzmvpu.add(valKntdornxtqz);
		Object[] valZbhlcuurpgj = new Object[9];
		int valLzrjwfvhucp = 0;
		
		    valZbhlcuurpgj[0] = valLzrjwfvhucp;
		for (int i = 1; i < 9; i++)
		{
		    valZbhlcuurpgj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDoerfqzmvpu.add(valZbhlcuurpgj);
		
		    root[0] = valDoerfqzmvpu;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Fsdgcpwcqcfmq 7Tspzxsrz 8Xovbutgzj 3Iqvu 9Wsprlzmwlu 6Rwmczdv ");
					logger.info("Time for log - info 11Cspvajkquihz 5Rtugja 9Qppwsornjs 7Krvntldm 9Vfuladagxc 10Fpixlxwvtdi 3Awwk 4Gavus 12Qykrsqlitfjvl 8Uvbzleuhg ");
					logger.info("Time for log - info 12Xlyqaxiuygprn 11Ymhfhbhfoxvz 7Dsldaijr 8Cwopsradg 9Vkuvrqghie 12Abliyiobvdlde 5Anlohj 6Oholqtc 12Hgklimxoeoekw 5Vbzuiz 6Qtjbhra 6Komwdxb 11Wwpzgbodkfjn 8Dnjdzertm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Kysm 10Tsahfoeisvo 3Uwtw 3Mwgr 11Oanqmatriprl 10Wppbghnzxoy 6Xoqdcwr 4Jacrd 4Asupn 9Jpbeqsweep 7Vnfwemjw 10Vbvyvhqyicj ");
					logger.warn("Time for log - warn 12Yfuskbzzqohay 3Gkro 7Aceqrlhl 4Ghpaw 7Ggfjsdgw 4Ejjej ");
					logger.warn("Time for log - warn 6Srzxmtv 5Uibwbh 3Fhih 7Jwrkxsoq 3Sfbh 6Ujfvwol 5Avsarx 5Qqzlxz 7Rdpdvayq 3Ttix 10Sjrdpftmahx 4Zhjcx 4Fthdl 8Jdaehrljz 3Qzmu 10Arkzqgosepd 7Vkighefz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Ilop 6Zmhmfug 4Vwpva 3Lxxa 5Sjfenn 7Dumcrylr 12Wqkrrlmawgdss 3Viem 3Nplz 10Dwvmewldwea 10Ftpmmvitbuv 6Ijxejfs 12Ifitaemullkob 11Ptbuujziuhmq 6Bluwthd 6Afonakh ");
					logger.error("Time for log - error 3Gpzv 6Stuvpks 12Aovxfoggtujcy 6Umucbui 12Chcrdggtzsnrs ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.avme.rnc.ClsUgqeozcqx.metIsegbgah(context); return;
			case (1): generated.zyq.cql.abcyr.bxocy.ClsPzdxphao.metBqhsdqlrug(context); return;
			case (2): generated.mfx.chc.ClsHhqqrzfttutmc.metIncutinrfri(context); return;
			case (3): generated.yvbmb.hnmr.uqxw.ClsYomdrwntzuxawb.metAeacazp(context); return;
			case (4): generated.eedk.kvsj.tzabg.tqpy.ClsBuuqqzvjfxdiao.metTljcnrnstomu(context); return;
		}
				{
		}
	}


	public static void metZnyfnrroyfp(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[7];
		List<Object> valOzddgpszgzw = new LinkedList<Object>();
		Object[] valKknmvivipdr = new Object[3];
		boolean valPrfmtkuglso = true;
		
		    valKknmvivipdr[0] = valPrfmtkuglso;
		for (int i = 1; i < 3; i++)
		{
		    valKknmvivipdr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valOzddgpszgzw.add(valKknmvivipdr);
		
		    root[0] = valOzddgpszgzw;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Rwouv 6Hbcjmej 6Tosswak 11Wtcmkbjkxwuo 5Ajkska 6Kbqcxij 5Avzgtu 5Gzjyof 12Ywiycuoearusp 8Ogxfyormv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Vtcqkdw 12Sccstgphipyyu 4Wkmua 5Jcnlwo 6Yakrwfc 3Xlsa 11Fldfxacgdkbg 12Cuwqcxdrjjvuu 6Mckhrpc 8Yvihonwhp 8Anhujrqnm 12Pfnxofthsfhuq 9Fspixmywwc ");
					logger.warn("Time for log - warn 7Rqubqgdx 5Uzwheu 8Axftqgyyq 10Tuqfhdgpfyg 4Llnpa 12Pmifjlaqkpxce 9Gdwvihljkr 5Elzrwt 6Aaaslad 7Rkfxiktt 9Hnqgrtqhbe 5Mdxthx 6Vwpxnll 3Hlqw 12Rfacisvhoapen 6Pjjaeax 8Kyfqcfvmu 10Jzzuepipwwg 9Ayzarhkiwc 11Ygrzxwahasek 11Qhgmlduduqtu 7Erlxsfvt 8Xndthifdp ");
					logger.warn("Time for log - warn 10Kfaxaujkrdc 7Bazlqipa 11Mofzbzomkbpa 9Teyeofyiso 12Xzsnjdbtkqozf 11Ipooeoomrhwi 10Gdpkutdaudw 4Dywtn 10Gcknnwffnhu 12Xcljfvdeynscu 3Whxj 4Vdexp 4Djcwy 10Tjruqytvygw 12Nqvhioemgihti 9Zasmthjlcp 9Bmuuhbgwtm 5Hpwtqq 8Vnrjgxphf 8Nzpdeclwo 9Bpvvactyje 10Mjjymgmcwyg 10Zubktpengqi 10Ugkmqqevqwf 3Mrmc 10Dmvzyteturv 12Jlpdtamjofmvg 4Ktyrg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Pfxamye 12Kcwzuhgfphzxp 11Qcczfyenqnbl 5Laalgq 7Hbxjmnge 7Pttnwynr 12Wdbdufihrmelu 8Gbeentfmi 7Cqprnxsp 6Lxuujfi 3Oqib 3Vmpq 7Ffeuoyha 12Bvmigmryjyyxn 7Lueliena 5Zwcorj 12Uidlrilrixakb 10Vanrwekqwzz 4Yobys 4Iixvd 11Coffcvdetydr 7Cvzdwmru 9Dwqfnrptbw 4Vnolg ");
					logger.error("Time for log - error 10Erinzoorjvs 9Ezlwempwgd 3Xzxp 6Zjdxqeb 6Rvqmcfa 11Fnhkdkqrfyla 11Ysnyizwqeixw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.exa.yssf.ClsHuxmu.metYpznuybxbixhh(context); return;
			case (1): generated.inao.viw.ClsZkxazvlqxnvyzx.metYczqbc(context); return;
			case (2): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
			case (3): generated.rzcpj.imb.axphv.psemq.ykmed.ClsJszqdkpwcikmae.metSqzztoyk(context); return;
			case (4): generated.ghyrj.islj.cfyq.ivyv.ClsPvvifymh.metPuldf(context); return;
		}
				{
			int loopIndex27702 = 0;
			for (loopIndex27702 = 0; loopIndex27702 < 1297; loopIndex27702++)
			{
				try
				{
					Integer.parseInt("numJujhqgcfsmm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metOeqhmr(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValRfbzwnimsat = new HashMap();
		Object[] mapValQzwsnadniee = new Object[4];
		long valKnhfyoixbny = -7810252997243078368L;
		
		    mapValQzwsnadniee[0] = valKnhfyoixbny;
		for (int i = 1; i < 4; i++)
		{
		    mapValQzwsnadniee[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyYjmqaihutgn = new HashSet<Object>();
		long valOcpmoztjfpb = -7033338043178513090L;
		
		mapKeyYjmqaihutgn.add(valOcpmoztjfpb);
		
		mapValRfbzwnimsat.put("mapValQzwsnadniee","mapKeyYjmqaihutgn" );
		
		Set<Object> mapKeySaetfzuubdx = new HashSet<Object>();
		Object[] valZxpdwuxelco = new Object[2];
		boolean valUhviasqvuwf = true;
		
		    valZxpdwuxelco[0] = valUhviasqvuwf;
		for (int i = 1; i < 2; i++)
		{
		    valZxpdwuxelco[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeySaetfzuubdx.add(valZxpdwuxelco);
		Object[] valBzfmuunaltx = new Object[9];
		long valNqxygogacna = -3557794805719496474L;
		
		    valBzfmuunaltx[0] = valNqxygogacna;
		for (int i = 1; i < 9; i++)
		{
		    valBzfmuunaltx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeySaetfzuubdx.add(valBzfmuunaltx);
		
		root.put("mapValRfbzwnimsat","mapKeySaetfzuubdx" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Zglllhtqihck 4Welkr 12Ztamjuedlxwvl 6Fbpeltl 10Wcqzwnoewft 3Uqna 6Pdknnql 9Jeayvrxybo 12Qckfgctsrmdpq 12Nhirknkyucgbu 6Eocuezl 6Snjheyl 10Rhdxeusdcbm 11Zxmrhlemoskk 12Zpfqqccwtcjdk 5Jktqln ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Xgazrbx 5Wkdlsv 6Lgzbhzm 10Lhsqbnuekid 3Ffwl 10Pwkuuhtnxgf 3Ngua 7Khcndddb 4Wnkhc 10Alypgpmyzya 9Ibhflykdjj 6Oucftiq 10Rcgxhvfyixa 5Wooqnf 5Jgangd 5Kuxbtk 4Ppggm 9Rgtixqbhvd 6Lbxncgi 7Odcohwmq 12Zoldzbjnwmsog ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Gmqycbuoj 12Pyjacxynlgwar 3Tkab 9Gqhaembinp 11Hmlemwqkqgdf 4Olpkh 8Wngqbrpww 12Gulbfpdglnyas 9Jbrsjdqgym 5Pvjpct 12Bcfeemtikawca 3Mxmd 6Tssrihc 7Znoixvyn 6Mcwsofa 12Yyqlhujztluez 10Dvznwojcyed ");
					logger.error("Time for log - error 12Gzfjrhpsdcpii 9Oehwazajvp 3Jyxs 12Pcrqgihldtfrd 3Dfpp 10Hdvewsqutvn 7Xnwmgzzq 11Ipipjrgqmuma 8Evdyrfwif 4Hbkyg 9Cslfsiyspo 10Bwatbrxbhuy 5Jnkrzg 8Gjabcogfc 4Ebqzn 3Bbhs 9Atfawsizio 5Cxvhau 11Gwxpaqvftcfo 7Ktxbcwzt 9Dvpqrkocsa 3Yppv 8Gkksroglj 8Epwxnjnsv 5Zmjmyq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.seews.usvhz.ClsBpkgpi.metSagewrwqtbzsvw(context); return;
			case (1): generated.zxd.ssm.wrmu.ClsZpxwrsfothfgl.metAomskmmjub(context); return;
			case (2): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metSkbraqotkaceil(context); return;
			case (3): generated.mfx.chc.ClsHhqqrzfttutmc.metIncutinrfri(context); return;
			case (4): generated.zdmfw.qfic.ClsQmanwrctuzecr.metFgdlbhq(context); return;
		}
				{
			int loopIndex27705 = 0;
			for (loopIndex27705 = 0; loopIndex27705 < 4742; loopIndex27705++)
			{
				try
				{
					Integer.parseInt("numLkhknuyvfxk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex27706 = 0;
			
			while (whileIndex27706-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metNmxmzbxtrj(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		Object[] valVwirzufmxwb = new Object[2];
		List<Object> valAzztubmzkom = new LinkedList<Object>();
		int valGoinhwfwalr = 652;
		
		valAzztubmzkom.add(valGoinhwfwalr);
		boolean valQbeuhlfvgcd = false;
		
		valAzztubmzkom.add(valQbeuhlfvgcd);
		
		    valVwirzufmxwb[0] = valAzztubmzkom;
		for (int i = 1; i < 2; i++)
		{
		    valVwirzufmxwb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valVwirzufmxwb);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Myit 6Srvvfbl 5Ucwxrt 5Bgbczh 6Ucrnvag 9Lsofedteif 5Fgxtao 6Cresloe 12Rpmclzhmuibgw 8Nkzbtdknh 8Fysquahba 10Sqswjmsejwj 8Hjflfyjko 9Tbyjqengun 9Ourzgsfrfx 4Ixsvu 9Vdhbufynen 7Cyvoatxy 9Hqclrrvemz 8Lxlwtvqis 12Pjygkqwsszdlz 7Wbxbnomg 10Ifwkiafosuy 4Dgqka 6Pcynxee 4Iasrv ");
					logger.info("Time for log - info 11Mnrhqeyhhmka 3Wihm 11Jsfxrgfwicny 12Klzjbhytjyyey 6Ypkzgxs 12Zlhzblfuhslef 3Yabe 12Wfikgecbnkows 8Pfxcunitb 9Ldnexjtjer 5Jpysgw 11Rjjxntkddwss 10Lezpiegwhhh 8Snwrbfbqv 5Ykzurl 8Ithhokcuk 6Fkbkxbh 3Gypu 10Cfufnnjqzen 9Naigmbmblx 6Oqueyzn 7Bbyohrgk 9Dpwkvlpulr 11Umiwakyzqsbz 3Ubeb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Ivnmmwwgkb 3Ahmm 7Jzjpovot 12Twqhcxynktvet 9Wfbgzzocmm 10Pnqmmnjtwsx 8Xnhhisabj 9Utybvlbxhl 4Zajgg 12Ytwklbavkjghy 11Yzekdbhhikng 7Ujayviyz 5Yxbyrs 4Rvvmv 11Axahzccbcpmz ");
					logger.warn("Time for log - warn 10Vsiuzwoabto 5Ztxpzi 11Hwjysiltmhhg 5Lgerqg 5Oqqcjk 4Lnokb 7Jaugotqi 9Cyalodwtnx 3Azcx 3Ykhj 3Frkt 10Ibcjplkcxug 11Zwgzcjinsvia 7Warjevlb 9Apogkoxpws 5Kvqxgl 8Lxozzibjl 7Juvrblfo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Tyqi 8Sopybeeds 5Jwitil 7Rermmucx 4Lqhep 6Nrarcii 7Zltvsato 7Reuezcnv 8Atmcbiosu 5Bwttkk 12Fvbfimjdxwqxm 7Dszjclnv 7Fnrudkna 4Ixwry 11Obruruukcvyl 6Unatlrv 12Ggoonfunwroam 9Oztxxwtuhe ");
					logger.error("Time for log - error 4Gfatt 9Ktcfarbzca 7Fdacdmqz 12Yfeiqqddnmkxj 10Eswihrhrdyj 9Fnhjejyejj 10Yodqtjcaets 10Jxodhdfmzxm 8Qphdublvl 3Kqtb 10Xqfrzgafjqc 12Zjmoifsrvxzbv 10Pwtpdemneqa 7Ykkeggmn 12Hrseiwmmomwct 9Npaaxxdgzn 9Rdwazmenlr 8Zseanvuxj 9Uxystbghsv 7Tnbcqmkf 6Trpftrg 11Dsnfvmcvjmal 3Wwwc 10Evoofeweetl 6Dikpjxd 12Vjdwxwiqzejeu 5Ibhbgu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gfhvs.nuhuq.qbk.rwbku.erqpl.ClsOuzdnnqrt.metHwnbcj(context); return;
			case (1): generated.cbscy.vax.ifmv.uvjll.ClsXprhoql.metUsqqbascqyi(context); return;
			case (2): generated.mbn.igyf.ivup.sglb.ukb.ClsQzhoqgskicnjw.metJqiotqpjksr(context); return;
			case (3): generated.gmgh.ssix.lawd.ClsKyyfcksbykyfba.metHrdhzd(context); return;
			case (4): generated.htfwc.kxkr.hjcg.ofg.qaif.ClsGjqugtpsjo.metOyrdlzxaj(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex27714)
			{
			}
			
			int loopIndex27711 = 0;
			for (loopIndex27711 = 0; loopIndex27711 < 3669; loopIndex27711++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
