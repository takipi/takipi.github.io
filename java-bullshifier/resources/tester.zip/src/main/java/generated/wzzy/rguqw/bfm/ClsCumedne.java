package generated.wzzy.rguqw.bfm;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsCumedne
{
	 public static final int classId = 50;
	 static final Logger logger = LoggerFactory.getLogger(ClsCumedne.class);

	public static void metJsfyyjsbivcd(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valNppirgjwyvh = new LinkedList<Object>();
		Map<Object, Object> valFizkrmxlxxo = new HashMap();
		String mapValSanernycmnw = "StrSfxgozgtiuy";
		
		int mapKeyDqywuyyouiu = 92;
		
		valFizkrmxlxxo.put("mapValSanernycmnw","mapKeyDqywuyyouiu" );
		
		valNppirgjwyvh.add(valFizkrmxlxxo);
		
		root.add(valNppirgjwyvh);
		List<Object> valYdcosnppved = new LinkedList<Object>();
		Object[] valOjhkpyztgfv = new Object[8];
		boolean valAlylndmorrt = true;
		
		    valOjhkpyztgfv[0] = valAlylndmorrt;
		for (int i = 1; i < 8; i++)
		{
		    valOjhkpyztgfv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYdcosnppved.add(valOjhkpyztgfv);
		
		root.add(valYdcosnppved);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Wduzjikofz 4Jqsqy 8Jufiksuvd 3Ntyq 8Koehfiqyd 10Tegqhhfttte 7Xtofkxks 6Gxlnyfz 8Otdnqiqoy 3Psgr 11Inqmyngqxclz 12Tphepxptgenmx 5Ztvsww 6Mmwgdzj 3Ewtl 4Npvuv 8Lijupfakl 10Vsoopqjufag 8Oavfaebqy 10Snvaqegxrfl 6Yislhcb 4Juxwf 5Fijjmq 8Qetsmkqga 7Zdpeuxpy 12Rhhlgrkisuprv 7Qybrsxyx 7Fhrddfjf 8Gvlqhioom ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Poihx 3Ocex 9Sqatqmkwcz 3Eapg 11Cfzwfnzjkfht 5Vrprkc 8Xuujesvnt 11Wflleashlyxt 4Muees 3Fgbf 6Sqmribn 6Jgznisw 5Bfmbyh 7Iclxlkad 9Eqiwdiaqmo 9Vlrprghfuk 11Uyxhezqupgtj 3Lszt 9Jldkdxssuz 3Vhmt 10Qrmlsxgfcqq 3Chfr 4Ehlre 11Josxcqlxguil ");
					logger.warn("Time for log - warn 8Annltnyso 3Bnml 6Wlbxhbr 11Gvdrxdbaxzdl 4Xpbpd 5Uxpdvz 7Ulimrcho 8Mgaoozbaz 5Agholz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metWfolwtyhy(context); return;
			case (1): generated.gcr.qqx.juuh.caxx.ClsRlelgjq.metIstdlmn(context); return;
			case (2): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metDghubvohwq(context); return;
			case (3): generated.weide.dnna.unvd.vtw.pcbre.ClsExwicwtb.metHqnibperro(context); return;
			case (4): generated.hyq.yrx.ucb.jdut.ghw.ClsXwcyosgzsc.metMysukbgfyiodpv(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirNyjsvewjzgx/dirJmqtdrcmyhb/dirSfxytamahyf/dirBpqeovpruoa/dirWlakarkgksp/dirXfbfboxuwsx/dirHmmehzbdgwh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex2928)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numPtqjbwpbqre");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((5980) * (1560) % 89022) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((3602) - (9447) % 821205) == 0)
			{
				java.io.File file = new java.io.File("/dirRgcmriruihq/dirUaalsgtizsd/dirRmwztqnlslh/dirNzsnafjpmvm/dirLsfgwtiwncz/dirSvmjfbunnvz/dirMpkyopcurjt/dirIlawewcnuwy/dirZhgiildylkc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirJhzyefdcsdi/dirWlxdwovvtdu/dirReliojgzwyz/dirBvlkxexloyh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metNzmkdspqsroeb(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValLzlsnwdolvo = new HashMap();
		Object[] mapValNzffzbsggvj = new Object[6];
		long valUznztkvcmeo = 3645675377103766901L;
		
		    mapValNzffzbsggvj[0] = valUznztkvcmeo;
		for (int i = 1; i < 6; i++)
		{
		    mapValNzffzbsggvj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyNajikvopjxa = new LinkedList<Object>();
		long valKsadjhdesjk = -3030197357978974572L;
		
		mapKeyNajikvopjxa.add(valKsadjhdesjk);
		
		mapValLzlsnwdolvo.put("mapValNzffzbsggvj","mapKeyNajikvopjxa" );
		Set<Object> mapValXpuxtosnjyz = new HashSet<Object>();
		int valOedahiahsqb = 0;
		
		mapValXpuxtosnjyz.add(valOedahiahsqb);
		int valDbtwjxvxdwf = 773;
		
		mapValXpuxtosnjyz.add(valDbtwjxvxdwf);
		
		Set<Object> mapKeyYrjeluajscm = new HashSet<Object>();
		int valZjkwzmghgtw = 209;
		
		mapKeyYrjeluajscm.add(valZjkwzmghgtw);
		boolean valPayquxbbmmr = true;
		
		mapKeyYrjeluajscm.add(valPayquxbbmmr);
		
		mapValLzlsnwdolvo.put("mapValXpuxtosnjyz","mapKeyYrjeluajscm" );
		
		Object[] mapKeyVpedlahoveo = new Object[6];
		Set<Object> valZcdrtaoachx = new HashSet<Object>();
		boolean valTogifocuosn = false;
		
		valZcdrtaoachx.add(valTogifocuosn);
		boolean valZgvkzfxcven = false;
		
		valZcdrtaoachx.add(valZgvkzfxcven);
		
		    mapKeyVpedlahoveo[0] = valZcdrtaoachx;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyVpedlahoveo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValLzlsnwdolvo","mapKeyVpedlahoveo" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Taozswgem 6Rppvbqp 4Fljos 3Lzxj 5Cwzluy 5Nhaxfk 7Mskuxzqy 8Umwnvltkz 5Juqqfl 3Wbgi 4Bmjea 6Tbxlwnl 10Xxprjxowdwo 9Zrhzawzwlq 6Ulpiqay 9Wgmtjavwdp 7Piekdqgo 11Kqgloabuivkg 12Pabnuxotylnhd 12Zvtkehwvkvqzo 10Afwtcynjtbo 9Aknwyidwpi 4Jxfbn 5Qaohhe 3Hifh ");
					logger.info("Time for log - info 12Mcvsaozlxbszo 7Itbzjgkt 12Pkppvihqllqcv 5Pixeqx 10Xoecqgvblpm 10Fhhkodpemgq 11Lgdgjakjduae 7Zypxvqac 11Vczgwjnmvacx 11Gnsexeycptjk 11Ljlmbhgncerl 8Cnnyaqqgd 10Dsgfmwlgozr 8Ucexxatvc 12Atxoahjpucvoa 12Sobzjdhvoxzbe 8Epbtibkrh 11Yxjvuqwvvock 4Aolul 4Frrnt 8Toenhrpoo 3Fyoj ");
					logger.info("Time for log - info 9Zgydhmrsyg 5Lsefos 9Evoxnaycfr 11Htgegtuqeotm 6Zlrnkvs 5Eabucg 8Thmqtxxsv 5Dcivyl 4Ioggd 9Ssglizefju 11Jrhayevpbsyq 7Olosytwg 12Rtzxdcpazpwfz 12Nmmhubawemkhj 11Ywozscztwfhf 8Cicrqbrhf 6Lcdmmyo 5Yhsgsq 10Esezkfzvzrr 5Squfak 5Pfmoyw 5Oradwv 10Wlfynwmvnvv 12Gcwhgapdxerji 10Mfxnefqlmvf 4Nnnyt 6Nfabmgl 12Covvqhbseaieg 9Feygsmprsu ");
					logger.info("Time for log - info 6Mfkqpzz 6Zzwhdhk 4Xgqtc 10Lzknoceutub 7Ywdrbpva 10Nfvukwhrfds 12Hrtssirntpjye 8Behcssuxr 11Rxjldqmzymkl 11Xepegxgdudxp 11Fklbyrofknid 9Ywvisvhkgj 3Bmjk 5Rvfzxz 4Srzta 9Hqgcgnvnmj 12Lipnrpjzblmei 11Izhgtcorxzew 10Mdkbunzixpo 12Igaupvljgbinw 5Nhiiml 4Uguar 9Utjprwfabh 6Rwkenom 7Bbslyxiy 11Hdmwdjoximlh 12Pkyaiqjapdymp 4Gtrzv 9Mzhbasvdfn 5Dtcmqr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Nnfnvqifj 11Fcwxyusiexcq 6Dfgazgg ");
					logger.warn("Time for log - warn 6Bskosez 7Ctxbepcz 3Vakt 12Fxgktujinfbot 8Pzykkbufl 8Qpwhsymun 7Trtcrpaj 3Jelh 8Spotqceem 11Xbqcnfwwkiad 4Rhxwm 10Fwidfrygyzl 12Qpiklkcnebjxw 8Uztaazmew 10Qulijoavfxe 11Vthgwvoeevpq 12Zxjlzhtxukhgf 4Uflvx 4Huzpm 5Tvapin 8Yojyuuiud 5Pvhkwd 11Mqcwynieybxo 8Jpfxtrkpi 7Zhujmvoo 8Mrooxaqqx 10Khecngecwmm 8Xlxilnwdx 12Yntsxrpjuyqiw 11Bhxcvzxuqnmy ");
					logger.warn("Time for log - warn 3Kkxu 12Bzyghgjvdhgcs 11Nokighyqxbzb 8Fkxbozhws ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Yzoghp 10Qszdxgxjuon 4Pekdz 4Aquep 12Azeieqxwxhxvt 11Sbqujyipstdd 4Uavyq 8Lpeztbvzv 5Pbtrok 9Twvwsyzvmg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wte.xgtr.bgy.yncq.pkef.ClsWcqetwudvh.metMkywussdywwg(context); return;
			case (1): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metUfpufoucpqucye(context); return;
			case (2): generated.obnl.keokn.bqrr.mlh.qwmk.ClsAxxbgst.metTcizkn(context); return;
			case (3): generated.zuqq.dis.ClsZotjz.metPhpym(context); return;
			case (4): generated.rxif.wckg.ncsqv.pmlox.ClsRkhayrnqgfzod.metOqicwb(context); return;
		}
				{
			long varBhcnradetqe = (9698) - (7516);
		}
	}


	public static void metJavfokczruv(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[4];
		Set<Object> valGhiezuxqlhq = new HashSet<Object>();
		Object[] valVyhglewgsip = new Object[11];
		long valUegsqxfpkvr = -8209456703443729209L;
		
		    valVyhglewgsip[0] = valUegsqxfpkvr;
		for (int i = 1; i < 11; i++)
		{
		    valVyhglewgsip[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valGhiezuxqlhq.add(valVyhglewgsip);
		
		    root[0] = valGhiezuxqlhq;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Gwezjgnm 9Xtfrmytmmv 8Zraknblca 7Xnaemqvz ");
					logger.info("Time for log - info 12Eymuzipyzadbd 10Mixaonulqfl 7Kzntrfpm 7Lfzpxrkp 6Phejnrh 10Lfzbwxvdgen 12Fvptkmpidxqzt 8Wizskzrpy 8Gguhjdsha 8Ozeidfsqx 7Reoqvaao 11Xaindwuvhbex 12Qvtbyumoioene 3Nhjr 8Evgshixqh 11Zbohojxoiqfa 9Knnoalrpip 6Quwyntn 8Wxlcuzkql 9Xawpkgwsqn 9Ckguanibqb 7Nwkivdde 9Hnubnlowct 11Cwpljnvxzbqt 11Zbakztusjmij 3Ytiz ");
					logger.info("Time for log - info 5Ffvfzc 6Phsrdwx 11Nbskhyibnzhj 5Gphjuw 12Rbycsgxdmeqqu 6Kammqli 5Guanow 5Dvtxag 7Atmpxorq 9Corygjcnzg 6Alelpxk 8Fbnwszsho 8Ffkcmktcp 9Fkofcwajhk 4Lxjzv 3Jdzl 5Ellvkx 8Rwllranga 9Kgcdetyjkj 5Xvvpxs 7Lwoogzvu 5Fdwwjf 12Hjpzjxhjufivv 9Bdmatywles 3Dpff 7Twflrjmi 12Pqrtlbyjzyoco 8Usvdaddpr 7Unveklnl 9Ejnkcfnqci 11Fuvtihpsvvxt ");
					logger.info("Time for log - info 9Mkowntwmay 10Nzzstxnsipt 5Gqdoml 8Pyjkvayhy 6Olfswbo 3Qhcv 11Ckylmnoykxxz 5Fnxthq 4Esppb 6Gnapoqo 11Rsijjzqrsrea 6Zglfoxr 7Grecgoci 10Fcttfxtjius 3Lhjo 8Ipwdzxsil 12Nayibsyxkxjam 4Otqlx 5Unkpca 12Mcltvuetdfick 10Uahnehxhrof 12Xxwigsorzsjgk 11Utsualanhvld 6Hwboqmt 4Qrmkr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Awthsatttr 10Ujiloiztjpi 12Cnsniqktuofpi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Pdxp 3Abjz 10Fqrtwgsrddq 11Mcasyvnrjgup 8Hrgiubmbw 3Wwfm 11Ouphcaeebfqi 12Jowtiucdnohaa 6Plukknd 5Yuiouh 9Qhgzltctcu 7Vwlepfvj 10Gvjaioubgxa 10Mnifvrddltn 11Vobotmyetqpi 12Aaqaqxnoqamzd 10Jumxephkttt 5Tdhvqr 9Jxueyaqblf 6Bxyfhiq 9Hdqbzwoiqz 10Pvizgnjzlmt 7Ewnunvdc 8Hfiqsamxd 7Budhpuew 6Adonizx ");
					logger.error("Time for log - error 3Xwto 10Uiukpqrvtra 7Seovpqvb 11Ifpqkyndsmvb 4Ibrok 9Eskyatsuzf 3Idmn 9Ehacjnqgkm 5Kdwmtg 9Yzpttmzkrf 10Gehshaxebpy 12Eqldexbqmagnd 10Cggrpnaolxz 8Bpquqxhko 6Cpbbjnz 10Dtchqgtwjio 12Dwjmduvouczgi 10Tbvyotkmita 7Ngmdwehx 11Bqnbnhkdymfe 4Ruunm 4Apkcz 6Gmqbewy 12Negbfnnlyuzap 5Eixjih 8Oormgvgew 11Aeytqzhzywbq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.reb.nzlh.ClsFjrtwsmg.metGcfvrdlvkdpv(context); return;
			case (1): generated.ntoe.pshsx.ClsKjqouchrqothb.metMqidtlggwab(context); return;
			case (2): generated.dxrru.qphkk.sigfx.fho.qtrx.ClsXgcfqnkax.metBpzoot(context); return;
			case (3): generated.rprz.twb.ozdl.ClsMnahuieydv.metLsuejvaasjahy(context); return;
			case (4): generated.rludj.zqn.tuc.ClsSdrvvvm.metOhtuehbexx(context); return;
		}
				{
			int loopIndex2939 = 0;
			for (loopIndex2939 = 0; loopIndex2939 < 30; loopIndex2939++)
			{
				try
				{
					Integer.parseInt("numMqkifebmfzh");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex2940 = 0;
			for (loopIndex2940 = 0; loopIndex2940 < 3646; loopIndex2940++)
			{
				try
				{
					Integer.parseInt("numJwyiffwfhon");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((Config.get().getRandom().nextInt(285) + 4) % 313929) == 0)
			{
				try
				{
					Integer.parseInt("numZlbcalyimbs");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((5092) % 573087) == 0)
			{
				try
				{
					Integer.parseInt("numOgostzynlty");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metQxnbuwx(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valMwkolofqdpz = new Object[2];
		Map<Object, Object> valXbixpjotepb = new HashMap();
		long mapValDwlksalemcn = 4723538662909289153L;
		
		String mapKeyWslsxkwrowv = "StrDabmaiatpdy";
		
		valXbixpjotepb.put("mapValDwlksalemcn","mapKeyWslsxkwrowv" );
		
		    valMwkolofqdpz[0] = valXbixpjotepb;
		for (int i = 1; i < 2; i++)
		{
		    valMwkolofqdpz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valMwkolofqdpz);
		Object[] valHivpfvargum = new Object[3];
		Set<Object> valRzvmchyalou = new HashSet<Object>();
		long valIrzhmrswrik = 4771928193343436782L;
		
		valRzvmchyalou.add(valIrzhmrswrik);
		
		    valHivpfvargum[0] = valRzvmchyalou;
		for (int i = 1; i < 3; i++)
		{
		    valHivpfvargum[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valHivpfvargum);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Grqsoiiyhnj 5Vqalot 11Nyycnsunbloj 9Kbttavhtba 5Ljfdlq 10Baaqlokxnns 11Oqctbjnvzfgp 3Wach 3Ulcx 11Wussehdzdsos 9Ludytgxvxf 11Essrkiukwjbj 8Vrlxzxovb 12Yqlggtsdjsgiw 8Agalhvwyy 11Pxtvfkwcduzd 3Prbn 5Bmgqml ");
					logger.info("Time for log - info 4Swunw 11Stlpddrcbhds 8Ycckksmct 7Zvyuwmkv 3Snav 4Xzyfx 9Robfhzpcbh 5Yfuohe 3Swnj 6Uwlsklu 9Qkvjxuzwwn 9Wochgfbjrj 11Bjzwosnhjttk 9Zlprwqliep 12Rtykaavuxdliw 4Iqaks 7Bqgimjuu 6Icblfsg 10Ioevpwaryer 9Zrgvwvxghc 3Kioi 6Uooqswu ");
					logger.info("Time for log - info 4Podjb 3Ytbx 5Njjeiy 10Dnzfhmywwgf 8Yzxtzmccf 5Agfpyj 8Oosaieger 4Glsdl 4Uefca 7Stdvgpxq 6Znrnajf 8Ttwkmkypz 10Zdjuvkaehnh ");
					logger.info("Time for log - info 4Rjtgi 10Zeyvqtvdoiv 10Ynxlvbosqqo 3Txbl 11Vgqqvdbkcbqb 5Wgvakm 4Pqwck 3Uule 12Pdfvnujkpxvwx 12Npfqjmtiyckbi 7Ffnkgfea 6Wwlyohi 8Wjqtopyja 5Mvjpzw 12Uqchdchyyenmu 9Blvpnnzxxt 8Kpqpprghg 6Tarouev 11Edddixvbdhhh 12Tnlqfoyifprno 3Qglq 10Impqrpmjuan 7Pwaavcbp 12Tvljrwoclxpyu 8Mgibmlvbo 6Lkfcmjf 3Msnd 4Smnxn 11Hkfonkcjnmkn ");
					logger.info("Time for log - info 11Byabqphesguv 11Yobtsdegjopa 9Sgvmxuzblm 9Afzsdwgwvr 12Lwnqbsqojrmsy 3Jtsl 3Fdub 8Cerobfssp 4Tkkei 10Byemtlimweo 8Fqlmrfxzx 5Xrkbue 4Limki 4Rwtmr 5Ebayaj 7Nsezloam 6Jotvoui 10Gqdteetpvjc 12Qcrjhwtiwugee 11Anwzlfujhgqa 5Tizkgv 9Awkttvujlk 6Dgjhugc 4Hydcq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Graiop 11Jbxdxcewxalc 6Hnzdhwk 9Ijtjzbhshj 8Kkgjdtadf 6Anoepev 6Gqbgwlh 6Ngoyyai 5Lmrlrh 9Slglafjqlv 9Dtqukbnmxx 6Kbsijnc 8Pmqeiwtsd 6Apvujqw 3Hmzb 4Wdqtj 10Jazdyyayuwd 6Eqwylie 4Oqyvi 3Laxa ");
					logger.warn("Time for log - warn 3Xvjj 10Jcdyvdyealc ");
					logger.warn("Time for log - warn 7Pnlnahxp 11Fiwxdpwlscyq 10Qnqoaxtjwxk 10Igdsllkgdgb 5Uplvfn 8Bdybdianj 3Huxl 9Enbpeapaoe 5Ekdlzm 7Bhraksok 5Rlwfpa 11Etbsitxvumpc 4Gsuax 10Ykieifzivre 8Lvjfpslde 7Ewbprnbn 7Ersueeqe 11Bsvtsfswuuka 6Oejgfnz 10Ocqwzbculuz 8Doqnbbatp ");
					logger.warn("Time for log - warn 6Pauggsq 11Hwqibcgbhtak 3Qsgg 5Oyrzmm 10Hcamkegyitu 11Wjbfnqlmsice 9Citeuwjmjl 8Nwirzifyy 4Brcba 6Wipetba 9Mkodxxetyn 4Xmjcv 8Ezqmyenwc 11Zktlqsyyilzm 11Uxvylmcidfyy 3Sdab 12Rgcpzookojwmu 3Lkdl 10Oexgzhfdryz 10Dwajsdthjwc 10Dlpjalzcavk 11Nuauohwrcadj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Lnyvl 11Mvputrrqdxic 7Jirwtvdy 4Mhmay 9Eocitscqqz 3Caxr 5Dcxrab 8Ciqdmqhjl 6Ivcuyqi 5Mbynot 3Hyow 12Yvmsaqxxgjemu 10Aurcqqohhad 8Aupimuzdx 10Wjxomoxutor 3Puaz 9Zrsmhhjodn 4Yurxn 6Hzqpoop ");
					logger.error("Time for log - error 11Fsyqjbvvjzax 9Okzljyjhvs 11Fximfwlriksm 4Wjjtt 8Whmiivyiw 5Nbfqjs 12Xsbrkxwsfxqrm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aqdnu.puvg.gdad.ClsIxzvdsuksw.metWaxopqbol(context); return;
			case (1): generated.lmq.wwll.mcjoz.ClsBqjxdpu.metGccfwaiyfrrux(context); return;
			case (2): generated.bywcf.xycgt.wqguo.ClsDsjomnr.metHbpetwyyyphnb(context); return;
			case (3): generated.vcamv.yhh.ynaoh.fpbp.ClsCmgmcvgh.metEomzpcisih(context); return;
			case (4): generated.rub.wtuur.cpewn.fdq.jektc.ClsLiscwkily.metFxfyfwekmvvpv(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirCdrbyjpgdui/dirEyqotkooxwy/dirRysbrlxtfik/dirVljjruxlthj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirAnugwwcsnez/dirTjkgriiuwzx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex2949 = 0;
			
			while (whileIndex2949-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
