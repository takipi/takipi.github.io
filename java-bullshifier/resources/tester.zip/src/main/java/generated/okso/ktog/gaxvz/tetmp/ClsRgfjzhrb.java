package generated.okso.ktog.gaxvz.tetmp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsRgfjzhrb
{
	 public static final int classId = 386;
	 static final Logger logger = LoggerFactory.getLogger(ClsRgfjzhrb.class);

	public static void metVduhhhsluhwuv(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valTvmwkytmmqh = new HashSet<Object>();
		List<Object> valDcrcnootilz = new LinkedList<Object>();
		int valKdpjayfzhxx = 428;
		
		valDcrcnootilz.add(valKdpjayfzhxx);
		int valRsxycxqonek = 399;
		
		valDcrcnootilz.add(valRsxycxqonek);
		
		valTvmwkytmmqh.add(valDcrcnootilz);
		Set<Object> valBymhexclisj = new HashSet<Object>();
		long valXozfqvqjwvm = -3958403781849890914L;
		
		valBymhexclisj.add(valXozfqvqjwvm);
		String valSiavrgugukh = "StrOdyodgwzmlw";
		
		valBymhexclisj.add(valSiavrgugukh);
		
		valTvmwkytmmqh.add(valBymhexclisj);
		
		root.add(valTvmwkytmmqh);
		Set<Object> valPlvzzprqgmv = new HashSet<Object>();
		List<Object> valHdnsymbovuh = new LinkedList<Object>();
		long valMmehrrfllew = -3967792989466155759L;
		
		valHdnsymbovuh.add(valMmehrrfllew);
		int valNynknafhngy = 603;
		
		valHdnsymbovuh.add(valNynknafhngy);
		
		valPlvzzprqgmv.add(valHdnsymbovuh);
		List<Object> valZshrtcyerhd = new LinkedList<Object>();
		int valCnfczefqwmp = 143;
		
		valZshrtcyerhd.add(valCnfczefqwmp);
		
		valPlvzzprqgmv.add(valZshrtcyerhd);
		
		root.add(valPlvzzprqgmv);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Hjpokxu 7Qzcjqedm 10Kamnxfnsyfe 11Jqcvgvnijmlg 4Vsmij 3Hkeb 8Adsbvvsif 6Wayfxgx 10Vgwyrntcgkr 8Vtnhqdptj 6Bjktjsa 6Hianhxm 11Wefmwdkvhzsx 11Kabatkkyozil 6Hjnqrqu 9Chsqwouexv 10Lpztkfyceev 12Neufvokjluxuu 10Wyycselcaza 8Plopopdhm 3Inaz 3Ucxu 10Boxgupyzlmv 5Blgcgl 12Fxnwtzanpmios 6Vbwcxbz ");
					logger.warn("Time for log - warn 9Thfmmrkkqy 11Wiqwsqbdqmhr 3Ztvr 11Qafqxzazhodm 6Qtpcpnp 11Xjvzxydvluhz 6Gprlfga 11Siudhquijada 4Icrnd 7Zwejcrpn 4Onlhq 10Ztwegicemqt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Fpizylh 9Xjlzwgraqh 12Sjjxqnhrtptld 5Bmbxuc 4Unfws 5Rcosiq 8Qxmoegxqy 3Feyz 12Nnccpdzftmqrq 3Cpgo 7Jyamahdn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wwon.szd.tew.ClsRzjcfflrioiqf.metGxlswbykyhhwq(context); return;
			case (1): generated.qpya.todk.woo.rrzxr.ClsQlmcomguvtqu.metVbgwaaycr(context); return;
			case (2): generated.qnmn.narfk.rdhdk.ClsPtwatcpapj.metGdaktormyy(context); return;
			case (3): generated.vyk.nsacl.bsfy.saukt.ClsKpfdsyokiohmf.metYmoozuxldwzan(context); return;
			case (4): generated.eddt.homo.syk.wqll.dyeuq.ClsYzlmjqrjjp.metMqehtaaykikdy(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numWmlwkhdfosg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex26534 = 0;
			
			while (whileIndex26534-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numQksoggkjdiv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metNvgqnwoj(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValAxkwzkxnzxs = new HashMap();
		Set<Object> mapValWsqddzvfrir = new HashSet<Object>();
		String valYnsvxxbbtfm = "StrVywpcxnwebc";
		
		mapValWsqddzvfrir.add(valYnsvxxbbtfm);
		
		Object[] mapKeyYxzyljipraj = new Object[5];
		boolean valChiywobgmvy = false;
		
		    mapKeyYxzyljipraj[0] = valChiywobgmvy;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyYxzyljipraj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValAxkwzkxnzxs.put("mapValWsqddzvfrir","mapKeyYxzyljipraj" );
		
		Object[] mapKeyQrwbwtzrwmh = new Object[8];
		Set<Object> valWszwlwjvqmq = new HashSet<Object>();
		long valCarorwyldhg = -4816858287083673070L;
		
		valWszwlwjvqmq.add(valCarorwyldhg);
		
		    mapKeyQrwbwtzrwmh[0] = valWszwlwjvqmq;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyQrwbwtzrwmh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValAxkwzkxnzxs","mapKeyQrwbwtzrwmh" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Sowrchb 8Csqkepgfi 7Iuyegeee 3Xaxt 8Bkkgytyrj 6Mxgbirb 11Urbugfkrdnnn 7Gmrkdbbp 5Jcjfzz 8Dhsqootpt 8Fulnokbhg 9Jlzqozrhfi 6Zloxfog 4Yzqtj 4Afnee 8Oukvmkjrq 9Dejxcerfvo 10Kpmlbuycfhe 9Klppycpcpq ");
					logger.info("Time for log - info 12Esxuoakefnxba 8Fhwuyryrp 7Fyxxsrpp 5Pnomry 10Rithakgucyw 11Fasjepveekom 8Svywuggty 12Nhepwhsdgmayf 9Prokxhwted 5Jlszaw 9Tdjszykegq ");
					logger.info("Time for log - info 7Qxhuqhqy 4Nfynq 7Sftplloz 10Skxupdjxuzk 7Lvjcxmvh 6Tqsamcv 8Prjpjiffo 10Ieghyddncpl 5Lfztfx 8Ixkswmksp 12Fzavexyaaxypj 8Jcmmibsxq 6Romyujy 10Wgvuwecvdcb 10Qoyibjbxfrk 4Hxsdt 3Pehl 12Oyucggkokofjv 8Jctlgpsfl 3Zbvt 5Vmflqq 9Aqrpywjahg 11Unhrfywoquop 4Vhtxb 6Zedbtpc ");
					logger.info("Time for log - info 10Ehuustgordy 11Xenhjygdpiut 9Uqtsnfgcfm 11Skankvhqbzvn 3Jfuj 6Elojgrq 4Tkfzc 3Znat 7Rpmtzzte 12Dhgzqxphwtplz 6Vtgiowf 8Wbdsvlkbb 7Wiuwekgp 5Ifhisc 12Apvsypeehmbqw 6Dnulrcr 11Eumcylyewacy 11Zjpnqnuhoecm 7Unhkgwbp 11Pnxibrtmfjnr 7Wibuaole 10Gouoyregjwu 9Seklbjgrgn 10Vutejidywty 5Bnfloh 10Upwmkwfnysv 9Undwdbnvbv 11Kcepkqrunnzc 3Dxdk 10Ighcjxovavo ");
					logger.info("Time for log - info 8Ajgazdydw 12Gralhtndoanae 7Jygbtrle 3Rxsu 5Kpwdux 4Pqwje 7Jlacpbrj 6Drrqayz 10Hwdxhzvnvml 8Wamvfmryw 8Qvdugvdpr 6Ruirfng 5Hyyzdn 10Lazkxtgjtob 10Nxszigyasjk 9Kidogeffjx 5Bjieyx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Sdodxdmxlcvz 7Efhioqkb 9Nfiqzezosq 4Vvwec 3Doeb 9Qbewanukkj 4Kyjhl 4Totby 7Nvgupbdo 11Toispsrcclfh 5Fpijjt 9Tcnfiipxxg 8Pozfbhrvx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qpe.ifudp.xgatn.jzg.qau.ClsJymdeqopgpbo.metKphqyqlpqj(context); return;
			case (1): generated.axdim.stv.ClsSaegiqo.metVwtuv(context); return;
			case (2): generated.qnmn.narfk.rdhdk.ClsPtwatcpapj.metAlhpjsfvu(context); return;
			case (3): generated.jbipj.zrsb.daypv.qszx.ewk.ClsVnncvmwdx.metBqqpsfdskrnrd(context); return;
			case (4): generated.gasq.isr.fpndy.jhzr.ClsNxizwkdumgga.metEyznktcptuql(context); return;
		}
				{
			if (((3108) % 958192) == 0)
			{
				java.io.File file = new java.io.File("/dirCyzgvhsmzay/dirErzryumnvvt/dirGvkaiojndgn/dirFcweodajgoz/dirWqwxgoclczu/dirVglebxziang/dirLvzvqiomxhs/dirLduwukreooo/dirMibejyokfey");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((8183) % 422398) == 0)
			{
				try
				{
					Integer.parseInt("numExablpishdq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varMfcxxtvstek = (3882);
			long whileIndex26546 = 0;
			
			while (whileIndex26546-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metLlvwdlebp(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valQiipjqvtfrk = new HashMap();
		Set<Object> mapValOsxhqhoraaj = new HashSet<Object>();
		int valUomfsloruty = 147;
		
		mapValOsxhqhoraaj.add(valUomfsloruty);
		
		Set<Object> mapKeyZelrylzxjwc = new HashSet<Object>();
		int valClcwgujucvq = 508;
		
		mapKeyZelrylzxjwc.add(valClcwgujucvq);
		boolean valNuuemyzmjil = true;
		
		mapKeyZelrylzxjwc.add(valNuuemyzmjil);
		
		valQiipjqvtfrk.put("mapValOsxhqhoraaj","mapKeyZelrylzxjwc" );
		Object[] mapValAesrmosytfr = new Object[3];
		String valGlibnevduui = "StrYmecuiivpdb";
		
		    mapValAesrmosytfr[0] = valGlibnevduui;
		for (int i = 1; i < 3; i++)
		{
		    mapValAesrmosytfr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyCqvhrxwmiag = new Object[10];
		String valYtgyrckaoda = "StrRpymjgamcbl";
		
		    mapKeyCqvhrxwmiag[0] = valYtgyrckaoda;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyCqvhrxwmiag[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valQiipjqvtfrk.put("mapValAesrmosytfr","mapKeyCqvhrxwmiag" );
		
		root.add(valQiipjqvtfrk);
		Map<Object, Object> valCqakxtfsiwy = new HashMap();
		Set<Object> mapValBarmhoenlpa = new HashSet<Object>();
		long valOdlmneqlepf = -2129314920126103216L;
		
		mapValBarmhoenlpa.add(valOdlmneqlepf);
		String valLmtonmcgbcg = "StrRwhbkmdmcjm";
		
		mapValBarmhoenlpa.add(valLmtonmcgbcg);
		
		List<Object> mapKeyLhmxmxnlszj = new LinkedList<Object>();
		long valMmgvfnyvkms = 1099078529726095937L;
		
		mapKeyLhmxmxnlszj.add(valMmgvfnyvkms);
		boolean valXvoannuhpwq = false;
		
		mapKeyLhmxmxnlszj.add(valXvoannuhpwq);
		
		valCqakxtfsiwy.put("mapValBarmhoenlpa","mapKeyLhmxmxnlszj" );
		
		root.add(valCqakxtfsiwy);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Mcmpwjjetzoix 9Geukjjjkwe 8Pqegdrebe 4Xdttb 4Uiemk 11Pqunnjhxftoi 3Nvtq 7Qponhdpc 9Noauzkepdh 4Nzszh 3Kgmm 7Uophsgwk 11Itbeeohipgqp 3Qkgk 9Ehutpippuf 6Pwtwaam 12Vgkxtluoncdpc 8Ciwzvpacm ");
					logger.info("Time for log - info 3Zcio 9Kecxdaxncg 3Xzmh 11Qytcybekidun 10Nbgbexqkunm 5Ubrcyk 4Gpjsj 11Frfhhwzrmkhg 12Xabtmwwkgukuy 3Gpbe 9Cgkcamathc 4Rsobu 9Vintihnait 3Nixb 8Soaxrcoar 12Fejjjvlyuqyhf 9Nkiytipjvw 9Sycslvwrcf 7Plyumwgl 8Pknnmcsnp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Lucthho 6Rozcyqs 9Glsktelnzp 3Zvzf 7Cmcyocsn 9Axhsfunrwc 10Xslnnohsxuf 3Dkti 7Godipywt 5Zhaorx 4Xazra 12Whiqilzyeukiw 4Vvirt 12Jzmexynafjnzy 5Pamfhc 4Xtkjb 5Iegbna 9Njsrltopxn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xam.emsw.ClsNwmpfankaxgqb.metYfqgrrxvvcg(context); return;
			case (1): generated.hzw.xclp.jagge.pvih.oqmlx.ClsBjaeoqqxwxxp.metAhluzg(context); return;
			case (2): generated.rjuw.mmbua.ClsRawvqxmhewbl.metOsciin(context); return;
			case (3): generated.ifyrm.rwj.ajr.gkqyg.ClsSfeshwgdectgpm.metKuczfwtup(context); return;
			case (4): generated.egtuf.tby.poy.tetgn.cnw.ClsOidjvegh.metTjmqwo(context); return;
		}
				{
			int loopIndex26553 = 0;
			for (loopIndex26553 = 0; loopIndex26553 < 1945; loopIndex26553++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((3110) * (Config.get().getRandom().nextInt(521) + 2) % 343840) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(403) + 1) % 94319) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirWvrocssapqh/dirUfzpeumkxlp/dirDnafzqdquaf/dirQftlkjrayob/dirJlfpvusmyxn/dirIsyanjxeoqx/dirYmwhculcnht/dirVdoqadrijwx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
