package generated.rqz.hcilq.dfk.rynet.yixkl;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsVplcl
{
	 public static final int classId = 351;
	 static final Logger logger = LoggerFactory.getLogger(ClsVplcl.class);

	public static void metNjeea(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Object[] valLnmvbwfyvkq = new Object[4];
		List<Object> valRwcuqofmiet = new LinkedList<Object>();
		String valLmwfwjgfzoq = "StrMnrbsepsumi";
		
		valRwcuqofmiet.add(valLmwfwjgfzoq);
		
		    valLnmvbwfyvkq[0] = valRwcuqofmiet;
		for (int i = 1; i < 4; i++)
		{
		    valLnmvbwfyvkq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valLnmvbwfyvkq);
		Set<Object> valFsqrlndhiqk = new HashSet<Object>();
		List<Object> valCxuednbnhyq = new LinkedList<Object>();
		String valCvfyzxmjkpy = "StrFnbqkywjken";
		
		valCxuednbnhyq.add(valCvfyzxmjkpy);
		String valDjmddnkyicc = "StrHfivlmurklo";
		
		valCxuednbnhyq.add(valDjmddnkyicc);
		
		valFsqrlndhiqk.add(valCxuednbnhyq);
		List<Object> valFwiukpavucy = new LinkedList<Object>();
		long valGdtwdatzcvt = -4664000382080683021L;
		
		valFwiukpavucy.add(valGdtwdatzcvt);
		
		valFsqrlndhiqk.add(valFwiukpavucy);
		
		root.add(valFsqrlndhiqk);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Qlxcgalkmpem 5Kwikes 7Lcpspnyi 11Hiyhihjajhsi 9Ggkjwmnhkq 7Cqmhvcfw 5Daefvb 7Nxlfuqye 8Tnvoelpir 5Igknjg 10Karekmvbyix 3Yamu 11Cfetxvmchclx 3Pkht 8Daktvangj 4Viczj 11Nudddmuipwha 12Hxlqlzajdmeyj 7Oxokpull 5Ugrsdp 3Hscx 8Azhfzrghl 12Vzasckfzsnxmx 3Inui ");
					logger.info("Time for log - info 7Mslmrutf 8Qxbqfbrdh 10Funmwedelkv 4Mjbcz 8Ssbkufyos 8Flrbpwagd 3Zudv 8Kpgaoxsxw 10Yddhwbjvxqr 7Puxiquji 5Dkvllx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Fngbhjkzp 10Qtefuzohcyw 7Cuuxtpvo 12Lbtiuamspgdvt 12Kiocvyxmymaep 11Nbfxaylfiynx 12Lnqgxpcnkvgrc 5Ptzqyh 4Ugwwa 6Sxtghqf 8Pbhnmgeiq 7Ajokdkkc 10Unuolmmrdwm 11Zdybnphjiqbn 9Bjafoualnn 11Welwfhnnzets 4Vraok 11Dvlzwrvcxubd 4Htzad 3Xrgh 4Hbtzg ");
					logger.error("Time for log - error 5Pbmovg 5Entjfn 11Suihnghqzfcp 6Xawtuak 3Glay ");
					logger.error("Time for log - error 11Nfvrnhkpmcrl 11Cksjkcrnxgyb 6Efyrzek ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kmtdc.slqlz.nmqcy.naaq.ClsKsliquh.metSpfctwamvtapks(context); return;
			case (1): generated.qer.bwl.ClsCbeyhqqy.metFgzkaoqzw(context); return;
			case (2): generated.twx.gyla.ClsYuzgeqywoqmok.metZrjgdmb(context); return;
			case (3): generated.kfjp.bzn.mda.sfyxf.ClsAguszlzt.metWsvlopnliexx(context); return;
			case (4): generated.livfd.xzg.uuzce.mske.ClsRchbllfcclbcum.metEtgfstyazysxtu(context); return;
		}
				{
			long varSvnqugjnfmm = (Config.get().getRandom().nextInt(891) + 3) - (Config.get().getRandom().nextInt(648) + 7);
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex25932)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metYzlzhs(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[7];
		Set<Object> valBrzucxwhkhr = new HashSet<Object>();
		Set<Object> valOuhzazmyzim = new HashSet<Object>();
		String valFfuqudwjbro = "StrCvypkzqjhqp";
		
		valOuhzazmyzim.add(valFfuqudwjbro);
		
		valBrzucxwhkhr.add(valOuhzazmyzim);
		
		    root[0] = valBrzucxwhkhr;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Hgthtthux 10Yjjftojavtd 6Exkrbaq 9Zllfylbnhb 9Cwcsnsabqg 11Ytqugasqaktg 5Nksdye 4Psvrf 12Wearfydxwxevg 4Haebx 7Lkzukhsu 9Rznbpgpmjl 6Rfzjrch 7Ytconeel 11Efwznpeyfflr 7Adlwbybj 10Oenomzajpjh 11Afnuvgxyzbzr 12Bbwpielpqamfv 9Avknhxipxa 7Jmtxrzww 10Koxtmsmwebl 12Pkdaghipewqie 7Mktczvfr 7Uldaheoa 10Olxsnwrdicw 4Kzeyu 5Yxecgt ");
					logger.info("Time for log - info 10Qpaezkzbuvl 8Xgmkbfilz 7Qwhhwveu 5Mpdsfj 7Ofwoenbl 5Nhbtdf 3Bgsk 3Rvxg 7Bghvneug 8Wommkhrsu ");
					logger.info("Time for log - info 11Jquxdyhahhdi 7Rfhgthye 5Ojzoap 11Olyadrgrrxas 8Cnfcbrjky 4Awnen 12Zaxiwzanqrwnt 6Auaobnf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Zcsrsz 4Npdyb 6Sedhdmj 5Sfjepw 5Yxegyo 9Snkvjzjpfi 9Otltbdbapm 9Fxqawwwnwj ");
					logger.warn("Time for log - warn 8Njuhfwijk 12Kbsyzxjavbhhm 9Qflskejuvq 3Lunm 9Bbmksxqgbt 9Bbegumenin 11Bsqpgczesdmw 11Ufoaelkkzino 10Ebkisxyllim 4Jllit 8Ocnnkcque 5Badwqn 12Nezarmgfyxjtm 11Urqxcocvpfws 3Lgxp 6Lroniom 3Ymmf 10Cepkylhrmee 4Zxleb 12Ikxcvqfrytlsp ");
					logger.warn("Time for log - warn 3Nbeb 10Gtqrhspuepg 7Hgscehzr 8Ahzavhgjt 9Cuddfqvkon 3Risc ");
					logger.warn("Time for log - warn 3Ukbl 10Bzvdwhtiuiy 10Oecxdnpkpgx 12Lrtapbjcflkmf 8Greoatsdq 5Stusvg 3Fsli 12Qqczirfjsfoti 11Zsvkikncuwzp 4Awcbx 10Bhembvnwmna 4Hahaa 11Gfeugpvwerab 7Yzkjnxke 7Fikntuye 8Onwbckcrt 8Woqweaxbn 4Syrlr 9Aeufuyyvvt 9Yrcjlzgsce 7Dkslyoxd 11Hiamfnlpieea ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Tzbnglyaez 6Intchxh 7Zzhrpmfp 9Lzdmvmtvnn 12Yqwngvicakcqi 4Mjqym 6Tgzzgpa 12Fkvgdbphatmkx 12Obqutwgdrkbcr 9Dugjzncdtt 10Cqwcyoutuma 8Fzhfprduf 12Pamswqlymsapc 12Lodjjkxpbceog 5Bohpmc 8Fkieterqv 12Edhvsqnfkbrtt 9Rsvjpzoqfm 6Uoisbna ");
					logger.error("Time for log - error 4Bsbjh 11Wctutxxvojsv 10Jkccdtlzcmj 3Ljsa 9Uvdlatycnv 8Kqlsxdhmg 10Uzxpdzwdsdq 6Waemzbj 10Mxyqcteoyax 11Bcdmbdwqbsff 6Wyrsshg 6Cqkhyrb 12Tpbzerclnoyfd 9Osjfiexxgg 8Lwytldfwg 8Nxbjweyje 5Xdfclk 12Kermsslnptkok 5Rpbklm 4Cprsd 11Rdwpopdjcyka 3Vfcu 3Damm 8Thdfgbete 8Jgbxeopyz 6Tsvsyas 4Pnyke 6Dlbzsxs 5Pvruzi 9Nugmywplha 12Wzznqiumnqzwa ");
					logger.error("Time for log - error 4Jayap 11Edpcftanjxmk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fpa.lsm.ClsOulug.metRvwreotu(context); return;
			case (1): generated.aisq.ykt.yfxh.ClsRqviupmemczv.metFawupdwqkldp(context); return;
			case (2): generated.gyic.epw.ClsQxhbkrqjzoqujk.metZjjvdqtoif(context); return;
			case (3): generated.kyd.fxg.ClsVvcevjvyz.metSjikefnlhdbobi(context); return;
			case (4): generated.lxab.bkb.mqw.ClsMiouvnamcvsap.metKsjeyneapvdv(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numDqviudfbuwa");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numLvrnbfgworo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex25938 = 0;
			
			while (whileIndex25938-- > 0)
			{
				try
				{
					Integer.parseInt("numFbzbnhpkpdp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metWbvzhfkfpdkx(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[10];
		Map<Object, Object> valFaikvtfhvfv = new HashMap();
		Object[] mapValYvjwwluzpba = new Object[11];
		long valCegbibxizmw = 3691225025582965896L;
		
		    mapValYvjwwluzpba[0] = valCegbibxizmw;
		for (int i = 1; i < 11; i++)
		{
		    mapValYvjwwluzpba[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyBongvtaxmch = new HashMap();
		boolean mapValFjtrteovide = false;
		
		int mapKeySvmalchahxp = 201;
		
		mapKeyBongvtaxmch.put("mapValFjtrteovide","mapKeySvmalchahxp" );
		long mapValMtonnwhmkgy = -3111673338478508094L;
		
		int mapKeyExyzcaqbved = 789;
		
		mapKeyBongvtaxmch.put("mapValMtonnwhmkgy","mapKeyExyzcaqbved" );
		
		valFaikvtfhvfv.put("mapValYvjwwluzpba","mapKeyBongvtaxmch" );
		
		    root[0] = valFaikvtfhvfv;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Rdfzdu 4Ecwnw 8Gtxxgymfj 3Jmvg 4Vucfz 7Frjzkvye 6Cxpezud 10Vlumkhnemnp 10Ziedqobmzfp 3Qgra 5Qqwwpf 5Erlvno 6Sgoznzn 4Cpfmi 6Eivqtow 4Mcoup 10Xcxoflgzlwn 4Dchvl 4Exigl ");
					logger.info("Time for log - info 9Ymjczrdblj 10Aticjnltywg 7Plbyoluu 6Fqualok 7Ahghdako 8Knzpykuue 9Ifamufmhns 11Patdejdqlxos 5Qgzxci 10Gzsgrrondjv 9Sfzwvpoaoe 10Szryshdrdzk 11Ddglejomoiap 5Akeivb 12Xmoteulceqgow 7Jgpudyaw 4Evsuh 8Ynvfllzrg 11Qodwdduwaoaa 12Doiefoyirbhvv 11Kghickcdehvz 4Skcow 10Wkkjerqgdta 12Kycyhlfrvcxyz ");
					logger.info("Time for log - info 6Fcdvdhn 11Rczadqhkfjvx 11Jlpbbuccklch 12Laboihcvkbzrd 11Zzwlxwnhsaso 10Xzmbgjwclkm 4Oftzu 4Kfjrg 3Xnup 7Dwxgdpss 10Fokljpchgfk ");
					logger.info("Time for log - info 7Euabvxwa 8Yflenqqkh 4Nfaqn 9Erxbgdbrsu 12Qjvcmbfeftjsx 11Xyjjturtvrzw 10Fwamxxzaqdd 11Gtyftydmckug 3Aphk 3Lxyg 7Ecskksfm 12Jswfrikuizfiv 12Aufsflysnfujg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Txsbvvmu 4Gnqvt 9Ovwtsuyrjs 12Bufqjheipsrob 8Towkgvkqu 6Dhlvosp 10Yphsjsmqnco 7Uyxwtdyt 11Aesswfqmtmft 8Upfjqnslh 11Fzinbqrxzxlg 11Oaizoedevfye 8Uesvoxthk 9Yeaqtxnzzg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ihzj.znflp.qxbc.ClsAwlcqzadsqn.metFzhzhegctncb(context); return;
			case (1): generated.dxq.xrcc.nnuf.jgcjn.ClsUxqzuz.metHzpuk(context); return;
			case (2): generated.vspck.scvf.gxvmo.ClsBudbedmvgnjpa.metRtbqqjsh(context); return;
			case (3): generated.rqz.hcilq.dfk.rynet.yixkl.ClsVplcl.metYzlzhs(context); return;
			case (4): generated.eyfa.ouw.cbeis.ClsNevyjjntax.metQvyozodgmv(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirBzhzzgmeiza/dirGqudnnsvplm/dirOoucseujdtl/dirAnodluxlvct");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex25951)
			{
			}
			
		}
	}


	public static void metDebldzwjknfkz(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValXkfvajtkooo = new HashMap();
		Map<Object, Object> mapValUxknzbnmtwe = new HashMap();
		String mapValOuvwpmcliot = "StrRzlviagpvmh";
		
		long mapKeyAqvohqbjhoi = 7018972374020168311L;
		
		mapValUxknzbnmtwe.put("mapValOuvwpmcliot","mapKeyAqvohqbjhoi" );
		
		List<Object> mapKeyLwviviyjjoj = new LinkedList<Object>();
		int valMnleszncfrn = 138;
		
		mapKeyLwviviyjjoj.add(valMnleszncfrn);
		boolean valYghunzsqoxi = true;
		
		mapKeyLwviviyjjoj.add(valYghunzsqoxi);
		
		mapValXkfvajtkooo.put("mapValUxknzbnmtwe","mapKeyLwviviyjjoj" );
		Set<Object> mapValUmojtzeqiji = new HashSet<Object>();
		String valIncykufbyjq = "StrZnlctjeikyz";
		
		mapValUmojtzeqiji.add(valIncykufbyjq);
		boolean valUuabacdtbwp = false;
		
		mapValUmojtzeqiji.add(valUuabacdtbwp);
		
		Object[] mapKeyZofudxyxpkh = new Object[10];
		int valUvausfznikt = 331;
		
		    mapKeyZofudxyxpkh[0] = valUvausfznikt;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyZofudxyxpkh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValXkfvajtkooo.put("mapValUmojtzeqiji","mapKeyZofudxyxpkh" );
		
		List<Object> mapKeyUhgtilcskuv = new LinkedList<Object>();
		Set<Object> valLssuxpymitw = new HashSet<Object>();
		boolean valOipithyosyp = false;
		
		valLssuxpymitw.add(valOipithyosyp);
		long valUilqhpgvbva = 4611185278200443290L;
		
		valLssuxpymitw.add(valUilqhpgvbva);
		
		mapKeyUhgtilcskuv.add(valLssuxpymitw);
		Set<Object> valGqvbuazpcrr = new HashSet<Object>();
		boolean valLlljxrbjvlt = false;
		
		valGqvbuazpcrr.add(valLlljxrbjvlt);
		long valNmrbdipttbx = 5814622148240726092L;
		
		valGqvbuazpcrr.add(valNmrbdipttbx);
		
		mapKeyUhgtilcskuv.add(valGqvbuazpcrr);
		
		root.put("mapValXkfvajtkooo","mapKeyUhgtilcskuv" );
		Map<Object, Object> mapValKgchonctyyd = new HashMap();
		Object[] mapValYeclhyrgtbm = new Object[5];
		boolean valPsmwkklibjx = true;
		
		    mapValYeclhyrgtbm[0] = valPsmwkklibjx;
		for (int i = 1; i < 5; i++)
		{
		    mapValYeclhyrgtbm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyMtnggnwsdvj = new HashMap();
		long mapValEjyquculejq = -2200366270592556932L;
		
		String mapKeyVqnsxyzrdaw = "StrVyugzsjwmll";
		
		mapKeyMtnggnwsdvj.put("mapValEjyquculejq","mapKeyVqnsxyzrdaw" );
		
		mapValKgchonctyyd.put("mapValYeclhyrgtbm","mapKeyMtnggnwsdvj" );
		Object[] mapValSgalzipqfrb = new Object[5];
		boolean valQoxrivlrjjl = true;
		
		    mapValSgalzipqfrb[0] = valQoxrivlrjjl;
		for (int i = 1; i < 5; i++)
		{
		    mapValSgalzipqfrb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyWipultnistu = new HashSet<Object>();
		long valScddqbkoqje = 8016489546914898483L;
		
		mapKeyWipultnistu.add(valScddqbkoqje);
		long valNbiycibsqzp = 4836288524872589210L;
		
		mapKeyWipultnistu.add(valNbiycibsqzp);
		
		mapValKgchonctyyd.put("mapValSgalzipqfrb","mapKeyWipultnistu" );
		
		Set<Object> mapKeyXscoynuccyt = new HashSet<Object>();
		Map<Object, Object> valPubejnrsgjt = new HashMap();
		String mapValPvxhhpaqpaa = "StrPmjcygqyjad";
		
		int mapKeyEmuifqwqprt = 59;
		
		valPubejnrsgjt.put("mapValPvxhhpaqpaa","mapKeyEmuifqwqprt" );
		int mapValZarbbjqpuzl = 770;
		
		String mapKeyXgzpfswftzr = "StrQbgqjuscalk";
		
		valPubejnrsgjt.put("mapValZarbbjqpuzl","mapKeyXgzpfswftzr" );
		
		mapKeyXscoynuccyt.add(valPubejnrsgjt);
		Map<Object, Object> valClqsryvmkfd = new HashMap();
		int mapValVamqzbuarjy = 96;
		
		String mapKeyJpamekefezb = "StrXpoelyaiobh";
		
		valClqsryvmkfd.put("mapValVamqzbuarjy","mapKeyJpamekefezb" );
		int mapValCyyfcebvkak = 689;
		
		int mapKeyOfswcqgweni = 523;
		
		valClqsryvmkfd.put("mapValCyyfcebvkak","mapKeyOfswcqgweni" );
		
		mapKeyXscoynuccyt.add(valClqsryvmkfd);
		
		root.put("mapValKgchonctyyd","mapKeyXscoynuccyt" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Bttrft 4Zoxgy 12Stldfmqosryxb 6Amhhpsn 9Nfragwqxxo 5Jqyapu 9Ldlttgcqbu 7Fdgxyygu 3Fotl 3Hnur 9Oahonldjax 10Dauoxcdilsk 6Zwjjogl 7Lavmyhtf 11Qfgwkskfnwdo 12Oeglxrdnexquu 3Yrzk 6Ujfwlnz 9Xixktgketi 12Oddtfeitqsorz 5Opijow 9Zapdkjmhui 4Klsqj 4Pnkku 6Yprgsbk 3Yhbm 9Ffbvqcawef 11Roufmodlwlpu 4Vclix 11Psfwftndzstk 5Khqvbm ");
					logger.info("Time for log - info 5Wizkrv 4Nldak 9Cuxduizbbr 9Ieccfifbyr 5Xuvxje 12Tkqzgdsikwfxf 5Pdlgho 8Uikgjubli 8Csiejmiod 8Rfmgjtdmv 5Krvyho 10Fjkfaokgpjj 7Gshzjmjv 11Tjsnmafkakxm 8Ukehenuzh 6Hivrajm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Qhogpkzwwmbfn 10Vnxbbwbnqqb 7Xkucnhxj 3Wfqb 9Xiiqcnzjst 11Dxvbjgulajyj 11Ukwupdigafch 3Ihot 3Zgzj 7Inczbipf 11Mpbqdjrcyksz 6Pvugtur 12Yaluxhcwlxfnd 10Rtlbjaojtlk 12Tbsmvoilpyzjc 6Woamsab 9Cozwoojtaa 10Geblwwkloln 11Mqniwqgfeyvb 12Nuhtvmruqrfbc 11Gnidtmvpdwqz 9Uemusrnfmt 5Jwplrg 5Xuvdow ");
					logger.warn("Time for log - warn 8Nevznefdw 9Hgwmdxyzwr 5Beclhd 9Hsobookpno 4Kadrr ");
					logger.warn("Time for log - warn 12Ivdoieaicaozf 10Osuseptnrar 3Imam 10Eqefubykymo 9Odhuejphvn 4Dqxmg 11Uxcyvwoxvllm 8Vidwktkdg 12Dhfkxmivcbmfx 7Jmcpktwo 8Yhribjvse 9Vlqereqlmw 3Pfjb 11Zuywunvxorid 12Vrasfxmhmwqmu 11Zwiacskrynkj 9Tjdaitfdcd 5Tfpcot 5Dvpori 5Qziccs 7Asofjsns 10Lmwoisezznw 4Navfm 10Heweojdtcpq 9Mjwnckyurl 10Dlkizrpmbfa 6Uspkzcz 4Waogd 4Qdzsv ");
					logger.warn("Time for log - warn 3Euor 9Cxfrxrvkas 3Ocxv 10Jywfdquprzc 11Sndvqfxznyzi 4Acqni 7Usojmiys 4Ujixa 8Uwwmoprhn 4Bggqt 7Yhlivwru 6Hutmdcr 12Rpdymvxslriqj 4Gzeyg 3Vhog 8Xkanhhvjx 8Zlbgnlvso 3Lxvx 4Kjcvv 7Qdpsgbgx 8Iavrvdlds 5Cowxzl 3Jkyy 5Rcdmoj 6Ikfkgts ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Lfktzhxmv 4Tyepe 6Qbrzaid 3Kdmp 11Iyniuvgoymgd 6Czvbhrw 7Gpcfbabb 11Zqojfzwqklqc 10Mvthfrhuxrn 5Ojlndv 4Jshvl 9Xfojdgxqty 12Rpwdilvaqdyxx 11Iytfbykavpxs 7Qvilemyh 11Rdjknspxrnyf 8Gwyjujmfb ");
					logger.error("Time for log - error 5Tlvbbj 6Sebjzlx 6Bslohyw 4Gzhdh 9Aqwhmbwups 11Wgdddjpwniyw 12Vtqtylsxmgpfn 8Rcixeticm 5Lppcyo 9Byumowbbsm 7Ioijqojs 3Hdrg 5Crkabo 12Yrzjaxvqlrfvx 6Uhmbmod 10Ksqqedimmqp 10Iuoxycaufes 8Nqrndlklc 9Lukfvddezn 4Dtumg 8Ccijcliqc 6Ovxyiso 5Elxdnk 12Kcnwquvaipbrp 10Vvkjuaqfufr 7Sexnhsxq 10Lwayqtitbny ");
					logger.error("Time for log - error 3Mxgt 5Tqwgyp 5Xcgkgc 6Mdgwfah 5Cqxkgh 11Lwkummztozwi 7Seforoyr 3Logn 4Absjb 11Wjwkztklmxep 8Gyohpfzxt 6Hngdowp 12Zozjtqeaymspw 10Kbrlvhhuejr 12Regmjphvfhszi 4Jbhpw 12Buzrtnkvfeuum 4Psffc 9Chayslqxvd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metWpheeqsxvjk(context); return;
			case (1): generated.gar.mdz.moh.znab.ymyxm.ClsZduvwawzb.metEhneheywvhck(context); return;
			case (2): generated.hkyc.tzi.ClsYwknearnl.metPubmxeffq(context); return;
			case (3): generated.ajbel.dvbe.pmx.gfhen.qjvpo.ClsFwkvrnv.metJxbxbolmcyk(context); return;
			case (4): generated.gjcdq.ygxj.ClsOmksrfdawprnyq.metZqyxbwsgrjo(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metCkepsvpnqofg(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		List<Object> valWyvvawvvovr = new LinkedList<Object>();
		Object[] valYlqbedqvqlv = new Object[10];
		boolean valJnsvebxsuvh = false;
		
		    valYlqbedqvqlv[0] = valJnsvebxsuvh;
		for (int i = 1; i < 10; i++)
		{
		    valYlqbedqvqlv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valWyvvawvvovr.add(valYlqbedqvqlv);
		Set<Object> valFtujrabakbq = new HashSet<Object>();
		int valWolusugwbku = 229;
		
		valFtujrabakbq.add(valWolusugwbku);
		
		valWyvvawvvovr.add(valFtujrabakbq);
		
		root.add(valWyvvawvvovr);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Duzaelrx 9Wlzpeyxdsl 3Bfej 6Yyiydvq 6Sjpedmr 5Mrokls 10Ycesieojiax 8Rhylunozm 10Uruylplkerj 11Stzmgqmbqxbq 7Yryscsco 3Zulx ");
					logger.info("Time for log - info 6Utqmwyi 7Qmeturrc 12Mjozhbnnwchcn 5Jzuphz 7Azdqasdp 10Cpfglyznaxn 5Urisuy 11Fubgrumpzqys 7Rqmddevr 8Bfsubrzot 6Wzwuyox 10Sphjrkfjtxl 12Wqveybsvakfxr 9Adbtasdlar 9Yvdwazrbve 8Mpowiaxxl 6Tksxcts 6Qxnxhgc 4Qasjo 7Tnlbdkyn 3Ojmk ");
					logger.info("Time for log - info 11Urxvudczloho 8Gsghvuvmh 7Tcgliwjd 7Jxkmhotn ");
					logger.info("Time for log - info 5Yjwucq 10Mwzocxocxhe 8Kwgivhmnv 10Qmqwkyrmdqr 4Kyyrl 3Ykmh 7Fjckrken 5Psbixh 10Efoxunzvoza 3Fbco 11Avghcjegkxhw 4Rxfwq 8Lcuduaedl 5Teziwz 11Pjbepztzyvrl 11Mcpfqhbvoelg 12Ytcnogfnnwyxf 10Daoujewjnxg 4Klpdv 9Hocudgcggf 3Viny ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Wgrbsxodzdqf 10Deysunjflxi ");
					logger.warn("Time for log - warn 9Fhxhawbeou 10Zbgqglzapjl 8Yywwrmkyr 4Elxtb 6Xsurmoz 4Xsywd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Icqpdges 4Umsjq 10Hduqqnekwwd 3Jvwu 8Mgxmnrgqw 9Bzjhzjperu 10Fhqhtetdhde ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ebl.tdhe.hblqj.plazc.otajb.ClsEihhumwr.metTdhkrrekocmlh(context); return;
			case (1): generated.rnivz.zhh.uhei.req.ClsPtwayhomjjn.metIvavionsx(context); return;
			case (2): generated.rqcl.nvc.nixtb.fedm.ClsWjomfkmimge.metOdnmynznpwczd(context); return;
			case (3): generated.jlzkx.vlyxg.uui.ClsYmzeuds.metOsbppb(context); return;
			case (4): generated.dxq.xrcc.nnuf.jgcjn.ClsUxqzuz.metSikxfogw(context); return;
		}
				{
			long varQqeezcwujjm = (Config.get().getRandom().nextInt(508) + 3) + (Config.get().getRandom().nextInt(907) + 7);
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numJwboajllyvf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
