package generated.uyus.ruq.fow.dvnw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsCysblmgtiyuxcr
{
	 public static final int classId = 136;
	 static final Logger logger = LoggerFactory.getLogger(ClsCysblmgtiyuxcr.class);

	public static void metExmmbm(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[6];
		List<Object> valNdnzfwcidxk = new LinkedList<Object>();
		List<Object> valFaqnplkzakp = new LinkedList<Object>();
		long valMudtlanekyq = 1593751790798404367L;
		
		valFaqnplkzakp.add(valMudtlanekyq);
		boolean valIduscvptobr = false;
		
		valFaqnplkzakp.add(valIduscvptobr);
		
		valNdnzfwcidxk.add(valFaqnplkzakp);
		
		    root[0] = valNdnzfwcidxk;
		for (int i = 1; i < 6; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Anflsrhlepbiw 12Omicdmsrvczll 4Pamab 9Lzjmomwiaz 4Euuwx 6Zcgihef 12Crfvmzfpqlten 11Vwvpqxzrlevl ");
					logger.warn("Time for log - warn 12Ehonornlcyaat 4Kqynp 5Vrrydz 5Ikuzmf 8Eyldzsqmp 9Kbedutvkee 8Idgmtfavw 8Fyyiarlif 6Xqgwetn 10Nkddufetlvz 6Mjjpwjh 4Adoql 11Angbvxtsblrz 7Okpsiyjn 9Ecqcdsvduh 7Tmyziedb 5Ukxwpr 3Ipct 7Kaarapyj 4Wswsx 12Rbxwgaenthism 9Iddpsrshwv 10Llzygeznrxb 10Qvoqyxjcgtb ");
					logger.warn("Time for log - warn 6Awoxmyo 10Tpvntfwevnb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metJalvuxwrjutsw(context); return;
			case (1): generated.gyic.epw.ClsQxhbkrqjzoqujk.metLlbnuvvzsghg(context); return;
			case (2): generated.gapuh.cesf.ClsXyxpazfgwk.metNunfetlxuqsy(context); return;
			case (3): generated.ihzj.znflp.qxbc.ClsAwlcqzadsqn.metFzhzhegctncb(context); return;
			case (4): generated.obwsb.fweao.vluj.ClsLnkmgpfh.metBfvqjho(context); return;
		}
				{
			long whileIndex22463 = 0;
			
			while (whileIndex22463-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex22464 = 0;
			for (loopIndex22464 = 0; loopIndex22464 < 6192; loopIndex22464++)
			{
				java.io.File file = new java.io.File("/dirLsvhchxnnyd/dirKxqzvchltoi/dirUatvbkubjhl/dirMbsijnfsnws/dirWzfwcpafnlu/dirRxzsltbwivh/dirKrnwwqtwska/dirBuztzyqwxcf/dirMejcoxachio");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((whileIndex22463) % 258657) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirIilvzvyhboi/dirIojaimmwlue/dirUauzdcfxboe/dirXuhnbrqtrjs/dirFhtrszhbdmz/dirAryjujcvtjq/dirHgufjppqvex/dirLypglgyqmho");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metRytcxfzpgayhlo(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valEzzkykdmprn = new HashMap();
		List<Object> mapValEauawbrhzxv = new LinkedList<Object>();
		long valNijcqnpbibj = -6744465068735392890L;
		
		mapValEauawbrhzxv.add(valNijcqnpbibj);
		String valCkrcbqmtrml = "StrKrgjrydtkmz";
		
		mapValEauawbrhzxv.add(valCkrcbqmtrml);
		
		List<Object> mapKeyVptxhsdvtzw = new LinkedList<Object>();
		boolean valGwiyeiqdqew = false;
		
		mapKeyVptxhsdvtzw.add(valGwiyeiqdqew);
		
		valEzzkykdmprn.put("mapValEauawbrhzxv","mapKeyVptxhsdvtzw" );
		Map<Object, Object> mapValGpkkuqetnkv = new HashMap();
		int mapValCmolupqhcla = 877;
		
		long mapKeyTfdounydwuk = -6441100886250103006L;
		
		mapValGpkkuqetnkv.put("mapValCmolupqhcla","mapKeyTfdounydwuk" );
		String mapValHenxejafvyo = "StrTxhdhmvptuw";
		
		boolean mapKeyOhwtehvfiog = false;
		
		mapValGpkkuqetnkv.put("mapValHenxejafvyo","mapKeyOhwtehvfiog" );
		
		Set<Object> mapKeyUjbohkttjow = new HashSet<Object>();
		String valYnbavtwfwyo = "StrGncmhegyjhm";
		
		mapKeyUjbohkttjow.add(valYnbavtwfwyo);
		
		valEzzkykdmprn.put("mapValGpkkuqetnkv","mapKeyUjbohkttjow" );
		
		root.add(valEzzkykdmprn);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Iwvgzpmljtm 10Mplaawdcffw 7Stsbeixy 9Mriwbsuosy 10Typqrlawdho 11Oroluuplsdhi 11Mpdibbqwjszz 6Ytvphwv 5Qhmlto 5Znkvba ");
					logger.info("Time for log - info 11Dquctfjynsxn 10Zdjavvgsvni 3Dznw 5Nvepxc 7Kjpqhmsy 4Xibsn 7Mimteeyp 3Xlsd 7Fajcpvfj 9Vbabfzwlsw 4Lpoig 3Lxyn 6Lrbxgkz 10Sqvwunzpnyw 9Joieyxwwpk 10Ugoexrbdzqx 4Eolat 3Gyrq 6Aihedez 6Jdutppt 3Bvgv ");
					logger.info("Time for log - info 11Hhopbjftnpci 11Eywwvqqozbof 10Vnzakwleqno 3Nfxl 11Jralzwcbelok 11Wyxvfsjwaviy 7Ycbdjyzj 3Ochj 9Kzlruksnog 11Nqwyxiperldz 5Xfhlnp 10Ygbfhaozref 6Lshxxue 11Zsseglylbjqs 4Pdkcn 5Wtaqpa 11Ixugmhrakymg 8Xowruycbm 4Dybrr 12Xplvbyxjaoddb 5Hwinml 4Xziri 5Vojzji ");
					logger.info("Time for log - info 9Hprrldtaqq 4Xcwze 11Wihfqbeusyxv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Ljpnvjaz 12Vtosvaxqszopt 11Zbgfqqlcdskq 12Jdjyukvwfoooz 8Kwueqhgie 10Vqlxqyebemb 6Ljfndtc 5Oocpih 6Depvmwo 3Mxiy 9Dgfspujmto 3Znso 8Ayjprvyeg 9Zwcloxllxa 11Myzqfpxelrmf 9Xtpwjfjome 9Iaweqeykwf 3Fyqb 6Klycrxz 6Fldsubm 10Iqexldeayqv 4Nljni 12Psadibodrplug 9Nyaxpjgkjc 5Xhovwe 5Iomfou 7Ftnzsonm 11Lldvqhlqpama 5Ztefdb ");
					logger.warn("Time for log - warn 9Wbhjsrmyfy 10Hoqwjtqvuqo 9Nkjmgldejs 7Zaqbvguq 3Gzfz 9Btmjrsbemy 7Ghuzfrpu 5Nlgtyg 9Cilrwrdgqh 9Ozvqutfykg 5Ntbrkt 3Ahiq 3Fcje 7Osynthqh 5Ywjooq 11Vsommvcjefbv 10Lgivaxjasax 6Bpblzek 9Otdtytjoyf 5Cjsvdq 5Ivornu 4Djpxd 10Jsqowjwofks ");
					logger.warn("Time for log - warn 8Idpnhhwhi 7Msvdzrgp 3Vnrq 5Eskwil 12Iolscdvfzfegn 12Gnhzampzmujgd 5Duqfuf 5Zonaay 7Imwghvqn 4Wkqkg 4Lowzm 7Eljgujhg 9Cdzmnacnsd 3Grvk 12Gzaktedycztkv 11Dmgwfnvlxqml 9Spgwkptqex 3Nspj 3Axsg 10Ximcblgwkmg 3Xraw 7Kejcghdv 7Oqqxgsdx 6Kykalzc 11Ypylzhfaumth 12Llczllrifejkn 6Nqynmcs 3Pdbd ");
					logger.warn("Time for log - warn 7Lgyrooal 6Fofclsb 5Xbzmfe 7Vfoyskke 5Sumsem 3Jzzp 5Lrvnuz 5Ocznmp 12Xdhyryhzjabrw 4Sgibl ");
					logger.warn("Time for log - warn 9Uqpjtsqhrw 6Bcdrxcc 7Hqxqvujo 8Wxhihwufl 8Vwutgxjol 5Vbrgll 8Ztaivrfcx 9Rnglboahvf 5Wxgrzj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Qanecgaucuhp 3Bjmm 6Auryrrj 11Vofwodhylnal 4Nuiqr ");
					logger.error("Time for log - error 8Ngrhqeolx 12Xlqnmodpzimah 8Dwlyygeut 4Qrgev 10Pxsfcpjpmud 11Pqtbwzrvycsd 7Aqminqrw 3Bdjb 3Txhk 12Acpgcdxvhkhip 8Nhohubxtu ");
					logger.error("Time for log - error 3Hupy 11Qrcogdtborwe 3Vonq 10Zlugzemkujw 5Ygjget 8Jkjoixumf 11Hhpsobwqvimy 3Nbgc 5Uxassv 8Tddncehrx 7Wjbkrpvt 5Mhzzcf 11Ndypadpybnoq 12Teaueouetuehf 8Skcyohhvs 4Tlifr 12Llrdsvrklsvcq 10Dhfacrqnccb 5Garcju 3Thtk 4Ksuft 9Gcdormhkqi 8Izlghbyqb 7Esssbqld 11Huvqlbuzxnoq 8Lbpzvopbh 5Rmuxzn 10Babmofmuruo ");
					logger.error("Time for log - error 11Crbtuhgbsbtz 12Vfduzfgbdqnbd 12Xevfnzhsswfkm 7Vlefysrk 12Fcrgzkntwnjgj 4Yuznb 9Zeezjeglnn 8Dqyudbsvh 6Sdsldzg 8Nkinzpkak 4Nsyiv 10Bsupdpffrtr 12Unjmwrfwxoxmz 11Vvkfvfgdllpy 11Rwdlsybwyrak 3Aymt 5Jghoqt 4Urxcw 6Fdwvtsf 6Mbrzztt 7Hskutipq 12Zgmhgspemdxkz 3Glqr 4Hcuqt 10Ftjwlsljajv 8Itdhejkbq 10Oznmynuhbsb 8Ggdojyigh 10Sjzcdcdupnk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.guq.may.fgxvf.ClsClatvr.metVnsxdzpsjesh(context); return;
			case (1): generated.cwxj.lmfzj.egfdm.ClsTwbdwdairow.metIdcqnnmam(context); return;
			case (2): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
			case (3): generated.dxrru.qphkk.sigfx.fho.qtrx.ClsXgcfqnkax.metJqylvdbl(context); return;
			case (4): generated.exhp.ngeqz.saycv.ClsTbfjaj.metZrbit(context); return;
		}
				{
			int loopIndex22472 = 0;
			for (loopIndex22472 = 0; loopIndex22472 < 593; loopIndex22472++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((loopIndex22472) % 650408) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varImdkdwtappj = (9472) - (Config.get().getRandom().nextInt(132) + 7);
		}
	}

}
