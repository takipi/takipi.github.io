package generated.fkhk.aid.ztzxu;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQjlasdqvzflfd
{
	 public static final int classId = 85;
	 static final Logger logger = LoggerFactory.getLogger(ClsQjlasdqvzflfd.class);

	public static void metXgpgomawgjao(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValEzlbetiwret = new Object[11];
		Object[] valUhrlkkgltnk = new Object[8];
		int valYsokpmpoyiz = 37;
		
		    valUhrlkkgltnk[0] = valYsokpmpoyiz;
		for (int i = 1; i < 8; i++)
		{
		    valUhrlkkgltnk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValEzlbetiwret[0] = valUhrlkkgltnk;
		for (int i = 1; i < 11; i++)
		{
		    mapValEzlbetiwret[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyEzykcjjpigh = new LinkedList<Object>();
		Map<Object, Object> valXmghrnqhbrm = new HashMap();
		String mapValMfukgumfeaa = "StrUopxocjfkgx";
		
		String mapKeyPpfkrrgetie = "StrShigloiyomh";
		
		valXmghrnqhbrm.put("mapValMfukgumfeaa","mapKeyPpfkrrgetie" );
		int mapValWfgzpjmqghv = 667;
		
		boolean mapKeyYlxmljnyyec = true;
		
		valXmghrnqhbrm.put("mapValWfgzpjmqghv","mapKeyYlxmljnyyec" );
		
		mapKeyEzykcjjpigh.add(valXmghrnqhbrm);
		Set<Object> valRrimgzdogdy = new HashSet<Object>();
		boolean valMcllumjzdsp = true;
		
		valRrimgzdogdy.add(valMcllumjzdsp);
		
		mapKeyEzykcjjpigh.add(valRrimgzdogdy);
		
		root.put("mapValEzlbetiwret","mapKeyEzykcjjpigh" );
		List<Object> mapValLdzgdvkkvli = new LinkedList<Object>();
		List<Object> valGomnctlkref = new LinkedList<Object>();
		int valRvmjacabvfl = 389;
		
		valGomnctlkref.add(valRvmjacabvfl);
		
		mapValLdzgdvkkvli.add(valGomnctlkref);
		
		List<Object> mapKeyVeptfdiofas = new LinkedList<Object>();
		List<Object> valEgtjnbulzwi = new LinkedList<Object>();
		boolean valBodezwzocqt = false;
		
		valEgtjnbulzwi.add(valBodezwzocqt);
		
		mapKeyVeptfdiofas.add(valEgtjnbulzwi);
		
		root.put("mapValLdzgdvkkvli","mapKeyVeptfdiofas" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Gqjeawxf 3Dgfa 6Umhphvt 3Aejv 4Caads 12Dlunejwvtlpnu 4Xohhe 3Uxyq 6Grsknub 6Ivmfvke 6Xpcakvj 4Evmuv 11Ysbbznylnzgd 5Csppcv 9Srxyxdfmzb 9Ohxwzztjhp 5Rpsjfp 9Lttuavibfs 12Fwboltiquftqr 9Zpeyhiklms 3Sohy 3Piln 3Tbpo 8Grjtmjfyw 7Plcebodv 10Thcbwmmatsk 7Pmtoepfh ");
					logger.info("Time for log - info 11Ckkgginmmiih 9Flmxyyogqz ");
					logger.info("Time for log - info 3Sqlt 7Btbwhhfc 3Mjbe 12Uvmkofzanbaba 4Teguq 4Esoio 7Tsawtpsg 6Wjquvtg 6Fufqidf 12Ayxmhhbejhoki 7Ccgkqpmz 8Drcsfcnix 12Fawupjuarmejr 12Jkdvzsmtoejrd 3Yrho ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Dlrqirzjegnky 12Okmlyifgcsxkz 11Msuqmiomkeni 6Cljthws 3Xcio 8Zwllwrqem 4Zsqfn 9Fijkrgszyw 12Pigapwkqsvmte 3Jgnq 5Lvjxjh 9Rjremiiifd 9Dmplmvnkfn 9Rnyqyndxrf 7Fuelapqa 10Xzobhmbhyjd 11Azsctajrqsuu 4Ibcse 3Vtay 8Xiujsocda 9Rimscisaus 11Odulappggpsr ");
					logger.warn("Time for log - warn 4Rboec 12Akoryiwwvbxzh 10Jgtlkzjutbh 6Eckzbjj 9Apsapmjrii 5Qbgttd 8Tgwezsfww ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Yoxjtsrbpsbij 12Ykhsxluntckqt 6Dmywouu 10Rjobjygfhkm 11Saoqwpfxionl 3Fghr 8Llhycotiv 4Gdqhc 6Fiqsrzf 12Lsrhfmxlqpsov 9Pikqzakefh 9Kwimsmbwov 12Ucmakppshspvq 3Yims 4Whhje 9Xwtjnejmye 6Qzjfozz 9Nphfceonmx 6Vxajibv 12Jqnklahzdjawr 12Drtfeajownrvu 9Arsxaxwasy 3Guoa ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ewz.kir.rqdl.wup.ClsTcnbjngxap.metXatmnfjmhsznde(context); return;
			case (1): generated.eddt.homo.syk.wqll.dyeuq.ClsYzlmjqrjjp.metCwoimorcxixd(context); return;
			case (2): generated.pxy.vesv.fuz.ClsEaskwlgtcshts.metCnqxpzkxiqea(context); return;
			case (3): generated.hdrlt.jxdm.bjqs.pupxs.ClsZoyaigxdyb.metCofpcgjfkt(context); return;
			case (4): generated.obnl.keokn.bqrr.mlh.qwmk.ClsAxxbgst.metSbbednuxhis(context); return;
		}
				{
			long whileIndex21505 = 0;
			
			while (whileIndex21505-- > 0)
			{
				java.io.File file = new java.io.File("/dirMmmmaitkxnm/dirEzjzylaueqv/dirDwldvmjykti");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numEdrwodcwlet");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metXxrecknofqwu(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valZlhdktitdjc = new HashSet<Object>();
		Object[] valJcjtpwyhoee = new Object[9];
		long valTwtzfgniqlw = -3133722792402539325L;
		
		    valJcjtpwyhoee[0] = valTwtzfgniqlw;
		for (int i = 1; i < 9; i++)
		{
		    valJcjtpwyhoee[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZlhdktitdjc.add(valJcjtpwyhoee);
		
		root.add(valZlhdktitdjc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Dyph 10Pdwddotygmr 11Bvizhhzxnghw 8Adjhavuzw 3Gnim 7Azkhraaw 4Jhqnr 12Cacofdnhbsykh 10Qrmtgyibpnp 7Xctdzerm 8Kunbsccjg 3Vdnk 8Zmvrnnqpd 7Smkjdvex 6Porvzio 9Wudhunwxoe ");
					logger.info("Time for log - info 6Cwbpyvn 12Bxojpvdkllxxa 3Fmex 12Bjdbrfgqcboxl 11Uymlpdagtclv 4Uzode 3Oyms 4Fuxzb 10Lpehceqjnoz 5Gjrefe 7Dsruwsoh 4Pdpfj 3Boub 12Gjbetmkbhdzgp 6Gqjqqdq 4Lvtwe 10Rjfvppvusup 7Wdgbvxgm 8Uhdkgfkvb 12Yqffbozagbjom 3Oodx 9Oxicxfpuoz 7Klekzflm 6Bhkfvih 5Ogoeri 8Hbfstbpgz 6Lnzfgha ");
					logger.info("Time for log - info 5Zhkilt 9Jfpumlujvk 4Pxqfh 3Izwi 6Rmenlni 9Xzqlxgfhkh 3Gyuk 7Qudtiszi 8Kqrgnfbay 7Mqrmbzbh 4Hrqsm 3Gomo 7Xsvdjgdo 6Xheckmn 12Vvilhbbgzrjhx ");
					logger.info("Time for log - info 8Feyhivjul 6Tsjnjgi 10Clipiydajny 3Zyye 5Htdxqu 11Gooxwthbfghq 12Zydwdyyhzflkg 10Sfizhalligu 9Pqofuifhxj 4Uwmvm 5Xzjzqv 8Kyaivbfla 7Ciswatvh 7Zrsfzkbd 7Zglreezt 3Hppg 11Ddyreuflglet 9Lfzylbyyro 8Osgoiwghz 4Pareu 8Fowllfmag 11Qehlsmabvczd 8Bkuhknppi 8Xyjlxbfhh 6Mqljegt 7Ucsnjtbh 7Apmphpnj 8Yabsdgyma 3Gwxz 5Bzpgjv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Jtojixwfaucez 7Sidirzhq 6Emnkdzl 10Bofvgtcsxbd ");
					logger.warn("Time for log - warn 6Jvxglgc 12Vhfudlnwbfsfu 6Cudwmql 6Drnaess 10Outxbgqvudr 5Oprcqa 3Vihz 10Blqyxscuihe ");
					logger.warn("Time for log - warn 8Fabznnthe 8Ljaqfwyuk 3Mgqq 3Avfw 5Ltpiqn 12Wqfsotitrgjam 7Ixjuliut 10Dirqzwsjztd 4Yauya 3Jkcq 10Dimrcdaxylw 8Jqpepkpap 5Idbbzi 12Cdrejxxpmvgxq 11Bldvasqnvgxo 5Idesrc 11Gcwvrhswhcjs 3Uddz 8Bbcgttfjx 11Tainiifezfez 10Gqtoxcgyfrx 9Vqzcxllyza 3Pmaa 4Veeij 6Pclmwjm ");
					logger.warn("Time for log - warn 7Asyjthix 5Fdhkzk 6Klmgggz 9Enrdrncapt 11Iwebvthgwwjx 11Syqmdzkqfyef 5Whcrmt 10Zpahxbviyol 3Vawz 10Hmgefyhupua 5Zdauou 7Yutivqmj 8Yxqmixoif 8Yjgecuplq 4Uxsza 11Pinbkybiwrwt 5Plrrkv 4Jtlut ");
					logger.warn("Time for log - warn 7Ljcrhkbi 12Uohlarjyiktzo 4Lvlkp 8Ykgoezzfi 6Tyrvkce 11Yzvdihuwzgid 11Lmpgdayilvpd 9Jfkemjqykr 4Fbtlv 11Kzkulrgvonsr 8Xdwfwbxzf 4Lmoze 12Iuhaackjwyvww 4Ffzrk 4Gzont 3Kvro 11Hksuoacdvzmg 4Rzgnt 12Jmuzuhbkndpbq 7Phnxsjbr 11Xodkbnmcfqpj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Ukuh 4Vegbv 7Lmqotapv 12Hceurbnyvkaaq 8Fmlbsfcsv 3Lfye 9Xcslettjrd 10Zzilbuiapos 4Qgxrh 5Zxellw 11Jrwckglftpqc 7Lhjdwvku 7Enlnopyr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aby.eyq.viq.flsc.ijccw.ClsKeovzqbtjs.metTizqtcinnozd(context); return;
			case (1): generated.bvvh.vrkq.ClsCiivqtifsuv.metBcfndjmmnf(context); return;
			case (2): generated.wzzy.rguqw.bfm.ClsCumedne.metJsfyyjsbivcd(context); return;
			case (3): generated.lmq.wwll.mcjoz.ClsBqjxdpu.metYpiqwjcggcaa(context); return;
			case (4): generated.kqywo.pil.grw.dvt.ClsJduhsebfba.metRxalgp(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex21515)
			{
			}
			
			int loopIndex21513 = 0;
			for (loopIndex21513 = 0; loopIndex21513 < 5100; loopIndex21513++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metCcnwvtmpiltc(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		List<Object> valDduezbnmwpv = new LinkedList<Object>();
		List<Object> valUhycjhkdxtg = new LinkedList<Object>();
		int valLxsvxqfjtpr = 601;
		
		valUhycjhkdxtg.add(valLxsvxqfjtpr);
		
		valDduezbnmwpv.add(valUhycjhkdxtg);
		Map<Object, Object> valDlefabmstrt = new HashMap();
		boolean mapValXynqojcuzfx = true;
		
		boolean mapKeyVfnublyavdx = true;
		
		valDlefabmstrt.put("mapValXynqojcuzfx","mapKeyVfnublyavdx" );
		
		valDduezbnmwpv.add(valDlefabmstrt);
		
		root.add(valDduezbnmwpv);
		Set<Object> valQphivnkuafu = new HashSet<Object>();
		List<Object> valGdhbjkwqkxn = new LinkedList<Object>();
		long valLwhhblielav = -2912236961725029769L;
		
		valGdhbjkwqkxn.add(valLwhhblielav);
		int valJamvhebxhzv = 96;
		
		valGdhbjkwqkxn.add(valJamvhebxhzv);
		
		valQphivnkuafu.add(valGdhbjkwqkxn);
		
		root.add(valQphivnkuafu);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Opnvwnatjmez 6Spjvoco 10Szwuttviotf 7Jdwazzkk 9Xoermzgamq 5Lmhpjq 5Tkdbov 10Qjofcygymuv 8Uecqmrzme 12Inqgxohpvrjcl ");
					logger.info("Time for log - info 6Zmguiqf 6Apwnlke 11Rtoojxkekkcb 12Ylfzksarhuumt 11Xaebtqyyyyhf 4Iusna 12Urcqjvzqsziwf 12Mlshimpqtdnfb 4Rsgyi 12Tgmwdnpbqgtqv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Dylomra 7Xoqtisfc 3Rcbc 3Xeid 11Qhgixpnuaesn 8Nbioclruf 3Sxhj 4Rqsdw 9Mdbfyoocnv 7Kokaqpej 10Pasenbpcuwb 9Tvpzdwkzyb 12Tblyrrqzsaxem 8Qatcsqltd 7Cabxdefw 7Uffmdorb 4Kksal 10Rztcfxbnabk 4Etenx 12Kxxezysaelcdy 7Itslaaxa 6Glnlyyp 9Ocslkpixqk 8Rvelimavp 6Pdcghys 4Vyapu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cxtx.gvv.woynp.wvzz.den.ClsHntsemdxcztjdw.metSzmkjzex(context); return;
			case (1): generated.ukp.wkgj.kys.bbj.whcvs.ClsShqgniemg.metRrbombfiz(context); return;
			case (2): generated.bcbrr.mrpx.ClsJcswauwrr.metIydcpeyrd(context); return;
			case (3): generated.prq.bplky.nxkb.ClsOpjmpjfimau.metKcvsmcfaqhw(context); return;
			case (4): generated.wvkuf.rvtq.kcgfs.vezg.ClsKfeffw.metYhvpbcd(context); return;
		}
				{
		}
	}


	public static void metSrhconsb(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valOrnrplguifp = new HashMap();
		List<Object> mapValMxizcftjquu = new LinkedList<Object>();
		int valJjhzobsgkok = 598;
		
		mapValMxizcftjquu.add(valJjhzobsgkok);
		
		List<Object> mapKeyCkfczaawvzd = new LinkedList<Object>();
		String valMzlrfkdyjsf = "StrUtrhboxghbs";
		
		mapKeyCkfczaawvzd.add(valMzlrfkdyjsf);
		
		valOrnrplguifp.put("mapValMxizcftjquu","mapKeyCkfczaawvzd" );
		Set<Object> mapValWlduqfktspa = new HashSet<Object>();
		int valTeyzusiroqz = 438;
		
		mapValWlduqfktspa.add(valTeyzusiroqz);
		
		Map<Object, Object> mapKeyMgjdftmpgod = new HashMap();
		int mapValKuzuxerckwv = 148;
		
		boolean mapKeyIfhmjugtahn = true;
		
		mapKeyMgjdftmpgod.put("mapValKuzuxerckwv","mapKeyIfhmjugtahn" );
		boolean mapValFtvxlowvamo = false;
		
		String mapKeyXyalqdwtnhh = "StrSqyviuosycf";
		
		mapKeyMgjdftmpgod.put("mapValFtvxlowvamo","mapKeyXyalqdwtnhh" );
		
		valOrnrplguifp.put("mapValWlduqfktspa","mapKeyMgjdftmpgod" );
		
		root.add(valOrnrplguifp);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Uzbnowpwoz 5Hozywp 10Mufivshxkbp 4Yweqw 6Cjeikuc 9Ewredpidne 12Jeltyfosmrros 7Cznkwtaf 5Aqbvyx 6Uzsikkl 12Qizsbqdamsoao 11Tsdnmyjzrwib 12Yxqoutoubdgzq 5Wgxxed 4Gqnrx 10Dqoasngjfyr 7Rrhrtzrd 7Fcmsgrny 7Fczlpqzu 9Xsvmafbrmn 3Xtvf 6Qznpwjf 3Hmdl 7Busdcwqs 10Rfokdqadrho 7Hijvzxuc 6Yyffqrb 8Ukoneweyo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Dzzemgl 4Wlqum 6Nzcvznd 6Cqplajn 9Xreadmpsqo 10Xmqgtsalbdn 9Slpcrrobro 3Dcys 4Bapeg 10Wwgjfwdpyxe 9Uzqbdkpsrq 8Ukeljprwi 7Tctnenpy 8Ciwgubgmh 10Gqyjgzhwcjg 4Vbovl 6Bxfehym 9Kmslbdyage 11Cvcpxwajzlxp 11Vygfwiafuchb 7Dipczrus 7Fggmexxj 3Utrl 3Hght 5Fwdbua 12Ttaxrquhuyrld 6Nsraryb 6Unjcfzw 6Nhjytjz 9Jrqxypkncz ");
					logger.warn("Time for log - warn 5Xkqhdk 11Iyjeubneglzp 6Llkdovp 9Yctevipzyp 3Oenh 12Glsbjngacdbbi 12Moawipanxjljx 6Codzyph 9Qupphuoeab 9Kfvqlwjaqf 9Cngzvfegda 11Twhsmpynxyhd 7Vflxsaic 6Mgheehi 5Jppiko ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Grippzcjt 12Zmaeegaypiutx 4Lcjbt 9Acidybcmqy 9Pwugzmidfo ");
					logger.error("Time for log - error 5Nztkde 8Lzqtjehve 8Kzixfpcng 7Kxcholfm 6Ctbzcfv 12Weknhxqiqygpt 5Cennuv 3Qryd 4Xlmzv 8Muxdozazt 7Zeoaprrq ");
					logger.error("Time for log - error 11Szrhkbszknhp 3Oand 8Prrqmyonx 3Igtp 8Hsnnpkywz 12Yvyegzxdbtoll 11Lfkcdenftceq 3Ldjd 6Mmloaig 4Klzrs 3Rokp 11Ckxusmyudqgx 5Mgtcts 11Csutbjknarxf 8Zpxqlwprf 7Qnygngxg 11Ncbgmwqzctri 3Hgdd 9Hlugpilgfg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ayxg.baac.ClsIciuzantocwhkq.metBmijwhb(context); return;
			case (1): generated.avme.rnc.ClsUgqeozcqx.metIsegbgah(context); return;
			case (2): generated.lfb.pwad.aey.ClsGmnfes.metLhrypvccb(context); return;
			case (3): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metNjrouzbt(context); return;
			case (4): generated.kibd.nddr.nknr.pccz.hryio.ClsBgthm.metFrmpvshfvh(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numMgbxlzbbjqd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numGkucnqemrdv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex21527)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((Config.get().getRandom().nextInt(798) + 6) - (6339) % 625940) == 0)
			{
				java.io.File file = new java.io.File("/dirEtwwlgoqtqq/dirAtxzxvuvwmr/dirPambpfgvuhk/dirWteworfmilc/dirWyghchgcimh/dirHcvqztplowj/dirYwwohwkstrx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(14) + 6) * (6442) % 316503) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirRfemsgjpgpm/dirQrnzhaionit/dirHswibxwrakq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metYjmossro(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valDyhbzlcaagj = new HashMap();
		List<Object> mapValXjcdxxrqjuj = new LinkedList<Object>();
		long valUrzkdkfdpgb = 1834459493829821457L;
		
		mapValXjcdxxrqjuj.add(valUrzkdkfdpgb);
		long valSqclylsqdna = 6580377285253427962L;
		
		mapValXjcdxxrqjuj.add(valSqclylsqdna);
		
		Map<Object, Object> mapKeyMxkgzjuhoyq = new HashMap();
		String mapValRhkuvvkkhjq = "StrWfnigcjgnwt";
		
		long mapKeyAygbhwewygd = -766907405087664265L;
		
		mapKeyMxkgzjuhoyq.put("mapValRhkuvvkkhjq","mapKeyAygbhwewygd" );
		
		valDyhbzlcaagj.put("mapValXjcdxxrqjuj","mapKeyMxkgzjuhoyq" );
		
		root.add(valDyhbzlcaagj);
		List<Object> valZqeoonvntiy = new LinkedList<Object>();
		Object[] valElcvqatmluo = new Object[10];
		String valPckszjzxpmg = "StrXulldsqoach";
		
		    valElcvqatmluo[0] = valPckszjzxpmg;
		for (int i = 1; i < 10; i++)
		{
		    valElcvqatmluo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZqeoonvntiy.add(valElcvqatmluo);
		List<Object> valWdybcmfwyhv = new LinkedList<Object>();
		long valCqcrurnnvai = -7235554025774086433L;
		
		valWdybcmfwyhv.add(valCqcrurnnvai);
		boolean valWosqatitdcc = true;
		
		valWdybcmfwyhv.add(valWosqatitdcc);
		
		valZqeoonvntiy.add(valWdybcmfwyhv);
		
		root.add(valZqeoonvntiy);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Qgzzer 3Egrr 12Fjxuygrpuohau 12Vypaqfhuivows 10Dsezqxbuuky 9Ntptdvvgqe 4Pemba 5Oakzyw 5Hrdypy 4Nnfjp 12Ybaioinzyhogh 3Pmtr 7Fdaqmala 4Omlwq 8Mrvpyanuk 10Bxzyemrbqkr 3Ogai 11Ksukhpyzuwpw ");
					logger.info("Time for log - info 7Ucflhcgq 10Ojwgqwylydh 4Wtcdw 7Wffduali 8Mjggxvmar 7Kikhsrfc 10Mermhaaemrv 4Yodpc 7Ceflkxfe 6Qimrlng 10Rfzjpkkhvgu 11Yzmhxtemqsyj 3Qlte 10Zuryxlmhvtz ");
					logger.info("Time for log - info 11Rafaotomzwoa 10Mgmktkrneft 8Pdwnusuqe 3Wtql 10Ysyktdfjgao 8Vitduenzd 9Vlndcxyytn 4Wpaeo 4Vpnhl 12Cftravquhvwbq 3Tkgv 7Avtnpdoo 10Patmtjigpgu 11Idnuurygpzlt 5Fowzng 3Kgct 12Qqluritpvlxwh 10Vbtmaoedlst 10Kfrbdnjzefw 6Cnrbsbo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Nckwgiesjp 10Lgvumpbtzpd 9Iddvcpndiw 7Kwdljwxr 6Xgvmcae 12Nvlhwrvhybspb 5Epgfvd 10Yiwsuxabuow 3Shaq 7Ewbilcza 4Upygu 3Hwws ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Zvynceqrivnuf 11Zikmypmozsux 3Ophv 8Moojwpudv 11Jzoxoywzmzqk 9Rjukribavm 12Uexjgkppyskbu 10Kxxknrblykg 4Nsboi 6Crjxome 9Zbgvxyggda ");
					logger.error("Time for log - error 8Jkvyorpey 10Aierkvotkog 8Amywwbimd 6Toyevzs 3Jtyl 7Grufrbvp 12Hoiznkwphjtfp 12Nrgrugxfqexhz 6Scdgszb 9Jcuvvosbaj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gfpc.pbcpl.isevo.syh.yqsp.ClsDuasxzsefdmugn.metLfljogrsdcdny(context); return;
			case (1): generated.egtuf.tby.poy.tetgn.cnw.ClsOidjvegh.metTjmqwo(context); return;
			case (2): generated.ocg.pnhd.assci.ClsEkxxqpavkqxkay.metTiqnjmdqil(context); return;
			case (3): generated.uxbqo.pcskv.udre.ClsKillneqmm.metIokufnwdnpfcxt(context); return;
			case (4): generated.gpnn.qul.pdexl.hxjph.zmndq.ClsIcvyndtrplxfkf.metWyrdoedscqrw(context); return;
		}
				{
			long varZkkgljwlyfc = (Config.get().getRandom().nextInt(361) + 4);
			try
			{
				try
				{
					Integer.parseInt("numLnoirogryby");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex21540)
			{
			}
			
			long whileIndex21538 = 0;
			
			while (whileIndex21538-- > 0)
			{
				try
				{
					Integer.parseInt("numFknygubxlng");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
