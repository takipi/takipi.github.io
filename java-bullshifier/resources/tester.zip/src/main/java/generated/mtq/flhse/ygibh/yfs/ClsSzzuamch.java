package generated.mtq.flhse.ygibh.yfs;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsSzzuamch
{
	 public static final int classId = 254;
	 static final Logger logger = LoggerFactory.getLogger(ClsSzzuamch.class);

	public static void metIuxgxgafdnqnhh(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValKxtisnidluc = new HashMap();
		Set<Object> mapValVwumqebrsnc = new HashSet<Object>();
		String valJcwcmxxabsz = "StrZukirspisff";
		
		mapValVwumqebrsnc.add(valJcwcmxxabsz);
		boolean valQuchbwjrwgi = false;
		
		mapValVwumqebrsnc.add(valQuchbwjrwgi);
		
		List<Object> mapKeyRxxtrqrvelm = new LinkedList<Object>();
		int valAsnhflyxgcd = 344;
		
		mapKeyRxxtrqrvelm.add(valAsnhflyxgcd);
		String valLkuukykeubg = "StrHcjfsmuqzkl";
		
		mapKeyRxxtrqrvelm.add(valLkuukykeubg);
		
		mapValKxtisnidluc.put("mapValVwumqebrsnc","mapKeyRxxtrqrvelm" );
		Set<Object> mapValGgjcqkehdjw = new HashSet<Object>();
		String valOtqkzaiwqzw = "StrFwxdhzxggar";
		
		mapValGgjcqkehdjw.add(valOtqkzaiwqzw);
		
		List<Object> mapKeyPfidxkvzkso = new LinkedList<Object>();
		int valArjnxbrmseg = 907;
		
		mapKeyPfidxkvzkso.add(valArjnxbrmseg);
		
		mapValKxtisnidluc.put("mapValGgjcqkehdjw","mapKeyPfidxkvzkso" );
		
		List<Object> mapKeyLrbkmsohxgg = new LinkedList<Object>();
		Set<Object> valTsfpjggmfxp = new HashSet<Object>();
		int valNjkxwslchhu = 776;
		
		valTsfpjggmfxp.add(valNjkxwslchhu);
		
		mapKeyLrbkmsohxgg.add(valTsfpjggmfxp);
		
		root.put("mapValKxtisnidluc","mapKeyLrbkmsohxgg" );
		Object[] mapValWnffzwqqqgi = new Object[2];
		Map<Object, Object> valJtmbnmrluse = new HashMap();
		long mapValKpbhenmkhxg = -2799532739282381419L;
		
		boolean mapKeyJvqkiaatirl = true;
		
		valJtmbnmrluse.put("mapValKpbhenmkhxg","mapKeyJvqkiaatirl" );
		int mapValOzwztteduvp = 902;
		
		boolean mapKeyNzqtjqgcwmu = true;
		
		valJtmbnmrluse.put("mapValOzwztteduvp","mapKeyNzqtjqgcwmu" );
		
		    mapValWnffzwqqqgi[0] = valJtmbnmrluse;
		for (int i = 1; i < 2; i++)
		{
		    mapValWnffzwqqqgi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyCfixtpfqsrq = new LinkedList<Object>();
		Map<Object, Object> valGbesgvsefif = new HashMap();
		long mapValMmrvjhfrmdk = 6267676832936126292L;
		
		long mapKeyDdceupsefmz = 7722569205083170156L;
		
		valGbesgvsefif.put("mapValMmrvjhfrmdk","mapKeyDdceupsefmz" );
		long mapValPiuljlstqsk = -7605892806191527659L;
		
		String mapKeyUlmhsmcvzdi = "StrGthqkleziwb";
		
		valGbesgvsefif.put("mapValPiuljlstqsk","mapKeyUlmhsmcvzdi" );
		
		mapKeyCfixtpfqsrq.add(valGbesgvsefif);
		
		root.put("mapValWnffzwqqqgi","mapKeyCfixtpfqsrq" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Vsdkalurvoqt 4Zmjtl 3Arjb 6Zlojyel 9Tgjskcrpnb 4Xipay 7Nftgfjxy 9Bzsihsdnmw 7Qpchdtlx 11Vasqnisosnxv 11Bgzvofzcxooj 6Apuvcws 11Jmeehppefvov ");
					logger.info("Time for log - info 11Aiafkmorwmxc 9Bzbttncqfx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zkx.deuj.ClsQemyphqswqdyqm.metPsjlvoansmv(context); return;
			case (1): generated.yfyks.sksk.asgi.ClsXzaehxcicrdskw.metEpcsazywkgm(context); return;
			case (2): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metSqibhmdisq(context); return;
			case (3): generated.afba.qbfns.sure.ykux.syv.ClsCqlibdmm.metOvhcjl(context); return;
			case (4): generated.cmup.ytrbd.ddu.ClsZmyzij.metDiwjsq(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(63) + 6) + (5166) % 488688) == 0)
			{
				java.io.File file = new java.io.File("/dirQpsmgxygika/dirUdgffzewzse/dirSuhhxjqxynp/dirYptgmlotktt/dirMkkqazztyvb/dirIxloufsquox");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
