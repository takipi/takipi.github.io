package generated.godw.hlszo.mtqbt.shx.tbgwd;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsMygvrmsqnwlsdw
{
	 public static final int classId = 392;
	 static final Logger logger = LoggerFactory.getLogger(ClsMygvrmsqnwlsdw.class);

	public static void metHodxre(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valWfzsqdsavoc = new HashMap();
		List<Object> mapValAkhpowosbzp = new LinkedList<Object>();
		int valTanmsljoilb = 871;
		
		mapValAkhpowosbzp.add(valTanmsljoilb);
		
		Set<Object> mapKeyWervuilpsry = new HashSet<Object>();
		boolean valExfbhefnijw = true;
		
		mapKeyWervuilpsry.add(valExfbhefnijw);
		
		valWfzsqdsavoc.put("mapValAkhpowosbzp","mapKeyWervuilpsry" );
		List<Object> mapValHoqalixvuoy = new LinkedList<Object>();
		String valXgjpzgecnrv = "StrYowqfcvivrd";
		
		mapValHoqalixvuoy.add(valXgjpzgecnrv);
		
		Set<Object> mapKeyRrrqfhibolb = new HashSet<Object>();
		long valLtiwgvadnmg = 5943034793864636535L;
		
		mapKeyRrrqfhibolb.add(valLtiwgvadnmg);
		
		valWfzsqdsavoc.put("mapValHoqalixvuoy","mapKeyRrrqfhibolb" );
		
		root.add(valWfzsqdsavoc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Utmjoxhbkuwt 8Ptpkmbmng 11Lxzpkeaupnhe 5Qxsbnh 4Csfhk 10Hggoqnligyq 11Taidpmfaivva 11Mzjviqcbvyxt 7Mooxqmof 12Zsdcvuwempuzp 9Crykkfmtgu 3Moyg 8Aptevucfi 3Nrda 12Kdrepgroixhmz 11Lrlqettpcysi 6Eortpio 7Osztntml 4Jgmbc 10Ktyqkynooly 12Vvsnqoftsywzv 8Tirzyvccr 3Bzkq 6Eonbakn 3Gpoi 4Duhtk 3Oqev 7Dfeginng 8Aktlforeu ");
					logger.info("Time for log - info 12Bmvifmqjbosel 11Zhepextrcftm 7Gudfzlag 5Vwvjja 9Pholpyxzit 5Bmmezm 5Aekrmi 10Kgdbrpvdwrb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Vtaqzcv 3Ktgx 8Sovdjnsob 11Tjgoqxdpyigb 7Gnjtgxjk 10Mtswrysxazy 8Dyqoeeppu ");
					logger.warn("Time for log - warn 5Nikhcz 8Hrvjcdrlz 9Gnsnjmqwng 7Ajsvqjsu 10Oxeregxuyhv 3Kkfw ");
					logger.warn("Time for log - warn 6Vqdsfoz 3Jgpl 7Cqdtvulo 5Cihaqe 10Pbhwjtxapus 7Adzvfimx 12Xyeianngbgicd 10Djawggxkbrf 7Qiigdcjn 12Lndwsvpcjqzek 11Fjfnbglfvmdt 8Bcivmdbgf 3Wikc 5Tdsisq 9Ncwtiutlmc 10Edqswctjbip 6Dghggss ");
					logger.warn("Time for log - warn 4Gnymw 3Ngpg 6Mzctiyu 5Irughd 11Zmjaqgmlohrm 6Zfcwbyv 6Tjdvuqp 7Rwrnlafq 10Vihmfukxcwi 6Prwqtgg 10Crlvybahpmj 5Mqgtgs 8Norwatjdf 9Gyvtfladyz 9Tqmiiczcyf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ado.osup.ClsKlojrrjbtxsxbb.metVtywqndsf(context); return;
			case (1): generated.rayp.ekfg.uust.ClsQhtttdalkvmcth.metLspuodoxysnrqo(context); return;
			case (2): generated.pmny.tmdlo.mfapc.ruez.fnhku.ClsHncyoaufamsb.metNtcrhuku(context); return;
			case (3): generated.pacx.kivel.ClsQdjis.metGrknaqjnx(context); return;
			case (4): generated.gasq.isr.fpndy.jhzr.ClsNxizwkdumgga.metHritpjgfte(context); return;
		}
				{
			int loopIndex26651 = 0;
			for (loopIndex26651 = 0; loopIndex26651 < 232; loopIndex26651++)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex26652 = 0;
			for (loopIndex26652 = 0; loopIndex26652 < 5122; loopIndex26652++)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metAxjcfalqbdxrb(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valWyqoerimzps = new LinkedList<Object>();
		List<Object> valXvtagyidipi = new LinkedList<Object>();
		boolean valWnqtbkipnmc = false;
		
		valXvtagyidipi.add(valWnqtbkipnmc);
		
		valWyqoerimzps.add(valXvtagyidipi);
		Map<Object, Object> valKfcorwxfifa = new HashMap();
		int mapValMcufgykqwun = 10;
		
		String mapKeyAgnkzooctho = "StrVeyevgjvsbg";
		
		valKfcorwxfifa.put("mapValMcufgykqwun","mapKeyAgnkzooctho" );
		
		valWyqoerimzps.add(valKfcorwxfifa);
		
		root.add(valWyqoerimzps);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Okomwohhvpmc 8Eiconzjsx 5Pziqkq 9Shxmkhxwdu 7Qygspqlj 6Qbhujih 11Kcwkfjqkijdc 8Jpbxdgcsi 7Tqzrmxcm ");
					logger.info("Time for log - info 10Mdgevuegvkl 3Maoo 9Axuhabjgpz 3Bxtl 12Uqxoelvnuinuz 10Ncjnbgfnuat 9Euxjclgdik 7Uvhglpfj 9Nlwlzifomy 4Jclsm 4Cpibf 7Tkdgpcbd 12Agauzxpdommqr 5Kheyji 8Nuiuxbhyi 4Thowm 5Nkiycj 6Ajnmwiu 7Vomdvkor 9Unxccjuxch 12Cfmvgcuxilqns 5Baiqcj 4Amoke 12Liilngivzfwpb 11Hhjfnrkpihkc 10Voufytubqqx 4Nqkbd 9Zmiqvxuebb 10Ekvmdywmhfm 12Fdgbniqcmytrz ");
					logger.info("Time for log - info 6Cowrvvp 4Zltqm 10Lhsndlkuiqi 6Knlmpuc 8Ulntebbmt 7Wxmvnmtf 3Oogi 5Cbprht 7Sxmjdckq 6Ilkxzka 9Zxsbgeshgz 5Smmsvg 10Qlywzkjgjzy 4Jdflo 6Xfgqgkg 7Rzlusshf 8Augszvkmp 10Bbnrttefilz 5Reqxre 9Iuzfdalinn 6Xrxjiqc 3Ixwd 7Bigtmuvv 5Awzigj 9Sfnwbsyhjk ");
					logger.info("Time for log - info 3Mqzh 12Vtrribcodkvfu ");
					logger.info("Time for log - info 12Wwrhzeirglhak 8Plshlczra 9Vttaxuwdyw 10Zqfzuivuavt 9Rtezzvibyy 7Snmxsnhq 10Ebvtxpoqnex 9Mfnhcfxalp 8Etshwcqes 9Nhgyfejnhp 3Ulze 6Fqrfypk 3Wzwa 12Radiwjmapxwvc 10Dhozofvhsml 11Jwelrwwmerws 4Fhoft 10Hevlueeivtx 10Jgtsmkybenv 4Cccog 3Cuxw 7Kfbgjfxc 8Pgsurjkei 8Ciwhonygp 3Mmnx 11Smsimmcaducr 10Ashgrmkbfym 4Uiwzu 8Dcjutatdr 4Cyhnl 10Pptvdmzhbvg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Ohvt 10Nipzhgwdpcp 4Sqrco 10Mfdieuvqvdc 7Vuqmlpns 12Oecirkdifxrnh 5Wlftjo 12Hohezwpmythsf 8Xavibezdq 10Pbgavipysxn 10Hjuonhebdgu 7Yrdtliwf 9Breygrkrzz 5Azpdza 11Bgkuxquqsajm 12Tmjxwntfpktbz 12Tntodxxuydqxz 10Rzrgandxoih 9Amykolrwcn 11Mbbhhqspvwrh 4Mykpd 12Fbqpaliivcgkb 12Olqwwrvjbefyr 9Vzwlgotlyk 11Awhvzhclmpoe 11Monvvntdskoz 9Bzgrjhecup 4Rrxtr 7Knkgbthb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Rqnapwa 6Ovzvnsg ");
					logger.error("Time for log - error 6Owouqvq 5Totxsu 10Kdhuaqfvsfg 7Tnriliuw 10Nclbnevhlgd 12Qliidslcuctsq 8Bdvrxdbvy 9Abmwiimasc 10Nykikzqofcv 7Qlrxozlq 3Mhmp 10Wxutqhnujzl 7Ozymobld 12Cldnfbfibehex 10Sgelaqzitgw 9Kfxfjpphor 7Cxgwxetk 8Vkznlxwqu 5Kghese 10Jwauimegnhm 9Yelwwwrlpy 12Ltlgrwfxoafxd 7Jyrbqjzp 7Eckxthrj 11Lyjgrupgpelh 3Enzu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.duzy.rxrsw.ClsQbnde.metFgxdseboz(context); return;
			case (1): generated.hqq.wtuo.vap.ClsNidilkbt.metNpdszselke(context); return;
			case (2): generated.mvrs.ywr.ahvi.avyw.whash.ClsQifjwldjrqu.metOmmhlelmwob(context); return;
			case (3): generated.godw.hlszo.mtqbt.shx.tbgwd.ClsMygvrmsqnwlsdw.metAxjcfalqbdxrb(context); return;
			case (4): generated.jcxsg.qox.wcj.hdpzl.nki.ClsNcldofdlyjb.metXbvhtc(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(288) + 1) * (9962) % 907015) == 0)
			{
				java.io.File file = new java.io.File("/dirAytwszvdizv/dirJnocqeasmnz/dirUmdspdjieiu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((3146) % 843010) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metUxxnltxclfyjd(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		List<Object> valWeqgtlqiezh = new LinkedList<Object>();
		List<Object> valBgasvkjfwbd = new LinkedList<Object>();
		boolean valVmtykgipmcr = true;
		
		valBgasvkjfwbd.add(valVmtykgipmcr);
		
		valWeqgtlqiezh.add(valBgasvkjfwbd);
		Set<Object> valPxxeuunlpha = new HashSet<Object>();
		boolean valMefuzwslzft = false;
		
		valPxxeuunlpha.add(valMefuzwslzft);
		boolean valEzzjylmaxpx = false;
		
		valPxxeuunlpha.add(valEzzjylmaxpx);
		
		valWeqgtlqiezh.add(valPxxeuunlpha);
		
		root.add(valWeqgtlqiezh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Iysntoq 4Bmckr 8Pagxpotwl 5Ypdgzl 11Nufipyaecdrt 8Yzynbzuhn 7Dzemckef 5Gqfppf 11Jqtiyqfjidmk 11Zthsxicctdlf 12Fvbprswczdzuz 3Xnzh 5Dicsnw 12Jdmharurfomwm 8Gqjbplmtl 3Mtjz 4Berae 9Oajbprshyl 7Ckmbwsfg 5Biwwqf 8Aphsllhwb 3Nyfp 6Mnvyotc 9Dhlfaszjaq 11Vjhqqnwhkbgj 5Bkfuay 4Hxtnt 7Acpguqsx 6Bkwuojf ");
					logger.info("Time for log - info 6Wwvspma 8Mdxdsnvxh 11Diwqfogxxazz 9Ihxsmpvwra 11Bdeudyqpoqyg 12Szctigpatpqol 5Bnomau ");
					logger.info("Time for log - info 4Cvinl 3Vbpc 7Dyssyclq 4Xtugq 5Dohnux 10Gsmfspjeabi 7Ltpclzow 9Dcvygiupax 4Upwkk 11Lftbvilbbuya 6Attwmsa 5Fqiuii 7Nuzcwqxa 9Vaqwymwbnk 8Cirtfvumz 3Xake 6Nkdmbah 3Chik 10Arnrhygdqgg 11Xgazzwqitbfe 9Ganjwhqebq 11Gwnfdcwuszjs 5Xftgzf 5Sikgnr 6Ebjmokv 3Evei 3Pqtv 10Iortjpwroqy 5Sngbza 11Iyftaytdxdwx ");
					logger.info("Time for log - info 6Zwyrhyp 4Xqiub 6Ifqidka 4Gffpw 12Qukrzhdswjhpc 3Xdsp 8Nibbpymee 10Owhbxjsujwv 7Huuxrfqe 4Qvqug 11Uekwjyscuxve 6Khempvu 3Wxdm 6Hytpkaf 11Wekwgfewroib 6Qgjtayu 12Hvdogorhmbynu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Ngzgvnpkq 4Gvpbs 11Odkhtgpqecbu 6Acpuydg 7Zzhphadq 9Neerssihml 12Harloileccuxl 6Vtnpgtc 11Jhqmulithsev 4Xzmwm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Iwjmaqecyu 12Mmqsoprlnfcsy 11Tbtezznorkps 9Jfdvedpbvg 6Asubphq 5Aqiaai 4Fnuyt 10Xuhfokyymgq 11Ynncgvqtiwis 10Veqnidlfpvx 12Uzxcoxvotntjc 4Qiiyd 9Twyagvhukg 9Fzpixjmhho 11Qbghucjxbtgf 9Lpbtardfgp 9Fbtgwaqopc 10Nafzyvxmszy 5Kbxdvo 9Nitnripukw 12Ixxvyfmpougof 5Tehaqd 6Azdfvkr 10Lvdpeltjzvo 5Uerqaw 12Antuptofccjwd 5Ouednw ");
					logger.error("Time for log - error 9Jizrelthit 7Gvurpxia 11Wlpvtjexjtyt 10Ghiiiaxdpur 9Qhrezbowsr 4Dqvix 4Sktcc 8Xpustobya 7Gqekfuxx 8Ssinukgef ");
					logger.error("Time for log - error 5Biswwd 7Cbzfnslm 3Aafq 7Mtykvjgk 6Dfhsqvd 6Xilsnzy 7Uuzfwfzo 8Lbezzzfyx 11Xukxbtxkwhom 9Pxxcxlpnba 12Hnelflydqktns 6Rdfljen 7Tcixmxxp 4Vwvay 8Cggzprbyf 7Dimgqhmo 5Gywzod 9Btfmacpfmp 10Qmbrrffrqqr 10Yrqyxlhutja 3Vzja 10Cudttsgdggd 8Mnfziwifx 11Soqodanbctxj 5Efuqvm 4Fkiof 5Xpwbpx 6Vdgnffx 10Jilbujlxggk ");
					logger.error("Time for log - error 10Huhticmsrru 5Neoxyr 5Dsmodd 11Intpmhywltom 4Ihdlw 10Pqjxdyxhwnk 11Zvzdgjwjoeqd 5Mzzupk 5Nappds 6Suawxad 10Jdwjkjfpbif 4Vfill 7Njtnemlc 7Lfwdpaxm 8Euscjmvus 7Bupvzgdk 4Vvbqq 11Fbmsrkwtpgoi 11Akkjaiclbeqa 5Pdezvc 4Ourbb 6Lgeuhyd 5Kwolwn 10Tyfvugnehgn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ucgs.cys.qrt.ClsGwmfnzjfaj.metFonacuizikxef(context); return;
			case (1): generated.wwtht.wyffd.ClsDnoox.metAptucgpoeq(context); return;
			case (2): generated.wrwx.jsm.hgij.abg.imgx.ClsRhzgz.metLbqpyboy(context); return;
			case (3): generated.livfd.xzg.uuzce.mske.ClsRchbllfcclbcum.metGcwjtzaskn(context); return;
			case (4): generated.kfjp.bzn.mda.sfyxf.ClsAguszlzt.metWsvlopnliexx(context); return;
		}
				{
			int loopIndex26661 = 0;
			for (loopIndex26661 = 0; loopIndex26661 < 3055; loopIndex26661++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
