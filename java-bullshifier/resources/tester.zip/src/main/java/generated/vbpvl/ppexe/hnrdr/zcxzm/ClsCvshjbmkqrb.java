package generated.vbpvl.ppexe.hnrdr.zcxzm;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsCvshjbmkqrb
{
	 public static final int classId = 48;
	 static final Logger logger = LoggerFactory.getLogger(ClsCvshjbmkqrb.class);

	public static void metJcfyp(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valKanxrpadrbf = new HashMap();
		Set<Object> mapValZlpounkewgc = new HashSet<Object>();
		long valTikcpuajkgx = -8162344265312808165L;
		
		mapValZlpounkewgc.add(valTikcpuajkgx);
		long valWpltbuapeqz = -9132816832529128794L;
		
		mapValZlpounkewgc.add(valWpltbuapeqz);
		
		List<Object> mapKeyIpicmlqihgv = new LinkedList<Object>();
		long valPtuznpczqww = 6334919769149830816L;
		
		mapKeyIpicmlqihgv.add(valPtuznpczqww);
		
		valKanxrpadrbf.put("mapValZlpounkewgc","mapKeyIpicmlqihgv" );
		List<Object> mapValLgaibrnlcvo = new LinkedList<Object>();
		long valGhqsxfpopty = -5598523284188085316L;
		
		mapValLgaibrnlcvo.add(valGhqsxfpopty);
		
		List<Object> mapKeyKspqqusitgr = new LinkedList<Object>();
		int valPpflacyfnrv = 5;
		
		mapKeyKspqqusitgr.add(valPpflacyfnrv);
		String valZfniiwtbzvr = "StrHtcihppqtue";
		
		mapKeyKspqqusitgr.add(valZfniiwtbzvr);
		
		valKanxrpadrbf.put("mapValLgaibrnlcvo","mapKeyKspqqusitgr" );
		
		root.add(valKanxrpadrbf);
		Map<Object, Object> valZlpczofljvh = new HashMap();
		List<Object> mapValEtlncotqvil = new LinkedList<Object>();
		int valVamdqlvfyvj = 835;
		
		mapValEtlncotqvil.add(valVamdqlvfyvj);
		int valLtsolkuzwdz = 457;
		
		mapValEtlncotqvil.add(valLtsolkuzwdz);
		
		Object[] mapKeyPzwakybpoor = new Object[2];
		long valZjnxhkpmgis = 1324318681923440228L;
		
		    mapKeyPzwakybpoor[0] = valZjnxhkpmgis;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyPzwakybpoor[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZlpczofljvh.put("mapValEtlncotqvil","mapKeyPzwakybpoor" );
		
		root.add(valZlpczofljvh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Mgtyw 6Vmewqlc 6Nlykzic 11Mdgvxzsddtbf 11Ragxvorrqnwg 3Fthi 7Sdqhjwjy 10Bwwcshfshbk 9Tgiitxkjuf 7Zmuhqhzy 3Hwzw 6Rklmbce 12Gkhqwzoegbyfy 7Cfcxwoiz 6Depmklx 5Gefils 4Qvosh 12Tvomtqwualxus 10Bbajbmysesp 12Bycmfvaytagkw 6Epnkgct 8Hlrupzfqr 4Sblsn 4Aukye 3Etiv ");
					logger.info("Time for log - info 4Jxfum 8Suhtwpfnr 8Lbfctgyul 11Oshmmcavkrug 3Yuow 4Ddnyo 10Ooclvwdnknp 12Tbijebcpmslsw 6Pjhlmvw 7Xkmcsvqg 12Zyoeqnqlfomtg 3Xbnc 7Irevaspb 12Paxrxrlfjuwjg 3Phqt 5Pyllgu 9Jdctpsaomb 9Kwymqzctxs 9Amdrpssvqu 12Ubqsodrdpyquq 3Zfww 4Nfufr 6Zzwurtx 10Ncyyzziavau 9Wzdlvphpnn 5Svxuir 10Xstqbwcmwjq 3Ifyw 8Tienfpabp 11Pzdqjhnnlxhv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Lzmdndo 8Mnglejizl 6Ahclwvm 11Bmxzuevblpbm 6Xiwqyqe 9Ghfliekfbz 11Ptpnzifrvpig 12Itjqlgazwgohf 10Ffrszauujxj 5Acyosw 8Pcwtrxxcb 3Pgdk 9Qxzvcvqpyo 8Fnqstvgml 3Ljfx 9Ykbfrjowwp 6Vgbjinm 11Iosotezvkllg 11Lvhswgaffvul 10Mnmcgwgjqhv 10Hatfejafqkc 10Ktvyoaaysfg 4Jdflh 6Qdkjxsc 12Wfdczrhpmfygh 8Vrtqwxicq ");
					logger.warn("Time for log - warn 5Xqmaxx 7Ahlxugnh 12Xrcqbwagfetsr 11Swkakpftrnif 8Xcqhbuzkl 11Rkgnomzqxdez 10Caguaygbsar 6Qjpbbic 12Pkbseozlqelpm 4Eobts 4Wlvrp 7Slpcbpvp 5Croqwv 11Jmjwsypqqcid 7Zihinbqe ");
					logger.warn("Time for log - warn 7Zyulllcj 5Iddgyn 9Xhmcaohxlw 10Hppyezeuxyh 11Mhamdrbjrvze 5Xiuhsa 11Ybgfjnevmroe 7Coluxadh 5Vflbop 8Ikamsugsn 8Pkorpyrfz 3Ezyl 4Rvxbb 9Lovligsjyw 10Oozopghkear 10Tqwirjqmwgr 12Hvguvpmsjyqxg 9Lckmgxonbk 6Wayszmc 9Vuznqouiyk 4Htoow 11Wwucjnrqwnhv 5Fbonhd 5Ihfxlt 5Qyaoti 4Qavim 6Fqrnyqv 8Qzthbpyba 8Ucwtcpqmu ");
					logger.warn("Time for log - warn 12Lnfwmljplcnxy 3Vfpl 10Xsmxrtycgsk 12Dckhgxkaevfen 12Ihtarbdsyimon 5Gpfipl 8Zdqvavqdr 11Udlhufkytxfj 6Egnmcyd 8Vjxsqampu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Sllt 11Vrswxqvugpiz 6Iznbqcr 8Hovxyqzxl 12Pahlmygwkmpla 11Trdwevbzliec 9Otulqgdvvb 8Nauqoivik 4Zvlyp 9Iipiquhuzr 9Daflutpkmw 3Zxfj 4Lrkrw 8Einzyyvxi 12Apzqdwhovdpof 10Whmwtwwbleh 9Sthqidkimy 12Cloqvrxuxhvvt 12Mcntezhnhulwp 6Cricnxn 8Ydeahzjbt 3Mkpm ");
					logger.error("Time for log - error 4Fdqzn 7Ateogtcf 8Irwwhappp 7Xmgfrzhy 6Ehjifja 11Dswvcfhuqmcn 11Bvecaelofbya 6Sennuht 3Fbuh 12Jwqrntnaaqlvo 7Tncwhubz 7Ynyhrsox 4Oqvxa 7Dbmcqgjk 7Voxrijsh 12Ditoyvfvguqzm 3Tmps 7Mecxmaov 6Rmieryd 10Zxwhgjcmmkn 7Ojrtmjwo 12Pqanmflkinyfh 4Dhtlt 7Famckhnt 7Wbhzixic 11Fwmpyaiupoyx 7Nckksmzj 4Hlsws 10Lowzpivabyb 6Yokdtln 11Xvjfjclsbjog ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qku.vho.jtvuy.nvgy.zmvk.ClsVjaehh.metEpucadc(context); return;
			case (1): generated.meo.tvmj.xqqix.qdpb.crypd.ClsCqiefbhpitkzjs.metRkiiokfveuzir(context); return;
			case (2): generated.zuj.yzx.nga.pvup.ClsJyskqhfglgbk.metCxwonkfw(context); return;
			case (3): generated.twx.gyla.ClsYuzgeqywoqmok.metZrjgdmb(context); return;
			case (4): generated.alv.nmsc.bjnyq.zit.ClsUxjrwrfu.metWcnramwnolmtp(context); return;
		}
				{
			long whileIndex2889 = 0;
			
			while (whileIndex2889-- > 0)
			{
				try
				{
					Integer.parseInt("numXrflfcrvkgd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex2890 = 0;
			
			while (whileIndex2890-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
