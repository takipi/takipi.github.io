package generated.eddt.homo.syk.wqll.dyeuq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsYzlmjqrjjp
{
	 public static final int classId = 68;
	 static final Logger logger = LoggerFactory.getLogger(ClsYzlmjqrjjp.class);

	public static void metWfbnvwlbefalsd(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValPlwtrtutrqn = new Object[3];
		Map<Object, Object> valDaolcrrwomj = new HashMap();
		long mapValGwaznvkosdi = -3366147378021759666L;
		
		boolean mapKeyLkogvahzpcb = true;
		
		valDaolcrrwomj.put("mapValGwaznvkosdi","mapKeyLkogvahzpcb" );
		
		    mapValPlwtrtutrqn[0] = valDaolcrrwomj;
		for (int i = 1; i < 3; i++)
		{
		    mapValPlwtrtutrqn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyHkjqhkntncr = new HashMap();
		Map<Object, Object> mapValQgrqhshntvg = new HashMap();
		long mapValJjhcdktmoza = -4735461676956133123L;
		
		String mapKeyPnfzcsqydut = "StrQbljrzgxawe";
		
		mapValQgrqhshntvg.put("mapValJjhcdktmoza","mapKeyPnfzcsqydut" );
		int mapValZjhwtkdqdak = 582;
		
		int mapKeyNhdzhuyxmfy = 63;
		
		mapValQgrqhshntvg.put("mapValZjhwtkdqdak","mapKeyNhdzhuyxmfy" );
		
		Object[] mapKeyPflthbzeqjr = new Object[4];
		long valGspwsaiirbi = 5836519451496793921L;
		
		    mapKeyPflthbzeqjr[0] = valGspwsaiirbi;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyPflthbzeqjr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyHkjqhkntncr.put("mapValQgrqhshntvg","mapKeyPflthbzeqjr" );
		
		root.put("mapValPlwtrtutrqn","mapKeyHkjqhkntncr" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Eiuhzqwb 6Rexiuvl 8Qvosezhqq 3Qjwf 6Umdktrb 11Xfgbxorusqhc 4Huzaf 11Yceafngxnuec 7Voijuakx 11Phnwmqmgxqob 4Faolp 10Opwtscaubsj 3Xdnx 8Onbppreoj 12Ibejgscclgmwn 7Hmlppasz 11Mkfmczobinnq 6Fnmybeq 9Kphdzbdlzk 3Hjnq 10Ujbkkgcsvoj 9Meweywazyx 3Ujvb 11Srygswfceswb 5Cypkfw 8Eoaqgelor 5Hvpbpd 12Wzltfvuvhfyvt ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Lsaawp 5Eysaqi 5Nqrzef 5Zphofn 10Vvxhcredyac 7Whziydcq 9Suaclabrgc 7Xwtcwfjn 5Skldcr 9Axtwoveauv 8Dlgfcxsaw 6Gnupbmm 7Vjexayzw 5Otkxtc 9Jibgwajoir ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Iledmrl 4Cziyz 6Kzcxvzh 12Aueavwmuhqcch 4Kljve 9Jcoontaizh 3Yguu 12Ldgymtjzeckus 4Qqltz 7Eumxuauq 7Nqwyybmo 7Iosrodke 7Dxncybtp 4Maxtw 5Qfudzd 3Hzsb 7Qowfamoy 11Gjycufquvuwv 12Kfhiymuzfivgb 11Dhirvjxmkqxw 5Udwdfu 7Vzpherjg 4Lxpuy 4Gqhrv 4Pbmtz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.guq.may.fgxvf.ClsClatvr.metFgntuphc(context); return;
			case (1): generated.pfu.znq.ClsGxncns.metXbdeur(context); return;
			case (2): generated.kkru.kkr.eff.wedv.ClsTciibuckxmwxc.metEofuqsp(context); return;
			case (3): generated.wunj.xtrc.rfx.aikz.yopv.ClsTejixmzc.metAhxfdsezzruvtx(context); return;
			case (4): generated.rnv.dtvl.uhnk.ClsTzqkdsb.metKrrjeushc(context); return;
		}
				{
			long whileIndex21205 = 0;
			
			while (whileIndex21205-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metCwoimorcxixd(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValBoujdtdjyik = new HashMap();
		Set<Object> mapValKyzonohbnio = new HashSet<Object>();
		long valBiopmfdvvyq = -888033792147980407L;
		
		mapValKyzonohbnio.add(valBiopmfdvvyq);
		long valGrhfgarsqak = 7789759551556332754L;
		
		mapValKyzonohbnio.add(valGrhfgarsqak);
		
		Set<Object> mapKeyLrggnvxjfhs = new HashSet<Object>();
		boolean valWgpyvhnnxqf = false;
		
		mapKeyLrggnvxjfhs.add(valWgpyvhnnxqf);
		
		mapValBoujdtdjyik.put("mapValKyzonohbnio","mapKeyLrggnvxjfhs" );
		Set<Object> mapValObjqjucwuhe = new HashSet<Object>();
		int valCyekmqijuoi = 4;
		
		mapValObjqjucwuhe.add(valCyekmqijuoi);
		
		Object[] mapKeyUuanmvjoacd = new Object[2];
		boolean valUyiwauthztx = true;
		
		    mapKeyUuanmvjoacd[0] = valUyiwauthztx;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyUuanmvjoacd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValBoujdtdjyik.put("mapValObjqjucwuhe","mapKeyUuanmvjoacd" );
		
		Set<Object> mapKeyZpmmmxdilmo = new HashSet<Object>();
		Set<Object> valTumktkqvllx = new HashSet<Object>();
		boolean valEnzwmcruebp = false;
		
		valTumktkqvllx.add(valEnzwmcruebp);
		boolean valKxlujtyaepx = true;
		
		valTumktkqvllx.add(valKxlujtyaepx);
		
		mapKeyZpmmmxdilmo.add(valTumktkqvllx);
		Map<Object, Object> valMlpouhhkaoj = new HashMap();
		int mapValLvjwiffdfaj = 769;
		
		long mapKeyFedvoyokcfq = -6101565936494856073L;
		
		valMlpouhhkaoj.put("mapValLvjwiffdfaj","mapKeyFedvoyokcfq" );
		
		mapKeyZpmmmxdilmo.add(valMlpouhhkaoj);
		
		root.put("mapValBoujdtdjyik","mapKeyZpmmmxdilmo" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Wiol 6Epkwsdi 3Lmie 3Tpcn 4Kxwis 10Gjxwasocnsb 12Zrsqgfbbejdpo 3Oqlq 12Pwwcdrehbekuo 7Jitudgjx 3Xelm 5Hytlez 5Ymwrrp 8Tejuwzukt 7Dnzmmvaq 7Lnitfpcm 10Lyugkkzggxh 11Atfoeghpyobp 7Selrdgoe 4Qoshx 4Rfygu 4Sptnb 11Fhessulaozrl 5Epolsa 3Ejio ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jyd.enpnr.ClsZxueqcgpd.metEwimth(context); return;
			case (1): generated.psl.vgj.rgm.ikl.ClsWqomoi.metKrbftwlk(context); return;
			case (2): generated.qpe.ifudp.xgatn.jzg.qau.ClsJymdeqopgpbo.metNcpaipo(context); return;
			case (3): generated.lxeoh.qnh.crznc.ifldw.owge.ClsJaitfhoyoqqri.metElosoop(context); return;
			case (4): generated.zeo.tykl.bkniu.uhs.uwxh.ClsUegpnzqhmar.metNitnfqpe(context); return;
		}
				{
			int loopIndex21208 = 0;
			for (loopIndex21208 = 0; loopIndex21208 < 6824; loopIndex21208++)
			{
				java.io.File file = new java.io.File("/dirXvbgsyrotbd/dirZahpggxltvl/dirIpcefchtbrh/dirVfwtxksevzk/dirRrnqgmtioic/dirMvvwljcdrau");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex21209 = 0;
			for (loopIndex21209 = 0; loopIndex21209 < 541; loopIndex21209++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirMvludjmqgaa");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex21214)
			{
			}
			
		}
	}


	public static void metMqehtaaykikdy(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValSpgdgfwjszf = new HashSet<Object>();
		Object[] valEfkfvbgecna = new Object[2];
		boolean valOmhxjlnlpin = true;
		
		    valEfkfvbgecna[0] = valOmhxjlnlpin;
		for (int i = 1; i < 2; i++)
		{
		    valEfkfvbgecna[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValSpgdgfwjszf.add(valEfkfvbgecna);
		Object[] valRtyahprfgtq = new Object[7];
		boolean valAjnsieipyad = false;
		
		    valRtyahprfgtq[0] = valAjnsieipyad;
		for (int i = 1; i < 7; i++)
		{
		    valRtyahprfgtq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValSpgdgfwjszf.add(valRtyahprfgtq);
		
		Set<Object> mapKeyYgterzfoonm = new HashSet<Object>();
		Map<Object, Object> valDuvxwpamstn = new HashMap();
		int mapValRsczftectde = 274;
		
		boolean mapKeyQldskagiiyh = true;
		
		valDuvxwpamstn.put("mapValRsczftectde","mapKeyQldskagiiyh" );
		int mapValDmykuqfxuan = 482;
		
		long mapKeyBksgjgdlrjm = -4746700127004390583L;
		
		valDuvxwpamstn.put("mapValDmykuqfxuan","mapKeyBksgjgdlrjm" );
		
		mapKeyYgterzfoonm.add(valDuvxwpamstn);
		
		root.put("mapValSpgdgfwjszf","mapKeyYgterzfoonm" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Lfopy 10Pksknwbrqon 8Onmmzfnvk 9Oxywgqfdep 8Sncplibxi 7Eeiyabzm 8Dqfhnxwje 11Oterczpdxrut 9Jyivaeqmpu 11Tvlxhrrreegd 12Iibmyavlgjosi 11Euydgfymhfrw 8Pyrdcvcla 12Ftwymxjxmqtrn 12Mgmkhtegnjaph 7Tjihvjtk 12Oormhrnrenjve 6Sgzxhfb 10Sqcvvxpjhld 7Qenxcwib 7Ifyoizty 7Ikmphndp 9Jmzxezdaut 7Qhjwsjou 9Sutajulptm 6Cjdljlu 11Ekbtagscpsur 10Uomsaqdzaqu 6Xnflqod 8Wxatltaof ");
					logger.info("Time for log - info 10Cefuiuzzdpl 3Pjeq 12Cwoswpyfsrgmd 6Kygfotn 3Ucsi 8Dsvdvsukc 5Jfbhel 10Dfnpwimvamr 10Ydabvgnqebq 3Glvk 7Srkwnrgm 5Einwqp 10Dvjbosthgco 4Vkeio 6Dzpfofq 4Nyumq 11Ifdhdjytrgwi 5Dutvrm 10Jbmlusfgzso 4Isprd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Msge 6Ahsznwu 6Rmcvwze 7Rczqpsqe 10Ckvyzvujxie 6Mhnculd 3Bhnb 3Dwvb ");
					logger.warn("Time for log - warn 11Vmmkgcmxvgef 11Egyfepoojkhh 5Aayhid 4Ksyao 6Vtalzkk 9Wtuolnwddh 5Jkchmt 4Uhcwy 4Ezvii 7Ctcfmalm 5Ppypng 8Isfdxdizu 3Tlzd 11Fmsjzwlrqwhw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Toakltqaam 8Rjkoflair 4Ydueb 4Wjmcp 6Qsxxkij 10Asnbhtahjub 7Chsnmmqz 3Vfem 3Hxts 4Bylyb 6Lndmfrd 3Mcrv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cqy.ffep.ClsWvinhicphnl.metWwbnpyd(context); return;
			case (1): generated.zuqq.dis.ClsZotjz.metPhpym(context); return;
			case (2): generated.nle.etupm.unno.jlzdn.uik.ClsNynvcklxtmhfla.metVlaejrvj(context); return;
			case (3): generated.tgr.kelz.siz.xfels.ClsKydjl.metQmhajcedjutgex(context); return;
			case (4): generated.rnr.pwsrq.cbi.tat.ClsQsqavl.metNujgqvqobxeyw(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex21220)
			{
			}
			
			long whileIndex21217 = 0;
			
			while (whileIndex21217-- > 0)
			{
				try
				{
					Integer.parseInt("numXzbgtzqcgtu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numVvinqsblmdk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex21223)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metMppewjvqxegqe(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Object[] valVmjdftygyzf = new Object[4];
		Set<Object> valCbgfvjyvbup = new HashSet<Object>();
		int valHkxfkjyhrrf = 76;
		
		valCbgfvjyvbup.add(valHkxfkjyhrrf);
		
		    valVmjdftygyzf[0] = valCbgfvjyvbup;
		for (int i = 1; i < 4; i++)
		{
		    valVmjdftygyzf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valVmjdftygyzf);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Ermtbcpp 9Oknwwauawg 7Rbnhsmwl 7Sqjfsidr 6Xpstgcx 5Gzqany 8Pbpisekmk 7Rfdvista 5Omvhpo 4Ifzwo 9Gqanlamjdu 8Kksmyofub 6Rwzxstq ");
					logger.info("Time for log - info 5Koafte 9Ibpgxtlvzd 7Uwoqxutj 7Pcwdsrqz 5Unuqwj 11Fwqokekyxyto 6Tsrzijz 8Bzmktaovh 4Skjwr 4Hmxrj 3Llie 6Ikkrrcr 7Bkqgkpfu 12Zxtsdpkxlgxei ");
					logger.info("Time for log - info 10Srsgtotmdve 6Wxcnuzh 8Koywtfnvo 7Ekjymrcu 8Ulpwuuftt 5Crdjko 3Sfeg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Yzteukc 5Dquvbg 5Tuadrc 9Lqdsddopgd 11Kstsfepcunuy 3Qrzg 3Aukb 4Mylzm 3Jftg 6Lwdxzfb 6Upabcav 6Kazkdsd 7Cjxjecvx 7Rmygzzqq 6Nfysrap 5Gernaj 10Zqhbcasisrf 8Vzzyyadfz 12Plttewhxlyttt 7Wsqwbsxj 11Pkojsnnhyzjg 6Cirupfm 6Tqocqgc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Rhuezipfomaha 8Gnnwmghlo 12Gegnudwagqgle 12Irooxeryvxunp 10Lhyjphuaeqs 7Fjhqeafp 12Iiumvlwyvfrxl ");
					logger.error("Time for log - error 10Epqdlajgopf 5Yasjjj 3Hgrt 8Xbftsmckk 4Itcna 5Hmmbze 7Wnyunoeh 6Wpscbhc 11Siiellnxxlnc ");
					logger.error("Time for log - error 3Bcvh 9Gbxmyxnhwa 10Oftqmpzratb 9Bnwodtnypw 7Xsyjtsvx 3Gtaa 10Lgfbmlrfunk 5Owruha 6Zifitxr 6Hcgrgjo 9Zzpybpqtxn 9Tyzgemaqwz 4Wqrul 8Hfyqlrctd 5Phsdaq 7Jmitxenw ");
					logger.error("Time for log - error 5Mhtkhg 4Ttkdi 4Xfaer 7Rmknxcmu 7Xguxtdwf 12Pfcpfqcosbzvv 4Gjeme 11Zgznjawsccoe 7Tgkodxmt 4Fopbi 9Uddccstkow 12Kpswjsoobveuy 11Qouesrqaflsa 8Utayrhqap 11Uqxwlrktwbwd 6Tdugrjn 8Pvddluhxn 4Qkmbu 3Bdxv 10Mjrhwohryrz 5Udemda 10Ziamvgnzysx 3Wuvz 8Ibcycqxmf 3Jvfj 6Qulfjri 10Vqpshqxyelh 11Tzzkryxqbxsx 10Jygbgrukbrr 10Hewpluhpwwc 11Drbfaepyjdms ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cfolx.abg.ClsZqloaugvusc.metIetjxtz(context); return;
			case (1): generated.owqo.mlfkn.xvo.nivs.zcmac.ClsNuoghbmezp.metDtgdmwp(context); return;
			case (2): generated.mrz.embg.gydr.vls.fvllv.ClsYrxhq.metOlxzxxtvhnzlxg(context); return;
			case (3): generated.cjexh.ehrl.mtwqa.ClsVshethruisurxt.metGryimbv(context); return;
			case (4): generated.bjkl.rwmim.scbu.axq.ClsFteiawx.metUpikxxqrqxf(context); return;
		}
				{
			if (((3324) % 440371) == 0)
			{
				try
				{
					Integer.parseInt("numYfhfxcgpygq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((7423) % 906474) == 0)
			{
				try
				{
					Integer.parseInt("numQphiprnrsjn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((9105) - (Config.get().getRandom().nextInt(364) + 2) % 867936) == 0)
			{
				java.io.File file = new java.io.File("/dirNfsmvqthfhj/dirFocpvjyyxoy/dirEoqippqirwy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numLocydrlplkz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
