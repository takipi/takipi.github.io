package generated.bcbrr.mrpx;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJcswauwrr
{
	 public static final int classId = 220;
	 static final Logger logger = LoggerFactory.getLogger(ClsJcswauwrr.class);

	public static void metIydcpeyrd(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valPxosmdprzfv = new HashMap();
		Object[] mapValLfqfjcsyupo = new Object[10];
		boolean valXlngchyekgh = false;
		
		    mapValLfqfjcsyupo[0] = valXlngchyekgh;
		for (int i = 1; i < 10; i++)
		{
		    mapValLfqfjcsyupo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyNjzmmfvgnah = new HashMap();
		long mapValQnaqqsneltr = -8376434727065670016L;
		
		long mapKeyAslgyoelfdn = 8744833684355592568L;
		
		mapKeyNjzmmfvgnah.put("mapValQnaqqsneltr","mapKeyAslgyoelfdn" );
		int mapValIvyfzebjifz = 34;
		
		boolean mapKeyMbxfwjqvinu = true;
		
		mapKeyNjzmmfvgnah.put("mapValIvyfzebjifz","mapKeyMbxfwjqvinu" );
		
		valPxosmdprzfv.put("mapValLfqfjcsyupo","mapKeyNjzmmfvgnah" );
		Object[] mapValXwjkrttaumn = new Object[9];
		int valNsjibcijweh = 610;
		
		    mapValXwjkrttaumn[0] = valNsjibcijweh;
		for (int i = 1; i < 9; i++)
		{
		    mapValXwjkrttaumn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyKqnojmmbumq = new Object[5];
		int valRgtliawqwtz = 552;
		
		    mapKeyKqnojmmbumq[0] = valRgtliawqwtz;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyKqnojmmbumq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valPxosmdprzfv.put("mapValXwjkrttaumn","mapKeyKqnojmmbumq" );
		
		root.add(valPxosmdprzfv);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Kmxxpmbafkied 9Tlplpxtmgk 12Wwqfkeqwavtpg 7Byftcbvh 8Jerejebvi 9Cunvkxnviu 8Lxvhlyskn 12Xuwmasgswowva 4Nkqip 12Axeuvhbrodscj 12Ivmumablmedch 3Swiq 12Rmaogjmnonvce 11Tqhfesdktlyp 4Mpcuh 10Hlmbdsiijyt 9Ocdddbyjfm 10Sazetoosmft ");
					logger.info("Time for log - info 12Ldfttscpxabhs 4Fkgpz 3Ueps 9Dtjtqzblyg 7Ullijslb 5Qldhfc 6Hwtfdpq 9Jkirmwwqum 11Kwdjfcieatcq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Qenb 7Hrywbgnp 10Ftlpivwphxf 7Ylrdanxy 9Izchinrrsq 10Gfdzzbvhxuq 12Hircmwbtrtjwx 8Czhcfzztr 5Raiaqh 12Jgfdkowlfotrv 12Ytfhhabmgwbnw 4Adhjd 9Aclyknhysu 8Rwiwtffdh 10Ahonhtzgxvm 4Rbbzl 4Needd 8Bjqdvwdoz ");
					logger.warn("Time for log - warn 6Mwfwdyp 7Ttgmafxr 4Jrqqc 7Mjghglgs 9Scqpdfpqyr 6Axzlysh 10Uegwwnpxeyg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Yadsdhinbeab 4Bpgug 10Mbeecilydvk 6Yzpncnt 12Yxyxbzfakshqu 7Mcpqassg 8Rafxfkqur 9Xdfncbaxmi 3Lgzv 11Hnucmagepjik 4Kudoq 4Zleom 7Vvqgzgha 6Hkynpzl 9Ozfiskggzd 4Rorsz 3Dfrq 12Hoglifcauwmig 3Ubhy 3Pxsi 5Rxmtse 10Anyrtxtdaso 12Gvyamzijrosje 12Uvzykxeehticl 11Hiwrffuykyru 4Rtojx 6Jyupduq 4Jbqcp 6Achhjaz 12Mwdpehzrmyxkr ");
					logger.error("Time for log - error 5Lntpgh 7Kkuqaqzd 4Pwrrg 9Eecsatldrq 10Zrhlunacael 6Jklpuru 10Befxwgtlxof 3Saat 7Ikqzzswp 3Deil 7Kitxdhvn 12Crtytbacarfap 3Rxon 4Urajf 7Hvgyytgq 5Gqiaca 5Wdcbdj 11Fthzsnqjsnjs 9Yxunhhcutl 10Ixgmgftljts 10Gogqbyarzxw 9Ixgrlznemt 9Ithubgjsty 4Hlqcf 10Wgjucihpprv 7Qkdyxbzx 10Dhncjcyfzma ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vuj.qjcvs.phb.poi.ueh.ClsHxaaaxntrhq.metHrwdn(context); return;
			case (1): generated.obfi.prawn.asr.ClsHvlzhrjejvoom.metHvtgxvmeo(context); return;
			case (2): generated.nexb.cijvx.oksu.fhpbq.ivltf.ClsErarfyfw.metMuphdva(context); return;
			case (3): generated.bwwh.pcsa.hpav.bbh.ClsXicvnzwjqnoh.metQfgugo(context); return;
			case (4): generated.pema.ddj.ssuh.ClsIlinaijnkxxo.metCsqjaayw(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numGqqqvymuoyi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex23903)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((3178) % 556144) == 0)
			{
				java.io.File file = new java.io.File("/dirEfvxjdjdrbw/dirUjqoebvwvmd/dirCnkjwtpmnqq/dirCdgdgetlobe/dirUmlguivqsho/dirBidtwwmqjvo");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numQtkhhpzmwwi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
