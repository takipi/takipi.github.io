package generated.kjubh.rgz.earxz.ypjc.pmupv;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsUctrmkk
{
	 public static final int classId = 364;
	 static final Logger logger = LoggerFactory.getLogger(ClsUctrmkk.class);

	public static void metPxspawrgwl(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[6];
		Object[] valCrozjjqptix = new Object[8];
		Map<Object, Object> valJwlofywllkj = new HashMap();
		int mapValChxmwjpiotz = 92;
		
		boolean mapKeyRrurawrbwrw = false;
		
		valJwlofywllkj.put("mapValChxmwjpiotz","mapKeyRrurawrbwrw" );
		String mapValCfzfmdsaero = "StrGrfjbvtrtga";
		
		int mapKeyIgcfxuqlhex = 79;
		
		valJwlofywllkj.put("mapValCfzfmdsaero","mapKeyIgcfxuqlhex" );
		
		    valCrozjjqptix[0] = valJwlofywllkj;
		for (int i = 1; i < 8; i++)
		{
		    valCrozjjqptix[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valCrozjjqptix;
		for (int i = 1; i < 6; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Zjarvhy 3Ldqc 7Asbbgcnz 8Ccudjuwvx 9Fgrcmtrzqa 4Pgmcg 5Xceczu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Wlswq 8Ejnoqowyu 7Nwluasav 11Bjsrmkafjcet 5Bglhrd 4Efsuq 4Ucyxe 5Pnitkr 12Ierlobzrvnyzy 6Cxzsbui 8Gffrvgwty 12Mtykhelhdeluw 7Imiqrgbc 7Dufktokm 8Ccerfkqgq 7Yixarewj 10Jiaijuqpqkw 12Htdukrqkzgibt 9Tmkpjoovsv 10Xnkbwgigqar 12Flnzdkwmjchoa 7Vcgolyty 4Psnql 7Lxejmbme 9Kxbcozghcz 12Zwznpnzsztupe ");
					logger.warn("Time for log - warn 8Vshzqtiey 4Iifxr 3Kkfg 11Swxlvpagpabn 3Dcmb 9Erqhyktkhl ");
					logger.warn("Time for log - warn 4Hfmbm 6Zlhcelh ");
					logger.warn("Time for log - warn 7Rrbfxvto 8Azgplgwde 4Txykz 4Hutyz 12Mrftprxqreejm 4Bccgf 4Pzuss 3Wguz 7Vpajkkys ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Dswvmzc 12Pznqfpwmwbmjp 9Gqbardnnlz 10Odoyudrpnxz 6Sugfqss 9Jrjfbftaic ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metTlqjnsfger(context); return;
			case (1): generated.kfvy.ymxa.end.hazk.nwqfn.ClsXakhsfoyrlse.metJcgkp(context); return;
			case (2): generated.svs.oxvq.ClsHqpfa.metBgvjclpbm(context); return;
			case (3): generated.usy.jqyb.aoxm.cmxc.tdb.ClsGdtxkhc.metAqtyyf(context); return;
			case (4): generated.rprz.twb.ozdl.ClsMnahuieydv.metLsuejvaasjahy(context); return;
		}
				{
			if (((7762) + (9234) % 29322) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(236) + 3) % 707984) == 0)
			{
				try
				{
					Integer.parseInt("numSrqawsawnad");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((Config.get().getRandom().nextInt(329) + 5) * (Config.get().getRandom().nextInt(174) + 1) % 133621) == 0)
			{
				try
				{
					Integer.parseInt("numRocdexezfxr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirPlkpzwiumjb/dirEcbdwiroprt/dirVappkbvvcre/dirBeutiselpfi/dirOepblsihxhr/dirCtgyrncjefh/dirErrxgofmsea");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirZligulhycoo/dirIsyvbudvidk/dirPbpzujfhrxh/dirXnlquncytxs/dirCqvocwnbuqg/dirLsvssdlqyer/dirDpdrcoommtd/dirCiunczfxaye");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metKedywb(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[5];
		Object[] valFjoapsukhyt = new Object[8];
		Map<Object, Object> valMwtnqmanhdx = new HashMap();
		long mapValImpooltfcvj = -2524091361378535328L;
		
		int mapKeyBfofhblwhjn = 661;
		
		valMwtnqmanhdx.put("mapValImpooltfcvj","mapKeyBfofhblwhjn" );
		
		    valFjoapsukhyt[0] = valMwtnqmanhdx;
		for (int i = 1; i < 8; i++)
		{
		    valFjoapsukhyt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valFjoapsukhyt;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Kafqwtrbeajho 4Iyqxl 6Lmbgjqm 11Puasdzgcufzj 6Htakxne 9Axvpuzgnte 6Fkjlpiv 4Vqnkt 8Kdanaijgu ");
					logger.info("Time for log - info 7Ovsenrfe 12Lrxmxspisatgi 12Nxdkknmezuiyh 3Syin 11Lmhejhvlozlt 7Mhpfwjpn 7Qptgnrhe 5Dqgtqd 7Hsdkmqig 8Ehmutulvx 7Omhdeaes 5Mrzgcs 9Zarzejhzsm 9Qdugzuaodu 11Khwehrcfapfp 9Mhqbsbtqwz 8Hsgrssrft 8Kagoxntof 6Bqxdeam 9Mndoqlyzyk 6Doxrexp ");
					logger.info("Time for log - info 8Aayexspau 6Myivzmq 6Qdiftwq 6Ikxthcr 5Ipmjfe 3Oetd 9Fgcfhtrmcm 11Sbypmnhirwex 4Fqyqi 4Nzufj 12Aqiqqsvdhlyyq 4Pqsoo 9Yucqqrmqge 10Mbsohiqjvso 6Cblwyup 11Nelakghkquma 7Tkvedjmu 10Ngqfvzjtcml 3Rtcw 3Rmpo 5Deamgt 9Tuwxeasyxt 8Ruatlrenj 10Ystinupapnb 3Gbhg 6Rlikxxq 10Rdszqwdgiwm 4Tfyyy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Xluphhbjumih 8Umednhxke 10Ujruhsmtjha 4Cownr 10Rxcqxfhksoa 7Ytyjdlcs 4Pvlph 12Gdchhomxgcknh 12Rdvoqohbhklfm 4Dnrdq 6Crwbbqv 10Qigezlydtml 3Jyvc 10Bfjrauikukk 11Uqijdvowhhvb 11Pbsylodbpwfp 3Qtpt 5Gkydzj 11Swlzahuxrodj 10Opkpspehdgn 6Hekqtrh 4Tliir 6Jqecghe 4Bkzdw 8Gmebcxxzm 10Tghhunpmtjz 10Efakmwobbmm 3Ahqe ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Zasfi 10Nqxvvfepewe 7Iwhcabbp 6Zhmhljc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zic.glh.ClsJylyrkbuexopc.metXfvmhgsf(context); return;
			case (1): generated.kfvy.ymxa.end.hazk.nwqfn.ClsXakhsfoyrlse.metJcgkp(context); return;
			case (2): generated.obfi.prawn.asr.ClsHvlzhrjejvoom.metCqwbu(context); return;
			case (3): generated.qdml.hmlho.ClsQuiharvpvfv.metXrurj(context); return;
			case (4): generated.evl.qnyx.qnt.hnkpr.mua.ClsPqzytqp.metUawoukuahbtfc(context); return;
		}
				{
			long varRxpvsfphjve = (5773);
		}
	}

}
