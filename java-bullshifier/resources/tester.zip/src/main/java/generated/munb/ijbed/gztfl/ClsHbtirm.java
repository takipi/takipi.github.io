package generated.munb.ijbed.gztfl;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsHbtirm
{
	 public static final int classId = 494;
	 static final Logger logger = LoggerFactory.getLogger(ClsHbtirm.class);

	public static void metFoavrf(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValAgwpokkaehs = new LinkedList<Object>();
		List<Object> valXkwpinuiagk = new LinkedList<Object>();
		String valCpfzyiyxohb = "StrPzxkhskoycy";
		
		valXkwpinuiagk.add(valCpfzyiyxohb);
		
		mapValAgwpokkaehs.add(valXkwpinuiagk);
		
		Object[] mapKeyWgpzpfhrhdd = new Object[6];
		List<Object> valWdqzsaquajo = new LinkedList<Object>();
		String valOjluzsaepzt = "StrJcbgmmyaite";
		
		valWdqzsaquajo.add(valOjluzsaepzt);
		
		    mapKeyWgpzpfhrhdd[0] = valWdqzsaquajo;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyWgpzpfhrhdd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValAgwpokkaehs","mapKeyWgpzpfhrhdd" );
		List<Object> mapValToanxgzvsqt = new LinkedList<Object>();
		Set<Object> valZxncvhpwzpm = new HashSet<Object>();
		long valVmaginkzwid = -2317729500155366030L;
		
		valZxncvhpwzpm.add(valVmaginkzwid);
		String valTxqvqtcwjcj = "StrOcketozocuc";
		
		valZxncvhpwzpm.add(valTxqvqtcwjcj);
		
		mapValToanxgzvsqt.add(valZxncvhpwzpm);
		Set<Object> valTapqydaszda = new HashSet<Object>();
		long valGhutpjsvvpe = -350134369439553780L;
		
		valTapqydaszda.add(valGhutpjsvvpe);
		
		mapValToanxgzvsqt.add(valTapqydaszda);
		
		Set<Object> mapKeyPgmgegvgxls = new HashSet<Object>();
		List<Object> valZofsrcuopxv = new LinkedList<Object>();
		String valBiidjmkiaza = "StrQvrnmgsynec";
		
		valZofsrcuopxv.add(valBiidjmkiaza);
		long valSckujkhaajz = 5964207616930308033L;
		
		valZofsrcuopxv.add(valSckujkhaajz);
		
		mapKeyPgmgegvgxls.add(valZofsrcuopxv);
		Object[] valHgifhkbyega = new Object[2];
		int valZazmaqrixyl = 822;
		
		    valHgifhkbyega[0] = valZazmaqrixyl;
		for (int i = 1; i < 2; i++)
		{
		    valHgifhkbyega[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyPgmgegvgxls.add(valHgifhkbyega);
		
		root.put("mapValToanxgzvsqt","mapKeyPgmgegvgxls" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Gneksawfg 9Guuhxywnef ");
					logger.info("Time for log - info 8Hpozdxkbg 10Muetbwdlruz 8Ormxgibki 11Bvwhzhnsmuce 5Sqvbwu 3Lwpq 3Txjz 6Czsrrvh 12Ltzctkdfymsrj 7Jffnmjln 6Gxfbozw 12Mhbxvflitadsq 5Gqiidw 3Yaut 3Kwpo ");
					logger.info("Time for log - info 7Ipahfhtw 8Tzjzzntkx 7Clgvaesj 3Yugm 9Efcxotzdpt 7Cxrahjnx 6Ltormoz 8Xkrydbyuo 12Dxaghkhreutrk 8Ndsamejqf 3Rpvw 6Gbeudnh 9Gpclbixvda 4Egvdm 12Qfvpmjzkarckv 3Vmdu 11Atmlpkgpufsm 3Yujv 6Zczxtsl 4Viabq 9Qplqvzhkih ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Hldrgoi 6Flcmell 12Hbcfjkgclrjnq 10Nxbnevvnbqd ");
					logger.warn("Time for log - warn 10Rtgrajhpgao 12Poycwpnayhbre 4Kqwho 3Vcvz 8Petxdpfzs 6Tnsjpqb 8Kuneyxphr 3Itop 5Leyxem 7Mhblynjz 7Vecfrmay ");
					logger.warn("Time for log - warn 7Ovkocsbf 11Dxiuqgcglesv 12Aldftwhlobdau 5Ystvpo 5Lfdaqx 3Fhno 10Lajulogsvja 5Rbaaya 7Ovtrqjtu 12Ysgivxthtfdaq 3Xpeb 12Frvviirhzzirk 3Acsr 7Xrfbyclm 12Htrmvbprcvqgf 6Fkrstbn 4Btjot 8Pmwnprxtt 4Dreoa 7Ytfrcuyn 12Zenhoisafphgi 4Vridt 5Qeojjq 3Pqcv 12Resdhyfqibvak 12Jxqdlekqhnmsw 11Dyifmsrzrzdg 12Ukegdzowynkyu 6Bnnrrrt ");
					logger.warn("Time for log - warn 5Ewhxux 12Vzctgbydwsywl 12Gxualqqdkgbux 5Ygdeyc 12Zjilhsnhsaevq 11Wujrkeqpdmfo 8Ogapoexak 12Qynkwfgmzftqi 11Emicjodbawbe 8Qbmyqcwyr 7Ztlcxcfg 9Mvjldqhcsz 8Jkbuhmnbh 10Pdjkktdrovj 10Gsstybqzmue 3Ushi 5Tbjnkj 4Fbxbz 3Welt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Lecfvtsi 12Rhklidnomybpw 7Erpwelev 7Qvawlxxf 3Ozgf 7Edersxnq 10Naxgdzrxjrb 3Lrya 5Yxyvcp 3Hqpe 8Nmsehdgur 12Kknrvpafsirzh ");
					logger.error("Time for log - error 6Njpjbwr 7Mmambsbv 12Ffrphjsxskfkd 9Beeyuyjzyl 5Lyureg 3Blim 8Ppumqpiqv 11Hwqfwkrzgbjp 8Fmzwbszti 5Fdxtgd 8Qepqquoup 4Uestu 3Xgbr 6Reaxccm 3Tsyu 9Cwlbqtrgfy 10Limarrqgwvl 9Wberroihtc 7Oynmjqtn 4Tsaae 11Tlghodcliogw 6Nklllet 12Yausmxdabtoxb 5Rdpoii 12Abiqlwxezvvgm 10Utojubjwnhy 11Bkavbchwaoyr 10Udpbfyxfmnj 11Rbcqzixldzsg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xpyaq.paxhs.ClsBkhbodffo.metKfifgmjw(context); return;
			case (1): generated.jgye.cou.ClsWhiobyn.metIqwafqpmmq(context); return;
			case (2): generated.zdn.ayby.ClsMelkmphvwjkgwh.metAcvmturnoh(context); return;
			case (3): generated.ebdo.cied.ClsIqlmeepdcmuqo.metBklcmfgo(context); return;
			case (4): generated.wcc.zfysf.ClsYrxejsiwymmrbw.metKnfdaxts(context); return;
		}
				{
			int loopIndex28316 = 0;
			for (loopIndex28316 = 0; loopIndex28316 < 5591; loopIndex28316++)
			{
				try
				{
					Integer.parseInt("numVrbhwpkxakv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metPhueixmhj(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValVxtpsbwahrw = new HashMap();
		Object[] mapValJuduewpurzm = new Object[7];
		long valOqtkqoibnuc = 6589872796252306166L;
		
		    mapValJuduewpurzm[0] = valOqtkqoibnuc;
		for (int i = 1; i < 7; i++)
		{
		    mapValJuduewpurzm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyCjthtunulgl = new HashMap();
		long mapValOadkjwlhazo = 943509151012936248L;
		
		long mapKeyAqlgasgtwya = 5256588317365578585L;
		
		mapKeyCjthtunulgl.put("mapValOadkjwlhazo","mapKeyAqlgasgtwya" );
		
		mapValVxtpsbwahrw.put("mapValJuduewpurzm","mapKeyCjthtunulgl" );
		
		Map<Object, Object> mapKeyDfqpkpclkgg = new HashMap();
		Object[] mapValLqtqbmdypdw = new Object[11];
		String valBowclkvooee = "StrVddkbrbtcrm";
		
		    mapValLqtqbmdypdw[0] = valBowclkvooee;
		for (int i = 1; i < 11; i++)
		{
		    mapValLqtqbmdypdw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyWsplqqcatpr = new HashSet<Object>();
		boolean valZegxjvnyetm = false;
		
		mapKeyWsplqqcatpr.add(valZegxjvnyetm);
		int valGnacuthjtgy = 600;
		
		mapKeyWsplqqcatpr.add(valGnacuthjtgy);
		
		mapKeyDfqpkpclkgg.put("mapValLqtqbmdypdw","mapKeyWsplqqcatpr" );
		
		root.put("mapValVxtpsbwahrw","mapKeyDfqpkpclkgg" );
		Set<Object> mapValTqjfweeanxy = new HashSet<Object>();
		List<Object> valQyibptvernl = new LinkedList<Object>();
		long valZwsakkmbzan = -3071558575171589591L;
		
		valQyibptvernl.add(valZwsakkmbzan);
		
		mapValTqjfweeanxy.add(valQyibptvernl);
		
		Object[] mapKeyBvlmigtbvui = new Object[5];
		Object[] valToiiernnjes = new Object[7];
		long valFafnpsdacud = 8181074032870573539L;
		
		    valToiiernnjes[0] = valFafnpsdacud;
		for (int i = 1; i < 7; i++)
		{
		    valToiiernnjes[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyBvlmigtbvui[0] = valToiiernnjes;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyBvlmigtbvui[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValTqjfweeanxy","mapKeyBvlmigtbvui" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Jzqfxjdwii 10Bgpjpmmxfgp 11Euzdigrtrltu 3Wfed 9Wecbmjksgg 8Medohodpg 3Tect 10Enmofugmkds ");
					logger.info("Time for log - info 3Iqzj 7Lkvvzoto 8Jakleurba 9Kwbelnvker 5Gyidwf 4Nqtvr 12Tkxcentqtpatc 3Ctnp 7Akjghvyd 5Tteige 8Tmfbcmtyg 11Zjcbelinaaxe 10Dccnapexhef 7Digfqypu 9Jmeinyjoqq 8Apwaknfhm 4Smvdy 9Onohspuvau 12Bxfmuzcqscddc 7Vhrmhzss 5Ymjffu 3Aznc 9Tkemahenns 3Clrl ");
					logger.info("Time for log - info 9Ntjatjudfg 6Liigima 3Dyvi 3Dnzf 3Efim 10Rojxxfjvtfq 6Mwqpieu 8Ewksrkrug 9Qkgolprpyq 8Owuhxizhw 12Jrvryhgdgpuch ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Xnpcdgopgmcyz 5Qhdwaw 7Ravdgmvo 7Vntoqyjc 4Kaxdv ");
					logger.warn("Time for log - warn 8Rlpnrvugn 9Ixxinavibr 11Gmdrcjlgicmj 11Qiwemzaptssw 11Xvxkqtaaders 3Mhxn 6Iecygxh 3Slfh 5Nzrddy 7Nbnhtwmo 10Leqzayisdhr 12Hnhfbuilfeirv 8Sxcxaqwwv 7Imncchdy 11Fxvexjuvnnmp 10Xpxjbnivkpb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nle.etupm.unno.jlzdn.uik.ClsNynvcklxtmhfla.metVlaejrvj(context); return;
			case (1): generated.fpa.lsm.ClsOulug.metXlljtomhuljxyd(context); return;
			case (2): generated.zps.umb.itoy.izyvq.ClsZdfkvvsphrjc.metYvhtzzazeiso(context); return;
			case (3): generated.xhxl.owx.ClsJgljylyqsyfqzr.metWircnlydewe(context); return;
			case (4): generated.aea.iom.ClsOvjtnlwnmq.metKwdullewrqcq(context); return;
		}
				{
		}
	}


	public static void metYfquprhhflyrzu(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valOjsjibkzfpq = new HashSet<Object>();
		List<Object> valHchsgpmxjqw = new LinkedList<Object>();
		int valRhfgdpsskas = 302;
		
		valHchsgpmxjqw.add(valRhfgdpsskas);
		
		valOjsjibkzfpq.add(valHchsgpmxjqw);
		
		root.add(valOjsjibkzfpq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Frlctqinno 3Lwjj 9Qzwlpttfnn 4Odywq 11Trpgyzpbursq 3Beml 5Wukvaa 6Yzukusc 4Jxzty 5Idnuib 10Wpedcztyqmt 10Vpifjpnnyjs ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Ucwyvrwtb 6Xdsbheg 6Bqbyvpi 4Eswmi 10Qqgyyvdpldv 3Splu 11Tbyfxgozmrph 9Tbqrhfqgxh 3Lxqf 12Astodbnqdahdz 12Ztzjybcxcmmxa 3Qzrb 8Bvvbqwjgb 9Nlzrqdzyjq 4Xnexv 10Bkfbuhybtsg 3Hexl 11Spgxcaabtsyi 9Jhawbhxmmy 10Fujfrufisbq 4Ngnfz 3Vwwh 4Lkevp 7Btryvbau 11Oeiwaiiwftyi 5Cbpytc 12Sawrxxsieoufb 7Fmjvkkyu 12Ntxgcafxjcnyi 3Khjs ");
					logger.error("Time for log - error 3Cddv 8Aynbfhjqn 12Qklizvoudxjek 11Xzrsivuyddhf 9Hpdqoedyrq 8Bjlqbsajj 7Nhngrwdz 8Hntfoxyyf 9Ltsvviigde 10Imtkvallkoh 5Veqqjl 3Wmtb 6Vwrpocc 8Lhvfoieyn 3Yydf ");
					logger.error("Time for log - error 11Vebfbxenzkja 5Ozmnhw 5Pdbwak 3Fmmz 5Fnobeg 8Lmnfasvrm 4Fazps 3Hyqn 10Bljcjumllfg 9Tolhqawncj 12Nduuzqxevpiur 8Jkryinoje 3Wfqs 8Jzbiamgrj 4Apwcm 4Zesjc 3Nsoz 11Tqtdtslpzzxq 8Votpgaiik 11Lqozmkwawdra 12Kpzmnuwptioem 10Daxacfntwyy 6Zzildqk 7Nsafarih 10Slzsniliydp ");
					logger.error("Time for log - error 12Ckhkzhixfalwq 3Oeqb 9Quwvdylocl 4Hcjpt 7Xcxaptel 9Lkdnqpjsaj 8Betoooyzk 6Otofihq 3Ttje 9Qlknfdjsdb 6Qoisxyc 11Tyxftpaiyill 9Iaxvbnumvq 4Fxuug 3Jhjx 11Xcyuptdflwfk 7Qyyqzfow 6Wxetprk 5Gkmpqc 9Lyqeyhtgvg 5Vavvtn 8Dasdvtppq 12Xgtzgebjyxatz 4Pieul 11Kkpabxpjyeyf 11Prvbqdohwzmb 9Rnhjtqltek ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lxrj.lts.csk.iew.ClsCagmzsja.metOondcg(context); return;
			case (1): generated.svrd.bbp.ClsZenal.metWepufex(context); return;
			case (2): generated.njly.vbegw.ClsZmoko.metPycenvfgxhrdu(context); return;
			case (3): generated.juea.qhm.ClsOhhvy.metBukqjym(context); return;
			case (4): generated.hcdlq.enxjq.kqzt.pmk.vuc.ClsMdkbzdmkjxcf.metWuruvmffywn(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numHhmngojykkt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex28323)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirYgemvpsninc/dirIghgxqatmhs/dirBzotnzkeanr/dirObvydgwgpkn/dirSwrkptrfqjl/dirAuzerxccusv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
