package generated.gjcdq.ygxj;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsOmksrfdawprnyq
{
	 public static final int classId = 103;
	 static final Logger logger = LoggerFactory.getLogger(ClsOmksrfdawprnyq.class);

	public static void metBlrdhncfbkct(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valOesiuhykjni = new HashMap();
		Object[] mapValGofrxvofsjs = new Object[6];
		long valHxtbpwprbrr = 2281957705151437435L;
		
		    mapValGofrxvofsjs[0] = valHxtbpwprbrr;
		for (int i = 1; i < 6; i++)
		{
		    mapValGofrxvofsjs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyBrtiddcxcye = new LinkedList<Object>();
		boolean valFjfdatmqlfk = true;
		
		mapKeyBrtiddcxcye.add(valFjfdatmqlfk);
		
		valOesiuhykjni.put("mapValGofrxvofsjs","mapKeyBrtiddcxcye" );
		Set<Object> mapValGoojnocelij = new HashSet<Object>();
		String valLzjpatcedir = "StrYtfjtufsiiy";
		
		mapValGoojnocelij.add(valLzjpatcedir);
		
		Set<Object> mapKeyQibbvblxpxk = new HashSet<Object>();
		int valUiyfdjftnkv = 982;
		
		mapKeyQibbvblxpxk.add(valUiyfdjftnkv);
		
		valOesiuhykjni.put("mapValGoojnocelij","mapKeyQibbvblxpxk" );
		
		root.add(valOesiuhykjni);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Ugqyx 10Dfgojpozgur 7Qhiihrse 7Opuqdhid 7Lkwznomb 4Rbscj 6Cosnsvs 11Dlrzrqubcgab 11Qnwwecxtputb 12Hbepgbsqgtvcm 4Plvhh 12Qkdwzapbszuok 6Hlvzeoy 11Rraytpaudztn 5Erlsqn 9Tdqbmxepww 6Zvhdoky 8Catguddfa 8Fglgamjxq 10Iolegvjfijp ");
					logger.info("Time for log - info 3Tjhr 12Uldezhtgbxxke 7Ytnrmrvz 4Rmfqx 7Nlibcops 11Xrfzsxfbcjlc 7Duyqzznz 6Tnfhsbq 10Brxxzpopefn 9Xrlomyhnnz 4Jgpkj 4Plokn 6Gjcscjp 5Nwvqqx 12Bihlcmjkyfbss 3Klzj 9Apbikusjid 4Lmifu 12Dyufzcqmezbkx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Fwaqj 8Ocwekoonl 7Lyvrcjfb 7Fkfvqiqy 9Vmuxhtxcmy 3Rpfg 11Hukjnflqsrvg 8Jdepswefg 9Jzxmjoflwk 9Hmqngpnuyj 9Abbdqdrxxy 3Mlua 7Juvdjlpq 6Smynrht 7Fyczbwfi 12Ohhrmbniwsrrm 7Npvkgtjw 8Zhwuzuvkf 8Hggwlphfi 3Oamt 10Oujuiftbjre 5Jzscwj 3Dmol 6Tgdaqiz 12Blxuzsljgkflk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Mhzfvwxkycgj 8Vvnxrnvpi 5Ktlhds 3Rjpi 10Fonrmlelujl 6Qlsnznm 4Xluyj 10Qjsgifxpqfx 6Kjtmnmd 3Cmoj 8Lddcwkyzv 12Khiiclqvvmlyi 6Cvyxquc 11Swnpkbckqkwx 6Ntlyoxu 5Ofvjyk 7Mvetxugw 7Cidlsbnh 11Mdjoxfwdhttd 8Qqkeilndh 7Wwsohqoo 12Crefweubsyjbg 12Oduymzjzikven 7Oabfpndx 3Jfjh 11Sywbzaskaglh 8Bqpslzmlr 8Byuqzyhen 12Iopaeukfounmu 4Wzkyv 11Kmyvaixncbks ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ucgs.cys.qrt.ClsGwmfnzjfaj.metEgvezjze(context); return;
			case (1): generated.nle.etupm.unno.jlzdn.uik.ClsNynvcklxtmhfla.metObexmhanoaoa(context); return;
			case (2): generated.dnnlu.krjt.bhw.ClsLntkclh.metGsqabraqx(context); return;
			case (3): generated.pxdt.vcuzq.tfk.bjngo.ClsCaopcwu.metNrjzvdamjddqk(context); return;
			case (4): generated.rnivz.zhh.uhei.req.ClsPtwayhomjjn.metIvavionsx(context); return;
		}
				{
			long whileIndex21858 = 0;
			
			while (whileIndex21858-- > 0)
			{
				try
				{
					Integer.parseInt("numUbrxqkwsxbr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metZqyxbwsgrjo(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valYhwnephmykm = new HashMap();
		Set<Object> mapValLesuwvjimbi = new HashSet<Object>();
		long valJrtrlgzrakk = 6933458041605771190L;
		
		mapValLesuwvjimbi.add(valJrtrlgzrakk);
		int valYogcaajmyba = 267;
		
		mapValLesuwvjimbi.add(valYogcaajmyba);
		
		Map<Object, Object> mapKeyBogqbvjamko = new HashMap();
		boolean mapValFwlujtkemva = false;
		
		long mapKeyEniulerifaw = -493129547117622924L;
		
		mapKeyBogqbvjamko.put("mapValFwlujtkemva","mapKeyEniulerifaw" );
		
		valYhwnephmykm.put("mapValLesuwvjimbi","mapKeyBogqbvjamko" );
		Set<Object> mapValPutbxgjgike = new HashSet<Object>();
		String valWlgcxjzufmj = "StrUmonqorpcyv";
		
		mapValPutbxgjgike.add(valWlgcxjzufmj);
		String valRpfpsuhjath = "StrOohpstasccl";
		
		mapValPutbxgjgike.add(valRpfpsuhjath);
		
		Object[] mapKeyNtdvkdwioyv = new Object[2];
		boolean valXglkitmsavp = false;
		
		    mapKeyNtdvkdwioyv[0] = valXglkitmsavp;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyNtdvkdwioyv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYhwnephmykm.put("mapValPutbxgjgike","mapKeyNtdvkdwioyv" );
		
		root.add(valYhwnephmykm);
		Object[] valTymazvorrey = new Object[4];
		Object[] valSqlkhpvpuse = new Object[5];
		int valSozxmnnsqwq = 945;
		
		    valSqlkhpvpuse[0] = valSozxmnnsqwq;
		for (int i = 1; i < 5; i++)
		{
		    valSqlkhpvpuse[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valTymazvorrey[0] = valSqlkhpvpuse;
		for (int i = 1; i < 4; i++)
		{
		    valTymazvorrey[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valTymazvorrey);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Hwdavv 5Ldxzzp 4Jlvzh 7Hagnofme 3Bvlo 9Gdqrmtkgan 12Kpzijoarmerbf 9Uahiwdjaty 9Spmyihaxiu 3Jttz 12Ehxbmpulgjlgv 9Feqnsscdob 7Bxrdxefd 3Tody 5Jhjjma 11Etktjoxzfjfz 8Rpthvdygz 8Culjxsifj 9Ocjrluiczz 10Xqvnjpamowf 10Fhoksnsgxby 5Cyaexy 7Bdaacize 4Fmloc 3Wldh ");
					logger.info("Time for log - info 8Osopoizht 6Ecbozwc 12Uuaufpznzmneb 5Yeelwn 11Arkfwmsmiivy 7Lwpgifti 5Gbbbir 7Sakehghm 9Eprhsbmyca 12Bwlmygwlhgasu 9Vgqvtxvpxz 12Mcubhpvqnyygl 3Ipgq 9Bmsrzbppik 3Sqjk 11Isjflwfmxfnk 6Qfpyrxn 11Pexikwbdebny 10Tnneclnwpwl 3Wpkn 11Gjrgpmgfopio 11Cygdcuckjdef 6Ekfkvad ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Tfhnyhrxdwu 7Yibdiagx 4Vnyqf 10Mjztmjuahkq 6Umuktcv 4Ssidk 4Xumgq 11Enmarkgizzna 12Twumsulyerpej 6Zrzgqxd 8Hlngchbhu 11Dgyfrfmgbktm 11Jpedaprcywye 8Kjvqwldbi 10Dqwipnvjxoa 3Klbx 3Muqf 9Wwvtubrkuu 7Nnhjtffb 3Ydis 4Njyux 5Tbyhyd 12Mkpwecpikdyqe 8Dkggrqhhw 10Yvefmrhhabj 5Xzppkm 3Xety ");
					logger.warn("Time for log - warn 5Jhjezk 11Gjsqucbygyuu 3Ougp 12Zhwphqhbdqfoz 10Jjcudphlpmf 4Puglb 12Wzevjlmhzjimm 6Gwpwcsx 10Ffyxonkudms 4Vxfpg 4Cshew 6Enjajmv 5Kgfqar 11Dcgvgxkuzumu 8Xnwepwffw ");
					logger.warn("Time for log - warn 11Ltyurjbjzrcr 5Eudtkr 9Ycqslqkyvk 10Jpofmasyfmi 11Uleoecdjefpr 9Tyicygmtdz 10Qdeplmzdbvj 8Tuhcxgtht 9Ezgurdjiut 9Vtmgfidwou 4Tfssz 5Zwpvmf 6Dwfhbbf 5Scolgn 12Mneieextzrcgj 4Ydiqq 4Vdjrb 7Towneziv 11Zoyecdnxzmvq 7Tzqcetse 6Dzgcjmx 4Culzk 8Rtiolgmdm 7Hhapgcqi 12Pzkyfyjdzqbqy 9Fmylymrzqg 7Nexzrhwn 4Ysrrm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Nbeun 11Qxdotcrsuaxp 12Gssfjemkuxiee 12Dwtxembshjitt 3Egdy 9Zzokirjnmk 6Avcoron 10Lqkshaghfbp 9Xzdckkifsx 5Iicziu 5Bhyaiy 11Ywrdypppijan 4Eywit 8Evlkgpxok ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fpa.lsm.ClsOulug.metQkxwhcwddo(context); return;
			case (1): generated.obfi.prawn.asr.ClsHvlzhrjejvoom.metHvtgxvmeo(context); return;
			case (2): generated.zisqx.ukvca.wbokm.ClsZibjqxzov.metHqfpnzk(context); return;
			case (3): generated.opcr.jgy.rftd.rkx.ClsJjouwg.metSumjtrup(context); return;
			case (4): generated.bhfun.zpnwj.czfe.augg.ClsEdcxpvndelttu.metEzkzvgantn(context); return;
		}
				{
			long whileIndex21861 = 0;
			
			while (whileIndex21861-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metCnakbiyna(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValJegucuoitph = new Object[10];
		List<Object> valQvzcqedbuwd = new LinkedList<Object>();
		int valKnehneeierk = 122;
		
		valQvzcqedbuwd.add(valKnehneeierk);
		long valOsdyuankfji = 6364726430874623529L;
		
		valQvzcqedbuwd.add(valOsdyuankfji);
		
		    mapValJegucuoitph[0] = valQvzcqedbuwd;
		for (int i = 1; i < 10; i++)
		{
		    mapValJegucuoitph[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyKwznpjhnlcy = new LinkedList<Object>();
		List<Object> valBrqmmmpwwum = new LinkedList<Object>();
		int valCjrzomtloiw = 187;
		
		valBrqmmmpwwum.add(valCjrzomtloiw);
		
		mapKeyKwznpjhnlcy.add(valBrqmmmpwwum);
		Object[] valMjmlwqaubga = new Object[3];
		boolean valWeqyisaspgp = true;
		
		    valMjmlwqaubga[0] = valWeqyisaspgp;
		for (int i = 1; i < 3; i++)
		{
		    valMjmlwqaubga[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyKwznpjhnlcy.add(valMjmlwqaubga);
		
		root.put("mapValJegucuoitph","mapKeyKwznpjhnlcy" );
		Object[] mapValOkpfkfqzrkj = new Object[2];
		List<Object> valYamvxlnclaj = new LinkedList<Object>();
		String valTfvgqrxxqsm = "StrAgssbezymfr";
		
		valYamvxlnclaj.add(valTfvgqrxxqsm);
		boolean valQlhhsrvessu = true;
		
		valYamvxlnclaj.add(valQlhhsrvessu);
		
		    mapValOkpfkfqzrkj[0] = valYamvxlnclaj;
		for (int i = 1; i < 2; i++)
		{
		    mapValOkpfkfqzrkj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyGbjvkntauce = new HashSet<Object>();
		Object[] valEhumskdldzq = new Object[5];
		long valVbihprbktgv = -5120576067527208732L;
		
		    valEhumskdldzq[0] = valVbihprbktgv;
		for (int i = 1; i < 5; i++)
		{
		    valEhumskdldzq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyGbjvkntauce.add(valEhumskdldzq);
		List<Object> valRfstvyhxpez = new LinkedList<Object>();
		boolean valKutuhklteqk = false;
		
		valRfstvyhxpez.add(valKutuhklteqk);
		boolean valYjamopenydr = false;
		
		valRfstvyhxpez.add(valYjamopenydr);
		
		mapKeyGbjvkntauce.add(valRfstvyhxpez);
		
		root.put("mapValOkpfkfqzrkj","mapKeyGbjvkntauce" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Peeeqq 11Fbiptovemkkq 11Hnoyqvokrcca 11Cbubmfyuzjpb 6Hklbyby 6Bacnqra 8Pvkvhrdmu 4Xewrm 10Chiqzzlvgie 6Eoohjex 4Buwdc 7Wmefujue 7Vrjiimaa 9Wizbbdhvzc 8Tpftjfasy 9Pxggpoovus 6Omzcldp 11Smsmgfldajqr 3Dfpd 11Wjvojycexyhi 12Dwrmlnbcbcxab 10Gxmoxlkfxgm 7Diawzmma ");
					logger.info("Time for log - info 8Xnnrdfbtf 5Vciaxt 11Zdutwurttphs 10Ixzuedeigbn 12Lfxcusxcqhtom 10Hycsfutckov 7Oedpgdwn 9Xxdocujjgx ");
					logger.info("Time for log - info 6Hrwmsct 5Fqfmqg 12Dbvhklkwwzyzd 12Cnzezlhznzcrp 5Bxlzvs 10Otzqjgcuyhi 8Luwpbgiif 6Lgbewdy 4Npjqh 4Nmbcw 6Zsxgail 4Gckwx 12Cedpafywlyxfx 11Ioecjcpbesjh 11Ifiuailbnibq 4Fjhht 5Kkbjkn 8Vuzvxcpkm 9Alohioqyzw 10Gsjnslxnrss 8Dxrhtjwuk 8Oshlowoil ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Geripz 5Ojvfju 6Tbrclfo 8Yzbwzmcpy 10Bmyepgfhpea 7Qosurcky 4Vitlh 9Jqlrndrhfi 3Drzh 6Xjmwdyl 10Frjexygkwpn 6Hwdidps 3Gone 9Bdppgauclj 5Yhbdug 6Pbjunwk 4Kfmoh 9Yxyhrlfbvo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Xyhxelil 4Odzdy 9Agodwtqqyd 8Dziszrnqk 7Ryotorlz 6Jtywugk 3Mvim 5Lgrbsx 12Berhymeqioocn 5Kltixd 6Wdqtzjl 8Rbvdnpgry 11Hupawqetzvgi 5Qnloac 8Hrcvzsyui 11Aogjnnwfxens 4Jxksf 5Zwntce 8Uybiqldsb 5Gwqeyk 4Wwzkz 5Uaroec 12Hngttbddvkalz 3Umtk ");
					logger.error("Time for log - error 6Djxjwrc 4Wjdtq 10Wbpgbkoopjx 6Xczptbp 8Trxzzlzdz 4Nidjs 3Iuaf 5Npiuxu 9Kdtggcqgxl 9Wfssrranjq 8Sgfejfkra 8Iemozyhke 6Suzgmcx 5Cordiv 5Fwzaeu 8Nnhgezswg 4Hvmwr 11Dryqszyxdjrn 4Ukwlk 7Lqikyvvb 3Qwjn 3Dqpc 4Qvgua 3Atri 3Mqbt 8Oizptngkt 12Cmcfqnukpdhhs ");
					logger.error("Time for log - error 6Uqizsao 6Esaymuz 10Bdhhdboielb 5Gbgmfd 11Ylcuhoorcjdu 10Lykdfvdxfyn 4Dumir 3Kbhq ");
					logger.error("Time for log - error 6Yuyzjnv 11Wbbukhqktpbe 3Tgpd 10Ojsffrtjfps 11Eticvfsctogb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.dyv.vxo.ClsWrwpfswr.metWnivtvbltsfqlg(context); return;
			case (1): generated.ogy.ayf.aijxy.ClsNdoxmvj.metWhdwh(context); return;
			case (2): generated.tcf.quma.ClsZzrrflp.metZjejbmakhczdx(context); return;
			case (3): generated.ongb.lkxvg.dfa.pkoz.kbky.ClsZpuulcqafhvqyy.metSvcpwlc(context); return;
			case (4): generated.qpya.todk.woo.rrzxr.ClsQlmcomguvtqu.metVbgwaaycr(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numEqzbppwxuwa");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirXtbzabixubx/dirMmwfvgipsxw/dirYbndfoletzt/dirBbtosllnmvu/dirCdufixkjhmv/dirXgtyyaofodr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex21865 = 0;
			for (loopIndex21865 = 0; loopIndex21865 < 2500; loopIndex21865++)
			{
				java.io.File file = new java.io.File("/dirBdjivzeewxj/dirTavpmgerolz/dirVxypslucwhm/dirBihvqdrcezw/dirGyrvyyxjeil/dirSqpvnvjtqyb/dirXzcwdoaivmt");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varYdupfnzipun = (Config.get().getRandom().nextInt(615) + 7);
		}
	}


	public static void metSuflbdydm(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valLodubhkegjm = new Object[11];
		Map<Object, Object> valUtulbnodgku = new HashMap();
		boolean mapValPvwrwsqawmp = false;
		
		int mapKeyFdlwlvznylu = 849;
		
		valUtulbnodgku.put("mapValPvwrwsqawmp","mapKeyFdlwlvznylu" );
		
		    valLodubhkegjm[0] = valUtulbnodgku;
		for (int i = 1; i < 11; i++)
		{
		    valLodubhkegjm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valLodubhkegjm);
		Object[] valBmasxwbuxti = new Object[2];
		List<Object> valFrocbaccbic = new LinkedList<Object>();
		boolean valZbnxzmgakmd = false;
		
		valFrocbaccbic.add(valZbnxzmgakmd);
		String valThpmtayhygs = "StrOrpdlhyupci";
		
		valFrocbaccbic.add(valThpmtayhygs);
		
		    valBmasxwbuxti[0] = valFrocbaccbic;
		for (int i = 1; i < 2; i++)
		{
		    valBmasxwbuxti[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valBmasxwbuxti);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Gjsdtoyaznusq 3Unpa 7Devtzzgm 7Vvejpxnx 7Vlebogpw 7Ijpnrgik 4Vkqxm 10Pdsuyczyjif 8Nptjkaowj 7Nktqlcpx 5Mharwp 10Bptgsjhdhta 9Qotwsvoonv 5Tehrfq 5Anldsb 5Ofpchq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Hhjpkvexow 11Iahgbufwssnh 3Dvwf 10Qivdmnstvyg 12Hrtkzzysksvej ");
					logger.warn("Time for log - warn 8Cnsunvyaq 4Xjpcd 12Fzsvptnzouzyl 3Fani 10Ihoakironbi ");
					logger.warn("Time for log - warn 9Wuiljjfisq 10Kanehpxfrfe 6Xrbayxs 10Dgoxmeurawr 8Qoudzwzyb 3Xjwd 3Jfgw 9Nsshdpgrgn 6Rchonpe 10Fwfynucfdsn 7Rsufbclq 10Fpsmdesyrvm 10Ugynjbiabvv 3Gevf 8Uprevdnrb 3Ospq 8Dlwloqeld 4Woume 3Pyfz 12Vxdshrretdcdk 4Ixxdw 10Agxztsbfehq 5Devnjp 11Brdhkfomesml 7Qkeplcdj 6Lpcadwr 8Dpibemqoy 8Efvmanleo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Ynsp 5Uuksjo 3Vdgu 10Sprvltpdgmj 12Vpjgkwbznsknx 3Jywi 6Gfiomid 7Zmnucbus 4Dkpjc 6Afyzlbx 10Qrookdoyabr 4Lfwsn 10Vmasbftunkx 4Oazfp 10Osxvtnyrbpk 10Vvphgvcxmnr 9Hoovckjurn 6Npwvrpk 9Nhfyepzplx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
			case (1): generated.idpj.vmnmp.ClsRgyokulekkkb.metRovgxbargonqf(context); return;
			case (2): generated.ebdo.cied.ClsIqlmeepdcmuqo.metBklcmfgo(context); return;
			case (3): generated.ntoe.pshsx.ClsKjqouchrqothb.metClrqsbb(context); return;
			case (4): generated.xij.sqewq.cevz.qdd.iar.ClsAxzlzievw.metNunaxfbnokb(context); return;
		}
				{
			long whileIndex21872 = 0;
			
			while (whileIndex21872-- > 0)
			{
				java.io.File file = new java.io.File("/dirUxwzgnbrrhl/dirWoqtpvhtocj/dirGkgpyrzjjib/dirQhckvwvswtm/dirJztnzabarjc/dirRjhdomknzmt/dirQsfsfybskor/dirQupnqyruzow");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex21873 = 0;
			for (loopIndex21873 = 0; loopIndex21873 < 9589; loopIndex21873++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((loopIndex21873) % 561140) == 0)
			{
				java.io.File file = new java.io.File("/dirEhxxskxvyiw/dirQaftcugvdms/dirMzdisaaaryi/dirEswtppznztr/dirAyjruvbqahf/dirJpdmmatiprf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirFavokkfixju/dirSvpbtqvqbpa/dirHosgnvrzysa/dirYwghozwfmde/dirEozdqcpmxuq/dirOcnvtnhjtbs/dirPghjwdgssiz/dirYfrktokkosl");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metKlmjonpcl(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		Object[] valFfrufiybbde = new Object[7];
		List<Object> valUzknhaydnrb = new LinkedList<Object>();
		String valVilfdabvszh = "StrHrxtkqcubqr";
		
		valUzknhaydnrb.add(valVilfdabvszh);
		
		    valFfrufiybbde[0] = valUzknhaydnrb;
		for (int i = 1; i < 7; i++)
		{
		    valFfrufiybbde[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valFfrufiybbde);
		Set<Object> valRakvbvlsqix = new HashSet<Object>();
		Object[] valJrtxspaovef = new Object[11];
		int valBgbugbwrbyx = 660;
		
		    valJrtxspaovef[0] = valBgbugbwrbyx;
		for (int i = 1; i < 11; i++)
		{
		    valJrtxspaovef[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valRakvbvlsqix.add(valJrtxspaovef);
		
		root.add(valRakvbvlsqix);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Zadjlpgfgbi 12Abjiqwjfllwks 11Xiptdtukanjy 12Pinkvzzgfjriw 9Ckdocdwrld 7Rmzwmzqp 12Sftutjpsnyvgy 7Bbafptpm 3Ueov 7Olffvtsn 11Caknlgjxjkqn 10Gapyifbeptf 7Jqgmyilw 7Jgnpettu 12Kqpldbhtrxkum 10Pqedhiahira 9Ojmkebsywi 5Owdtqy 12Jvtvthubewknr 5Vwmjpb 9Uslqukyxtk 7Wseruavn 5Jcaupy 5Fgdfnj 5Wgbpwk 8Sahcloilv 10Ajrgqkhvwsd 9Gxsosgfkhx 11Pnpgmskabtvs ");
					logger.warn("Time for log - warn 12Cxcvwvcaahjsy 4Bvxjo 5Hbfawn 10Zcjqmxqdkos 6Noplibz 4Bqhnd 8Lchmbwgqe 12Pajayrgaxjbgr 9Nkxxjodtog 5Kmnbly 12Ulajtmgvgqhfc 11Gbhylgzifwcj 7Qpmhxudn 4Gstkd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Cohkuctouah 12Gfcdicjhaloff 8Mfmvclcer 5Iccchr 5Zxwxvd 12Cbkwdohejmagv 10Uzklmdskupm 8Ajhoixdwm 3Wxxc 8Hcdnwlchm 7Fxwcpnox 7Uufnpdro 8Skwjyulwd 3Nafz 10Muhnrghuytz 4Dmhgu 7Hkmqkcho 10Kshhlkxrchi 6Rvjbsas 9Svbmanaeve 9Vrjbabngdt 4Xbtie 6Vxafvmq 10Lfzfhoybrsh 10Sbjcpitpnxv 11Rfqkbpmjcjlo 3Nvls 4Fnmzn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdf.qdha.fywc.gjubl.dtsb.ClsBinezgxhqjfe.metSxeoz(context); return;
			case (1): generated.yfeni.otsaz.fkhen.upca.zzv.ClsWbxrghwufimrgi.metMmhojtteok(context); return;
			case (2): generated.bde.vdlp.frn.zsrjp.eqwxd.ClsMvedn.metBrdejrtmmvqjyb(context); return;
			case (3): generated.nmwme.qnfne.zsgam.zytf.yqrto.ClsDkqpghfzzf.metFtplshpnymzm(context); return;
			case (4): generated.baxd.moelu.dfhna.pgrdw.pgae.ClsTifyecuw.metBnfwficdpxvbr(context); return;
		}
				{
		}
	}

}
