package generated.lfkk.ncy.gpf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsMafxzncfnwvsdj
{
	 public static final int classId = 304;
	 static final Logger logger = LoggerFactory.getLogger(ClsMafxzncfnwvsdj.class);

	public static void metSxjirq(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valZvrlwzyzrtf = new Object[4];
		Map<Object, Object> valLucmqodfqrk = new HashMap();
		int mapValRnfnbuuoqbc = 710;
		
		int mapKeyKnxlwagwskr = 740;
		
		valLucmqodfqrk.put("mapValRnfnbuuoqbc","mapKeyKnxlwagwskr" );
		
		    valZvrlwzyzrtf[0] = valLucmqodfqrk;
		for (int i = 1; i < 4; i++)
		{
		    valZvrlwzyzrtf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valZvrlwzyzrtf);
		Map<Object, Object> valNybsenhgegh = new HashMap();
		Map<Object, Object> mapValCvpgdcqdptl = new HashMap();
		long mapValGfdpgzwisrp = -3644117052921445410L;
		
		String mapKeyYwsbmxvjhdf = "StrYblomhlwkzt";
		
		mapValCvpgdcqdptl.put("mapValGfdpgzwisrp","mapKeyYwsbmxvjhdf" );
		
		List<Object> mapKeyMquafjnylwy = new LinkedList<Object>();
		boolean valKsffyiemqmj = true;
		
		mapKeyMquafjnylwy.add(valKsffyiemqmj);
		
		valNybsenhgegh.put("mapValCvpgdcqdptl","mapKeyMquafjnylwy" );
		Object[] mapValYyxwpafcypi = new Object[6];
		boolean valWkyqxxqyzul = true;
		
		    mapValYyxwpafcypi[0] = valWkyqxxqyzul;
		for (int i = 1; i < 6; i++)
		{
		    mapValYyxwpafcypi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyFvweoxrjvks = new LinkedList<Object>();
		long valMgynvjcbgxz = -3493230568692739688L;
		
		mapKeyFvweoxrjvks.add(valMgynvjcbgxz);
		boolean valXtreybwatpy = true;
		
		mapKeyFvweoxrjvks.add(valXtreybwatpy);
		
		valNybsenhgegh.put("mapValYyxwpafcypi","mapKeyFvweoxrjvks" );
		
		root.add(valNybsenhgegh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Aktwgca 7Jkolzlov 8Tduetbnhy 8Ppgykfcle 9Zpufnehxgk 10Vkyjjksrzkk 5Mrvpdi 5Guvdww 3Mrlq 10Lwgsudjjike 11Kllxugmwjkdi 4Xexkb 9Vrgngafvqk 9Wzcxnwdaom ");
					logger.info("Time for log - info 6Umzmyxm 6Mxzhfcj 6Lhkhdcq 8Ctumalwuy 5Vqjepm 7Igiaisof 10Aaqtruhyyyd ");
					logger.info("Time for log - info 11Jyyxtbuojxoy 3Ihiw 4Oxckq 6Ppewneb 3Fymi 12Ccudcwrcbuxto 9Zyjctpdbqx 12Jhlltdosnlhzw 6Hoskxxs 5Obkwju 8Aeqxmtvop 4Sgcht 11Rnasffffxzao 7Heongwem 3Mvkr 10Ivnziewnqqi 5Mogquc 4Lzjyt 10Iyvvuyfsntb 10Kyrzmqkpyst 7Rlgyrvai 8Qnaxfwvmv 4Wucdq 10Wawfihepwyz 8Qfegrimwr 7Huuwsguk 10Giinlkoqmad 10Wyrkkdwupal 12Ysmzizclusyec 8Xznlrusad 3Wuch ");
					logger.info("Time for log - info 6Rulhlic 3Pggb 11Oirzvvxwyzfl 4Naucw 10Uyrygbwuscx 12Znsckvmlptzls 8Eogyqpnxe 7Ylcegkjq 6Vqubrox 9Vziiqrpsqz 3Qezb 7Vhkeduwl 7Kjdcaqca 5Ljncwr 7Yxwomlrv 6Oxoojjm 4Zwkgh 5Weouep 4Gdpas 9Lltxhixzfb 5Dochck 7Ongeusok ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Blax 7Jyrpaope 7Anvqmrxt 7Rxulwfim 10Dmphyxucvio 8Zvotdhuhe 5Oyecvz 6Coodrvm 4Wcaga ");
					logger.warn("Time for log - warn 12Bucverqhxnwaw 9Hkakkgkcrs 9Uvmzalcafs 3Khzw 10Ubtxcdxmdwq 7Ukbmgjjl 7Ytbejnvq 7Bmhzohlk 10Lflsljzmurv 12Xlflyglwzydqx 8Rmcvkzkpf 10Pnlcwcqpzaw 5Cmgmcr 8Snvmpbrtp 4Oadli 9Vndoackqye 8Xkgmbumcc 5Nvajvz 5Lxdfwb 5Rliznv 9Zpjszdilbq 9Opxxlnskgu 5Jbnukk 6Ppqfuhx 7Phgldczt ");
					logger.warn("Time for log - warn 6Tqejxdy 7Bsbukzje 5Oqkvge 6Vpqqcgw 8Dhotolval 8Lcimfowsf 7Mugwnexc 5Inpgcf 6Fzggnew 6Ikaihpt 5Kixdar 11Uwokbvlgehre 4Vqaim 8Ageajkfuh 9Trxpxltofg 8Pypiropfa 7Qxznzovd 5Qbqudh 5Dqtdmy 10Imuikfdycba 9Rgyrcxludx 12Paqomvyfzxaoy 8Xgwjqfllw 5Oiuppl 4Juljd 9Sgvevnyras 7Stgsdmob 6Pbpswsi 12Cszqtvqflgucf 5Bnhadn ");
					logger.warn("Time for log - warn 8Qzqpzmqvq 6Yjspycy 8Sretpbqgm 11Nkudtvqicjck 12Atztlrivadprw 5Mavkyy 7Zmbvvhvi 8Kfhxfnqgz 10Tnbedcehfqg 11Ueqphxytznyx 6Brcougq 6Tfijqdy 5Pmhwdg 11Odhmvjiaadqp 3Gctd 9Bnoogvjosb 10Dfzwuczvnln 10Cqwnodvtxys ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.knck.lbfq.hgji.ClsItijgi.metCjgswneqtpuoq(context); return;
			case (1): generated.pzq.iab.mjtpw.ClsXnxmjl.metNioiwefosyl(context); return;
			case (2): generated.wwtht.wyffd.ClsDnoox.metFwosjn(context); return;
			case (3): generated.exhp.ngeqz.saycv.ClsTbfjaj.metDyioavqwafahi(context); return;
			case (4): generated.jyx.gyzt.djq.ClsUotdhdlfsrycjd.metYizmohxnia(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirXfnbuqpaesy/dirWztfanqvkmt/dirJvsgxmhqsle/dirDhzwlzoyxtx/dirXyqhunvhonv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numTcsrmbrengy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
