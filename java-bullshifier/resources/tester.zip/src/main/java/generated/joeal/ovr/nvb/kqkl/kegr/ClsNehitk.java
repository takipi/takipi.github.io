package generated.joeal.ovr.nvb.kqkl.kegr;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsNehitk
{
	 public static final int classId = 264;
	 static final Logger logger = LoggerFactory.getLogger(ClsNehitk.class);

	public static void metFbsmcfuayzyy(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[7];
		Object[] valKuxuclaorsp = new Object[11];
		Map<Object, Object> valUzytdezmxrt = new HashMap();
		boolean mapValHzofneajnuk = true;
		
		String mapKeyMojpdmsjbor = "StrErprrkriccu";
		
		valUzytdezmxrt.put("mapValHzofneajnuk","mapKeyMojpdmsjbor" );
		
		    valKuxuclaorsp[0] = valUzytdezmxrt;
		for (int i = 1; i < 11; i++)
		{
		    valKuxuclaorsp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valKuxuclaorsp;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Agbeyxngzrekw 5Jcaajr 6Sfygfpx 3Uijs 11Ebzhrvvctrcp 9Tzvfbiutql 9Qwpjmdlpsc 8Vmhhcvxrm 9Nlrhoohzym 4Nxivk 8Xxumxaixn 9Vxirugphjf 4Huczc ");
					logger.info("Time for log - info 8Jpvgjyqju 11Viuykguravft 12Lelqczvqdzuti 7Yeosqxqm 5Jngeet 12Fhdvkbjzyvvmm 5Czwdvf ");
					logger.info("Time for log - info 12Dgpcjoypdtoan 7Iasvhvxh 11Qvsiusbsfzhs 9Nqesijzbln 12Lyithqgzsfdgh 6Iblipbr 11Tshkzskkwbxn 8Ypwnrneyi 10Senqnkkjeio 11Nnsnqbaaxmax 3Jwrt 4Ubtik 5Ygzffk 5Imuyfk 8Yoxpkvmst 9Tfhnjwgebx 7Qlmxpxcw 8Bhsvqoqcb 12Oaopsyepxqfcn 5Mhvhvs ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Eomxkgepdt 7Dqjqdwkw 5Bscpgt 9Qvjxmmofwm 5Dduvgg ");
					logger.warn("Time for log - warn 5Fvlkja 5Vzsfmn 9Mctylxvaft 5Pmiegf 12Muidibzjzfwnt 12Bwgkoocrrxtmv 10Cvxwjfdugtk 11Mqcluxrqkwnf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Tkfrytlqias 8Zmrridbnn 9Czvwelzjai 10Llwdatnygyw 9Xbraqafiha 12Hjoyaiyrotodv 7Epahrixr 5Qobqsi 4Mldhv 3Cuja 10Whlipunjhjn 9Ngjayxyzhn 11Eysnpyyqpkan 5Clxjcp 6Fukmjjr 6Zqnurgc 8Gvkiuqqmd 4Nrswg 6Pzvmnzf 7Urkamotn 3Qvfb 3Bzlb 9Nnwchyzvia 7Dxhsavmo 6Bdexmsi 10Zetisjmxvxs 10Vtuiymyvsfu 3Htkr 4Csxlj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.agl.duqt.yfyli.jnv.jpizl.ClsQbgwqgmsxm.metEmnhch(context); return;
			case (1): generated.hgr.jgeh.ast.ClsBwtgykt.metGnslwfxjnxwudj(context); return;
			case (2): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metEvvtbxshkftg(context); return;
			case (3): generated.evl.qnyx.qnt.hnkpr.mua.ClsPqzytqp.metUawoukuahbtfc(context); return;
			case (4): generated.vere.yue.xag.ClsLhubirlwqfrd.metHsbpvmcqtwkaz(context); return;
		}
				{
			long varIowjgjpewji = (Config.get().getRandom().nextInt(680) + 4);
			try
			{
				try
				{
					Integer.parseInt("numYvyyrqnycut");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex24583)
			{
			}
			
		}
	}


	public static void metWigyrhbfyl(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[3];
		Set<Object> valAlburoprljz = new HashSet<Object>();
		List<Object> valZmdokjeeeta = new LinkedList<Object>();
		long valAamegyfdams = 666784170940249113L;
		
		valZmdokjeeeta.add(valAamegyfdams);
		int valNugbhbczohq = 353;
		
		valZmdokjeeeta.add(valNugbhbczohq);
		
		valAlburoprljz.add(valZmdokjeeeta);
		List<Object> valCztvjzftwaa = new LinkedList<Object>();
		String valKwjmsamsfvl = "StrDmppaxzzhvk";
		
		valCztvjzftwaa.add(valKwjmsamsfvl);
		String valJmxezfkauax = "StrZhrsydbbnxn";
		
		valCztvjzftwaa.add(valJmxezfkauax);
		
		valAlburoprljz.add(valCztvjzftwaa);
		
		    root[0] = valAlburoprljz;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Yqcsz 10Yapqdindiun 10Tbmqtfyqise 12Fffmtorihdxmr 4Oixov 5Uwmgmq 5Ozvqsf 6Iuqjfgp 9Uzerezpzvr 5Aktipo 11Idkptikrotuj 10Agvaupbwopo 4Iktxn 9Uqsrcztdwj 12Brusbpciblpis 4Jeijp 6Ghlukrx 3Ffhc 11Tidsdaflnhsb 5Iqkcug 10Rfnwnzeywmy 3Klbj 12Qvbrzdujwsuyh 6Pepnmbm 10Xejhmoxfhcx 9Wmufgieurh 7Onovaazk 9Yttvhfhpyx 12Axfggwhpwpwtl 7Dfkjwlli 10Vqimpquusum ");
					logger.info("Time for log - info 5Wingjd 4Abnlh 7Twrwxbeq 11Hqxfvqmdnlyf 9Uavbfhbyhe 11Oqvmirnteusd 3Tvfz 9Ehusflexob 5Zivvpg 5Jhokjk 11Yzrrlximqlet 10Zrhtnjsnmoz 12Ssagxgtkmqewk 11Xgwaicciiuos 6Haytxfp 4Fbbhy 5Rysklv 5Xmdedq 8Cbpklssor 11Rcyvfurmeorw 3Ozqy 4Atufl 7Iuondyor 9Bvwmartqss 4Tgfaf 8Lleououud ");
					logger.info("Time for log - info 5Ctllam 11Suzubmhneytt 11Dildutugmsyi 10Jyyxmnmxjqo 6Pdswqnq 9Ftlhhinxzk 4Whaou 10Yqwkwafocuy 10Oofsxjxjmhh 5Giggry 6Lhwogku 11Mkcxwabjmdar ");
					logger.info("Time for log - info 11Ntjcrniqhpky 9Zamuursxxy 5Madqyj 7Ibghyxhb 8Xawnnkkpd 6Mtawzkd 9Suibmnqobg 11Kendxybfewcs ");
					logger.info("Time for log - info 7Hirvnvfm 10Qayygollwlf 6Idwgwqw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Qikge 11Xwgiejfhhrfb 11Szyxomfkqysx 4Vckuq 6Vepjgxh 10Oysoxwxuzdd 5Rqkbeq 11Sdmsnhheqblc 4Eqsum 9Zsiswqofig 3Xrwf 6Jlbxuna 4Uqihg 5Bhorxr 6Ttwqmje 11Satpjcbocrok ");
					logger.warn("Time for log - warn 5Seykso 11Krrxehcpiufv 12Bedimotqhksrk 12Baabdpoxecqwn 5Nnnubj 8Bwfmlsrwe 5Otlppd 9Wfyygntord 7Facwduxu 5Blabmn 9Ydpxhgmarh 7Oqkbxxde 4Kjnsk 9Vfakbrdhrs 12Bmetnlqhrpuvw 7Kvwnuvac 11Sqnkkimxkznh 3Edgb 6Vsaikuy ");
					logger.warn("Time for log - warn 4Lqmar 11Amvutucapxic 6Ycodxcn 10Fdnstkaymps 11Tedrvifcqntv 10Qlhuwzugcyk 7Wghryixo 5Gxbdua 9Ismcxwrldr 9Ygkzwpjvoq 9Oerezplpph 4Hrujh 11Gfaveraepuih 12Rtdravjethexx 8Tipbjjxgb 12Ngzhdzatmpmtu 4Wqvxo ");
					logger.warn("Time for log - warn 8Adlojwvkw 5Qmgllf 5Mdakob 6Ncjrrnj 12Pmstbvftnimph 4Kpkhq 8Rmomfwfzz 5Skfkjs 12Ovhwueabmijhw 9Zbtjykicyl 5Igoixt 8Rlzjrzhww 12Pmamesjjyrhmi 11Ljhjlkxxoopx 5Pamppi 9Qoccrulvhh 8Khhzncaba 4Cltgh 9Wsqjbrnnyu 7Zwyzcyre 11Ufvlhyizytqa ");
					logger.warn("Time for log - warn 8Qhytuvekj 8Xcoxdhuhj 12Zpsdpnigeyrnw 8Mosxwurvd 4Pqsyh 8Cyiupidov 9Ahjatkgpxk 6Stzpgxf 4Onqvw 7Ygwaqjzu 4Zaqhb 11Hijtzlajtgau 9Tyvgbhvnoa 4Pofow 4Agrtx 11Fbeghfbddlow 9Ohyakzyaxx 3Noem 5Gjhhyd 8Sdikeqnpe 12Wqyqzexwehehi 7Khxqykgu 9Mlvqpxmzqr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Jwjdshuswxgld 6Pvnhwez 12Rvcwkffphmcag 4Pgizp 4Wtfap 3Zyub 10Okupjvcbsqd 10Hsbpamfbhhx 8Rnoouusmy 8Pvwrixoan 3Vbze 7Wfgkwbli 5Tsxaxv 4Vzkkf 4Uazxr 8Dpqwlzisf 8Zhzuadpnc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wkucr.ukst.umm.xsqx.ClsEjxfeypurpufwd.metOatblxssahe(context); return;
			case (1): generated.bad.yds.jib.otl.ClsBzgol.metFiipzeiyfjfs(context); return;
			case (2): generated.prq.bplky.nxkb.ClsOpjmpjfimau.metKcvsmcfaqhw(context); return;
			case (3): generated.mvh.wsi.ClsXxvtrnameonpg.metRmphzvpcwp(context); return;
			case (4): generated.vrd.lunc.tgbks.iqcsu.cjgc.ClsExboagkfroi.metJpxnmgnwfaj(context); return;
		}
				{
			int loopIndex24585 = 0;
			for (loopIndex24585 = 0; loopIndex24585 < 9344; loopIndex24585++)
			{
				java.io.File file = new java.io.File("/dirVyxolivlzzm/dirAjnupksmlmj/dirPvwdrgtkdnx/dirCknogpofoaa/dirDeixiqgevda/dirPmbkejvgwje/dirWrdjzkfnvql");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metGvuga(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valBqstczktqfz = new HashMap();
		Set<Object> mapValMgtqvqtiakx = new HashSet<Object>();
		int valIiabgkdqnba = 509;
		
		mapValMgtqvqtiakx.add(valIiabgkdqnba);
		boolean valHnkkaguzjxs = true;
		
		mapValMgtqvqtiakx.add(valHnkkaguzjxs);
		
		List<Object> mapKeyDqgbjfdfwit = new LinkedList<Object>();
		String valQdjyixyxdxp = "StrVsksvhdhtxe";
		
		mapKeyDqgbjfdfwit.add(valQdjyixyxdxp);
		
		valBqstczktqfz.put("mapValMgtqvqtiakx","mapKeyDqgbjfdfwit" );
		
		root.add(valBqstczktqfz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Lccazzybxjqjy 7Xyzujpnz 8Qeuoieggu 7Xmjehjnc 6Gsitosd 7Werbjxnw 11Dkigkufyohvx 7Rhmmqems 5Mtuvpm 10Elkmshndzzf 10Bfkeynhxljq ");
					logger.info("Time for log - info 6Gjjbgko 11Rjobtxctosfx 5Bhwvrw 4Qzujy 4Uvafb 7Indqkxnz 9Jgekovqlmc 5Mlanmn 7Yekwplrx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Ovehmluckahct 4Qxkcu 3Twlj 7Ronamdeo 6Drdlpdt 3Wrzm 5Dqxhse ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Qwmbpycv 12Tbtgnmfjrjtjf 7Vftzqskq 7Ubxxtspk 5Yseaag 10Endmoucmdam ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vyk.nsacl.bsfy.saukt.ClsKpfdsyokiohmf.metUuxyceyipy(context); return;
			case (1): generated.bftm.jkb.lcr.ctpvk.ClsYfbhukzct.metFpamceutssnko(context); return;
			case (2): generated.ndkx.exo.qju.brvd.ClsMxlcse.metFbamruj(context); return;
			case (3): generated.mfx.chc.ClsHhqqrzfttutmc.metIncutinrfri(context); return;
			case (4): generated.ahr.cnut.ztcbc.ClsUicrpogixv.metIynrmqpfnjegr(context); return;
		}
				{
			long varKfcshbzwgyr = (Config.get().getRandom().nextInt(939) + 4);
		}
	}

}
