package generated.gfhvs.nuhuq.qbk.rwbku.erqpl;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsOuzdnnqrt
{
	 public static final int classId = 206;
	 static final Logger logger = LoggerFactory.getLogger(ClsOuzdnnqrt.class);

	public static void metYemauozpyth(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valIesbcjkdyyu = new HashSet<Object>();
		Map<Object, Object> valKvhldfmpdzg = new HashMap();
		long mapValZoxsfmniwni = -748686262059056619L;
		
		int mapKeyStytvmxpcua = 738;
		
		valKvhldfmpdzg.put("mapValZoxsfmniwni","mapKeyStytvmxpcua" );
		int mapValJfqtvnliajn = 328;
		
		long mapKeySruuozpomlz = -6408797443366563747L;
		
		valKvhldfmpdzg.put("mapValJfqtvnliajn","mapKeySruuozpomlz" );
		
		valIesbcjkdyyu.add(valKvhldfmpdzg);
		
		root.add(valIesbcjkdyyu);
		List<Object> valBsrlxfwutbw = new LinkedList<Object>();
		Object[] valZloqbmkaviv = new Object[7];
		String valAuixgigglaz = "StrYrzacwlknwa";
		
		    valZloqbmkaviv[0] = valAuixgigglaz;
		for (int i = 1; i < 7; i++)
		{
		    valZloqbmkaviv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBsrlxfwutbw.add(valZloqbmkaviv);
		
		root.add(valBsrlxfwutbw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Pzjlkfeiqethr 3Kzfb 7Bgompear 9Aowhoqzmjw 7Qgkpvrzd 7Aabnccnz 7Tyburnic 5Fdvvan 4Phfwh 5Blecvw 9Ewtxghzdfp 9Lxskzxarob 10Qpucmoqlywu 11Wnxdtjfawjvg 9Txordcuhsv 6Vmdtyfh 8Yalxqbdih 10Gcpifzvwfih 12Bvrvrvwvihukg ");
					logger.info("Time for log - info 3Grnf 10Ztbvgknqzcv 6Bjqrzyh 7Pzrwzzxn 9Zlqfktnqui 6Uzhesxe 10Kyajzcagwfj 11Qflxaskjtwbp 10Efucrkrfehf 10Ozwcltvsylr 3Lvnk 10Tqemwaauegy 5Xhggme 8Rohanyymz 4Pmmwm 9Vroxizlgcu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Jcagn 8Tadkucqfr 7Ohmgbnvn 9Gzjzhnwdny 11Fcdpcqzltqws 6Jxagrks 4Ndzir 6Fywatkd 9Lbtxypgulx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Arahlrz 12Flmjcoxqpjuxj 7Yifknkyb 7Vqbfgyre 4Sugtn 3Swhr 6Pcrbgqq 12Fxtbmwkqxiogv 10Ipglkpxvnyx 10Upmouvgpncs 8Fdowgcfmq 12Ozzqjkijzkhto 7Jbytbypf 7Qjcghdft 4Mtiwh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qpe.ifudp.xgatn.jzg.qau.ClsJymdeqopgpbo.metRgioipeguamkhy(context); return;
			case (1): generated.rlg.pxdte.svn.clv.ClsMkagt.metNjyfilmrjy(context); return;
			case (2): generated.rnt.ihen.ClsUnbfdq.metGtesoym(context); return;
			case (3): generated.bde.vdlp.frn.zsrjp.eqwxd.ClsMvedn.metBrdejrtmmvqjyb(context); return;
			case (4): generated.zljq.wuqwj.ClsEloxjpaim.metYpqwrjj(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirOsxanlddmox/dirMxypnqgtxbu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex23648)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirVsksbkqtffb/dirCsgendzwfqk/dirIjrqclesreg/dirFqpovvpctpt/dirDpehfadxumy/dirCiajwibssuw/dirStjgjkznufi/dirSxziigyhxil");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metHwnbcj(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[3];
		Map<Object, Object> valVbwrvewshqy = new HashMap();
		Object[] mapValLsrhsvhodmt = new Object[7];
		long valGbzuhuqwieg = 1807216209596157204L;
		
		    mapValLsrhsvhodmt[0] = valGbzuhuqwieg;
		for (int i = 1; i < 7; i++)
		{
		    mapValLsrhsvhodmt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyEudthjviatw = new LinkedList<Object>();
		int valHmzcwfvlgtv = 529;
		
		mapKeyEudthjviatw.add(valHmzcwfvlgtv);
		boolean valOzczpuxoncb = true;
		
		mapKeyEudthjviatw.add(valOzczpuxoncb);
		
		valVbwrvewshqy.put("mapValLsrhsvhodmt","mapKeyEudthjviatw" );
		
		    root[0] = valVbwrvewshqy;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Mbvz 12Jmwelkstjpyef ");
					logger.info("Time for log - info 3Ijou 4Gtegw 9Seaurqcqlz 5Uurrgq 7Liehhuag 11Zbgcvaqqktfk 10Knwlysbrgyy 9Nfregiljpk 11Lpftzzyrqowj 8Xsywauaar 4Mecpf 4Zgwwu 5Dzkqtj 9Lieyhndbfh 8Hxrhyyezv 11Lnpwxtogjodv 6Qsbrlgm 5Zfmywm 8Sdxujnxul 6Dqtnvrj 9Cffmzgksgs 5Ldtzfo 11Rbrolgclhtun 3Hiop 11Vfzpqshpsveu 3Pcnr 5Nqpvdf 6Udrawou ");
					logger.info("Time for log - info 12Efsfkumrqrjor 9Bppadkupqf 9Ucdjhfbmfl 8Elxmqwfyf ");
					logger.info("Time for log - info 6Czraifm 10Upbyoitubun 9Rmvqszjrbe 7Ezziajqw 4Eqtzr 8Mwtvuonox 8Myoufcucl 3Opxm 8Cxqttexnk 10Eonomuuxeqm 9Qmxvkvcqdg 7Ddxgtyut 5Kpjlib 8Rhguwtwhn 7Zlouohfn 6Bqytrqz 4Xlocq 12Dtbwbbwluctqw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Tnnrnrvjawci 12Ndqthbucdvmwq 11Gpehvaprudlm 4Iicip 4Vfzvb 5Ewyrjw 8Xtxyusvuf 3Qhjh 6Jzswtjw 11Pcdpxnlpyhgw 11Zmwzmdazdtxl 11Crbjmcnsuqek 9Rndldgncaj 3Lrop 7Pcxnwfpn 3Jyzh 8Pbrjixmbe 3Nwwd 3Gygk 12Nglxuqknvajeu 3Rewq ");
					logger.warn("Time for log - warn 7Rtyxtfwc 12Qrwtrtvuobmmo 11Biqruwdglrdy 7Fcbbqdqj 11Kferwnqzwayr 12Xrskuqdftnsfp 11Hfqvkodxfieo 4Rkmur 10Lrqrlntcgly 5Hrptxy 12Xgsbrofhacxvu 4Cdkwl 7Xsnfjcxa 12Ofzixlrzqknvx ");
					logger.warn("Time for log - warn 7Ehzgoftu 7Qhyclwae 5Savwxk 8Rsghfmzuj 9Rfawsjbqcv 11Zxvugbfqyspv 5Nmtnpk 9Tiiefuovff 8Bcigeiofl 10Yukqicigdxs 5Qjoiqx 8Rzlqrcolw 6Vaxeeaj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Djebeg 12Quzlbnnpzwywa 9Tzsbaqzvry 4Azwaf 4Fioji 12Ppejsprxhpqbg 8Ulfmbcpyu 6Wmyympa 5Cnrvxx 8Kaovxtaoa 4Xffuq 6Xgkeaqy 5Efofai 8Ozfigfxph 3Webo 10Ikeymiivfxb 10Ujsfoblqrjw 9Pbxodnetfg 9Vednkcjrfx 12Lkayqosydqfdg 4Gmpjc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qnzm.livr.ClsPutzsgygioejxl.metMebbiihjouloja(context); return;
			case (1): generated.xij.sqewq.cevz.qdd.iar.ClsAxzlzievw.metNunaxfbnokb(context); return;
			case (2): generated.hfhsc.dtsm.exj.akcxm.ClsEggbq.metGkdrqysenzt(context); return;
			case (3): generated.lmq.wwll.mcjoz.ClsBqjxdpu.metLzmwjdeakzh(context); return;
			case (4): generated.xluq.wys.lexvj.ClsEsonclfnnvbg.metKsdklzxlnfg(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirTmiohmqnaqd/dirVasqjavjcbt/dirGwhgenbenny/dirChccdsgatap/dirBbxibwdqklw/dirVeamewbpudu/dirXnceejqgvsc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex23656 = 0;
			
			while (whileIndex23656-- > 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex23657 = 0;
			for (loopIndex23657 = 0; loopIndex23657 < 4086; loopIndex23657++)
			{
				java.io.File file = new java.io.File("/dirPjdiqdbmvia");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metRbpddposz(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valGqpikbgqvsj = new HashSet<Object>();
		Map<Object, Object> valYvnustgjhgl = new HashMap();
		String mapValUbwviasfezo = "StrHnijviaezsy";
		
		int mapKeyOgjdifonzyw = 115;
		
		valYvnustgjhgl.put("mapValUbwviasfezo","mapKeyOgjdifonzyw" );
		String mapValCcptdzmqews = "StrXrxtrzqnnje";
		
		long mapKeyXkhzlpkfcke = 5685579681583080388L;
		
		valYvnustgjhgl.put("mapValCcptdzmqews","mapKeyXkhzlpkfcke" );
		
		valGqpikbgqvsj.add(valYvnustgjhgl);
		
		root.add(valGqpikbgqvsj);
		Set<Object> valGxaarjvgezx = new HashSet<Object>();
		Object[] valVlxadkbjchf = new Object[10];
		String valIznzrhjtzzo = "StrGorlohefzig";
		
		    valVlxadkbjchf[0] = valIznzrhjtzzo;
		for (int i = 1; i < 10; i++)
		{
		    valVlxadkbjchf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valGxaarjvgezx.add(valVlxadkbjchf);
		List<Object> valPzkxtjmrugf = new LinkedList<Object>();
		boolean valAlkuscvtcqi = false;
		
		valPzkxtjmrugf.add(valAlkuscvtcqi);
		boolean valGeahasganlh = false;
		
		valPzkxtjmrugf.add(valGeahasganlh);
		
		valGxaarjvgezx.add(valPzkxtjmrugf);
		
		root.add(valGxaarjvgezx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Fwtsdcsnfpyv 12Epyrzprkmcggc 5Havrmb 6Gtchiuh 7Gugbvtnd 6Ijtpuyb 12Tzxrdecvvtfof 12Niqejyoqgxwns 9Dloukvsvqg 6Oskthrx 11Wymavkdetchm 10Uxsmnpmmbxg ");
					logger.info("Time for log - info 11Lkfbqjlcsmnw 3Qujl 10Tdzpqyhhmdm 9Qjhvflzzyn 7Czdcbqfg 4Tmdjo 5Hbjdxc 5Xvrmaa 8Kjllcjccf 5Wueihu 4Rjdsz 12Wxskcmwdlhgeq 3Rbln 8Efizvaksy ");
					logger.info("Time for log - info 12Xcwsdgzfqwerj 4Wlxuz 5Qknhjx 3Odpi 11Zvkfdmyigciz 6Vibwuni 5Oqdelh 8Stoxcgbru 11Vbxuetfcgxnf 7Qkhnekxs 8Yrtugfcsx 11Nefqffnvqwmc 4Ixgqi 8Oobqwhnbh 10Odbbgusaxaf 11Xdlagvcvblwk 9Jcvrdegcce 5Gasqld 12Wielurkiuwpud 6Poboqof 11Vilgstflfutr 11Yqgfaotzusmu 3Puhb 12Hjaouchstwhvt 4Kjfuf 8Gdfppamzi 11Zoqwxkdobcse 12Eylvatbwqsixj 3Itnf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Zazwv 5Vsrwjm 6Vfuyuqw 5Blbytr 4Pyscz 6Ljymeww 6Fczuxdo 12Umsbsamuvytzh 9Jbgcpkkvda 7Rfyalufp 9Ofzuvfuldl 8Alqtinrmt ");
					logger.warn("Time for log - warn 10Hkdgkjftbwr 11Pklaazgcqvxe 10Prbrebaycvd 8Psfcevqiz 6Xebaqvf 5Ztwqiv 11Ubtdcpopznhs 6Wszofjd 4Ysyik 12Swsbrpiriyzvx 6Dkxvlxh 4Ozqvt 8Sxhmpzftj 12Sqzkbpecaetli ");
					logger.warn("Time for log - warn 8Xteqvynub 3Fvmp ");
					logger.warn("Time for log - warn 12Yoycldefvxzib 10Mkhdhokyzvj 6Uytuxls 10Btfgskzvdxi 5Xreguf 3Ohnf 10Hcesjqktvdk 8Rcbprgdmc 7Rrucqixw 10Vbltuvcwjlf 4Ykdfk 7Uqvcpgyk 10Vwgtmuethhm 3Vgjz 7Hpglmgkx 5Bdjauc 11Rngwanbacpog 3Rcou ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pmny.tmdlo.mfapc.ruez.fnhku.ClsHncyoaufamsb.metZiouerfahj(context); return;
			case (1): generated.hbd.gdsbg.cmv.qvo.ClsZtgxvnjsll.metQvkbrrhkdtwqhx(context); return;
			case (2): generated.cfolx.abg.ClsZqloaugvusc.metIetjxtz(context); return;
			case (3): generated.tmohp.pbwu.gfhxq.zdkm.ijx.ClsDimqu.metXkytsyqb(context); return;
			case (4): generated.ryyqn.hafq.oqfv.ClsRsktinox.metWxtwtvz(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex23667)
			{
			}
			
		}
	}


	public static void metAacwokcmgyz(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valUxgdqptwkuv = new Object[4];
		Object[] valPslddvttfby = new Object[7];
		long valJfoytsxkpnw = 5399874578790070018L;
		
		    valPslddvttfby[0] = valJfoytsxkpnw;
		for (int i = 1; i < 7; i++)
		{
		    valPslddvttfby[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valUxgdqptwkuv[0] = valPslddvttfby;
		for (int i = 1; i < 4; i++)
		{
		    valUxgdqptwkuv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valUxgdqptwkuv);
		Object[] valAmlwczugpna = new Object[11];
		List<Object> valFpjtsjzipfa = new LinkedList<Object>();
		int valTawjrhcaysf = 344;
		
		valFpjtsjzipfa.add(valTawjrhcaysf);
		
		    valAmlwczugpna[0] = valFpjtsjzipfa;
		for (int i = 1; i < 11; i++)
		{
		    valAmlwczugpna[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valAmlwczugpna);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Xdwddrko 5Cvkjyp 6Pborbdn ");
					logger.info("Time for log - info 5Rynyec 10Tjwizuonlyq 7Gwybbuml 11Xnmqgnwqzhwu 9Zcztawqbtq 6Lakfsac 4Rdsaz 8Fbhmjygpq 7Mbradpwv 3Wztx 11Dmcpwueumutc 3Sioa 12Cgpwwkrrfancu 10Iunzfzmgpjw 10Nqlulyjlhwk ");
					logger.info("Time for log - info 9Uyvwhnykzt 7Faiuhusn 9Ywrwcpiprc 7Yejgfypl 12Cpvqobknzsxuo 9Fktztbexsy 11Ejgvqccavqqc 11Lkaduooivrev 10Mgdicxonwrp 6Vgruvpb 5Jgyqjo 4Myeof 12Dyylpgjdokblb 12Dnlwdfdmaflzn 5Mduexw 12Twgwugtlzylkh 4Bdubu 3Uraw 12Hmpcbcnafvrjn 3Bwnr 5Zvtell 7Gecvxqbm 12Iogfjskjqvmrp ");
					logger.info("Time for log - info 6Vrtvhmn 10Tpsqgygvmso 6Uofjyml 12Qfufxeijxwmpy 5Zxpykc 7Bbjcaqqd 4Vrirs 8Rregwmxgb 9Qknpdzxhjp 12Aiugcrhytxcms 12Mybgboaivztow 12Jirnzvckzrtrs 11Foxlfcvibnsd 5Flgmqm 3Fwfd 5Gpjwot 9Phnspgqpti 7Ppapfeua 11Hpichzumtvwh 4Lknks 8Dgpsdjzsq 4Bzejq 12Wfnggotbogizi 9Sjkoffvenh 5Rhqyhq 4Tzbhv 9Damqwsppyq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Jfbgxpbvdn 5Tfmldg 8Kecvglhtz 7Dgwbqczg 3Rhil 4Prqnd 9Zstmbimrjj 10Aavfmgsexsy 12Zeyfzwrxuehuh 8Zosdarpiw 6Jhpbnvn 10Spsxtjrogdt 3Vwrv 4Skywz 4Dvyrq 7Cdjzkcmv 10Qcdtuasrcmv 6Kknivff 6Csgqjae 8Obpdvquyg 8Atphonmge 10Shjgvxlhzwl ");
					logger.warn("Time for log - warn 8Ktfxqylmv 12Wjimaxpjehdmm 12Yqnzwappixtoy 3Lwxk 11Kpgzgwhkxalu 4Mowrb 11Xyayiwsoehda 3Sktl 9Rbjhppvqvf 5Swnoyx 12Qjzymgrujgyxb 11Zgosknlkhmbg 3Qkqn 5Wwftlu 9Ymgpvvpcpa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Tcmgotxrl 4Ychcl 6Ihdolxa 6Prhgpen 4Himvq 4Clttw 12Ezikjwmykkslh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.inao.viw.ClsZkxazvlqxnvyzx.metYczqbc(context); return;
			case (1): generated.blsj.gki.ClsOuhbksvj.metEkzrb(context); return;
			case (2): generated.rxif.wckg.ncsqv.pmlox.ClsRkhayrnqgfzod.metOqicwb(context); return;
			case (3): generated.miye.jljz.lus.ClsMvdumbmsqtl.metCcisf(context); return;
			case (4): generated.hzldn.tyqka.jujr.chcpl.ClsNxkmsnjozqsvm.metOzhtrhcipg(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(505) + 6) - (Config.get().getRandom().nextInt(114) + 5) % 905466) == 0)
			{
				java.io.File file = new java.io.File("/dirAnuvqylntzu/dirCruhoxlubfz/dirKgrsmksowkn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex23670 = 0;
			
			while (whileIndex23670-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
