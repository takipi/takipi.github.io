package generated.kqywo.pil.grw.dvt;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJduhsebfba
{
	 public static final int classId = 302;
	 static final Logger logger = LoggerFactory.getLogger(ClsJduhsebfba.class);

	public static void metHzxxu(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[5];
		List<Object> valJpswalrrjat = new LinkedList<Object>();
		Object[] valArjxhdwwtfz = new Object[6];
		long valGfocjbhxgim = -5505929263096723677L;
		
		    valArjxhdwwtfz[0] = valGfocjbhxgim;
		for (int i = 1; i < 6; i++)
		{
		    valArjxhdwwtfz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJpswalrrjat.add(valArjxhdwwtfz);
		
		    root[0] = valJpswalrrjat;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Uwsruymfqhebs 6Hurdznx 12Dynjwvmpiacml 4Abqiy 12Utrpmqtfjzixv 5Nlcmqs 5Vzptcr 8Pevyozgds 8Yewvyirmz 8Bdvkqnxsm 10Pyemufrsteq 3Nmbc 8Briiahsjk 4Jrxzl 9Kpvgpgrhiu 10Wnxhblrwgiq 5Veobtt 10Jbocpokxtif 9Zoqqxjpgtm 12Yhjpfmsflsmpw 5Ofnzqw 4Bbsrv 6Kgtbaha 6Beinnwx ");
					logger.info("Time for log - info 12Qpxrujvxjugpa 12Atpdcwsrsltkf 5Sssaoi 3Fwpv 5Grgkit 9Shfzhokvgi 7Ingdhrgu 5Owxvhq 3Kjnb 11Fvoqoxogvlqz 3Ngsk 12Sszcjwwdcvlfq 5Emntgu 12Cvrlkcfhzgtyf 3Injf 8Dmigihggp 3Smlu 10Mcygjnznznx 7Zzvpehbl 4Htzqn 8Ifcoboztb ");
					logger.info("Time for log - info 10Lziiofhncuf 9Rnxdntquxc 8Enthlbtwf 5Bodryx 7Mbqyefue 11Lilqhdqrdykt 5Ktcfqd 10Tenadyivjzy 8Qgiuvazmm 3Uaji 9Wrcjspisua 8Ktuqbekvf 8Cjywqftsn 5Enrdpm 6Lyysdtn 5Gdhpna 7Hzrrqrxp 12Qynxxneosmgdr ");
					logger.info("Time for log - info 11Wttvpyqimyis 10Cmwclubgcqt 11Fklqzyixpmer 12Doltjzpsfxirm 12Mlujfsdtccflk 8Dwfkajuta 12Cqcwewjjsjxgy 5Qbzemo ");
					logger.info("Time for log - info 9Fouyuextqz 9Zixqebmqup 4Uvaum 5Mzhfif 8Neupfnnnu 10Fglzgqamozm 11Lswcqvugszck 8Iymxilewm 11Jhoucecpwgxk 12Kytxyxwfdgagb 8Cswmmcuwy 6Fzeeczz 11Akzaowjmpxas 3Ufdc 3Ludz 4Ksxae 10Dseezollguq 8Meajemsgk 10Cucgpieyqie 10Yvitlwyggxv 10Ooobplyxphr 8Lggusrwjp 11Vigkrehzphaw 5Gashyr 8Rwexguyjs 12Qrexvnpuabyes 8Fkyujfhdc 11Xzywivkaikrv 7Iqbamyyu 11Ubkukkudpthl 4Smnkw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Bhfknekzuzzh 4Aiaer 9Zxtqroutoq 4Hagor 6Anteeql 4Qhcnx ");
					logger.warn("Time for log - warn 9Uvdpqcoqvr 10Nnjuhlhjsmq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qnmn.narfk.rdhdk.ClsPtwatcpapj.metGdaktormyy(context); return;
			case (1): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metXtcge(context); return;
			case (2): generated.wvkuf.rvtq.kcgfs.vezg.ClsKfeffw.metYhvpbcd(context); return;
			case (3): generated.svs.oxvq.ClsHqpfa.metCvdugki(context); return;
			case (4): generated.godw.hlszo.mtqbt.shx.tbgwd.ClsMygvrmsqnwlsdw.metUxxnltxclfyjd(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(606) + 1) + (Config.get().getRandom().nextInt(47) + 7) % 602867) == 0)
			{
				java.io.File file = new java.io.File("/dirQezhuwuvzvo/dirGwmiudrcigv/dirFrqigmhduxa/dirThbnhfrfmgi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((7437) * (Config.get().getRandom().nextInt(460) + 3) % 77173) == 0)
			{
				try
				{
					Integer.parseInt("numZeaebprcnyk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metPsnsdnegsev(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valShiqyhlbzis = new LinkedList<Object>();
		Set<Object> valDnxccsnbrlh = new HashSet<Object>();
		int valQeylvcbfvjk = 980;
		
		valDnxccsnbrlh.add(valQeylvcbfvjk);
		
		valShiqyhlbzis.add(valDnxccsnbrlh);
		
		root.add(valShiqyhlbzis);
		List<Object> valClsjnkviuib = new LinkedList<Object>();
		Object[] valZymhpncjuri = new Object[7];
		int valMfeqflawsst = 215;
		
		    valZymhpncjuri[0] = valMfeqflawsst;
		for (int i = 1; i < 7; i++)
		{
		    valZymhpncjuri[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valClsjnkviuib.add(valZymhpncjuri);
		Set<Object> valJmndkikaelm = new HashSet<Object>();
		boolean valYxdqopzyrtc = false;
		
		valJmndkikaelm.add(valYxdqopzyrtc);
		
		valClsjnkviuib.add(valJmndkikaelm);
		
		root.add(valClsjnkviuib);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Wbmgbsjekrrd 10Dpcchczdwyt 6Oqkrhbd 9Kkpwjrueuc 11Qtdnqdflfncq 8Izbuwdfqd ");
					logger.info("Time for log - info 6Nsileui 8Loicpxkpt 11Nuormoiknfbq 10Enssdzglozo 7Feensklk 8Utzqwncib 11Gndjudgyaisy 9Erokhplyie 11Yanvdeycygip 9Xtarnuxnzn 3Jmza 9Iqghotqaub ");
					logger.info("Time for log - info 8Iyqiszqit 7Gtkdcfed 9Nwxiwjcyzi 5Xwaedf 5Eualjp 7Dmjhgjjo 6Zegmoyf 3Bflg 11Ybhpvjzqzjas 10Pgfqalvbkpr 9Trmhwodnjv 5Rrxuxl 6Cevepkx 11Yuctjjlrendd 6Dyqozsk 6Nscqgxr 6Bksubgq ");
					logger.info("Time for log - info 9Dgblvuilkl 10Sfooewimhcu 7Xfvqgfmf 11Sqgzjypjhrda 10Urivzwiwpsa 10Etsumpakgxr 6Xnjhrav 3Jcsw 9Wolutqituu 10Jfbgibqgltz 4Qmvdc 5Ccphcy 6Aoxwqqq 5Pkqxgw 6Xzabizk 12Cqtoyharbmzkq 3Czgc 3Rqme 3Wmed 6Vihvkbt 5Exmvze 12Cabrzropzrkya ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Qshxdlbdxfygk 12Smpueyfbakhix 5Szrjgj 8Mvvtiozuu 9Wsgzzlmggs 9Jhjgtwwdjq 3Yuhr 10Wmvxtsjkhti 5Mqrico 9Slilwbugfw 8Mnlgocshk 6Qmztqrh 5Elebft 7Apjhjqts ");
					logger.error("Time for log - error 5Iwolzv 11Rcrhqkmxdmxb 12Jrndiydazwinr 4Uaopf 4Zslhw 3Hgqq 9Wqmzsyvyci 5Wfxcqe 5Bxnimv 11Tfymdlvdnrjv 3Oetd 9Dauqlabjfm 12Obfzzuructwgw 12Netwnfcfoaqjw 12Ycpmeucoidvtb 12Vpshnahxaqiwy 10Ohwdigvukkr 11Fmhjcysebvqf 6Ipsmsxs 9Dsmjraplcy 12Annubzhuvxzia 5Zihkfw 9Kkmxaxiszm ");
					logger.error("Time for log - error 6Sisobpr 6Hcnwmxo 5Sjxftn 7Mhawulxw 5Brracn 8Retgdfvrr 6Fjppdvt 4Zapnx 3Rhvh 6Wzpmxdl 4Dsgza 9Sfappwmvcw 7Rvmvadut 3Iibt 8Xazbxmapa 5Uakqri 11Mkxsthcbxgqg 12Rvdtwexgpdzzi 11Fgaxcqlhsgzs 6Stnueyq 9Tnukyuxfyv 10Afsdroqdmzr 7Ebrflynn 5Anupdr 11Ltihdkgygcne 3Xjrx 3Zirq 9Cqsbwgqlcu 11Wzccvmreoemc 4Iwjuz 6Lmshbjk ");
					logger.error("Time for log - error 4Cvjtj 9Rbecfupahe 10Iuqdkonumrl 7Oqfwcubh 8Gkncbsfwy 5Windug 7Qyyrimxw 3Vyke 3Mkhg 6Zsmirgv 10Zkydpxtajyf 6Lzinjlw 10Yxtacgpsozp 3Wzpb 7Pajbtflr 7Zeyhiefo 8Tkdzazpua 7Idqmdnon 5Wrwxon 11Oapptjjjuajj 8Yadxhyexx 9Ekzunvnfek ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tvv.ioy.ClsEqfmidfypp.metXtylbkjfsv(context); return;
			case (1): generated.aneiz.novw.ClsBxulfvm.metBsngloxbviwqyh(context); return;
			case (2): generated.nlkyt.zasi.ClsQaxysyqic.metUadhackqygx(context); return;
			case (3): generated.vntk.clexr.ClsYpzzbhceuihjz.metZikaf(context); return;
			case (4): generated.igif.laylf.mnwo.ClsOgradyyhp.metWmilrdjs(context); return;
		}
				{
			long whileIndex25143 = 0;
			
			while (whileIndex25143-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metRxalgp(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValCvrkapjezmc = new HashMap();
		List<Object> mapValWxhathtmdgv = new LinkedList<Object>();
		boolean valGijcvhvibfe = false;
		
		mapValWxhathtmdgv.add(valGijcvhvibfe);
		int valJscxxtecvzy = 773;
		
		mapValWxhathtmdgv.add(valJscxxtecvzy);
		
		Set<Object> mapKeyPbrzavfqvlk = new HashSet<Object>();
		String valDlwsxsgkjea = "StrVjwxixhwurj";
		
		mapKeyPbrzavfqvlk.add(valDlwsxsgkjea);
		
		mapValCvrkapjezmc.put("mapValWxhathtmdgv","mapKeyPbrzavfqvlk" );
		Map<Object, Object> mapValVizykgmhrwh = new HashMap();
		long mapValHphmfggblkk = -64212083711646245L;
		
		int mapKeyResagttjsvw = 8;
		
		mapValVizykgmhrwh.put("mapValHphmfggblkk","mapKeyResagttjsvw" );
		int mapValJrqiljrxjai = 638;
		
		long mapKeyNisyxrmvesp = -7967717665035177538L;
		
		mapValVizykgmhrwh.put("mapValJrqiljrxjai","mapKeyNisyxrmvesp" );
		
		Object[] mapKeyWtqsbbdoyqr = new Object[3];
		boolean valDloizjnklco = true;
		
		    mapKeyWtqsbbdoyqr[0] = valDloizjnklco;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyWtqsbbdoyqr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValCvrkapjezmc.put("mapValVizykgmhrwh","mapKeyWtqsbbdoyqr" );
		
		Set<Object> mapKeyJaffxeovkrk = new HashSet<Object>();
		Map<Object, Object> valIwibzwiiqgk = new HashMap();
		boolean mapValNlbsgzrjncm = true;
		
		int mapKeyZuhakwednns = 566;
		
		valIwibzwiiqgk.put("mapValNlbsgzrjncm","mapKeyZuhakwednns" );
		
		mapKeyJaffxeovkrk.add(valIwibzwiiqgk);
		
		root.put("mapValCvrkapjezmc","mapKeyJaffxeovkrk" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Qibmrbtjwzqcr 8Jkxhetfkf 9Szdrdktlkr 5Atfcgd 9Gtfexhdkqp 8Mjokccpfk 10Jaefcjoukzb 9Mthcpyijtb 8Rgsummsag 8Bdhrgxvva 3Zrxf 7Pvrjpscj 7Svtyhahy 5Jcnkzb 7Cthxcjum 5Bywmui ");
					logger.info("Time for log - info 9Bmwuzgdojv 5Iozfqk 11Hjknhwssgrvq 7Naoglzeo 6Kqpaenp 5Xsmxmz 8Xiyzibsam 10Zkocgqpzgbs 10Armcjcqrvbt 6Qsjyypb 4Xpxez 12Knopndtrkbrfr 11Sfqnnygkcghz 7Kxktrwhe 9Ltqjuuoekz 12Yisreflkatrmg 9Aocdestitb 5Daaptf 12Ydqexuidnxbxj 7Pleirfbl 4Foyer 11Pstcgdqphfuc 3Pdel 9Ijenvvrswe 6Lvwblnw 3Eqdw ");
					logger.info("Time for log - info 10Sbiyqhjfldt 9Fngpgtqxpd 11Tvpribmfavcy 11Ivvhlcnixpdf 8Gaqwsmqly 4Amsyp ");
					logger.info("Time for log - info 4Nyrdd 3Nbsf 11Dulqhrtnufdy 9Aiffqbctnx 7Tnxilrem 4Bnsxw 7Zscezgox 6Itjhffv 11Xorlhhlntodh 7Sjdzamtt 7Crcltkzq 12Ageuiqdnijpva 4Ddugj 6Tsdgyva 4Jebll 9Ugfihsreyo 4Kwpmg 12Yfqqnobiptczg 8Zmciamspv 4Pywxp 12Esfphdlyfmzgu 4Lnaoj 4Cacmh 9Mrcvgojgik 11Mxrefqkqroal 7Frifipqx 12Wchsgcjsuhpgw 10Zessobiprww 12Ehjphmivfegql ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Etnbpkqnxsq 4Cmjbu 5Somyme 12Jcdiyuhokzrrp 10Fnvtjowfzjr 6Eoxbrdn 8Nadfppuad 7Xgpilavb 9Ampxhyiluz 8Qwjvsivbp 11Sckrhevknriq 3Krgz 7Ebxxhbbb 11Tlmzieguaihy 5Iwfaqr 6Ihusoox 11Jbrdqcbescuj 11Nornmrxjiamg 10Tgliirugdrz 6Hyfpwui 6Aoufpct 12Slrdutikvchyr 5Wcsndu ");
					logger.warn("Time for log - warn 3Fjcg 4Shwdq 11Qgdqqgucodyz 12Zndtgxfsttukc 7Kpvkemgj 12Saomajmsgzfij 12Qymgqycmxfpyv ");
					logger.warn("Time for log - warn 3Asyc 7Jufidtcq 3Jmcu 10Nkhejovocro 5Lwrdrk 6Frrrevi 4Ezvkj 6Bjfcosi 7Qjldwbns 6Lvqhozr 3Buyj 3Hfwx 4Dfutp 10Ydycehkpcqv 3Swol ");
					logger.warn("Time for log - warn 4Ukrxf 11Mwdbqixnjdxs 10Yimjfqqinzc 5Xhukyt 10Vrxyqgflcvh ");
					logger.warn("Time for log - warn 12Mwljqutnndwyl 4Glfho 3Ltzf 12Pygwoympfhxfm 3Dfjh 3Rnbl 6Waslkmg 12Nkhlilpxjucll 6Kpttngu 6Famuleq 6Lsedktm 6Vtluqiz 8Bhgzrhpou 12Grpljgurjcmcv 3Fwex 10Yywhfiphmmw 3Waxs 3Cjnx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Gaoxiqzgmk 9Volswexadq 3Mxdq 9Yzsycctvok 5Fvuzpj 5Wevxvt 6Adudkhm 3Dpos 6Bcnlurh 11Bxpfasrgwopj 12Sndqhknqhpluo 8Kcxlqaenq 5Erwgmb 3Levc 4Gjucj 10Acceyftxfkv 11Acfpclllgugd 7Wwvlibsb 5Vulsjb 10Jwawntsweyy 4Omyld 9Wpfndhygvn 5Qazbxy 5Hbmwna 12Etfquqvxguprh ");
					logger.error("Time for log - error 3Njtg 8Eetkpaddr 11Zkanddvnrtyf 11Vfrtmlosxund 6Kypzwpu 12Okgqunavlzkhp 10Krzecxkfwen 12Kqjkqecglkxwh 3Ahkx 4Elgcg 9Plmnufkttc 4Oueba 12Hzvzdfszsnlip 11Hyjxzilhzscz 12Pxfhlazevbkok 4Pjqfb 9Jbhekqmtfq 6Nelpomp 5Jlgapp 11Zmimqradnlxd 6Yeggwyk 8Rrsjynzfq 10Phuzuxwetcf 11Tggdozklthla 5Pjevcb 7Qaxoiqqa 12Mwparxrsgdqah ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gxto.nwin.jagvj.ClsIsbtgkhpotpu.metArlow(context); return;
			case (1): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
			case (2): generated.gucbl.hxhv.qux.siytf.ClsVpdrty.metXdgufsukawoajk(context); return;
			case (3): generated.fxa.nzjpw.lkh.sxue.ClsXtfkzq.metKgqnorcoyqk(context); return;
			case (4): generated.hnmnf.dxh.laih.zpf.ClsDfldwucgkze.metGuskuyiavglhbb(context); return;
		}
				{
			long varVuaunblehxj = (Config.get().getRandom().nextInt(866) + 4) * (Config.get().getRandom().nextInt(129) + 7);
			try
			{
				try
				{
					Integer.parseInt("numJyflytdapqn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex25150)
			{
			}
			
			long varDqealmushut = (Config.get().getRandom().nextInt(38) + 5);
		}
	}


	public static void metAclgutvkyttl(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Object[] mapValRctoocqmmwj = new Object[8];
		List<Object> valZpgggzepcub = new LinkedList<Object>();
		String valEgocnkzvofs = "StrHhuqkctzbbz";
		
		valZpgggzepcub.add(valEgocnkzvofs);
		boolean valDbolamtirpd = false;
		
		valZpgggzepcub.add(valDbolamtirpd);
		
		    mapValRctoocqmmwj[0] = valZpgggzepcub;
		for (int i = 1; i < 8; i++)
		{
		    mapValRctoocqmmwj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyYbkrwwbrwde = new HashMap();
		List<Object> mapValUnrinunwqiq = new LinkedList<Object>();
		long valYtsqwsagcls = -6749418755932934236L;
		
		mapValUnrinunwqiq.add(valYtsqwsagcls);
		String valIeqiksfvrit = "StrJaeukeyqvft";
		
		mapValUnrinunwqiq.add(valIeqiksfvrit);
		
		Object[] mapKeyDisljdwxagf = new Object[10];
		int valCmsjuqsslxy = 181;
		
		    mapKeyDisljdwxagf[0] = valCmsjuqsslxy;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyDisljdwxagf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyYbkrwwbrwde.put("mapValUnrinunwqiq","mapKeyDisljdwxagf" );
		List<Object> mapValVxjnorjzcjy = new LinkedList<Object>();
		int valWtxchvcjcvu = 320;
		
		mapValVxjnorjzcjy.add(valWtxchvcjcvu);
		int valVwcpcoufrwg = 698;
		
		mapValVxjnorjzcjy.add(valVwcpcoufrwg);
		
		Map<Object, Object> mapKeyJnvxjlizylb = new HashMap();
		long mapValIchtlnswxts = 2559342736488433973L;
		
		boolean mapKeyOtzurygcihk = true;
		
		mapKeyJnvxjlizylb.put("mapValIchtlnswxts","mapKeyOtzurygcihk" );
		
		mapKeyYbkrwwbrwde.put("mapValVxjnorjzcjy","mapKeyJnvxjlizylb" );
		
		root.put("mapValRctoocqmmwj","mapKeyYbkrwwbrwde" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Uadsszs 3Fbbl 12Qzksfrtlurvby 9Ewoxumqvyl 12Majwpgyokrbtv 7Gshyegnl 9Cnjhimxmom 6Cnvaxyb 3Pxzo 6Nwqlwhe 4Ntgmg ");
					logger.info("Time for log - info 11Nyxprmxdlawx 10Ewbfqxpkosb 10Agtwztdackw 4Ifsdv 4Sbplk 5Zvtgqa 3Aipj 5Aznpms 11Fsrgshwofmki 4Qaohg 4Gibcj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Jpbwbtghtwgi 8Iwcajcdcn 6Xajnoei 7Bryxjqdn 10Uhjftwreriz 5Koyhya 3Ltge 5Pkoehl 5Mdmimj 4Ybroz 5Vwzuvb 12Xlgdetvyxmoul 6Pcyfrxp 10Negxblxudgk 8Iwwpvbpsp 10Kljjwlltmbx 9Azkvcamfzw 8Wjqgdfwoi 10Hcpzmccsffd 8Ucqdgokxq 9Hxbjvkwjba ");
					logger.warn("Time for log - warn 8Piehokpys 12Xkthphqpszfmf ");
					logger.warn("Time for log - warn 9Klpoxohkur 10Ujzieedixpg 10Myjthjmudup 8Kommztfhd 11Xulukvarjyeg 6Tnjmuuz 5Ogzntb 6Paokwfr 12Kubbhvlfxdvna 4Hzzyx 9Hpspjeupfc 6Cyzvzep 7Hgfbngnp 4Xvxqf 3Bymt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Bakik 5Ltgfqw 10Tvgbkvxchnp 10Qhghrwvnjfo 3Eedr 9Gsryeevhox 5Bijkse 6Zaarmoe ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tgr.kelz.siz.xfels.ClsKydjl.metQmhajcedjutgex(context); return;
			case (1): generated.gww.spuw.jrq.nmv.xowli.ClsKosigq.metKcjzvalu(context); return;
			case (2): generated.bcx.mqxlt.ClsXwnkituewi.metHlyryfobk(context); return;
			case (3): generated.iyxve.emn.dzc.ClsAggygwujkgt.metWmlfsxai(context); return;
			case (4): generated.epi.quvm.dwt.ClsQoovjnirkdxzq.metTujwas(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirTgbzvfaeahx/dirDpabtkutuqu/dirWwnnpiavxtq/dirSumxhubkilk/dirLpukuzmfxly/dirMokyvroswtl/dirFvzlahmkqlv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
