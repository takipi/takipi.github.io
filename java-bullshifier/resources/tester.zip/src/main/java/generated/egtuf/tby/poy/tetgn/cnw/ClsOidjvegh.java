package generated.egtuf.tby.poy.tetgn.cnw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsOidjvegh
{
	 public static final int classId = 91;
	 static final Logger logger = LoggerFactory.getLogger(ClsOidjvegh.class);

	public static void metCzhml(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valRmchhpxabnx = new HashSet<Object>();
		Set<Object> valAkaytjgutgp = new HashSet<Object>();
		long valNyfwblhpspa = -4632759461523492582L;
		
		valAkaytjgutgp.add(valNyfwblhpspa);
		
		valRmchhpxabnx.add(valAkaytjgutgp);
		List<Object> valOntcjhwkgci = new LinkedList<Object>();
		boolean valOtwcxrkpitr = true;
		
		valOntcjhwkgci.add(valOtwcxrkpitr);
		
		valRmchhpxabnx.add(valOntcjhwkgci);
		
		root.add(valRmchhpxabnx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Qutcl 8Otodjijyi 12Koacztedrmppm 6Dnmvssa 6Lkpxico 10Zeqrbfufpem ");
					logger.info("Time for log - info 8Zfmfzunbj 10Xjztajmmitj 12Vhyzamxlnblpn 6Gdhieat 6Dlwupbr 8Edxbuqmmn 11Kigoczusiwnh 5Ywqsyv 7Uuptcsjc 3Kydz 3Waie 10Rnleatlkjlm 10Uijhgxhnfmv 6Vciipfs 5Jbgumr 9Jekvdmwwku 5Txqmia 3Vyyz 7Szbyudpu 12Qfvbucsuewzef 8Ixtmknrrn 10Jddwnxiyzjn 3Vokf 9Dlswtzmrhx 11Ooahsllcvdyh 10Rfdexmaqfau 9Ypdgzpgyix 12Rzboatckjncxv ");
					logger.info("Time for log - info 10Dkewmuuweea 7Wjuwzrfj 5Qjphiw 12Tznmhlboryfhc ");
					logger.info("Time for log - info 6Gaysapw 4Yhngm 5Wvorlf 7Hhlldwcx 6Wkzwenb 11Bceawdfvekiz 11Qwsedirfmzbr 11Dxsbhrewttjt 12Dzurcfnajolii 6Osyxiax 3Avwk 10Xkqznowajqp 5Moigtx 3Wnvx 4Yyqcs 4Uwngh 10Aqzaqobrxup 12Meafixuoilwli 3Mnev 9Kjcihvbbsm 11Uqldenjmlcsh 4Uufps ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Kpnqmdgsyguv 5Jqjjdj 3Cepo 12Eaolupygiqofc 12Pnrnzrvmjytse 7Optoynjo 3Dckt 4Eisyy 11Hjvhjggrgktc 3Tyqb 10Wsvlvheahxs 8Beycigtvo 7Aunbcjxg 9Xzhcjlssps 6Xwlalud 5Ofrcln 5Jwynls 4Nqlru 4Ysewt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Mxnruxa 4Mryxz 7Njeanevm 8Qtieovpov 6Pnexuwk 3Caqr 12Pytdzgedxevib 9Kdklljxjow 4Pnpxr 12Eskhtyqkhqzvf 4Orulj 12Vyevxsoohleuj 11Phtdcrutwrpe 10Upswvqouvpq 9Knmyxcgljw 6Oeuevol 8Pdjgrskga 3Osmb 11Xobtbzdnoybb 5Tcnapp 7Xbtwrgaa 4Albwi 10Mmtidsvbjcr 7Ohfqacgt 9Fmunyjvfzq ");
					logger.error("Time for log - error 7Arniqefv 8Dwizwlpmb 12Nmgtznbhxdpiw 10Hmsxktsrgwp 3Hhku 8Nhjippatz 10Jlndgsraaom 10Shghgxbemdz 11Ganvohhngfyv 5Jrmqnc 6Tfpueni 11Jkofpzitxbco 4Jbjbx ");
					logger.error("Time for log - error 4Eijwj 11Ouyecgvlvscr 5Jpaeef 10Smsnuxomumb 7Tgkaivzd 9Iyqirjxyvg 3Zohc 3Icxv 12Mefpdqqppdnsz 3Wmtg 5Gaplfd 7Jgliyifd 8Orbpoxuuu 4Ssrdn 4Hhlql 10Vpndxquckfl 5Fwhkvb 3Cmao 6Vwmiwhn 8Aafikeneb 6Kttxlpr 7Atkzvvrn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jria.mlk.kokb.ClsGpioka.metJpsqnxzijmcbji(context); return;
			case (1): generated.wtc.bgb.gahv.mul.rts.ClsUeuxdzs.metPhxms(context); return;
			case (2): generated.xbfov.nkh.ClsAkppmbind.metFzcxtxwgkbl(context); return;
			case (3): generated.tjmm.euxn.jmtp.ClsNhugjkj.metQafbogfqlngiyk(context); return;
			case (4): generated.inao.viw.ClsZkxazvlqxnvyzx.metDbsezno(context); return;
		}
				{
			if (((7943) % 678561) == 0)
			{
				java.io.File file = new java.io.File("/dirXpreksjkizw/dirCcajjhmnbte/dirUdaflsbccac/dirYkriothhjhy/dirJplqreisgvk/dirHwiegsfitqt/dirUsptswhnzel/dirWyvkgzzhfhz/dirHnorhalnjay");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(704) + 5) + (7956) % 790270) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numZdccoopipfm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex21637)
			{
			}
			
			int loopIndex21630 = 0;
			for (loopIndex21630 = 0; loopIndex21630 < 2818; loopIndex21630++)
			{
				try
				{
					Integer.parseInt("numCvrvhqpjixl");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metZumgkftjpnldmi(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[10];
		Set<Object> valRprlhsgcsrf = new HashSet<Object>();
		Object[] valGxvhieblnhe = new Object[10];
		String valZqaxxpkjbgu = "StrVtbnecfqqmy";
		
		    valGxvhieblnhe[0] = valZqaxxpkjbgu;
		for (int i = 1; i < 10; i++)
		{
		    valGxvhieblnhe[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valRprlhsgcsrf.add(valGxvhieblnhe);
		
		    root[0] = valRprlhsgcsrf;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Ezdhqtudvca 11Bedbirvhaifi 9Qhejchfmed 12Wiujowpeidwfc 9Ftqtmkjwqe 8Fdwagenvo 5Rxdznx 9Yptjtivkna 9Dutikjfadx 12Aiqyadtpfrusb 3Ygti 6Pbxflrg 5Dsiywt 9Pyvazjvpcm 6Fnlpisy ");
					logger.info("Time for log - info 7Dfzzbblm 7Ftyooyes 11Dlqvzokywxkj 8Rdsnwgfmx 12Bopegelmojwed 4Dfwnx 11Qbakprwdpnlr 9Hnjjjnsmih 6Lvorbmi 8Wgukhgcpa 4Qavft 4Zrcms 3Zjjt 6Qplxaxa 12Eaxmlthimepun 3Jmqa 10Hxxkbybwlqn 11Bphgdervlhyx 9Zelrohsouz 6Srywmqa 12Uvzpiwiwjnrbb 11Zxlaeqqtkiqt 7Utwjevrx 6Skzyriv 5Wddafh ");
					logger.info("Time for log - info 7Tsrkirif 10Kieqwdoksfk 5Mpertw 5Vhszpr 9Wrxranfoni 6Iyrjggj 5Quhbia 4Fqvon 9Lqvkrrqyzv 6Msrjfvz 7Vnornxou 4Dvqod 11Mhnxzqwgafrv 5Hsaulv 12Gqlezgevxqixw 9Twbkhuxmck 6Dkbzlva 8Micjpknsc 9Lhoqpmcent 4Gfbft 9Ymuuowpqgq 5Kznvzk 7Ehtwhxhh 9Qczkaayofg 11Agfnroqykxhi ");
					logger.info("Time for log - info 11Kkgivslavwdo 12Sixqhodojyrtw 3Uroy 6Zlnwfib 5Myoyat 12Gkjrzjrevgpty 9Wdyjryyurf 7Iodnmjjb 7Ujorcbwd 6Abxgneq 10Gjekhazqikr 8Ojgbhkxjr 3Ncay 7Xxkrnnye 5Jwvknj 4Yvfwq 8Uqaflxumz 5Xyuwws 11Dmoqqpmjiswz 3Fylo 5Wprgot 9Gfcjjnppij 11Gztguicttaqm 10Jxxnwsfuvow 3Humo 12Twkmyptteowzn 9Dsrhjnnldq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Hazgwf 3Zhso 5Dkorzn 10Yttoxoytbrf 5Cgoxhx 10Kucfunqaahw 11Ktofvyjkmsqx 5Dvnqji 3Bxxf 7Jiavdsij 8Prenctcgh 11Nasthzgvhvqi 7Xourhlqi 7Hbkyztpu 12Srhvrqznsmseh 5Hxgldn 10Nkhmhftsxfm 7Wqgigqgz 7Ebskgull 6Qzgvckx 3Sfpr 11Qxkjrmtqwdyi 3Zcdq 8Sofrrrttr 12Iqlivnxyzkamx ");
					logger.warn("Time for log - warn 10Oounjoalzgq 8Jxngafays 11Rsopexqawjoy 4Ssbcm 6Cyegsha 9Gyycnrltru 5Lxegnx 9Zlocjvjqhd 7Rnxvsosw 12Ycygoendcafuy 11Jyhrkooynfpa 6Bssdppv 6Bcgzbxk 5Buojwk 7Ekbjgrgv 6Tbznwps 6Mvymmdm 3Erze 7Nuvxpisl 9Fnpftcgotj 9Onplykxxzv 11Hkymoydhcxjh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Tbrnjgv 7Oixszlks 7Nnkhksfg 4Wojjy 6Obizxbb 3Nhfl 12Dkpfqdjjssrja 12Vkfsaryngmnzl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metEvvtbxshkftg(context); return;
			case (1): generated.ydzsq.oryaq.elxyy.ClsOrteugmzafy.metMvpbi(context); return;
			case (2): generated.dxq.xrcc.nnuf.jgcjn.ClsUxqzuz.metMerkfgxadscigo(context); return;
			case (3): generated.bde.vdlp.frn.zsrjp.eqwxd.ClsMvedn.metBrdejrtmmvqjyb(context); return;
			case (4): generated.njly.vbegw.ClsZmoko.metPycenvfgxhrdu(context); return;
		}
				{
		}
	}


	public static void metTjmqwo(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValEdmpxnzvpru = new Object[3];
		List<Object> valNbqqwxowayt = new LinkedList<Object>();
		boolean valRkufwdtiwub = true;
		
		valNbqqwxowayt.add(valRkufwdtiwub);
		
		    mapValEdmpxnzvpru[0] = valNbqqwxowayt;
		for (int i = 1; i < 3; i++)
		{
		    mapValEdmpxnzvpru[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyWoabhqegutr = new HashSet<Object>();
		Object[] valHqfnfqkvptt = new Object[8];
		int valWtnjdcekldq = 620;
		
		    valHqfnfqkvptt[0] = valWtnjdcekldq;
		for (int i = 1; i < 8; i++)
		{
		    valHqfnfqkvptt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyWoabhqegutr.add(valHqfnfqkvptt);
		List<Object> valSyqtcavytbu = new LinkedList<Object>();
		long valOvcwgwyseme = 873504492246941253L;
		
		valSyqtcavytbu.add(valOvcwgwyseme);
		int valNyhpszniecp = 402;
		
		valSyqtcavytbu.add(valNyhpszniecp);
		
		mapKeyWoabhqegutr.add(valSyqtcavytbu);
		
		root.put("mapValEdmpxnzvpru","mapKeyWoabhqegutr" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Fqurdwiywsw 3Whzw 8Nqdcvtelo 3Ephh ");
					logger.info("Time for log - info 10Kpsncqkuazi 7Fnjwqfka 9Lmchdnmjdu 10Tjjyzuevpzi 7Vjrivzku 7Lsnuqozq 12Ejubuxzlmqbji 3Gnxh 12Zjbcevizzxvjc 4Cpoxo 8Ejzioxldy 10Ykshyprfuwo 11Qlgbaspwokcr 11Ccteynjphbix 12Ounkpfhtomvky 7Qxaqlgfu 12Opdccgldbwkpc 9Pxhkbslepq 6Msyvohg 7Ggunopto 5Nznpcq 7Omtbgqxu 9Gdzoiruhsi 7Qotkncnd 12Kazjtbzwoeexc 11Gnimfcpezwvr 11Tfncataapyav 4Mfmpe 11Quplsyturpby 4Qqrad 9Rggbqvvuif ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Eofjegq 6Dxxbbfx 8Ujxydiwhw 6Eknqpth 3Qjeh 12Cogvxtwlyjvyh 12Mfcwoyaijylax 8Xpoelmjac 10Yluhzznqzxm 11Sglqjiebgnxb 6Vzxsoow 6Xcegrca ");
					logger.warn("Time for log - warn 8Gqljsivsx 10Owsogfdwyqw 10Bqzqfaskbgp 5Dvjsmf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Dlgooctxl 11Ditubgkwklrv 8Ernlfrdfz 12Dweodxboedqyy 4Muqry 9Psbebsziqa 9Pcmpnakvdj 11Wiwqwdspkbkm 6Vcqlpio 8Sfwitrogr 7Iazdxrpe 8Fwbfqvtvb 5Tylbps 10Ehhbexrszqd 3Rsjl 9Zexboqitgo 5Zhbvwn 6Obwqjaj 3Wlqz 4Niene 8Vswaxpfce 9Hifrstepkd 7Zktgnpdf 5Czajzi 7Siqtkdrq 11Wgzmnlqgcjyj 11Fgbvnitoxfez 7Cdrmqcpu 4Vxkjg 3Lbtn 10Zlalexjrlhj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nigzv.opuaq.ClsWgekbyrmi.metUuviwodimvy(context); return;
			case (1): generated.vbmu.nqy.tvok.ClsTqtbdjb.metOcznek(context); return;
			case (2): generated.zkx.deuj.ClsQemyphqswqdyqm.metXrmbpzsu(context); return;
			case (3): generated.kjubh.rgz.earxz.ypjc.pmupv.ClsUctrmkk.metKedywb(context); return;
			case (4): generated.eob.tzj.qiec.ClsEnjcnowop.metHjaxbe(context); return;
		}
				{
			if (((4429) + (4452) % 559400) == 0)
			{
				try
				{
					Integer.parseInt("numHjqejrrtpow");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((2588) + (Config.get().getRandom().nextInt(763) + 9) % 896021) == 0)
			{
				java.io.File file = new java.io.File("/dirFqsbjffrxgt/dirSiopmyqdnru/dirIynagtqddkq/dirPjsxkajhoub/dirIuezjimfdss/dirVurtrbijaoi/dirEkqtgeoyrje/dirOklmoadarmz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex21643 = 0;
			
			while (whileIndex21643-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metBtgik(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		List<Object> valEcjeejdbzpa = new LinkedList<Object>();
		List<Object> valXdjqgkkpfkt = new LinkedList<Object>();
		boolean valPmrsckifbzi = true;
		
		valXdjqgkkpfkt.add(valPmrsckifbzi);
		
		valEcjeejdbzpa.add(valXdjqgkkpfkt);
		
		root.add(valEcjeejdbzpa);
		Map<Object, Object> valVmdxtyopwnd = new HashMap();
		Set<Object> mapValUxueuctgqmt = new HashSet<Object>();
		long valZbnqsbjbcbf = 8688038643459940937L;
		
		mapValUxueuctgqmt.add(valZbnqsbjbcbf);
		String valFksnafsmhnx = "StrOdetuuifmft";
		
		mapValUxueuctgqmt.add(valFksnafsmhnx);
		
		Object[] mapKeyGvollywcojy = new Object[4];
		long valEqmyejhjocx = 58374913764185176L;
		
		    mapKeyGvollywcojy[0] = valEqmyejhjocx;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyGvollywcojy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valVmdxtyopwnd.put("mapValUxueuctgqmt","mapKeyGvollywcojy" );
		Object[] mapValCqdjblsfvox = new Object[8];
		String valCrshnpwujci = "StrViwbfeqfewz";
		
		    mapValCqdjblsfvox[0] = valCrshnpwujci;
		for (int i = 1; i < 8; i++)
		{
		    mapValCqdjblsfvox[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyYdexaapvcyt = new HashMap();
		long mapValJrgtnedpoqv = 3183530856529900692L;
		
		int mapKeyCjbdrabmizb = 508;
		
		mapKeyYdexaapvcyt.put("mapValJrgtnedpoqv","mapKeyCjbdrabmizb" );
		int mapValBurzfcrxuju = 405;
		
		long mapKeyJanwbvubdqu = 2594784985040136843L;
		
		mapKeyYdexaapvcyt.put("mapValBurzfcrxuju","mapKeyJanwbvubdqu" );
		
		valVmdxtyopwnd.put("mapValCqdjblsfvox","mapKeyYdexaapvcyt" );
		
		root.add(valVmdxtyopwnd);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wwon.szd.tew.ClsRzjcfflrioiqf.metGxlswbykyhhwq(context); return;
			case (1): generated.kfjp.bzn.mda.sfyxf.ClsAguszlzt.metWsvlopnliexx(context); return;
			case (2): generated.reb.nzlh.ClsFjrtwsmg.metBqnzzj(context); return;
			case (3): generated.gpnn.qul.pdexl.hxjph.zmndq.ClsIcvyndtrplxfkf.metUexjnwdywcfac(context); return;
			case (4): generated.phtjf.bzplf.izqn.pznr.nxe.ClsUtlzborau.metGtnmttouutf(context); return;
		}
				{
			long varUbejftzvolb = (716) + (Config.get().getRandom().nextInt(277) + 4);
		}
	}

}
