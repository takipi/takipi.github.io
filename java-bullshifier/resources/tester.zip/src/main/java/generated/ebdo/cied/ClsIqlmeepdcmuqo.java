package generated.ebdo.cied;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsIqlmeepdcmuqo
{
	 public static final int classId = 459;
	 static final Logger logger = LoggerFactory.getLogger(ClsIqlmeepdcmuqo.class);

	public static void metBfionas(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValPomwvxlbfvp = new LinkedList<Object>();
		List<Object> valIscosqrentb = new LinkedList<Object>();
		int valKqeemlkonil = 610;
		
		valIscosqrentb.add(valKqeemlkonil);
		
		mapValPomwvxlbfvp.add(valIscosqrentb);
		
		Set<Object> mapKeyZjcgetjomnj = new HashSet<Object>();
		Set<Object> valRxkhobqxlnk = new HashSet<Object>();
		int valEkiopqlznup = 11;
		
		valRxkhobqxlnk.add(valEkiopqlznup);
		
		mapKeyZjcgetjomnj.add(valRxkhobqxlnk);
		List<Object> valGxtujlljzks = new LinkedList<Object>();
		String valIdevczelaed = "StrKthspspehpu";
		
		valGxtujlljzks.add(valIdevczelaed);
		String valAumykunpbhz = "StrUnugkampeip";
		
		valGxtujlljzks.add(valAumykunpbhz);
		
		mapKeyZjcgetjomnj.add(valGxtujlljzks);
		
		root.put("mapValPomwvxlbfvp","mapKeyZjcgetjomnj" );
		Map<Object, Object> mapValKyaehjaxrxz = new HashMap();
		List<Object> mapValAqpkpbznaoq = new LinkedList<Object>();
		boolean valVxpjjfxxvrz = false;
		
		mapValAqpkpbznaoq.add(valVxpjjfxxvrz);
		int valStbcltbntoj = 597;
		
		mapValAqpkpbznaoq.add(valStbcltbntoj);
		
		List<Object> mapKeyDbzvqgutmnz = new LinkedList<Object>();
		long valTtprbghflnk = 5586883343007732036L;
		
		mapKeyDbzvqgutmnz.add(valTtprbghflnk);
		String valEdevgaijlyn = "StrJtlnqnceahw";
		
		mapKeyDbzvqgutmnz.add(valEdevgaijlyn);
		
		mapValKyaehjaxrxz.put("mapValAqpkpbznaoq","mapKeyDbzvqgutmnz" );
		
		Set<Object> mapKeyRcnsfwefsex = new HashSet<Object>();
		Object[] valAsnmlgxzckk = new Object[7];
		boolean valPsgybywjwgd = false;
		
		    valAsnmlgxzckk[0] = valPsgybywjwgd;
		for (int i = 1; i < 7; i++)
		{
		    valAsnmlgxzckk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyRcnsfwefsex.add(valAsnmlgxzckk);
		Object[] valMibxmtzcbat = new Object[4];
		boolean valIjxwzsobarx = true;
		
		    valMibxmtzcbat[0] = valIjxwzsobarx;
		for (int i = 1; i < 4; i++)
		{
		    valMibxmtzcbat[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyRcnsfwefsex.add(valMibxmtzcbat);
		
		root.put("mapValKyaehjaxrxz","mapKeyRcnsfwefsex" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Kqct 10Pdnniqlkrtu 6Eybtgld 12Rknwqgqqyowab 5Tkqcgl 8Toyzhtxwu 3Pror 7Aqoduzvw 8Bpkekhjnx 3Lvwh 5Radurl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Xscsrfdkaf 12Tqwxhosyogupt 11Vxfdsnxlpyhk 5Vmpxqp 9Vqxxprkedr 11Hmtoiyoccqgv 11Cifzsetirrpq 6Rvgkivn 5Zmprvv 11Soimsdldmcdm 12Dqrqmftcdkgxq 7Lkylglyc 12Qdggsizahdess 3Nran 4Ettcv 4Iitce 9Hpgahliyhz 9Bmwnoietab 8Ejqrdcdva 9Tuxtzzausp 6Ltkhrtn 9Dbhowkbgbs 5Ixdjjd 8Cxwrwdopm 5Hruxpk 12Mmzrhzbfclwrb 8Rykkxmnwj 10Kfcpdcepurq 4Zrmiq 10Fhxxqdtpcnh 7Gxgknhus ");
					logger.warn("Time for log - warn 6Cifvhba 9Uizrzyatsn 11Sawatgojhrzy 10Hjpifzkessi 3Lpvu 4Foiuv 9Rhshsnghpm 3Jhzh 11Sytlbwgtwbuu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metEwxuvzwhpbpte(context); return;
			case (1): generated.pef.kybz.yzpf.dzs.obqpv.ClsKizvnatyigi.metVpeqkkprfd(context); return;
			case (2): generated.plye.kjczy.bmku.wrxrk.zek.ClsNtetu.metLbovgdo(context); return;
			case (3): generated.gmrwo.oumy.sahgj.zbppw.vqlx.ClsDexipe.metBsktjpxjygwoz(context); return;
			case (4): generated.gyic.epw.ClsQxhbkrqjzoqujk.metZjjvdqtoif(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(25) + 5) + (5286) % 520005) == 0)
			{
				try
				{
					Integer.parseInt("numHikrdgnldbi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((7034) * (Config.get().getRandom().nextInt(297) + 6) % 187035) == 0)
			{
				java.io.File file = new java.io.File("/dirKdwdtwrhjun/dirMpahtwrmjuj/dirCvdxwhmcnjj/dirIcujbzqrwig/dirQfdogwanqqk/dirJxhjtrvmxrv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varPbsynnzvhaw = (3203);
			long whileIndex27734 = 0;
			
			while (whileIndex27734-- > 0)
			{
				java.io.File file = new java.io.File("/dirPxyocfivsfy/dirLpvrycomdmj/dirGvepshdnmgv/dirIngpmyzzhqd/dirJgsderxobnq/dirRthvntodfud");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metKtzhn(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValWdpygecysjs = new Object[10];
		Set<Object> valYhighydukcm = new HashSet<Object>();
		long valMmsriomcgah = 1534024613847587077L;
		
		valYhighydukcm.add(valMmsriomcgah);
		
		    mapValWdpygecysjs[0] = valYhighydukcm;
		for (int i = 1; i < 10; i++)
		{
		    mapValWdpygecysjs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyUrsnzvrrqdi = new HashMap();
		Set<Object> mapValFfkojyerihg = new HashSet<Object>();
		boolean valEiuumypkqnv = true;
		
		mapValFfkojyerihg.add(valEiuumypkqnv);
		int valNaxxwsxwkgb = 916;
		
		mapValFfkojyerihg.add(valNaxxwsxwkgb);
		
		Set<Object> mapKeyEzisxxsjqtv = new HashSet<Object>();
		String valXqcekomkoqp = "StrWitzksyatww";
		
		mapKeyEzisxxsjqtv.add(valXqcekomkoqp);
		
		mapKeyUrsnzvrrqdi.put("mapValFfkojyerihg","mapKeyEzisxxsjqtv" );
		Set<Object> mapValUctxzxnqyrn = new HashSet<Object>();
		int valDawucjtxolp = 265;
		
		mapValUctxzxnqyrn.add(valDawucjtxolp);
		
		List<Object> mapKeyVxgzxtlrlaa = new LinkedList<Object>();
		boolean valRunleussnki = true;
		
		mapKeyVxgzxtlrlaa.add(valRunleussnki);
		
		mapKeyUrsnzvrrqdi.put("mapValUctxzxnqyrn","mapKeyVxgzxtlrlaa" );
		
		root.put("mapValWdpygecysjs","mapKeyUrsnzvrrqdi" );
		Object[] mapValOjoctgcpwkk = new Object[11];
		Map<Object, Object> valMieowmqagsc = new HashMap();
		long mapValUktfztnshvr = -5789917340182606967L;
		
		String mapKeyEtynildobua = "StrExrpyybcwgm";
		
		valMieowmqagsc.put("mapValUktfztnshvr","mapKeyEtynildobua" );
		
		    mapValOjoctgcpwkk[0] = valMieowmqagsc;
		for (int i = 1; i < 11; i++)
		{
		    mapValOjoctgcpwkk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyIlyeyoewber = new Object[4];
		Set<Object> valGqmgmsutmxn = new HashSet<Object>();
		String valTrrvqwocgur = "StrVgmkvmrrsvv";
		
		valGqmgmsutmxn.add(valTrrvqwocgur);
		
		    mapKeyIlyeyoewber[0] = valGqmgmsutmxn;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyIlyeyoewber[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValOjoctgcpwkk","mapKeyIlyeyoewber" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Pkwczdigqs 12Ssrfdtzcgvtdj 9Usmjpcvlev 9Xsosajrbic 11Tfwtzhsmbclx 9Rytyoemdsi 11Fwxqtjgmcczo 6Qjlpkur 10Pwnhvswwrem 10Arkelnhqmyt 5Baowhc 8Veqiggkqp 4Xswzb 11Acgyrtjnyphu 12Mlmvgqplggjdw 7Fwntzcot 5Cxsxky 10Digjeijwcpr 5Lhqrzi ");
					logger.info("Time for log - info 11Zhfzyhiatvpu 12Auaynyjxxgxrs 6Yhsfubd 5Pdqsvx 4Ihzxw 6Zwqyzxl 9Dkkkxcrffu ");
					logger.info("Time for log - info 8Ugwmzpaqi 8Qeybdagkl 3Khvg 11Fiqmmcrnbaax 3Rrvr 7Mdqxmxfn 6Mypfghl 3Dgeb 10Cypohheuudz 4Scdrr 4Sfaid ");
					logger.info("Time for log - info 5Ltvmym 10Pndrvnwsici 5Oqnmjr 5Kpjddx 3Ymyc 4Pklwy 10Jfmkcwpzxyf 9Zalmgokeek 5Bdgijz 3Qzwq 4Ifdnr 8Tehzturbt 5Qntcpq 5Clckep 6Rldbrrl 9Risngcbiae 12Htlnhpqzfgyxn 7Twhnjhqr 6Ekuwenh 7Arcgyrxk 7Ylxgayxi 9Yynjyxfpah 3Bjbe 9Vsmlabpyio 9Mpnpasspdr 3Jqaa 8Devrrxppd 5Dlinan 12Lgqbesnddojha ");
					logger.info("Time for log - info 7Ybgwiqyj 7Kgazjbye 11Wqqlqainuzsb 11Bjsdppphlnwr 5Ljecus 4Shscd 7Vebmkehw 7Cbglfsnt 10Nadnxayorka 3Kyaj 6Rfgabrz 8Sltdaajye 9Qbjigmusjg 7Mniwusyi 10Kaajgmmvshk 12Vapikcfruzrjd 10Dkkikaiybyv 10Ftkyxdybiml 8Iendzwukv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Uhtso 9Swqosbmzri 11Uueurbyvylga 3Vsba 5Lrkqrg 10Qnabmphsrxp 5Eextrn 4Buxiy 11Iuvktygvsaci 5Vzsyqp 7Xqmvpnnt 3Syxi 9Xmsuuvizwc 10Xgfqljzuntd 4Luqhj 8Hawmqgrmg 5Udbkby 11Cdcqsormaqaf 9Atdlnidmay ");
					logger.warn("Time for log - warn 6Xhulezc 11Lxvavbutnvgy 4Ygike 9Ftdnzmsjwp 6Chhbrmn 5Ztgdhx 9Wnsabqhmmv 6Huhkfxj 5Cykwot 9Lvriehkpuy 11Otalaicgnmjg 8Guooirzmh 8Trzxnjnsc 10Hqteivvmlga 9Pbuuuvdwft 9Gqmztkurtb 7Jgogxjph 12Emlyqcvpxqywi 6Jgtylty 6Tebexui 10Htyanjlqyqh 7Ohhorlqb 8Dpxkjhhrj 7Ieprcnqr 11Gazhqovjdrgo ");
					logger.warn("Time for log - warn 11Ocrxeutycdia 6Pbilkla ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Suglnqkhza 6Kwaigvb 12Bkhwxotloddjp 10Mfvjrbsyslb ");
					logger.error("Time for log - error 3Jdty 8Wwffpcewn 5Rgasdg 3Aaww 8Jiqhlscor 6Kkbllkw 10Xdjdlncgfbp 7Moxivaug 6Tqbreqc 12Zbfynwvcmgtbq 11Qigqyntonpqr 9Bdovtehpfb 5Kjoylv 10Omfsrsbyptm 7Sllidjyw 11Gdtlkikhgyqu 11Vuvrypdmfyao 8Itdokfqlr 12Gmszaffswmlea 10Lhjhwnogdmq 6Faokwxm 10Fqxzrymlwoz 11Jvhomamiqfgf 7Ijfxsmsc 4Yzint 7Mdjytxbr 4Knodu 6Xlavvgi 10Dunjoimgyql 4Mmily 8Pbmwfjvtw ");
					logger.error("Time for log - error 11Vvrefidkuzxn 5Lrwbcj 4Coezt 9Uzcqidjick 4Ejdey 4Ljkin 11Riwacrxliysx 11Dufiqvraybtt 3Lqdq 7Xyukzqly 12Dcxiyolmojisg 6Lldyoib 4Vphhq 4Uoybq 5Erxwvg 12Qortilsymdikn 8Agaqpchvd 10Vevjbxqskez 11Qfacerobmjjf 6Pcbnzwm 12Ipxipyxnjoqjp 12Sraprmsflbnqq 5Xxuqft ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metSqibhmdisq(context); return;
			case (1): generated.lraiq.fcmvy.qwp.rkzex.eokht.ClsJupuz.metWvwztkw(context); return;
			case (2): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metBninyradw(context); return;
			case (3): generated.erjvc.bth.rgln.usqa.ClsYyzexetbgpowz.metFvecfmslo(context); return;
			case (4): generated.hjt.myuvv.hkc.tfpi.ClsJfukwmizredp.metYduwrchx(context); return;
		}
				{
			long whileIndex27740 = 0;
			
			while (whileIndex27740-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varYfylznckxcy = (Config.get().getRandom().nextInt(965) + 4) - (Config.get().getRandom().nextInt(824) + 0);
			if (((3727) - (Config.get().getRandom().nextInt(61) + 0) % 773961) == 0)
			{
				java.io.File file = new java.io.File("/dirTkjnvvguswq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metBklcmfgo(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valGaijxqjkhru = new Object[3];
		Object[] valIwxcwhhillm = new Object[8];
		int valMrqeaauqatv = 673;
		
		    valIwxcwhhillm[0] = valMrqeaauqatv;
		for (int i = 1; i < 8; i++)
		{
		    valIwxcwhhillm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valGaijxqjkhru[0] = valIwxcwhhillm;
		for (int i = 1; i < 3; i++)
		{
		    valGaijxqjkhru[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valGaijxqjkhru);
		Set<Object> valSotdzyrrhdl = new HashSet<Object>();
		Map<Object, Object> valAafqurulztl = new HashMap();
		String mapValLepvbqipzbe = "StrVdfsnijplmg";
		
		long mapKeyYawdikpdwhn = -5946932646388136856L;
		
		valAafqurulztl.put("mapValLepvbqipzbe","mapKeyYawdikpdwhn" );
		
		valSotdzyrrhdl.add(valAafqurulztl);
		Set<Object> valNwjdzyfwzdb = new HashSet<Object>();
		int valAakqsaeltmk = 427;
		
		valNwjdzyfwzdb.add(valAakqsaeltmk);
		long valWvtzhvemcxd = 7735416298199919477L;
		
		valNwjdzyfwzdb.add(valWvtzhvemcxd);
		
		valSotdzyrrhdl.add(valNwjdzyfwzdb);
		
		root.add(valSotdzyrrhdl);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Btaovytw 7Dpeeqhpf 6Hnqumyb 4Buunw 9Imvcbscspr 11Gpnvfoamnesu 9Itsgbepbik 4Qguwn 11Ntucijdibbam 8Vljtoyyji 3Pbsh 5Ormgku 11Wjdbfqpedooo 7Fauqqwku ");
					logger.warn("Time for log - warn 11Sohjyhrvbwoj 10Jlcabqzsfad 3Bppx 12Xizjtpwiujeac 5Mcpcdi 6Hoqpmfv 12Qocikrwpftppv 4Nfidc 11Nhjyxmlwmtvk 8Uihtxjxbq 8Eddcbuwyt 10Uluhtbjudxi 10Warmlmzvuxx 11Ztylorozgpch 5Uhwtfw 11Mntxndmdojom 8Mpzjxhmsx 11Pqupvvgifkhd 7Ctypmwax ");
					logger.warn("Time for log - warn 12Frkjpjtwlcbwl 6Yeeqkae 3Hdjn 6Piqsmof ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Mfdhhcbvg 6Lzdrjef 3Nqkz 9Ugawfiyttc 8Xsuiyoijg 7Nwcdfzpi 10Timybpkdrbl 8Qdztmygoz 8Vqqlqsgvu 4Szozh 10Igjlrcijhmz 7Xhloclir 7Hjuahqae 4Tcizs 4Esjwr 3Ewhy 8Vefiyfejz 6Nqocwsi ");
					logger.error("Time for log - error 11Lmdthjgjqlpm 3Zwnl 11Tteuehjrxfff 10Roplaosykdx 3Kbuw 3Fpsk 7Gjkfyrcc 8Mvhzlhgyn 10Qwszqyulfow 7Tgiybzqt 9Qvcrwzfxxz 5Yhdjiv 6Zvxkznc 10Hvmykxrdmya 3Nfbe 10Yrrklezzhbc 6Vhntydi 11Ixmjjjzmgeqc 4Rjpmo 9Zrccffalls 9Bezvdlaqjk 4Xttgv 7Lzstmfjx 5Gytgoa 7Flvlgunn 4Mshga 11Gdxdjjqbzjwo 9Fqzkbysujl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lxeoh.qnh.crznc.ifldw.owge.ClsJaitfhoyoqqri.metElosoop(context); return;
			case (1): generated.ifyrm.rwj.ajr.gkqyg.ClsSfeshwgdectgpm.metGyotdudguzdcli(context); return;
			case (2): generated.hrks.gbo.qgg.fgvtm.ClsHtrpxdwwowcxea.metBfoddnchgjakj(context); return;
			case (3): generated.wtc.bgb.gahv.mul.rts.ClsUeuxdzs.metGmiqxl(context); return;
			case (4): generated.fpa.lsm.ClsOulug.metXlljtomhuljxyd(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numQchdksbgbha");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex27749)
			{
			}
			
			long whileIndex27747 = 0;
			
			while (whileIndex27747-- > 0)
			{
				try
				{
					Integer.parseInt("numJdvuaxjlogc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
