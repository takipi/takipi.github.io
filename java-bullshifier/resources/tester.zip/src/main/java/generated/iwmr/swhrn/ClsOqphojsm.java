package generated.iwmr.swhrn;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsOqphojsm
{
	 public static final int classId = 387;
	 static final Logger logger = LoggerFactory.getLogger(ClsOqphojsm.class);

	public static void metZarul(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valQfkqcrzphow = new HashMap();
		Map<Object, Object> mapValIcirucxzmlt = new HashMap();
		boolean mapValXfmwbmhgeai = false;
		
		long mapKeyAayopmbexru = 7501763859950023895L;
		
		mapValIcirucxzmlt.put("mapValXfmwbmhgeai","mapKeyAayopmbexru" );
		
		List<Object> mapKeyVjexhniutpj = new LinkedList<Object>();
		int valRdzsgbgpuod = 532;
		
		mapKeyVjexhniutpj.add(valRdzsgbgpuod);
		
		valQfkqcrzphow.put("mapValIcirucxzmlt","mapKeyVjexhniutpj" );
		
		root.add(valQfkqcrzphow);
		Object[] valXkbuzbqzwjm = new Object[7];
		Object[] valOyrhvijkazn = new Object[2];
		String valDzylwpmtasm = "StrVodwjkgrrhp";
		
		    valOyrhvijkazn[0] = valDzylwpmtasm;
		for (int i = 1; i < 2; i++)
		{
		    valOyrhvijkazn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valXkbuzbqzwjm[0] = valOyrhvijkazn;
		for (int i = 1; i < 7; i++)
		{
		    valXkbuzbqzwjm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valXkbuzbqzwjm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Baslt 10Mlgsqmhvgkc 12Qgozlydyvkczn 8Dczdbwoie 12Yaurjtmvanodg 7Gsdemjkb 7Adpxeaqv 3Uihp 3Tqaq 3Uzrf 3Beud 10Wxutiispwld 12Opvktccwovjmq 11Nmpvhdpynhbx 9Ookmqzrfnm 6Rghfejp 4Wqdsc 5Wsvqhv 11Oylluxdzpufb 7Preuacxz 5Nvshbx 4Qinzw 5Lnrscb 6Zenqnre 3Sakf 6Fysyveh 7Dhvseeqq 10Inybbogvqlj 7Bniykroc ");
					logger.info("Time for log - info 7Nxdbowgh 5Ngbpgn 9Rzbvrkrqxq 3Xund 8Aokwbrock 4Ysxsy 4Hxgrb 8Cowvhvlzm 12Crkybgdiqaosg 12Xfnimmxvfnaft 10Oinqoigpdim 8Nrujnlxqf 4Ckngr 12Yyivtlwmxuanv 12Ezgkorfapiurk 10Dzsxtroaeuu 8Epmkhdizv 3Afxn 12Thrqgugrmrpyo 4Owhvc 3Pset 11Ghgfkgqpbgex 5Fpujsf 12Lpnhjhobmctyc 9Fqmiegwysm 6Tmgguho 9Liapfhgzqn ");
					logger.info("Time for log - info 3Dgdl 6Rpzdiec ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Vsiyicbr 8Iujwvvezj 6Rvelany 4Juagu 4Vknph 3Szvl 8Fpoqebpre 7Wmugsqgi 6Kntuakv 10Grcajzbbefi 3Vtgl 5Wactve 9Hkjkykegtd 9Icwfcdwjzk 5Elsbvc 7Hmlpkxdw 4Wipfd 10Udpgoihctig 11Ldffcnhafkud 11Dcawwrrmxzrr 4Rdgoj 10Inrclhamtxs 5Spiktr 12Jkftlycmajbmh 7Jfmuhhrx 9Rngjrxfyoh 5Wnoswg 7Ogkylpjw ");
					logger.warn("Time for log - warn 3Psou 5Skektr 3Hbym 8Oflfzfrbs 10Qrjlfcsblzq 12Fgkqrwhejjnce 8Kpvlldnzd 9Gtfqxiiujx 12Hnkhrepvohxxv 10Ivewcwrhrcn 12Yyqlxyflbrkxt 6Xqdoomx 6Yvurbbr 5Kwxowh 4Yeixv 5Corpzt 4Haled 12Fzmnhqphxztrf 6Auvxjtr 11Jnwfepdbhamf 3Bqtm 6Fcosnnn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Eomyfs 6Gvuswuy 9Zfhreyxtmt 4Hoszv 5Iseqbv 10Qkmylqwwshy 4Pmlxg 11Pdndmschyryg 7Qvozjsfq 12Hxylzlirwprdv 5Kylekg 3Cbms 9Ewzbqzfhca 5Jqvlpn 9Nsdcoqruff 3Nleu 5Ukybtu 3Veob 7Wnldiemq 12Jawxahgffkczv 6Bqennqm 11Uerhxpczatyl 8Vctdauhax 11Mgimisymjzke 6Luwanvk 4Eqzqn 5Vfrbxa ");
					logger.error("Time for log - error 10Svaigtgdjwq 8Ebgvhwubi 7Nryyparu 9Ltbekkafmp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lxrj.lts.csk.iew.ClsCagmzsja.metOondcg(context); return;
			case (1): generated.qrzc.frg.utv.itv.ClsGoyvsxo.metOllflngqrpzh(context); return;
			case (2): generated.eob.tzj.qiec.ClsEnjcnowop.metRglvwndsjd(context); return;
			case (3): generated.qnmn.narfk.rdhdk.ClsPtwatcpapj.metSoquexyw(context); return;
			case (4): generated.hcdlq.enxjq.kqzt.pmk.vuc.ClsMdkbzdmkjxcf.metWuruvmffywn(context); return;
		}
				{
			if (((8405) % 899498) == 0)
			{
				java.io.File file = new java.io.File("/dirBzoejxpgwjp/dirCozfbwblogn/dirTotblckjety/dirVgdvzjulski/dirQiiapbttodj/dirEcsggikhvdl/dirQdnnxnqpqky/dirCztzgjjgbuf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(984) + 9) % 529695) == 0)
			{
				java.io.File file = new java.io.File("/dirEpkikqraqkw/dirLpuelsfkgbs/dirIwzndlvrdcx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metZpnazknfwlswat(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[10];
		Set<Object> valFfwbqldyblw = new HashSet<Object>();
		Map<Object, Object> valHvybxwgebaw = new HashMap();
		String mapValWqgcommdorh = "StrKsgbedplmyf";
		
		int mapKeyPwlptryjabu = 204;
		
		valHvybxwgebaw.put("mapValWqgcommdorh","mapKeyPwlptryjabu" );
		int mapValVwoitbfrpcj = 185;
		
		boolean mapKeyQisyjouljzm = true;
		
		valHvybxwgebaw.put("mapValVwoitbfrpcj","mapKeyQisyjouljzm" );
		
		valFfwbqldyblw.add(valHvybxwgebaw);
		Map<Object, Object> valNvqwbiihnib = new HashMap();
		long mapValGlsxhxaifjw = 6959260748006501204L;
		
		String mapKeyKjuaylnndpa = "StrRldtbnmdecz";
		
		valNvqwbiihnib.put("mapValGlsxhxaifjw","mapKeyKjuaylnndpa" );
		String mapValZgueupmnkeu = "StrWocxpcstxxh";
		
		int mapKeyKswuhakasss = 225;
		
		valNvqwbiihnib.put("mapValZgueupmnkeu","mapKeyKswuhakasss" );
		
		valFfwbqldyblw.add(valNvqwbiihnib);
		
		    root[0] = valFfwbqldyblw;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Ioffhfhpy 10Lqhvadznrqn 4Frdsf 12Tovbldmtmzwlm 4Embxm 9Rlwlvexgbk 11Ueimffhcsjwg 7Nplihfnp 10Pdmolprxtpk 3Xtxg 10Qbwthiiqruh 8Vssctmxcl ");
					logger.info("Time for log - info 12Makihoonbailr 8Dokciklyi 7Uclbnxnl 10Xnpsabluoks 3Zdob 12Awyprtzxenreu 8Lobkybjsw 3Aaah 7Fdzzhohr 4Basdm 12Yrxepkuamxlhj 6Muatyol 3Wlqg 5Znbdag 6Stsewzd 3Fmvq 10Ooddxgwfjto ");
					logger.info("Time for log - info 6Nzwjfjg 3Cobh 7Nqayzwqr 4Vbzou 5Thksms 6Ibazqun 10Ejisxtebmxl 12Alnxojmrcuayi 9Mhfmtxuqfj 9Rovhtjqnla 7Aabcjejx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Dxefeehi 9Dbpghrgull 8Xnpwsmifw 9Crmcffgbis 7Isbrnghz 5Pcwyad 4Odoqm 7Zevuknsd 5Sshdyy 11Oiikrlyjvklo 4Metbx 7Rfwhamuz ");
					logger.warn("Time for log - warn 8Xxtdtsgpb 10Twccdvvhyas 5Dnkmfp 10Gbzirutuadj 9Uwtjvmtkwn 8Xgxpgotxd 8Lvxniqcqs 3Ibxx 11Fsnegzqnzxqa 11Buwszpsuxcxe 10Nbpvkqnbisd 10Zddlucjxkip 10Trpckzbnemn ");
					logger.warn("Time for log - warn 8Hnfcrgdkh 10Pbkgnjopeei 4Ulhbk 12Dwxinbrmalwqf 5Likelu 9Lokoojhofk 4Gqnvc 3Nkst 12Hpolrnibsqvyd 5Elcpaj 5Jndseg 10Wlcvcgmdvus 4Brlnq 5Lmiksy 12Eybapniqxhvzq 11Aekhrhqbtehj 3Bfua 6Mthrdpf 4Comff 8Brvkzemkt 4Olami 3Lykd 8Wdpubqgyp 7Xrzkuxde 7Wsacklgf 11Zusdqvxvrpru ");
					logger.warn("Time for log - warn 3Lxoe 7Bwwjaxcz 6Vfwovri 10Tsxslkizuwh 3Jmgm 3Uthb 12Lpnupvckstcuq 3Xjwr 9Pwruydwnxx 10Sysvjmpbbkh 7Skxgxtkn 12Lfpmrrfplezhb 6Prlnrjs 8Vuubvtmnw 8Qdlczmqhc 7Kaiatzjt 11Thpnyalhedxb 8Wzhwiesvc 11Onojysosqemx 3Smna 12Lucxtrjedmfje 6Fptmpmg 8Nsguwocmf 10Lskhlosmsqr 9Zrexotitlu 5Iinjis 5Ykyhqh 7Hqloanww 4Ikzsp ");
					logger.warn("Time for log - warn 11Wvjukvqvcfqe 6Skxyhtu 5Twjzit 4Atnts 6Evwxytg 4Rlxoe 12Dwpaoxtxkoobm 9Driycffjgx 11Sofsjypxbbrn 4Prwhp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Lwvmwztgnxjr 6Cczkrbz 12Ohsbdtxcmfhmj 7Iglnljxb 11Sndxrtptadzj 5Wvnivv 11Wgljvcsredos 8Aglhzoakk 7Jixoazpo 3Qpal 4Sghnc 10Dqpmhtognhc 5Iaqtfh 3Qeho 4Zuvtr 9Yvwopxphft 11Eejxphwxxroo 11Unpzhpqllkrv 11Vzqhqhpuvmeq 11Lxqjuucimavt 7Gsnlrebi ");
					logger.error("Time for log - error 9Pgilbkzngv 9Bqemqbbajo ");
					logger.error("Time for log - error 10Amilpdykszb 11Znveqehuyuxc 12Iqvxuldhcgbgl 12Dumhtgyjasklo 3Dglk 8Hczeulrgv 10Xmbxmipmjul 6Iqjdckb 10Gpwsiikwhcm 5Lzirgf 12Jsanthnwogowf 11Aeheahtwwfwf 3Lezp 6Uhhbkzs 3Gakc 11Zubvhbvilgen 8Oagfcsegq 12Ozclfzkgbtvvr ");
					logger.error("Time for log - error 10Uxfpoigwzdm 9Yjfzhhfink 10Sewzygstoqq 4Llbaw 9Fnsblfmxoq 12Ypmbnbrhyeuao 5Igwaxq 10Ejvhsrawkpy 7Joisdxpt 10Qytcmacyncq 12Txertcgeoocyw 4Azzmr 5Jukyrj 12Zpnxfzkcgnxjl 6Uwvtevn 4Gsmez 4Kphdi 10Eujbmrzsvxy 10Stodwfkfgnx 3Qvhw 5Ptbgpq 9Qebivaoaer 3Pgbk 3Uuup 12Hlnrpdutqxgvq 5Mmfgbd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tcf.quma.ClsZzrrflp.metZjejbmakhczdx(context); return;
			case (1): generated.kjubh.rgz.earxz.ypjc.pmupv.ClsUctrmkk.metKedywb(context); return;
			case (2): generated.xqnb.haff.rrb.lurge.ygwj.ClsNrgsacrzyefzg.metXouqbpti(context); return;
			case (3): generated.hvqh.qdnb.tawyn.ClsAaddylg.metCsnugb(context); return;
			case (4): generated.mpex.dpd.nziyl.ClsMvkjogpaegzqh.metCcluioiaauedgi(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex26570 = 0;
			
			while (whileIndex26570-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex26571 = 0;
			
			while (whileIndex26571-- > 0)
			{
				try
				{
					Integer.parseInt("numQnzvtfvlfqk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metNpqoceezgx(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValTwrruohvgaw = new HashSet<Object>();
		Object[] valCxvxvtfvknh = new Object[5];
		boolean valEcmoucltzfk = false;
		
		    valCxvxvtfvknh[0] = valEcmoucltzfk;
		for (int i = 1; i < 5; i++)
		{
		    valCxvxvtfvknh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValTwrruohvgaw.add(valCxvxvtfvknh);
		
		List<Object> mapKeyCenxeezhtnz = new LinkedList<Object>();
		Object[] valYegwhidhuka = new Object[6];
		String valXugetknbady = "StrNrswexkccpf";
		
		    valYegwhidhuka[0] = valXugetknbady;
		for (int i = 1; i < 6; i++)
		{
		    valYegwhidhuka[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyCenxeezhtnz.add(valYegwhidhuka);
		Map<Object, Object> valUbvshwbjqli = new HashMap();
		int mapValKkgvjxdrkeh = 911;
		
		boolean mapKeyReizzwrxxva = true;
		
		valUbvshwbjqli.put("mapValKkgvjxdrkeh","mapKeyReizzwrxxva" );
		boolean mapValPcvgabqfzvp = true;
		
		boolean mapKeyDrsjrfiorwe = false;
		
		valUbvshwbjqli.put("mapValPcvgabqfzvp","mapKeyDrsjrfiorwe" );
		
		mapKeyCenxeezhtnz.add(valUbvshwbjqli);
		
		root.put("mapValTwrruohvgaw","mapKeyCenxeezhtnz" );
		Map<Object, Object> mapValBspfqlwcaib = new HashMap();
		Map<Object, Object> mapValIenvlogfmiz = new HashMap();
		long mapValLitkvcohtby = 4507548841326337661L;
		
		String mapKeyCnapxiqgois = "StrFpuphvnuqzj";
		
		mapValIenvlogfmiz.put("mapValLitkvcohtby","mapKeyCnapxiqgois" );
		int mapValRbjksrjjluq = 34;
		
		int mapKeyCfswpbavkup = 104;
		
		mapValIenvlogfmiz.put("mapValRbjksrjjluq","mapKeyCfswpbavkup" );
		
		Set<Object> mapKeyStanolvicgh = new HashSet<Object>();
		long valPseieeepvpi = -7971822506285792048L;
		
		mapKeyStanolvicgh.add(valPseieeepvpi);
		long valUbszikrwrpm = -1203930217649383784L;
		
		mapKeyStanolvicgh.add(valUbszikrwrpm);
		
		mapValBspfqlwcaib.put("mapValIenvlogfmiz","mapKeyStanolvicgh" );
		Set<Object> mapValXqvccvefpxf = new HashSet<Object>();
		int valMbzgbuvysym = 706;
		
		mapValXqvccvefpxf.add(valMbzgbuvysym);
		int valSgraemyjdqb = 551;
		
		mapValXqvccvefpxf.add(valSgraemyjdqb);
		
		List<Object> mapKeyAdtfszamuiu = new LinkedList<Object>();
		boolean valPxkpucmiuso = true;
		
		mapKeyAdtfszamuiu.add(valPxkpucmiuso);
		String valYftelbtnjex = "StrYffqiwigmti";
		
		mapKeyAdtfszamuiu.add(valYftelbtnjex);
		
		mapValBspfqlwcaib.put("mapValXqvccvefpxf","mapKeyAdtfszamuiu" );
		
		Set<Object> mapKeyXbfobclgkvf = new HashSet<Object>();
		Map<Object, Object> valQkxafgopnbv = new HashMap();
		int mapValOtvgsfeggzl = 382;
		
		long mapKeyLiwdimrposd = 7965146569133448001L;
		
		valQkxafgopnbv.put("mapValOtvgsfeggzl","mapKeyLiwdimrposd" );
		long mapValBtjbzavwzef = 6738578920549768477L;
		
		String mapKeyBoeuqlpwrvz = "StrYibezjcojzi";
		
		valQkxafgopnbv.put("mapValBtjbzavwzef","mapKeyBoeuqlpwrvz" );
		
		mapKeyXbfobclgkvf.add(valQkxafgopnbv);
		List<Object> valOuwyezxameh = new LinkedList<Object>();
		boolean valKitvpahmfew = true;
		
		valOuwyezxameh.add(valKitvpahmfew);
		
		mapKeyXbfobclgkvf.add(valOuwyezxameh);
		
		root.put("mapValBspfqlwcaib","mapKeyXbfobclgkvf" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Gmom 4Sociy 12Icoainrdckuei 11Lshxcgjvtygy 11Phlffqhflimc 6Zperhjf 10Yelzrowhaiz 12Egznbfzbostyp 11Itwcvckebcav 7Uiiyoxfq 9Miltobssob 10Uhxveosbzzw 5Mdagoi 11Pmvmqitbgope 6Mdxnars 12Kywmysleteueu 7Jrswzizn 4Bhocg 10Zvuuvxxbjup ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.psl.vgj.rgm.ikl.ClsWqomoi.metExquakcyim(context); return;
			case (1): generated.gxto.nwin.jagvj.ClsIsbtgkhpotpu.metArlow(context); return;
			case (2): generated.dbr.dvpj.ClsKgmhp.metVaplmoyavlsjm(context); return;
			case (3): generated.avme.rnc.ClsUgqeozcqx.metIsegbgah(context); return;
			case (4): generated.rnivz.zhh.uhei.req.ClsPtwayhomjjn.metIvavionsx(context); return;
		}
				{
			long varBgpveqckbdj = (2978) - (4739);
			if (((Config.get().getRandom().nextInt(299) + 9) + (8436) % 723152) == 0)
			{
				java.io.File file = new java.io.File("/dirQnpfowhuaob/dirQaezkfxifki/dirQlrbonxzfra");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex26580 = 0;
			
			while (whileIndex26580-- > 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metAtffyacmyd(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valNrdhfiryxvh = new HashSet<Object>();
		List<Object> valIaznhdqznnc = new LinkedList<Object>();
		int valDztehzlfbsv = 508;
		
		valIaznhdqznnc.add(valDztehzlfbsv);
		
		valNrdhfiryxvh.add(valIaznhdqznnc);
		
		root.add(valNrdhfiryxvh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Kgfdwwb 9Tqevjlqtuq 7Btdcspji 9Oabykftzcg ");
					logger.info("Time for log - info 9Duuxahnozx 6Wdaiyva 12Ecxvcualjuune 10Uunozjvlivm 8Fybthcbos 8Ajdyhbtva 5Mcrkkt 10Tesjtlqalup 5Buswsw 4Gozks ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Tpdrrg 3Auci 6Crobfyw 8Houluwcop ");
					logger.warn("Time for log - warn 8Luadcnzcz 12Sacfudpujebje 10Claznqawiul 8Jfohxoibo 4Yfyol 6Elfzdop 4Xpsgh 8Qggpusqox 4Smgft 3Yynw 11Doxxcszimmnh 9Ianiiazpwc 11Ovqprwkoqzou 11Ifnortynjhgb 5Dnruun 6Rquqqmb 10Nnqgqinbnpg 7Zneevqxj 12Pseabzzbgkked 3Qjsf 9Uomrozuwnl 4Pvaui 6Lephmnk 9Zfobigfdku 7Ondlshwb 6Mdizygt ");
					logger.warn("Time for log - warn 11Wghnjvbyztda 3Ycfu 4Wkcoi 8Adqwdyrwn 5Qtthoe 6Xjzzuxk 9Fsaqqtjnkv 3Vtda 4Kxlol 7Jynfqlyz 3Bprz 11Wlkifahjjvdc 6Krpbobj 4Ljful 5Upiuod 4Mgjnb 11Esjjqmqwjdoy 11Wepdtogutaqd 5Duogcy 3Vyay 9Qtdlvnfvfl 4Whtgb 3Psqi 7Vjjzppdl 5Eylnxt 4Vnfpq 12Vsgbebwwakdee 7Zgdyhkbq 10Iozxefvmhvq 5Ciyxwc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Jlhnscqwofim 3Bbvy 8Jmkxnsqxc 3Wtnw 7Ratqxsym 10Uucfuhpedmj 9Msbsxqcovp 4Czhja 4Airyd 7Gfwolcuz 5Ueirer 9Quwvksyzmx 12Ytxrfdadppvqw 4Rawrr 5Sskmic 11Znvoupgtlnnl ");
					logger.error("Time for log - error 8Nwfnldxok 10Cdargspoelo 3Pces 8Ojljnbhlb 12Jrtxavqqfgfhn 11Zkvoyvourigt 3Wslu 10Ymwzjjiiwwg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metSkbraqotkaceil(context); return;
			case (1): generated.zfv.ypwo.wuncq.ClsFveqnpanl.metApyyqiuohqp(context); return;
			case (2): generated.xbfov.nkh.ClsAkppmbind.metCoxqxndopdgbb(context); return;
			case (3): generated.vfomk.ywmw.ClsYphqbuncz.metMivehrooaiow(context); return;
			case (4): generated.bvvh.vrkq.ClsCiivqtifsuv.metBcfndjmmnf(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(65) + 3) % 745162) == 0)
			{
				try
				{
					Integer.parseInt("numIlrnemjraiy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((5606) % 893228) == 0)
			{
				java.io.File file = new java.io.File("/dirFmtxuymzjvc/dirAzlyjowjorv/dirEarfvsyqfzm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numSxpcqtjedxr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex26593)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirBhetmjenyuf/dirHwdkzxpitdo/dirFmuucibaalx/dirFtfwhsuvbkt/dirZwzktakyfsn/dirNwwnqldxkut/dirChbjbluufgs/dirOribeufpdys");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex26597)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
