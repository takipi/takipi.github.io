package generated.ymhs.ivq.mlr.cezkl.gzyiv;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsKvdrph
{
	 public static final int classId = 422;
	 static final Logger logger = LoggerFactory.getLogger(ClsKvdrph.class);

	public static void metIszbhwn(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValRcqsfxcwpne = new LinkedList<Object>();
		Object[] valUpzblcpozfy = new Object[6];
		int valDtzesmraueg = 35;
		
		    valUpzblcpozfy[0] = valDtzesmraueg;
		for (int i = 1; i < 6; i++)
		{
		    valUpzblcpozfy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValRcqsfxcwpne.add(valUpzblcpozfy);
		Set<Object> valFqkzvbaevgs = new HashSet<Object>();
		long valNrvddihvbkc = 1902852362812162679L;
		
		valFqkzvbaevgs.add(valNrvddihvbkc);
		
		mapValRcqsfxcwpne.add(valFqkzvbaevgs);
		
		Object[] mapKeyVxmivwblzdu = new Object[3];
		Object[] valMswrbokdwad = new Object[2];
		String valQvziypkznam = "StrKbxluchntsw";
		
		    valMswrbokdwad[0] = valQvziypkznam;
		for (int i = 1; i < 2; i++)
		{
		    valMswrbokdwad[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyVxmivwblzdu[0] = valMswrbokdwad;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyVxmivwblzdu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValRcqsfxcwpne","mapKeyVxmivwblzdu" );
		List<Object> mapValGkwvaksvrer = new LinkedList<Object>();
		Set<Object> valGgeopzvqvxy = new HashSet<Object>();
		boolean valWvkxnlhzroz = false;
		
		valGgeopzvqvxy.add(valWvkxnlhzroz);
		
		mapValGkwvaksvrer.add(valGgeopzvqvxy);
		Object[] valMvfjekuephk = new Object[2];
		String valEdnscbpzfee = "StrGjmuuturzbu";
		
		    valMvfjekuephk[0] = valEdnscbpzfee;
		for (int i = 1; i < 2; i++)
		{
		    valMvfjekuephk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValGkwvaksvrer.add(valMvfjekuephk);
		
		Map<Object, Object> mapKeyGyvqdcnjxgu = new HashMap();
		Set<Object> mapValKmtmvfcjopj = new HashSet<Object>();
		int valPrrbkpuuqbw = 434;
		
		mapValKmtmvfcjopj.add(valPrrbkpuuqbw);
		
		Set<Object> mapKeyPwvvovwcjuo = new HashSet<Object>();
		long valNgviqipwtdd = -5008486708615368700L;
		
		mapKeyPwvvovwcjuo.add(valNgviqipwtdd);
		
		mapKeyGyvqdcnjxgu.put("mapValKmtmvfcjopj","mapKeyPwvvovwcjuo" );
		Object[] mapValQrmzdaaqgfg = new Object[3];
		int valEsrmsmnxopx = 82;
		
		    mapValQrmzdaaqgfg[0] = valEsrmsmnxopx;
		for (int i = 1; i < 3; i++)
		{
		    mapValQrmzdaaqgfg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyPraezjsszec = new Object[4];
		boolean valIzxflmipfwh = false;
		
		    mapKeyPraezjsszec[0] = valIzxflmipfwh;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyPraezjsszec[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyGyvqdcnjxgu.put("mapValQrmzdaaqgfg","mapKeyPraezjsszec" );
		
		root.put("mapValGkwvaksvrer","mapKeyGyvqdcnjxgu" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Cmbzou 6Dacgzwc 4Zkouu 5Bsyxoj 9Ogosrdmhwb ");
					logger.info("Time for log - info 9Aryyxsfcfg 12Ivvqcznwjepvg 5Acsdug 8Brxvtllhp 12Bfskkszhecvxq 11Vcnhqqymnhsg 4Maljc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Ptbmc 10Acculzpfgsr 12Hgtthgaqxqvqg 8Edlifalzf 3Dfuc 11Skheptulbybq 3Pety 11Aiabmoyicblv 6Lblbzpi 3Gajz 10Dotmiqcdikd 5Fqnwqv 4Hfxhi 4Onoib 10Dlsqrldzjrq 12Dfimlpsspsljx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Bftgjkt 9Hauawhxgyl 7Rhjgkmui 7Ddmbwmbb 10Lsnerjaejid 10Wfklsgvrpbt 7Yphgpyhw 8Aaerfqisg 7Uaxmhqqq 10Sgjmpjwnldm 3Lcyt 10Dctvdlvhtzt 8Dltgyffuo 10Fxpxwekyzbl 7Usnyokye 12Jrwzcyjnbxqce 11Aqmeglosewhd 5Vsgxjv 9Wavwktiooq 5Mmzkxu 8Cmbgtkhsd 8Awddvgmys ");
					logger.error("Time for log - error 10Epckfhtxkal 11Ibvscuaoetzv 6Dijyfbg 9Xxphxtqggf 4Ogdht 12Zmmvnehgjsnky 4Obkdo ");
					logger.error("Time for log - error 10Nompbbkmcua 6Vwdezje 6Abweekw 11Zvwzhopykrgw 9Vsiivtyblo 4Uzlsu 11Dvnbhksxifie 7Bzuqwpyk 5Ahpdfz 8Vpwennhic 8Aclvnyxts 3Nzaw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wkucr.ukst.umm.xsqx.ClsEjxfeypurpufwd.metWmlpl(context); return;
			case (1): generated.igif.laylf.mnwo.ClsOgradyyhp.metWmilrdjs(context); return;
			case (2): generated.fpitj.gxmf.ClsSfcuawq.metDngtubno(context); return;
			case (3): generated.pzq.iab.mjtpw.ClsXnxmjl.metNioiwefosyl(context); return;
			case (4): generated.siinn.hrk.mef.ClsDcfbqxc.metPlpmmksy(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(152) + 4) - (Config.get().getRandom().nextInt(197) + 0) % 585126) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((Config.get().getRandom().nextInt(69) + 5) + (7672) % 953950) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((7185) - (Config.get().getRandom().nextInt(422) + 5) % 158023) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metHojjbkdvq(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[7];
		Map<Object, Object> valNsicqtviimp = new HashMap();
		Map<Object, Object> mapValIzxipkydtui = new HashMap();
		long mapValIiukzbgyzil = -4853850674537555696L;
		
		long mapKeySolzcgdvhfd = 6097325737841280101L;
		
		mapValIzxipkydtui.put("mapValIiukzbgyzil","mapKeySolzcgdvhfd" );
		
		List<Object> mapKeyLxvhxddgzzh = new LinkedList<Object>();
		int valXastukzbqku = 232;
		
		mapKeyLxvhxddgzzh.add(valXastukzbqku);
		
		valNsicqtviimp.put("mapValIzxipkydtui","mapKeyLxvhxddgzzh" );
		
		    root[0] = valNsicqtviimp;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Dodeqhw 4Brxlh 8Vqivlqmbr 12Mcugvjzgenhas 11Gzuweanmoeed 4Sbybn 3Eqsc 7Funzpqrm 5Oquhyg ");
					logger.info("Time for log - info 9Htxtowjgug 4Fiooz 4Ouuga 6Rzlxzmc 12Eqfpuicrrcqxt 9Lmxqejfmrz 7Ypslamvk 4Lpiiv 11Ysrjhvcaiuoc 11Xhckkxdplvmq 12Vlyyplbxkqezs 8Ckqbsvsxg 12Patfybiguxcnb ");
					logger.info("Time for log - info 8Gkxsuqsno 5Ecptdf 12Leocfwgtnzymd 6Abxtgek 9Nmbnyonhye 9Yjrqbsuzoh 8Mnjvlaonm 11Yvvebxztpcrc 12Nfvhtniespyck 5Llknop 7Zvyocnfw 11Jkyecjmpommz 9Ruutypeoqq 10Bpcixmsfhte 3Hwfa 11Omztgmrlvvek 12Zefrqepqoarlx 6Rhlvfqi 3Vroj 3Izao 10Adnhhomebfq 5Bsqsno 11Nlbmywuifxrr 4Oucpr 6Oeoixym 5Tsceqq 10Hxvlguywtpf 10Smglimsetve 11Qqjkrqhlxcmt 12Hrrdirnhteiyi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Jhtirr 11Qiyxzxnqsfwh 6Nickpii 7Gfqpvpqd 8Frvelofmx 6Cfiuwyy 6Onsvblc 12Fcwesvbvhunif ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Jwgr 6Qxhizsq 5Lmxjti 5Usggkq 6Xnkepzd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ryyqn.hafq.oqfv.ClsRsktinox.metAtshswjvgunkn(context); return;
			case (1): generated.zdmfw.qfic.ClsQmanwrctuzecr.metEvpjjip(context); return;
			case (2): generated.krka.pbdp.kxfhk.gqt.tfv.ClsAdvwmtrn.metGbpohttt(context); return;
			case (3): generated.afba.qbfns.sure.ykux.syv.ClsCqlibdmm.metYjsgjmdmtzt(context); return;
			case (4): generated.flwv.kjeus.ClsAhjobcsyb.metMaqmdna(context); return;
		}
				{
			int loopIndex27087 = 0;
			for (loopIndex27087 = 0; loopIndex27087 < 432; loopIndex27087++)
			{
				java.io.File file = new java.io.File("/dirSbesosbifvr/dirBoefpsmcubx/dirEjcpdtaqedq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metXevuffadmfcuxi(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[9];
		List<Object> valRzfslmsntqa = new LinkedList<Object>();
		Object[] valMbebhuoyvfj = new Object[9];
		int valCcemvqfbtun = 427;
		
		    valMbebhuoyvfj[0] = valCcemvqfbtun;
		for (int i = 1; i < 9; i++)
		{
		    valMbebhuoyvfj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valRzfslmsntqa.add(valMbebhuoyvfj);
		
		    root[0] = valRzfslmsntqa;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Egzy 8Hywuxytpr 3Igsk 12Azdldejnxoaxx 12Xtxevhokvnmzq 11Fnxcwagbgofw 10Eflzpxobifj 10Cimvfsseoub 11Wfhrwqqnvaxl 12Qfswtavyvknct 9Wfcnduaboe ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Vcvglqvxs 6Usfzjak 8Ujslqbnen 9Qpzrjkznzp 10Balonhvmgkb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qpya.todk.woo.rrzxr.ClsQlmcomguvtqu.metVbgwaaycr(context); return;
			case (1): generated.ebdo.cied.ClsIqlmeepdcmuqo.metBfionas(context); return;
			case (2): generated.ajbel.dvbe.pmx.gfhen.qjvpo.ClsFwkvrnv.metXipxiwvyvncxvi(context); return;
			case (3): generated.yfwg.zmane.bbbip.wqsm.tbdz.ClsSzekb.metZjimsrct(context); return;
			case (4): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metKlgcwsafmqppr(context); return;
		}
				{
			int loopIndex27090 = 0;
			for (loopIndex27090 = 0; loopIndex27090 < 4237; loopIndex27090++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varPsmpipenhry = (9386) + (Config.get().getRandom().nextInt(422) + 4);
		}
	}

}
