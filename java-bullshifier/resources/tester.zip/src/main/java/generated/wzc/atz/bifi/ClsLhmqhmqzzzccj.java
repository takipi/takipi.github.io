package generated.wzc.atz.bifi;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsLhmqhmqzzzccj
{
	 public static final int classId = 466;
	 static final Logger logger = LoggerFactory.getLogger(ClsLhmqhmqzzzccj.class);

	public static void metIawrsmojnwsw(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[6];
		List<Object> valPeazgzunctm = new LinkedList<Object>();
		Set<Object> valFzkfdtlvdri = new HashSet<Object>();
		String valLufcyuxjqew = "StrWhjoawmdlej";
		
		valFzkfdtlvdri.add(valLufcyuxjqew);
		long valAfdzykjqxnh = 7155391745232275069L;
		
		valFzkfdtlvdri.add(valAfdzykjqxnh);
		
		valPeazgzunctm.add(valFzkfdtlvdri);
		List<Object> valFnurbpkpgdx = new LinkedList<Object>();
		int valEgkfuessmwx = 0;
		
		valFnurbpkpgdx.add(valEgkfuessmwx);
		
		valPeazgzunctm.add(valFnurbpkpgdx);
		
		    root[0] = valPeazgzunctm;
		for (int i = 1; i < 6; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Gffecfewbjyox 10Weoarnvropw 11Bkygfsrgqaue 6Jhgbowq 12Sgaqhuqiuryny 8Fntzscxav 10Qgyplpjrzni 11Qeflbmpvsaze 11Jqprwuofovby 6Tpfrzph 5Kksxys 4Ggngx 11Vllrnwzkgigb 4Vtaxy 8Zdukeggos 12Xyqbmcjrxztow 6Nqntdgu 10Bycjwhwjccd 11Nkhizeqeqseu ");
					logger.warn("Time for log - warn 6Evbiwqo 5Lzawxu 11Mhdicpxqauzd 11Ziafanqazxyj 5Pykdqx 9Onfcduvcye 12Bdvpaajawhssy 8Joebsnexh 9Gfosvnqscb ");
					logger.warn("Time for log - warn 9Misupnkmus 3Zamp 6Vmgouvw 7Xnduaswj 6Uskzqvh 8Possrtnzh 3Rjjh 7Tcxmvvbq 11Bwmoanvvxpei 4Gujke 9Fztuhgrghw 6Ptglyyr 10Oosiismmcug 9Iclrlnmxrb 10Szscwtvufxd 8Zgnypxnit ");
					logger.warn("Time for log - warn 4Uiohv 3Ryss 8Rxwcnvofp 11Fnjomcngradu ");
					logger.warn("Time for log - warn 8Ovrojmshp 8Ncydsfzev 7Rdrahlfz 12Ugnjhoxyrfojp 7Wzjboohc 4Ffvyt 9Cwziauyqgo 10Pchpyitcavs 6Lhcdwde 11Rnetzshtfuyk 6Rzrvylt 7Aorbnbfq 6Mirftye 5Rrbgxq 7Cgitnuvc 5Hjnvsn 3Zpxc 5Bovuph 11Dbbaiipcwwqk 8Utiyjtjjm 4Ltsvy 9Pymthbdibc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Atkzbxqeq 11Vsxaycvaiwlh 4Wdoew 10Qxyjjdqsnay 11Olwwoqpgclhp 11Fswfiaderdta 7Bmuzqeuc 12Bikmirskgvxfv 6Zykjvlc 11Ffoxnpnsyjrp 5Hefnsf 3Xpkp 8Aivxyauoa 9Utksjxzisg 5Ylzvox 6Zazxdrx 12Vwlhafijmmbpj 12Iersxmetoqopi 12Wsldbqvuoihhw 11Odmbyfcoexol 6Uftqudo 3Iuer 7Hnwjqzkv 8Sbvhuiznr 4Vdkpx 6Ubcutvr 6Nebicvo 9Bykkjuaplz 5Rcbihr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.avme.rnc.ClsUgqeozcqx.metIsegbgah(context); return;
			case (1): generated.krka.pbdp.kxfhk.gqt.tfv.ClsAdvwmtrn.metDvriulzpcrhbb(context); return;
			case (2): generated.agl.duqt.yfyli.jnv.jpizl.ClsQbgwqgmsxm.metEmnhch(context); return;
			case (3): generated.enb.ktdil.ClsEqcfzlhpy.metDsnfgxxtqarhp(context); return;
			case (4): generated.hadv.dozj.puo.ClsVowitvkgtx.metBrrizswg(context); return;
		}
				{
			long varLqnjijvmfhj = (8303) * (2175);
		}
	}


	public static void metTthfpespngis(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valFwaqdretmwv = new HashMap();
		Map<Object, Object> mapValFqzixmrxojj = new HashMap();
		String mapValHqsztnljwim = "StrXvykllxmasj";
		
		boolean mapKeyTdezzbmjwbh = true;
		
		mapValFqzixmrxojj.put("mapValHqsztnljwim","mapKeyTdezzbmjwbh" );
		boolean mapValIbvzkyxtzzr = false;
		
		boolean mapKeyDdzharvkcvh = true;
		
		mapValFqzixmrxojj.put("mapValIbvzkyxtzzr","mapKeyDdzharvkcvh" );
		
		List<Object> mapKeySnxcqvfhkfq = new LinkedList<Object>();
		int valTwplxejtnbg = 896;
		
		mapKeySnxcqvfhkfq.add(valTwplxejtnbg);
		
		valFwaqdretmwv.put("mapValFqzixmrxojj","mapKeySnxcqvfhkfq" );
		
		root.add(valFwaqdretmwv);
		Set<Object> valBlwszkgvcqc = new HashSet<Object>();
		List<Object> valOhqvudiwnpq = new LinkedList<Object>();
		boolean valCsxtzcdjchp = false;
		
		valOhqvudiwnpq.add(valCsxtzcdjchp);
		
		valBlwszkgvcqc.add(valOhqvudiwnpq);
		
		root.add(valBlwszkgvcqc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Jzbvexu 12Oziudznwemflm 4Taaqi 6Ddbadev 7Rplsbpvz 5Sksfks 9Anvzvbijyv 6Hqphywv 12Bymixlgbvnnmn 9Aamlpnauvy 6Lxcdhfk 12Bbmskjkltlspb 11Znqiuioazjak 7Mrttcibc 3Ysdb 10Gyghveouppx 3Bvyy 12Vlfrkbxcrhmse 3Pmwv 8Gmismabjw 11Swklikflnegt 6Qhvxdsi 4Ggeaa 6Hsqlfpa 4Vdtyv 8Wswazirys 4Bwjrn 8Ilvywrgkr 6Dulwvkd 3Vizp 11Ecviqxvmraxg ");
					logger.info("Time for log - info 6Kykgfnu 5Gttdep 10Jovacubdjlv 3Fuvd 8Eubrwupnq 10Oxaonowshbr 10Uawzulobgmk 10Orevtlcvocx 4Ibffk 8Niagamygo 10Lgkvrhvygeb 5Unxfdp 10Xloysoomshw 11Grfssoyfhpzb 4Enkgu 3Jlhm 4Pjzfc 4Rkabr 7Xyddgonp 10Swavmvosick ");
					logger.info("Time for log - info 4Wxsef 7Tmyxhgqv 8Veooemueq 8Goubpewnu 10Ibmuqodjtpm 8Libgihmfw 4Fpkjr 4Zmgxx 9Jksmvemeyz 8Yaviruirk 10Pnocqtsqqjr 3Bhuw 10Jejrytgjeig 12Fmskwuamjqjxf 3Niyy 4Iqyqh 10Xfchchjaclr 10Ckirviylajo 12Qnvrmqnoxucyt 11Vcqpcoymfnes 8Exfxugowz 11Vsbaatxmxajm ");
					logger.info("Time for log - info 9Wuhejxnizf 10Befjqnsfonc 7Ktatvoqd 6Hwflrke 10Ktslsmgmeeg 6Gjhozdn 3Tbvw 10Qqezplmoujs 7Uxrwlpow 9Slswnauslb 9Edfdnbeqvt 3Hgxe 9Lnsuurdasx 7Iuoegkbh 9Utxruixloo 3Tqcq 9Gshxscexnq 3Hier 4Twbhc 5Ussuvo 9Omlhrovsnh 7Dmnmczau 9Knjusfllgy ");
					logger.info("Time for log - info 6Gucryuj 3Auto 11Sgnowvilqqms 10Pajgbskpgch 9Aizxlnkrap 12Idsktrmkhyfwi 4Ryhow 3Srjh 5Hyjzgc 9Cqkgindazr 5Wvczev 12Hfjllwaalhwqn 7Lmkpftrf 3Lfyu 5Lphjvf 9Ytslrqmrcs 4Corgk 10Xyrzyctympk 4Xtmaw 6Gruxuli 3Hdns 11Mhgylukuesxb 6Rbbpqvc ");
					logger.info("Time for log - info 4Fnqsv 11Rdeiqauwxpyr 9Eebbfvvusl 9Eirtohzgix 6Hvnyxlh 10Rqwegtfgydx 5Xvesmo 4Sflbt 4Mtvlk 5Jbcway 6Myguhoe 12Loiffoovdbygl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Kpusbdpyblc 10Datsrcfitby 8Sqcdyyhlg 8Ucesavdzk 10Ajjauxpuvvf 5Mntczm 4Yotzm 8Gattyqtwm 9Blrupnuapx 4Kdezx 11Zdbawmtudmjx 5Ppiqst 7Rntqhmcy 8Bzhuzpqur 9Mvlgyctene 9Xcvspdspcq 11Opwqjmeeuqgi 8Ajyqrulvq 12Ikaxjqaioxagi 12Bsxgjmhwmxulh 7Qgjcvnfy 7Gdumjmtn 4Tckfa 3Lzbu 4Qihvs 6Ankdwgn 9Obliuqladb 11Nwyejkfmqiyh 11Nhwacjvzthlm 6Jtbnmdc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Naepxbe 6Vfqmhdr 4Drbqg 11Orlctaarscvf ");
					logger.error("Time for log - error 5Ccsrvn 7Tblkpmgi 11Gyhsqytfeqws 4Yicwj 7Sysgszzp 3Ymxr 4Wsudp 11Fxzvrdmskpux 10Saarvbuaiir 5Deqpcc 7Cpagbssi 3Ktfg 4Oysrc ");
					logger.error("Time for log - error 8Trznpeibs 12Ytlfuooaqvfvl 12Jukirvmylzumr 10Ctrbmbqpeiv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jmrw.ryri.ClsDmqllltcxdlzd.metQoxlfxubml(context); return;
			case (1): generated.kivyr.smd.affpo.ClsEqlzjivgvsoafb.metFtrfvpusk(context); return;
			case (2): generated.maoc.ohm.nwzbx.efqn.ClsOzonhytosc.metIeedbzcj(context); return;
			case (3): generated.gfiaw.wgvz.askqs.ClsGbqekumwdbwfn.metRznpltfgjhr(context); return;
			case (4): generated.lfb.pwad.aey.ClsGmnfes.metQfgeyandauqd(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numKzqkutjyxsz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirXnvltsghndi/dirJwxqejppdse");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metVhmzct(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[11];
		Set<Object> valMogymwfojxs = new HashSet<Object>();
		Map<Object, Object> valVpbgfnsoltn = new HashMap();
		boolean mapValGdybltiguat = true;
		
		boolean mapKeyGkmbkkxgcoe = false;
		
		valVpbgfnsoltn.put("mapValGdybltiguat","mapKeyGkmbkkxgcoe" );
		
		valMogymwfojxs.add(valVpbgfnsoltn);
		List<Object> valQoecdbtevvl = new LinkedList<Object>();
		int valBelnvxdryzv = 135;
		
		valQoecdbtevvl.add(valBelnvxdryzv);
		long valPykxakiywmd = -264286047558415896L;
		
		valQoecdbtevvl.add(valPykxakiywmd);
		
		valMogymwfojxs.add(valQoecdbtevvl);
		
		    root[0] = valMogymwfojxs;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Dlkc 3Tkor 9Lhruutcfyz 9Peisceavga 9Rpdnkcvrdp 8Apsabqdaf 10Rorjxjurqfr 5Gyympd 8Xjelxtafz 5Ujpuir ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Fihkkxc 6Jxphvzy 6Dbeebka 10Nxqrjvgoafd 10Lvjwkyqmewa 8Linrurhtt 9Bfltafshnc 7Oqbffzhl 8Xqmwiinlu 8Mgvcorlqh 3Dcnz 9Czkhaeqlfr 5Niwzfa 12Oaoyjhoeydbcx 11Ngpqpvbmuzqc 10Frevrtrxtdh 5Guxpic 10Cyhrifqegqx 6Ilbgevt 8Wlsxgejor 12Elrrmagmfydzr 6Tilifvx 7Ezpnowks 6Zthlpuv 9Uhkablsisd 3Xgvq 10Wcqlpozthts 10Rbsktxxyszu 7Qzuznumz 11Nuaeirnjgfvm ");
					logger.error("Time for log - error 10Zbinholgvfl 7Qwpxwwof 10Rqzjczhzrhp 3Irlu 5Kkclrs 11Mltruynbtjna 10Nbcxggahrfq 6Bglzlra 4Nbqpu 4Wsgrk 10Tjsnetuokis ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lraiq.fcmvy.qwp.rkzex.eokht.ClsJupuz.metTywqcdpv(context); return;
			case (1): generated.qer.bwl.ClsCbeyhqqy.metFgzkaoqzw(context); return;
			case (2): generated.qnmn.narfk.rdhdk.ClsPtwatcpapj.metNosih(context); return;
			case (3): generated.qrzc.frg.utv.itv.ClsGoyvsxo.metZvafe(context); return;
			case (4): generated.kivyr.smd.affpo.ClsEqlzjivgvsoafb.metFtrfvpusk(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirNqjwurpbwyt/dirDgruyzwpywu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numXssavokzcbt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metIrfepbrwzvpunu(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValCofpivohmny = new LinkedList<Object>();
		Set<Object> valOiizpjodoxp = new HashSet<Object>();
		long valYuxaxnohfom = -5664717431802478234L;
		
		valOiizpjodoxp.add(valYuxaxnohfom);
		
		mapValCofpivohmny.add(valOiizpjodoxp);
		List<Object> valEvkwfcfjwdr = new LinkedList<Object>();
		boolean valJxdwvccixtv = true;
		
		valEvkwfcfjwdr.add(valJxdwvccixtv);
		
		mapValCofpivohmny.add(valEvkwfcfjwdr);
		
		Map<Object, Object> mapKeyQhmkuemedeu = new HashMap();
		Object[] mapValWfvwyknutll = new Object[11];
		long valPdjqyucgicp = -4412163044454609866L;
		
		    mapValWfvwyknutll[0] = valPdjqyucgicp;
		for (int i = 1; i < 11; i++)
		{
		    mapValWfvwyknutll[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyGkwgcjmlmxd = new Object[5];
		int valHadhigxncya = 980;
		
		    mapKeyGkwgcjmlmxd[0] = valHadhigxncya;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyGkwgcjmlmxd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyQhmkuemedeu.put("mapValWfvwyknutll","mapKeyGkwgcjmlmxd" );
		
		root.put("mapValCofpivohmny","mapKeyQhmkuemedeu" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Gsqqfccu 12Vbsepgvgvurpe 11Fkuzycnnjsxt 7Yvxpbfuw 12Jjxlplswvoalz 5Jokudt 3Sgpq 7Dlechjcq 6Rsazzac 3Izto 6Mccregu 11Ukralvhmmhcd 8Rjxzicivg 11Bugjhkklhnhd 10Hucoytjebea 6Uuplgrw 9Yuxwguzoas 12Ycgodmbgkbbti 9Xrjhkmkhjq 4Dkvmq 9Fapnxznulc 5Iujzfx 9Dciofgqrpn 7Gzhzsmyg 6Llddrmn 11Uvesvxdjueoq 4Pulse 8Gprxawygr 6Tnflcig 3Txaq ");
					logger.info("Time for log - info 11Pwjdjgpdliac 5Cfflvw 12Zmnprgiflomqu 3Loea 4Wwliq 10Ityciptsmmh 10Wguvtbgdxps ");
					logger.info("Time for log - info 6Ggtttdl 7Kzixfeqg 10Amhtmruglri 12Lyamqehicqrsm 8Vmtgndlud 3Gsye 12Wwueuukxaansp 3Bsce 12Uefcqsksvkaly 10Vwddyaibssj 4Qidpt 12Iwbrmakaxtaul 9Zjkizlcddh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Oaujbwjx 5Leqiti 8Nnxsalcyf 7Ztcsjzof 5Jfapeb 10Yxrtlhnuozg 8Yvcrezbyz 12Cozplsnfvoucx 5Mcawca 5Fvngyk 11Cvjfwzsqchxi 11Tsuxkgvhpmnv 10Wdkcackimsv 9Tipzekeylj 11Vjqygcyztuhf 12Uqmblhznoojtx 12Djzgjbgszwyjm 10Torbggvhqbi 10Sjexrfwpkle 8Sjedhiepu 11Bhvtkoglkmph 4Bjknn 12Xmibgmzvswmmw 9Efiteqsigf 6Hnhowre 10Glcnfqfrcbc 7Ekqnfbgr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yfwg.zmane.bbbip.wqsm.tbdz.ClsSzekb.metJangle(context); return;
			case (1): generated.jyd.enpnr.ClsZxueqcgpd.metEwimth(context); return;
			case (2): generated.wzzy.rguqw.bfm.ClsCumedne.metQxnbuwx(context); return;
			case (3): generated.bcbrr.mrpx.ClsJcswauwrr.metIydcpeyrd(context); return;
			case (4): generated.gasq.isr.fpndy.jhzr.ClsNxizwkdumgga.metEyznktcptuql(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(690) + 6) % 629274) == 0)
			{
				try
				{
					Integer.parseInt("numIhvyjygoduh");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(100) + 1) % 964502) == 0)
			{
				try
				{
					Integer.parseInt("numFvhvjxbpxdw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numYiknvgevdol");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metJchuni(Context context) throws Exception
	{
				int methodId = 4;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValVuocxcczmqa = new LinkedList<Object>();
		Set<Object> valPgsgfqcpulu = new HashSet<Object>();
		String valEumwehzxqha = "StrAooeofrhpxg";
		
		valPgsgfqcpulu.add(valEumwehzxqha);
		int valDjopbllmbad = 300;
		
		valPgsgfqcpulu.add(valDjopbllmbad);
		
		mapValVuocxcczmqa.add(valPgsgfqcpulu);
		Map<Object, Object> valLaimgtrnqbf = new HashMap();
		long mapValGmwspafeupr = 5809965923567275955L;
		
		long mapKeyXuzchiudwmd = -7225329211389754649L;
		
		valLaimgtrnqbf.put("mapValGmwspafeupr","mapKeyXuzchiudwmd" );
		
		mapValVuocxcczmqa.add(valLaimgtrnqbf);
		
		Map<Object, Object> mapKeyWkbqfnntegq = new HashMap();
		Set<Object> mapValMkaahvhyrhl = new HashSet<Object>();
		int valSeaegqxmbno = 554;
		
		mapValMkaahvhyrhl.add(valSeaegqxmbno);
		boolean valDpukxfsgzyc = false;
		
		mapValMkaahvhyrhl.add(valDpukxfsgzyc);
		
		Set<Object> mapKeyBuyplcauwnp = new HashSet<Object>();
		int valNptydaxcilj = 125;
		
		mapKeyBuyplcauwnp.add(valNptydaxcilj);
		
		mapKeyWkbqfnntegq.put("mapValMkaahvhyrhl","mapKeyBuyplcauwnp" );
		Object[] mapValWmhrclenjfw = new Object[3];
		long valHrogaqusnzy = -5702296253457031922L;
		
		    mapValWmhrclenjfw[0] = valHrogaqusnzy;
		for (int i = 1; i < 3; i++)
		{
		    mapValWmhrclenjfw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyTmyqnghpvao = new Object[11];
		long valDorowwmgoxe = -7337309543977925281L;
		
		    mapKeyTmyqnghpvao[0] = valDorowwmgoxe;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyTmyqnghpvao[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyWkbqfnntegq.put("mapValWmhrclenjfw","mapKeyTmyqnghpvao" );
		
		root.put("mapValVuocxcczmqa","mapKeyWkbqfnntegq" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Nyakiua 3Vexq 12Cnikdtblaiszn 6Nqcslzc 9Tskkvpubzc 3Ftup 12Qvaypjsccimzl 11Adqmniaobmzc 4Ppkmu 5Mipkwl 12Oshwxfumdeeqf 12Ugiwbdhpmuvuf 6Iiksiip 3Oxok 9Plcdgjhcbh 11Rfejhvwphazf 9Jvljfaxrxt 4Tiuew 12Mcevnduynnyhf 11Hvmisinbhyfs 6Leeunyu 6Xldzdte 5Zzrazd 5Abdeyu 3Jwld 11Avmpmfxpntoj ");
					logger.info("Time for log - info 4Gyfbj 5Dekchr 12Xjjrrkfjcebxm 9Suadkbzgpr ");
					logger.info("Time for log - info 5Myfijs 4Eufec 10Iwoyvowpslw 3Jcyd 4Jheiy 11Vgfotmainxdg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Fahgfvlqc 9Mypqiztaur 11Loaedmiklpxz 5Dcvrbq 7Qgrhjhjs 8Bhpqctxhw 8Znagjwaxa 12Uxdooqebnudxl 10Sjidbmwxqjz 3Muyw 11Kklmyefhkcou 12Xlnhkjbafgghu 5Fxqdgr 6Lectukb 9Kvaopggaqx 5Yzcswd 5Nmetxn 4Lfrtk 5Vwlitu 5Ukczrm 3Iuzb 4Abkpn 9Boyozldyzr 5Oarxia 8Rnhqpvonv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Iiqcxobp 8Urmjcbuyo 5Daglij 4Xlohq 4Vvvux 3Dsbk 5Bpohix 9Gytjrjdutp 6Qqriigm 6Ygekwtg 11Soybdosvsmcu 7Cirehcol 10Ecloireybes 11Itgruohqexqn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wxgmf.hjxrw.ClsYvfyyrknqfec.metRjzexmwk(context); return;
			case (1): generated.rzy.sppai.eju.hupq.ClsPjendhgbojpy.metVwpivrvw(context); return;
			case (2): generated.fhy.qnk.brj.xhy.ClsYgumeudbf.metVozkhelpekwnp(context); return;
			case (3): generated.xij.sqewq.cevz.qdd.iar.ClsAxzlzievw.metNunaxfbnokb(context); return;
			case (4): generated.munb.ijbed.gztfl.ClsHbtirm.metYfquprhhflyrzu(context); return;
		}
				{
			long whileIndex27874 = 0;
			
			while (whileIndex27874-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varDxmyxquitlm = (Config.get().getRandom().nextInt(798) + 5) * (7979);
		}
	}

}
