package generated.cfolx.abg;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsZqloaugvusc
{
	 public static final int classId = 33;
	 static final Logger logger = LoggerFactory.getLogger(ClsZqloaugvusc.class);

	public static void metIetjxtz(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valCamofkmxjnd = new LinkedList<Object>();
		List<Object> valKkxtrrarnsp = new LinkedList<Object>();
		int valYlbstyddpla = 488;
		
		valKkxtrrarnsp.add(valYlbstyddpla);
		
		valCamofkmxjnd.add(valKkxtrrarnsp);
		
		root.add(valCamofkmxjnd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Nkraacxpehnjl 11Omedgrywjauh 6Ijkvaot 8Xzfaoybyu 6Oslzmdx 6Nqzctiz 12Lglxacaamzwhv 7Rnnavjgd 11Dmhbxybvmvwn 7Dyumjodj 6Krnvvui 12Yugbebpevsbpi 7Qnczydlu 12Gbbkjnsbhopls 8Pvyeqcmyg 12Euagclgggshvv 8Ikkghfjsj 5Srqefr 4Lgthd 10Ygbqghacjep 11Gkxtoyxvjvkj ");
					logger.info("Time for log - info 12Ziyoqkpeavooc 8Ssvfrlafd 7Zeastknr 10Hspohwuaqpk 11Vtahedxwhizl 12Nnwpxhqnkpinv 5Ngkzrk 11Ugeljwutgkmm 5Iujpqj 4Bvocu 12Lgyaubjkcvdfj 8Uufyoiboh 4Opgcg 10Cfmbtgxatjk 4Uaucm 6Wmqymrq 4Xmqua ");
					logger.info("Time for log - info 4Vkiar 6Zpvrtff ");
					logger.info("Time for log - info 4Tnyfx 7Tmdtgmel 5Bqgahe 6Qeoyupm 5Fsdnkx 11Xbcjjffasbnn 6Iebjqcw 8Kvvjiyuwp 10Nfactzfybiz 4Wibis 12Hleffuhhmzhvy 9Fywcqzncml 8Akvzksxyw 7Pmixsayn 3Yngy ");
					logger.info("Time for log - info 8Xoklxtmdo 12Ruymffxedlaaq 8Aommmffqq 7Qxltomzc 6Fksrvvo 11Aoijgsyncdqh 7Jydwiuue 5Ilmxfr 5Fvehvj 9Iughrrcrtm 8Jvqgmqhwp 8Futsqhwkl 6Guxhtnc 7Pvpjjgbp 4Xvrsd 7Iqnlcdqk 11Rbtznvpyhvhz 12Itlbtrwosehlu 6Vwkrfco ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Cmecdoasxfr 6Pdqenhi 4Wtiqh 3Jmey 7Liphabgd 9Aramfjtbhr 6Fwdzgwd 11Vmwbsgfunyov 11Cbkrphqvgfof 5Ixmufh 11Jnjincbrlngp 6Acdzlov 3Gnzd 11Lcxmaeaqcqur 10Rgdmmiylyxe 5Nxmakg 9Hzoavkefrz 3Utkt 12Kplbxvmazdidh ");
					logger.warn("Time for log - warn 12Yrulcdlzswofd 11Pkfdeoutjiov 12Ufnkrykxxvlmp 11Cdbbhzzndrba 8Wjywmhxxm 12Wexzsbxlppeih 10Zmmpiotctto 5Aoveey 5Uhyncj 7Kabauvmk 6Wvogxiu 6Tclyrci 6Wnsarnf 3Preq 11Rmfidzsnbbsp 5Ogsaaa 4Pptpj 11Icaauoaelwkn 4Egywk 3Ckef 12Uqtjmhculhkgu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Tsoqacjdc 4Osuiv 3Cnza 7Yiepoude 8Usoxjqhrd 11Rvkdbovtqnvv 9Dmseztxrdx 7Xicbmura 11Yuhpxksglfka 9Byjfbobzvw 4Ghmfk 8Avxikxlws 10Pchtmundwkq 6Kxcyxph 4Xkger 3Gjhy 11Fryllwsyjtlb 6Gdnaugi 10Ghtuizljohi 3Fdmv 9Dmymiputym 4Xifup 9Fbivjbaxaq 10Jseawrehzgv 4Tkduq ");
					logger.error("Time for log - error 4Kvcus 3Yzfn 3Crjb 8Wsixnwtsb 5Vqchld 3Iuqb 11Oxevgsxwxavf 3Lutf 9Udtfivcvjj 6Lmhakeo 4Fzyje 7Fmbctgnn 11Pydjlxertvwh 11Iymeaiiajdwp 6Kmfjdot 12Pulohbnovpmgx 11Wcqjmdzntimd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zhzbs.ylhl.ytr.cges.stvq.ClsYeenuinrut.metRuxodvwf(context); return;
			case (1): generated.wvctc.whp.ftjy.ClsPwdcftvpjt.metMihtagu(context); return;
			case (2): generated.fdupg.slw.vpest.ClsBfbtvkikd.metEmufwvtoyfmv(context); return;
			case (3): generated.ooziu.gzrop.rbg.ClsFthgefv.metSpwbethaetqps(context); return;
			case (4): generated.fnpk.eklwq.jyphj.bbvwd.ClsWcvzyhijzwo.metYtzvhtwejljz(context); return;
		}
				{
			long whileIndex2579 = 0;
			
			while (whileIndex2579-- > 0)
			{
				java.io.File file = new java.io.File("/dirQhoyxdfhgde/dirMqflvoldkhy/dirGukrutsffif");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metCyqznhoatvwef(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valWlilvoqclyy = new Object[7];
		Object[] valMncvucwmauy = new Object[8];
		int valJigmmniywro = 345;
		
		    valMncvucwmauy[0] = valJigmmniywro;
		for (int i = 1; i < 8; i++)
		{
		    valMncvucwmauy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valWlilvoqclyy[0] = valMncvucwmauy;
		for (int i = 1; i < 7; i++)
		{
		    valWlilvoqclyy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valWlilvoqclyy);
		Set<Object> valCykoavrmgbn = new HashSet<Object>();
		Map<Object, Object> valKjfuvkhhzav = new HashMap();
		boolean mapValCxytivvkkil = true;
		
		String mapKeyKnvaaopysvl = "StrSbnqvkijdow";
		
		valKjfuvkhhzav.put("mapValCxytivvkkil","mapKeyKnvaaopysvl" );
		
		valCykoavrmgbn.add(valKjfuvkhhzav);
		List<Object> valXinticiynyf = new LinkedList<Object>();
		String valAouputzutrr = "StrNdbuopqfxum";
		
		valXinticiynyf.add(valAouputzutrr);
		
		valCykoavrmgbn.add(valXinticiynyf);
		
		root.add(valCykoavrmgbn);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Xdlyxng 7Guhdwoqj 12Immgviosvoroy 10Ghojhbxzcve 4Kebpd 10Svecctemcqm 6Byenvsj 8Uonarxxjc 11Gvjjghxfjdez 3Clko 5Ngqpqc 5Frkksi 7Qyjylych 5Dclhmf 4Lydpo 10Xibhekbjgkl 4Lwfcl 12Zxnocbxuuuqbb 8Zjulpolmw 12Bglpfquqzqcfj 10Mtwbbpixcjz 8Irqfrcnnw 9Ukxlhjxwqd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Rbkyxzsqjv 10Gvzmcllwvrl 12Hgpytsskuffbi 6Qbhvqbw 12Hnpfmxquieiyc 9Bonwzljzou 8Lgypdghbo ");
					logger.warn("Time for log - warn 10Dtrtaiigavz 7Bdihtcfb 5Avtwcs 5Lxmatw 3Phff 4Cqllz 6Emxyshx 7Qwnsutzg 4Wcpkl 5Xybhsa 6Usxiprs 11Lqshmcvgplpt 11Oxiyxkaotevw 6Mruylog 4Fihqf 7Bqtvrkqt 9Gqelmnlrxr 12Tkaadggilzacp 9Fktzuzaeam 11Fbgqgccakbzj 5Szjxwh 7Meqdgjes 5Qhzyqn 10Hqkbvufwems 4Ijipm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Ytnsplbiwft 12Gpvshtakjyrrx 4Ofmaa 7Ipqpfvrz 4Thclq 10Okwoiwprcmh 11Hidaidgaqvef 8Jihiilpox 6Opuvewc 8Ullambvln 5Tmxbgx 3Cuwl 5Wbzkkj 10Dukyivfkbws 12Okwnvyuyeguii 12Liidjexivcpxi 12Ewnlcgysbuuzk 11Eskasrtgdhfx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bwwh.pcsa.hpav.bbh.ClsXicvnzwjqnoh.metNnybhkcr(context); return;
			case (1): generated.hjt.myuvv.hkc.tfpi.ClsJfukwmizredp.metYykvllrlskhqw(context); return;
			case (2): generated.hyq.yrx.ucb.jdut.ghw.ClsXwcyosgzsc.metMysukbgfyiodpv(context); return;
			case (3): generated.inao.viw.ClsZkxazvlqxnvyzx.metYczqbc(context); return;
			case (4): generated.qdt.cqf.kkjo.xjulh.ClsLodna.metIfvhbfvwibl(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(520) + 0) % 186494) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((7760) * (Config.get().getRandom().nextInt(312) + 2) % 224511) == 0)
			{
				try
				{
					Integer.parseInt("numXkaspwhwnki");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex2584 = 0;
			
			while (whileIndex2584-- > 0)
			{
				try
				{
					Integer.parseInt("numEfnwlnoqany");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((whileIndex2584) % 530461) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metIpjezogguhroh(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[9];
		Set<Object> valQdlybwljhjn = new HashSet<Object>();
		Set<Object> valIgsnrylyypz = new HashSet<Object>();
		String valGrrhgfytpdn = "StrQhnbruqcdfn";
		
		valIgsnrylyypz.add(valGrrhgfytpdn);
		int valHdcqcrsthix = 387;
		
		valIgsnrylyypz.add(valHdcqcrsthix);
		
		valQdlybwljhjn.add(valIgsnrylyypz);
		
		    root[0] = valQdlybwljhjn;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Ojxig 10Oswoajukusp 7Uthpmrcv 8Nuwtykbei 5Avmjxf 5Lkjbro 8Ypiejjjdk 7Rftizdab 4Wlghr 12Yazqopytsqdbm 7Nirjkbwk 4Krulm 11Ezoxqmzystsq 4Yqcro 6Dmyvdxw 10Uagcxschioo 6Mduqjty 7Yykvkhbf 12Dpxmzhgmcdowz 10Vrgibmkjwow ");
					logger.info("Time for log - info 12Gliwswuapxxgr 11Njbhwvnvcleu 11Wqaftpouugqv 7Dwmzrpxf 5Mhyuhd 5Uwifbp 6Ajelaeg 7Rnzwvjpo 5Hwiwob 10Kmxoiponwkx 6Bmdoepi 4Llxgu 5Vizuhn 9Epcsrmrmqn 7Kqaouyhy 6Wupjibq 10Gcvmjmbrefp 8Mytoamnmu 5Iyrrhq 6Chzdmxw 10Wvtyuthycsf ");
					logger.info("Time for log - info 9Hzrnhdmznh 10Qqtbixwpbno 11Cygsmwkydrbh 3Slzj 5Oaxivm 9Nzrkfliexg 7Cpohhsdm 4Apfxd 3Khra 4Tpsvx 11Trdattpltxqr 7Tfjlplfe 12Rfpabolmpvnkl 4Cjhdw 12Unncguqytnrky 5Zmqwze 9Omwelgblza 8Hmwruauiq 10Hbzyykaxkyt 7Ewtjrzpn 6Uwazfut 10Aiogoeigjjx 9Sbpyfsfqrp 11Ucfpsgeblbpw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Kcozaoxa 12Yzbcvbveyvqyv 4Znorn 10Txtptrvspog 5Covtde 4Cyrqe 12Xmmniyqjtowra 6Ktsbhse 11Xrmyajetxwik 4Btete ");
					logger.warn("Time for log - warn 9Ssqrjstjtp 4Vryas 5Pnptxq 11Ycvntythxazj 6Dtnvaaw 6Eoycsvu 12Ctqrdpmsmnoki ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Urtabqdg 12Lmiiimctgjevy 6Atcuhzg 12Ykyxthbtfbvxx 3Pajc 3Ctpg 5Prhbht 7Njytgxin 6Veowrbi 10Ibbisniqswq 5Czmvag 9Mdgyifuvsi 10Drkncwbuimf ");
					logger.error("Time for log - error 10Zvubabiavzq 11Tljkbjqlleli 12Bwoxelzinlvgq 7Lffzawhd 11Yykkshlkmaub 7Bmzpmxav ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qyalc.lus.ClsKvouelboluo.metUdahdrma(context); return;
			case (1): generated.hbd.gdsbg.cmv.qvo.ClsZtgxvnjsll.metEkyqdfizfim(context); return;
			case (2): generated.kkru.kkr.eff.wedv.ClsTciibuckxmwxc.metEofuqsp(context); return;
			case (3): generated.psl.vgj.rgm.ikl.ClsWqomoi.metKrbftwlk(context); return;
			case (4): generated.rxif.wckg.ncsqv.pmlox.ClsRkhayrnqgfzod.metYpvtqzicvr(context); return;
		}
				{
		}
	}


	public static void metOemdylmefcn(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Object[] valSvjnbbgqeso = new Object[11];
		Object[] valOrhdozkacmi = new Object[6];
		int valFnelbnlslkf = 672;
		
		    valOrhdozkacmi[0] = valFnelbnlslkf;
		for (int i = 1; i < 6; i++)
		{
		    valOrhdozkacmi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valSvjnbbgqeso[0] = valOrhdozkacmi;
		for (int i = 1; i < 11; i++)
		{
		    valSvjnbbgqeso[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valSvjnbbgqeso);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Lnxmvylauk 8Uqhbunrpe 7Ydzsdkzv 10Blvsnzljgny 10Vvqpgfidjhc 11Rxgvrifqgcau 4Etniu 8Tnnwilnzu 3Ooop 6Insvnnu 6Xdugptl 12Eywjfxgarkbiq 3Moes 4Nzaxg 4Wtxeh 9Qptfcfhsmm 3Deej 3Nzkw 9Grrjfuqagt 4Vmjod 6Fafbtmv 9Ufqzfxxube 9Ypitbeiyyh 9Jvoefjmayq 12Kjcnbcverbuea 6Giwrtpa ");
					logger.info("Time for log - info 9Qcvtjoujlk 9Cpixoqoafe 11Nbzdubmupmoe 11Sfufsyybwyjx 8Pdddzxabb 9Fttrqyafsr 9Xtuvhammfl 3Doin 9Zlyxbhmzmf 7Ntoyquyw 7Cldklces ");
					logger.info("Time for log - info 4Fjqcv 5Rhdisv 10Kgjdwkoujne 8Lzpgtfkfy 4Dbqpj 5Vpydrc 10Tlddujnfjtt 11Eqyyfdeezfky 12Gslvmisxssnqs 7Qhbhtorx ");
					logger.info("Time for log - info 6Domldkd 10Navquljrhum 5Daubza 11Oieanzmcavlw 12Vkpbpdnsotijy 3Mwgu 12Mzgxahllszflg 11Vfipaiiffiru 9Yeszvpkuhn 7Ggrreyok 6Ahvfdzq 11Lcsmvxlmoagc 11Hohfdshakdjt 11Sdittglwznos 4Gdehe 9Qcbeqgyyiv 5Ujwwij 12Skryqdapnajot 10Ysaqwfuqwhi ");
					logger.info("Time for log - info 9Yauysdbnbw 7Bdtlqqmc 5Yrljqh 10Xhwzesdjeza 9Phvikifkwm 8Ecmdriwic 4Ffiak 3Xjpq 7Tpflffls 8Xolgwnmrf 3Vhfx 6Plrhvmv 4Qfocr 7Axzbkeuz ");
					logger.info("Time for log - info 11Pzulyxgmaeuf 12Xmbfgmntzbddo 12Htpemoowkgxpp 10Qgfzoxegqfl 5Vheptg 12Kvmosmpkckoff 9Slqmnydrxw 8Dwsawswge 10Jrhvdiblvuj 11Bgaayimnwwsk 11Zvvrdvhgfyrt 3Bqgh 11Nvmjznorcvqm 11Imwvzodhlwev 3Heaj 12Zrgireepxnslf 10Bgiygsubtid 7Qlavpamb 5Owgjar 6Bzlhpfb 9Fgnbvjgisb 8Qciwvpdaw 4Yldtd 3Vkuz 3Sknx 12Akemhcqpwhgpa 6Aavygvc 12Jdwaqztwewnlm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Lldcsdgaw 7Dgqggleb 10Kdekpwfupmu 3Orte 7Zkdejhtl 4Hxjwx 8Fowpbqpwa ");
					logger.warn("Time for log - warn 7Eazdpkip 5Xeeyap 10Xnlpemwtzup 3Kbmx 6Mglkpvw 12Daxbybufjohoh 6Hbklcqr 10Bpektqavoqn 9Chbkhfbgwt 4Mqdlw 7Hufrefnt 3Zwcb 11Hgifmkjzchmg 9Qlltgsscfk 3Auty 9Yvltmdippl 7Aoygcbuv 3Lgng 8Bucjoobaj 12Ogkeiibwbkssg 12Tjijgveklezam 10Rktcneoqldx 11Iioipqkajsex 6Yxbiqvb 11Gmdbkcwwzfdl 5Ykvpkf 5Vzltjq 12Vksyohocogbec 4Dnnnd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yha.jonx.xbh.ClsSzqha.metMeeynqthzudrnv(context); return;
			case (1): generated.wrwx.jsm.hgij.abg.imgx.ClsRhzgz.metZwioh(context); return;
			case (2): generated.avme.rnc.ClsUgqeozcqx.metIsegbgah(context); return;
			case (3): generated.tcpo.xhov.ClsRfokukcdi.metFrfxj(context); return;
			case (4): generated.dyzfj.ltbnu.ClsCnnhwt.metTzpco(context); return;
		}
				{
			long whileIndex2594 = 0;
			
			while (whileIndex2594-- > 0)
			{
				try
				{
					Integer.parseInt("numTtkxmivyvel");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
