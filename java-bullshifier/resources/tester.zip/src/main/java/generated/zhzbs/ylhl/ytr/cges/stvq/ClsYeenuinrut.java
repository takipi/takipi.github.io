package generated.zhzbs.ylhl.ytr.cges.stvq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsYeenuinrut
{
	 public static final int classId = 249;
	 static final Logger logger = LoggerFactory.getLogger(ClsYeenuinrut.class);

	public static void metRuxodvwf(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valBrfsccbribg = new Object[6];
		Map<Object, Object> valLopixgxptaw = new HashMap();
		boolean mapValSqrdlizdbvm = true;
		
		boolean mapKeyMuptvvquisg = true;
		
		valLopixgxptaw.put("mapValSqrdlizdbvm","mapKeyMuptvvquisg" );
		int mapValBydwkmzkgou = 483;
		
		boolean mapKeyTupprmdfqgl = false;
		
		valLopixgxptaw.put("mapValBydwkmzkgou","mapKeyTupprmdfqgl" );
		
		    valBrfsccbribg[0] = valLopixgxptaw;
		for (int i = 1; i < 6; i++)
		{
		    valBrfsccbribg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valBrfsccbribg);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Mwap 8Ifydnfqkz 9Pgfkzlchxo 6Yqkenxi 10Jhhqpnewpzf 5Ikvxdt 5Wnerro 12Jptagerxtrsed 12Csstmkjtnbdqm 9Xqghtxybjm 12Tjmzuyubjcmom 6Cvpdvrc 12Gmtrzhewdhiau 5Tqdkwa 4Zmkpg 9Svnneojkvh 5Jbqjqc 7Dmpljyki 11Nhkkmjdgwdqy 5Tcgitp 8Zodxggyqj 12Ihsvcfzyqslhg 10Ijbbflrdnwj 8Rjkstorsd 4Gghln 7Mfswtsen 8Yfrlnhhux 12Sjbueznowljzw 11Cgvfnikvuzol ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Dyroou 12Nwzoioftvyfqs 12Gjxtefinrebng 8Pkggqspoj 6Exfefph 3Hack 8Okhbijpzl 9Iwaqqqxoxz 5Sjxbyt 11Cdrqemixhjzz 7Xdzcvhjr 12Dbsjpbhluacig 4Rhngm 7Rcyczqnk 12Lsakkzseqobml 10Lewivbrjxjh 10Koydhgompyq 6Txbpbjd 12Wolnodojvvxak 10Veboayiswaf 9Idloufscmy 10Apnnfkbopjb 4Mahpb 10Wukzyexeitf 6Ktwhjuu 7Mxyvgqce 4Ymyju 10Woqfthzrczo 11Nsspqyjbehhx 5Icirhi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metGigic(context); return;
			case (1): generated.wgclb.xej.jxqsz.ClsVlhpzchb.metWmoop(context); return;
			case (2): generated.bcx.mqxlt.ClsXwnkituewi.metHlyryfobk(context); return;
			case (3): generated.aqqfv.gdkxm.pact.ClsAgtwrqa.metYkbdjrockaif(context); return;
			case (4): generated.zadtu.owlhb.qsd.bfzb.ClsWgiwrqnvyw.metJmapoligglq(context); return;
		}
				{
			long whileIndex24393 = 0;
			
			while (whileIndex24393-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
