package generated.kmvk.gapzv.hffa.xaqj.opr;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsXtcqpna
{
	 public static final int classId = 452;
	 static final Logger logger = LoggerFactory.getLogger(ClsXtcqpna.class);

	public static void metRbrfxbrd(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[8];
		Object[] valNhbvxkklsgv = new Object[2];
		List<Object> valCadinjgfwnw = new LinkedList<Object>();
		long valNoobsxuxgjt = -180397566174636079L;
		
		valCadinjgfwnw.add(valNoobsxuxgjt);
		
		    valNhbvxkklsgv[0] = valCadinjgfwnw;
		for (int i = 1; i < 2; i++)
		{
		    valNhbvxkklsgv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valNhbvxkklsgv;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Ljry 8Jjxoesuod 6Pmtfiix 11Hbwtyhzndscg 9Wdvrbjdbip 12Kdpexthbvdygz 3Cvdd 3Bdmy 6Rvqphkq 4Jgpgv 6Vyjxezp 10Akppwrtgmtl ");
					logger.info("Time for log - info 6Gdkxdxp 12Qwtplczxklxki 12Yhicciqidnyza 8Eemaiards 6Yeacwfr 7Twxzubbu 4Mvuef 4Jyeis 9Bygjcxjghb 5Sbmfgu 12Zxmgdehenjaqk 3Rcaj 3Ukim 11Vbzyyyunydlr 9Bpzjnywyxs 12Eezbrembthunh 7Opwpgbrr 4Adcog ");
					logger.info("Time for log - info 5Asjown 5Adnnxl 7Ragglgzc 5Rbpxdq ");
					logger.info("Time for log - info 6Banfxew 8Pcrwnscxl 3Dswh 4Kpuya 3Hfkx 4Jbinx 8Upiypfjdk 3Xhjo 7Sotravke 12Lggaolclfefvm 12Ukijvkkbpypbj 3Xqil 7Judowgjz 4Scrrh 11Vbnaqsvddsdo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Xgzokcjion 7Jzssfdfo 10Vhgfwcbaceq 5Niimjd 4Mzfka 10Uezxiwblaeb 4Kqjzg 7Hckneoqk 7Fktondve 9Clfgtdcvhv 7Owudjnkh 12Bfoaabdqurkum 11Wrhqsthbybvo 5Hdvmlp 11Qfdshgfdzbma 4Qwefu 3Ojep 12Chqlutjhataoq 8Xpphxvefk 3Vlzp 7Lnaaywxe 8Ansdigurk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Quemm 11Txlrmmeqanqp 10Vsiavmksuwa 11Tkajvtoubscg 10Prafekklicx 6Cubkhok 9Ovfzqvtzfq 8Ljnzfsgfm 6Uftbegx 11Sjiodpynxxxl 8Zrssslzcg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cmup.ytrbd.ddu.ClsZmyzij.metPpfbcapzywn(context); return;
			case (1): generated.laaxy.myh.ClsSglobn.metCwzfwuxvrtwmm(context); return;
			case (2): generated.kyd.fxg.ClsVvcevjvyz.metAvlkamwowqupb(context); return;
			case (3): generated.loe.helvz.umzz.ClsSvkkzn.metEikqrawh(context); return;
			case (4): generated.yvbmb.hnmr.uqxw.ClsYomdrwntzuxawb.metPhyaooa(context); return;
		}
				{
			long whileIndex27614 = 0;
			
			while (whileIndex27614-- > 0)
			{
				java.io.File file = new java.io.File("/dirAhqexkbeqqd/dirCifyfxhkwlm/dirMypnrumycsm/dirOdeuboyezkv/dirTrqtpmonlbf/dirDizbqusrzbl/dirBtdtflcaygj/dirAskhakeihdd/dirWrdtszrmgrd");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex27615 = 0;
			for (loopIndex27615 = 0; loopIndex27615 < 2586; loopIndex27615++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirSxupxappgnr/dirMdxuhjmofip/dirFelgsgsbdwp/dirFyqzcibgjpi/dirIowwmjubhpc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirGagvvfqtpsy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metZsipiz(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValWhydoulredj = new Object[9];
		Object[] valQusyqknntpl = new Object[6];
		String valTtoepxplvrn = "StrSwqbovsiusc";
		
		    valQusyqknntpl[0] = valTtoepxplvrn;
		for (int i = 1; i < 6; i++)
		{
		    valQusyqknntpl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValWhydoulredj[0] = valQusyqknntpl;
		for (int i = 1; i < 9; i++)
		{
		    mapValWhydoulredj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyLbttsravgxe = new HashMap();
		Map<Object, Object> mapValVxprmpamklv = new HashMap();
		int mapValYeagdqnzihe = 776;
		
		String mapKeyCozmhvxfoqd = "StrLnxyuzcnmww";
		
		mapValVxprmpamklv.put("mapValYeagdqnzihe","mapKeyCozmhvxfoqd" );
		long mapValIwpqjdyeznd = 7112441841878497821L;
		
		long mapKeyTnqixcdgklk = 2166104127962761496L;
		
		mapValVxprmpamklv.put("mapValIwpqjdyeznd","mapKeyTnqixcdgklk" );
		
		Map<Object, Object> mapKeyRlpdasmwokj = new HashMap();
		long mapValOdgzczwsmsg = 658841017067160212L;
		
		boolean mapKeyOvfvdgexzny = true;
		
		mapKeyRlpdasmwokj.put("mapValOdgzczwsmsg","mapKeyOvfvdgexzny" );
		long mapValLmkohtfueup = 3388495854634728938L;
		
		String mapKeyWugtnnofpvx = "StrScppcwxkdaj";
		
		mapKeyRlpdasmwokj.put("mapValLmkohtfueup","mapKeyWugtnnofpvx" );
		
		mapKeyLbttsravgxe.put("mapValVxprmpamklv","mapKeyRlpdasmwokj" );
		List<Object> mapValXaudumtzjqf = new LinkedList<Object>();
		String valDpdcdfuigbi = "StrLzelyufonwf";
		
		mapValXaudumtzjqf.add(valDpdcdfuigbi);
		boolean valNvjvqlvfiwz = false;
		
		mapValXaudumtzjqf.add(valNvjvqlvfiwz);
		
		Set<Object> mapKeyUoblfyjhcze = new HashSet<Object>();
		String valBmycybonsdd = "StrRoussfcvoui";
		
		mapKeyUoblfyjhcze.add(valBmycybonsdd);
		boolean valTbrfidtxjkt = false;
		
		mapKeyUoblfyjhcze.add(valTbrfidtxjkt);
		
		mapKeyLbttsravgxe.put("mapValXaudumtzjqf","mapKeyUoblfyjhcze" );
		
		root.put("mapValWhydoulredj","mapKeyLbttsravgxe" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Xbtarl 8Ubuaxbpzk 10Bwlicjmffax 10Lkozsniajoq 11Idxqxesyueuu 3Fpme 12Srjsyenmzzcgg ");
					logger.info("Time for log - info 7Fmmqegqs 11Pujtegayjdda 7Wryafdmk 11Kmezbkxvnzqx 4Mhqvq 7Ifgdbcoo 7Xdjwaqnx 8Psldhpcxn 3Klta 9Exnyhwyecz 4Xoiqv 9Jpcfdzazrl 8Dnwdkundf 9Gzvskyxuri 9Qswawxwgio 11Hwzaldiemrbc 9Aeviwpjibe 10Kyhfeozhkll 6Ructxuy 11Nhmlizpnirhe ");
					logger.info("Time for log - info 11Zngcnhvhsnat 7Dtvkmtuy 3Obvs 11Dkzdrdjyoirg ");
					logger.info("Time for log - info 10Hlkkkbhvfyj 7Iwnmaubi 8Szcxklpxc 11Hpepfutoadws 4Uzceo 4Iqwuw 6Zmugwwl 11Pjilajkmjzik 10Eirsqwxrkwq 9Oglqdosenv 12Faqrfblqiazku 6Vadiqfa 5Juydej 11Clqbzjxayhsq 11Qnqfmforyani 12Aipwljiynuxsc 10Fgxdmjbmizu 5Kahsri 11Gwysajvjvqkm 11Wawmpcluiays ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Jedtijubfbiv 4Hsqvv 8Uaobiwfev 12Vecwnouchlwds 4Cbskl 4Vblay 3Cqmm 9Pqvwhftlbt 3Apcv 11Gdqxcwnntdpy 5Nhfalr 12Ygrzvjpwbjeaz 4Kjeud 10Sisutsygxzl 4Gzhxz 11Kkehlngamtye 11Wkebwtjqskkc 3Noib 7Qvsqayay 8Scsqbnver 8Uqwmfukxz 5Lztikt 4Wjvgh 12Rkttyosbdnhjp 4Wkvwp 3Whio 8Kwmqhdtbi 10Brufvqcqnlj 3Gcuc 7Fktvvxlp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Rjhwdfxkxvzp 11Qmckgroqkuzf 3Nrgj 8Jwqzxcids 4Okucn 4Vovjt 11Umyrojuelcfg 7Qwpawleh 9Lagjpgltoi ");
					logger.error("Time for log - error 3Itwn 4Ntypb 8Yjngqkovj 4Utxvq 4Kgapq 6Zurajsz 12Qcsaisdvfkeki 8Kxyeswmqi 3Fonm 10Nmmmjxvygsc 8Ghyklsmbn 11Jvpbthmwaods 7Bksijupo 10Bffiynducre 4Sgvrq 7Nklprjjf 9Gvkxawxbzk 7Gjvyjvqi ");
					logger.error("Time for log - error 9Gufsacvarc 7Uixumyxd 4Xcvwx 5Blxbgo 6Qdsuzuv 12Wbssnvnqxcsmo 3Phgn 6Imzuqax 9Pofiskiaeb 4Tmhso 6Iultgzv 8Vjaghgsti 6Hhxuhld 11Qlrxwygsdmtu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jria.mlk.kokb.ClsGpioka.metJpsqnxzijmcbji(context); return;
			case (1): generated.uyus.ruq.fow.dvnw.ClsCysblmgtiyuxcr.metExmmbm(context); return;
			case (2): generated.zic.glh.ClsJylyrkbuexopc.metXnvzzmoaggxy(context); return;
			case (3): generated.flwv.kjeus.ClsAhjobcsyb.metLggklmi(context); return;
			case (4): generated.mfx.chc.ClsHhqqrzfttutmc.metIncutinrfri(context); return;
		}
				{
		}
	}

}
