package generated.otrak.sob.wdjq.subj.sgplp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsIiictfycdas
{
	 public static final int classId = 336;
	 static final Logger logger = LoggerFactory.getLogger(ClsIiictfycdas.class);

	public static void metWtlyyvaowbyrc(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValYrsbwcedcsh = new HashMap();
		List<Object> mapValPreqojlorub = new LinkedList<Object>();
		long valIawnxvwrdjp = 8351970936956355586L;
		
		mapValPreqojlorub.add(valIawnxvwrdjp);
		
		Map<Object, Object> mapKeyUhabwjmhzpq = new HashMap();
		int mapValJckkycrxsta = 974;
		
		long mapKeyRxsfquchmcu = -6119548160723016132L;
		
		mapKeyUhabwjmhzpq.put("mapValJckkycrxsta","mapKeyRxsfquchmcu" );
		long mapValZtuungwzfia = 6819334920930225151L;
		
		int mapKeyBbcczihtcap = 425;
		
		mapKeyUhabwjmhzpq.put("mapValZtuungwzfia","mapKeyBbcczihtcap" );
		
		mapValYrsbwcedcsh.put("mapValPreqojlorub","mapKeyUhabwjmhzpq" );
		
		Map<Object, Object> mapKeyJqzvackwjns = new HashMap();
		Set<Object> mapValAzqrstvetaw = new HashSet<Object>();
		int valZwlqwngushb = 95;
		
		mapValAzqrstvetaw.add(valZwlqwngushb);
		
		Object[] mapKeyNbcxmwhtldi = new Object[3];
		int valFepicgpzrzu = 54;
		
		    mapKeyNbcxmwhtldi[0] = valFepicgpzrzu;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyNbcxmwhtldi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyJqzvackwjns.put("mapValAzqrstvetaw","mapKeyNbcxmwhtldi" );
		List<Object> mapValFuyvndkzaix = new LinkedList<Object>();
		boolean valOfqlxfryrsu = true;
		
		mapValFuyvndkzaix.add(valOfqlxfryrsu);
		boolean valTlzyiokafyu = false;
		
		mapValFuyvndkzaix.add(valTlzyiokafyu);
		
		Set<Object> mapKeyXqvvqmsjqyf = new HashSet<Object>();
		boolean valHugrxpdbobj = false;
		
		mapKeyXqvvqmsjqyf.add(valHugrxpdbobj);
		
		mapKeyJqzvackwjns.put("mapValFuyvndkzaix","mapKeyXqvvqmsjqyf" );
		
		root.put("mapValYrsbwcedcsh","mapKeyJqzvackwjns" );
		Object[] mapValZidchzrsdte = new Object[4];
		List<Object> valGggvzcberjr = new LinkedList<Object>();
		String valNohqxadvyjn = "StrQeggzbknzxn";
		
		valGggvzcberjr.add(valNohqxadvyjn);
		
		    mapValZidchzrsdte[0] = valGggvzcberjr;
		for (int i = 1; i < 4; i++)
		{
		    mapValZidchzrsdte[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyTxttffsonkz = new HashMap();
		Object[] mapValPuwxdhckezv = new Object[5];
		String valOcgnjltaopt = "StrUvcgtnnxvyq";
		
		    mapValPuwxdhckezv[0] = valOcgnjltaopt;
		for (int i = 1; i < 5; i++)
		{
		    mapValPuwxdhckezv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyHbeqnavzunt = new LinkedList<Object>();
		int valQchdfcxhevr = 665;
		
		mapKeyHbeqnavzunt.add(valQchdfcxhevr);
		
		mapKeyTxttffsonkz.put("mapValPuwxdhckezv","mapKeyHbeqnavzunt" );
		List<Object> mapValAogdbuogite = new LinkedList<Object>();
		String valKkhrgecclml = "StrCxduqhywodh";
		
		mapValAogdbuogite.add(valKkhrgecclml);
		
		List<Object> mapKeyDdflzofayxn = new LinkedList<Object>();
		int valAlkbjwvncfi = 525;
		
		mapKeyDdflzofayxn.add(valAlkbjwvncfi);
		
		mapKeyTxttffsonkz.put("mapValAogdbuogite","mapKeyDdflzofayxn" );
		
		root.put("mapValZidchzrsdte","mapKeyTxttffsonkz" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Jjtqwogkjma 9Puadhuuvhu 8Wxpeybxui 12Ksbvbwcuuttns 11Wsnnnlqjofzf 5Kukryh 5Gkzjtt 8Bjtfucuyw 8Xcfniyglu 5Xilama 10Nlyazfglhdb 3Mtrl 12Emnmzzlyhkply 4Udjwi 9Qebalniqxp 7Ydqlptcp 3Gnfc 5Rbkjtw 3Mkrb 7Sfdcubfq ");
					logger.info("Time for log - info 8Cdmunnklu 10Flkqvlfexsj 11Nlkmmfxsgivs 7Ubeejjvi 8Bulxmifqr 8Jrnjgjows 7Shbwiguc 5Jbbghv 10Fpvmbbitnkn 11Skpcljntqvys 6Eqhacbp 5Tbhnyf 8Ivanytecj 12Vjeypvimukncu 12Nyynnwrnwavmt 10Ncyzwpreipj 6Vdbjjvo 10Uthhdmqzhoj 5Tdtymg 3Rvrt 5Louwnl 4Suohp 7Epfqmcpm 3Bbki 8Sltrxykey 10Wwderrtfkus 11Fohtxufuuoxg 4Rujxt 4Dmznb 4Wrfjc 9Xsbbmvuugt ");
					logger.info("Time for log - info 3Rzcc 8Sotvqerdc 8Zuewvahyc 9Xazswbqnet 7Joqejtyt 11Ucqwaeyjzuyo 7Nzcppjbt 4Dotfg 9Wjaqxvitlg 5Mrurme 10Luhwuqwjnoz 3Jyik 5Qhmcmj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bolg.tnlb.nmug.ClsHstaiufsowx.metPapexcx(context); return;
			case (1): generated.wtc.bgb.gahv.mul.rts.ClsUeuxdzs.metGmiqxl(context); return;
			case (2): generated.hcdv.yknh.ClsEeaftdg.metRwfpqecfughig(context); return;
			case (3): generated.aqdnu.puvg.gdad.ClsIxzvdsuksw.metWaxopqbol(context); return;
			case (4): generated.obwsb.fweao.vluj.ClsLnkmgpfh.metRmfxpeuo(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex25640)
			{
			}
			
			long whileIndex25638 = 0;
			
			while (whileIndex25638-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metTnuzyugemny(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[9];
		Set<Object> valHxmsyojflzz = new HashSet<Object>();
		Map<Object, Object> valJsjdgjvqbjk = new HashMap();
		long mapValLrihspzfgiv = -7369001021995550560L;
		
		String mapKeyWnsdxtorszk = "StrSgptvjhvqpk";
		
		valJsjdgjvqbjk.put("mapValLrihspzfgiv","mapKeyWnsdxtorszk" );
		
		valHxmsyojflzz.add(valJsjdgjvqbjk);
		
		    root[0] = valHxmsyojflzz;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Tgxsh 12Zkdgqeioyfmop 7Ctckkfiy 11Cujolrvimjdp 7Nmdflspj 8Isqwkmkyu 4Nzios 7Mztvxyyq 10Uutykxjddly 6Msjppsp ");
					logger.info("Time for log - info 3Azhz 8Utallcgad 12Bpbejaxpeatnk 5Ghluaj 4Qjypy 7Zhyvvaow 8Psnmqzezw 4Bfmgv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Cctnqgalm 5Lhozrk 3Gyvl 12Ksjqtjtraxyrv 3Koja 7Bwmzrqbq 7Mwgfghnp 7Sxkypjog 10Nsfzkgfjshv 8Melfidgva 11Uwlegtrwedjr 6Ivtzkdi 6Uzzkfku ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gmk.vzs.crbap.ClsEkyhsmjeh.metRgiazeewshcl(context); return;
			case (1): generated.unn.flt.iyr.tjmvm.ClsFuxljnbiciwosz.metIhsje(context); return;
			case (2): generated.udzdg.aoq.runwl.jiwf.ClsBbcobewbgt.metIishdsesvhq(context); return;
			case (3): generated.plye.kjczy.bmku.wrxrk.zek.ClsNtetu.metAmeedefvfwaa(context); return;
			case (4): generated.vfomk.ywmw.ClsYphqbuncz.metMivehrooaiow(context); return;
		}
				{
			long whileIndex25643 = 0;
			
			while (whileIndex25643-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metBiiorgnidrplu(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		List<Object> valEhwsdwmaaaw = new LinkedList<Object>();
		Map<Object, Object> valMdzbzgeplnr = new HashMap();
		boolean mapValYfluyveoqnv = false;
		
		int mapKeyEckrabtgytr = 515;
		
		valMdzbzgeplnr.put("mapValYfluyveoqnv","mapKeyEckrabtgytr" );
		
		valEhwsdwmaaaw.add(valMdzbzgeplnr);
		Set<Object> valIezmuaujojx = new HashSet<Object>();
		long valPmvumsyduth = -6105792059723762704L;
		
		valIezmuaujojx.add(valPmvumsyduth);
		String valCkjqnhimhbf = "StrAivknlwztvp";
		
		valIezmuaujojx.add(valCkjqnhimhbf);
		
		valEhwsdwmaaaw.add(valIezmuaujojx);
		
		root.add(valEhwsdwmaaaw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Bvdj 4Uakwk 11Ysaqavemfbvv 6Hkfsxie 4Pdhmc 12Akdgeozisscnv 5Jzcigy 3Csap 5Mlbayk ");
					logger.info("Time for log - info 9Dutmjwgata 7Kzzrwimk 9Anshqwvqxn 7Jgzhznnf 12Apxryocznznmy 3Tonb 4Fqpis 4Kklap 5Nrthjz 11Qyuqjectfnar 7Umzrbcwz 5Zxthzq 3Aady 3Rjti 8Qanubcejo 3Twsa 11Mjjkkzzwwuqh 11Bikzdefeqbkx 9Ykhfhejdpx 8Cynalgnyi 7Tiseukrw ");
					logger.info("Time for log - info 11Wfpsescviody 7Sqzsblhr 9Faaifdtobo 10Kmuzdorzbwk 7Iuyjcftv 10Wkfluzywxgp 5Brsfff ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Fhpqamvkyta 11Lmvchmorwhyx 3Xtiy 4Osfkz 10Cdbtpocbqfm 5Yqmwmr 12Tnjtayjinpuay 12Drcnyjxqqqedd 5Vhhdcn 12Xbnfqpdkedxzg 8Fdqleyivk 6Mtxuqoi 10Vwanfgvjbjs 12Zoljjggfozojy 11Dthoibvjdhgk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rlg.pxdte.svn.clv.ClsMkagt.metStdtlmnbk(context); return;
			case (1): generated.vhk.matvp.xpri.ClsIidoitanl.metMirdsxeleqw(context); return;
			case (2): generated.wrwx.jsm.hgij.abg.imgx.ClsRhzgz.metLbqpyboy(context); return;
			case (3): generated.xmh.glm.nii.qvkag.ClsSkjzsax.metHllaqgm(context); return;
			case (4): generated.qyalc.lus.ClsKvouelboluo.metVctwjruk(context); return;
		}
				{
			long varYiktbtlztqg = (Config.get().getRandom().nextInt(220) + 1) + (5747);
			long varOkzeewltzhh = (Config.get().getRandom().nextInt(103) + 7) - (Config.get().getRandom().nextInt(801) + 4);
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metBnsdi(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valVaxahrgkgne = new HashMap();
		Set<Object> mapValAizanlrfxhu = new HashSet<Object>();
		String valBlnjiiwovox = "StrSwfpzhihmyo";
		
		mapValAizanlrfxhu.add(valBlnjiiwovox);
		
		Map<Object, Object> mapKeyMmyohxcpvem = new HashMap();
		int mapValArpjmljcywu = 739;
		
		long mapKeyNdwogoaregi = -4526899813282266855L;
		
		mapKeyMmyohxcpvem.put("mapValArpjmljcywu","mapKeyNdwogoaregi" );
		
		valVaxahrgkgne.put("mapValAizanlrfxhu","mapKeyMmyohxcpvem" );
		List<Object> mapValQxvssielscm = new LinkedList<Object>();
		String valLidrluyrupe = "StrHfdsmwpgrjn";
		
		mapValQxvssielscm.add(valLidrluyrupe);
		
		List<Object> mapKeyXxnsbkjwkzn = new LinkedList<Object>();
		int valDovskirnnmc = 385;
		
		mapKeyXxnsbkjwkzn.add(valDovskirnnmc);
		String valEljvyisemhh = "StrTitrxkehcbr";
		
		mapKeyXxnsbkjwkzn.add(valEljvyisemhh);
		
		valVaxahrgkgne.put("mapValQxvssielscm","mapKeyXxnsbkjwkzn" );
		
		root.add(valVaxahrgkgne);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Waftdgl 6Kqfrnyy ");
					logger.info("Time for log - info 12Mbjeugstkuixo 4Tfetw 12Xzignvymlqfbz 11Gpgeqfzdmgwi 11Jonuiuuwcket 7Cydlgmqo 4Ueloa 8Nbzedjhzq 6Jivctmp 8Nfjfycrbg 5Xbsptk 10Kucisamtyfz 9Krjulxzaqt 5Xpsayb 12Limuxorfkapqi 12Rlyqdxkklavze 11Dpivofcpsbbe 9Jbiglmwxvo 4Soiux 10Avhcchfddcu 5Dvkvol 10Inzpywjyafl 10Auimfqfvhwh 11Xrlccrbjasvc 11Guhtzxtjppkw 9Riptyoqznf ");
					logger.info("Time for log - info 8Wvwyiwemh 3Zbfr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Lrpcofuxb 5Ihmzvu 4Fqocr 5Zvfoyv 6Ystacqm 9Urmrlwyzfp 3Pjdt 7Pevgpnuw 9Hhnaqqfrer 11Pbbpkksxdppw 6Jzdclmv 3Mfys 4Jdkab 5Dzsvqc 4Kxjyp 9Itgcahmkgf 11Ozvunwlqroii 7Xvqmevoo 5Mczghu 11Vvwbypdsqtpj ");
					logger.warn("Time for log - warn 9Rnqiumbhwt 8Aeozdzgxi 4Crrgy 12Cantdjfwvzbta 7Vwhagfxh 12Rwfhilasjpbjq 12Kndewzogezrsu 9Ciayzxnngx 5Vwtmeq 9Unlqmcozvl 3Kvep 3Eblt 8Mmzsirjkw 5Kysjnt 3Qvwn 11Ihtrycizilav ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Mizugp 9Ccstkwjihm 3Cpsh 11Kgursrxuqtks 11Gzjqfxdvceyv 4Asgwt 3Ykbt 7Rgtdsoip 9Kpcwwqenht 4Ayjta 6Iiyfueb 4Shwbu 8Xlzfnzvgn 8Afuwafuts 5Drifsw 10Khkpbcybhou 7Bdjfkcts 10Rlmuwtpamuf 7Tdfahhrd ");
					logger.error("Time for log - error 8Attywqmoi 6Gedgoka 10Vbegzigzlmh 6Apgjsuh 6Hmxyujt 5Yoabjz 11Svxoevkrsflg 7Sxpuckhc 11Piucnnijjneh 4Cknre 5Yfnslv 3Fcif 4Jtgfb 5Hpyhmm 6Hjyfkqb ");
					logger.error("Time for log - error 7Syjqniex 4Tdkqd 10Vwuytzuogkm 12Awrzdnrrncgze 12Yflcznbxpqvcn 11Wffaupoxovip ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.spdv.axe.ClsZyjdutdtmcu.metNmxmzbxtrj(context); return;
			case (1): generated.aisq.ykt.yfxh.ClsRqviupmemczv.metFawupdwqkldp(context); return;
			case (2): generated.vvl.eygsr.pmv.fzat.xuhvb.ClsRspudgdgeelrz.metKpypbtozts(context); return;
			case (3): generated.vrd.lunc.tgbks.iqcsu.cjgc.ClsExboagkfroi.metJpxnmgnwfaj(context); return;
			case (4): generated.kwutd.ipdj.aoc.ClsFtolmgndn.metLhyuqqu(context); return;
		}
				{
			int loopIndex25653 = 0;
			for (loopIndex25653 = 0; loopIndex25653 < 5714; loopIndex25653++)
			{
				try
				{
					Integer.parseInt("numAyfwxzwaihu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
