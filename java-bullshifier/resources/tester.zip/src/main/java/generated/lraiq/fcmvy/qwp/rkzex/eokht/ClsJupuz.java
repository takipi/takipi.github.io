package generated.lraiq.fcmvy.qwp.rkzex.eokht;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJupuz
{
	 public static final int classId = 212;
	 static final Logger logger = LoggerFactory.getLogger(ClsJupuz.class);

	public static void metYgzcykugupxev(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValNpdtdjdhysx = new LinkedList<Object>();
		Set<Object> valBxuwadikioa = new HashSet<Object>();
		boolean valBwxogphnboy = true;
		
		valBxuwadikioa.add(valBwxogphnboy);
		int valGoyyxkgwmll = 674;
		
		valBxuwadikioa.add(valGoyyxkgwmll);
		
		mapValNpdtdjdhysx.add(valBxuwadikioa);
		Object[] valAbzbseqlgst = new Object[10];
		long valGaaikhibezs = -7269415459824143341L;
		
		    valAbzbseqlgst[0] = valGaaikhibezs;
		for (int i = 1; i < 10; i++)
		{
		    valAbzbseqlgst[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValNpdtdjdhysx.add(valAbzbseqlgst);
		
		List<Object> mapKeyNgmftzdpyek = new LinkedList<Object>();
		Map<Object, Object> valChngazxfawy = new HashMap();
		boolean mapValTbaraonjtno = true;
		
		int mapKeyChywjbwwwgm = 643;
		
		valChngazxfawy.put("mapValTbaraonjtno","mapKeyChywjbwwwgm" );
		boolean mapValWlefncsnpzt = false;
		
		long mapKeyTvcikxjkoth = 7740869891451253231L;
		
		valChngazxfawy.put("mapValWlefncsnpzt","mapKeyTvcikxjkoth" );
		
		mapKeyNgmftzdpyek.add(valChngazxfawy);
		Object[] valEtydynwujgl = new Object[7];
		boolean valUishzmozhry = true;
		
		    valEtydynwujgl[0] = valUishzmozhry;
		for (int i = 1; i < 7; i++)
		{
		    valEtydynwujgl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyNgmftzdpyek.add(valEtydynwujgl);
		
		root.put("mapValNpdtdjdhysx","mapKeyNgmftzdpyek" );
		Set<Object> mapValQxxgxuppmra = new HashSet<Object>();
		Set<Object> valHaifuagjmca = new HashSet<Object>();
		long valObxufaptomw = 6122163768639708738L;
		
		valHaifuagjmca.add(valObxufaptomw);
		
		mapValQxxgxuppmra.add(valHaifuagjmca);
		
		Object[] mapKeyZqccamalraj = new Object[10];
		Set<Object> valAnkjsisvhcm = new HashSet<Object>();
		int valUoiapzlljnf = 860;
		
		valAnkjsisvhcm.add(valUoiapzlljnf);
		String valNjtkozeqvbt = "StrBqcbtqsgsll";
		
		valAnkjsisvhcm.add(valNjtkozeqvbt);
		
		    mapKeyZqccamalraj[0] = valAnkjsisvhcm;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyZqccamalraj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValQxxgxuppmra","mapKeyZqccamalraj" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Rxkukrfmc 12Ukolqnyqcrptc 5Cwqkuu 8Mepmzlzxa 4Imhko 7Isrpohoq 12Vtiqtcltogpjf 11Tvqofbisyqyy 5Glhhcx 7Etgdlhhv 6Fvaarha 3Xbts 11Yextnwifxeuq 7Fgogotac 11Gvpshqrnqqkm 9Gnifrbmtck 5Umrkyf 4Svjlz 3Cfuq 5Friuah 10Ikuomfxhxjx 3Kfgs 4Luukh 8Uozhghcvi ");
					logger.warn("Time for log - warn 4Mfpia 4Ixgkj 5Blxkez 5Sghhvr 3Yiig 5Elbkoc 6Xvbbmgl 12Hyetfhlwwqhsf 3Ukzq 4Kruhl 5Fxkdsy 5Xatdzq 6Cujcygk 4Uwgef 4Pzpvy 5Qpesvr 4Ogxfi 10Plciwkzqrle 5Nneuyq 6Zyvselq 6Jqzfftg 3Tmkg 10Huflhhdijub 10Ftbnfygmvyc 9Axbstwxafr 5Myvrwk 12Ommqlmbakqxwd 3Uvqn 11Wkcfjpeqtgsh 6Nmepybg 7Gctvyetl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Dtynrugzme 7Lhdthtvx 8Guqxruhoe 8Uutsxjddy 7Ujbqwxwe 11Niohhzugyiqj 10Rzvewaflbki 11Etgwgtkkeckj 12Phjqmswdfljsm 5Rogsad 12Kaocdmtyrnfei 10Fxbxlmjrhfi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xvt.cmvm.fgj.efz.bawb.ClsIacmgbgh.metHijjkg(context); return;
			case (1): generated.krka.pbdp.kxfhk.gqt.tfv.ClsAdvwmtrn.metDvriulzpcrhbb(context); return;
			case (2): generated.zuj.yzx.nga.pvup.ClsJyskqhfglgbk.metBegxo(context); return;
			case (3): generated.xajsm.xnlym.ClsUmfzchfskds.metCirgapizik(context); return;
			case (4): generated.drdz.aky.gfc.cjlsi.ndn.ClsMzlwuddsrmx.metPkkootprwfykih(context); return;
		}
				{
			long varMeutjluvfga = (Config.get().getRandom().nextInt(276) + 7) * (Config.get().getRandom().nextInt(793) + 7);
		}
	}


	public static void metOxzzhqatm(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValHbvuaudguqe = new HashMap();
		List<Object> mapValCbulzgdekko = new LinkedList<Object>();
		boolean valYsdxdlodyvb = false;
		
		mapValCbulzgdekko.add(valYsdxdlodyvb);
		int valToardgzxaji = 125;
		
		mapValCbulzgdekko.add(valToardgzxaji);
		
		Set<Object> mapKeyEvchgpjlutf = new HashSet<Object>();
		String valRjweiuqgckz = "StrScpjveyyfuc";
		
		mapKeyEvchgpjlutf.add(valRjweiuqgckz);
		
		mapValHbvuaudguqe.put("mapValCbulzgdekko","mapKeyEvchgpjlutf" );
		
		Map<Object, Object> mapKeyVqlhbadnbrd = new HashMap();
		Set<Object> mapValCjoewcfmjjj = new HashSet<Object>();
		long valUllrocaladk = 6730022514886835750L;
		
		mapValCjoewcfmjjj.add(valUllrocaladk);
		boolean valRidwkrvmihw = false;
		
		mapValCjoewcfmjjj.add(valRidwkrvmihw);
		
		Object[] mapKeyDyqfnyckuvp = new Object[5];
		String valQignhnwlukm = "StrYnnnupxbtkl";
		
		    mapKeyDyqfnyckuvp[0] = valQignhnwlukm;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyDyqfnyckuvp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyVqlhbadnbrd.put("mapValCjoewcfmjjj","mapKeyDyqfnyckuvp" );
		
		root.put("mapValHbvuaudguqe","mapKeyVqlhbadnbrd" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Lexectkoyihi 3Jwnd 8Dfnkjfxrs 11Rucgfaslrhou 5Amrdoi 6Vtobvgu 5Vjqwel 4Xshty 6Omeykro 8Vwqjomiif 6Syfhaji 12Ztkdapiailebz 9Pikmmrkzja 12Eetnebmkajdsl ");
					logger.info("Time for log - info 3Rgrk 3Emrh ");
					logger.info("Time for log - info 3Wzmh 11Mqdgqnsouwhp 7Jyozrllq 8Vzssabavy 3Xzfr 8Kmtqwwumo 5Godvsk 12Ohqklnqzfqcyv 5Pdghgg 6Nnngsxs 6Lhslxns 11Axxhkevjstff 8Xfxorfkax 4Culls ");
					logger.info("Time for log - info 11Wxztyonjoxzg 8Opnccvzcs 6Vkvaoab 6Wwbfznj 12Ecljqvsyjdbgo 4Zineu 8Zcxuvhjmm 4Pzcph 11Szkvuvyggpgt 12Ikqxattfmwquo 10Izdrbmblvas 6Dbbjrsj 4Qwzdw 8Kkvvfwoqu 12Icpqdkphbbzch 7Nvjicyvd 9Ioagxuutvt 11Oyzzyzjjabyq 10Kberytonaux 3Fvwc 6Cmpcdvr 8Qdctchzml 7Ydzlmgrg 8Wtebhuheq 6Jxjknrj 6Rxuxqxd 12Mwelgshmjjmua 6Zqubude 6Jnskgio ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Eouv 10Vxcdqobbyju ");
					logger.warn("Time for log - warn 3Mxxl 3Tufv 10Hmqerlnwvhx 11Gesxspcfqcru 6Afdijiy 11Dpxhnkvuizej 10Tdynvxvbeki 4Evypq ");
					logger.warn("Time for log - warn 12Jcospmpprmqck 12Kxqncfznzxoti 11Fsewjsqeyvov 6Dvpwtjz 7Gyaucghy 8Riigkwwvc 7Hwecamec 10Gkdvzvdkwfw 5Efrgjx 12Qempbykibpttd 5Wupqcz 12Fpdxvwlhltjuh 10Fgduqcguxzs 5Blqpyh 9Okgvgubvwu 10Tkmesadiazd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Gvuaoozyccjiu 10Hfrnueatrbi 7Ufqhnmfs 8Yhpxuxpox 9Qrapeiasgn 9Wxsnarpqbl 7Uqysgdyt ");
					logger.error("Time for log - error 11Mgolivcmnfnm 8Ujoujgpcw 4Bbuoy 5Hxnigm 3Pjtj 9Lapnssoohs 3Rdpb 4Tzrzm 4Nxial 8Chigblscr 12Znimhlgqmjmks 5Mdkwgb 4Gekky 6Nwyvufc 8Jwmtiducn 5Hfkkwt 12Ciiqrarbgqqxa 10Waywcqonxpq 8Vpvvmnwad 9Zskchgkwix 3Woyi 7Hblvjakw 8Ppqcmnkco 4Ivmnc 10Rafzoniumxl 9Wofcipxcik 11Esxelsrmrfgo 7Getdvgiq 5Fiunxs 12Ufvxlinpeocao ");
					logger.error("Time for log - error 5Eizgng 12Itmeunhxlgjdj 6Cdneiex 9Wriiegjtpl 8Llryafygv 9Xkbadkfdqq 4Peupz 4Obspq 6Krlwmqj 11Snyovaitocyk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rjuw.mmbua.ClsRawvqxmhewbl.metBvnihykij(context); return;
			case (1): generated.ecksk.wvb.ClsNtqfbmlui.metOzgvgztdgxgwck(context); return;
			case (2): generated.nexb.cijvx.oksu.fhpbq.ivltf.ClsErarfyfw.metMuphdva(context); return;
			case (3): generated.ocmm.ezbtm.vxyei.kuseg.ClsUqzgoaq.metGzyab(context); return;
			case (4): generated.gyic.epw.ClsQxhbkrqjzoqujk.metCxlwimqqzxfd(context); return;
		}
				{
			int loopIndex23758 = 0;
			for (loopIndex23758 = 0; loopIndex23758 < 5146; loopIndex23758++)
			{
				try
				{
					Integer.parseInt("numQhedqzjapdm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex23759 = 0;
			for (loopIndex23759 = 0; loopIndex23759 < 5992; loopIndex23759++)
			{
				java.io.File file = new java.io.File("/dirTujsfxnoirh/dirGdbvityprtl/dirJygbppsthhu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metVmcuy(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[2];
		Set<Object> valTsbdopeejyx = new HashSet<Object>();
		Object[] valGurfnykzhri = new Object[9];
		int valKtxireavmyg = 943;
		
		    valGurfnykzhri[0] = valKtxireavmyg;
		for (int i = 1; i < 9; i++)
		{
		    valGurfnykzhri[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valTsbdopeejyx.add(valGurfnykzhri);
		List<Object> valSxvigzmfuqn = new LinkedList<Object>();
		boolean valZzlybftdmyq = false;
		
		valSxvigzmfuqn.add(valZzlybftdmyq);
		
		valTsbdopeejyx.add(valSxvigzmfuqn);
		
		    root[0] = valTsbdopeejyx;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Tiuqgrqh 5Zhyics 5Bpvmga 12Jbqqzjrfiwhty ");
					logger.info("Time for log - info 3Koxt 5Dhffgz 12Bshmeqyowgwkl 6Lqsnhod 9Imwnmrento 7Ulbzbldl 3Qgol 4Cxzdn 10Jrtbompjucd 12Rfjzbgojizgqt 4Jbysx 11Jotprgualnol 11Nzfazmszlkos 12Ldqprnotvzplg 3Hyzo 11Pweceoplzaji 5Zvuesg 7Jnzluuha 12Jheqypgefnhop 9Qzaenbikms 3Qyal 9Xucaaxrhsu 3Meud 7Aqtlwxkz 11Tpwccsplusxx 10Annighlcico 6Bcohvut ");
					logger.info("Time for log - info 9Ejpzqqeqjc 5Egesex 10Qjuyzfabrna 12Zvrfrgequjcgm 4Trihs 8Idsqaewax 6Ijplogh 10Auokefluqdc 11Nobzlqlpzxmn 5Hzdkad 4Gjsll 4Liizh 12Vbszhsqemcuoi 6Ggfwddy 6Fkswlxn 6Pgtzjws 7Lrqzqldd 12Mgfiymadjbdcm ");
					logger.info("Time for log - info 6Lagzkwh 3Fqbx 6Xklpeqg 4Yxanr 5Oxsotw 11Zzqpttlgfgzo 3Rdec 12Bapplvsmvgdhn 9Xrcgslthll 9Fflgdmpuzc 7Twubarct 3Rugr 4Gaucg 6Degdbtx 11Kfcwoewjautl 10Cadhuvoewrn 7Cacdvagc 3Epea 8Akxjyqeos 8Rpsuoufca 4Sudls 3Msri 3Lrwe 9Nbptqwahka 10Fkpmbkptpts ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Wmca 12Wkmsrydzzpztd 7Yctqbdxt 10Ouszwaolwux 3Roer 6Dbzvfep 8Bkypthtzc 9Jnjvakvmle 8Blajckknu 6Ppfbspz 6Qowwdft 4Phjgx 4Iisep 5Mggkkz 8Ekqicbpzs 5Tfjjql 11Chcwxlunhlyo 3Hspm 6Dpcynjz 11Wasvgzmhhufg 8Fwavgtzms 12Niwasmfhzmnkq ");
					logger.warn("Time for log - warn 4Plmhs 5Ixbquh 6Jureybr 11Lmisezrpywgo 5Rvdrel 10Omcrcbncatm 5Qkgfzv 9Pzhuzhytbt 10Zjvnpteanml 8Svpxxgnlt 10Ntqtkrxznbz 10Ueintttvkre 9Srswjoslme 10Wlzxlasihqt 4Npygp 4Ttuof 3Yqzn 6Ughofua 9Uzywrqpsuq 4Uqqrt 6Trbpnee 4Opkvg 9Rhszxnwxie 4Wxmbh 4Nihbn 5Oyljwx 9Sdepiykxzn 4Acgfo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Whecupwxlof 6Fxzoxwg 6Tyaozkq 8Ypunirkge 10Dwtusamgsse 10Qdpcqgcrdaf 7Ypmeraec 3Wssj 9Ghkrtsybbg 6Lvordco 11Clrvbqeejirh 4Afzyf 5Rjqgnf 12Kexmermmonsgw 11Zirqujyfjvsr 9Yxsckfgihp 6Pjmeyeg 4Qeqbw 9Sskthegqgd 4Pmydw 5Gykgix 6Qglwnbx 9Rwiraelyfv 6Lqvnrab 8Pnpfdgctr 5Yuqgxr 10Rferaezcyhw 11Xescwylyybfh 5Iadtcb 10Njqwkclajfs ");
					logger.error("Time for log - error 3Nfjw 8Rfqnfnswv 10Xzjppnwrseh 12Adktkjshuvcbd 7Xnfehycv 10Gqgqowapjgx 10Icsbuidyqap 12Bbdfeatitgobk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cin.hewe.akg.wyf.seuvv.ClsFgxjhcrdocnyas.metKhzutma(context); return;
			case (1): generated.cpb.wnddu.ClsLvopzbmgvjj.metJpplktwh(context); return;
			case (2): generated.uwqq.rznca.ubddn.auo.ClsOkthnaihqahfl.metJezqzyduxos(context); return;
			case (3): generated.bkbep.bjvph.skry.qijli.gfl.ClsFlycqobnxjszt.metGocmomhxeq(context); return;
			case (4): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metGigic(context); return;
		}
				{
			long varTsdymwwqwdo = (4329);
		}
	}


	public static void metWvwztkw(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valDaduvilvmcm = new HashMap();
		Object[] mapValRkwbgkuuifz = new Object[6];
		int valOdquvwovjwh = 25;
		
		    mapValRkwbgkuuifz[0] = valOdquvwovjwh;
		for (int i = 1; i < 6; i++)
		{
		    mapValRkwbgkuuifz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyOrobrugnolx = new LinkedList<Object>();
		int valZyfjvwtfagn = 878;
		
		mapKeyOrobrugnolx.add(valZyfjvwtfagn);
		
		valDaduvilvmcm.put("mapValRkwbgkuuifz","mapKeyOrobrugnolx" );
		
		root.add(valDaduvilvmcm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Vcwteodhqwiiw 12Qtddpcgmrrmbj 10Eraodbhbbgp 12Mbepeqibowwnn 11Sukwkogylfim 8Ygcjxvqjc 8Rwuceinom 10Vzeeglcjuov 9Kvotohdzud 7Ynyoyuuw 10Stqendqvcxi 12Fsxbygjpfcxrl 10Ybgdnchrzpp 10Rtbufyjelmv 10Cpwalelaxur 6Tzuiusf 5Rupums 5Loecxq 9Sbchmzwkcs ");
					logger.info("Time for log - info 5Ufofvs 10Yindbaecjhj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Miinixrhqw 7Audggcse 7Vafuvccc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Lokjnj 11Ufmbsxbskdgs 6Dregxmo 3Lkmo 3Vcja 6Dfoihbc 11Wjmifhdukyta 6Sugnojo 11Mzkzjzgchmap 11Tjrofzczsqfw 9Ozqamdivel 3Uffa 4Agxww 4Gszwd 11Mnlcyslhjnmw 3Aude 4Zihwi 8Oqkxugult 5Mvkfdm 9Vcnufpchor 8Pofxawxto 10Lztrvwciqye 7Hgywltov 6Xqnmfec 10Htlqqkxbgxn 4Uuqmc ");
					logger.error("Time for log - error 12Iwltkzkwdtkff 12Nvcsohmzrgkdh 4Evgct 4Oqlkl 4Itwyf 9Txpwalnjpy 10Keajhfiaasr 4Frvbi 10Dqjjimaxgbu 4Rkzqf 10Tprfwgzfeen 5Cutega 5Wlobap 4Tlpjm 11Lypdznyytwpg 4Estxq 6Ducudla 7Pjspftjr 5Ydcfki 7Haoospoi 5Acqueg 9Gnpwpesljw 11Vpmfshntwxpv 8Vdwqcbrcc 11Tnntrlmipjpj 8Hoowbjnls 10Icgcugmvkho ");
					logger.error("Time for log - error 4Gqtvk 7Tskwzcsl 5Ukwptt 9Rcbnwffsog 5Pajefl 8Zfppuemet 12Umclkvxemdizc 4Rovbw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nclk.lhd.awxff.ClsWzypoogjnr.metXvtfzticubdsik(context); return;
			case (1): generated.kfvy.ymxa.end.hazk.nwqfn.ClsXakhsfoyrlse.metJcgkp(context); return;
			case (2): generated.avme.rnc.ClsUgqeozcqx.metIsegbgah(context); return;
			case (3): generated.joeal.ovr.nvb.kqkl.kegr.ClsNehitk.metGvuga(context); return;
			case (4): generated.wzzy.rguqw.bfm.ClsCumedne.metJavfokczruv(context); return;
		}
				{
			int loopIndex23766 = 0;
			for (loopIndex23766 = 0; loopIndex23766 < 8776; loopIndex23766++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varFolavqgdcru = (5707) + (9874);
		}
	}


	public static void metTywqcdpv(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valBrcusdxylaw = new HashMap();
		Object[] mapValLxdanlbbnxr = new Object[10];
		int valBmwxzuwlnby = 684;
		
		    mapValLxdanlbbnxr[0] = valBmwxzuwlnby;
		for (int i = 1; i < 10; i++)
		{
		    mapValLxdanlbbnxr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyTxbsdfrluww = new Object[11];
		int valFqbncwcrerv = 683;
		
		    mapKeyTxbsdfrluww[0] = valFqbncwcrerv;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyTxbsdfrluww[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBrcusdxylaw.put("mapValLxdanlbbnxr","mapKeyTxbsdfrluww" );
		Map<Object, Object> mapValYkfkpnzpibw = new HashMap();
		int mapValMxfrordkeoh = 117;
		
		int mapKeyGbanvsvyogo = 242;
		
		mapValYkfkpnzpibw.put("mapValMxfrordkeoh","mapKeyGbanvsvyogo" );
		String mapValUhkqzzmaicm = "StrJyqgnkzcrho";
		
		long mapKeyQzyhvicmppq = -4592206820835030534L;
		
		mapValYkfkpnzpibw.put("mapValUhkqzzmaicm","mapKeyQzyhvicmppq" );
		
		Object[] mapKeyPvjrcjwijgx = new Object[3];
		String valQmsmngdcght = "StrXluwloudsdy";
		
		    mapKeyPvjrcjwijgx[0] = valQmsmngdcght;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyPvjrcjwijgx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBrcusdxylaw.put("mapValYkfkpnzpibw","mapKeyPvjrcjwijgx" );
		
		root.add(valBrcusdxylaw);
		Map<Object, Object> valSegeikrtmks = new HashMap();
		Object[] mapValQikmutcormd = new Object[4];
		boolean valLorlzwwitey = false;
		
		    mapValQikmutcormd[0] = valLorlzwwitey;
		for (int i = 1; i < 4; i++)
		{
		    mapValQikmutcormd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyVetwnilfkbd = new Object[8];
		boolean valAruvgycljnx = false;
		
		    mapKeyVetwnilfkbd[0] = valAruvgycljnx;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyVetwnilfkbd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valSegeikrtmks.put("mapValQikmutcormd","mapKeyVetwnilfkbd" );
		Set<Object> mapValNdsjauzpsei = new HashSet<Object>();
		boolean valAalzscjvjdj = false;
		
		mapValNdsjauzpsei.add(valAalzscjvjdj);
		
		Map<Object, Object> mapKeyCvklbfvjqzf = new HashMap();
		String mapValIfgrqfednrv = "StrQknawpbufoj";
		
		int mapKeyMfmopjedtzv = 983;
		
		mapKeyCvklbfvjqzf.put("mapValIfgrqfednrv","mapKeyMfmopjedtzv" );
		String mapValPlneyrijyqh = "StrRueltdhijjy";
		
		boolean mapKeyWxcqcjmzywp = false;
		
		mapKeyCvklbfvjqzf.put("mapValPlneyrijyqh","mapKeyWxcqcjmzywp" );
		
		valSegeikrtmks.put("mapValNdsjauzpsei","mapKeyCvklbfvjqzf" );
		
		root.add(valSegeikrtmks);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Ghnhdziwgfe 10Rehwdxhujdi 11Ozkrzwfwxavz 5Asyjyc 5Vuvmeq 5Cjxjht 11Hbirimjujoks 9Dnozurxuvs 6Gyxjrcy 10Yoquanucwhe 12Rwktknsgcgadg 10Igtjekudgdu 12Xdjrmgddbaroy 9Rznmlbtgmu 3Wvjj 11Ckhkcrwbsgld 9Zxtamzzdrh 12Lbhexpkkoahgs ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Frjprrp 9Dzfusmyddt 11Nlcgyxkfgnfw 3Zwxa 10Dtorqactpra 3Jjsa 4Rizdt 3Qewq 9Dhcgnnkcfu 6Mqjmrim 4Ouwxe 7Afhguhti 7Mzwdtpbe 12Pbekgadscfvnt 7Rihlyice 5Nhzgku 10Rxbsouazaox 7Enrsjrmp 11Wumjjapnhnsf 12Rumhfskugltjw 5Jrnazc 6Ojzshim 8Mpvgtelrz 9Mnmqfrkdto 6Yszlowp 4Vnoil 11Vwxyotkzvymk 11Bvkkutgobqrb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lbx.ujwf.wayq.ClsEtipntwjjs.metYkgppbepgd(context); return;
			case (1): generated.deuz.rvz.jsq.ClsHbyckyeswad.metJegrkbyqxodbpi(context); return;
			case (2): generated.lsv.svu.ClsVsswgqo.metRpymmmock(context); return;
			case (3): generated.axdim.stv.ClsSaegiqo.metKmdsuvjx(context); return;
			case (4): generated.xqub.fxwha.ClsHlclqblgzonjn.metRwhisq(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(144) + 8) + (9207) % 229869) == 0)
			{
				java.io.File file = new java.io.File("/dirVenzsftjpzh/dirKarrgzgbsmt/dirCfoorncfuzr/dirDzuemllzznb/dirIyrixnhvdot/dirZzyllmrbkzf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numOakjbckfhdi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((4591) % 951946) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(558) + 1) * (2976) % 583443) == 0)
			{
				java.io.File file = new java.io.File("/dirTwykdtojchg/dirRoipfavmxbb/dirDratnhmdujw/dirKgvymgzfnyc/dirOqkvcnasmrl/dirVopzrvdazyo/dirRfjgwvgqmdb/dirOfvxdzistjk/dirAvnoheenjgc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varNohjgdmxvsa = (4506) * (Config.get().getRandom().nextInt(170) + 8);
		}
	}

}
