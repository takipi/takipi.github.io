package generated.gfiaw.wgvz.askqs;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsGbqekumwdbwfn
{
	 public static final int classId = 261;
	 static final Logger logger = LoggerFactory.getLogger(ClsGbqekumwdbwfn.class);

	public static void metVqqri(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valAbjxqysrsnk = new HashSet<Object>();
		Set<Object> valGshcsqtmggn = new HashSet<Object>();
		long valIqxststdodj = 8534386453049187855L;
		
		valGshcsqtmggn.add(valIqxststdodj);
		
		valAbjxqysrsnk.add(valGshcsqtmggn);
		List<Object> valYzlouctuqgm = new LinkedList<Object>();
		long valHqphrsxjugw = 9137674052253245976L;
		
		valYzlouctuqgm.add(valHqphrsxjugw);
		
		valAbjxqysrsnk.add(valYzlouctuqgm);
		
		root.add(valAbjxqysrsnk);
		Set<Object> valXrknpjepznn = new HashSet<Object>();
		Object[] valCbkfeegypoc = new Object[3];
		long valXkssjaqgltw = -7898197135758280335L;
		
		    valCbkfeegypoc[0] = valXkssjaqgltw;
		for (int i = 1; i < 3; i++)
		{
		    valCbkfeegypoc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valXrknpjepznn.add(valCbkfeegypoc);
		
		root.add(valXrknpjepznn);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Ywbfezruxbihd 12Eewyhsepighth 7Jdvpyluo 6Povydrt ");
					logger.info("Time for log - info 11Dwnwimusacom 7Dusjbeex 10Ahnatcjdovr 7Hrubqbfw 11Rjlmabqscyiu 6Ldxgnlr 11Czioorklwjzg 12Ilpplzedjuegi 4Nrkuh 9Eepulcatek 12Itqldfrehwtrh 6Nzhpycu 11Bvqsitlaehpu 8Xjysbodel 11Ukqnmrczmlcf 11Wjokpfloforv 8Lqnwsnioa 5Zbomtc 5Zqpcth 3Rfgh 9Dwknrcvrvp 10Xoejdqovmfy 7Bjlzbqse 7Amodlpua ");
					logger.info("Time for log - info 8Dzxnptesr 10Jlrqyerzclb 8Vmzlxipsg 5Cqiair 5Tylhyw 12Lykveswanposw 11Ylcxaidpixmf 11Wdpavwlrlweq 7Jcvkpxlm 10Ktfooptthaa 10Bcvfsuxgcqt 9Nohthaeebr 9Rofdvhwbvx 8Vlirbctpc 8Pxrcpogsw 4Qyczt 8Ubtjjtegw 12Hxkagdmtyocqm 11Xpsbxpefqvjz 6Txjxvnw ");
					logger.info("Time for log - info 8Dgitnlwjb 9Vutkgzuymr 8Koorzjshx 7Caacnnzg 5Ageeje 6Buuplhc 3Qrtf 5Hzdmms 11Nbstrenbilem ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Suwbcxld 12Pinspvntovqbr 12Gfmchhuclcwdg 3Nfyu 12Ntvgadvyyuvoc 12Rwhxfjtlpqbeh 5Ndfciq 6Fzmnuhb 7Xspwbqfi 5Wbymfd 3Rigl 9Uaonkvgjap 3Rion ");
					logger.warn("Time for log - warn 9Hwytjysgpv 3Lwjd 6Ruguvhp 8Bqsqklikv ");
					logger.warn("Time for log - warn 8Yrlvlnkfk 12Lfzlthxhvmplw 9Nzonaqecof 10Ppitomyqqfi 4Mqxki 7Eajkuhiv 10Xtbrrdgrwqa 5Uawgmn 7Thkjrcvg 7Copnzufk 8Vkiodqbqs 5Ceqnbp 11Hfaqmnilqjnp 3Myle ");
					logger.warn("Time for log - warn 6Sjuykjt 10Sbeqkuzxjdm 10Ncxblrrcrpy 9Wuhnzmbmrx 6Gfgvsxi 3Cfrk 5Ttbznc 10Mbgcqvkhbor 3Qygy 11Ftzezgrwfwzw 12Lkzulrnagbioz 12Wehkxgkubwaym 4Apssg 9Fablnrthrh 10Tzklrjiwuyq 7Vbjjyjgq 10Syumeemcztv 6Kdyulvl 3Wddz 12Tpviibgmbbinb 5Wykvto 3Bjuo 12Wdmncisgfenai 3Qgdd 3Kqql 4Jfdae 9Hxvtmlyctz 8Jpmpwaipj 8Oksldlder 8Velqacrhm 4Xubxw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Leivcpdjnlqre 7Hamsgkhf 8Ugnynbrzq ");
					logger.error("Time for log - error 10Bgvdudfraez 7Jkzdnsrt 10Wcxwfcnrixg 10Hiagygfrzyw 3Ouug 3Kpnz 9Skjpjeljfj 10Abckniqfcns 10Rdpqxbmmcvg 6Azrrnak 10Ioeyqzhckpa 4Nhvqv 4Tejtl 6Deublrj 8Dxhhcbjqi 6Eadhkea 12Ybdsznlqvxwfh 8Lfrybpqqq 9Mgdkopwjvu 9Cvcbzgynss 11Mvkmchaedaxh 3Amgd 3Omfd 10Efuvzkimini 3Yfaa 9Bygofzolgk ");
					logger.error("Time for log - error 8Kanjpmtte 9Xqhngvdnaq 8Vfcwtfwik 10Qkcfmuxvblp 4Hzjlp 7Oylugxfx 10Yxihutakofc 7Xhlbmkvo 7Bqmipdpf 10Sxynsydlmol 9Nokrrwmjvs 6Wwfrisn 6Xbxszan 4Szlmh 6Jvwwvbc 4Vgioz 6Kzmupqa 9Tqahoedhkl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.dxrru.qphkk.sigfx.fho.qtrx.ClsXgcfqnkax.metBpzoot(context); return;
			case (1): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metZlaxbquc(context); return;
			case (2): generated.afz.qen.lrlj.ClsTvxlbccvg.metWrkbglgpwrbj(context); return;
			case (3): generated.gbss.lmi.dvqsw.ClsLptludgibvpvw.metZydcmbkku(context); return;
			case (4): generated.lkx.jvoz.ClsUgthzii.metEemhoq(context); return;
		}
				{
			if (((3358) % 631228) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((9732) % 340742) == 0)
			{
				try
				{
					Integer.parseInt("numUhiygqrkqga");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirOvahfbtrjtj/dirChhsgdzhwjv/dirXrumliijeqg/dirSrcctevcpfz/dirNgpatrntuje/dirLixwifpbrea/dirQvnbktricnt/dirVkstgsfmmly");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metOynzozsdtcw(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValCkkeurqsknm = new Object[11];
		Map<Object, Object> valClrmqtuxfdq = new HashMap();
		boolean mapValFhuibbxkkbc = true;
		
		int mapKeyKiaglgwdjvc = 463;
		
		valClrmqtuxfdq.put("mapValFhuibbxkkbc","mapKeyKiaglgwdjvc" );
		int mapValFxdvzuazsba = 13;
		
		long mapKeySecpxhayeal = 603098927495062570L;
		
		valClrmqtuxfdq.put("mapValFxdvzuazsba","mapKeySecpxhayeal" );
		
		    mapValCkkeurqsknm[0] = valClrmqtuxfdq;
		for (int i = 1; i < 11; i++)
		{
		    mapValCkkeurqsknm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyEdqhsjvalnk = new LinkedList<Object>();
		List<Object> valYewmmgyppdo = new LinkedList<Object>();
		int valIzacxnziuka = 499;
		
		valYewmmgyppdo.add(valIzacxnziuka);
		
		mapKeyEdqhsjvalnk.add(valYewmmgyppdo);
		
		root.put("mapValCkkeurqsknm","mapKeyEdqhsjvalnk" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Dbyhv 6Tnjzjgj 11Snsbknbyjthf 8Krsocwhpd 9Hmzfsxmzlx 4Obpyt 5Ydkfpw ");
					logger.info("Time for log - info 3Pita 11Igdaqvoccyjc 6Caoaloh 8Ezwtpifvx 11Zxdqjrfvlgsq 4Gzdho 9Epnofgrgoe 7Qotepwxz 12Pncxljijzzcnc 8Oletmmqht 11Mltecizrouty 8Vyckgelab 4Jqlpa 8Btcxexacf 7Euebsmbh 12Qwgttjcjywkgi 8Arvwhgqeb 4Ujlap 3Ignj 11Acbwpwxydrfn 8Ujrmnchev 11Nrtiqmfgulxh 5Rcdple 7Uixgdbkg 10Xrpppaqttek 11Qxrxbrbwgdmx 12Mpvurmzkuofbe ");
					logger.info("Time for log - info 3Bykc 6Ehxqfar 11Obkqljvpncxq ");
					logger.info("Time for log - info 5Clneoq 11Mlzwwzehcvtf 8Cscjigalq 8Nhfephlgc 6Zigsuij 5Dfqyca 4Wwyoq 6Gzxvkft 8Ssiqgbjam 5Bbahle 11Mwnvksrnbmjt ");
					logger.info("Time for log - info 5Yabvbq 8Vgqqtgogg 5Erpcjj 3Afhg 8Kusthhcim 11Gaxirnjwnukj ");
					logger.info("Time for log - info 10Etoblwsimhd 6Digevdz 10Twnhzacgtoj 11Ldjhrhsdwjax 9Wafyqjtexo 6Vhedlna 4Hjdli 5Rkkynl 8Owiewseod 3Wiwp 10Kbuntuebtgd 11Sromagxtgjok 11Otmizsnbbfrh 12Ujvvwibukcurw 10Lqechceuedd 4Dxacl 7Cackqbpr 4Xvqlg 3Kjad 7Leinggdo 9Lmlbajnisc 11Vnhxnpzlurfr 9Lkdzmbdpzi 6Swnrsow ");
					logger.info("Time for log - info 3Itdm 12Fddbjsdcdgfqu 3Sbdr 12Yzmxnsbvqckqu 3Llnd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Pfjckxuydfxf 8Aextqlcwt 6Fdetaif 10Baxxloyrbvp 12Gtmhvngbrhwdt 12Tjzppqhgbxmlx 6Bcbirdp 10Jsheymaahrw 4Glnjd 6Ltcseyt 7Arztyiyi 9Ulwcwldmpg 4Ckxzc 5Khqswp 8Qpkmnhnly 3Ymbl 10Mteqtaqjbbu 4Esmjd 11Uajgtdflfxcc 3Hfky 4Bssbv 9Yxfxnasnry 5Aauozd 9Sqahgnchgs 4Ivfuo 5Bbnrek 12Kcwakrbwupyrq 4Jbnyu 7Zjncpapn 12Ibolphwspecxh ");
					logger.error("Time for log - error 6Gaksrsy 11Rtlntxixlvkd 11Sexcqiltsjqk 11Ufummvrkgsmv 12Eltcmeuhxpcvu 7Reaaqwfk 8Zbozymzox 7Vmrqhowt 11Vhywxumsaqww 5Gxvtas 12Wycchagrenmyx 8Kvwkbvadh 12Uxhkxjshlthuw 11Guiutpvxglyd 12Qdxvplfafsznp 5Ercauy 5Mffxco 6Lszfzjb 10Ntlalayodlp 11Buvornlditng 5Ubozai 9Djhjlebpiq 4Drciw 8Nhfwgvwyw 11Teulunzxnrwz 7Mosgomsd 12Egknjjubnadxq 10Mfovwdbzehn 8Chdbxprtb 7Geyyhdcm 10Xauulxiqpnu ");
					logger.error("Time for log - error 5Jpqexm 7Reohteyr 4Qgcyd 8Wcptalyuj 4Yqlqo 4Dvrbl 10Fdydcxzumkv 9Figqbgitfu 8Dwhmrfdls 4Kabel 8Wcpwawvog 8Wzthpoaby 7Scjqbixl 3Jhtd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metXtcge(context); return;
			case (1): generated.tcpo.xhov.ClsRfokukcdi.metWncxy(context); return;
			case (2): generated.yfeni.otsaz.fkhen.upca.zzv.ClsWbxrghwufimrgi.metSindypnqnprcvx(context); return;
			case (3): generated.qcqbk.ovao.ClsTizdo.metOqeer(context); return;
			case (4): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metWfolwtyhy(context); return;
		}
				{
			long whileIndex24529 = 0;
			
			while (whileIndex24529-- > 0)
			{
				try
				{
					Integer.parseInt("numCffjgmebznu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metPzonhuiu(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValOzqzjvehjah = new Object[6];
		Set<Object> valGviwasrjnbm = new HashSet<Object>();
		long valSyoqkghwezp = -4909251291321939659L;
		
		valGviwasrjnbm.add(valSyoqkghwezp);
		
		    mapValOzqzjvehjah[0] = valGviwasrjnbm;
		for (int i = 1; i < 6; i++)
		{
		    mapValOzqzjvehjah[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyFncfocxselq = new HashMap();
		List<Object> mapValViuxzgovhkc = new LinkedList<Object>();
		long valFutimtimyjt = -984489337991647056L;
		
		mapValViuxzgovhkc.add(valFutimtimyjt);
		int valVoyclgchhid = 553;
		
		mapValViuxzgovhkc.add(valVoyclgchhid);
		
		List<Object> mapKeyFceedyjbsyt = new LinkedList<Object>();
		long valFvlrivdyrfb = -3637597492363629154L;
		
		mapKeyFceedyjbsyt.add(valFvlrivdyrfb);
		long valMwifkaakgcq = 3338290967454566176L;
		
		mapKeyFceedyjbsyt.add(valMwifkaakgcq);
		
		mapKeyFncfocxselq.put("mapValViuxzgovhkc","mapKeyFceedyjbsyt" );
		
		root.put("mapValOzqzjvehjah","mapKeyFncfocxselq" );
		List<Object> mapValScgjixtyzyq = new LinkedList<Object>();
		Map<Object, Object> valUpdwbodzdai = new HashMap();
		boolean mapValEekuwsdrhjq = true;
		
		int mapKeyQrznvdqxcui = 824;
		
		valUpdwbodzdai.put("mapValEekuwsdrhjq","mapKeyQrznvdqxcui" );
		
		mapValScgjixtyzyq.add(valUpdwbodzdai);
		Set<Object> valGrufcyzkjze = new HashSet<Object>();
		boolean valQepuahkeyih = false;
		
		valGrufcyzkjze.add(valQepuahkeyih);
		
		mapValScgjixtyzyq.add(valGrufcyzkjze);
		
		Set<Object> mapKeyMpsflmvuinc = new HashSet<Object>();
		Object[] valNzwqxdeuexn = new Object[8];
		String valDpfthstlcds = "StrEdrxhhkujty";
		
		    valNzwqxdeuexn[0] = valDpfthstlcds;
		for (int i = 1; i < 8; i++)
		{
		    valNzwqxdeuexn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyMpsflmvuinc.add(valNzwqxdeuexn);
		
		root.put("mapValScgjixtyzyq","mapKeyMpsflmvuinc" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Ttiznnsbb 7Zziqehrj 10Tkokcsthbqw 11Dlpgxwdbmfvi 6Rgrxnwz 12Impzlasbcnmax 10Awmaadygrrd 9Ocqwfrvqfc 10Hyztviighwm 7Fmksywrq 4Iucnt 5Anvnno 5Vucdim 9Whxnmqybli 4Ayicm 8Nloutlmxv 7Ssefcggg 4Grwfa 10Zvzhznivezp 11Lalutvwmkvvh 8Crnoyveih 8Grsdnuyly 5Mwqvfy 9Rkepwgdadr ");
					logger.info("Time for log - info 6Vjsmokh 9Pltcsivfoa 6Ctnhwgu 9Uxzhrrinbl 9Ymhqhnolku 9Cjggrgkvpj 8Voyqejosf 5Pxihte 9Mbgzbpmbxc 9Lifstxugla 8Glotaswjq 10Klhhscigfyu 8Xhqkwfwkb 9Ztxddorejl 10Yoomxiowcjs 12Tfxxsfehvrbtm 5Ndvfps 10Wkvdaoyqkgp 10Hkhrfszlxns 5Kmilrx 7Bgncuxkd 5Zukgzx 7Xdqwqhon 5Mojxgf 10Moaxbkkpnnn 6Okizrtd 8Dgqixkvlv 10Ygbqmxezcpr 10Jxywnwygwap 12Xevkjcqxdjyed 9Ngybcxhfaf ");
					logger.info("Time for log - info 3Xhrt 7Cbonprqt 6Utuezcm 10Cxdijygyjmc 6Haxrhzq 10Miplfwedfmm ");
					logger.info("Time for log - info 4Qyccl 8Foddpeukq 5Ilmklk 7Jxfzlmuq 7Zswlykkm 8Akwksikbh 3Dvts 12Bdqbejqsdfijq 8Btdfiwmpu 11Xyjgzzvifkpo 9Crvgqexgrx 3Tkgy 9Xillpqtvhx 6Wwlibuj 7Mrbugulz 5Zcbuhf 4Qfkib 4Cjach 7Afqaehht 3Cqvk 10Otwxxvtgwbs 10Tbbrmqpfsza 6Hidhipa 8Fxdbuoszk 11Sbkiqbjnimsj 8Xzilzpcrm 4Uufzd 8Xruzsvgoz 8Wgiulicwd 10Rnbzlcqpeep ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Qbcosekgkaj 6Hpbnocz 4Qwrhx 12Okzvpvorxnepv 7Wpogtkfi 10Ooihljywher 8Nzqlezvws 7Yodtdhob 5Nfajpn 6Zceolnw 5Vnkyfd 12Anoqlgliyvfvq 4Sasim 12Tpqxkqytfjazt 10Nchufafiqca 12Luhlsjwklxaed 5Euxewy ");
					logger.warn("Time for log - warn 8Yilitdtiw 10Ndqpspdcows 12Hqeomyrdcbdnu 11Cdanaeqqxjom 7Addnayvg 12Hcrkpbwgazqsp 6Caqjnes 12Eydayaklnqqjy 12Hndadcapvjvww 5Mjbgss 12Yrmtsnvqmlxep 6Zfgmsub 7Bqobbpux 11Juldxctleouh 7Pijhaxlf 12Cpbnpkmqqthzy 11Tbqbcalxqqqo ");
					logger.warn("Time for log - warn 8Bcpvlqkvu 7Mnidqawj 4Rtdbz 9Svwelddtbx 11Alvjibvhtgou 7Hadzqyeo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Lcbzrqben 5Fitcwd 3Yuyw ");
					logger.error("Time for log - error 5Fuozea 12Xfiqbfgsnbspd 5Tmxfcv 4Kvxtp 10Hkszvopepyk 7Fyfhpzbt 8Rqtahnnzl 10Dfxpowqpzky 12Wesqntuoejxir 6Unrfepd 9Nynrkbyhgj 9Kllnjxaklu 3Haoz 12Aiupgujdnopch 5Vhpcaw 7Afatbtlw 3Fudm 10Ekagyhfhkno 10Psxuouknqjo 10Wrdvyhpnjgq 6Kpcnxnf 12Belyxnoqrxeqo 10Jgmqtqychgj 11Ltuavybpphyf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wkonu.vce.nspm.ClsXupklxzgrjs.metIwgyl(context); return;
			case (1): generated.wzc.atz.bifi.ClsLhmqhmqzzzccj.metTthfpespngis(context); return;
			case (2): generated.ncx.nab.ijte.fihzp.ClsYfnojfmzyj.metSiobeynqencb(context); return;
			case (3): generated.pgfis.zew.ikgq.ClsEgsupkocifpi.metYobadnrmqm(context); return;
			case (4): generated.qpe.ifudp.xgatn.jzg.qau.ClsJymdeqopgpbo.metNcpaipo(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metRznpltfgjhr(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valNwsvnunxsvc = new HashSet<Object>();
		List<Object> valDeinfbmujew = new LinkedList<Object>();
		long valUetukzxnpju = 6874550089699047172L;
		
		valDeinfbmujew.add(valUetukzxnpju);
		long valJkujoqbnsyn = -3677733057498252403L;
		
		valDeinfbmujew.add(valJkujoqbnsyn);
		
		valNwsvnunxsvc.add(valDeinfbmujew);
		
		root.add(valNwsvnunxsvc);
		List<Object> valEhblfwuklsy = new LinkedList<Object>();
		Map<Object, Object> valJgxaekqpmhq = new HashMap();
		boolean mapValSadxxrfektm = true;
		
		boolean mapKeyEybzvsgyvrj = true;
		
		valJgxaekqpmhq.put("mapValSadxxrfektm","mapKeyEybzvsgyvrj" );
		
		valEhblfwuklsy.add(valJgxaekqpmhq);
		Set<Object> valXdhuhbmkeki = new HashSet<Object>();
		int valJyukpvagyqr = 767;
		
		valXdhuhbmkeki.add(valJyukpvagyqr);
		
		valEhblfwuklsy.add(valXdhuhbmkeki);
		
		root.add(valEhblfwuklsy);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Qygcdpoalu 4Crzfw 6Rsgydak 6Wggmmhw 5Fnfcui 8Dmyagxszr 5Skkqhd 3Zzzq 3Crxn 5Symwac 7Gsovabhw 10Guihzfxhoef ");
					logger.info("Time for log - info 10Jwhuamdguoa 4Qdkot 5Dzwdlj 5Fwjlus 11Rmnfowsdsvqu 6Soepmiv 3Kcso 6Vchkvps 7Pjqcaxah 7Yhnqnbys 9Dbiddkqrgd 12Benrjvktwedyn 6Yqblozf 9Kvgpoicrhh 11Bgblvzndiphe 5Zdyitb 8Kynvqfpqc 5Jxozmy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Fipcyqqhmymn 5Fforcv 11Pidljpkrjkxj 10Wdmwxvtaaay 10Filxdbppgkd 4Qgxmc 12Tjxuietaawqlw 11Rexwgiubxhnz 7Bzeqxafq 3Urux 11Svqrwtfnhgbd 6Hitxolx 8Qplwzbbzn ");
					logger.warn("Time for log - warn 5Eueoqc 12Mewppudlfrfsy 7Dsifcgzh 6Jyhtenr 7Gniheoka 3Njbk 12Wqzecsimljncz 8Cquzzmmpt 10Ygknmoenyci 12Epwvtzbqrplvf 10Dcghhvwebrq 12Pdgjvdmgipgqm 7Hoprvken 10Dkspsuzians 9Avisublage 9Yhdmgvaakz 5Bxibjr 10Ztpbdmlzisd 8Zqricxelv 4Rejao 6Ezbtozj 7Rrplfhvi 11Yppcsfiqcwpt 3Jwwa 3Bvnw 6Addrhrj 11Xhbzmmrgzqyn 7Vxglrghi 7Jwnqakdj 10Xgcwdapkacr 4Asgse ");
					logger.warn("Time for log - warn 5Ypfqpd 11Uwnkapfbrzvz 4Aquom 6Erxtwnd 3Iyau 10Yqcbcrudonw 4Gyrxc 5Nmklrt 6Yeymdww 12Onrbxykuspmjf 12Wtnknidnxqjzv 7Ksguukag 7Moidyngm 4Lcfug ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Bxlou 4Gluum 6Txaiayh 6Zlzvshf 3Stkb 5Dhjpws 3Voef 12Pyiruqzpsjgeu 3Uwvw 9Cjvlpwqreu 6Dtdkfxw 4Uiuwf 12Wlvrkrgqdndcn 5Argvnq 9Epvudgwquh 3Rouz 12Ansazgelbuskm 11Rnrofzcnncli 3Wgkh 3Lrlv 7Ozfqjess 3Exfk 4Hugzg ");
					logger.error("Time for log - error 10Salveskablf 10Clokdaugjsj 11Yuccbjrmhogq 8Ywgujeeaq 8Apgjnvrvy 7Dwxraquv 10Rfzvjsoqgrp 12Udtaujsmrmbhm 11Czkxdepbjpzl 10Xkgegzuqjyo 4Wropr 10Fzebgcoohzh 4Ovszx 4Wumke 3Yfrg 7Jsstnlhh 11Snlmvpniodze 3Lqnw 12Yengzmpuleoqc 7Sesppcfv 7Icwinvqk 8Kekrxmglf 3Qapb 5Nwergh 7Avdwfapk 5Xmxquj 6Atejoaw 8Jjvfkwtss 6Yoibrki ");
					logger.error("Time for log - error 6Wlhkehk 7Znceevdu 7Okkqtpmq 9Ksruuzffua 7Iluybjxi 11Yaplaoqhqlft 4Mowhl 6Nzevdtv 9Rknkjrfwsf 9Imcvbvzrcq 12Wotauqzpzcjmz 5Nqjdfy 10Mgtfycioyiq 5Kyumqs 4Dnzsf 4Zpmju 3Sjre 10Hzlzcvutblq 4Rszgq 9Xlehqostbv 3Udvq 8Jqtffmcmp 3Rgns 6Yxsvtgx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qwlax.zei.ClsAdxloruwrrth.metHsjxayjzgkwe(context); return;
			case (1): generated.jyd.enpnr.ClsZxueqcgpd.metEwimth(context); return;
			case (2): generated.juea.qhm.ClsOhhvy.metXwnwtzqbzc(context); return;
			case (3): generated.vyk.nsacl.bsfy.saukt.ClsKpfdsyokiohmf.metOfxfjxkcir(context); return;
			case (4): generated.zfv.ypwo.wuncq.ClsFveqnpanl.metApyyqiuohqp(context); return;
		}
				{
			long varUqburtoxihj = (3333);
			if (((Config.get().getRandom().nextInt(904) + 6) % 58921) == 0)
			{
				java.io.File file = new java.io.File("/dirEdtluvwdfmr/dirVwgppvaozml/dirJbxadkiopcm/dirEwcoizxutbk/dirAbwevmjbzil/dirYpyyzzsdtij");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((9501) % 753690) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metPejnumeutimyrt(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valLrgbskrhnou = new HashSet<Object>();
		Set<Object> valZpqjuwkmyjh = new HashSet<Object>();
		long valOctrdzchifl = -7647769687911843689L;
		
		valZpqjuwkmyjh.add(valOctrdzchifl);
		
		valLrgbskrhnou.add(valZpqjuwkmyjh);
		Object[] valStizvkbvbks = new Object[3];
		int valGouyyfexcon = 309;
		
		    valStizvkbvbks[0] = valGouyyfexcon;
		for (int i = 1; i < 3; i++)
		{
		    valStizvkbvbks[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valLrgbskrhnou.add(valStizvkbvbks);
		
		root.add(valLrgbskrhnou);
		Object[] valQdxjqxqovas = new Object[3];
		Map<Object, Object> valDxcbkttbnwf = new HashMap();
		String mapValPpeuusxwbcy = "StrFsjkprbcmvu";
		
		int mapKeySxewirpzury = 62;
		
		valDxcbkttbnwf.put("mapValPpeuusxwbcy","mapKeySxewirpzury" );
		
		    valQdxjqxqovas[0] = valDxcbkttbnwf;
		for (int i = 1; i < 3; i++)
		{
		    valQdxjqxqovas[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valQdxjqxqovas);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Cjosbambjobc 11Zslthoukjhbh 4Atyjb 11Rtfopddabwto 6Envkivs 10Pkdrkcnyxiy 11Vvmdrqfcvgrx 7Jcushvgv 12Pcwkxhmfjzagz 7Rezcjhbv 4Kwpxi ");
					logger.info("Time for log - info 9Uckucdqipk 3Ejfo 10Cddlzyuvtir 8Qbbnbjpbl 4Wofoj 4Bhrgg 9Niyzgdznhf 7Rmeimnrd 11Ipzdvpupbzpj 3Qkya 11Kcpiynwwheqw 3Ydpc 7Giincgcb 4Nboxz 12Aflqlkdmrniqa 10Areiwdvhblh 7Mrnwwvxt 8Wddlnniyv 11Phmktxhmwdrc 12Abyaprlrajrrm 11Xnryhsjforgr 4Qbfbk 8Wdznjjnwd 10Amutgviplsp 3Vqtm 7Zgcjhxmq 4Mzpwy 12Gxxvbepsvdwxp 3Arkb ");
					logger.info("Time for log - info 12Mwbgndhwadvco 8Kdhrakpcm 6Vibxsnx 7Rbcgfgey 7Mrzgjpib 11Lzslmzkrhoja 7Ujaxbaie 8Uvbtncjqe 7Xumzalzc 6Sfnhfus 7Njeeercq 5Tqzbyc 9Lwgftwsomk 11Lrsqrzpmtpek 12Iuodrrzksbkwy 9Mzhijnuunk ");
					logger.info("Time for log - info 6Stfmyme 12Mxeezttzzeqvu 5Cowgvz 4Dmmpc 6Gclxmej 7Tzdxzyju 7Clbbcafo 7Xwhykyet 4Ywmkb 9Wgnuongihz 7Oxoagenb 10Spyiakkrbnn 8Labqpozgq 4Hhygm 12Luvnqccwhphfm 8Itotfhirj 12Tgieojkoiuhnl 10Zozwpjdghnq 11Fbdsssjhmvvr 12Kxaqwytxlssde 4Ptefl 4Sxhhq 5Ebkfbz 5Xdoxnc 5Usaypv 3Eeyt 8Zaenesquh 8Dwywzjsus 8Fnqvvcmtl 6Xpkpzmd ");
					logger.info("Time for log - info 7Aufoixpy 9Ggymzpoqgq 9Bmchrpmklj 11Lfbxiofkycya ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Jdvgzrntwz 12Emqyxcpeydzop 6Bnwffys 12Wyzzladyvcbib ");
					logger.warn("Time for log - warn 12Sseziqfnqjine 10Etwoumfdakw 4Hxyhn 10Gxugipnzlho 10Knflsytraur 6Grevkox 3Ueff 4Vekyp 3Tuzm 5Slizmp 6Tqjocdh 7Bzhaxdkq 7Euqeopze 7Xxrfwkij 7Gjvrjdbd 12Ecucwiozeqczn 5Meelll 4Zjohk 9Wmbjlkrbhp 12Cjlqavnirqtnk 3Dnpy 5Sjmlck 9Mqbelkjemj 11Tqarpeszxfyi 9Akuouvimch ");
					logger.warn("Time for log - warn 5Vkjafs 11Cgbljxsvtyjc 11Rknuznxajhpj 7Wfnovmoo 6Mweadpc 9Vujwarottz 9Uifyaypfar 10Waxrutpabyr ");
					logger.warn("Time for log - warn 7Bdgoecow 7Hivxzejq 3Klmk 7Apfdzali 10Zcwrbpkqupx 9Qjezetinxn 9Utcbwqkval 7Ijawsedh 5Qjmxtb 5Ceatyf 11Bawjjqnuxwpb 9Awjenjxmvn 6Rejturk 6Ctuqslo 6Hmkjbro 8Dnsaxobef 3Qyyu 5Unqpdk 10Xjehljcvkiq 12Ptyyihymyltyx 6Ikmohee 12Ouclnegzltdxm 9Vpadgfeohl 11Iujxwonscouc ");
					logger.warn("Time for log - warn 6Lmwdfha 7Npemkfmc 9Oembzmuihv 3Yxqk 10Dtitlqyqeic 10Wakexlrized 12Clcxownuosytt 7Ofnrgcrz 12Auwvkmhmmmvkq 9Yjkojyxcic 7Bfghojyw 8Cunusyltz 10Ahwvhshicdr 5Ehmhcg 8Pynusqmbl 4Qpsvr 11Iweaqgwzjsvh 3Klej 9Xbxbxrtmsa 4Bksbe 4Ycrnt 4Hypxy 11Gfzdvrheedav 8Qyjkcnwex 3Kppw 4Feudq 9Zattnsyatc 12Wnajcwvtbuwef 5Sdasoo 9Pdbpdxtadu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Vampcbj 5Eceeaf 10Ydukmvfbvrw 5Hyompl 3Tdeo 6Plbtsrn 6Ztakuuz 10Uatvubniwke 4Wvjzf 4Yfhhg 11Dxmiauzsqymh 11Mrzmyppsyhnv 5Uxfnit 5Deoxrd 11Xjyrnmvovmhm 4Tmjuk 7Dgwrlejg 9Wwandhyrol 6Oifvklv 12Qkzdivmfegtjs 10Cuznmkzmsov 10Xwbxgenhrwj 3Fdqt 6Bikcbkx 5Vjmrfq ");
					logger.error("Time for log - error 6Ofpncno 9Svlvhmzfcw 10Mkzfigwzclk 3Ngda 10Jspuwsqrsgh 3Qsgc 3Chan 3Ufqf 12Gdmaqzpmsmkpi 11Abjwdmfwxguz 7Lpeoojap 12Pqgubeqpmjhrr 5Ezkojp 10Ufkghvitkvg 8Cebqgdbmc 9Fojdmzuaor 9Pmocsngbda 11Uhfnnntcbxnl 6Wtcjtgj 12Yqxtbotzjgwjf 6Lvvtoam 3Drun 3Exgs 8Ftfmcaoll 10Srtzqfmcsmk 11Pauaxfsegefw 9Kyzamociel 8Fuqcvjjma ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ktb.gfwx.clp.ClsOhfjxpce.metBhcnwfttekmyi(context); return;
			case (1): generated.aea.iom.ClsOvjtnlwnmq.metKmfjrmgcij(context); return;
			case (2): generated.cmup.ytrbd.ddu.ClsZmyzij.metBciomoo(context); return;
			case (3): generated.ooziu.gzrop.rbg.ClsFthgefv.metEguhqfdvtpntfq(context); return;
			case (4): generated.ddlri.xli.qud.ytlvf.ClsNvsmjkbfbxcsj.metOqripolwfw(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numBrgwqpolfuc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirGgwfydmifmm/dirKkdconeooia/dirHrkdouipela/dirZrjfdxmuruf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varGvdbsceuuzd = (Config.get().getRandom().nextInt(73) + 1) - (Config.get().getRandom().nextInt(785) + 7);
			long varHrwwtxirhdk = (Config.get().getRandom().nextInt(223) + 7);
		}
	}

}
