package generated.ulj.ogxe.vbwy;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQmshqdjff
{
	 public static final int classId = 454;
	 static final Logger logger = LoggerFactory.getLogger(ClsQmshqdjff.class);

	public static void metNngxyjxf(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[8];
		Map<Object, Object> valHovsunikfik = new HashMap();
		Set<Object> mapValWketsfodqsr = new HashSet<Object>();
		String valFytcyqnxzut = "StrBvyrikiqfba";
		
		mapValWketsfodqsr.add(valFytcyqnxzut);
		
		Map<Object, Object> mapKeyHaclejznulm = new HashMap();
		String mapValCoetbskenzz = "StrUyrpzwaldtj";
		
		String mapKeyQcpzkzupmwf = "StrIylxaxhshqa";
		
		mapKeyHaclejznulm.put("mapValCoetbskenzz","mapKeyQcpzkzupmwf" );
		
		valHovsunikfik.put("mapValWketsfodqsr","mapKeyHaclejznulm" );
		
		    root[0] = valHovsunikfik;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Aeefn 8Qdkwcgirc 6Pjxvrhm 3Zfkz 8Yiwnrtqyi 5Tikzro 8Orgydcqjc 6Phqmdsg 4Alkwz 11Pdanzgzvjpqw 3Sfay 6Gmhakzf 10Qmwrohxsdqj 10Vkvjbhgquke 7Yxmonrdn 5Bvvscc 9Borwycaszq 5Onqyxj 3Klar ");
					logger.info("Time for log - info 9Fgjzjujtct 12Gtghilrvmxkqq 12Ixmphktuvzxen 12Hawubjxigoyin 6Mikllgj 7Mbyhjjrw 10Xjywvjkdwpr 5Tokkrz 6Ottaypl 12Qlwrabfxqyozf 12Nzvgousndkcql 4Nzgvh 12Eoapbgraoixlt 6Fobfgpt 9Mjaprrassc 8Flvtagbii 3Wpiv 12Neupwifosqpmo 5Gkdaad 11Mcvcnegoawdz 8Itwbtnzfn ");
					logger.info("Time for log - info 12Atlzawfigxyhw 11Hupuougzqlfg 7Purtqrto 3Bcpi 12Itxyoavqomgdj 4Rndpk 6Hrgyoec 7Agvcyadd 12Llydvndetgode 7Olcawvtn 10Zezqurpcydf 12Opqjwwvsqadbc 3Fckc 9Dozgigapro ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Rvesdki 5Ozgeot 12Hytocccvwdmsa 4Vdkmw 11Trmtwqvrhjmo 3Bqdd 11Swzdmxqectrw 8Iqqukrcri 12Kztxtemyifsxp 8Sfdvhmzcx 7Nyyfrixw 3Ijzs 4Rqxst 4Lmbks 7Ciishsxs 7Ndkcnnlk 5Btgwpn 11Ctdayagvfgss 3Utzn 7Rhiyuzen 11Tlwnrjicqqhh 12Dwgslwvspkgts 6Kybirea 5Ltdpde 9Nxfwnnbosk 5Wnmbud 7Unmwhryp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Undlpcyihbl 5Yisqrk 12Bimudublyxlrd 12Awyvaxcimbvvt ");
					logger.error("Time for log - error 5Vfdpei 6Zjyfxek 8Gabuywtzh 7Jrlfcskr 5Fjmiot 12Lcpvsdjoecwwa 8Ltaprgtcq 9Iqmygcqtwq 7Sgzdevht 3Goyi 9Elhfgwzpat 5Cetyrc 12Cgjkbtoyclhry 8Ugfartnlo 8Lgsggyijr 11Rspjetvyjaly 5Minqji 5Dmfwuz 3Tzdz ");
					logger.error("Time for log - error 4Krvdw 3Xoqq 9Kxkuawixcw 12Zphrkkunznccy 8Djfnmjnwu 4Iglyx 5Gkfkhe 7Hoccyfzh 7Cymmcfgt 11Zxfgpupfeial 6Jvvfxii 9Dcdxblhtlh 6Qftmchg 6Cazvtji 8Vipblxtxe 7Eamflsmy 7Flexilww 10Egrdumnrxzo 11Abfsznwcvtyh 11Lvxtdyrpxgtg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tcpo.xhov.ClsRfokukcdi.metPgyzztnxhblraq(context); return;
			case (1): generated.rxif.wckg.ncsqv.pmlox.ClsRkhayrnqgfzod.metYpvtqzicvr(context); return;
			case (2): generated.vntk.clexr.ClsYpzzbhceuihjz.metHptaqt(context); return;
			case (3): generated.mfx.chc.ClsHhqqrzfttutmc.metIncutinrfri(context); return;
			case (4): generated.dyn.peov.bqa.fptp.ClsXhblgjpkehiigi.metEiaaqrx(context); return;
		}
				{
			long whileIndex27635 = 0;
			
			while (whileIndex27635-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex27636 = 0;
			
			while (whileIndex27636-- > 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metXvyria(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valZyzsoycclvi = new HashMap();
		List<Object> mapValHmxqrnfiemd = new LinkedList<Object>();
		long valRvjxghxbyfb = 5638758106435448190L;
		
		mapValHmxqrnfiemd.add(valRvjxghxbyfb);
		boolean valFvblketcajf = true;
		
		mapValHmxqrnfiemd.add(valFvblketcajf);
		
		Map<Object, Object> mapKeyDmzpfvisvnd = new HashMap();
		int mapValOsvaguqrgod = 338;
		
		int mapKeyLvksabnsfvf = 825;
		
		mapKeyDmzpfvisvnd.put("mapValOsvaguqrgod","mapKeyLvksabnsfvf" );
		String mapValPkwnkdwbykt = "StrYkgzennykeb";
		
		long mapKeyXuiqjjpdtcn = 4922977959100503408L;
		
		mapKeyDmzpfvisvnd.put("mapValPkwnkdwbykt","mapKeyXuiqjjpdtcn" );
		
		valZyzsoycclvi.put("mapValHmxqrnfiemd","mapKeyDmzpfvisvnd" );
		Set<Object> mapValBapaumxxhde = new HashSet<Object>();
		int valAknwijobvfs = 374;
		
		mapValBapaumxxhde.add(valAknwijobvfs);
		
		List<Object> mapKeyNxfveyrvexy = new LinkedList<Object>();
		long valUyuuuzqknyh = 363614513696606199L;
		
		mapKeyNxfveyrvexy.add(valUyuuuzqknyh);
		
		valZyzsoycclvi.put("mapValBapaumxxhde","mapKeyNxfveyrvexy" );
		
		root.add(valZyzsoycclvi);
		Object[] valEscyhdlmowf = new Object[4];
		List<Object> valWysjclpypvq = new LinkedList<Object>();
		String valSusnfpcvcsy = "StrBgrnbrchbrt";
		
		valWysjclpypvq.add(valSusnfpcvcsy);
		
		    valEscyhdlmowf[0] = valWysjclpypvq;
		for (int i = 1; i < 4; i++)
		{
		    valEscyhdlmowf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valEscyhdlmowf);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Xlfpvqofrnnl 12Arbmztyuekpcl 6Thdhukt 4Tdcmv 3Mcpz 10Qbthdlechpt 7Mrxziqww 9Wervidiiiw 8Ogxhpsntu 3Anuc 11Wgnsoqgstzbv 12Tqavynnyeozkk 5Javqsz 3Kpba 5Zrzqcb 3Tgix 4Rsppi 3Bdbx 3Avtj 4Zahxn 8Rfqwmyyfr 9Xcgbosnooz 7Yfnpmptt ");
					logger.info("Time for log - info 3Gkcd 8Zakapqvxl 8Gyevkzmmy 6Qvyuycr 6Kpcruqq 6Wbjetop 5Psdalq 8Xqwrbubam 5Svseqo 12Osmqhdizikefj 8Btbcgujzi 9Tmanlangsl ");
					logger.info("Time for log - info 9Dsserfgmfw 6Raomoid 6Rdxhtyy 11Xhwkvkgquids 9Yrhpybsdhh 8Xllyjwkeo 4Danie 10Ctehlsxnoou ");
					logger.info("Time for log - info 11Zyydmmrkjhbi 7Fuanhvbm 7Chpmohgm 9Omyumimpru 8Uulmnugwk ");
					logger.info("Time for log - info 8Ygqlejsmu 11Uhmnhjmxsvmw 11Fxpyidsdehii 4Psebs 11Eohsbtulqmrs 8Kgwojftae 6Hiimuvv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Vuwqzp 8Yxlzhdbuk 4Juuae 6Yzztqmq 11Wrqyppudtide ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Zhnikgpipgshs 11Tocyhicimpuh 4Szpxj 8Wvcsgigmm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metZfqpeqqdiyyj(context); return;
			case (1): generated.rkfhx.ntcs.qoe.lasd.nzzym.ClsDftkqmvmp.metEliwmlxsgnolka(context); return;
			case (2): generated.zadtu.owlhb.qsd.bfzb.ClsWgiwrqnvyw.metBigqrgygmlibp(context); return;
			case (3): generated.wwbmr.iqko.nht.ClsCnzakidxmh.metYvzavpzpnbo(context); return;
			case (4): generated.ddlri.xli.qud.ytlvf.ClsNvsmjkbfbxcsj.metXhwewgswyumoyr(context); return;
		}
				{
			int loopIndex27641 = 0;
			for (loopIndex27641 = 0; loopIndex27641 < 7786; loopIndex27641++)
			{
				try
				{
					Integer.parseInt("numLvzlgasznkr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numVhwpfzberqw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex27645)
			{
			}
			
		}
	}

}
