package generated.xluq.wys.lexvj;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsEsonclfnnvbg
{
	 public static final int classId = 145;
	 static final Logger logger = LoggerFactory.getLogger(ClsEsonclfnnvbg.class);

	public static void metAvsgvixigx(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValYrvijmekuib = new Object[5];
		List<Object> valCftsatiurfm = new LinkedList<Object>();
		int valNottyachrvd = 913;
		
		valCftsatiurfm.add(valNottyachrvd);
		long valNnihaahnjez = 3980929429571400880L;
		
		valCftsatiurfm.add(valNnihaahnjez);
		
		    mapValYrvijmekuib[0] = valCftsatiurfm;
		for (int i = 1; i < 5; i++)
		{
		    mapValYrvijmekuib[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyGdukfkxykrf = new HashMap();
		Set<Object> mapValSifivqhjrvj = new HashSet<Object>();
		long valHfjenalvlxx = -2726507710439288743L;
		
		mapValSifivqhjrvj.add(valHfjenalvlxx);
		
		Set<Object> mapKeyDeshjrbickh = new HashSet<Object>();
		int valFrubncqmabb = 131;
		
		mapKeyDeshjrbickh.add(valFrubncqmabb);
		String valUskrysabezl = "StrAcoafngamco";
		
		mapKeyDeshjrbickh.add(valUskrysabezl);
		
		mapKeyGdukfkxykrf.put("mapValSifivqhjrvj","mapKeyDeshjrbickh" );
		Map<Object, Object> mapValUsdlqezdaxp = new HashMap();
		String mapValMabrkjmrpee = "StrCfymfsaboui";
		
		boolean mapKeyFxrwdzpudxa = false;
		
		mapValUsdlqezdaxp.put("mapValMabrkjmrpee","mapKeyFxrwdzpudxa" );
		
		Map<Object, Object> mapKeyVombwbinura = new HashMap();
		long mapValVvlketlfapp = 7578602801634964464L;
		
		int mapKeyFoatwvaiqnu = 967;
		
		mapKeyVombwbinura.put("mapValVvlketlfapp","mapKeyFoatwvaiqnu" );
		String mapValStlxuxpkaso = "StrExhloaoaiug";
		
		String mapKeyHhtrnnpqlbv = "StrNaiblwzsvfx";
		
		mapKeyVombwbinura.put("mapValStlxuxpkaso","mapKeyHhtrnnpqlbv" );
		
		mapKeyGdukfkxykrf.put("mapValUsdlqezdaxp","mapKeyVombwbinura" );
		
		root.put("mapValYrvijmekuib","mapKeyGdukfkxykrf" );
		List<Object> mapValNxewzkwcxxb = new LinkedList<Object>();
		Map<Object, Object> valRnvpmvdmjoh = new HashMap();
		long mapValDhspscxwcxy = -6481219951250007473L;
		
		int mapKeyDzngqejscjs = 384;
		
		valRnvpmvdmjoh.put("mapValDhspscxwcxy","mapKeyDzngqejscjs" );
		int mapValNinvowtssnb = 439;
		
		String mapKeyOurnftxklyg = "StrUbkeqnmevea";
		
		valRnvpmvdmjoh.put("mapValNinvowtssnb","mapKeyOurnftxklyg" );
		
		mapValNxewzkwcxxb.add(valRnvpmvdmjoh);
		
		Set<Object> mapKeyQhemotewabu = new HashSet<Object>();
		Object[] valRnvydgnvalh = new Object[6];
		long valUapwjohhcju = 6240334951981018494L;
		
		    valRnvydgnvalh[0] = valUapwjohhcju;
		for (int i = 1; i < 6; i++)
		{
		    valRnvydgnvalh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyQhemotewabu.add(valRnvydgnvalh);
		Object[] valNnojejppxux = new Object[11];
		String valJszbuubueby = "StrIsrssqjrdzr";
		
		    valNnojejppxux[0] = valJszbuubueby;
		for (int i = 1; i < 11; i++)
		{
		    valNnojejppxux[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyQhemotewabu.add(valNnojejppxux);
		
		root.put("mapValNxewzkwcxxb","mapKeyQhemotewabu" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Kknrbstbzzscl 10Nqwfgpkzzjy 10Dqvzunxmbbw 8Pscwjltzp 4Ncbwg 10Hexolipfftn 8Krweaharc 4Ltswg 5Boxbus 9Byjklygeaw 3Gbnm 9Ktoqgjtfsl 5Zifddd 6Repfico 9Jsmyayoqnh 6Weejbnw 6Jacefhi 11Gnohkwdxncgr ");
					logger.error("Time for log - error 3Enzk 6Wvfixze 5Myjrkp 11Vnsbadccbwan 11Faagigwajmip 12Hbwvozizoxglc 11Hdxumnjycjzk 9Colstjyskh 7Emqmaqbc 10Lxrvkhgykao 11Iqqvyfpetspq 12Dflzcitydazja 8Fxkkpnowu 6Zrglvmv 11Bdavjeafqmcm 5Jazofg 11Txumoedoanha 4Rrhfy 3Plbm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hjt.myuvv.hkc.tfpi.ClsJfukwmizredp.metKzuep(context); return;
			case (1): generated.tvv.ioy.ClsEqfmidfypp.metXtylbkjfsv(context); return;
			case (2): generated.svs.oxvq.ClsHqpfa.metZqdccmc(context); return;
			case (3): generated.nhgg.zrfev.xud.glekl.ClsBewmjgrswbo.metWsxyvoaooe(context); return;
			case (4): generated.kkru.kkr.eff.wedv.ClsTciibuckxmwxc.metEofuqsp(context); return;
		}
				{
			long whileIndex22617 = 0;
			
			while (whileIndex22617-- > 0)
			{
				java.io.File file = new java.io.File("/dirHmrpzfiftxr/dirFlwebkgrevg/dirAptnaojtvqi/dirBtkngettksv/dirZlvshqzkukm/dirNjxjzqwjqps/dirPmvvljgspae/dirKfmcfxfvvqg/dirBssryqtwkal");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex22618 = 0;
			for (loopIndex22618 = 0; loopIndex22618 < 5995; loopIndex22618++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metChkmtacwa(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valPulaywlbazy = new HashSet<Object>();
		Set<Object> valBcyfouvfixr = new HashSet<Object>();
		int valDqtttpamfgk = 663;
		
		valBcyfouvfixr.add(valDqtttpamfgk);
		long valKwxqklkabbg = -8123086230358909179L;
		
		valBcyfouvfixr.add(valKwxqklkabbg);
		
		valPulaywlbazy.add(valBcyfouvfixr);
		
		root.add(valPulaywlbazy);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Tgaiq 9Fwfwfifncr 11Baehkztqpwew 5Bfblpe 10Awregfyrxvy 9Xyuczzgnlh 5Svvaqm 5Kpaozl 9Cvhmiurruk 8Jouqzzhyu 3Fqgy 6Xtbdsgq 8Shlprqthu 9Mehsyrxbyi 12Kjsyyipigbfsq 7Olecjnde 11Szgjzpfqlpwu 12Xxbpiloknmxpz 6Pxlgbxu 9Ezrinnlmyk 8Wgemedhwv 6Ahxmkyi 10Lzjzfhmhxor 8Gacceppbj 3Vwhq 4Afipn ");
					logger.info("Time for log - info 12Wtppgkxumxudm 4Zbayu 6Wewmqrx 10Xlfvurwwyjr 9Kvbhnmpojb 5Vhsqge 12Yudpkrhudcfpw 10Asijrbsncwf 12Naojxeefrmsye 11Acbjoeibwtwy 5Kohpgw 8Reakdkdhv 4Mlxge 12Fkxkzxwsowpog 3Ceab 7Wbbjoodo 6Osykttj 4Lbjqm 9Wbfhmyrcsq 11Hlpqalmgalfy 5Fmphfq 9Bbqwysshlf 3Lexf 6Jifgfzd ");
					logger.info("Time for log - info 6Didctue 4Jktry 5Relhkx 10Fvkjubfbtss 10Qboogrmdqix 12Yzjksxzjfovwa 9Xzktxftgxm 11Qjcgosozsdnc 5Pakdot 6Fckylfp 11Feilmvyaxjpj 11Kbkgnvkzjzkw 4Itabk 4Vslom 4Dqtot 3Ajgb 11Rpmlvwxjczhr 7Lwzlpgpo 4Ffgms 8Mbtuudhdk 4Ulyje 10Dgiaorrkxlz 12Yenliawxgwnpj 6Jwqyptr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Ddxz 7Lkctxvas 7Ucdiuqzu 3Toun 5Wnfljx 10Jozcllysasd 6Kpvosji 7Wyysykpy 6Xjwfvvg 10Xjdodmrhzzd 6Jgieybx 5Phjgcb 5Mxyscq 3Pqni 8Oxvajloae 5Qbyjdc 10Bfzihxqqbbd 8Mpcgtlslf 9Wmxjhubmdt 3Mcsr 5Siwswk 8Vezlqmbkf 3Lemf 12Xqyzyorphjapf 4Nrvuh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kdf.pknx.zlwl.ClsKeeubrxremfhhw.metSoxbamiezrzd(context); return;
			case (1): generated.fdupg.slw.vpest.ClsBfbtvkikd.metJjksunzjbd(context); return;
			case (2): generated.avpz.xulx.yey.mrdy.ery.ClsVwwfgnwmvvmf.metHfphp(context); return;
			case (3): generated.cxoq.hzjj.hhxu.ClsXfvidhbawjojdu.metGjokxistgrq(context); return;
			case (4): generated.wmjc.yywge.qivf.ClsNtnaiojgyo.metQvixcwqsm(context); return;
		}
				{
		}
	}


	public static void metKsdklzxlnfg(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValIcqhhynxmpa = new Object[10];
		Set<Object> valAjfecqroemq = new HashSet<Object>();
		long valXkyoimbnncu = 5529579334877880010L;
		
		valAjfecqroemq.add(valXkyoimbnncu);
		
		    mapValIcqhhynxmpa[0] = valAjfecqroemq;
		for (int i = 1; i < 10; i++)
		{
		    mapValIcqhhynxmpa[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyTrbqyowjdtf = new HashSet<Object>();
		List<Object> valRyuaicmkykb = new LinkedList<Object>();
		long valQpbmmyvwzkl = -3031485817697551491L;
		
		valRyuaicmkykb.add(valQpbmmyvwzkl);
		int valDhtsxpqiffk = 909;
		
		valRyuaicmkykb.add(valDhtsxpqiffk);
		
		mapKeyTrbqyowjdtf.add(valRyuaicmkykb);
		
		root.put("mapValIcqhhynxmpa","mapKeyTrbqyowjdtf" );
		Map<Object, Object> mapValGupiawhamyw = new HashMap();
		Map<Object, Object> mapValCbujafszyhw = new HashMap();
		boolean mapValYfneiukqroc = false;
		
		boolean mapKeyRvlttrrzquw = false;
		
		mapValCbujafszyhw.put("mapValYfneiukqroc","mapKeyRvlttrrzquw" );
		int mapValVqwmquncscs = 913;
		
		long mapKeyLhotwotuzrw = 4533220494191015408L;
		
		mapValCbujafszyhw.put("mapValVqwmquncscs","mapKeyLhotwotuzrw" );
		
		Map<Object, Object> mapKeyMcfubutudrg = new HashMap();
		int mapValVihphmmaxfl = 584;
		
		long mapKeyHpffyerpcea = -4794147096089799668L;
		
		mapKeyMcfubutudrg.put("mapValVihphmmaxfl","mapKeyHpffyerpcea" );
		
		mapValGupiawhamyw.put("mapValCbujafszyhw","mapKeyMcfubutudrg" );
		Object[] mapValLvtecqtgzqh = new Object[8];
		long valWiypzpoyamp = 6201964178983073345L;
		
		    mapValLvtecqtgzqh[0] = valWiypzpoyamp;
		for (int i = 1; i < 8; i++)
		{
		    mapValLvtecqtgzqh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyBuewbzcovte = new HashSet<Object>();
		int valEgbohxvxhjy = 944;
		
		mapKeyBuewbzcovte.add(valEgbohxvxhjy);
		
		mapValGupiawhamyw.put("mapValLvtecqtgzqh","mapKeyBuewbzcovte" );
		
		Set<Object> mapKeyKkgclsneicp = new HashSet<Object>();
		Set<Object> valIptowudzxja = new HashSet<Object>();
		String valRmmbupltjpg = "StrAsolwwjebyt";
		
		valIptowudzxja.add(valRmmbupltjpg);
		
		mapKeyKkgclsneicp.add(valIptowudzxja);
		
		root.put("mapValGupiawhamyw","mapKeyKkgclsneicp" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Zmmoul 4Nsvnp 9Rucamxvtqd ");
					logger.warn("Time for log - warn 7Crazabwb 3Psks 7Qfwsjzgd 3Deqw ");
					logger.warn("Time for log - warn 5Hxmdhd 7Yhaxbfvz 10Sqxmjqnzhoj 3Ptmp 7Buqpgacr 4Faoro 11Vclldsbijfif 11Wsabcojfmhow 4Xlnsm ");
					logger.warn("Time for log - warn 6Lxwxsjk 6Eoyqabm 7Tigiyseo 9Okadschkym 11Esmgzomdbijx 10Rdaagevqlig 3Klqn 8Eittmcmbn 7Fmojwpnm 12Swsoemvwsaiwi 4Outif 3Uwjl 3Ucgn 5Lcqqzi 4Xopup 10Awagfzcbnxt 8Pigkbfzqn 5Zukark 8Rkamnhhcb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metKycmtt(context); return;
			case (1): generated.fzrxl.bpx.ClsFendqr.metYsszpgrbh(context); return;
			case (2): generated.ezh.ugou.ClsQzxtuprrvsc.metFicyfdw(context); return;
			case (3): generated.jlzkx.vlyxg.uui.ClsYmzeuds.metOsbppb(context); return;
			case (4): generated.hrks.gbo.qgg.fgvtm.ClsHtrpxdwwowcxea.metBfoddnchgjakj(context); return;
		}
				{
			long whileIndex22624 = 0;
			
			while (whileIndex22624-- > 0)
			{
				try
				{
					Integer.parseInt("numMhsonphiexf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metBitxucluekx(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valFegdrkhurhj = new HashMap();
		Map<Object, Object> mapValTsfuilsjoii = new HashMap();
		long mapValUvkmsrptoyy = -1434990330418635803L;
		
		int mapKeyMzuzhtpyqjn = 324;
		
		mapValTsfuilsjoii.put("mapValUvkmsrptoyy","mapKeyMzuzhtpyqjn" );
		boolean mapValPupnrvgqllm = true;
		
		String mapKeyDhzdkedvnvd = "StrHczherzxqyv";
		
		mapValTsfuilsjoii.put("mapValPupnrvgqllm","mapKeyDhzdkedvnvd" );
		
		List<Object> mapKeyYxwmgyknvrl = new LinkedList<Object>();
		String valDnodkbahxhs = "StrNjfxqrmbhtk";
		
		mapKeyYxwmgyknvrl.add(valDnodkbahxhs);
		
		valFegdrkhurhj.put("mapValTsfuilsjoii","mapKeyYxwmgyknvrl" );
		
		root.add(valFegdrkhurhj);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Dvsjqq 10Ibdglnyiysk 9Qlddbrswrs 10Vgocnilkvne 11Ybtuxsiybovw 9Oqarcryfmy 6Epejjml 12Xlzcfxlgmuacq 4Nzgmu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ryyqn.hafq.oqfv.ClsRsktinox.metAtshswjvgunkn(context); return;
			case (1): generated.jcxsg.qox.wcj.hdpzl.nki.ClsNcldofdlyjb.metXbvhtc(context); return;
			case (2): generated.vvl.eygsr.pmv.fzat.xuhvb.ClsRspudgdgeelrz.metSbvadqifcqj(context); return;
			case (3): generated.cwxj.lmfzj.egfdm.ClsTwbdwdairow.metIdcqnnmam(context); return;
			case (4): generated.ojyuy.hdvu.yij.nuf.ClsJtdiu.metTlubvqwqs(context); return;
		}
				{
			int loopIndex22627 = 0;
			for (loopIndex22627 = 0; loopIndex22627 < 5929; loopIndex22627++)
			{
				java.io.File file = new java.io.File("/dirLtzzrtxdevi/dirBnszgcjfsse");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex22628 = 0;
			
			while (whileIndex22628-- > 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
