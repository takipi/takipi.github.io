package generated.npa.tuyd;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsLxzuwxfsi
{
	 public static final int classId = 65;
	 static final Logger logger = LoggerFactory.getLogger(ClsLxzuwxfsi.class);

	public static void metPbpsvdupgp(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValOgnmxtnzgqq = new HashSet<Object>();
		List<Object> valXgqcepbvytx = new LinkedList<Object>();
		int valSyaouqkpgjb = 979;
		
		valXgqcepbvytx.add(valSyaouqkpgjb);
		
		mapValOgnmxtnzgqq.add(valXgqcepbvytx);
		Map<Object, Object> valWuibsnzsynf = new HashMap();
		boolean mapValUpfmmnobadv = false;
		
		int mapKeyVifcsuzdipx = 658;
		
		valWuibsnzsynf.put("mapValUpfmmnobadv","mapKeyVifcsuzdipx" );
		int mapValGzretomlhce = 933;
		
		int mapKeyQpignjvxouy = 830;
		
		valWuibsnzsynf.put("mapValGzretomlhce","mapKeyQpignjvxouy" );
		
		mapValOgnmxtnzgqq.add(valWuibsnzsynf);
		
		Map<Object, Object> mapKeyWzmynbxkjfy = new HashMap();
		Object[] mapValMznsalsatwq = new Object[11];
		String valMvgkskhmmcb = "StrArzuotcigge";
		
		    mapValMznsalsatwq[0] = valMvgkskhmmcb;
		for (int i = 1; i < 11; i++)
		{
		    mapValMznsalsatwq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyDxhkpkcraau = new HashSet<Object>();
		int valSeoaxsmrodw = 752;
		
		mapKeyDxhkpkcraau.add(valSeoaxsmrodw);
		long valPuzmtqeabym = 4353370527873791916L;
		
		mapKeyDxhkpkcraau.add(valPuzmtqeabym);
		
		mapKeyWzmynbxkjfy.put("mapValMznsalsatwq","mapKeyDxhkpkcraau" );
		Map<Object, Object> mapValElwrqvimfdt = new HashMap();
		long mapValArpjyhaeklc = -3743136280993674468L;
		
		long mapKeyQdxwgyrrnea = -2566559709405477270L;
		
		mapValElwrqvimfdt.put("mapValArpjyhaeklc","mapKeyQdxwgyrrnea" );
		String mapValRxoccyahdjn = "StrEvaayyqpble";
		
		int mapKeyVdgpzwlxceo = 417;
		
		mapValElwrqvimfdt.put("mapValRxoccyahdjn","mapKeyVdgpzwlxceo" );
		
		Set<Object> mapKeyJvagamugzhb = new HashSet<Object>();
		boolean valHqpxqmugcsi = true;
		
		mapKeyJvagamugzhb.add(valHqpxqmugcsi);
		boolean valClvqbjqqtbw = true;
		
		mapKeyJvagamugzhb.add(valClvqbjqqtbw);
		
		mapKeyWzmynbxkjfy.put("mapValElwrqvimfdt","mapKeyJvagamugzhb" );
		
		root.put("mapValOgnmxtnzgqq","mapKeyWzmynbxkjfy" );
		List<Object> mapValMhnpzbitrct = new LinkedList<Object>();
		List<Object> valEquqexajmuq = new LinkedList<Object>();
		boolean valBdbllaitewn = true;
		
		valEquqexajmuq.add(valBdbllaitewn);
		
		mapValMhnpzbitrct.add(valEquqexajmuq);
		
		List<Object> mapKeyFqwwhosamvv = new LinkedList<Object>();
		Object[] valDgewzdezqak = new Object[8];
		int valPkoyjzjybyd = 354;
		
		    valDgewzdezqak[0] = valPkoyjzjybyd;
		for (int i = 1; i < 8; i++)
		{
		    valDgewzdezqak[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyFqwwhosamvv.add(valDgewzdezqak);
		Object[] valAwxzledjzej = new Object[7];
		String valOogflkqmezp = "StrUixjsmogals";
		
		    valAwxzledjzej[0] = valOogflkqmezp;
		for (int i = 1; i < 7; i++)
		{
		    valAwxzledjzej[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyFqwwhosamvv.add(valAwxzledjzej);
		
		root.put("mapValMhnpzbitrct","mapKeyFqwwhosamvv" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Aytpcsghk 8Aeoluiinh 9Tcnyzzfqic 6Buzlgpz 8Ociunupst 3Yodv 10Jtsjkkipsdb 10Edpkvjldjvc 8Vuvvxlbcl 11Zdadiceqbgpn 5Udhwcw 6Zbetsod 3Jtfb 3Frby 4Cczfc 10Sgenhmmesrr 7Szhidqej ");
					logger.warn("Time for log - warn 12Jwcqywpknjuqz 6Ugdwioy 10Pnidwpxhhnt 5Mcfzsn 12Puzntqdauwyni 8Gsgkvebus 6Ladpbje 3Xhnr 10Fnciqzksvfw 11Wmbnxoiikhcx 4Estpv 10Grhfjurrgxw 8Hszcwritt 3Wkze 12Djecigmacbige ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Tzedkdvpvbb 4Ospjj 6Lvhoknk 8Rjffkruoq 7Phjlibgb 8Yocstqubn 6Rooakdn 3Ezxl 3Epvr 10Ajuavytecbq 7Jkrvhhbh 11Fvayvetrgtyb 8Epjjkaems 12Ohyoqzlftwkll 12Saifgmlkhbdhn 6Cyyoqui 10Gwyfirvsjzv 9Txagokcqiw 8Mqffgxztq 8Edldhfldp 6Blmvmax 7Feiqkrfj 11Waixdkswhbpm 6Xusoiog 7Ulfpudru 4Idrlw 9Retwfvuojw 7Naalxgxm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.opcr.jgy.rftd.rkx.ClsJjouwg.metKtdrtpazip(context); return;
			case (1): generated.hdrlt.jxdm.bjqs.pupxs.ClsZoyaigxdyb.metCofpcgjfkt(context); return;
			case (2): generated.tmohp.pbwu.gfhxq.zdkm.ijx.ClsDimqu.metLliixbwykd(context); return;
			case (3): generated.obqk.bihpl.ehwd.ClsWcpejgvq.metUrpeeajbj(context); return;
			case (4): generated.xajsm.xnlym.ClsUmfzchfskds.metJmjyqm(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirIujczsselaw");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex21155)
			{
			}
			
		}
	}


	public static void metNpvomn(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValGzvznjliitp = new Object[10];
		Set<Object> valPqzwhdfenad = new HashSet<Object>();
		String valXoecpppjtah = "StrTjhjtlfpttd";
		
		valPqzwhdfenad.add(valXoecpppjtah);
		boolean valTlpiptgmuek = true;
		
		valPqzwhdfenad.add(valTlpiptgmuek);
		
		    mapValGzvznjliitp[0] = valPqzwhdfenad;
		for (int i = 1; i < 10; i++)
		{
		    mapValGzvznjliitp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyEcebadfhvzz = new Object[10];
		Map<Object, Object> valMzimspxmeym = new HashMap();
		int mapValDwsbqcfjcdv = 74;
		
		boolean mapKeyEdcwpmpdejm = false;
		
		valMzimspxmeym.put("mapValDwsbqcfjcdv","mapKeyEdcwpmpdejm" );
		String mapValOnkepuofkig = "StrEoftdbsezua";
		
		long mapKeyVougtzifgji = 6657612237026179295L;
		
		valMzimspxmeym.put("mapValOnkepuofkig","mapKeyVougtzifgji" );
		
		    mapKeyEcebadfhvzz[0] = valMzimspxmeym;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyEcebadfhvzz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValGzvznjliitp","mapKeyEcebadfhvzz" );
		List<Object> mapValEojspzugsds = new LinkedList<Object>();
		Set<Object> valEkeefxfeayb = new HashSet<Object>();
		int valJylapedieso = 843;
		
		valEkeefxfeayb.add(valJylapedieso);
		String valQyagnxxsuft = "StrYgjzwwwzuhi";
		
		valEkeefxfeayb.add(valQyagnxxsuft);
		
		mapValEojspzugsds.add(valEkeefxfeayb);
		List<Object> valMnnbtmdybgu = new LinkedList<Object>();
		String valKwojuiomyux = "StrJzrdpkcudnm";
		
		valMnnbtmdybgu.add(valKwojuiomyux);
		
		mapValEojspzugsds.add(valMnnbtmdybgu);
		
		Object[] mapKeyRxrtbjmmgjy = new Object[11];
		Map<Object, Object> valIkdfogxuoja = new HashMap();
		String mapValSxlmrfcqzhf = "StrTzcphzyqsdz";
		
		long mapKeyPbrufhteaeb = -8350501017629877404L;
		
		valIkdfogxuoja.put("mapValSxlmrfcqzhf","mapKeyPbrufhteaeb" );
		long mapValRpywbeufxny = -914112702515661105L;
		
		int mapKeySparzbszubb = 126;
		
		valIkdfogxuoja.put("mapValRpywbeufxny","mapKeySparzbszubb" );
		
		    mapKeyRxrtbjmmgjy[0] = valIkdfogxuoja;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyRxrtbjmmgjy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValEojspzugsds","mapKeyRxrtbjmmgjy" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Rwre 6Nktwzzc 7Mtqebhlu 6Cbfzgzm 10Lwzjubslqwb 8Cfebsolvu 10Ijbdqwlcgiz 10Idmwgbrjkkt 4Nmocd 8Xihruzjbf 8Ogmxqnvpi 10Oqiplpasscs 9Zajtxvxfkn 12Luhpklgxmxprs 4Aknjx 5Tjituy 8Cfpphqvfh 10Ajocigqzioy 3Zxir 4Nblky 10Irznpkhsuco 3Rynt 11Ixpkkeytqudu 6Qsyqyrk 5Xnsife 4Tjvff 10Qkfvhptgkup 8Pochdihgk 3Bohw 7Sgxshqfw 3Jgsz ");
					logger.info("Time for log - info 8Lurqdsnjd 4Debci 7Rcceplpd 6Kklvbsi 9Jtdytcnrus 4Vtfow 10Pldovddupfp 6Vczedil 6Gxmmbyc 4Mfdtn ");
					logger.info("Time for log - info 6Vryuxtz 5Mflpdn 4Vpkuz 8Rgshabqxz 6Prtoaop 4Xnvkw 12Oeotmrtxrqtyz 9Wvkdesbmvx 6Bxwhcjx 5Vvnlqu 7Bdopcklq 10Cleoojoizxa 5Ncreya 6Kgepiji 9Bbjiytfuec 7Yfdgwchj 3Qqpf 5Swigfu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Jxjpxvpzwi 12Jkdfamrtffhsk 5Xglrxv 11Bbqsxmvobqwk 12Slnyujbrhsvgv 10Ytaosdhtxai 5Igstoj 3Rgpg 7Cvpuutcz 3Quep 10Pnjddpobsbp 7Rmwiivsb 10Ctuoowifftb 10Vjizmejvvip 10Qzkvnqsffnr 9Udelfduhvg 10Ntnrthpysis 12Unhsavxtxiomh ");
					logger.warn("Time for log - warn 8Jvhojombq 6Htdgbcu 10Qzlglktosff 6Rgnyhzq 4Fsebs 3Jsvi 4Ttoen 10Eqawilhvtsc 12Gltmodnqtgwka 12Szmnbzxtyeitv 3Jvfa 5Ddpadp 5Ducgne 9Ezxcjrtjsd 6Rauuhmr ");
					logger.warn("Time for log - warn 9Axnflqrbdb 12Dkqttrjutozjc 11Xaiditmokgyd 4Qpvdh 8Ruttdtwfp ");
					logger.warn("Time for log - warn 5Uumooh 8Mtmyoshnq 5Vkypeh 11Svjrugaiyznj 11Dtixjlgoivcf 3Qwuh 10Rlcaspjlwnu 9Xmbujfjsbi 5Hbhxnw 6Hbiidue 6Pfvncox 3Nkuv 3Ojos 3Vfbx 9Lkjiaszisd 7Xhckwqqf 6Emoqjvi 6Kpecuny 10Zpiyzmipmwf 12Kskxzuspmhtia 10Elqfuiyhcxu 7Nfkmtbez 12Ccfnczyxclwnf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ewz.kir.rqdl.wup.ClsTcnbjngxap.metXatmnfjmhsznde(context); return;
			case (1): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metDcqlrafmtcoxm(context); return;
			case (2): generated.xqnb.haff.rrb.lurge.ygwj.ClsNrgsacrzyefzg.metXouqbpti(context); return;
			case (3): generated.unn.flt.iyr.tjmvm.ClsFuxljnbiciwosz.metGczbjns(context); return;
			case (4): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
		}
				{
			long varXihmrrersxe = (Config.get().getRandom().nextInt(998) + 8) * (Config.get().getRandom().nextInt(463) + 6);
		}
	}


	public static void metVaqynjo(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		List<Object> valLxrxiajwxyg = new LinkedList<Object>();
		List<Object> valRihqmehgkue = new LinkedList<Object>();
		boolean valRgaydbsjlxq = false;
		
		valRihqmehgkue.add(valRgaydbsjlxq);
		int valAeujeqqgolz = 694;
		
		valRihqmehgkue.add(valAeujeqqgolz);
		
		valLxrxiajwxyg.add(valRihqmehgkue);
		Set<Object> valAfzvgrbnznp = new HashSet<Object>();
		long valHagotfnorzr = 4468674696287959653L;
		
		valAfzvgrbnznp.add(valHagotfnorzr);
		
		valLxrxiajwxyg.add(valAfzvgrbnznp);
		
		root.add(valLxrxiajwxyg);
		Object[] valByxonwlpzfn = new Object[7];
		Object[] valQzwafanhzoy = new Object[4];
		String valHyuqzgzgvcn = "StrGnmhinpbgou";
		
		    valQzwafanhzoy[0] = valHyuqzgzgvcn;
		for (int i = 1; i < 4; i++)
		{
		    valQzwafanhzoy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valByxonwlpzfn[0] = valQzwafanhzoy;
		for (int i = 1; i < 7; i++)
		{
		    valByxonwlpzfn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valByxonwlpzfn);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Emhxnmcat 9Muevtccuai 12Acrtebakgrswb 9Djptkqqlxo 7Jugluvqi 10Fvevhkmqxzq 5Bmytyw 7Sjmfxmpr 10Mucsifpzsam 12Abmdkvksexvaa 12Trhnmsrpfmalp 10Kdaijkziesn 6Yvdopdv 4Qjldp 6Orejake 5Lhwrgw 12Uwdtnstyrklhj 9Dxmyoasrnv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Ylfoe 6Astdweu 10Falaxctsmro 11Dyhdknzpaozq 10Bnghayxukuf 5Cuttex 3Vgoz 6Mzmrtli 10Ydwfaqzqsum 7Npmhhcpt 8Jwxsihszy 12Uaipdsfwfqhgq 3Hezk 6Jwirfks 7Czrahdch 6Ylazwgh 4Gaxxq 12Acazrfdbsrais ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cjexh.ehrl.mtwqa.ClsVshethruisurxt.metGryimbv(context); return;
			case (1): generated.bftm.jkb.lcr.ctpvk.ClsYfbhukzct.metRefjrhfmiyvoq(context); return;
			case (2): generated.fur.dagce.oeqx.ClsTsqthfwvzszch.metJmxhhbj(context); return;
			case (3): generated.bolg.tnlb.nmug.ClsHstaiufsowx.metPapexcx(context); return;
			case (4): generated.fxa.nzjpw.lkh.sxue.ClsXtfkzq.metKgwcxlgfzbemhw(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirPnyilznglkk/dirVnrlaxsiups/dirIiimpydmyxj/dirJwddgralxdj/dirHmucagvluyf/dirIwfycjndlyr/dirFgzjvhvpqyj/dirTdenjeslnjv/dirTpsijtolzwl");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numXbvtxijfgql");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((Config.get().getRandom().nextInt(600) + 7) % 63503) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((7385) % 151159) == 0)
			{
				try
				{
					Integer.parseInt("numVcncvohiyiv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numNmftjwdlzzx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numLcdmaiyvkrs");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numMmbsbxrzpby");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
