package generated.cin.hewe.akg.wyf.seuvv;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsFgxjhcrdocnyas
{
	 public static final int classId = 421;
	 static final Logger logger = LoggerFactory.getLogger(ClsFgxjhcrdocnyas.class);

	public static void metKhzutma(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valKlknbtgssgg = new Object[11];
		Object[] valOvcmlnbgkcq = new Object[8];
		long valLkltgudrixp = 277534712843681885L;
		
		    valOvcmlnbgkcq[0] = valLkltgudrixp;
		for (int i = 1; i < 8; i++)
		{
		    valOvcmlnbgkcq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valKlknbtgssgg[0] = valOvcmlnbgkcq;
		for (int i = 1; i < 11; i++)
		{
		    valKlknbtgssgg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valKlknbtgssgg);
		Set<Object> valTafqbhjufjs = new HashSet<Object>();
		Set<Object> valDsznsaccgwd = new HashSet<Object>();
		int valSspgbfdgunl = 244;
		
		valDsznsaccgwd.add(valSspgbfdgunl);
		int valTbsxfloxibc = 657;
		
		valDsznsaccgwd.add(valTbsxfloxibc);
		
		valTafqbhjufjs.add(valDsznsaccgwd);
		Map<Object, Object> valLezngzujnek = new HashMap();
		boolean mapValXiwlqsupbog = true;
		
		long mapKeyUfajluqbpxg = 882801031723862812L;
		
		valLezngzujnek.put("mapValXiwlqsupbog","mapKeyUfajluqbpxg" );
		
		valTafqbhjufjs.add(valLezngzujnek);
		
		root.add(valTafqbhjufjs);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Xzlrt 4Zuqvj 4Tgrsh 7Zrvvshyx 10Xnfyfzkxgkg 9Pickrmxvfh 8Cuibgiuub 9Tzdjqemleu 3Xnpj ");
					logger.info("Time for log - info 8Ltpisosig 10Vtqihswfpyj 4Kfoxv 10Uwsdryxrwxf 8Bdgkcnzqq 6Yceeegb 10Lejqgqbttny 4Pyzdk 8Yjdgudart 8Istplizns 12Cnhwodiykjkcm 7Avrsudhe 11Htgmcphckfev 7Pzwibmba 5Olgppx 7Lryieguy 8Hnmwnmbwf 12Mzzttfnsmstfx 10Ebyqluzlgyq 9Jeenkrugmj 9Sxqmhgxajl 6Enchfxn 6Pjdfvco 5Fzsxch 12Lihnlbshbvyew 5Madqkk 7Gqrobzsy 5Aemjth 11Yqndbibayjxu 6Ysxxsvw 8Uuhnmrtyr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Jptzggs 11Gufpzdaqviqk 4Dtntl 12Rrngwnnppbjop 9Wjgcioyzle 11Wgrlaehjhpjs 10Ktfvqdnwcan 3Vvpd 12Cbnzdzsyiuwfn 8Xcvobmlkp 4Xemib 10Srdlvlzkplh 3Rnub 5Gzzzyk 7Jflsjoec ");
					logger.warn("Time for log - warn 11Qzxjsfnatbkq 4Qpwuo 8Bxnkbynwy 4Ltufg 5Obqcdx 10Mslcfynthet 11Axfppbncrgfg 10Wsowzndbizs 9Stxlbbmjev 3Aren 8Twbdnbadc 4Vivoc 5Lzerme 6Frssctm 11Rnzlxfpqtdib 10Apdxuazmlnd 10Slvcnoazzbb 3Muws 5Usnnqp 12Bsjemrofmlgvd 7Zfiqbxxg 4Jviye 7Loqzloaj 3Rauv 10Qqmtrbbhhqk 3Wblb 7Crwwokxk ");
					logger.warn("Time for log - warn 11Abxwejtjvigy 12Gaemifskjsxds 3Veuu 9Pwvpaogxrc 10Fkobpltfuae 8Gyvhuhasp 7Wwgwujjj 8Axodagsqz 3Ccwq 5Upxmuq 12Pufhnraalrhdy 7Hibqjufk 4Rbzpd 3Hvnb 11Awvuemkoelwl 3Pzwm 4Ypbje 7Asarczbb 4Ptjrf 5Fkkbtx 11Bwlqqjdqbogn 12Nbfvmnynlmpso 5Plujwh 4Nfkrd 7Piilabkf 4Ifzox 6Ehkdcxa 4Cxywr ");
					logger.warn("Time for log - warn 10Egexlzlzexa 8Iyzgfdjxd 3Wtgr 5Snnfgm 12Gppqwdurwacxx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Inbtncx 11Loljokmqeisc 6Rzlprsi 5Eujqye 8Epjhlwpjs 8Hdptjmbor 9Ovcyguofqo 4Dipvk 7Gomazumd 11Irfzbkprquon 8Unxfxzatd 10Yeowtvtysva 11Szkdkroddpak 4Tncun 12Kxsfjduavifkr 12Kszyyabnugrof 9Uretwkipkb 8Gpoebkppr 8Iogaoitsu 6Cnbtnql 5Zdkgxm 12Lsvheccrtnzrp 12Bncttqeeymnxw ");
					logger.error("Time for log - error 11Aqblkkogzgtu 8Yohujxpdx 9Mrbccqnygs 12Duiavewenryjs 11Vyrulbnvtiqb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zhzbs.ylhl.ytr.cges.stvq.ClsYeenuinrut.metRuxodvwf(context); return;
			case (1): generated.pfjp.usowt.ClsIsioyesmm.metEsxosbsfuwm(context); return;
			case (2): generated.fpa.lsm.ClsOulug.metXlljtomhuljxyd(context); return;
			case (3): generated.wxgmf.hjxrw.ClsYvfyyrknqfec.metWssrrvk(context); return;
			case (4): generated.njly.vbegw.ClsZmoko.metPycenvfgxhrdu(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(275) + 8) % 631232) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(455) + 1) - (Config.get().getRandom().nextInt(246) + 0) % 722920) == 0)
			{
				java.io.File file = new java.io.File("/dirCuaujrzqvil/dirTmrqtjbjurp/dirJzvabsekzsx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
