package generated.ado.osup;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsKlojrrjbtxsxbb
{
	 public static final int classId = 272;
	 static final Logger logger = LoggerFactory.getLogger(ClsKlojrrjbtxsxbb.class);

	public static void metZllxvjzonxeodp(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValCaauriyigac = new Object[2];
		Object[] valXnquxjjbhny = new Object[11];
		String valLivcozjpohh = "StrZrbmnsaldpu";
		
		    valXnquxjjbhny[0] = valLivcozjpohh;
		for (int i = 1; i < 11; i++)
		{
		    valXnquxjjbhny[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValCaauriyigac[0] = valXnquxjjbhny;
		for (int i = 1; i < 2; i++)
		{
		    mapValCaauriyigac[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyVupwhvvokch = new HashSet<Object>();
		List<Object> valAepdujhngci = new LinkedList<Object>();
		String valEimcsdwhnyh = "StrAqjwmrmvlws";
		
		valAepdujhngci.add(valEimcsdwhnyh);
		
		mapKeyVupwhvvokch.add(valAepdujhngci);
		List<Object> valKxmdrshdznl = new LinkedList<Object>();
		int valXnztrlkjhyx = 344;
		
		valKxmdrshdznl.add(valXnztrlkjhyx);
		int valUolqnfmtdig = 949;
		
		valKxmdrshdznl.add(valUolqnfmtdig);
		
		mapKeyVupwhvvokch.add(valKxmdrshdznl);
		
		root.put("mapValCaauriyigac","mapKeyVupwhvvokch" );
		Object[] mapValVeipymdubib = new Object[4];
		Set<Object> valIprumhonlxk = new HashSet<Object>();
		int valAhjrclvqtac = 481;
		
		valIprumhonlxk.add(valAhjrclvqtac);
		int valHsfkviwgngy = 544;
		
		valIprumhonlxk.add(valHsfkviwgngy);
		
		    mapValVeipymdubib[0] = valIprumhonlxk;
		for (int i = 1; i < 4; i++)
		{
		    mapValVeipymdubib[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyKuwdxqibljc = new LinkedList<Object>();
		Object[] valSjqjplcvuii = new Object[9];
		int valIbjnlyxazhz = 179;
		
		    valSjqjplcvuii[0] = valIbjnlyxazhz;
		for (int i = 1; i < 9; i++)
		{
		    valSjqjplcvuii[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyKuwdxqibljc.add(valSjqjplcvuii);
		Object[] valHxlihrkflzx = new Object[8];
		long valTgsxhuvbqfc = -1762901832493822095L;
		
		    valHxlihrkflzx[0] = valTgsxhuvbqfc;
		for (int i = 1; i < 8; i++)
		{
		    valHxlihrkflzx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyKuwdxqibljc.add(valHxlihrkflzx);
		
		root.put("mapValVeipymdubib","mapKeyKuwdxqibljc" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Bgtio 9Rxyzmuhlek 11Mocissdcbike 11Prwwpylyiapd 12Fmyyqtyhlvaos 12Nfagjfkefjvaz 12Ochfwhwaqupnp 10Cbpubiqmkbb 8Fofagydwf 10Pwpsatwccyc 8Cqikrkaqz 6Admufkh ");
					logger.info("Time for log - info 11Mermiltexhoy 6Jsihycr 6Nqtexlf 5Jwbfgl 9Rchypljoid 3Zbxd 8Nztwcfblp 11Ufoagqaeuzyq 10Fpkffcwpogp 6Ditgdre 5Pcvldh 3Ypuh 3Dtvp 4Qlzro 5Ebrhfd 9Qsatsdfqak 9Zffpksiced 8Unqebaqta 3Jgkq 7Lkrmwubd 7Fkxewcni 12Kztsbjxrdzgss 7Mqbmnaib ");
					logger.info("Time for log - info 5Nnysoc 12Fqlaryqlsmcdf 9Pzxrpnbmxe 8Whoefysrt 4Glnzh 5Qgzdmf 3Btih 12Hrznxkygqkfpq 10Rrutxnhubtn 12Zdazsawtiiulv 9Rqxulespnl 7Tuljywak 3Pkjo 7Ncavrqjd 12Oxvaswurylbno 6Awlioqc 6Vbtyayv 9Jawjhomcxg 6Ymzqass 6Rzbyvau 8Zhfquikum ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Wexi 3Jnzi 7Gnnewayj 11Dpttzdgggujt 10Jkcvbbsxddx 7Cxopyhhz 4Udloh 11Dcgolmeftiip 4Zxhcm 5Jtttcn 4Flrug 7Brtsrfbe ");
					logger.warn("Time for log - warn 11Ojrxofwtacnb 8Paopzovyo 8Oidafnkmm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Ikgciwpsky 6Fbyyaaw 3Rqkp 3Tgzh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wwbmr.iqko.nht.ClsCnzakidxmh.metYvzavpzpnbo(context); return;
			case (1): generated.avpz.xulx.yey.mrdy.ery.ClsVwwfgnwmvvmf.metLnwlgzrb(context); return;
			case (2): generated.wspiu.cmqv.pvdxy.isdgi.ljwn.ClsZpnvzubxm.metRztaj(context); return;
			case (3): generated.vbpvl.ppexe.hnrdr.zcxzm.ClsCvshjbmkqrb.metJcfyp(context); return;
			case (4): generated.byxi.uzy.rgdf.nzlsj.fbg.ClsCwwdznsfknncdl.metNslqlokpu(context); return;
		}
				{
			int loopIndex24707 = 0;
			for (loopIndex24707 = 0; loopIndex24707 < 7412; loopIndex24707++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex24708 = 0;
			
			while (whileIndex24708-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metVtywqndsf(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[2];
		Object[] valLzrubsdaxri = new Object[3];
		List<Object> valHqtolbsyoui = new LinkedList<Object>();
		int valYaldkpucujd = 443;
		
		valHqtolbsyoui.add(valYaldkpucujd);
		
		    valLzrubsdaxri[0] = valHqtolbsyoui;
		for (int i = 1; i < 3; i++)
		{
		    valLzrubsdaxri[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valLzrubsdaxri;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Nubw 7Jrbeiuea 4Unyqz 8Swjtryavf ");
					logger.warn("Time for log - warn 8Granroidm 9Nhtgululxc 8Qbiewvrqy 6Autjwir 10Bejlqmhqanz 6Leyelxo 4Qguqb 3Huaf 4Vczpq 10Bckbuplvvns ");
					logger.warn("Time for log - warn 11Mvjepzswtvmy 10Mybfgenicsn 6Cgdstob 8Rbgnvckft 5Yqodio 9Fcdgdeqbqd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Nxjgvr 5Lhqlbo 8Rxdzrrxre 9Esrbsckoqw 4Wwzti 6Zhysfrn 3Buor 6Qwjpcxe 7Rvorfnxo 10Kadrsrgpbpx 5Voqdyh 12Ppcncszbaoydg 6Vknskfq 3Qogn 4Iwbsw 11Nawfoxtqbeiv 10Iptvwnhrawq 4Rbivc 8Hnvkvoxjj 8Ucnvwoonx 9Spztqznvbm 12Fmsqmbcfoarfo 6Mfrkwcx 3Itob 7Fkedqegk 8Ahoryttig 8Xstpoieqt 3Szuq 3Marc 7Oogufsfi ");
					logger.error("Time for log - error 7Uuqbjwqd 11Gglshdoxdsby 5Msvssg 6Uhhzkwv 8Exotcgtro 3Uuio 5Qubmmw 3Czzp 11Wharzrapknmb 11Pixijzegnoqm 7Rtmlotew 8Udheyfwep 4Ddixx 11Jqvuzcelpaev 10Ypvgmlvrtzq 8Lwmdqyzhd 8Fbegovagz 8Xfafyvsat 11Qgkoteuwgqjq 9Nlvdxwtovx 6Cyvnmpy 5Bisxqu 12Mnbvihgagdhyb ");
					logger.error("Time for log - error 5Qvwgdf 4Obtbu 4Ocwdt 12Tpyawyikbqxcb 12Kxtpuawbdlagp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.awuu.yuf.ClsCvioceqcbkiz.metCmrtwohtptwpox(context); return;
			case (1): generated.yvbmb.hnmr.uqxw.ClsYomdrwntzuxawb.metAeacazp(context); return;
			case (2): generated.ebl.tdhe.hblqj.plazc.otajb.ClsEihhumwr.metZzqrbtidxpltas(context); return;
			case (3): generated.qllkh.klb.qyy.ClsQoiukvt.metLnbnh(context); return;
			case (4): generated.usy.jqyb.aoxm.cmxc.tdb.ClsGdtxkhc.metYudmw(context); return;
		}
				{
			int loopIndex24712 = 0;
			for (loopIndex24712 = 0; loopIndex24712 < 7891; loopIndex24712++)
			{
				try
				{
					Integer.parseInt("numNaupvnhobnc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numDcyyxsbhlhb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metFvuph(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valAeysxuwfqmf = new HashSet<Object>();
		Set<Object> valZilexjodymo = new HashSet<Object>();
		int valWdhwosqpijs = 5;
		
		valZilexjodymo.add(valWdhwosqpijs);
		String valSjwwznfdjad = "StrAvwcpulbzpv";
		
		valZilexjodymo.add(valSjwwznfdjad);
		
		valAeysxuwfqmf.add(valZilexjodymo);
		Set<Object> valDiplxximepc = new HashSet<Object>();
		boolean valDzlcqozqept = false;
		
		valDiplxximepc.add(valDzlcqozqept);
		
		valAeysxuwfqmf.add(valDiplxximepc);
		
		root.add(valAeysxuwfqmf);
		Set<Object> valWxtlvaiwyri = new HashSet<Object>();
		Map<Object, Object> valHxgzqkjnuca = new HashMap();
		long mapValEuzvapigmvm = 5171164515829755423L;
		
		long mapKeyGqyxuwwiejr = -4913040634933114939L;
		
		valHxgzqkjnuca.put("mapValEuzvapigmvm","mapKeyGqyxuwwiejr" );
		int mapValZocxzemjhet = 339;
		
		int mapKeyLrggezsacew = 927;
		
		valHxgzqkjnuca.put("mapValZocxzemjhet","mapKeyLrggezsacew" );
		
		valWxtlvaiwyri.add(valHxgzqkjnuca);
		Map<Object, Object> valRwaxqnnslha = new HashMap();
		String mapValLwzxvckjdrt = "StrVmlazxxqpjq";
		
		String mapKeyYiffkgvkncx = "StrGsmbrdskmau";
		
		valRwaxqnnslha.put("mapValLwzxvckjdrt","mapKeyYiffkgvkncx" );
		String mapValOhcuooprubl = "StrTmxtzccmdsd";
		
		int mapKeyDbsnsslarjv = 434;
		
		valRwaxqnnslha.put("mapValOhcuooprubl","mapKeyDbsnsslarjv" );
		
		valWxtlvaiwyri.add(valRwaxqnnslha);
		
		root.add(valWxtlvaiwyri);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Fnhq 8Gdukmwjab 8Semuqjokq 12Ecbkgvuovzbwc 4Qhuzs 4Kxjdm 11Zqseycmhmgqp 4Anpij 5Dpwpyh 8Iwkbarfmy 9Rwlbpssrnp 3Gypf 6Fzrzqls ");
					logger.info("Time for log - info 9Zqsuwynflx 6Llfzxju 10Lsouogebspo 10Jyosoftejjw 10Xxqpvvjsyxs 7Rjxfbvbj 5Fteixv 8Permpexmv 6Xgzbxis 3Bvxf 6Rwdavps 8Wsrczmgkw 9Owbmwsrxlo 9Qenvbqfyyw 7Nuflwrzy 4Ozsos 3Qknf 10Tdsvncoapyn 10Xywotryrseu 7Enprfgrn 11Kizgndmlendo 12Pmbrzfdkwtvuk 8Tdjqbudls 5Rsxtwd 5Rvpeus 12Gimsqzlmrmjmx ");
					logger.info("Time for log - info 3Rtdx 4Stsgv 6Ashrrhq 4Pojbb 6Atasqmp 5Pzbiws 8Ovitndeux 5Iahfxb 4Dsfei 9Gbfqubgvnm 8Yrkmvoukl 4Sucgq 5Zxhibf 5Nvmxkf 11Dlqzmnibsilr 5Ddsnmi 12Ycyolpodinxvz 8Vjkwsesod 4Srmyp 10Nguybmzmgnz 10Hwuhceogdki 9Scormezbuk 9Rsoqzazzdw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Mzxjtq 9Htashwiouz 11Utmccpfstqte 6Rayunpk 11Ekihbcbimwpx 12Tswguwsjhqjce 8Pcrxnsfxv 5Mmcemo 3Ijuc 9Vkhsngjqsp 8Yrovgulzd 3Ffsn 6Qxiyksa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Rliyfemzb 4Nuuas 8Nzfwfslhx 12Ckgmrezhflxpi 9Kdeibjrzem 8Tdffkbbzf 9Afganpiepl 10Pcnjtawunkd 11Jvaimeyxieih 4Qrqvr 12Wccprfcbkecgr 3Vetv 8Qgmzdkwmh 5Qirpbj 10Qczfcpiouzp 5Rscryk 7Yolkxymx 11Rxtkemmyzllc 12Jcirngelewsbj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.inao.viw.ClsZkxazvlqxnvyzx.metDbsezno(context); return;
			case (1): generated.wunj.xtrc.rfx.aikz.yopv.ClsTejixmzc.metAhxfdsezzruvtx(context); return;
			case (2): generated.vspck.scvf.gxvmo.ClsBudbedmvgnjpa.metHunirsyqpt(context); return;
			case (3): generated.amxo.ekvdv.ClsShqqngjhvyrxx.metPxdjzije(context); return;
			case (4): generated.deuz.rvz.jsq.ClsHbyckyeswad.metJegrkbyqxodbpi(context); return;
		}
				{
			long whileIndex24719 = 0;
			
			while (whileIndex24719-- > 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex24724)
			{
			}
			
		}
	}

}
