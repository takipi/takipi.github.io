package generated.gcr.qqx.juuh.caxx;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsRlelgjq
{
	 public static final int classId = 49;
	 static final Logger logger = LoggerFactory.getLogger(ClsRlelgjq.class);

	public static void metRzypwxzdumiu(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valMygsudumawa = new LinkedList<Object>();
		Object[] valTbfhgyjpkgx = new Object[6];
		long valXxeobmbtrsh = 4534945270388063167L;
		
		    valTbfhgyjpkgx[0] = valXxeobmbtrsh;
		for (int i = 1; i < 6; i++)
		{
		    valTbfhgyjpkgx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valMygsudumawa.add(valTbfhgyjpkgx);
		Object[] valPmmdbcjjyjt = new Object[6];
		int valTohvzydkpdh = 695;
		
		    valPmmdbcjjyjt[0] = valTohvzydkpdh;
		for (int i = 1; i < 6; i++)
		{
		    valPmmdbcjjyjt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valMygsudumawa.add(valPmmdbcjjyjt);
		
		root.add(valMygsudumawa);
		Set<Object> valDtudkncmylc = new HashSet<Object>();
		List<Object> valLrlhlnhrmot = new LinkedList<Object>();
		int valKtxtdchxwpi = 85;
		
		valLrlhlnhrmot.add(valKtxtdchxwpi);
		long valKpvjryflijy = 1690302470749722532L;
		
		valLrlhlnhrmot.add(valKpvjryflijy);
		
		valDtudkncmylc.add(valLrlhlnhrmot);
		
		root.add(valDtudkncmylc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Gajdbuxxhkf 9Rmfnshqven 4Qpnco 8Drwvyswsp 7Pcpmpcfu 11Hppoowjmllpf 3Hjla 9Iqxaegjetl 12Veikcnrcemnrd 8Mmjottjww 5Ynjvve 6Koohnjn 10Mpgguqiazzq 5Tapefp 8Cmssglska 8Acyajledq 3Lkrr 4Lljkg 12Xffrqzjydbmov 10Gnwfhdlguox 5Qwxglx 4Lmwgb 9Fnznynunqr 5Dcrftj 10Kvnaaripobv 4Vqzem 10Oiuvraduakm 7Shlgnili ");
					logger.info("Time for log - info 12Sxecvihkxbqlt 12Qkqtbkdhofgym 4Ibycj 11Jdvheldqszod 8Cwyulbpyi 5Qlulej 11Tzfjlklhwhhv 10Xtdvnrbaxve 12Zfdnbxbslfgwl 11Iqumzrvzwvyb 10Lnshgirnkmz 8Heodavhgr 9Gbqrdlxtpc 12Vxfjxyflobmdr 8Qyjhzhivg 6Zzyvmmz 3Duap 12Pjywlogqeuwrf 6Qgkvcpu 6Jbyleqb ");
					logger.info("Time for log - info 7Carkaxjx 10Jbtqfxeqgnj 3Gnvi 8Idnkitury 9Azqyrgrnyd 7Jrnbarnj 8Ziwsuipru 12Rleymxnpvebio 11Cznciagergad 5Jkwuor 8Aungmuqbj 7Easmldfc 5Ahiwta 5Gpxeyd 7Azsrcnqy 5Dvdmeo 11Dghcuolibmab 9Kiudtakbbm 3Mntw 11Moqcvyolaxgb 12Ljbznwzjlvvyj 8Dxbocqtht 7Bevcjdvs 6Uwhpvtv 8Nufzuetix 12Sjvpezbhpzhpr 12Tazdldaqtaibz 10Blabpogupbr 6Neaejkl ");
					logger.info("Time for log - info 9Rknvqundku 8Ykpabqdur 10Uwrxnimeljr 4Cisbo 3Ugtm 10Rjzjkzeemkn 9Cqkdxbpbbg 12Mmstepwcioeao 10Myijgfvzvvh 6Kvmicaw 11Tjbvzigidskf 4Hqcbs 11Minokfidmass 3Csul 3Ggnn 3Mozv 7Swtwcnni 11Oorhmopwgmcn 6Mlarurs 3Jloi 9Etzjyeobfv 5Yfttdz 4Klcsy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Gkuiom 8Bwsivfxdk 9Isabjogphq 4Mmgrv 12Ztttvxrjckczt 5Pttktj 3Wvsv 6Tgkbzre 7Qvdksyct 11Bhgntlyhpjev 8Pznaqdtgf ");
					logger.warn("Time for log - warn 7Qeknxtxl 9Opttiriybj 8Apkjmgpiv 12Bluypbifqsahg 6Zkbgzpz 12Pexpakmwtifkl 9Fiaedkpxed 11Zxbshemtmzkg 3Prrx 8Cdfjyzvai 5Vqnnun 5Fnaoxi 12Orfmiyzsxgfal 9Vgkfrttase 8Rggbmsnww 12Nrnqibvcqvmxp 9Wmghmqcrkc 6Bobsvwx 8Elbchumdm 9Oadcoaiiwf 10Ynqgbygjtvi 10Wmnuyxlpqjh ");
					logger.warn("Time for log - warn 9Kmjuxjcnxo 9Ybxjbdqypf 5Zpdxcs 9Xnpredhafg 7Jcmrhzor 10Frrvjnuwogh 12Bmjjdmyvlsicw 3Lkjf 7Htazxmrg ");
					logger.warn("Time for log - warn 3Vvrn 10Hdowkatdepn 6Bskypwh 7Crnjfzhe ");
					logger.warn("Time for log - warn 8Cwhclvtfn 8Adoyihggj 7Jgbptrfs 9Zjfgarwgwq 5Iljfhl 3Losb 5Tjotgh 7Tfmzjniz 11Tltjdpdelqtg 11Huyvcsikajhw 4Bgukz 8Cvamclymo 10Wkzrsffzkmb 11Jyrpfrkmzgqa 5Fkytwc 12Mlxdyobkljqtq 8Esryhmzgn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wrwx.jsm.hgij.abg.imgx.ClsRhzgz.metZwioh(context); return;
			case (1): generated.bwwh.pcsa.hpav.bbh.ClsXicvnzwjqnoh.metQfgugo(context); return;
			case (2): generated.fkbuh.vawj.ClsXsqsadsvdke.metGrquryhkwyi(context); return;
			case (3): generated.jczh.tiox.sfe.qsygg.ClsFcpmoenzb.metEjlwxaxrxcgtq(context); return;
			case (4): generated.lzs.nehlu.rmx.ecdl.iyxe.ClsYbctjsi.metFvbkrai(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(838) + 4) * (1628) % 31574) == 0)
			{
				java.io.File file = new java.io.File("/dirKrpftyvtqjt/dirSfewldxygup/dirPsoojrjrkxd/dirRtyuzmydznj/dirJgjnkupvunt/dirWalxwvkdkyf/dirExstjlufods/dirJvujlxzgofr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirToibeuwwoqv/dirUxglvychjwt");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((Config.get().getRandom().nextInt(249) + 8) + (6092) % 887944) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varOfzwquzzeba = (Config.get().getRandom().nextInt(664) + 6) - (708);
		}
	}


	public static void metJcvcwuus(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[8];
		List<Object> valWtdjxvyakck = new LinkedList<Object>();
		Set<Object> valNfseeuykkgz = new HashSet<Object>();
		boolean valAgxsywtdvrz = true;
		
		valNfseeuykkgz.add(valAgxsywtdvrz);
		
		valWtdjxvyakck.add(valNfseeuykkgz);
		Set<Object> valQzsfpavkeuv = new HashSet<Object>();
		boolean valRknladwghcm = false;
		
		valQzsfpavkeuv.add(valRknladwghcm);
		
		valWtdjxvyakck.add(valQzsfpavkeuv);
		
		    root[0] = valWtdjxvyakck;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Bbgbvxn 12Pxvwoxlxfwjzq 12Ylluaaxucplje 10Sgrepatuarw 11Khdutnbeiyed 5Owsewx 7Byxiatzn 3Tbsr 3Nxjr 5Yckqwi 12Yfjetrmnyhkyn 7Uuwhrxjx ");
					logger.info("Time for log - info 12Dpsozdttjvtqk 12Lxrgvbpmggjkg 5Cnidio 10Zicypwrogps 3Sjlz 10Aceeslezepm 4Ihons 9Pfeqrpqziw 12Sdpsjzwqmfyeu 9Lxbxnxfmar 12Cpgwujvdltlva 12Kmfvgpkvkfbqd 4Gszzh 4Xsgnf ");
					logger.info("Time for log - info 7Inylhtur 11Gbseoqqxarxd 12Kbnyxsokmovpv 3Eiih 12Nhfypaddsacwi 4Jtocq 12Mxhyewzjfkpxg 12Mkgxptxwwpxmo 8Hkxbgkuky 9Ldfgrmatsg 7Ibknbpot 5Viwdru 11Fvfyaldemtnv 5Aobnuy 10Gtcjpqqrkwd 7Bctchlbx 5Ciqral 5Aangsj 11Mljpxvmvnpao 7Yfefgjxt 3Qvgb 4Bsgkp 9Nzxwaqqckm 11Oqtxtmosfide ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Wvlbkrswuzw 4Erkaf 10Vfehzeesivq 3Xzam 7Ucjmnvbl 10Cygkxyrspvz 6Cpfuhny 10Jzpayfkszcs 11Nufunuuerimb 4Ohnuw 3Oltw 3Flpu 5Mrzkzu 4Irazc 6Ohrngqm 9Golllatpll 3Owdj 6Fyimoiv 10Mnkrbshqsin 11Mcaxifnzajtg 5Jmajpa 5Tvumjc 12Raktrovnivntn 11Xuranzczyilf 11Payhbnfohutu 10Gazukkpnobj 6Rtadekc 12Zbxkfasdwsbfb 9Hcibzodjsg 3Xaed ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Cvtntmdqupm 8Pndsoqgkt 9Ckvlzsdksj 4Bdhqx 12Bdhvehgrzxglz 5Jjdbxr 5Stinru 9Osfzgdixbh 9Ytavyxatzg 8Tslayuyhh 7Pnppatzq 5Ffrmaa 4Dbnaw 6Izpsbxv 8Ssmjxvdww 4Layif 3Ojjf 10Zcccpkcdpny 10Rytpbwzgeuz 6Caygdyb 6Bvlclek 4Hlxee 10Lmkscpsruiu 8Haqpciotz 8Oadqltydr 7Tawovgfr 10Yackftcqavh 9Gvuwmfuker ");
					logger.error("Time for log - error 8Ehfcaimrp 9Zmvojzwgkp 8Avovhhdjp 12Ruvvdfkwxsbyx 4Qcrdh 9Ebiujosbtw 12Hhntdmfruvfsu 6Nymvxvs 7Cyvxtqgp 5Vetjkp 3Ojah 11Oqddadookrlt 11Jaihedvrufkp 10Qvborpkqomw 6Shzajji 8Xhuvamojw 5Ltknjt 4Uqquy 7Qlsrzswv 10Xorcctvsgqk 4Nrrdi 12Fbuxndfppncjp 4Ftquc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gcr.qqx.juuh.caxx.ClsRlelgjq.metIstdlmn(context); return;
			case (1): generated.iotb.mlgn.hcur.ClsAdwtsoupvuwy.metTfsczzma(context); return;
			case (2): generated.fhy.qnk.brj.xhy.ClsYgumeudbf.metVozkhelpekwnp(context); return;
			case (3): generated.kibd.nddr.nknr.pccz.hryio.ClsBgthm.metFrmpvshfvh(context); return;
			case (4): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metUsjlmntvgpvw(context); return;
		}
				{
		}
	}


	public static void metIstdlmn(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[2];
		List<Object> valOijwgkzahqx = new LinkedList<Object>();
		List<Object> valAawhkyggvgr = new LinkedList<Object>();
		int valMwujtdjxjft = 514;
		
		valAawhkyggvgr.add(valMwujtdjxjft);
		boolean valJreaihcyvlb = false;
		
		valAawhkyggvgr.add(valJreaihcyvlb);
		
		valOijwgkzahqx.add(valAawhkyggvgr);
		
		    root[0] = valOijwgkzahqx;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Ivxrygoqbvfbu 10Kcmnzhooypz 7Ajlaswrg 11Fncilmtddhce 7Chiizovd 12Liukuzqhffuji 9Whwtferdnt 6Efhpbuv 12Tiktuzbwteawh 4Dgbji 5Nwcvly 11Vlanbmygfuno 5Ojgxai 10Ivitcjgcydb 3Lquq 9Ekaebhiuww 12Dcpbjbpbzufbg 3Izuy 8Vkzhqmolm 8Aaxdsdqac 3Xval 7Vgkguatk 7Cttjqiui 9Vjpjczocrp 8Fukuobphv 4Isban 4Ejrkb 12Kvjtnqjihxrsk ");
					logger.info("Time for log - info 4Snlrc 10Ufwkzuqiwaa 4Vpdvf 9Fuzxijyvac 6Fhtccxa 12Mdpqpvtoojcoi 7Wkapuraz 9Lvajviiqfs 9Aohvjcctwx 11Kpekwsyaebzr 6Peovioy 4Kewyd 7Icgcojkh 12Zgzpbimjurmvk 6Toucjid 11Kftbdvovyzrs 10Fqypkyqdekn 10Jhalskalwtn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Bqgmajt 10Szcjhekxrpk 8Avbqhbths 5Wufuzd 5Cguxrl 10Vvlnbxtvarl 3Eoxx 8Smtvvbyby 3Yyie 6Dvreooy 8Hkimpasai 10Jalmbyquyto 9Pypgtnnuzh 11Ithsoymchlpc 11Yyzkmqayhjzy 5Ufyegv 9Epbaaujsbg ");
					logger.warn("Time for log - warn 5Cuetzg 9Pwtnkznozo 9Dxddytrvfx 12Pxoxnxaymjhht 12Dijlwpsxquxst 7Xnvovtfd 9Fidsoarchq 8Iyhysefir 11Wldthlgqhtyq 10Uzlrqelcevv 3Qibj ");
					logger.warn("Time for log - warn 9Kkxicyepgl 6Hjpubcb 8Hdnpguyvp 8Zklhvtdeb 7Klwvnyar 7Dwngzbfa 4Ttyby 9Wmalkvjpza 11Ccvrustoakyr 12Ehykyxabbmqnv 3Hmlh 11Guywqgojtlmn 3Arkc 6Rxhisqm 4Zfupy 5Jgndvl 3Guul 5Hjipka 8Kfkgrijaw 12Nkduhniuafexm 8Zfwnbcauo 6Ilkvjeg 5Xmizpw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Eeyxuhxgfilgp 11Zqcjzlgsozck 9Bihsnaxbrm 8Wclmvgefx 3Xgkf ");
					logger.error("Time for log - error 4Nahmk 6Wfxwszs 10Kkcqknmqryd 3Vupx 12Gzveawvqwhmmc 3Zxee 11Xbidspdzwfjn 11Guicnoogxmmr 5Dwtupq 12Xqedpcnjengnw 10Gjpvfdnldxt 8Gfmaghwur 9Ylwwkwgvkc 7Dkxxouoi 5Yaneho 10Udiqhroxxpw 6Hrpxqca 9Jnouoftjsc 8Qtekuwofv 3Pbhq 10Ecgejjttuma 9Huievedtvx 4Nxlkv 7Qjcrtvls 6Watxawg 3Bdlu 7Tumfulat 8Rmyevpijz 7Mtbrqowd 7Lrvzifng ");
					logger.error("Time for log - error 8Paqtyvrgp 12Nahklbuqpdczh 11Evykrucbnqnz 9Jbzcxphqfo 3Eora 4Qpqvb 7Bjatpgfl 7Rjeanxeh 3Ggnh 12Rwafoqzeazlup 5Ciefui 3Qmah 8Wnsyrzmya 3Dzvq 9Cqdrmwiigr 7Qmoovqje 8Gnmqaufbq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cmup.ytrbd.ddu.ClsZmyzij.metDiwjsq(context); return;
			case (1): generated.spdv.axe.ClsZyjdutdtmcu.metUjulwqqjkfq(context); return;
			case (2): generated.kklo.eog.twpb.eja.vmrt.ClsCtkkdlrnk.metMzowgzzffz(context); return;
			case (3): generated.flvo.tuwfx.wlpxx.jysnd.tuk.ClsFuuvt.metYllionx(context); return;
			case (4): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metUsjlmntvgpvw(context); return;
		}
				{
			long varZlwgrgsflhn = (3193) - (Config.get().getRandom().nextInt(836) + 8);
			int loopIndex2907 = 0;
			for (loopIndex2907 = 0; loopIndex2907 < 944; loopIndex2907++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metUjideppdjluqfw(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValVyjqsikautk = new LinkedList<Object>();
		Object[] valGdydbdmgfhl = new Object[11];
		String valUjrxwnnrkys = "StrEokmvldykqo";
		
		    valGdydbdmgfhl[0] = valUjrxwnnrkys;
		for (int i = 1; i < 11; i++)
		{
		    valGdydbdmgfhl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValVyjqsikautk.add(valGdydbdmgfhl);
		
		List<Object> mapKeyCzgidgsqnkq = new LinkedList<Object>();
		Set<Object> valRhjwushcqts = new HashSet<Object>();
		long valTnhhmtqsvff = 1818771279080146333L;
		
		valRhjwushcqts.add(valTnhhmtqsvff);
		
		mapKeyCzgidgsqnkq.add(valRhjwushcqts);
		List<Object> valYshvbrepqfl = new LinkedList<Object>();
		int valQdrbvjmburn = 351;
		
		valYshvbrepqfl.add(valQdrbvjmburn);
		long valLksanxesffg = -2140713860706166883L;
		
		valYshvbrepqfl.add(valLksanxesffg);
		
		mapKeyCzgidgsqnkq.add(valYshvbrepqfl);
		
		root.put("mapValVyjqsikautk","mapKeyCzgidgsqnkq" );
		Map<Object, Object> mapValWlnovjaecln = new HashMap();
		Map<Object, Object> mapValNxafrkadluc = new HashMap();
		long mapValXfhoybcjvxj = -2405096093540150885L;
		
		String mapKeyUryrhyowvic = "StrLmuuqytuvvh";
		
		mapValNxafrkadluc.put("mapValXfhoybcjvxj","mapKeyUryrhyowvic" );
		
		Map<Object, Object> mapKeyQfyirjcbnoi = new HashMap();
		String mapValFksltckdxgn = "StrQvyhaisshui";
		
		boolean mapKeyTkyrlypxnsg = false;
		
		mapKeyQfyirjcbnoi.put("mapValFksltckdxgn","mapKeyTkyrlypxnsg" );
		
		mapValWlnovjaecln.put("mapValNxafrkadluc","mapKeyQfyirjcbnoi" );
		Map<Object, Object> mapValInnjzgnbtkl = new HashMap();
		long mapValGidqazocrkm = -6479195033197026595L;
		
		boolean mapKeyNiwmiyqsqeh = true;
		
		mapValInnjzgnbtkl.put("mapValGidqazocrkm","mapKeyNiwmiyqsqeh" );
		int mapValFzrrkdxucxo = 401;
		
		long mapKeySwpxmicxwfr = 2223914977405873158L;
		
		mapValInnjzgnbtkl.put("mapValFzrrkdxucxo","mapKeySwpxmicxwfr" );
		
		Set<Object> mapKeyAtyjtedwiwh = new HashSet<Object>();
		String valJiklsaqajkf = "StrWnkvockurmp";
		
		mapKeyAtyjtedwiwh.add(valJiklsaqajkf);
		
		mapValWlnovjaecln.put("mapValInnjzgnbtkl","mapKeyAtyjtedwiwh" );
		
		Map<Object, Object> mapKeyUpskjuxajbp = new HashMap();
		Set<Object> mapValDwaqslinvuw = new HashSet<Object>();
		String valTpbpemtjcdn = "StrProjkuncjbg";
		
		mapValDwaqslinvuw.add(valTpbpemtjcdn);
		
		Object[] mapKeyZxpuxukbyfl = new Object[11];
		boolean valSiylgeetbtk = true;
		
		    mapKeyZxpuxukbyfl[0] = valSiylgeetbtk;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyZxpuxukbyfl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyUpskjuxajbp.put("mapValDwaqslinvuw","mapKeyZxpuxukbyfl" );
		
		root.put("mapValWlnovjaecln","mapKeyUpskjuxajbp" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Zreugktvfjopk 5Scjmzr 3Cdhp 12Kbvcubszbvmjh 12Bartvblmsycug 5Uqvypn 11Ovpssfsmmrpj 11Jvdjxxmcslis 10Vevgyrekhrv 7Tmkqpnaq 3Otvq 11Xfghqtywlihe 10Ukuvsuthqtf 10Keibrhvllkf 10Bloixqiognu ");
					logger.info("Time for log - info 11Tqecagoboimt 6Rslybmh 12Xuwfnkesexiqh 8Qjiqgqhru 10Zdyitmtmkcf 4Kzjfl 4Qkhya 8Cshhadqme 11Jjqwvzfwtrts 6Fvnoiqs 9Bjktfhlhsx 12Iuyfrbrhlfyod 9Sxjjbfxjrk 3Asjp 5Hmamia 10Jkbydlqbbik 8Eawmajlow 12Uazedqrxkvhmp 11Xcpvsqjthjij ");
					logger.info("Time for log - info 10Wvehveuhapv 4Fvshd 3Piwv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Ughkmgfuvt 12Piigwigimtbua 7Xjwvyrbh 12Kaislinbexjil 7Ambgmpzn 12Vxyjdsjaxnoql 11Vdhwjjdzgjas 4Qlmoq 12Wopwrzlxmuman 8Nenxcnydp 6Hztqivy 12Sfzrqmeojhqjw 3Qbfg 6Szjgwpo 3Qwqd 5Uhazxu 6Luqbsqo 10Hwylrvabzfq 10Tiuwnndztlx 3Xmtf 10Peknfuloqgl 4Ofdfo 10Nrewpxmnyla 10Subsohzbpxg 12Arwxfwavfvrcl ");
					logger.warn("Time for log - warn 11Bybxpxzjdwwi 11Ryrdotnebzda 5Meqkqn 3Surr 8Dbtlgscpi 12Pvgpccyfmvidn 4Rxtcx 5Uugkwh 7Xefsuqig 8Crhpnsptj 7Dnbzpdko 6Yozbego ");
					logger.warn("Time for log - warn 12Kdkfmkuvicllc 7Ukbixchi 10Twgvfueloiq 10Gdkqqwwsjtl 8Pxtoqfler 12Hxqjevjtreute 4Cxfzz 3Mfzm 8Akxssycuf 5Gmhgmi 7Eyiihiwc 9Ddbyvyjxrc 4Kcals 10Wzzfzupmubn 10Tfudvtedxin 10Ajlokyrfkxy ");
					logger.warn("Time for log - warn 8Epaukhjkd 10Dnfbojttcwr 7Ohcfggvq 12Oatjbkrsmpttg 6Ccgzfym 9Lltwaagsmu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Rpufxvvn 7Wicsomks 11Grkqhdnlrzwf 3Jikj 12Tpuqdmotssizg 9Aqxnehlsey 5Sqwkjo 7Hlkwaong 4Ytuvg 9Inckybtzis 5Gkodcj 9Ynmzxmvejl 12Nzbjkttdkyiht 4Zoecb 9Bvhzktoktg 7Febovbrl 6Bsqwcud 9Idvfovkyoj 12Rwolurxzthkgo 11Xkohjvypsefw 6Yezcung 3Ueov 10Qgbpgqacfez 7Qnrelcun 3Dqgg ");
					logger.error("Time for log - error 8Czbffragj 11Xmhiompcekko 10Wfxacdduyka 10Mazcsswvajp 12Bchmokjpncnal 3Iabd 7Dbvaokgs 3Pixb 8Veavvilcu 4Sfmld 5Njxkud 4Zhtzq 11Ynegviivojcx 5Mpwvez 7Rpeuzmcl 3Tdkb 4Tbiaj 7Foiqiyyy 6Bprrbga 4Wrxgq 9Nzfspgptie 9Ydjclvxtwr 4Dbpfg 10Rawjrhidhxw 10Ceafohgbnme ");
					logger.error("Time for log - error 10Haezxabnfnk 10Tefrtcihify 12Iiphtosntdxnw 9Hyrpdkoych 4Lvdjc 9Ngdtawnmaa 12Yumvdrvdxtjfm 12Lngnghspirtgk 6Oranvic 3Pqux 9Yvcvjfvxrg 11Amkxpqrpsyyi 10Rbtwksobmpy 5Aoppbv 5Teacem 7Hhpgvzgw 3Gdrw 7Igoticug 4Rixxy 11Fzywiqpyeoxb 4Ynsjw 7Rvvhrkbx 4Ysvar 7Cofnliae 8Ivxxfcvun 3Imdv 10Yshrxqdfncg 5Eyrdui ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.njly.vbegw.ClsZmoko.metEiorguqyqdef(context); return;
			case (1): generated.fpa.lsm.ClsOulug.metRvwreotu(context); return;
			case (2): generated.kivyr.smd.affpo.ClsEqlzjivgvsoafb.metFtrfvpusk(context); return;
			case (3): generated.vspck.scvf.gxvmo.ClsBudbedmvgnjpa.metHunirsyqpt(context); return;
			case (4): generated.nsbl.xxor.rsxq.aixva.einq.ClsJcyofzflum.metDvyai(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(373) + 6) + (4706) % 135570) == 0)
			{
				try
				{
					Integer.parseInt("numMfdunlpxlqb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex2912 = 0;
			for (loopIndex2912 = 0; loopIndex2912 < 2179; loopIndex2912++)
			{
				try
				{
					Integer.parseInt("numKsjskxfcgff");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metThiolalxnhq(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valIsnwmluxwul = new HashMap();
		Object[] mapValOorobsyzfjh = new Object[4];
		String valUvqqitawdmg = "StrUdqudhzjktz";
		
		    mapValOorobsyzfjh[0] = valUvqqitawdmg;
		for (int i = 1; i < 4; i++)
		{
		    mapValOorobsyzfjh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyNswojdieqjm = new LinkedList<Object>();
		long valQizcjqqjfiq = -7966551471802117383L;
		
		mapKeyNswojdieqjm.add(valQizcjqqjfiq);
		boolean valOgimotvaawm = true;
		
		mapKeyNswojdieqjm.add(valOgimotvaawm);
		
		valIsnwmluxwul.put("mapValOorobsyzfjh","mapKeyNswojdieqjm" );
		
		root.add(valIsnwmluxwul);
		Set<Object> valHvgxuefxxsn = new HashSet<Object>();
		Map<Object, Object> valUmocdfbeekp = new HashMap();
		int mapValRglznudqqgs = 548;
		
		long mapKeyPpdblldhjzh = -6837207402418743344L;
		
		valUmocdfbeekp.put("mapValRglznudqqgs","mapKeyPpdblldhjzh" );
		
		valHvgxuefxxsn.add(valUmocdfbeekp);
		
		root.add(valHvgxuefxxsn);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Epzihmfl 5Fsvfic 11Zeiylnsjijot 12Hktbzgvkbzexy 5Jrkiiw 11Plizdhtydmsz 6Lbyiehw 10Vbenbwnivzj 10Tddpyzjjtju 3Otxr 11Suozuffoibhb 6Hycxxyo 11Voidpgisumup 6Gqkimld 12Nflvkfentkoqu 5Qtagix 10Ewqzclticfq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Lfxiyo 8Etkuqnefi 7Fdomfhsz 11Ertqprvkspiu 6Jbyztay 10Vzsmtkxylfg 9Ysjomctqdn 4Wdanh 6Emjtuwj 5Hfriwn 3Godd 6Aieywxs 10Uckuokcodmy 3Hzum 5Ipmgpc 3Fvnt 11Ndlternuxove 6Jfjbzus 10Zgitdkbdkho 5Yqsocp 7Jnugbvcj 12Puanqtfmyinxf 7Ygnalbos 6Ayrrnqc 8Leqxghjsu 6Zyrgvud 5Lfeaph 7Avaodvgr 3Qcav 8Ypdeajdrd ");
					logger.warn("Time for log - warn 7Tlqnkdjg 6Fryoxqi 10Bnckauhkfvb 7Bwhhveah 8Decfeeukf 4Bfjzj 6Igihydh 3Uqfh 4Naxup 9Ieekcfezpf ");
					logger.warn("Time for log - warn 12Otxbluszmprgs 8Wddydzkog 4Ollds 9Fhqadwwsqg ");
					logger.warn("Time for log - warn 5Fzwmfh 4Wvfxt 7Xmxofveg 3Fzha 7Mzbezghn 4Pgukp 12Hjutbptqpsvce ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Dtqehcp 12Kfucrsxxefmml 5Cklswg 12Uwbjejmjgfkuw 3Vpim 11Xkqwqglqbeut 12Otevpgurfjzuc 8Bisumvpar 12Uqidhrkrgbcvh 9Checdpjtxm 6Fzzogjk 4Cqtdn 10Johxaxgqrtl 4Onkxp 11Slcwydxmcsiy 7Mdzjhwhy 10Qzesceihjkc 11Qthtcgpcnqyf 10Nbyklyejhmw 5Iyezrx 9Chsvkkfnfy 3Mtad ");
					logger.error("Time for log - error 6Gtyoclg 3Pioe 5Dakjsv 3Iuzc 10Secsrqxpiut 11Kaidfibvblws 5Brmmyq 4Keybt 5Nilzqe 7Hcuncwya 7Dntbikvb 11Bmqghkyvpehk 6Qbdlrxt 6Ncxnqrc 5Gjazqy 10Hgxccrqzupl 5Gzhaqq 12Bndoczuvhtgou 10Bigghujbpeb 8Lfudnczxq 7Eokqbiet 7Yeeljdwy 4Qebru 10Dctcvokxppq 10Yqlpuskklfz 5Grboix 11Juftqkyttmuw 8Ywbecejtw 6Lbezpaa ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hnmnf.dxh.laih.zpf.ClsDfldwucgkze.metQochsxxrm(context); return;
			case (1): generated.mipzp.qfu.axrt.ClsJkbbmhkrxeo.metJhzcshfps(context); return;
			case (2): generated.blsj.gki.ClsOuhbksvj.metZabhogiwotxh(context); return;
			case (3): generated.ddlri.xli.qud.ytlvf.ClsNvsmjkbfbxcsj.metIasfjtbluwvaig(context); return;
			case (4): generated.fdupg.slw.vpest.ClsBfbtvkikd.metGyqtk(context); return;
		}
				{
			int loopIndex2916 = 0;
			for (loopIndex2916 = 0; loopIndex2916 < 5459; loopIndex2916++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex2917 = 0;
			
			while (whileIndex2917-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((whileIndex2917) * (Config.get().getRandom().nextInt(17) + 8) % 533590) == 0)
			{
				java.io.File file = new java.io.File("/dirVojdulzyzcu/dirRzxotkwxaog/dirUcxslawlnzh/dirIuthtwqorto/dirGamixeubjzz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
