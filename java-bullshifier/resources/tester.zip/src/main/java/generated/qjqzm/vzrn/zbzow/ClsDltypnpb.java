package generated.qjqzm.vzrn.zbzow;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDltypnpb
{
	 public static final int classId = 214;
	 static final Logger logger = LoggerFactory.getLogger(ClsDltypnpb.class);

	public static void metUfpufoucpqucye(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valExczzrncvdl = new LinkedList<Object>();
		List<Object> valMzfteyfanjz = new LinkedList<Object>();
		String valDoclybqnnnh = "StrGbanmhpcjmu";
		
		valMzfteyfanjz.add(valDoclybqnnnh);
		
		valExczzrncvdl.add(valMzfteyfanjz);
		Object[] valTaaarsgmtgl = new Object[9];
		int valVyzdggbusxe = 993;
		
		    valTaaarsgmtgl[0] = valVyzdggbusxe;
		for (int i = 1; i < 9; i++)
		{
		    valTaaarsgmtgl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valExczzrncvdl.add(valTaaarsgmtgl);
		
		root.add(valExczzrncvdl);
		Object[] valVzmzobiajvx = new Object[3];
		Set<Object> valSqwmxalsoks = new HashSet<Object>();
		long valKcizkpstkao = -8922121565533855790L;
		
		valSqwmxalsoks.add(valKcizkpstkao);
		int valAedkgpllotq = 201;
		
		valSqwmxalsoks.add(valAedkgpllotq);
		
		    valVzmzobiajvx[0] = valSqwmxalsoks;
		for (int i = 1; i < 3; i++)
		{
		    valVzmzobiajvx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valVzmzobiajvx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Csqyunf 10Tznmyjmkqwg 5Zrjmdc 5Lcjjzt 7Awgxihjj 7Fkobqklv 9Kmrnybpewo 6Nabulxh 5Mkjnzi 9Kudfrddnaf 12Dbkykaautnkfa 9Sxzcgqfzdi 9Uuyyzdugef 4Xooww 8Retadjfnj 8Zpcmwqjtj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Xuemn 9Flbcgcjrtm 6Ogcfxjz 12Autmwzmkmddtx 9Ofatnzwsct 12Jbzumoaefzypb 12Rqxdqodorheli 7Etfpbiel 4Twfgn 7Kdwxmofl 11Euyvskvnqvrw 3Scox ");
					logger.warn("Time for log - warn 12Wjtgenbynzotg 3Ritl 8Tqopygsjn 12Junrixwfoziim 9Tlumjatpin 12Ooorbmmartmgz 3Radp 9Fqjipxbwml 5Vkxgga 5Pjoazt 7Hxnbqezr 3Uant 4Flnvn 6Oihnegj 10Gsjbzmilvsd 6Txzksdy 9Agdclzljkr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Cxppzmoxov 5Tickqd 6Nhrhrne 10Xyhambfllht 3Teog 6Urtcfau 10Qerhkyqgpys 3Tvvl 10Oweudawtpzv 7Hfmaxudf 12Ffbsldnsjbgto 3Lrtc 9Zqnlsreebn 4Wtoge 5Crwokf 12Cuapmryggzgyv 11Ethjzpfafmut 11Xhbvkekgkciu 9Zspjylftyv 3Qpap 7Hqdcbowx 6Uauelgk 10Jgnnjlbvsbv 7Pnlhtzsu 7Ebgjaumi 10Ujpjyodomig 9Peagqgcosi 11Orobrmlqiijq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.munb.ijbed.gztfl.ClsHbtirm.metPhueixmhj(context); return;
			case (1): generated.hgr.jgeh.ast.ClsBwtgykt.metBmeyjwcjjjikwl(context); return;
			case (2): generated.joeal.ovr.nvb.kqkl.kegr.ClsNehitk.metGvuga(context); return;
			case (3): generated.gcr.qqx.juuh.caxx.ClsRlelgjq.metJcvcwuus(context); return;
			case (4): generated.xajsm.xnlym.ClsUmfzchfskds.metYensggsobl(context); return;
		}
				{
			int loopIndex23795 = 0;
			for (loopIndex23795 = 0; loopIndex23795 < 1790; loopIndex23795++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metGigic(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValXfzhtmyyshz = new HashMap();
		Object[] mapValMwlkpufbmjm = new Object[3];
		long valXdtwqqpffqy = 1199566481236962424L;
		
		    mapValMwlkpufbmjm[0] = valXdtwqqpffqy;
		for (int i = 1; i < 3; i++)
		{
		    mapValMwlkpufbmjm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyYyflyvslhdi = new Object[9];
		int valXhbvriyrcus = 466;
		
		    mapKeyYyflyvslhdi[0] = valXhbvriyrcus;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyYyflyvslhdi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValXfzhtmyyshz.put("mapValMwlkpufbmjm","mapKeyYyflyvslhdi" );
		
		Object[] mapKeyKswwrjgqiyf = new Object[11];
		List<Object> valQrkmffplbva = new LinkedList<Object>();
		boolean valIppkehjwkwb = false;
		
		valQrkmffplbva.add(valIppkehjwkwb);
		
		    mapKeyKswwrjgqiyf[0] = valQrkmffplbva;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyKswwrjgqiyf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValXfzhtmyyshz","mapKeyKswwrjgqiyf" );
		Map<Object, Object> mapValMkuncjnqowk = new HashMap();
		Map<Object, Object> mapValHebpycjhcvq = new HashMap();
		String mapValWdfgxpcpwqr = "StrXvmrmjkczau";
		
		boolean mapKeyCakyxxfsbkx = false;
		
		mapValHebpycjhcvq.put("mapValWdfgxpcpwqr","mapKeyCakyxxfsbkx" );
		String mapValVipqzbqybki = "StrEaklimpnjeo";
		
		long mapKeyFqcntnqbykk = -1878171470270815512L;
		
		mapValHebpycjhcvq.put("mapValVipqzbqybki","mapKeyFqcntnqbykk" );
		
		Object[] mapKeyKfhckpiymbr = new Object[5];
		long valPowoemanwtt = 1484450934593311408L;
		
		    mapKeyKfhckpiymbr[0] = valPowoemanwtt;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyKfhckpiymbr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValMkuncjnqowk.put("mapValHebpycjhcvq","mapKeyKfhckpiymbr" );
		List<Object> mapValHhpbqdgfekm = new LinkedList<Object>();
		long valQgoyxqilegb = 92615319057150394L;
		
		mapValHhpbqdgfekm.add(valQgoyxqilegb);
		String valKjwbcvwulgc = "StrErikubnumgc";
		
		mapValHhpbqdgfekm.add(valKjwbcvwulgc);
		
		Object[] mapKeyKwdktcqcflt = new Object[7];
		long valLipqdtalbwb = -4718814375442810391L;
		
		    mapKeyKwdktcqcflt[0] = valLipqdtalbwb;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyKwdktcqcflt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValMkuncjnqowk.put("mapValHhpbqdgfekm","mapKeyKwdktcqcflt" );
		
		Map<Object, Object> mapKeyQmndvspxbzh = new HashMap();
		List<Object> mapValHuvjncawxxz = new LinkedList<Object>();
		String valYvvvifpybpi = "StrKfjllkhltmt";
		
		mapValHuvjncawxxz.add(valYvvvifpybpi);
		int valDpyqxwrghqa = 305;
		
		mapValHuvjncawxxz.add(valDpyqxwrghqa);
		
		Object[] mapKeyPrxsrhguflo = new Object[5];
		boolean valThgvdfdtqqw = false;
		
		    mapKeyPrxsrhguflo[0] = valThgvdfdtqqw;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyPrxsrhguflo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyQmndvspxbzh.put("mapValHuvjncawxxz","mapKeyPrxsrhguflo" );
		
		root.put("mapValMkuncjnqowk","mapKeyQmndvspxbzh" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Vrhbanjjdijvg 7Uikysruh 8Pcrxwnthl 8Fvkypxvay 6Pfuckiv 8Edupinxvv 3Ezjp 5Hlpiys 4Rswpa 12Pcsgbbjwyejfm 12Xuvsdzrfyiizi 9Mfcimnhbsw 7Lbdgtrlx 8Nqtciwxcm 4Ryjzl 3Fmly 7Ebikryko 10Oygmqmsvjbl 7Vrqulwie 11Yskpkepsnflt 7Tdalxgnz 8Jqfhkldgb 9Zqieijwevr 12Cwckkxybyreij 7Kjnakosl ");
					logger.info("Time for log - info 4Vyztv 6Ruvsyia 11Nirpwtfaeute 5Cwfpsc 3Cdpz 4Iemhi 3Fega 10Kngchljgdvz 10Vhgnolwmois 3Vqvn 3Iyys 3Zqaa 10Xujynnjbcpx 11Whtlezoophjx 10Oeyihucigvi 7Hqevsohb 4Kgbmv 10Iqzknlmzmoq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Cphjqiqobgida 7Lxsusbdw 10Iqfcwohgcrg 6Bmjpuck 7Ukhlukhh 10Xqsjbcesiny 8Yjfqdizvv 6Bfpzevk 8Fhcqukjbe 8Ovwbpcwkw 4Gcqfw 5Hybuib 9Nbhwgmmegr 12Tntfxxnpuennu 7Rshsvwcp 6Ndnisir ");
					logger.warn("Time for log - warn 12Usverrkpeinyw 9Xwjfglvwtq 7Qeulhtad 7Wbqjhjva 10Skztvgpvwhj 5Lyedvh 8Ylrwxsatv 7Ybisvjkx ");
					logger.warn("Time for log - warn 7Atlyhqug 9Lrwplcqtof 5Gwddga 6Xadkytp 12Rjwccaeqgktnb 4Rcpfx 11Kjljvorrpdlq 5Jkqdtm 6Aluwdgz 7Txmgjztk 4Acexy 9Wqudaaxaey 4Gnifb 5Uuhree 7Rxsdlqoq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tau.glw.atmw.ClsCedrqvgmxtsj.metVmijeiavbbbbxs(context); return;
			case (1): generated.xpyaq.paxhs.ClsBkhbodffo.metKfifgmjw(context); return;
			case (2): generated.vfomk.ywmw.ClsYphqbuncz.metCyvjbbsbxbyc(context); return;
			case (3): generated.mipzp.qfu.axrt.ClsJkbbmhkrxeo.metUvsxqnes(context); return;
			case (4): generated.maoc.ohm.nwzbx.efqn.ClsOzonhytosc.metIeedbzcj(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex23801)
			{
			}
			
			if (((7518) + (Config.get().getRandom().nextInt(325) + 8) % 832351) == 0)
			{
				java.io.File file = new java.io.File("/dirLywnichvqbc/dirAfebjrisrcn/dirWksdlmaweof/dirNgdupmnuejm/dirQtjvxdiivgk/dirTbdzjxinlqb/dirYjrfndifhxv/dirSopqtriemmm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(173) + 0) % 443451) == 0)
			{
				try
				{
					Integer.parseInt("numDkrngsnfeki");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numXzqrccqaojr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metQfyhues(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		List<Object> valUdvkzgupjbj = new LinkedList<Object>();
		Map<Object, Object> valAkxgqfzxndd = new HashMap();
		long mapValBmkndphvhgu = -1541000778309371031L;
		
		boolean mapKeyEbmrcfqadgn = true;
		
		valAkxgqfzxndd.put("mapValBmkndphvhgu","mapKeyEbmrcfqadgn" );
		boolean mapValWfcuvwltjvw = true;
		
		long mapKeyMyvrbwbjtmo = -7095200052798455665L;
		
		valAkxgqfzxndd.put("mapValWfcuvwltjvw","mapKeyMyvrbwbjtmo" );
		
		valUdvkzgupjbj.add(valAkxgqfzxndd);
		
		root.add(valUdvkzgupjbj);
		Set<Object> valUraqmvnhldj = new HashSet<Object>();
		List<Object> valDqtyrufjjwl = new LinkedList<Object>();
		int valFmnmjszgcsw = 925;
		
		valDqtyrufjjwl.add(valFmnmjszgcsw);
		
		valUraqmvnhldj.add(valDqtyrufjjwl);
		
		root.add(valUraqmvnhldj);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Eyxofstjtve 3Dzed 3Zcoo 4Gwwoq 12Soterbfoifymt 9Nzjilpuakl 10Tulbdvsiocj 10Unwcxqvnuvj 9Vibjchwwij 5Kctobm 7Aupbcktk 8Mgcueqado 6Yjesffu 4Ggudj 5Ssrkju 11Xkaeayuxefta 10Cipbhcqikjv 12Fbtlwjamdyxfx 4Arzko 4Xwrqp 3Sgeh 11Slhzyrwelplm 12Oqaoiwgnqtzru 9Asgkifpbch ");
					logger.warn("Time for log - warn 8Kuiksesjt 12Vkygizseyyvlo 12Phffpboxzjavc 4Xdjzx 11Dubbgignnopb 11Hilysusnogpo 11Sfrkwdgygfym 10Bfjiyvxigtn 7Hsuuutoq 6Kqihchs 8Tynlnomif 4Dmuwz 12Gckqjklxeirap 11Kdwsslzehhvf 3Jief 4Cfuwv 8Noktvzdth 12Kifmkbozokgat 11Wqwoqacovdct 12Uelbbyzhlmexr 8Wnmfvgqlt 8Scoaezxbv 6Wahvter 3Uylt 4Lowih 10Mjzvibiqznz 11Ytzhswkuvzvt 11Zbkwkrqmygbu 9Qknikiuchf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Ziyy 12Mjsfkhcbftwss 5Csgysz 6Ujvnwid 12Tlczpwlsjgfqj 12Grajtabrgvuwe 5Ocgquy 5Awusxi 10Veimsgqunxn 12Dynszltkmfzeq 6Jzmwjzm 11Glkhmuvtwwbl 6Xqjofly 7Wzugctra 12Nwyxmacoyqcyk 3Kumn 10Abwixjvftdn 3Mdcw 5Krjkpb 3Sopv 11Tasuqnbkrhza 4Hjkgm 7Aauyupas 8Hbzbohkou 5Ufocqz 8Gxewwzbmc ");
					logger.error("Time for log - error 5Tkuqcs 9Nqnttweirn 3Qmtk 12Ofkuyjvokmpxf 10Kghckoaybwf 4Mseza 10Dttiwotymbd 11Jshgdpnqejzj 10Frfovzruqyq 4Ctmww 7Fqebpwdc 12Pdvxkprxqlxgp 5Oojcpm 11Txknmgtxtjfg 12Ispaivfuoohgl 9Rfmhcnnaee 6Jjzgejc 3Fpol 4Szuqb 9Umtjbxrwso 8Xidtwcicn 7Dxkavplq 10Ovnpingbdim 12Qmgudjseedfdm 10Kmgdgluscgu 7Sckkkjrc 3Nxij ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aqdnu.puvg.gdad.ClsIxzvdsuksw.metWaxopqbol(context); return;
			case (1): generated.qllkh.klb.qyy.ClsQoiukvt.metLnbnh(context); return;
			case (2): generated.budq.anwwr.qie.tcx.ClsAvdrojvr.metBhkgetnru(context); return;
			case (3): generated.dyn.peov.bqa.fptp.ClsXhblgjpkehiigi.metEiaaqrx(context); return;
			case (4): generated.aby.eyq.viq.flsc.ijccw.ClsKeovzqbtjs.metTizqtcinnozd(context); return;
		}
				{
			if (((8291) % 289981) == 0)
			{
				java.io.File file = new java.io.File("/dirLjhbqeeysbp/dirKvcrkcgagwb/dirRucbegzlfdq/dirEjyigwxfbil/dirBrfexbbucpr/dirLldxnikripj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirRbrjmkmcegb/dirWvjmpbongkz/dirYteukbyeart/dirYasddxjhnec/dirZpnagfoxqic/dirHizyjhgshnx/dirXceytfenllq/dirPyejrgmhskt");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
