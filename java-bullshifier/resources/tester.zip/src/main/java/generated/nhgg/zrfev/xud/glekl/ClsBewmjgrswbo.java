package generated.nhgg.zrfev.xud.glekl;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBewmjgrswbo
{
	 public static final int classId = 242;
	 static final Logger logger = LoggerFactory.getLogger(ClsBewmjgrswbo.class);

	public static void metWsxyvoaooe(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valFbdesmcoofn = new HashMap();
		Map<Object, Object> mapValAcqksryeurn = new HashMap();
		String mapValQbcdharjyek = "StrXfmlyarlqwt";
		
		long mapKeyHzdttazwppq = 3292542570750161456L;
		
		mapValAcqksryeurn.put("mapValQbcdharjyek","mapKeyHzdttazwppq" );
		
		List<Object> mapKeyEgdsqdjzmom = new LinkedList<Object>();
		int valAtrwwrtxhlc = 863;
		
		mapKeyEgdsqdjzmom.add(valAtrwwrtxhlc);
		int valFrmxsgnamax = 845;
		
		mapKeyEgdsqdjzmom.add(valFrmxsgnamax);
		
		valFbdesmcoofn.put("mapValAcqksryeurn","mapKeyEgdsqdjzmom" );
		Map<Object, Object> mapValNycmmoqjvtc = new HashMap();
		boolean mapValSaazcaxacvk = true;
		
		boolean mapKeyUvmticpaprz = true;
		
		mapValNycmmoqjvtc.put("mapValSaazcaxacvk","mapKeyUvmticpaprz" );
		String mapValXbhbxwkfdne = "StrZsozubadbzz";
		
		String mapKeyKcvgvzfpubz = "StrFuvvbsnbhio";
		
		mapValNycmmoqjvtc.put("mapValXbhbxwkfdne","mapKeyKcvgvzfpubz" );
		
		Set<Object> mapKeyImynmosnlhr = new HashSet<Object>();
		boolean valHtiejcuolnr = false;
		
		mapKeyImynmosnlhr.add(valHtiejcuolnr);
		
		valFbdesmcoofn.put("mapValNycmmoqjvtc","mapKeyImynmosnlhr" );
		
		root.add(valFbdesmcoofn);
		Object[] valZexarregpik = new Object[7];
		Object[] valNwfigexjygl = new Object[6];
		String valJdzudnerudq = "StrGphqejsmmnw";
		
		    valNwfigexjygl[0] = valJdzudnerudq;
		for (int i = 1; i < 6; i++)
		{
		    valNwfigexjygl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valZexarregpik[0] = valNwfigexjygl;
		for (int i = 1; i < 7; i++)
		{
		    valZexarregpik[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valZexarregpik);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Rwygobhucmdpk 12Hcdyrmxsovrze 12Vqhohilvoegxb 9Nimhnnzdzh 8Upvvaenkk 5Otbais ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Wucyxpjetxc 3Razx 9Pdhzyvgqqx 8Xddnggerw 3Ctls 6Wxholoi 10Wdfngbgtpmr 11Qqinyowhenrl 12Vrmnymfgpitvb 6Gpftjeb 8Lhyslwbgg 7Gcqpwfdt 12Lxlbeohmqnuqw 9Kbaiozcyzz 6Bpxqjpn 12Tadwrzsqeqain 7Itfqfvps 11Klhwxhcmllmq 5Lqvupk 7Gcgrincd 7Whhhdiov 9Wqdmafbndr 5Bqmhbi 11Xrlfnteenvfe 5Chzqcu 8Ydozzfkxk 11Ezccgfvydygo 12Ahvfgzozwakpj 12Mmsujupnvqlvx 12Crcsxskyrinso 7Jvbbslri ");
					logger.warn("Time for log - warn 5Qalawq 9Vxjcmvwkgb 7Vqetocvw 3Whyi 11Pwlmukehaynj 6Tbxwvfn 4Olmhj 4Czzri 5Ozhjkc 5Ktsrhi 10Jntfklziths 9Xxdugrrqiq 5Aezxqr ");
					logger.warn("Time for log - warn 10Wzgnyfadlzi 10Txscusmweub 5Xngwbl 8Dapsvdpot 10Pfoexggbstz 12Fbvkwvcquitkx 12Eemcxblcteqwe 4Uvlsz 6Mfqjkjj 10Yqybbomajnr 12Txcmkcyfgmvjy 5Ssmynv 4Wxvar 10Tnqzkeftekt 8Oiquiecfn 3Kngo 10Epvimekogjv 3Qsxe 6Pgzpluv 8Pgsuibnei 8Ecvizqcpo 9Ccztjwnaus 11Jppicobyrnnl ");
					logger.warn("Time for log - warn 6Kqumiga 10Gnsfqqlcvim 12Dabotjhxgfaan 9Jtjpvekmdm 12Rjcwgxnionekc 8Kqqgwwcgh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Jofl 4Uapiw 5Gffhuv 3Fbxg 3Jsnc 3Lcmt 6Bghnlwt 8Ywmhzhvvd 7Gozbdjnr 11Vyudffihclhm 4Yyuhl 9Ncntruhrbt 9Qsodfunuqn 3Xrns 10Pdjqscosnzn 8Vrmaspvty 11Pgmzsygfupcl 9Noxymrlaep 10Vwyhnjdzifj 9Xhhmunjczz 8Qslvxapoc 9Vpegfsdobo 12Pnsenrjjjzlqe 6Wucmbnb 10Mbmuzgxsdik 12Yubbdirysneyr 10Iomclawzbwg 5Kbhptg 11Uutqmbxhbbwb 9Hadzgqbdkm 8Dlayzwdts ");
					logger.error("Time for log - error 10Sxzgpzhrbed 6Dhrqbht 6Zuowhjv 8Hdspgephu 5Edntlo 9Egybweehjr 11Aopyuowavngk 11Hnipfoafzqqu 5Oifxkn 7Lxkvdcln 12Izzgzlptpfaet 12Lxiidynnjegzo 5Sfphec 7Hhzobvrd 12Abgpbvicjdsxc 6Kkgnehk 8Xdlvtazup 4Jddqy 12Rqxiqcwopxdwa 5Nlqkog 3Rcid 9Tiajgryyph ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bhfun.zpnwj.czfe.augg.ClsEdcxpvndelttu.metSjwyu(context); return;
			case (1): generated.hfhsc.dtsm.exj.akcxm.ClsEggbq.metGkdrqysenzt(context); return;
			case (2): generated.ufqu.ddqdj.nsc.ClsAchghkwny.metKntxpyoov(context); return;
			case (3): generated.exhp.ngeqz.saycv.ClsTbfjaj.metZrbit(context); return;
			case (4): generated.vvl.eygsr.pmv.fzat.xuhvb.ClsRspudgdgeelrz.metSbvadqifcqj(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirFglosohsjqc/dirYtzepfhqbtr/dirYpymfyfvvwo/dirKhequienylw/dirRgpfydlykrj/dirZunuwoqozaz/dirYwqgzplwgso/dirTcqedymkqwv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirXwuhnxpagur/dirLzgzwhzzous");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex24272)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numOzschqyabrn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
