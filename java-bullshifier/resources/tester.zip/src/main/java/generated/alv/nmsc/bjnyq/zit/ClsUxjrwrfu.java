package generated.alv.nmsc.bjnyq.zit;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsUxjrwrfu
{
	 public static final int classId = 349;
	 static final Logger logger = LoggerFactory.getLogger(ClsUxjrwrfu.class);

	public static void metWcnramwnolmtp(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[4];
		Map<Object, Object> valOgbhjhhzsjg = new HashMap();
		Object[] mapValDpmwzzwtayk = new Object[9];
		String valFgopmelbeuc = "StrJhuafxqmkgj";
		
		    mapValDpmwzzwtayk[0] = valFgopmelbeuc;
		for (int i = 1; i < 9; i++)
		{
		    mapValDpmwzzwtayk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyBtsjwlwgvxp = new HashMap();
		String mapValBjmmnqtbysx = "StrRqkojfwwgwa";
		
		boolean mapKeyFqegshvyllg = false;
		
		mapKeyBtsjwlwgvxp.put("mapValBjmmnqtbysx","mapKeyFqegshvyllg" );
		boolean mapValBelchraztnu = false;
		
		boolean mapKeyLetxaukmerw = true;
		
		mapKeyBtsjwlwgvxp.put("mapValBelchraztnu","mapKeyLetxaukmerw" );
		
		valOgbhjhhzsjg.put("mapValDpmwzzwtayk","mapKeyBtsjwlwgvxp" );
		
		    root[0] = valOgbhjhhzsjg;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Kcwjmehtnjax 6Ezlvbij 6Brhfgfe 8Nhxgfniya 7Dbirrgra 9Lnfaofvpzo 7Wdbghhto 10Tcrkncpnqjd 6Ptrtlrf 8Vwzcgvork 5Cbdlwe 7Dwxulyoc 10Vkzzgbmstam 8Dhcuinqkr 4Gnsua 4Sealo 8Cqknpntng 6Flurgds 8Jmbuvywto 3Sxiv 7Trhnhydf 9Tkbgytddnw ");
					logger.info("Time for log - info 9Rezbijlbxf 12Ljvbzldgwdtcm 12Zpsevjkykffng 5Stpdzw 8Nhbumaofz 4Xkuut 11Gnngaagkafgk 10Nqemeryhzqf ");
					logger.info("Time for log - info 5Qrjdul 4Masdm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Peuxkrqwpcwag 10Ztxdktctmee 9Fwnkevkfyu 11Mqkdiqhmpqwd 6Mcufhjw ");
					logger.warn("Time for log - warn 3Miqx 11Dwgydjhcpaye 3Hvgx 11Sskdrwsscyxw 11Pzntdflzewgh 12Tzspgoynucxuo 11Bcslzzxhwumk 3Ragg 5Rvvshw 8Jfsvwxvmr 10Jularikijjw 10Xyltdvggvpu 6Mhkotmn 5Ilpebu 9Hulgqkoygj 7Kquvlizl ");
					logger.warn("Time for log - warn 6Ifsjsqp 12Nbrpotxxjkgos 9Pfsqqzfpzg 7Npafpbwt 5Wpqwtk 3Gupc 8Nycyfwrfc 11Eyuaxuodcuqh 4Jknhc 11Ukmrmyhjmzlv 10Tawffrlrxqi 4Zpysd 5Othpsw 6Shaedvq 8Gbnuksocl 7Djoirdpk 4Rwqsj 6Zxlekcm 6Nrmiqgp 5Cahpwt 8Uqoithplv 8Jnyqfmihd 12Yudqnpyzobpqe 6Aoshswf ");
					logger.warn("Time for log - warn 3Zzec 5Fopjcj 5Vapgtx 10Kxlgrhbpysi 4Svesr 7Jrjyhkkg 12Uqqmxeamwuiay 5Hhvfqf 8Ctlhojgzl 12Reqzdvnfwhphs 3Hjlc 12Efjjejdbegcbi 5Viscrt 8Fwdcpyspi 9Pxhltynued 7Kjyfxknw 8Mmgxigngn 3Axen 7Mbcqebxh 7Kzwzzupa ");
					logger.warn("Time for log - warn 12Wstdhrtfudiwa 12Hmhmgmcypsiev 9Hrlkviamar 7Scsnisci 10Ncpjdcfseas 5Unrtjo 12Kljqtlhrpjdij 9Hqtxpysloa 10Dvqyvetzmsz 3Lksw 4Lhmkj 9Pwlnsxbbun 10Lhnuweunkfp 11Vsssefnjtcuz 12Enuoqhxzhvtep 7Mrehcvcl 5Cokfbr 12Elamppysixcgh 6Xiinwhd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Ypdlssr 7Ifiqhpeh 7Mukfxzwu 4Inpli 8Oggdsurqc 6Jawwfmd 6Prkxnmi 6Fqmruhb 10Qutawzzwzgd 11Okjbnkyuxpkg 5Qlsswt 6Glxoujy 4Fitxy 5Kryidz 9Ykzxtaizsh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bolg.tnlb.nmug.ClsHstaiufsowx.metPapexcx(context); return;
			case (1): generated.loe.helvz.umzz.ClsSvkkzn.metHjtxfwvar(context); return;
			case (2): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metLlvwdlebp(context); return;
			case (3): generated.ado.osup.ClsKlojrrjbtxsxbb.metZllxvjzonxeodp(context); return;
			case (4): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex25903)
			{
			}
			
		}
	}


	public static void metWaekhxtfetlab(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valGpxlxyvhbgq = new LinkedList<Object>();
		List<Object> valBgbiciwtqcg = new LinkedList<Object>();
		String valQwgukqudbkl = "StrMrkxxywouzl";
		
		valBgbiciwtqcg.add(valQwgukqudbkl);
		
		valGpxlxyvhbgq.add(valBgbiciwtqcg);
		
		root.add(valGpxlxyvhbgq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Seebnossllh 9Wzdzdrdykn 7Eumxsmlc 11Namcslozlxpg 4Fmkmg 12Edksfimqyplfq 4Ahmov 6Amslxms 11Vxffoieuwpli 8Tbndtilto 5Emzlzl 6Ivzpnxp 4Bxxuw 10Vaqxjdoetoc 6Eazsqum 5Thdrnr 10Ahefbpewjza ");
					logger.info("Time for log - info 10Gjtaioblpom 7Ydsanuia 11Bshrzgubmkii 4Jaecw 12Jmzuqtenycgas 11Ppwppqbsmkss 5Pfawcn 3Qjiw 5Wobgdu 6Wctfvfl 8Ghdujotvu 3Bmxy 12Rxwhvbnoetrss ");
					logger.info("Time for log - info 6Yvqexdt 10Gyylascvjcn 8Jqmbummsm 8Kpwsmhlro 7Ccggkehf 12Vvxfwhhxntrrc 3Cydr 5Mhmebc 7Vgctotdp 3Smsa 7Lxbqryra 10Pdtaebfqrqm ");
					logger.info("Time for log - info 9Vadxqjqdjp 9Vwvabritsm 8Lmvhmkehg 11Ahswgpmljnpj 4Hbvlo 6Iukrryv 12Wvawvxvplaxov 4Wgram 7Jnndnzgy 9Nwkrzymljc 7Izwzkegp 3Uonh 7Jmtklzxw 5Odfgpt 7Bfvmegqx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Ucqvj 8Rvqngimnm 6Fxwdlej 8Pnrbkjdkb 10Rbjkvetdovo 11Kktotjaafxga 7Xxdcbewr 9Hvbraxhnmr 9Gpdazscyhp 3Mcwz 10Qqfrqbywlcl 8Fmqacgrmx 6Ecfnosf 5Sakfbr 5Vghrnr 12Dcuwvzerdxoxf ");
					logger.warn("Time for log - warn 12Oiasnsdwyswja 10Ksvrarddjao 8Tfjhjpcky 8Eynzskewh 4Xyuae 4Khbio 6Fppwdfz 8Crlolwpli 12Mofqfneoodgbh 12Mgwqeqwzqcutf 5Lxrqvm 10Tpnhvhuqfbz 8Bdvqynijl 8Bfwvwgqmf 6Vnyzylz 5Ooyteq 4Rjnci 11Obpsavhtcevj 6Fepuabg 4Wwdci 4Inzrl 10Vaxzgojwjte 8Ofrqbpdgk 11Syvstwyyphxh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Famqtgy 8Adzxfnpym 9Qacepmaatc 4Lmrpz 3Vpik 3Ewau 7Vscvtaff 4Wzudz 4Jvnzx 8Jhmjyivop 11Meqftfmkyajf 7Ycrlfkfr 11Wymsgukzlhgd 6Whaldfs 7Fulsfdmi 6Iutoihx 11Bcsaaiiklyej 3Tqcu 10Gwozvlonfrb 6Douvriy 3Zevl 6Xlvdsfa 6Cdpxczc 4Pyhio 3Xbhb ");
					logger.error("Time for log - error 12Lplrzxxbjjjnb 6Rxgrzym 9Cwjsvzgkxa 5Wjvwck 3Etlu 9Vmmvhkjzan 3Etgp 10Qbajacmsfsr 9Wlsmjasety 3Gvfu 6Yvstqky 10Xltouduqgzd 10Yyhcfbikilm 8Lrdrhmgqx 3Qbaq 9Wdfviqyvjy 8Kvivyhowc 5Ctrycy 5Tlrmmn 12Bzkurlqkoxgng 3Fdfb 3Xgha 7Qbuymbkq 3Uwej 4Bpnjj 6Amqrvis 4Ayxrg 9Buazwovsxv 3Vloa 8Zznntsphf ");
					logger.error("Time for log - error 11Pgohzknlzgys 8Ztfkstrkq 12Qmlfdiinarths 10Gnpbdnpjsqm 10Kujryopkkxl 7Ocozbmim ");
					logger.error("Time for log - error 12Lcdgealukdkzn 10Bwfkjwtdqsq 12Zksvyzmmbrrrc 8Spjzhdtyk 4Htofe 7Jcxsvsrb 7Djmpomea 12Cbxqmftffollm 7Unztkpvw 9Ibqpdffofe 10Iyepkfejroz 4Uqxcq 7Hzeanveu 12Wafdxhnrkobnn 7Qlcmahot 7Aktmpxtf 3Dkhy ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qwlax.zei.ClsAdxloruwrrth.metLkyzseqhzcwrch(context); return;
			case (1): generated.qspb.cjle.nfu.jdnb.hwx.ClsNgqnidoia.metMghoopxp(context); return;
			case (2): generated.uym.yiu.voiig.deif.ClsUwvuontynja.metDshagtzyscmkfi(context); return;
			case (3): generated.gjcdq.ygxj.ClsOmksrfdawprnyq.metZqyxbwsgrjo(context); return;
			case (4): generated.wvctc.whp.ftjy.ClsPwdcftvpjt.metRruqnnklvvnmp(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numOrghtsscpwd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex25907)
			{
			}
			
		}
	}


	public static void metNwxqnbhnue(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[8];
		Object[] valNdzajaoqxar = new Object[4];
		List<Object> valXiiougyrjll = new LinkedList<Object>();
		long valHrdcbuxjkze = -8929706260988814304L;
		
		valXiiougyrjll.add(valHrdcbuxjkze);
		String valWjotmrxynov = "StrClyiwbscsrb";
		
		valXiiougyrjll.add(valWjotmrxynov);
		
		    valNdzajaoqxar[0] = valXiiougyrjll;
		for (int i = 1; i < 4; i++)
		{
		    valNdzajaoqxar[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valNdzajaoqxar;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Jfjjqclzs 8Vaurxdtxw 3Cvqh 8Rdeffmqnu 4Qvmwy 4Knfiu 10Rttmjcvzcpk 5Cfffvu 3Iemg 12Iruzwbogsvpwy 8Elaikczjl 12Xttfsjmhrwnku 9Izaxfezqaa 3Utlf 10Fnxwzaqpfba 10Jwrixvoqbrz 6Kazsjth 3Rpwh 6Dhplble ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Yblui 12Flhweevazbplb 5Dykvoj 6Nnqpein 3Fjyn 3Bsgx 6Fbolkjv 3Txag 6Iolihkr 4Tkwdj 9Yimipljdsc 10Exnwezpyfus 9Gnkdqthtvn 3Sexb 7Lpbesjrl 11Xzmfwistkkgf 4Yjdxl 7Fztcqatc 6Hhgmtdn 10Gfxvblnekld 8Pyzaztqyx 9Cbkpksqkgx ");
					logger.warn("Time for log - warn 12Tphlbqjvddupd 5Lqiqky 11Jpyfcgsofxoo 6Gevorqy 4Bbecm 3Mvrj 5Ftehtn 9Sydmtkasex 4Jhugg 10Jpojyyrozeh 6Dalwkvz 6Djsvfxu 9Nykttnbnoa 8Etwcrkari 7Urnrxutq 12Eyobaqvahjkyu 11Ahpemkajdexi 10Akqxqxnviox 11Izqwtbsacznw 7Pufxeuty 12Ybwkwrynugbve 5Tvefxo 7Htcpahex 9Lxcmbjtzdg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Khsru 3Vqon 7Owrxcxlf 4Lmars 8Oajwvehmy 11Ruiyyqrfiwaz 4Axjzm 8Caekoviim 11Chzploybbjyh 6Hbplygh 7Eyfzjgzb 10Oyxgxebstsn 12Pdpazydoehqdr 4Ccysv 7Msxuxaba 8Jxghcdcpb 6Uisxjbx 9Kzjffbjxzg 6Jkqtrsh 9Talniydmlp 7Iphluaob 10Cqkenwsalpg 4Baftm 8Agkosatoa 3Equz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zhzbs.ylhl.ytr.cges.stvq.ClsYeenuinrut.metRuxodvwf(context); return;
			case (1): generated.vyk.nsacl.bsfy.saukt.ClsKpfdsyokiohmf.metOfxfjxkcir(context); return;
			case (2): generated.ocmm.ezbtm.vxyei.kuseg.ClsUqzgoaq.metIufhbdjk(context); return;
			case (3): generated.fxa.nzjpw.lkh.sxue.ClsXtfkzq.metKgwcxlgfzbemhw(context); return;
			case (4): generated.yckj.gphin.bfwh.sqsp.yue.ClsOefoqvazjwfl.metFjgyzxmr(context); return;
		}
				{
			long varBowidqumrqb = (Config.get().getRandom().nextInt(519) + 7);
			int loopIndex25910 = 0;
			for (loopIndex25910 = 0; loopIndex25910 < 8387; loopIndex25910++)
			{
				java.io.File file = new java.io.File("/dirQcfdhwgalnw/dirWxjajrzxnvi/dirBqiogtpsfzk/dirFkedppmsvjz/dirSetxmkpmkwf/dirWyxbcddsldw/dirSlnlhwqgpcx/dirCfnmduxjpff/dirBqqdpfvgisx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex25911 = 0;
			for (loopIndex25911 = 0; loopIndex25911 < 3864; loopIndex25911++)
			{
				try
				{
					Integer.parseInt("numQotnslsyddf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
