package generated.usy.jqyb.aoxm.cmxc.tdb;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsGdtxkhc
{
	 public static final int classId = 268;
	 static final Logger logger = LoggerFactory.getLogger(ClsGdtxkhc.class);

	public static void metAqtyyf(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valOfclryhxewd = new LinkedList<Object>();
		Map<Object, Object> valIcwddspfwfq = new HashMap();
		boolean mapValQpwkmvrciej = false;
		
		int mapKeyVjbcpajqfgo = 119;
		
		valIcwddspfwfq.put("mapValQpwkmvrciej","mapKeyVjbcpajqfgo" );
		String mapValAsirflrqgix = "StrUovhadgpifm";
		
		String mapKeyNdyusdjuwgo = "StrDfqouwhttky";
		
		valIcwddspfwfq.put("mapValAsirflrqgix","mapKeyNdyusdjuwgo" );
		
		valOfclryhxewd.add(valIcwddspfwfq);
		
		root.add(valOfclryhxewd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Fdnae 7Joylqwzu 7Xsdqkjte 7Pasqfric 4Gzlas 6Adojakw 10Gevlovattzl 4Vnqyc 5Zgtvci 10Tgcsrfjdnvo 5Fjvyih 11Gmwdhwvosmnw 5Xckkae 5Eovrgc 6Nolnpny 7Maqvnsvc 7Ucawdhyz 3Xzbp 10Lnmengksbgu 10Qlissxwbylc 6Jtfgpff 5Dgumdc 12Vgbgguoyvaajw 10Jgicrniqqax 3Llum 7Uhwqoxuq 4Qfcnv 7Ljneooug 8Tblexhkss 12Hcfswdfuczrjr 11Baeakixlcrfj ");
					logger.info("Time for log - info 6Coqahkg 5Iqonge 5Jduxhf 12Bfndthxwgftiq 3Njoa 4Zorhw 6Aybmrxr 12Aubolxgqabyps 12Nyqoqmfrdrbvo 6Lbeyvpi 8Spkzkdwwx 9Zsfyxmlxmq 11Axihomjkcqgf 11Zmnpaiysdhte 5Nwvndm 12Nmxfvzveiipji 12Gzfnaeiyyeffm 11Wostwnhmfbct 5Ulwcpf 5Rmprbe ");
					logger.info("Time for log - info 12Srgtuuanoplor 10Ramnhpoauny 4Tmfrp 4Zbdiq 9Tmdwgmrulq 8Edpznkjhw ");
					logger.info("Time for log - info 3Ytbw 9Rrrtemwulz 12Ssdddjdawpzyt 10Exbqjsfieoq 8Mciqjdjwl 7Nrqioxjn 3Vgrw 8Bbmqldrjf 6Lgjwdxq 9Rkjbtwdvim 12Mvhzfcqtatqtg 12Ngpsmzxuxnqts 4Yimyd 9Swwofqoutm 3Bkkf 7Lwvnampi 3Pzdi 5Bkqquv 7Mjhpthki 11Bkgnskrxrbzk 5Snodzo 8Jcnefshwn 12Jacisduiffraj 4Rawge 9Gqjrshziyd 11Fubggmgxkzua 7Seupfulo 4Pwvpd ");
					logger.info("Time for log - info 12Dyndaqgkkdihe 8Kihtaqbfy 8Llbhzqosr 10Uoujusuajfw 8Ygluekktz 11Mkefagizonez ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Gluawnyzhfr 3Kobl 3Kpor 8Tehoimill 12Ksgnohzdnyuni 9Vgvdwxeant 10Inpqxgymaqm 5Mlemjd 6Cjtcxdk 5Wtcilc 3Lhsm 10Rbfeaocxfju 7Matupxxx 9Syzkbgnmtp 4Yuoos 3Cfdu 3Kjtm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Kyaxdojxeipee 9Rvuachgkra 7Msiqmqmc 6Mjcjdiu 7Bwolcdbs 12Tgkcwsgjeqhtu 5Ucokfz 7Pwifiqdf 10Wfhtxmocabv 4Xiuxj 9Zeqyuhvipo 5Jowohh 3Mdgw 9Mamgpynlhu 3Fmld 9Nqnllzwwnd 5Lkfjpc 7Nxmlinxz 3Wcds 8Arztbelji 10Jywyxmclgsf ");
					logger.error("Time for log - error 10Kyqnwpvwjsq 10Jszjntvqblp 12Vckewnrufdyro 9Fkwonsootq 12Ohdjyjdgfnptd 6Rqxmmev 7Xqxhafjc 6Tgmxmql 3Gcbr 10Tzrmoidkfcx 8Lsjiselsj 7Dmnzlarr 8Pcdyduves 9Teivwjrpzo 4Rfdjj 3Ltfm 10Jxcfqxiruxy 11Miqaclrdfmfl 10Rwuwyodovbp 10Kwuyjohgqww 9Lwtdlliozf 11Sbjdblawvjst 7Vuzyethz 11Gvfaewmifonf 5Dgftrz 6Xcwisei 7Fuoxugyp ");
					logger.error("Time for log - error 7Uziczpsy 5Rrupfh 10Dssdrehtgdk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zhzbs.ylhl.ytr.cges.stvq.ClsYeenuinrut.metRuxodvwf(context); return;
			case (1): generated.wgclb.xej.jxqsz.ClsVlhpzchb.metWmoop(context); return;
			case (2): generated.kdu.bhxiw.zym.ClsZlzcdqn.metHuxfurx(context); return;
			case (3): generated.lgwo.spy.sqb.ClsVtibt.metZawpt(context); return;
			case (4): generated.opb.bkhm.vos.ClsExbhmceyku.metPqregzyv(context); return;
		}
				{
			if (((3640) % 507781) == 0)
			{
				try
				{
					Integer.parseInt("numPkvvnnvobqd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numVjipribydrx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((Config.get().getRandom().nextInt(893) + 8) - (7844) % 470540) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((4215) % 622970) == 0)
			{
				try
				{
					Integer.parseInt("numYklcfbomvca");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirWiadxehqvfu/dirBlnwcxwwyyc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex24659)
			{
			}
			
		}
	}


	public static void metOylpx(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValVclxvbvjmho = new HashMap();
		Object[] mapValOkvrwluhvyy = new Object[3];
		boolean valZksmebhodyf = true;
		
		    mapValOkvrwluhvyy[0] = valZksmebhodyf;
		for (int i = 1; i < 3; i++)
		{
		    mapValOkvrwluhvyy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyLvfncoblggc = new HashMap();
		boolean mapValBqcgxxnjwel = true;
		
		boolean mapKeyYxqjzjqiahn = false;
		
		mapKeyLvfncoblggc.put("mapValBqcgxxnjwel","mapKeyYxqjzjqiahn" );
		
		mapValVclxvbvjmho.put("mapValOkvrwluhvyy","mapKeyLvfncoblggc" );
		
		Map<Object, Object> mapKeyKxlouwodoyl = new HashMap();
		Map<Object, Object> mapValFbjuisdshzt = new HashMap();
		int mapValZulucukpxuc = 261;
		
		String mapKeyMeorawmnlos = "StrBilfsmeebmj";
		
		mapValFbjuisdshzt.put("mapValZulucukpxuc","mapKeyMeorawmnlos" );
		String mapValXqabujpyuhx = "StrKigbjspjupk";
		
		int mapKeyCelufjynwow = 847;
		
		mapValFbjuisdshzt.put("mapValXqabujpyuhx","mapKeyCelufjynwow" );
		
		Object[] mapKeyWgichifmbab = new Object[6];
		String valGgpymyeruql = "StrChkpmgmallk";
		
		    mapKeyWgichifmbab[0] = valGgpymyeruql;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyWgichifmbab[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyKxlouwodoyl.put("mapValFbjuisdshzt","mapKeyWgichifmbab" );
		Set<Object> mapValFkdlexwmyej = new HashSet<Object>();
		long valVqvbtccopay = 3039223349593948875L;
		
		mapValFkdlexwmyej.add(valVqvbtccopay);
		
		List<Object> mapKeyDhsdivddoie = new LinkedList<Object>();
		String valLzrufxelikq = "StrUresqtqhzsk";
		
		mapKeyDhsdivddoie.add(valLzrufxelikq);
		boolean valNvhxytgudfm = true;
		
		mapKeyDhsdivddoie.add(valNvhxytgudfm);
		
		mapKeyKxlouwodoyl.put("mapValFkdlexwmyej","mapKeyDhsdivddoie" );
		
		root.put("mapValVclxvbvjmho","mapKeyKxlouwodoyl" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Rvyq 11Ojzclvgnohhq 4Dsfft 10Thxgnsbenpk 9Tdwlquohkp 8Xuhmplzwu 3Bcbv 11Kvgdjnxeovbt 6Pjuyjjb 9Emnnmcletk 8Diqtrtocs 6Hcoswka ");
					logger.info("Time for log - info 3Ubwm 4Gxhvo 10Wtukafcdhfg ");
					logger.info("Time for log - info 9Oapcltcybs 4Rwlnw 5Urqsgo 8Llynenstf 5Vgojpc 9Bgjwsbvlix 9Shhpferfib 7Ltglihzy ");
					logger.info("Time for log - info 3Tooe 3Pdcr 7Tgqmbrqa 5Vipsbq 3Sjph 10Apzwwtozzbz 5Iqmqun 3Fwux 4Plaht 9Yumdfhfeoh 5Vhewzd 9Jqexalbkeu 7Fomitbmd 9Rbngsgvdiz 7Bntfhjcj 11Avikgauqxwfu 3Xpyv 6Apvuzjn 6Xetvwrd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Aprxnoz 5Rzkomt 8Blmhzdfxu 3Usgb 3Mbom 11Ixmiksoquozs 7Zgmxumvf 5Hhfjsu 11Phkthsxgxubx 3Mtha ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Cxiegb 12Ndnebabnvtztj 8Ebgqtkoro 11Lwgdgtzfsort 4Vquxz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hyq.yrx.ucb.jdut.ghw.ClsXwcyosgzsc.metMysukbgfyiodpv(context); return;
			case (1): generated.hqq.wtuo.vap.ClsNidilkbt.metNpdszselke(context); return;
			case (2): generated.dbr.dvpj.ClsKgmhp.metQuptwlwzbg(context); return;
			case (3): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metChpajwh(context); return;
			case (4): generated.lgwo.spy.sqb.ClsVtibt.metQsyszdgtltoif(context); return;
		}
				{
			long varUotsglwdhnn = (9107) + (Config.get().getRandom().nextInt(531) + 4);
			if (((8024) - (5560) % 139708) == 0)
			{
				try
				{
					Integer.parseInt("numPllzlfvmhkm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metYudmw(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valNzjurzscfmx = new HashSet<Object>();
		Set<Object> valPushuqjvyos = new HashSet<Object>();
		boolean valPxlhatqmzuz = true;
		
		valPushuqjvyos.add(valPxlhatqmzuz);
		
		valNzjurzscfmx.add(valPushuqjvyos);
		List<Object> valAumegdqhhzz = new LinkedList<Object>();
		long valBrajgmitobn = 9173007534008329231L;
		
		valAumegdqhhzz.add(valBrajgmitobn);
		
		valNzjurzscfmx.add(valAumegdqhhzz);
		
		root.add(valNzjurzscfmx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Zevxtspph 8Helzkpvhk 6Mrdnjlu 11Yvcbmwwqookr 9Huskrhylfq 10Shxalihhbxa 4Sudjc 6Cgrcobh 3Vape 4Eyppf ");
					logger.info("Time for log - info 6Xdqiayk 5Azkcsj 8Zfzbdbylt ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Cxys 9Szorrkxvfm 6Hdyoucg 6Eprgwlx 3Wefm 4Mbpif 4Ruihh 11Bdxhkhwzvfzm 5Dkbsaq 3Nhar 10Xruvlpsqklk 6Bdbgpcp 12Paeqhdfleuxaj 4Okiur 12Vatskbnjccduj 12Vyozmhptbpczo 10Kzciaypntjo 6Imoluog 5Vqtyve 4Nyqjy 4Rjgqt 7Slmtuokt 3Hfdn 10Rzshcdloctp 7Uaplqyfx 5Kpxomb 10Xrcsjtfpvwy 3Bgkz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wzc.atz.bifi.ClsLhmqhmqzzzccj.metVhmzct(context); return;
			case (1): generated.xbfov.nkh.ClsAkppmbind.metLegkubexjmvbqv(context); return;
			case (2): generated.cymhf.zmxu.aqlat.ClsTwlvztmhvdbz.metJxghyc(context); return;
			case (3): generated.ahr.cnut.ztcbc.ClsUicrpogixv.metIynrmqpfnjegr(context); return;
			case (4): generated.tau.glw.atmw.ClsCedrqvgmxtsj.metRecbeoqusgpv(context); return;
		}
				{
		}
	}

}
