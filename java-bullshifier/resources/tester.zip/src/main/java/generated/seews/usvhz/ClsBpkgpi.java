package generated.seews.usvhz;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBpkgpi
{
	 public static final int classId = 362;
	 static final Logger logger = LoggerFactory.getLogger(ClsBpkgpi.class);

	public static void metSagewrwqtbzsvw(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valBfcpgprnbdb = new LinkedList<Object>();
		Map<Object, Object> valBmkgycugqai = new HashMap();
		boolean mapValMsyvelhaxcj = true;
		
		boolean mapKeyGrezbqchafi = false;
		
		valBmkgycugqai.put("mapValMsyvelhaxcj","mapKeyGrezbqchafi" );
		int mapValJwsgmytypjc = 164;
		
		String mapKeyXjnsocgwvqe = "StrEaqrnjsmmvl";
		
		valBmkgycugqai.put("mapValJwsgmytypjc","mapKeyXjnsocgwvqe" );
		
		valBfcpgprnbdb.add(valBmkgycugqai);
		Map<Object, Object> valAbanmpdharg = new HashMap();
		String mapValVsdmpronocr = "StrNmcrzdujyat";
		
		String mapKeyRgpdgrxqcph = "StrLthdqsiuwhh";
		
		valAbanmpdharg.put("mapValVsdmpronocr","mapKeyRgpdgrxqcph" );
		
		valBfcpgprnbdb.add(valAbanmpdharg);
		
		root.add(valBfcpgprnbdb);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Qkpdfoty 5Jqcwnl 3Skyy 9Cpnkcygxsi 8Kuftlcjyo 5Ftptfd 3Mtsh 11Obcbktvivkxo 7Bhkegsfe 8Yccfzcetu 6Csgustp 7Eckzjrcq 12Pfdsnmmuichqo 3Yoqa ");
					logger.info("Time for log - info 5Grtuel 11Jntcuveolrbc 10Ihuzofwrxpb 7Mjtsxiag 8Lgtlivmvx 9Dthfkgmoet 9Mqgqssbupk 11Ectiooonydne 7Kzubygau 3Ecjr 3Xuwv 12Tqxaxcsctxqcf 3Axdu 4Eanwc 7Fvkhgsks 9Eryixqsvwj 3Rbhi 9Nxypexxwqs 9Yirlgzagvs 8Jlgjsgtgq 7Ujuxeqxt 6Wvndakq ");
					logger.info("Time for log - info 12Sxjhlxdcpwjyq 6Zivtrkn 9Jpucmatvok 4Drurg 9Wrohmutopr 10Wmmvllazixg 6Melukfn 11Yxqtwgeoydpa 7Sqfodupw 6Daknfsk 5Jpyydn 11Fqwjehuzelnz 9Bmrppnpiqx 6Tpebbqd 5Nhbzvq 8Vkvzpvgvl 4Tycaq 12Whnahrdnqiccs 6Ofltpta 9Qtsvtkvneh ");
					logger.info("Time for log - info 10Myrllohfcio 4Zqzeg 12Ocmpsgjmnqbqe ");
					logger.info("Time for log - info 6Xinbolb 7Zkrokwsr 3Vwgw 11Putdxhzwjnoe 4Idixv 4Cxhmm 11Owhsstekwdyt 5Hulqlg 6Xemphdr 11Achrylhbhsuu 3Qoph 12Otrujuewxvggu 4Ecpzk 5Efhljy 4Ceaoj ");
					logger.info("Time for log - info 7Ytcerxkn 5Lyiodn 12Vdxzgbysbfcbz 4Tzcwh 11Nzbhkkcvppsf 4Odmia 12Luezeqbpayjrj 12Lutccncndhwhu 11Kzgividlxhqq 4Jkkyd 9Yfvevhfdpx 9Honxrkqpfu 11Wkccirxefzkn 3Lhsd 11Dlqmechviqyq ");
					logger.info("Time for log - info 11Sovavojiufob 9Vtncidowhp 10Oytebefmlfq 6Idfkqgh 6Ccsngkt 10Qzrxkntrgyt 8Tyfynmtnl 9Atapdtwgtn 8Uqnmwamws 10Dcpnqotigje 9Kzxeysdojs 10Sominqvteau 8Efwftxsuz 5Mvosds 4Meyou 6Adedsiu 10Mbudqlomnze 7Fnonotil 12Tbliaxnlrwkmn 3Ejhf 5Awbccj 9Tjqsacjged ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Dmerimalr 6Qzczeuz 3Lkwd 12Xuhxrvebsnazs 9Iarvlpdtrn 12Upbotvjchgmyt 8Omofexkqr 12Icaoayvbynhfs 8Qxwybwgpz 7Ozrarvac 6Qtmsqnp 10Qicrentjzof 4Xnmrk 12Odwsiaoygcclh 8Govchswvv 5Muedfu 3Wkhs 11Wppdxqrwwlmm 4Xmiqj 12Aloonmaydqial 8Ynbfwjkzk 11Fcdmporfklwj 9Zdlqcwyvnq 3Jsbd 8Pmczoitaq 4Davqi 11Sjcxzpzbjipa ");
					logger.warn("Time for log - warn 5Qdjxsk 4Uqlmx 9Ntheggvgng 9Vwajfgbter 7Jeeoyspa 5Iaryjt 4Wngiv 3Cgqw 4Isacq 5Ihfxdd 4Sbzrl 12Lhvinllcvjarr 11Wfmnhnvwvien 10Arozhkizvow 12Oounesuiutzec 12Yuoacwjnezzcq 4Gusrm 7Bhqcskus 9Lsinycgqhr 3Dkhx 5Wfbxcv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Exnr 12Lrzwdnxxxoxjg 7Wmxyeobx 8Mzcolbjdh 6Adscbdz 6Evaoejf 11Hjmlmhjtybxi 12Zrmoqzfabaklk 5Thhyez 11Pmwaxxwbmmaz 10Mrrgbslpmfc 3Mfpd 3Gemo 9Jmbvyvqjwz 8Akqhewrzv 4Lvhyw 7Rpkqilxv 6Myknqsg 12Mqvucqmfhlnar 9Aheyutfpkk 5Kwwgss 9Xwhosznryh 8Klrbsurks 7Wmkwakqi 8Leklwzpni 11Kprsfzeobmgn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.obwsb.fweao.vluj.ClsLnkmgpfh.metNbeuqlcmickmxa(context); return;
			case (1): generated.hjt.myuvv.hkc.tfpi.ClsJfukwmizredp.metYykvllrlskhqw(context); return;
			case (2): generated.fzrxl.bpx.ClsFendqr.metYsszpgrbh(context); return;
			case (3): generated.gmk.vzs.crbap.ClsEkyhsmjeh.metLuteowlbyyvlf(context); return;
			case (4): generated.mee.zfhy.ctgm.thcf.dyc.ClsWmiwkyi.metPalkfswklq(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(639) + 6) % 133478) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((8064) % 712742) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numQqcexnbbsik");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varDvfwosmhtie = (4421);
			long whileIndex26109 = 0;
			
			while (whileIndex26109-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metKhnlgsy(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valBlsmhefyrob = new HashMap();
		Object[] mapValYkuiwgcpxka = new Object[3];
		int valXamsrdunlmf = 921;
		
		    mapValYkuiwgcpxka[0] = valXamsrdunlmf;
		for (int i = 1; i < 3; i++)
		{
		    mapValYkuiwgcpxka[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyFmmzmuwhjmp = new HashSet<Object>();
		int valAwizkgcxuee = 696;
		
		mapKeyFmmzmuwhjmp.add(valAwizkgcxuee);
		
		valBlsmhefyrob.put("mapValYkuiwgcpxka","mapKeyFmmzmuwhjmp" );
		
		root.add(valBlsmhefyrob);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Oyjobz 5Vxljux 11Kcimrzakwfrh 6Awcnazj 9Nptiqltuuw 7Pepvcbtt 4Ucisd 3Yfjp 3Bmbk 9Depamxptaf 3Ldad ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Dmmozwe 10Qseukmafehr 9Bvidcqwmas 7Aehjziva 9Xpgwpwqkhm 3Vkbi 6Gkqzsuk 12Crbvgyfudwodb 9Oetdfimrrq 8Snypfhovv 11Eyvaqdvxthca ");
					logger.warn("Time for log - warn 8Ccodoviud 6Wbvmdnl 9Ugryrywzwa 5Dgnfmb 3Vizj 6Ullmctt 7Ytemoouo 3Sbak 7Jhmbxgjk 4Wmliu 3Djqh 9Znbppdsucs 11Tlqtzrpftztb 8Hoszlecnv 9Jlwyttkyun 4Wuauo 3Aqhs 12Pwuvbcmtnezsl 5Oabbyu 4Mrqww 10Waixijehitz ");
					logger.warn("Time for log - warn 4Qjssy 3Twjo 6Uhquudr 3Tzkt 11Kqumwyauutxp 12Frzkthtfivlvy 11Pyjuvgvnvolw 3Amec 10Qjhflsoiqyr 9Sjihzyfifk 3Wlqu 11Etrxovyysmmz 7Ikuhefgg 3Fygd 11Hxnopckcdxub 3Stmi 8Tvismtrwu 5Tkmwod 10Rvbkbznjvvt 12Wnubxyaxanbhv 4Muwne 8Mxfbbzxgb 12Pnthvbxdzluye 7Pccdvzio 3Tehw 12Eiuehlngkyfix 12Flklsffnpvryu 10Atjygadrfem 8Sruydbqzo 6Depficx 5Pwepem ");
					logger.warn("Time for log - warn 12Spyrkezmqrzri 11Jyvkzsfqtkvx 4Aqehj 11Bneiyggypfzt 11Xvkzdmsodgwb 3Nbeg 3Bqdi 5Juellp 5Vnevbj 3Smwb 11Siiylwgvzhqj 9Qydvvgldyr 3Moub 7Nalujfgz 9Yzvodppvpo 11Onuqozuzcfnj 5Aooeez 4Gkqvg 8Okuocdbcx 4Rsunw 7Hqpifldz 7Xykztlsi 3Aikq 8Ronrkdeqr 12Jkrfbjwqpajgn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Ilhf 6Wtajbis 6Uezhych 8Fjvuuyphv 7Tywcspfg 4Uikrr 8Odtrwxrsp 11Tkprjhfyyiud ");
					logger.error("Time for log - error 10Zchwbshrudo 9Djbdkthmjy 8Tbfxwoixi 9Dylfbujbmb 7Goseafcj 5Hjmraa 10Xqbjjosnxlq 4Wvjyc 5Qsfugq 5Zsxzxs 11Hjokcsipngiz 11Kmlxcadwqzml 6Sabrbfa 7Jeybtxrw 9Wglqcrkphu 8Sbaspeczw 6Ahvnpwq 9Buecduksas 9Praarygowc ");
					logger.error("Time for log - error 9Hkmmhczyee 12Kegzaunaxyuws 6Tlyyqjr 5Jwhbjh 9Azdsxgqxdm 7Kcvuskhs 8Cekgtuhjp 12Lybzmwfzaoopf 11Iwwqrunqczos 6Rcwdjph 10Sbsyrlgjgao 6Kzikmrf 10Rhabthjcinp 5Nkemko 7Gsbknfvu 9Jimhkkreme 12Rymzxgribrnqw 10Cijhozneofm 3Myru 7Cucsmwsi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aea.iom.ClsOvjtnlwnmq.metKwdullewrqcq(context); return;
			case (1): generated.qdml.hmlho.ClsQuiharvpvfv.metXrurj(context); return;
			case (2): generated.kqywo.pil.grw.dvt.ClsJduhsebfba.metHzxxu(context); return;
			case (3): generated.uzhb.dwl.ClsEamgh.metGdedianbrzaib(context); return;
			case (4): generated.lfb.pwad.aey.ClsGmnfes.metLhrypvccb(context); return;
		}
				{
			if (((8715) % 896683) == 0)
			{
				java.io.File file = new java.io.File("/dirMiyxqmwzood/dirKlagwtytvxp/dirByaopdbzmdz/dirSjwnmqkkqvd/dirEeaodhbzbxg/dirZlwfvzzpmae");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(19) + 9) * (Config.get().getRandom().nextInt(176) + 5) % 144669) == 0)
			{
				java.io.File file = new java.io.File("/dirGbtixfyakpn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
