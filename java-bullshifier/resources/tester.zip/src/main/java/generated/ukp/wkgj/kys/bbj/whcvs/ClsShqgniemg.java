package generated.ukp.wkgj.kys.bbj.whcvs;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsShqgniemg
{
	 public static final int classId = 403;
	 static final Logger logger = LoggerFactory.getLogger(ClsShqgniemg.class);

	public static void metCasobnicsjqw(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valSgepngbnafb = new HashSet<Object>();
		Set<Object> valRfwrgvsqzhl = new HashSet<Object>();
		long valMmbbplqenuk = 8031844939437560013L;
		
		valRfwrgvsqzhl.add(valMmbbplqenuk);
		
		valSgepngbnafb.add(valRfwrgvsqzhl);
		Set<Object> valQbbwbwcrtks = new HashSet<Object>();
		int valDsoxjqvcomn = 451;
		
		valQbbwbwcrtks.add(valDsoxjqvcomn);
		int valIcxvnhdudvw = 456;
		
		valQbbwbwcrtks.add(valIcxvnhdudvw);
		
		valSgepngbnafb.add(valQbbwbwcrtks);
		
		root.add(valSgepngbnafb);
		Set<Object> valNejwdfdvrsf = new HashSet<Object>();
		List<Object> valCrtnrsxlkxo = new LinkedList<Object>();
		long valBxrexzgrcgi = 1580334988172506336L;
		
		valCrtnrsxlkxo.add(valBxrexzgrcgi);
		
		valNejwdfdvrsf.add(valCrtnrsxlkxo);
		
		root.add(valNejwdfdvrsf);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Sipdqrcmdgz 10Zmalorscylz 4Noxti 10Zawltjsuher 10Yxdtmtloreo 10Osdbxpdxsyp 6Gsaohbg 3Lvlp 7Xsvgydeh 7Cgwaucil ");
					logger.info("Time for log - info 5Gshzxx 9Evwjczacrp 4Dcdrz 9Xtcvwxxivy 5Evpxxp 4Gowiw 9Eueetvagrb 3Vwpw 10Lkicoqbzzsr 8Qfnilwejk 12Hgrbpafycvmej 9Vddnbsuglq 6Fcjqmyq 10Svfyaabmgno 3Lglx 3Cuev 9Sbglzyolrm 6Diuhaik 10Bagnqhjztku ");
					logger.info("Time for log - info 11Lpopgfldacrf 7Ojobxwqi 5Wnrprf 10Hdyoysmtaeu 4Xgqkw 10Esgcezlwznk 9Zirmxtchsd 5Kdnisk 6Qzthgrr 10Hlyhvirrlil 5Lwyhlp 11Affpqgdwwvnt 8Cozrubjtk 11Ftultydnyanc 4Pmhki 9Fzoparjjym 10Nnlreyhsrgp 9Zbmdfswkii 8Fwpdyoiaa 7Higrshge 9Gizecywnvu 4Iendv 4Jayzt 3Lyyx ");
					logger.info("Time for log - info 10Smfefdnxdam 8Phwbcajba 3Ttld 8Tmhbinwkj 5Xvuoys 10Cvnsffquyww 5Bkwzhi ");
					logger.info("Time for log - info 11Smfxvuxstqrj 5Daseln ");
					logger.info("Time for log - info 7Rmdhorqa 9Ynfxqqgrmw 11Lxhrqzfxwvsn 8Hugigqopy 7Lidexcii 10Owyctoxipqd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Oqmpghmg 7Wepbhvln 8Ifefnplof 7Audmekds 9Xilunkxyac 11Ngirtllosbez 3Gide 9Mxowbfgaex 3Vhuh 12Xqpxgmpkesiei 8Uhemsawia 8Ecfviwifx 3Cply ");
					logger.warn("Time for log - warn 5Twxedn 4Hblui ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Fswenj 5Sslkjt 3Vesd 5Kqfnno 4Mbeld 6Itrydhm 4Anlad 3Vmgp 5Zmkfpt 10Vlwyuobxgcu 6Zgwqmap 11Bobxsketbkot 8Rdoxhwvir 10Upvrfpmorep 10Vgtjmdemnix 3Jemh 10Eztbmjxesbf 3Appj 10Adsadzavykg 3Ppou ");
					logger.error("Time for log - error 8Grmaovgwg 3Xvew 10Benxywprxtb 4Fpacr 5Nnfelx 5Uiisus 7Qabbkoom 7Pxkeqkeo 9Fimksttonm 12Wxsrikhlbsmgf 4Epgwl 12Gkdvyccxtnxyw 4Ixeal 4Jhmpo 12Niwukkumlaohu 4Vbnvj 9Zlvdqftuqx 5Hrjbuz 5Ksstjm 6Htvmliv 3Qbui 3Jlpv 3Otib 12Ipzyaosijyodx 6Wndjsit 3Cdca 3Zspp 5Rcladz 8Tmmxeojce 8Bobohqvvn 10Qdhphjdcheg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.idk.jvavb.vjuwp.iuzf.fawz.ClsRtwkffyfhbvpjl.metHdimsltzwuwz(context); return;
			case (1): generated.elv.qjwox.npj.oxv.jth.ClsNewmedi.metPuqgumqeuym(context); return;
			case (2): generated.oue.dqjq.ClsSjudu.metJnkbmwyuexlv(context); return;
			case (3): generated.mvrs.ywr.ahvi.avyw.whash.ClsQifjwldjrqu.metEqwmtkny(context); return;
			case (4): generated.lwjvh.jknhf.givvv.ClsBgfhlg.metVudhurmppkohax(context); return;
		}
				{
			int loopIndex26788 = 0;
			for (loopIndex26788 = 0; loopIndex26788 < 6783; loopIndex26788++)
			{
				java.io.File file = new java.io.File("/dirVmknbptvaaf/dirLffcgltrdto/dirDrlwiroylpn/dirXtrxzokujaj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metRrbombfiz(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[3];
		Set<Object> valVbnszunwkpb = new HashSet<Object>();
		Object[] valHtvamnipkvu = new Object[7];
		long valKfrwtoaufig = -3618795649617202509L;
		
		    valHtvamnipkvu[0] = valKfrwtoaufig;
		for (int i = 1; i < 7; i++)
		{
		    valHtvamnipkvu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valVbnszunwkpb.add(valHtvamnipkvu);
		List<Object> valYbwfmibuiss = new LinkedList<Object>();
		long valDdntjqkmlsu = -5670747125152282935L;
		
		valYbwfmibuiss.add(valDdntjqkmlsu);
		
		valVbnszunwkpb.add(valYbwfmibuiss);
		
		    root[0] = valVbnszunwkpb;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Hnhctnzv 9Pxrzilnrjn 9Mexdxudjva 4Ajkbs 6Uoqjdxr 4Ztzjo 9Fsgedfqwye 8Uoxybupkh 3Ydiv 9Glmylmtjtf 12Ljdnrbfxzxqnu 5Ttndxx 6Ooimcjk 10Iikvlqotxcs 11Pzqsvpvqzozf 3Ohti 7Ekxuvqmp 8Nepxjuyxs 7Fjefvlhn 12Fhnfdpzykxcfx 3Qqgi 3Qhdy 10Vbfgaduyzvr 9Whovdnroad 11Iidywertnrnj 10Nfaxvasisyh 11Tfxhbsjrlwsb 7Tthiozdr 3Typl 4Tddun ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Fvqkntvqv 5Zaxldk 9Npnoyeobti 12Xbvfutegtbzgn 7Aioxppkz 4Gkdgz 9Nmcinlecke 3Ycvc 9Cbxjtebqrl 4Dsvli 7Xinucksy 4Swgjc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Rrsfazliqfu 12Xescgerunhezf 9Cvvrqrufes 4Efcmx 6Dqsgsvx 11Hjkgpomtgbzo 8Djgyamsvn 6Kgjomhf ");
					logger.error("Time for log - error 7Pqardkss 12Upoamhizwmhxs 6Lblgwxl 12Ayqzwdbtgzglj 4Nvrhb 10Fxsshpqutgb 7Xmcuosnw 3Aolv 12Lfqmbuzcfdljr 8Mojpmrniu 7Sjvsxrpt 3Cshy 11Igpyiqpfsgec 3Awlh 11Vkkarghdsmda 7Egprdfxd 3Bwen 9Ehwdhqnqlz 10Ixhdwitbxum 11Ooujpqoclzaf 11Vhxgnknkkltg ");
					logger.error("Time for log - error 5Rvzqqz 5Cipqxv 3Wvly 8Bwvdrzebu 11Yemzomucvwmk 11Wkfkxghhkdbx 12Ncanohteurqpg 9Txstlermpr 12Egsyuasohezta 8Kbyimnpzh 10Qeokddxlvwg 5Emeupk 7Ojodzses 6Pjbbpyu 7Rrgtgfkm 3Kwkz 10Yqrhkvzklje 11Cmqzqdhskiqd 9Oijrtppufp 4Uxcqj 4Czohj 8Bksoutnfu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.uym.yiu.voiig.deif.ClsUwvuontynja.metIvjieifumyhc(context); return;
			case (1): generated.ulre.knov.ClsTukvjlscu.metSnzvazpuz(context); return;
			case (2): generated.fgkp.bvpjp.tisw.nifap.ygoni.ClsBmkimj.metEbkiw(context); return;
			case (3): generated.dbr.dvpj.ClsKgmhp.metCjgyiauuohs(context); return;
			case (4): generated.lhhp.jdgtq.lkhh.mkg.wzb.ClsZnuut.metLrcocicqjkqlv(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirCajrmfvvyls/dirCjmhatumgxo/dirUprejmfkumx/dirFjvcxkhooyt/dirKqezhowbzik/dirXkgfdbmqzna");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirXqqudwyqpli/dirOmlnxfvnyyt/dirJuyghnbixql/dirHshrufjbsrr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
