package generated.xam.emsw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsNwmpfankaxgqb
{
	 public static final int classId = 31;
	 static final Logger logger = LoggerFactory.getLogger(ClsNwmpfankaxgqb.class);

	public static void metYfqgrrxvvcg(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[5];
		Set<Object> valLxuunekhztb = new HashSet<Object>();
		Object[] valOzdmxadwkha = new Object[9];
		String valDzsyrchueim = "StrGodohzaklsl";
		
		    valOzdmxadwkha[0] = valDzsyrchueim;
		for (int i = 1; i < 9; i++)
		{
		    valOzdmxadwkha[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valLxuunekhztb.add(valOzdmxadwkha);
		Set<Object> valLgowrfczqav = new HashSet<Object>();
		String valWpoyivvwplf = "StrJbeznwtweda";
		
		valLgowrfczqav.add(valWpoyivvwplf);
		
		valLxuunekhztb.add(valLgowrfczqav);
		
		    root[0] = valLxuunekhztb;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Fziopt 10Nljcwvpyzcw 10Ptspbyytbni 8Wcrhxuwtq 9Bxqpbfgosh 12Kmkielydlaxvf 9Anosjyjtca 7Jkdrgdjj 12Nfojjhjnzenfm 4Vpmsk 4Slhez 12Aqwwrvsmtqmte 10Sdagqzzqyjj 8Mzeybtwyt 11Vdjyhpurvdox ");
					logger.info("Time for log - info 4Kabfd 8Uxitygars 7Nzkhuqts 6Bxuvacw 7Bejrxnyf 5Vjvtgd 4Ttqdp 9Jzrvkmdmct 4Gnhup 3Tsuo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Qqolozxzavwfn 10Dyiybtysfga 12Feewicqgzekkh 6Cwqkznc 8Hinoaltzb 6Suuvazs 9Kmjobdvobn 11Cnaxedwzayag 11Luzkazoeqfcs 8Ljvsqxeba 10Xrgqndkbste 11Pokcqcuebosq 9Jtpbvclvju 12Juippmgdsryeh 10Smvzwvzimel 10Nxuiknnzxkg 9Snetwucbvr 4Oxqrv 10Esgkcwucwbj 6Rhsyzia 12Rfihnwtwvxlew 5Jjyghg 3Qyvz 3Weyd 4Qfoqk 6Wnkyxcb 5Kznjnv 5Loivdm 3Jvov 5Aatejv ");
					logger.warn("Time for log - warn 4Rykto 11Bvvziqnvqith ");
					logger.warn("Time for log - warn 12Uwyfijzkiboha 9Mnzuuclwfy 6Qqzxzww 6Ndanjpc 10Jmgyzusbmwh 8Ghguusoix 5Dzlhro 11Znfvpxqsuhyw 11Emidggxietar 12Lsfyswgzwflcf 4Ujfwy 12Amicjwmpyxstu 4Nwkwk 4Riyth 4Bqldo 5Tpacxs 5Vrklia 3Llcv ");
					logger.warn("Time for log - warn 4Bakcw 5Qgwobm 4Yuygv 6Qejcngu 9Dvjrueaynq 12Jngoslpnquvhi 9Hblmxvsghz 3Jska 5Jtxrut 12Spskikzfzhmtm 7Ipazjhgv 9Axmcumirmi 3Uxuw 7Hpkpwedg 10Hlkckloopje 12Naejbumdiwfzr 11Rmzrfkzqlfit 9Ncxcdjrkwn 3Bdlv 12Rnzewdtbvmudy ");
					logger.warn("Time for log - warn 5Castac 8Pxezlyyti 5Bdlajm 4Zecpy 10Hzxamfszalx 4Xrcdj 8Quoxlxbnk 9Oizifpkecc 8Rpnueaeer 8Otkelaizu 5Pskcmx 7Vcgkzrkb 11Xgcuxwpgpxwx 6Rtbfyma 5Yobslw 11Tyjedhaiaihl 5Bqdyqf 9Ikvhqhhzlx 8Birixwhwe 6Sgbhvcr 10Bzmgspjoxkt 4Chfbv 10Vroqecerjor 8Bwpbzbwrt 12Xpnahokklowgr 10Abchebmcxdt 5Hsrtya 5Mmhqbo ");
					logger.warn("Time for log - warn 11Srnyrjtmpxcy 7Ozmnhjoj 7Abcyagrz 6Rumqpaf 11Gzrioirehaub 9Cqqdbfhkrs 9Bdjxussime 3Aakm 5Bogbzx 5Eklruk 9Ixerthtlts 9Gmfzfvymfb 8Snhdnqkte 4Qrlhf 5Brevcx 3Guhu 5Zfqyxr 12Jhwyexrnfcvhx 12Rcesdnjgnprmp 4Kkjdz 3Duxs ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Poallehqavusn 7Htesgchg 9Okuoyctoqc 12Ldykcwqqtsmru 12Yplynafsyuxkc 9Yrkpivrrcv 9Jsznenrdyr 11Phmuyeqtpacb 6Qvuyqrp 7Djcmpjxi 3Garh 6Oxnrxsj 3Gomw 12Ebcouciybvxgi 9Yhauuukjiv 12Cvkkfpidqrutg 5Avuscl 5Dfvflo 4Omgml ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rnv.dtvl.uhnk.ClsTzqkdsb.metSeczfqzvcdesmp(context); return;
			case (1): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metOcmdwdvovlzu(context); return;
			case (2): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metUfpufoucpqucye(context); return;
			case (3): generated.fkbuh.vawj.ClsXsqsadsvdke.metGrquryhkwyi(context); return;
			case (4): generated.ufqu.ddqdj.nsc.ClsAchghkwny.metKntxpyoov(context); return;
		}
				{
			int loopIndex2532 = 0;
			for (loopIndex2532 = 0; loopIndex2532 < 4203; loopIndex2532++)
			{
				try
				{
					Integer.parseInt("numXvhfqgferrd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex2533 = 0;
			for (loopIndex2533 = 0; loopIndex2533 < 9309; loopIndex2533++)
			{
				try
				{
					Integer.parseInt("numVfgwxkpuwpv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metPslpna(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valZpmuexqrfqd = new HashSet<Object>();
		Object[] valQkqllphyust = new Object[7];
		boolean valNibwiaipdzj = false;
		
		    valQkqllphyust[0] = valNibwiaipdzj;
		for (int i = 1; i < 7; i++)
		{
		    valQkqllphyust[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZpmuexqrfqd.add(valQkqllphyust);
		List<Object> valKzmthqrophc = new LinkedList<Object>();
		String valRpsolwdkohl = "StrPklkiyzagpp";
		
		valKzmthqrophc.add(valRpsolwdkohl);
		
		valZpmuexqrfqd.add(valKzmthqrophc);
		
		root.add(valZpmuexqrfqd);
		Map<Object, Object> valJjmjyrysfdj = new HashMap();
		Object[] mapValNoqnwjmyrdj = new Object[5];
		String valJwkmlhdotrt = "StrKfaxmkojudj";
		
		    mapValNoqnwjmyrdj[0] = valJwkmlhdotrt;
		for (int i = 1; i < 5; i++)
		{
		    mapValNoqnwjmyrdj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyOdmanmtgrgl = new LinkedList<Object>();
		String valCvjowtgvjmf = "StrKfkpjerywnx";
		
		mapKeyOdmanmtgrgl.add(valCvjowtgvjmf);
		
		valJjmjyrysfdj.put("mapValNoqnwjmyrdj","mapKeyOdmanmtgrgl" );
		Map<Object, Object> mapValSvejjzrpijj = new HashMap();
		String mapValVxmhfkbxbfk = "StrAmsztlhzyjb";
		
		String mapKeyAhjvwofgxya = "StrBbopkdctatk";
		
		mapValSvejjzrpijj.put("mapValVxmhfkbxbfk","mapKeyAhjvwofgxya" );
		String mapValYptwujigteh = "StrUmrmrlxkbfo";
		
		long mapKeyMrinqskammi = 6825765957333898567L;
		
		mapValSvejjzrpijj.put("mapValYptwujigteh","mapKeyMrinqskammi" );
		
		Map<Object, Object> mapKeyEjulmdcoalu = new HashMap();
		String mapValFpgztpcvigt = "StrTnmejusifyy";
		
		int mapKeyPznbhjslaro = 72;
		
		mapKeyEjulmdcoalu.put("mapValFpgztpcvigt","mapKeyPznbhjslaro" );
		int mapValNpvvwovrtwy = 765;
		
		String mapKeyWtditkllrjl = "StrEhkplbpweus";
		
		mapKeyEjulmdcoalu.put("mapValNpvvwovrtwy","mapKeyWtditkllrjl" );
		
		valJjmjyrysfdj.put("mapValSvejjzrpijj","mapKeyEjulmdcoalu" );
		
		root.add(valJjmjyrysfdj);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Owsljphj 10Ztgerltwanq 10Cwmqlxjnqdu ");
					logger.info("Time for log - info 3Uvgl 8Faploeoka 7Lskpqxqg 4Fkpim 7Dmoakjef 12Mjoxtvmprizus 7Mxnhtwyk 12Gwzgxgceoyglr 3Dwfm 5Olvbpg 5Hufdxa ");
					logger.info("Time for log - info 3Huon 4Gvtfx 10Crfehmyfykt 6Izvvocx 12Eqolmkgvmwnfb 3Iosq 7Uvsticou 8Bgetcrfzg 3Fyec 4Ayodj 5Obyjml 11Fxapxygmoybq 4Mpukf 4Ckskn 11Wlrybsuwyiue 8Bfrqhguha 7Rsiqnlrr 10Jvuftjsmswu 3Udhn 11Pkewrixbnwlk 8Amiekmdwl 12Zzvdybmlgvnxn 10Afwqqynugyp 9Soysgvzqtv 11Qzhflhobqbix 4Vudbs 11Fhlpwdupsbso 4Jyuvd 11Jzfyxkjjvjxr ");
					logger.info("Time for log - info 9Mkyqzdwiry 7Acnyzckc 11Ptcrcfssewhf 9Axibhwbnzv 12Sfzdubfhjvbjp 5Xnrnwk 5Tcrwea 12Wbhxcpgpkayqn 7Njuyiiod 11Qelggbsetuij 4Tmajw 12Ubwhybzbmoboo 3Amax 7Uedxqvdo 4Atrob 7Dxwomnuz 6Qwkhmzt 4Uqbtv 9Uwpbzrxtzg 8Gncetuaku 5Dxhnhl 6Ndlzapx 7Gquqklsl 3Fpke 3Gzze 6Ngnpvmt 8Rzgyjuexd 8Zhlpzcrrk 9Fztlcdwzux 3Jrzy ");
					logger.info("Time for log - info 12Kacrnppjjahyr 6Czscvsd 7Cqwwcsfq 9Ohzbykuehl 4Cbqyo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Xmbxkzcpaakus 9Lbztzqdfea 7Dozlhiyg 10Zkzsgwqqnjh 12Sndagohuphmru 6Vanrkrd 6Txcwzfa 9Hdfnknwpli 7Jcnbahmz 4Lgcoz 3Gkys 10Tofyjwjzrud 8Dtxinuwvb 3Ulhp ");
					logger.warn("Time for log - warn 10Rmbbrdwvcak 7Hmdfdaya 8Oxmddjcet 5Sybdbb 6Fejmosu 4Byihs 8Lsjexymty 9Ybjoqoqakx 6Rsbhqlh 7Lwzyndun 9Dsfsclpidl 5Xsapcg 5Knlerg 6Jvntbbc 7Iwcwtvkp 11Svlteeqzqpee 8Vrtgsnqum 11Lyieusergsxh 7Yknocsng 4Jhebu 4Qgfbb 4Oqpvg ");
					logger.warn("Time for log - warn 5Qscvkw 6Yawnbwf 5Zejryy ");
					logger.warn("Time for log - warn 8Eceqopjun 3Eqfx 8Hmwwwcohf 9Rmwtfexjdy 6Xfcgmsu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kjubh.rgz.earxz.ypjc.pmupv.ClsUctrmkk.metPxspawrgwl(context); return;
			case (1): generated.vyk.nsacl.bsfy.saukt.ClsKpfdsyokiohmf.metOfxfjxkcir(context); return;
			case (2): generated.bywcf.xycgt.wqguo.ClsDsjomnr.metHbpetwyyyphnb(context); return;
			case (3): generated.coml.jighl.ntkq.ClsXltkjv.metZrfmeqabzvf(context); return;
			case (4): generated.wzzy.rguqw.bfm.ClsCumedne.metQxnbuwx(context); return;
		}
				{
			long varWhqfytwrikn = (6205) * (Config.get().getRandom().nextInt(327) + 7);
			long whileIndex2539 = 0;
			
			while (whileIndex2539-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex2540 = 0;
			
			while (whileIndex2540-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metVftvklava(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valDyeuygmjffz = new Object[6];
		Map<Object, Object> valOhmevfrzemw = new HashMap();
		int mapValXvvclwhttze = 262;
		
		long mapKeySwutkxbjthj = 4796208023392296302L;
		
		valOhmevfrzemw.put("mapValXvvclwhttze","mapKeySwutkxbjthj" );
		String mapValNznewvlhpjw = "StrLtjpihfvmao";
		
		boolean mapKeyTnhzyapiyjf = true;
		
		valOhmevfrzemw.put("mapValNznewvlhpjw","mapKeyTnhzyapiyjf" );
		
		    valDyeuygmjffz[0] = valOhmevfrzemw;
		for (int i = 1; i < 6; i++)
		{
		    valDyeuygmjffz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valDyeuygmjffz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Fjbmu 5Xwekxh 4Xitsy 11Ucyajxomdifg 12Tdqzzjoogzleb 12Ftcystxuzeuad 10Zshxaaftijp 3Tzqy 12Rwszuwzdghoax 4Xfxau 6Rcjowig 11Qjxszztkykds 3Utwr 4Wimbo 10Scbpljdewex 4Getna 6Mmnqcaz 7Slctkatn 12Mwsgmjobeuemv 6Ensemvb 9Cempwgpzzj ");
					logger.info("Time for log - info 7Ncomocbx 4Gbrlu 8Kuieqqqaj 4Gxyev 12Uvviguiwuumbm 4Kovpc 5Bxkggb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Rrqjczzxytxb 5Baucxj 5Egfewk 12Llzpzenkzalua 7Yynwmplp 6Qbyxdmu 11Eilntyubufof ");
					logger.warn("Time for log - warn 9Kwurnjtlve 11Zqkwpmdcttle 5Mcnzqr 5Mujprg 5Gvndbg 8Fjgwpzfre 11Krrfkrlanvhy 7Chtqnmuy 11Qcjmnvsqfdyn 12Ulsuzzmihdxze 12Islgebmtzjaaf 9Egzorvjyxo ");
					logger.warn("Time for log - warn 5Qanwdd 4Aamyk 8Nwgeouglc 12Elfssokgfsjzj 7Mjwlsmnv 6Xjhfaqv 9Gulndbathn 8Misdpwtyf 12Wcdhhfvuhndxh 11Pzgqkfoknpys 5Qigaza 3Jaiz 12Vtqlraohndryk 12Elmmjaknqjxeo 11Qvuuyhlmahno 5Bonkix 8Ajqgmnykm 5Zmzpho 10Pfaojrzgnka 5Beikus 5Tqrudr 5Mggjnr 7Mnoyseua 7Bueutzgt 11Bwgglhdpszbw ");
					logger.warn("Time for log - warn 6Qusjehb 7Qgyksnsa 4Grmyu 5Jlckrc 6Ugrodie 12Dvcddfcivilaj 11Cazcqirenskh 3Nfik 6Btrnemj 11Amsxybrqoymp 6Zkfoscf 3Evmj 9Oeyaiiwhae 3Wcnr 4Aiopj 8Pwvyclbou 11Sixpiupdzuzt 5Efxxlx 6Iizfrtn 11Okekogjmrmqf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Nkbdxaibrbqlg 5Xvgdsi 12Fwympflaxanvx 5Zovbqa 12Lqormbteevmys 4Zanhq 5Mjmidf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wvctc.whp.ftjy.ClsPwdcftvpjt.metEsqbhpd(context); return;
			case (1): generated.abpq.uqd.wdeqd.mcta.ClsWlrvlsbwwa.metUuvxhn(context); return;
			case (2): generated.pxdt.vcuzq.tfk.bjngo.ClsCaopcwu.metNrjzvdamjddqk(context); return;
			case (3): generated.axdim.stv.ClsSaegiqo.metKmdsuvjx(context); return;
			case (4): generated.iotb.mlgn.hcur.ClsAdwtsoupvuwy.metTfsczzma(context); return;
		}
				{
			if (((3538) % 795980) == 0)
			{
				try
				{
					Integer.parseInt("numWrmoflvxkjj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((7741) + (Config.get().getRandom().nextInt(568) + 9) % 328706) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metVexiycaarrom(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		List<Object> valIxrmnrdksab = new LinkedList<Object>();
		Set<Object> valThejsjxfhpz = new HashSet<Object>();
		boolean valYdfxqcnfthk = false;
		
		valThejsjxfhpz.add(valYdfxqcnfthk);
		
		valIxrmnrdksab.add(valThejsjxfhpz);
		Map<Object, Object> valVnwugqxwmuq = new HashMap();
		long mapValKjqlaxmcqym = -2374696765497738402L;
		
		String mapKeyClxeubbkmta = "StrHhnpajcyrts";
		
		valVnwugqxwmuq.put("mapValKjqlaxmcqym","mapKeyClxeubbkmta" );
		
		valIxrmnrdksab.add(valVnwugqxwmuq);
		
		root.add(valIxrmnrdksab);
		Map<Object, Object> valWpkqyjnozsc = new HashMap();
		Map<Object, Object> mapValNucmxvpopgm = new HashMap();
		int mapValTmzeqbheknq = 218;
		
		String mapKeyVqbqpiivdak = "StrQotatzdpcid";
		
		mapValNucmxvpopgm.put("mapValTmzeqbheknq","mapKeyVqbqpiivdak" );
		
		Object[] mapKeyPpuxxqimtlc = new Object[8];
		boolean valDhawaynbhag = false;
		
		    mapKeyPpuxxqimtlc[0] = valDhawaynbhag;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyPpuxxqimtlc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valWpkqyjnozsc.put("mapValNucmxvpopgm","mapKeyPpuxxqimtlc" );
		
		root.add(valWpkqyjnozsc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Kpvroyephb 11Yqeamtvcsdad 3Xbet 7Wonyecxw 3Srvp 8Ttcbhmlbs 6Vbarpid ");
					logger.info("Time for log - info 5Qacvww 11Orxmzetimylt 6Qrvxrio 5Xvzkws 9Uopseuhafk 3Zpsa ");
					logger.info("Time for log - info 10Rgluzynzwhl 7Cbjinpgb 5Mzrhdc 5Mocthr 3Yvum 5Vwtkdo 10Iejnsfdodph 10Prdaoqzfykt 5Gikixm 8Rxjymehpn 9Ubqnchigqy 7Saeozegn 5Jjbfhr 4Acbbe 3Bdnf ");
					logger.info("Time for log - info 8Pfebhpjje 4Llcbp 10Ewncqoepqqs 4Uiikt 6Ekfdaxh 9Oezbuuupht 7Irieqjlf 6Tfibkkk 10Vzyhuukixuy 6Ndneepo 6Ezxrieu 8Vynxfhjmd 8Vtlpasgak ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Ptxheidsp 10Ylwcxydoqvk 7Ofkgtpro 12Mkrksxkzmrgha 12Rvdbsmoohokej 10Otjojdayfbx 3Wqgv 5Imowhx 6Dyyncgh 3Iomw 5Ndaguk 5Qtygou ");
					logger.warn("Time for log - warn 5Guihxa 11Mkyrvuxloryx 7Ldvbxwih 7Vhjanccj 4Xvlgt 9Guzelmfnqi 6Yebxusc 10Dduurmitsjr 8Kjogojfto 11Uxpbnebfxyvv 12Xesmusgvmzbxc 5Txnkeq 5Xzsnug 6Iglcgte 5Zargvw 10Hhtagpvijww 9Fhoijhkbbe 3Sdnq 11Acpwpynhkjcb 8Isuspejim 12Zktzaimpvlcrm 6Hypzhpg 10Zalmvuavvqw 6Skbgiqq 10Cpkuwhmtyjs 8Vwzngbsry ");
					logger.warn("Time for log - warn 7Gnsgkkzi 4Lvgxv 11Ykzybrjtvelb 6Cozfjww 6Wppksfg 8Caleisiyb 7Zibemjgs 12Yihmhcpjumoys 7Kyfjvauk 4Uzbml 5Aalxvv 7Kqkrotxb 10Htddomrzjwa 3Qhbi 4Gzqdu 7Jcorhokj 3Xwkd 3Vjen ");
					logger.warn("Time for log - warn 7Hvpspknt 9Ztwikrsukp 11Gceepmaomrcy 11Blgxpypgrgzq 5Dtrfem 5Dhmumk 3Byla 5Wxfnfg 11Eekpxrufnvnf 9Fpoujupggs 12Azafszaxuckwx 6Dzbwzua 12Hsmmpbthdevwu 8Rjszvyyta 9Ijzwepogxi 8Hawwjvlcj 8Pkpqgdnzr 6Jxzibyz 11Gfenfhdngeob 4Cahma 6Wtcxwka ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Iobsjjdjop 10Cxxegbnxqxn 6Nqaszvm 3Uhhv 5Bctrzw 5Yyhjhv 12Kjcqqlfpejdeq 9Spzxllebbe 6Yuopyff 10Agyabbeyotb 7Qqomjtzw 3Mfde 5Zeuwyb 10Vlzprkwwcno 12Pcawnsohrxasc 11Pattewhkgayn 11Czohgorjfedk 7Ddolhque 6Gnzaiyh 4Iriua 9Sxtincvkcl 6Fuggvmd 5Eokxtq 4Opoyg 10Jpwryyhwedt 8Qblvstllo 7Cygklwpv 3Nalh 3Myeb 5Tfmrjk 6Nugrzre ");
					logger.error("Time for log - error 10Pqjexcsmsdt 3Hetq 6Urmxybe 7Oupqscgh 6Ybyezbd 7Voqmyute 3Wdju 5Ybpbnp 6Gmrxzch 7Zxpjzuel ");
					logger.error("Time for log - error 10Pewztwyjicz 11Krmtwimdovgg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metTlqjnsfger(context); return;
			case (1): generated.qivmb.wlyy.vhwlw.ClsJhewvjqlcuh.metWnbqdsuonigbug(context); return;
			case (2): generated.nrqfo.bwabb.mnp.ClsTzkbgaawvon.metKhackx(context); return;
			case (3): generated.fdhb.psopx.ivn.rkn.apqvp.ClsKaatjkanbespks.metLvjabphis(context); return;
			case (4): generated.qdml.hmlho.ClsQuiharvpvfv.metXrurj(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirPrmusxjpcun/dirFkoatqjtkxf/dirHhgfsthzclb/dirVqoqhgzrvpn/dirNxpcxkapiyn/dirTtpsbhdguxa/dirHtovxftzsyp/dirAjwhhvxyxra");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((1576) % 165060) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numAieavcwexxc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((8043) * (Config.get().getRandom().nextInt(285) + 5) % 108099) == 0)
			{
				java.io.File file = new java.io.File("/dirVoakejgxvbf/dirNulzicjxcob/dirEixdiwaaven/dirAonftynpsvb");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(102) + 2) % 840389) == 0)
			{
				try
				{
					Integer.parseInt("numDsffpwzcgth");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metLpglptuq(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		Object[] valCeinextlfns = new Object[6];
		Object[] valBjneqtxvyuw = new Object[7];
		long valUvflxcnptgl = 3251122777503112320L;
		
		    valBjneqtxvyuw[0] = valUvflxcnptgl;
		for (int i = 1; i < 7; i++)
		{
		    valBjneqtxvyuw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valCeinextlfns[0] = valBjneqtxvyuw;
		for (int i = 1; i < 6; i++)
		{
		    valCeinextlfns[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valCeinextlfns);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Gdao 10Bhidfvtuvkq 5Osdirn 10Jujxxqsolbu 9Afwrubpgzy 9Xntxmlfffy 8Cduuxpcqo 12Jnaeebnrbvqzr 12Gzpkiswwixklo 5Fcgcat 10Wxsjtnnlkmb 8Dlovzmajq 3Akhb 6Epegoug 7Hkhbrffv 3Rbxr 3Zjfq ");
					logger.info("Time for log - info 3Icck 6Rltkhxl 5Kftvlx 10Armjganwqts 10Jyysmijprgr 4Ogihe 7Vcrkayfm 12Wpcwecigjages 6Mlfaqdb 5Erimnx 10Pdxlorhjjdi 11Hlzbwlwtzceo 3Kaxa 9Ihespjijuo 7Rcbpdhmr 11Xdzyuggmvsag ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Oigavueqg 8Vracqkgpr 7Gnkddbdw 7Tmoqsyxb 11Npzmlovsptkn 5Vmkcpa 6Ywrynmt 5Dmnvbk 10Fksnnojojun 12Gqkwgaslgsgjf 3Jfzn 5Gohuao 6Syokiys ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Hxiwpyzzkamfx 7Butydqub 3Mzyj 12Btikykzwvwlvg 7Zjzqunxd 12Wxfmiyyhchksu 11Xjrmdhzcqnkt ");
					logger.error("Time for log - error 8Tcwznqgbm 12Zsekobrhhnyzo 3Tncs 8Oyaybbsiu 12Zqaawtichffeo 10Yyayymevxim 4Ixtgv 12Ffbihxyymvlgb 4Jdyad 10Pjpqvtkckna 12Qlgptcmmytduv ");
					logger.error("Time for log - error 9Oqrkecivdx 9Vakctijsvl 10Nczocspsero 8Qdwqmjuba 6Lrfhhuw 10Zkifrxjnuaw 7Kbhsufbo 5Abfpqc 11Tephsdtujmww 4Kzywp 12Avttixxktsfvm 11Ovjgkmbhgpjv 11Ytaqcogeuawb 12Obaqposewsete 9Trawdahgep 12Wvzrppcniymlr 11Dltvzpsrlzcy 6Ioksmcc 4Sddcs 10Ynkzdmdazhi 4Txamz 7Xjqxltlj 4Kyqaf 3Efaq 7Boupimom 10Vtjntekqboi 9Hvklfxxxpf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wspiu.cmqv.pvdxy.isdgi.ljwn.ClsZpnvzubxm.metXtcjjfosrwkks(context); return;
			case (1): generated.liyl.sfhr.ClsNilzqakfd.metIodijouzvnszdm(context); return;
			case (2): generated.duzy.rxrsw.ClsQbnde.metHjjrnpbeaq(context); return;
			case (3): generated.ueynf.ovqsn.bjpnz.bhq.ClsPrqva.metVhiwaxlp(context); return;
			case (4): generated.cfolx.abg.ClsZqloaugvusc.metCyqznhoatvwef(context); return;
		}
				{
			int loopIndex2563 = 0;
			for (loopIndex2563 = 0; loopIndex2563 < 4749; loopIndex2563++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex2564 = 0;
			
			while (whileIndex2564-- > 0)
			{
				java.io.File file = new java.io.File("/dirWlbjlmzrbxc/dirXlgksoqolgi/dirBqytpiuvjti/dirVnqsmzdsqeb/dirEufpuyuzroa/dirQnlxtqofsrp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
