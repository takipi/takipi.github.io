package generated.lxrj.lts.csk.iew;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsCagmzsja
{
	 public static final int classId = 130;
	 static final Logger logger = LoggerFactory.getLogger(ClsCagmzsja.class);

	public static void metMsmzpyezeb(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valZexolpcuvat = new LinkedList<Object>();
		Object[] valKgxfranlwhi = new Object[3];
		boolean valUqhowqlsceq = false;
		
		    valKgxfranlwhi[0] = valUqhowqlsceq;
		for (int i = 1; i < 3; i++)
		{
		    valKgxfranlwhi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZexolpcuvat.add(valKgxfranlwhi);
		Set<Object> valOsldeejpiia = new HashSet<Object>();
		int valGcritovvkyn = 406;
		
		valOsldeejpiia.add(valGcritovvkyn);
		String valYgvwjjxcrhc = "StrUkgvbjamtid";
		
		valOsldeejpiia.add(valYgvwjjxcrhc);
		
		valZexolpcuvat.add(valOsldeejpiia);
		
		root.add(valZexolpcuvat);
		Map<Object, Object> valWztavttfdta = new HashMap();
		Map<Object, Object> mapValLffnopysjml = new HashMap();
		String mapValOlektquzmtw = "StrRnpuuqzvara";
		
		int mapKeyHjvaxipzrpd = 51;
		
		mapValLffnopysjml.put("mapValOlektquzmtw","mapKeyHjvaxipzrpd" );
		int mapValOxvbxyfvbie = 99;
		
		int mapKeyUimghmkywmk = 566;
		
		mapValLffnopysjml.put("mapValOxvbxyfvbie","mapKeyUimghmkywmk" );
		
		Map<Object, Object> mapKeyLsscgbqyfqp = new HashMap();
		int mapValGuhxdceuhdr = 541;
		
		long mapKeyKxgajjkfmuf = 7367924692131882980L;
		
		mapKeyLsscgbqyfqp.put("mapValGuhxdceuhdr","mapKeyKxgajjkfmuf" );
		int mapValZtynburetvh = 867;
		
		long mapKeyDhhpwoeqycp = 6047377888616806304L;
		
		mapKeyLsscgbqyfqp.put("mapValZtynburetvh","mapKeyDhhpwoeqycp" );
		
		valWztavttfdta.put("mapValLffnopysjml","mapKeyLsscgbqyfqp" );
		
		root.add(valWztavttfdta);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Ulfvmgpgyg 11Xuhgksprmunv ");
					logger.info("Time for log - info 5Uazquo 9Khaufwvnms 8Ocyebwtho 7Sjpmbvkk 12Rbdxseaxgsrzk 10Aqrqqiueglt 10Nwbstqayirc 7Agoiupzg 5Azhclr 8Twwbdfpgu 8Stexmryrr 6Zldohzn 4Miode ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Qzyh 11Ndmgxoxhdecu 9Avyfbhzvfn 12Lsrucjfporwxq 9Hpwzmqvrrh 6Lezwttu 8Mewdpshyd 8Ffabjodqc 10Cdyxngbxixp 11Hopwxmtijusb 9Bncckbdvvf 7Hqzcipwf 6Xxngmje 4Cmfnv 11Mryndmmvojmu 7Nvmjtbgf ");
					logger.warn("Time for log - warn 8Ujonidbmi 3Gcwo 3Xthn 12Vccciyxgiybkn 6Nrmvryl 4Pndtc 12Qbkkrqguaqxiq 12Rudragaskkhmg 4Mwpzp 12Ovncwazzanrjv 12Ovrnsqmerlzsm 8Asqbsncle 12Rfaythtcehhuf 5Lhfucn 9Dijnmsbmgy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Jitaud 3Nwcu 4Edtwr 5Mtkrjh 6Uoksosf 11Glihrfnonuzn 3Ghwl 12Intqyatzfhrxp 4Hynbs 5Iuqbhi 9Xcyatvuiiu 12Ehezisbmlpdzv 11Wjxwwuleocpl 3Gwna 9Gfpgruszwt 9Lxxphkwdhj 5Prnbhi 4Tsznt 3Uurt 6Geyezpz 11Fydpobajfjzg 10Rjxhgxkyuvc 4Ltbwm 9Oovbpfwqsv 8Yijzohvyo 8Klrdxeqxc 8Dzxgxsrlk 12Oxljgkylcaykn ");
					logger.error("Time for log - error 4Qmbnf 9Mlmscsdldb 8Apfvaqyhq 12Crumsxtgitswd 12Cohruyhuppumh 6Gnbvaap 4Xcqyi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cmlwi.ajlk.yhine.aaz.ClsYxnwkcu.metFaguljivuo(context); return;
			case (1): generated.hvqh.qdnb.tawyn.ClsAaddylg.metCsnugb(context); return;
			case (2): generated.usy.jqyb.aoxm.cmxc.tdb.ClsGdtxkhc.metYudmw(context); return;
			case (3): generated.hzw.xclp.jagge.pvih.oqmlx.ClsBjaeoqqxwxxp.metPmkwxr(context); return;
			case (4): generated.mfx.chc.ClsHhqqrzfttutmc.metIncutinrfri(context); return;
		}
				{
			long whileIndex22375 = 0;
			
			while (whileIndex22375-- > 0)
			{
				java.io.File file = new java.io.File("/dirWilexotbtey/dirSkqggmhnrwp/dirZuvpiduzbtd/dirRbwtmnicxxt/dirOgiwzzujegz/dirBcovrljgwye/dirCbscancblhy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex22376 = 0;
			for (loopIndex22376 = 0; loopIndex22376 < 9138; loopIndex22376++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metOondcg(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valUhenzlkrvid = new LinkedList<Object>();
		Object[] valTauykjbflgd = new Object[6];
		long valGxyecofyreh = -1979458731671753669L;
		
		    valTauykjbflgd[0] = valGxyecofyreh;
		for (int i = 1; i < 6; i++)
		{
		    valTauykjbflgd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valUhenzlkrvid.add(valTauykjbflgd);
		
		root.add(valUhenzlkrvid);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Evchijovudoe 11Ieqgxuofpysn 10Scefuedazbe 6Imlqwku 6Jcixfzs 7Mdlidfmz 3Esza 6Yzvuzgm 5Sgrouq 11Wbntdxehvpzc 5Hfgmyg 9Zjhpsmafow ");
					logger.info("Time for log - info 10Rnauywxlylh 10Gsqdpemhhld 9Emqbfmjmoi 9Nncqdlbogl 11Slzdjxwjtrty 12Fksgtczkpebct 7Bekhktdw 12Eudgpyussqxxy 7Zszyuxzc 12Bcucjtsncvxgt 3Pgcy 5Gxxawz 10Tgrrmckogof 3Kwce 7Wfqfdpgn 10Drwzsfvajal 3Htim 5Ewfbhp 3Sikc ");
					logger.info("Time for log - info 12Ercdawrmhhviq 9Igfheqrhcc 5Zjcsnp 3Qivq 5Pfkese 3Fcwb 7Hgiiggfv 3Vcnf 4Kmrwg 4Mpslw 4Apvua 4Dkxkv 10Okiewhmilfn 4Frdtb 4Lfnki 9Yvfukzvqsj 9Rhkywyljgw 8Yifruqtmb 6Vdoibmq 5Ybdxzu 3Drpe 6Nhskspy 8Cslmvpanq 8Zbepjcuuk 9Xoddsdhmlo 9Hmtyusmmtw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Rtvpdd 12Lztwasuptnbmr 3Aiwf 5Ulgzqr 11Oprtfnraviha 11Xnldagfvjbxz 7Zvjecnhs 5Rebrtf 12Ojhnjutarutos 3Alrg 3Nwlt 4Qgeok 11Xfihailthbot 9Jzaefwxhqb 7Tygdxbxj 5Ypdydm 10Qfometlyeuc 7Mqpazcew 6Aezahdu 8Lnyoxiirx 12Qthzxdjrnvphf 12Cejdqqzzdxbsi 9Inrrywenoy 7Ssrxpark 7Hxdvikig 3Aeaw 10Eeuslbodcwz 4Xgasr 11Mfwgywsisrgp 7Tcqtqnct ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Wrzdqmwuhrzs 12Cafvxpwavkmzl 11Ykggitjjnzwn 5Lpyqpb 6Zdbekqv 4Aklzt 10Rkmvxgfmvij 3Mzyf 9Pygclxaglz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.psl.vgj.rgm.ikl.ClsWqomoi.metKrbftwlk(context); return;
			case (1): generated.sik.dyw.jmm.xdu.omh.ClsVarjcvcyur.metFesaihfuowja(context); return;
			case (2): generated.fxa.nzjpw.lkh.sxue.ClsXtfkzq.metMfvvu(context); return;
			case (3): generated.usy.jqyb.aoxm.cmxc.tdb.ClsGdtxkhc.metAqtyyf(context); return;
			case (4): generated.coml.jighl.ntkq.ClsXltkjv.metZrfmeqabzvf(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numBxyrcfngdqr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex22383)
			{
			}
			
		}
	}

}
