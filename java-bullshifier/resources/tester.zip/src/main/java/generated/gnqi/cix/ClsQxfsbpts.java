package generated.gnqi.cix;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQxfsbpts
{
	 public static final int classId = 234;
	 static final Logger logger = LoggerFactory.getLogger(ClsQxfsbpts.class);

	public static void metJwdiaxkgclbcke(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valHestmofclzw = new Object[8];
		Set<Object> valEnaiexwaafd = new HashSet<Object>();
		boolean valCjmpxzjgywo = false;
		
		valEnaiexwaafd.add(valCjmpxzjgywo);
		long valWcygpjpovps = -6607937296861257254L;
		
		valEnaiexwaafd.add(valWcygpjpovps);
		
		    valHestmofclzw[0] = valEnaiexwaafd;
		for (int i = 1; i < 8; i++)
		{
		    valHestmofclzw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valHestmofclzw);
		Map<Object, Object> valHimiktxnuxx = new HashMap();
		Set<Object> mapValPsriyotbcrs = new HashSet<Object>();
		long valSguhjanujdt = -7996853998388165718L;
		
		mapValPsriyotbcrs.add(valSguhjanujdt);
		int valGyiyklunmlc = 201;
		
		mapValPsriyotbcrs.add(valGyiyklunmlc);
		
		Object[] mapKeyWdizppnnvav = new Object[2];
		String valPxmlizfdwpx = "StrAeayyuofydk";
		
		    mapKeyWdizppnnvav[0] = valPxmlizfdwpx;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyWdizppnnvav[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valHimiktxnuxx.put("mapValPsriyotbcrs","mapKeyWdizppnnvav" );
		
		root.add(valHimiktxnuxx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Szdwrzboyh 12Bxtnksemcbbws 11Whlujanzfnii 5Pzffpo 4Lxhsm 8Xjvyakwis 10Uqbviuhxtpd 8Dtafhfcek 10Mjuzhpneixj 8Azhxqohwk 4Ritzp 4Ksucg 9Fohjkpcbev 4Sxiui 9Vocgzaflbn 10Yxeazyqnqvq 10Znkkeooloat 4Rsecm 7Tkqzpqil 5Kprmuj 6Neayltb 5Vmcews 5Vmsqsb 7Grnddbdz 7Hcesbkgd 5Qgoyeu 4Lmocf ");
					logger.info("Time for log - info 7Arhpfigv 7Vuviimad 6Iasfgws 8Fbcsbbsjm 9Jrbamcrtxe 9Tcgbetccko 4Rtedz 10Ixtvkkirbrk 3Opao 3Aukj 3Nlvk 10Fsqlikelylm 8Dpitpgdnn 9Dbvvlhnsuq 5Fkahxw 6Lxtnfpm 6Hqteauq 4Eqxui 6Yicivss 6Kubqvsz ");
					logger.info("Time for log - info 4Ipjgi 11Rbbxhmdsrsft 5Hdeafd 6Vmzhiwb 9Iakavebxdt 10Kdwwhgopjbc 8Vzjeopvvn 5Csinjv 3Ftml 12Rqlwttcokveoa 5Okpkjw 4Tbvbn 3Dasj 6Lvldavh 4Mkzab 5Cqiriu 12Lyacxmvpgmgkc 6Bllmpjr 8Edvqnjyfj 11Skpfyhkuhxcj 9Czopvzukzu 10Iyilhnxqrpy 10Xwmvvvgkvcp ");
					logger.info("Time for log - info 10Xrstfgrkenw 7Vvxvxzwm 10Byemotteafz 12Xcvwvkmfyzegm 11Swcqzcxowixf 12Tsotshercgznt 6Ijlrkbx 7Lsblanik 11Hrvtfhgoyako 3Ucyp 6Ymtnwrm 6Szhmasq 5Nttcrf 9Zxapwwhehh 5Ftpodg 9Vkexudxdjj 5Ckbext 11Zacgulinpycq 8Qwhaklgdz 7Sykhcgjk 12Nccdlczvmsjce 5Hlyyzk ");
					logger.info("Time for log - info 6Jkyfckh 12Yjmttveeltmmj 7Dfqgogmp 10Fpbxrhymwwm 6Iswblku 11Elwyiyahpazh 9Qtutwjhaju 6Uyjfaqy 4Ifvzk 4Pdjvg 12Jgrffglctqwtx 12Aqxnxaupggdzf 12Kqvvafxxqchna ");
					logger.info("Time for log - info 7Lvgmforr 3Xyga 12Laxavrxgytfzr 10Ksjstylivpw 12Fkmkwatvyldeu 11Ygmvysnqjwqu 11Ohccqkfhixew 6Flrzaix 6Utaydal 10Agrmlprhvuo 8Pnilqyrxk ");
					logger.info("Time for log - info 4Hhjlm 4Dgzaq 6Ennqqwe 6Gnvuxxu 7Ymsohekp 4Sokqi 11Xtfatuzejfen 3Qyvn 4Kixev 8Slgcaitpx 5Omdqok 8Tbrajbrup 9Tflgowyqgn 3Irkh 9Dkiqracesb 3Tgfu 12Dvxauqwlunaua 3Qfbr 4Vzhcv 9Rtzdgrkqcp 11Aeniofqhkvov ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Lwsl 10Zraipmbcaqn ");
					logger.warn("Time for log - warn 9Tccbvuomrw 12Jgddxgdzsgdem 9Ayqxunaiuc 7Mwbgohlg 9Qdlwkjzeri 9Lonsnzvldt 3Idcu 5Haekzn 5Mydovf 7Bqqfkgkp 10Toxozcfljcz 6Ezrwpwp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Hkgrunmszdtz 6Fqscivd 11Uolbosieclkz 9Nnywsnpycr 10Brovtexktpq 4Dzhrw 9Bijfrmjdql 11Ojwjyzicthgt 12Zwbvmirrcsblf 6Apmifxo 8Suiuzbyyv 6Hqbiyqd 9Miyznasnjy 6Puevtjl 10Fhtqcnevnhc 4Lemau 7Ysguybra ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gapuh.cesf.ClsXyxpazfgwk.metNunfetlxuqsy(context); return;
			case (1): generated.vyk.nsacl.bsfy.saukt.ClsKpfdsyokiohmf.metHsxtpfnfagp(context); return;
			case (2): generated.zkx.deuj.ClsQemyphqswqdyqm.metHakngb(context); return;
			case (3): generated.pxy.vesv.fuz.ClsEaskwlgtcshts.metCnqxpzkxiqea(context); return;
			case (4): generated.hyq.yrx.ucb.jdut.ghw.ClsXwcyosgzsc.metGxlvnhkhnqc(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numMeaculmugcf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex24174)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirEjejmqnbpyw/dirAzdmvkgffco/dirNrkqwvlnpgk/dirTqlsolprter/dirWfziwuaqakz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varCwhwhvxjjtg = (4019);
			varCwhwhvxjjtg = (5743);
		}
	}


	public static void metKsqjpoe(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valBmzzzfapkie = new LinkedList<Object>();
		Object[] valPqjnjlmlmhc = new Object[5];
		boolean valQwmznnbsexa = false;
		
		    valPqjnjlmlmhc[0] = valQwmznnbsexa;
		for (int i = 1; i < 5; i++)
		{
		    valPqjnjlmlmhc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBmzzzfapkie.add(valPqjnjlmlmhc);
		Object[] valRlokegmvgmb = new Object[3];
		boolean valCdzbgaxwmfs = false;
		
		    valRlokegmvgmb[0] = valCdzbgaxwmfs;
		for (int i = 1; i < 3; i++)
		{
		    valRlokegmvgmb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBmzzzfapkie.add(valRlokegmvgmb);
		
		root.add(valBmzzzfapkie);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Qyczrgz 7Nmgqqiup 10Sqhnsjdohve 11Omcrenjqwcsr 9Oardzzdodv 6Crekhzo 10Kbhbtmqyilx 8Idpfugnjs 7Sprahnxk 8Kmxyzmhei 9Puezvspkvq ");
					logger.info("Time for log - info 6Jbnyzkr 7Ogvwosvl 9Ebpsszssdj 10Eqtfwjwgqff 8Xalexymcn 5Worbuu 7Hztrhhuq 8Pucqvtpod 5Vjwpzu 6Xzkvxtu 12Mfbkhqfkotime 10Okxukzjbuvz 6Ravmlac 7Piozzjbu 3Rusz 9Cyvkesudcz 11Lajfhzmrvfec 12Fjabrnogxdytz 12Airoopgvcjwxi 7Aymdsdes 8Gdblieijb 5Wuowef ");
					logger.info("Time for log - info 11Ycdyrxkffzai 3Ktys 12Wsilmiktmopng 12Sfthechwnedfs ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Smriqndvxoo 7Cbxtirxx 5Bbiayw 3Hxis 10Opasvdsldkl 4Uwxeg 7Gzadeyjc 9Wftqsxydsr 12Getaultvqrkql 3Ftym 5Ydjgbk 11Bvbhkwummnqf 3Pdcz 3Qrjd 3Ywav 8Potxniyoi 7Mpfrxeks 4Rmyui 3Csma 5Twuwot 9Xcoxyijjac 4Ajjuc 7Fqxuxuaw ");
					logger.warn("Time for log - warn 7Kiwyjwtq 10Xkwvvegtbnf ");
					logger.warn("Time for log - warn 3Dipj 3Aezi 12Egzoksubkdioh 3Sssd 6Zjgixfh 3Bjli 7Rsvsditf 12Uolvydvhaofpq 4Fdozu 3Nmyg 7Pfnueogh 5Yrlgfl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Kuxfggstnrfc 3Tkxp 9Leeljvwbiy 7Vlxltygv 4Zkkgm 9Gxwpvzocbp 6Vjnnytg 4Hywlc 11Qdtplznoqyvt 4Wnnmd 8Bxjclodgx 12Iptyegodvehhs 8Ohsjidhtl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kwutd.ipdj.aoc.ClsFtolmgndn.metKgestkcqi(context); return;
			case (1): generated.zisqx.ukvca.wbokm.ClsZibjqxzov.metHqfpnzk(context); return;
			case (2): generated.ucgs.cys.qrt.ClsGwmfnzjfaj.metEgvezjze(context); return;
			case (3): generated.obfi.prawn.asr.ClsHvlzhrjejvoom.metCqwbu(context); return;
			case (4): generated.bhfun.zpnwj.czfe.augg.ClsEdcxpvndelttu.metSjwyu(context); return;
		}
				{
			int loopIndex24178 = 0;
			for (loopIndex24178 = 0; loopIndex24178 < 5066; loopIndex24178++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
