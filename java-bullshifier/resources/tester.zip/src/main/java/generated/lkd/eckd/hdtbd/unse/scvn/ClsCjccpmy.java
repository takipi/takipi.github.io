package generated.lkd.eckd.hdtbd.unse.scvn;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsCjccpmy
{
	 public static final int classId = 259;
	 static final Logger logger = LoggerFactory.getLogger(ClsCjccpmy.class);

	public static void metQahumxsfmpvl(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valZoiwnqxbndm = new HashMap();
		Object[] mapValBvxwavwgyxd = new Object[2];
		int valLoreqerokun = 977;
		
		    mapValBvxwavwgyxd[0] = valLoreqerokun;
		for (int i = 1; i < 2; i++)
		{
		    mapValBvxwavwgyxd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyRoevydiseor = new Object[3];
		long valTpmynapwlyi = -2616284841502274381L;
		
		    mapKeyRoevydiseor[0] = valTpmynapwlyi;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyRoevydiseor[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZoiwnqxbndm.put("mapValBvxwavwgyxd","mapKeyRoevydiseor" );
		
		root.add(valZoiwnqxbndm);
		Set<Object> valBvunqobslcj = new HashSet<Object>();
		Object[] valVchftgymhhg = new Object[10];
		long valAhwnukmlxvj = 264464780356302803L;
		
		    valVchftgymhhg[0] = valAhwnukmlxvj;
		for (int i = 1; i < 10; i++)
		{
		    valVchftgymhhg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBvunqobslcj.add(valVchftgymhhg);
		
		root.add(valBvunqobslcj);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Bkgyrwh 9Pjstwpfdfl 4Kydby 7Jaeefsck 11Ibcxkzvjpbnc 5Hmhffh 5Ehkjid 3Ubde 4Bmman 10Umrruzfjtpi 3Dqtg 7Evmgkspa 3Ioww 7Cgacthyp 3Wpzk 3Bdor 5Xpjixx 4Xhzua 9Xvgykpdprx 6Iyhzztl 8Mowtvhvyd 5Cysqqy ");
					logger.info("Time for log - info 4Gaatq 9Rpeynsumzs 5Rggsqr 6Febgxxq 8Zcmoqrync 6Blfznzu 3Eohp 9Eatidzuyho 12Mlzsxxmdeqgbk 5Lknkhe 6Acpijwo 5Shgafn 3Lpwo 5Jrubwk 4Kfjfm 10Rzhzzvhttev ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Uefadk 7Hpoortva 5Dmcnna 12Rqqwpwfzsdlmg 6Qrrbtyd 7Zzfnydsa 6Wdkqmtd 12Gnpmcadwbibbs 4Quyoq 6Hwummhc 5Dxyywa 5Irabbk 7Unlecclk 7Ofclopfs 4Yprmz 7Iesfklmk 4Zhtjp ");
					logger.warn("Time for log - warn 10Swlifwouyey 5Ftcsih ");
					logger.warn("Time for log - warn 7Iuchqqna 4Zsvcl 9Pverdvevij 6Poqkhqg 3Nvpa 5Tilass 8Dfbiqcvre 10Wgrfomwqdup 8Vhxqdxhyw 5Ltqcpp 12Jjmqmawsxclmn 7Hzrvenaq 8Huzthnvzc 11Liezrydavuhb 12Ttgmpedmglcza 3Cjif 5Axfirk 5Xldzqn 10Qfsddxjsptv 9Bpdpxvsdra 11Yqopqnoqfwav 9Qmfonveban 8Qoyujtuhx 7Dztvtvpx 5Sqcjxu 9Obimdiccbu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Vmiohxyeroymm 10Pkriigzaonk 11Yulddwnctiqf 10Alpplddniww 8Jgfnkwfcg 9Hnigpcvett 7Ewihhmsw 4Dchro 8Jbessgryk 11Vgyarpcjkvbo 6Ixmszux 10Edcjyenjrhb 10Vuwzwcaipae 4Wheqw 9Gsztqnpzvh ");
					logger.error("Time for log - error 4Tbfez 8Dszyknubq 6Ajuyprw 4Oxphr 10Jqehflbtupc 11Pueehvvbjmpf 3Kxpa 10Zlogozjrcyj 5Zibius 12Abaxsnkpwstcv 12Cyjeavoibbcmi 10Mxtweevsfhw 7Fyguudhz 4Fiyxs 4Decnk 9Joxvnbhfgi 5Mujlsf 11Eycvomgkdrpo 5Scaphs 6Ucctoez 5Hjvpwa 12Fxtpyfbddpsco 5Mlocgj 9Ozoztqazjb 5Pkmhcc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.idpj.vmnmp.ClsRgyokulekkkb.metRovgxbargonqf(context); return;
			case (1): generated.liyl.sfhr.ClsNilzqakfd.metDymwfdjjlcu(context); return;
			case (2): generated.rjuw.mmbua.ClsRawvqxmhewbl.metBvnihykij(context); return;
			case (3): generated.ongb.lkxvg.dfa.pkoz.kbky.ClsZpuulcqafhvqyy.metSvcpwlc(context); return;
			case (4): generated.hgr.jgeh.ast.ClsBwtgykt.metGnslwfxjnxwudj(context); return;
		}
				{
			long whileIndex24484 = 0;
			
			while (whileIndex24484-- > 0)
			{
				try
				{
					Integer.parseInt("numOfpeglggyus");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varXqaftzfqsqg = (5003);
		}
	}


	public static void metYcdmbyork(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valYokwiewgmbi = new HashSet<Object>();
		Object[] valMxdwelpxcgp = new Object[2];
		String valJgtgleeqanr = "StrErhapbjpccm";
		
		    valMxdwelpxcgp[0] = valJgtgleeqanr;
		for (int i = 1; i < 2; i++)
		{
		    valMxdwelpxcgp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYokwiewgmbi.add(valMxdwelpxcgp);
		
		root.add(valYokwiewgmbi);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Qqimkblm 12Mvlazglocxopu 4Tkizd 8Hqjuzfpuq 10Ninyxzjdjyg 10Jnbgwotngqg 5Pktvxh 10Abxfvvbjxbx 12Mshfepiuehpgd 4Gsmpu 12Wlyxgjsocczta 11Nedzdcingcne 6Oojasic 6Vxjfkhz 8Lldngzuhl 10Dwrlhrazycl 12Jmvudzhbhzjmy 12Ortcemhgfkbvl 11Whpmlfuajmtd 11Lffwuzqzldxp 4Etncx ");
					logger.info("Time for log - info 12Clegstlgmvufc 7Lvdzxtgc 4Otdaj 3Qudk 10Xsxrxjebwld 9Gwngmajdxa 4Mjaya 9Emlszubnoc 4Kwcxo 8Aknzphgqz 12Uqutqlfvobulv 9Naccpbziew 10Unitqlvuxti 5Dxqrqn 6Blnysxz 10Xcnwlspywdt 5Oltdkq 10Jkmnmfbufez ");
					logger.info("Time for log - info 3Qipm 12Icsoanfksgwlq 11Xybgqsqojyuh 3Ygcn 9Gmmfvtpgla 3Fqsu 11Jjfbtonceamq 10Rlmniefkits 11Ambbiignwqfb 6Savmzxm 8Lbahfkzaz 11Rhvqqcnqqrsu 10Azmbpjxubwp 12Ntcjayacofqsz 8Kvcjmoslw 9Tzdxjkntiz 10Vipkbibazah 11Krrmkicvdlko 12Aaiufxntbziko 8Qmduhlpye 12Ptylbgcpdpwyo 7Vmvpzzat 11Znuznqqfgbwv 6Zmsickw 11Pgnbccpwcasw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Iuqfhtuustcc 6Qdzjsmp 8Wlrkgdtqk 7Ggnqblyv 3Ykxe 10Dnqdbidkgso 10Xoajblgfzme 6Wwsmqsv 11Lwmirpsihbjb 10Dbocraklsdm 5Lcdych 12Lvcehllrcxbvt 7Dcnyznwz 7Rueaffil 4Oiibt 3Vufo 12Yqlyhgonzjqeh 6Heppcwx 7Gcrugqxd 9Mwhitqpkqc 10Lmfwewzdegu 4Zqnxf 12Vnoyfasndilfc ");
					logger.error("Time for log - error 10Suvvlszsxcp 12Jrgnyqhdnerqr 5Okhbyf 6Injgxmx 10Tvlatwfepdx 3Xgzu 10Udtikhvyavs 8Ytioqgelp 7Ieefrjaz 12Sywrxjunpczia 8Tfxahnyvm 11Iijvoxrhgoet 7Twfdsvqt 6Qoerycc 9Pevwdufzfr 9Uaagmkielg 5Bggivg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wwon.szd.tew.ClsRzjcfflrioiqf.metGxlswbykyhhwq(context); return;
			case (1): generated.rorl.wuo.lqgdf.ClsUltodfmiuq.metZqbkch(context); return;
			case (2): generated.bnlmp.cvjtk.ocoo.ClsDyyxrbbjxtkmxe.metAmgdel(context); return;
			case (3): generated.erjvc.bth.rgln.usqa.ClsYyzexetbgpowz.metFvecfmslo(context); return;
			case (4): generated.kmtdc.slqlz.nmqcy.naaq.ClsKsliquh.metNmcayldfqz(context); return;
		}
				{
			int loopIndex24488 = 0;
			for (loopIndex24488 = 0; loopIndex24488 < 6015; loopIndex24488++)
			{
				try
				{
					Integer.parseInt("numPfsdgrfecxh");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metBnujb(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[3];
		Object[] valEmpoyezcfgx = new Object[6];
		List<Object> valXveibbggpas = new LinkedList<Object>();
		int valUtwvzbqcizn = 291;
		
		valXveibbggpas.add(valUtwvzbqcizn);
		int valCqqmlmqqadu = 527;
		
		valXveibbggpas.add(valCqqmlmqqadu);
		
		    valEmpoyezcfgx[0] = valXveibbggpas;
		for (int i = 1; i < 6; i++)
		{
		    valEmpoyezcfgx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valEmpoyezcfgx;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Vairqzbq 10Wfprknhbajt ");
					logger.info("Time for log - info 8Hqgyzluvi 7Ipnoaoho 3Iult 12Htbqjjuowjiha 8Dljwpromj 10Cpnddaroses 3Ftmb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Xwusxndqx 4Prvrb 7Horvuzwb 5Tbeyml 3Aukl 10Ddskaqljvml 6Toioofd 12Ldmtjeazucvwg 5Bebvmo 5Cyqqwx 9Xbtaqnsztz 6Jjprqpw 7Oqhxrzyn 5Ikrgbx 6Uxqxoho 8Rnmadowjg 7Wqiphyyv 10Pqsxsuubmux 8Bluxppnjh 8Jdyktafza 3Omsr 12Jssertrcgzwfg 12Ijvonnuqtluwx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Wsqyknceovzo 6Fpxngig 7Wwcgojaq 6Xiytsmh 4Rqsts 10Iuhguvtbfpi 8Pdvylndtc 6Aoebeeg 8Vnznzhtns 6Fmzbtil 6Yeyogtt 4Udnym 7Lypunhcs 6Ymrozum 5Pxrdra 11Oiihboahubtv 7Ubsflqaq 3Pwuo 5Snwwth 3Utkj 7Yqfsjnig 12Dlsuoyfhircek 6Qdaxlmy 4Desxw ");
					logger.error("Time for log - error 7Rudbjnbd 9Lpzqbgbily 7Rmmwrsrp 3Gpkz 5Bjkbcr 9Nddproseva 6Nlvohcf 5Uffebb 5Dowqkt 5Ezusgo 10Mfdtpxgjaxv 10Vpddxlhvgbr 6Vnayhwi 3Ltfe 5Ccaboo 8Jzfocwidf 3Eqfl 10Icfszsmruab 7Qbisdlpa 12Rgcrtxdscgoce 11Qtcvbhhvrwin 5Yfpbyv 9Paxsbqrdyo 12Rjwjpbsoozkia 9Ptiugkemrl 7Qdsrobpg ");
					logger.error("Time for log - error 12Vzlhyciygfdvb 4Dcuyu 4Gdntm 5Flnmip 12Duwvximjujjsu ");
					logger.error("Time for log - error 12Aozkoviklhlrr 9Mtxkuoaxhk 6Wctyuog 12Xlqzqvisbhnox 11Avubkpluhxlg 12Nxhrbqkxdaltq 11Hbfjwirinzrf 9Cpzlohcefi 6Uvismxv 7Bnrepszz 5Fewrls 12Jytonmljtammf 7Jeruuooz 4Nowyi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ymhs.ivq.mlr.cezkl.gzyiv.ClsKvdrph.metIszbhwn(context); return;
			case (1): generated.weide.dnna.unvd.vtw.pcbre.ClsExwicwtb.metHqnibperro(context); return;
			case (2): generated.vspck.scvf.gxvmo.ClsBudbedmvgnjpa.metHunirsyqpt(context); return;
			case (3): generated.jczh.tiox.sfe.qsygg.ClsFcpmoenzb.metEjlwxaxrxcgtq(context); return;
			case (4): generated.fdf.qdha.fywc.gjubl.dtsb.ClsBinezgxhqjfe.metBmbttdastn(context); return;
		}
				{
			int loopIndex24491 = 0;
			for (loopIndex24491 = 0; loopIndex24491 < 3258; loopIndex24491++)
			{
				java.io.File file = new java.io.File("/dirSyzfbxuvtit/dirNtibabpffnh/dirKnfkutrlbjr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex24496)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirSyiypgjyqhx/dirKtgupsoxmfk/dirFolfgherzmk");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex24493 = 0;
			for (loopIndex24493 = 0; loopIndex24493 < 7514; loopIndex24493++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metJebquacmhoywe(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valIvvgjdarjar = new HashMap();
		Map<Object, Object> mapValPjwafaygogx = new HashMap();
		int mapValSgwdtupzcbu = 797;
		
		int mapKeyKblzkkrdrbb = 810;
		
		mapValPjwafaygogx.put("mapValSgwdtupzcbu","mapKeyKblzkkrdrbb" );
		
		Object[] mapKeyJalweotwfqt = new Object[3];
		long valYwsuqlhzpaa = -2067798058425799427L;
		
		    mapKeyJalweotwfqt[0] = valYwsuqlhzpaa;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyJalweotwfqt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valIvvgjdarjar.put("mapValPjwafaygogx","mapKeyJalweotwfqt" );
		List<Object> mapValQkbajyncgcr = new LinkedList<Object>();
		int valZuztdxjhpkx = 787;
		
		mapValQkbajyncgcr.add(valZuztdxjhpkx);
		long valUclchrutcpz = -7637922125003114071L;
		
		mapValQkbajyncgcr.add(valUclchrutcpz);
		
		Set<Object> mapKeyWkyuejlfhrj = new HashSet<Object>();
		long valUigyjsfthxt = 2723750726153085722L;
		
		mapKeyWkyuejlfhrj.add(valUigyjsfthxt);
		
		valIvvgjdarjar.put("mapValQkbajyncgcr","mapKeyWkyuejlfhrj" );
		
		root.add(valIvvgjdarjar);
		Map<Object, Object> valPqwmwdttelm = new HashMap();
		Map<Object, Object> mapValGgqnveyhpvj = new HashMap();
		String mapValMbxewyjizop = "StrWrkvdcmivff";
		
		long mapKeyFelcnfwoyvi = 620986260640384828L;
		
		mapValGgqnveyhpvj.put("mapValMbxewyjizop","mapKeyFelcnfwoyvi" );
		long mapValFbvtbfvsxge = 1504741889362492097L;
		
		long mapKeyDkqnkjznxbp = -9133995384734996359L;
		
		mapValGgqnveyhpvj.put("mapValFbvtbfvsxge","mapKeyDkqnkjznxbp" );
		
		Map<Object, Object> mapKeyMrcqfeoqidz = new HashMap();
		int mapValIebzqhxlwfx = 899;
		
		int mapKeyMlahgvvjsxf = 662;
		
		mapKeyMrcqfeoqidz.put("mapValIebzqhxlwfx","mapKeyMlahgvvjsxf" );
		String mapValNrazwrlmivt = "StrWcetwuddbab";
		
		int mapKeyZyuwrrmovez = 970;
		
		mapKeyMrcqfeoqidz.put("mapValNrazwrlmivt","mapKeyZyuwrrmovez" );
		
		valPqwmwdttelm.put("mapValGgqnveyhpvj","mapKeyMrcqfeoqidz" );
		Map<Object, Object> mapValKuohjqsgbdt = new HashMap();
		boolean mapValYrplkpylbsj = true;
		
		int mapKeyXjuhiefwtwn = 786;
		
		mapValKuohjqsgbdt.put("mapValYrplkpylbsj","mapKeyXjuhiefwtwn" );
		boolean mapValLlmyprixtzb = false;
		
		int mapKeyVtfjqnzvowb = 230;
		
		mapValKuohjqsgbdt.put("mapValLlmyprixtzb","mapKeyVtfjqnzvowb" );
		
		List<Object> mapKeyQjmbtyyryuv = new LinkedList<Object>();
		int valWjhfyytabua = 532;
		
		mapKeyQjmbtyyryuv.add(valWjhfyytabua);
		
		valPqwmwdttelm.put("mapValKuohjqsgbdt","mapKeyQjmbtyyryuv" );
		
		root.add(valPqwmwdttelm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Katp 7Kxnjlxei 6Ngnfleg 6Hajjmru 7Pfucwynb 7Vtmyiypt 10Fylrkjuwtsr 7Fpgxdang 8Aiokjflgz 4Jizxt 4Flckh 12Uzdhppihdyvjb 3Dmjb ");
					logger.info("Time for log - info 12Dzipbahwttflm 11Ojrjkgtctuwo ");
					logger.info("Time for log - info 4Acdwf 10Qmtbptorbnc 10Etvlhyncmim 11Nkonvootdhqi 12Hrpfclwfzcfng 7Dfssgeup 9Vrscjezzxa 6Ohbhmce 11Ivuewkxfswdi ");
					logger.info("Time for log - info 10Ldprdcjoukv 10Yhlczzsnpva 5Djuidq 6Ikghrsj 10Qqvacbhorbt 10Uvzbfzhnrfr 10Ssimphlfrwf 12Dorfahqhhdahc 3Amgd 12Paeikbwwbmdcz 12Zfxwahpdnkwsk 9Kzacxyowgw 10Hrslsgzdjrz 11Biqdoeprzgqx 9Kdaugyfuxp 12Vnsyctfjfbofw 4Ewtzj ");
					logger.info("Time for log - info 6Ktwbidb 6Gcchoqo 3Zpjt 5Denyka 3Tmwc 8Egywpsjoq 3Fqsf 6Zsgvcfr 3Rbog 5Qegzrr 9Rxjngxihmf 3Mjen 7Bzfiqgth 11Vzrweshsojll 3Pxsi 10Aimwdieqsek 12Enbdcwwqbdwdg 9Sjwieepatc 7Xryhidwt 8Kmjqsnzgb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Mdrxrjubiaa 6Khbpqvj 7Fjzlweqi 4Cjqgt 10Rjhqkgtgzwx 6Loefqiw 12Fongyfwxxldtq 11Vxuxijwmtber 8Fkbsdmptk 12Dhewsdqcsgyrw 8Jwbpjordx 7Ttqbmeld 3Ftzk 6Pgconrh 4Exjen 12Drhpkpftuslxk 8Kgzifgqlr 4Npkiy 5Lyzxha 9Ydsikllykm 4Idcho 4Kjdoj 11Fknoavsjsmjk 9Ffpgckupfx 12Hammsrzpmscup 9Uqaxprniwc 7Dnfnwsih 4Dzyrl 8Xcwqzlhdw ");
					logger.warn("Time for log - warn 6Ajlnztm 9Vnxrgefkkl 6Dpiaciv 4Vugku 10Dqkfuewuovq 8Avgnwhfsq 12Pjrmnwvzzjhfl 7Ezhzfmwk 12Jvzpotkkiadvb 8Nsdtcafpy 12Yugptpjxqnznk 5Asuqgt 7Twsgijiy 9Pcmonoxfcp 4Islgx 7Jzttmfsj 8Eejnqdmwl 12Hoijapneuhkyu 12Whxvyocuyblmn 12Mratrgkovmara ");
					logger.warn("Time for log - warn 4Ltgnd 8Nnpdddkqv 10Hqnvilkozon 7Fcuphfon 8Afxqphewu 5Unqjmv 9Sfnmywzens 9Zrslveaihm 8Zzyzgdskq 5Gitgxm 12Sxbgctrcxegyz 10Ioxcbuacwah 7Xseoyunx ");
					logger.warn("Time for log - warn 5Lkunxf 11Fskucajuhizo 10Ivemykiqlxk 3Eopp 12Duvwowresdeuj 9Dedtczfmgb 10Etljbtdggxw 7Lxeiwphs 11Xbkhkalvympt 10Pcrivwonctf 4Awvgp 4Ldjne 11Bhjvybzgmnuw 8Hhvtkrjhq 3Xvth 7Orjwcsfe 12Nkgplvlbarnnd 9Mpixyuqegw 4Fkwmg 9Xswjvvqlzr 3Lwii 7Enrxeriw 8Qwtvcpkua ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Wqxij 5Eywaui 6Iyxvhgx 7Mygatamp 9Oicfaumptr 12Aobephovmvspn 12Htuxakxycucwu 8Iqqflmyoa 3Gghe 11Jrgbkqyughut 12Rjkdcpmuwpsbb 7Kqutjzmn 3Acdh 7Cnoidjyk 6Rdtympr 9Zjbswhzihu 12Qgfpdcedesvkf 8Scemsknwb 4Dvdmo 11Oxlvnjbekrpf 6Qaszvfe ");
					logger.error("Time for log - error 8Zhchzwyov 9Rnqulgcwhm 9Gknnfnesmn 7Erxmsmpd 4Cnrmo 9Brsiubfcqc 10Dgjopnjnwyu 8Xdzefznps 11Bjwhuxrqaxvc 6Rtpobfe 10Euihxxutpdf 12Ufkpkxhqxqyce 10Sqpjynnrwmk 11Pirvdocrkaiy 4Zaerg 10Hvpfjajqxjy 5Lfgmdq 7Vjcoglua 4Ypuyq 8Qdxfxicbb 8Nfawhvipx 6Fwurtqt 4Svrgm 8Wntaqijpc 5Orfiov 4Inprg 4Qtxei 4Eprpn 4Yxpmn 10Jyngdceaslz 3Enkr ");
					logger.error("Time for log - error 7Gtssvfze 6Cdojzod 9Saovewsvbw 5Ioooqb 12Gpmjpdkapmxeo 4Gijdn 7Bvfbwbkp 6Xxdcxsc 6Vfoeybb 5Hnruhi 3Qtqy 12Vuyqumyxfakss 8Izilrbrkp 5Vekurl 9Qwpntzgmvq 10Jnuzttyowkm 8Nbhnygpcq 4Gmpis 9Uinqclzlgb 9Egojyiegon 5Rwltac 8Gyzwpxcso 11Mpnixhhapxyz 6Dmlewvb 3Vfxx 5Ntonqx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xij.sqewq.cevz.qdd.iar.ClsAxzlzievw.metUvgcknurz(context); return;
			case (1): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metDcqlrafmtcoxm(context); return;
			case (2): generated.vfomk.ywmw.ClsYphqbuncz.metMivehrooaiow(context); return;
			case (3): generated.qwlax.zei.ClsAdxloruwrrth.metLkyzseqhzcwrch(context); return;
			case (4): generated.mrz.embg.gydr.vls.fvllv.ClsYrxhq.metPmjofrckzavphr(context); return;
		}
				{
			long whileIndex24501 = 0;
			
			while (whileIndex24501-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex24502 = 0;
			
			while (whileIndex24502-- > 0)
			{
				java.io.File file = new java.io.File("/dirFzciupxovwh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
