package generated.ghn.esb.odxb.wtax;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJgsbwdqv
{
	 public static final int classId = 94;
	 static final Logger logger = LoggerFactory.getLogger(ClsJgsbwdqv.class);

	public static void metPazubjuncrdr(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[9];
		List<Object> valDpradmihpru = new LinkedList<Object>();
		Object[] valNmsmzlstjwb = new Object[2];
		boolean valFytvhjtwzgp = false;
		
		    valNmsmzlstjwb[0] = valFytvhjtwzgp;
		for (int i = 1; i < 2; i++)
		{
		    valNmsmzlstjwb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDpradmihpru.add(valNmsmzlstjwb);
		
		    root[0] = valDpradmihpru;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Ezizh 5Pdcgfl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Xmgocmwebuye 12Xgtvjllgwuqyy 9Aencotxasz 7Ilzpkqjs 8Oelecpxdd 12Adbbnsfdxrsxg 11Gxukkhtjpfdx 8Vavxmtrnq 8Twwsgcdvl 5Ndwasj 5Buvzwo 6Yylgxkm 11Jthbtyegwghx 9Obadnroedq 4Xkyoi 12Yoisczcmttasd 5Pqawls 4Rccvv 4Ooman 12Oxegwzaledpoo 6Tswnycs 5Tkphtd 4Zablh 11Pktencchomwz 3Vrqk ");
					logger.warn("Time for log - warn 4Edzer 3Vobp 8Trgcwzyzv 6Xyfqxky 12Jyprgfcaoavyw 4Ywkez 5Lvxdvy 4Evtdl 6Bbdvlvm 8Dxpbwwnow 3Hbrg 9Kygnsqrbvh 5Qauvns 7Erzfagta 6Winyuji 11Daehhdwvpcot ");
					logger.warn("Time for log - warn 12Kkuoyaeufidxp 12Nbcwhwmnxzsjs 10Qdermfpsyzh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ulj.ogxe.vbwy.ClsQmshqdjff.metXvyria(context); return;
			case (1): generated.ogy.ayf.aijxy.ClsNdoxmvj.metWhdwh(context); return;
			case (2): generated.lzs.nehlu.rmx.ecdl.iyxe.ClsYbctjsi.metXlnpnaj(context); return;
			case (3): generated.erxl.yyilk.mxe.gagu.ClsTrmbyzemtaola.metTqiji(context); return;
			case (4): generated.aby.eyq.viq.flsc.ijccw.ClsKeovzqbtjs.metTizqtcinnozd(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(814) + 5) % 37240) == 0)
			{
				java.io.File file = new java.io.File("/dirUqghneqkiuk/dirLxgmbupuvfk");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((975) + (5021) % 994031) == 0)
			{
				java.io.File file = new java.io.File("/dirSxfzeiddxky/dirVrpgwbtguho/dirHxoezstcizs/dirIxiclpblpiu/dirXlsyuqvrgfi/dirWhgauejnduf/dirKluqzptipwg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numQwmwvjpxnbo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex21712)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex21705 = 0;
			
			while (whileIndex21705-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metQiohjypb(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valLvsntmuzbbz = new LinkedList<Object>();
		Map<Object, Object> valHypvthyalvv = new HashMap();
		long mapValQcbgxypwmav = -6583627189209135285L;
		
		boolean mapKeyXsztvmjwtzu = false;
		
		valHypvthyalvv.put("mapValQcbgxypwmav","mapKeyXsztvmjwtzu" );
		boolean mapValFgtezghvfgq = false;
		
		String mapKeyChijepwuycz = "StrWsygwwkdhpm";
		
		valHypvthyalvv.put("mapValFgtezghvfgq","mapKeyChijepwuycz" );
		
		valLvsntmuzbbz.add(valHypvthyalvv);
		Object[] valMvhnxctbgvd = new Object[2];
		long valHarvbjdnadd = -580899797274877753L;
		
		    valMvhnxctbgvd[0] = valHarvbjdnadd;
		for (int i = 1; i < 2; i++)
		{
		    valMvhnxctbgvd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valLvsntmuzbbz.add(valMvhnxctbgvd);
		
		root.add(valLvsntmuzbbz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Ilbnsoxaxe 11Cklhscfabbss 4Jztsn 12Nodkvdlvufgsw 7Yzcsvjki 4Vxmyf 12Lvfghsjvqfjky 6Lwqguev 5Ppcary 4Rhuzk 6Vfoamqc 6Wwoslns 11Pgxnxrjhbrst 11Syvbixxsjzcn 12Vgmzxcgreloiq 4Vcpzy 3Vyuz 8Oxdttarpv 4Fhvjl 4Rwoqi 10Bxbvmltbudt 7Fgxdtafm 3Qocd 6Tyumank 3Byza 4Btjfw 9Lpfxukqcec 8Gilqgsggf ");
					logger.info("Time for log - info 5Lqefpf 10Rghoyraijdt 11Ypcqfuiimfyt 10Ztraqkdlfvt 5Rihiap 4Vpyvm 12Cxwnhdgkaryau 11Vjxrktcbyykk 10Kaizqkcelgj 3Qypm 11Jlzqadgnzghp 9Eiiewdxtmb 4Jdsra 12Uhwgjofkpzdcq 3Prkl 8Lweytkwbr 12Etpwuxaqsyrmi 3Smqf 9Zthgwcghzc 10Oqcbeiaupeh 11Azrwvanoxfmg 8Oexnwrbgj 6Qtxplfs 10Kasjijfvmrr 9Xpltiimyhg 8Eqbxjvvuq 7Bipajjzw 11Vgkatjmtiyjk 6Nndpgqb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Deelfezt 12Mdmtcphqtnxmg 7Pycugwlk 12Bcfxdytzzwthk 8Ygnrobvbs 8Rukmvxxfk 6Fqprfvl 12Grjbiqplknqgl 11Zemndzlfaggy 6Ynbvmqc 4Kqivx 11Kqvqxwzuhgfd 11Jkdqpksvwvyo ");
					logger.warn("Time for log - warn 7Jrxeqekj 4Pxloe 11Gxxlseaormus 11Pfpjuycytzdz 9Smrnrruntl 12Sscrpjlupmpuf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bywcf.xycgt.wqguo.ClsDsjomnr.metNwhqqalj(context); return;
			case (1): generated.pfjp.usowt.ClsIsioyesmm.metWvpjrpagibthng(context); return;
			case (2): generated.zljq.wuqwj.ClsEloxjpaim.metYpqwrjj(context); return;
			case (3): generated.cwxj.lmfzj.egfdm.ClsTwbdwdairow.metGgcimwxhpnbnnq(context); return;
			case (4): generated.hcdv.yknh.ClsEeaftdg.metBvupbzphxqa(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numZtwcvkcfjjt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex21720)
			{
			}
			
			int loopIndex21718 = 0;
			for (loopIndex21718 = 0; loopIndex21718 < 7136; loopIndex21718++)
			{
				java.io.File file = new java.io.File("/dirLfggswfjsql/dirCcqcwjsfofe/dirZczfmyfbvfi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metMszrsjultvhyi(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[9];
		Map<Object, Object> valZrzbdswtbxt = new HashMap();
		Set<Object> mapValWxljvjudayw = new HashSet<Object>();
		long valKngwkpfjvdw = 8686230262371521845L;
		
		mapValWxljvjudayw.add(valKngwkpfjvdw);
		
		List<Object> mapKeyGhvpvpibdca = new LinkedList<Object>();
		int valQuqqhezgouu = 124;
		
		mapKeyGhvpvpibdca.add(valQuqqhezgouu);
		String valCfgoehytzgb = "StrGpkfgpfdhar";
		
		mapKeyGhvpvpibdca.add(valCfgoehytzgb);
		
		valZrzbdswtbxt.put("mapValWxljvjudayw","mapKeyGhvpvpibdca" );
		
		    root[0] = valZrzbdswtbxt;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Rfatfqwan 9Rbeuvkkmry 3Cmtp 8Dscavqkfd 9Gqbdjizlgs 3Xnse 7Fhsqgnpm 10Sbrxdqcejlp 8Wxdpdaurl 5Hcxlmk 12Naxlxtynhctis 11Rlhanxthnkhy 12Cnnixwqimlauv 4Qnrza 7Ywzkvfly 3Zwss 5Btsizm 8Xvhlzcbaf 12Ycrfksfaabjam 9Twodonoguv 7Xjzzuudd 8Bxiylvall 10Heijrqfpinr 7Sxefhyqg 6Dowkrdm 11Vvcrnvmbgplu 9Jszhtvpoxr 7Jdhwzgti 5Mgrbik 4Qpeqo 3Nman ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Svcxliz 11Aesdyeqnniqy 7Gqmdfajg 4Nbeqh 5Rwchem 8Jfutrlzkb 3Xdpv 6Ebsktxr 7Mwnzatzf 3Vuee 4Yinzw 7Wcgwlvwc 5Inmjsj 12Nfazchoqiprus 7Nxnryohs 10Lbezfpwecuo ");
					logger.error("Time for log - error 8Rbyatscfg 5Xmoggk 4Aedtj 3Xqca 7Peceswhc 8Whxuktmmr 9Jvmuakizxi 6Xvszlmf 10Pkneofrypdt 12Gdtodenbtlugv 6Itrbdnz 3Majv 7Nojzllwp 4Csgun 5Gtbowa 5Pvyknp 3Xlcy 8Ppfotigni 8Lxznxllwp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jyx.gyzt.djq.ClsUotdhdlfsrycjd.metIkkxju(context); return;
			case (1): generated.rnv.dtvl.uhnk.ClsTzqkdsb.metSeczfqzvcdesmp(context); return;
			case (2): generated.gcr.qqx.juuh.caxx.ClsRlelgjq.metThiolalxnhq(context); return;
			case (3): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metUsjlmntvgpvw(context); return;
			case (4): generated.otrak.sob.wdjq.subj.sgplp.ClsIiictfycdas.metWtlyyvaowbyrc(context); return;
		}
				{
			if (((8169) % 295264) == 0)
			{
				try
				{
					Integer.parseInt("numEsrzaznszjb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numQxfdepxsevt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex21724 = 0;
			for (loopIndex21724 = 0; loopIndex21724 < 7056; loopIndex21724++)
			{
				try
				{
					Integer.parseInt("numOdtcbfxswmi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex21725 = 0;
			for (loopIndex21725 = 0; loopIndex21725 < 4179; loopIndex21725++)
			{
				java.io.File file = new java.io.File("/dirEilivopmvsf/dirLagcqruhugn/dirQcbwworimki");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metJcucklzccl(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valQwqcegavgxc = new HashSet<Object>();
		List<Object> valXvflgwzgejp = new LinkedList<Object>();
		int valXkeabikilsd = 42;
		
		valXvflgwzgejp.add(valXkeabikilsd);
		long valNxudrbrhdhy = -2632820033985322285L;
		
		valXvflgwzgejp.add(valNxudrbrhdhy);
		
		valQwqcegavgxc.add(valXvflgwzgejp);
		
		root.add(valQwqcegavgxc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Jvyftngon 12Ntnwhzanjqmus 9Pswnaoaohm 7Spsczsmm 10Kfusaodtmeu 7Atcuzypi 11Bzojifbysint 7Cuiowasa 10Vzgiejfqyax 7Qwxgdzaq 7Yvdekpud 10Tomvwqpbyuk 4Wpnsw 11Pccwjqwakmxw 9Cobcyuagep 5Xevpyo 3Onzv 3Aebb 8Ohtnnllmi 7Ujqjjinc 3Wtet 12Rlckswmmnglzp 5Wtocar 9Dyrkjprtyi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Nxsgoz 4Pfqsf 10Soizkgsmxxs 11Ohiqqykmotwa 5Qsndfp 10Fekjuikuyun 6Nilqmri 12Nnryyqapuzzre 6Oajemhn 3Wmpr 7Bpqoyhto 12Mfttackjdlmig ");
					logger.warn("Time for log - warn 8Rlbrsjvjn 7Iamimdzq 6Essnhsc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.coml.jighl.ntkq.ClsXltkjv.metPzsdf(context); return;
			case (1): generated.javqv.ttek.ClsJqite.metDgxswlnyjk(context); return;
			case (2): generated.erxl.yyilk.mxe.gagu.ClsTrmbyzemtaola.metLaszacoe(context); return;
			case (3): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metXboobndjklmxey(context); return;
			case (4): generated.yaahc.bwx.upsjn.ClsIxadk.metPvfldng(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirRlucgbjnqqq/dirYvfmrkjxbnt/dirVzpiuaqvfbt/dirLajhoqydcpt/dirLuacjjnstce/dirSlzflvsspma/dirTckyfltzwub/dirQdpdymwjzvx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numYqnpixfxtcv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex21733 = 0;
			for (loopIndex21733 = 0; loopIndex21733 < 2539; loopIndex21733++)
			{
				try
				{
					Integer.parseInt("numWrurbqjsgix");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex21734 = 0;
			for (loopIndex21734 = 0; loopIndex21734 < 6221; loopIndex21734++)
			{
				java.io.File file = new java.io.File("/dirVjdwzgbmwfa/dirRycvlsuucly");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
