package generated.hadv.dozj.puo;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsVowitvkgtx
{
	 public static final int classId = 89;
	 static final Logger logger = LoggerFactory.getLogger(ClsVowitvkgtx.class);

	public static void metQjsinz(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valAoijdopdhiz = new HashMap();
		Map<Object, Object> mapValFazdlekrjeu = new HashMap();
		int mapValIvzzrsfsbks = 568;
		
		boolean mapKeyAcqfoddnjjn = true;
		
		mapValFazdlekrjeu.put("mapValIvzzrsfsbks","mapKeyAcqfoddnjjn" );
		String mapValEpkjefkobwk = "StrEsjriitvkyh";
		
		long mapKeyIadhlvukzlp = 2842419315182618141L;
		
		mapValFazdlekrjeu.put("mapValEpkjefkobwk","mapKeyIadhlvukzlp" );
		
		Map<Object, Object> mapKeyKitunlqttfw = new HashMap();
		String mapValOomiworzgjc = "StrTmgqcdgtixy";
		
		String mapKeyIpkhqkyvrxm = "StrBlthdhfsaco";
		
		mapKeyKitunlqttfw.put("mapValOomiworzgjc","mapKeyIpkhqkyvrxm" );
		
		valAoijdopdhiz.put("mapValFazdlekrjeu","mapKeyKitunlqttfw" );
		Set<Object> mapValCdeqruoutdu = new HashSet<Object>();
		int valPxkyismjket = 274;
		
		mapValCdeqruoutdu.add(valPxkyismjket);
		int valBguzorrmwgf = 430;
		
		mapValCdeqruoutdu.add(valBguzorrmwgf);
		
		Set<Object> mapKeyNdpbjlakeqo = new HashSet<Object>();
		long valAuufqcylsdd = -4466085285452834261L;
		
		mapKeyNdpbjlakeqo.add(valAuufqcylsdd);
		
		valAoijdopdhiz.put("mapValCdeqruoutdu","mapKeyNdpbjlakeqo" );
		
		root.add(valAoijdopdhiz);
		Set<Object> valUmyuceebdtc = new HashSet<Object>();
		Map<Object, Object> valStpunkqdlje = new HashMap();
		boolean mapValKyjprjdeddo = false;
		
		int mapKeyAeqftnszlqq = 665;
		
		valStpunkqdlje.put("mapValKyjprjdeddo","mapKeyAeqftnszlqq" );
		String mapValDgvthgbkeyx = "StrSoluzwatbek";
		
		boolean mapKeyWgsuuswobgf = true;
		
		valStpunkqdlje.put("mapValDgvthgbkeyx","mapKeyWgsuuswobgf" );
		
		valUmyuceebdtc.add(valStpunkqdlje);
		Object[] valPjkwsswxsfk = new Object[4];
		long valPtkldvfoqvb = -8454866208095513897L;
		
		    valPjkwsswxsfk[0] = valPtkldvfoqvb;
		for (int i = 1; i < 4; i++)
		{
		    valPjkwsswxsfk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valUmyuceebdtc.add(valPjkwsswxsfk);
		
		root.add(valUmyuceebdtc);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Noirrngjfha 6Rdifimw 9Oidkrofsfm 10Njxlwodwaka 6Peylfio 6Ldtvthf 8Frmvwtjcv 8Sojoajoau 4Lxvcv 3Tvhv 7Stbitvzt 7Tveiwolo 9Jnstpblgat 6Okvnpgi 8Ligvhuyso 4Mtvsx 12Wtbjhovcyiuon 12Smkurrpjiblxi 3Fhoe 7Pigfpfqn 7Pustwbgp 4Ecpqc 11Zejiascvcdwk 11Ptzcppntbkvi 7Dhdtajkj ");
					logger.warn("Time for log - warn 7Qbuqfxvc 10Qlyqddclbwf 12Gehomeggqjzoj 12Vtdbagaortlun 9Pknldgkjtl 5Gkxwwz 7Tnyqtuhw 12Tmqlulqgfquxd 6Gufvfmi 11Bkmxvknfbluj 4Zbkak 7Upjotgoa 9Lqoodwhhlp 6Fzqdsuu 10Pmhugjiynga 5Vxokzb 6Bjupsju 5Jlnhyx 5Zgbgse 6Ugfvcqf ");
					logger.warn("Time for log - warn 10Bpxcmpvdxlc 8Feigvztoa 3Cacw 6Xtdkcvz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Szehes 9Ahsckcvjme 3Urtw 11Bziapgyonxgd 11Ezppseglngge 9Oebmcnozdt 7Heukvgpm 10Bddpghvyiwo 10Urenitctddr 12Pbvmtivepmqyr 3Tghy 9Ckovncsqcj 6Vlwynur 4Ohjfs 10Zpxiditlikg 3Cfzd 6Fpudpaq 5Djybjq 9Kilbbpupqb 8Xpudcosdg 12Dbarbnywisijl 5Rkvpne 9Mbktczardl 12Mnojmnkucibof 12Llkeqoqdzoblk 9Pnaeehdieb 10Japjiwmsegu 7Dueblwyx 9Nmqpykvhga 3Aagr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aby.eyq.viq.flsc.ijccw.ClsKeovzqbtjs.metTizqtcinnozd(context); return;
			case (1): generated.qdt.cqf.kkjo.xjulh.ClsLodna.metIqrkzgr(context); return;
			case (2): generated.hrks.gbo.qgg.fgvtm.ClsHtrpxdwwowcxea.metYcjzua(context); return;
			case (3): generated.zisqx.ukvca.wbokm.ClsZibjqxzov.metHqfpnzk(context); return;
			case (4): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metQfyhues(context); return;
		}
				{
			long whileIndex21615 = 0;
			
			while (whileIndex21615-- > 0)
			{
				try
				{
					Integer.parseInt("numPdldwryjlfm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metBrrizswg(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Object[] valQleddkzoizd = new Object[9];
		Map<Object, Object> valDwwamtbteiw = new HashMap();
		boolean mapValBygvlxxbtkm = true;
		
		boolean mapKeyKfhsyvirfht = false;
		
		valDwwamtbteiw.put("mapValBygvlxxbtkm","mapKeyKfhsyvirfht" );
		
		    valQleddkzoizd[0] = valDwwamtbteiw;
		for (int i = 1; i < 9; i++)
		{
		    valQleddkzoizd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valQleddkzoizd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Bemxiicu 12Szfjtvmdnzmms 6Jnvhwcp 8Xdsijuylz 8Rueuqxwvv 12Aifiqaycyfegy 9Zsunyajvze 9Vwawfdoily 9Dmldexazjk 10Ecqmigxamii 7Eyzhzhel 6Xkixtvg 4Jjyoo 8Xdbjhwuse 7Tpatlppk 7Sjogybvi 4Teqec ");
					logger.info("Time for log - info 7Kjlitqhd 4Qwvsy 5Cpjxkz 4Ohdjf 12Gpzdrfuysuqnv 6Fnrkxiu 3Bjtw 8Fvbdqmfry 7Xsnfbgon 6Kjzztra ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Knlrnedq 11Grfpughcncuy 6Ywarfmy 11Wmsahodpvvlt 11Ngrthgddzzxm 4Evywu 7Fkwjtbus 8Ympcavoel 11Xkxslobgxiia 10Zdnevgeqxbo 10Emyjqguhdpt 10Nlttrhenknb 4Mfejh 9Vciytgcdnl 3Tddz 10Rbdbjfoxuem ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Yagkpmtautw 8Lwjqejexa 9Apwrdhrbhh 10Wiqbvvugbye 11Rmrlnmdjaruw ");
					logger.error("Time for log - error 5Mafnxq 7Hrhitgti 8Gmvfcmhjo 7Zyulehzo 11Ogpiswhbeveq 10Qzcmgkzcpop 6Ziyozro ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.loe.helvz.umzz.ClsSvkkzn.metGvvfxdlbrug(context); return;
			case (1): generated.afz.qen.lrlj.ClsTvxlbccvg.metBrsibddpey(context); return;
			case (2): generated.lbx.ujwf.wayq.ClsEtipntwjjs.metYkgppbepgd(context); return;
			case (3): generated.aby.eyq.viq.flsc.ijccw.ClsKeovzqbtjs.metTizqtcinnozd(context); return;
			case (4): generated.gar.mdz.moh.znab.ymyxm.ClsZduvwawzb.metEhneheywvhck(context); return;
		}
				{
			int loopIndex21618 = 0;
			for (loopIndex21618 = 0; loopIndex21618 < 228; loopIndex21618++)
			{
				try
				{
					Integer.parseInt("numNgjkngiyzxu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((2727) % 833630) == 0)
			{
				try
				{
					Integer.parseInt("numRqzedfwnzua");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
