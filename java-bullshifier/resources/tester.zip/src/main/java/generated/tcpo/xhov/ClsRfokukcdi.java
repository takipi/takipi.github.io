package generated.tcpo.xhov;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsRfokukcdi
{
	 public static final int classId = 184;
	 static final Logger logger = LoggerFactory.getLogger(ClsRfokukcdi.class);

	public static void metPgyzztnxhblraq(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValGzrockcoagt = new HashSet<Object>();
		Set<Object> valHphhjxbakje = new HashSet<Object>();
		String valOxhrqycljuz = "StrMychutopydi";
		
		valHphhjxbakje.add(valOxhrqycljuz);
		
		mapValGzrockcoagt.add(valHphhjxbakje);
		Object[] valBuyrxdrjraw = new Object[7];
		long valWzxljwrqzlj = -1726128135939843513L;
		
		    valBuyrxdrjraw[0] = valWzxljwrqzlj;
		for (int i = 1; i < 7; i++)
		{
		    valBuyrxdrjraw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValGzrockcoagt.add(valBuyrxdrjraw);
		
		List<Object> mapKeyYyuburuemxl = new LinkedList<Object>();
		List<Object> valQlnfdxniakm = new LinkedList<Object>();
		String valDbfhmftmanw = "StrGmyyvcznajm";
		
		valQlnfdxniakm.add(valDbfhmftmanw);
		boolean valShqmarjqryk = false;
		
		valQlnfdxniakm.add(valShqmarjqryk);
		
		mapKeyYyuburuemxl.add(valQlnfdxniakm);
		Map<Object, Object> valCzcobqyjdeg = new HashMap();
		boolean mapValNtgedyfocgf = false;
		
		long mapKeyBjqvndbdtzl = -4765271336098635708L;
		
		valCzcobqyjdeg.put("mapValNtgedyfocgf","mapKeyBjqvndbdtzl" );
		long mapValXtewtoiuchn = 3453332266733613393L;
		
		int mapKeyNkvfeshbudl = 673;
		
		valCzcobqyjdeg.put("mapValXtewtoiuchn","mapKeyNkvfeshbudl" );
		
		mapKeyYyuburuemxl.add(valCzcobqyjdeg);
		
		root.put("mapValGzrockcoagt","mapKeyYyuburuemxl" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Tzuwf 10Enwvciiasdu 3Ysah 4Rjkmj 7Obsasiki 11Lgtgdqsyzyrw 11Frqhhllrhnwy ");
					logger.info("Time for log - info 12Ydrusyiqkrhus 5Pquihx 6Vhuouha 7Woxudjfv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Ixsm 5Bejwmx 6Czeyoot 10Vbxefkdbbph 11Zvhvzurqhwdk 10Avpbbcpbthp 5Sacnon 10Hexksxwxunf 6Xgnlaft 7Ftkgkonp 4Gbmrg 7Zcgzslhf 9Doflfiuhly 4Wxulq 6Jwgfvwk 10Dhopavkqzwo 3Kddl 5Slipfk 4Soarh 8Ngmzyelzl 3Hdte 3Levh 3Ipvu 10Rpyfqjsjhdc ");
					logger.warn("Time for log - warn 8Xzslxmmgr 12Zscrjoijqvbmd 9Swcwykzbgs 12Takoukymsqxwz 10Cedrsysyxdc 10Payvqjhwejh 5Tejvew 4Vknhl 5Uhsfgv 10Wwpydyiqpzg 8Fmhcvpeyp 7Rmrvzwac 11Byiitppjtmiz 4Kbzuz 3Qmni 11Ksifulfkrcse 9Uqjumpqntt 9Jdpqdyxbgv 8Wvrutjftd 3Gqgi 12Iezwflusbiiar 3Llle 9Cwyevlzrhu 9Hjayfphoyx 8Jttkuykza ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Pretxpy 11Iwewkwbdtfuh 11Lvwzfzcxpfmj 8Gtrarjeos 9Qnkpcfyiwe 8Almhejjbr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ldtgt.vdfx.cdz.lkx.ClsLvvwnymti.metSmshnclxqxhvn(context); return;
			case (1): generated.nmwme.qnfne.zsgam.zytf.yqrto.ClsDkqpghfzzf.metFtplshpnymzm(context); return;
			case (2): generated.xbfov.nkh.ClsAkppmbind.metCoxqxndopdgbb(context); return;
			case (3): generated.godw.hlszo.mtqbt.shx.tbgwd.ClsMygvrmsqnwlsdw.metUxxnltxclfyjd(context); return;
			case (4): generated.uym.yiu.voiig.deif.ClsUwvuontynja.metIvjieifumyhc(context); return;
		}
				{
			long whileIndex23271 = 0;
			
			while (whileIndex23271-- > 0)
			{
				java.io.File file = new java.io.File("/dirOsfjmpdemgt");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((9218) * (whileIndex23271) % 686350) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex23273 = 0;
			for (loopIndex23273 = 0; loopIndex23273 < 160; loopIndex23273++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metFyxdxe(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valXdjzigwzhwx = new LinkedList<Object>();
		Set<Object> valGzhukrtkynt = new HashSet<Object>();
		String valJzkfkswtijh = "StrIneetumccbn";
		
		valGzhukrtkynt.add(valJzkfkswtijh);
		String valLesolebwfaf = "StrDhojrokpsoc";
		
		valGzhukrtkynt.add(valLesolebwfaf);
		
		valXdjzigwzhwx.add(valGzhukrtkynt);
		Map<Object, Object> valEpladyczfjh = new HashMap();
		boolean mapValDckgetqsyzi = false;
		
		long mapKeyEdjfotlweya = -4089663211219722582L;
		
		valEpladyczfjh.put("mapValDckgetqsyzi","mapKeyEdjfotlweya" );
		
		valXdjzigwzhwx.add(valEpladyczfjh);
		
		root.add(valXdjzigwzhwx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Dpukqfajbcezq 12Ayqvljeskvmgg 3Ywwr ");
					logger.info("Time for log - info 3Mnbz 7Hbpzfoyl 7Bqcnqchw 8Coohzenqt 11Xoufaboaruun 4Zchdc 4Amttl 12Ysnmijydzbqac 4Alcyx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Pbjowpqeiopwu 4Pcmkg 6Vwntshk 8Vynupzckv 10Cnstizlmxgr 5Cdsxaj 5Cbbkav 3Rspe 3Ksgt 6Gtnetgi 12Dktigpgqgklyr 11Ovuqwakwonuy 6Peodctg 12Zsdfwvdsynpry 6Zdqjsif 9Zzvpbveikm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Erirubnvd 3Hiuc 5Kzvvbo 5Udwajc 7Bbxtuvyc 5Dxljws 10Ujzwsnczzqo 12Kboxlogtfxkmj ");
					logger.error("Time for log - error 9Nnrgifdztg 5Mwptka 11Auszejkexjgq 6Dwpgjhr 5Ytzdqg 12Uiqjutzvmjerf 10Rsoyudszbyh 4Nlalg 3Soio 5Qnrdok 11Lbwcywxueddw 3Nhbt 9Cpejimqplu ");
					logger.error("Time for log - error 7Xtawyvrh 5Wziqzu 4Eezal 9Jampedyrbu 10Loqkrkrlmbk 5Oozeme 11Rotejwvstkst 10Cbuexuxvdzr 5Isvqzb 8Odtncjelq 11Mopqvqqckxwf 4Uxsas 5Fyumbc 4Mgvlm 3Cptf 5Pllbhf 9Cleprmkybj 8Skmcdebnx 10Xiaozlkoxec 8Xbrxzvjqu 4Qctty 6Vxgzagh 10Otmejzfijxh 10Jicjqnvmooy 6Wmjgzik 6Cyuvnln 9Ctgdojjydk 6Fcfsgyg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lxeoh.qnh.crznc.ifldw.owge.ClsJaitfhoyoqqri.metElosoop(context); return;
			case (1): generated.gfhvs.nuhuq.qbk.rwbku.erqpl.ClsOuzdnnqrt.metYemauozpyth(context); return;
			case (2): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metZlaxbquc(context); return;
			case (3): generated.spdv.axe.ClsZyjdutdtmcu.metOeqhmr(context); return;
			case (4): generated.fpa.lsm.ClsOulug.metRvwreotu(context); return;
		}
				{
			int loopIndex23280 = 0;
			for (loopIndex23280 = 0; loopIndex23280 < 4294; loopIndex23280++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex23281 = 0;
			
			while (whileIndex23281-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metWncxy(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valHwcfulbzlct = new HashSet<Object>();
		Object[] valRlpftfmofqc = new Object[5];
		long valFunbgcqejkw = -5418090422177555395L;
		
		    valRlpftfmofqc[0] = valFunbgcqejkw;
		for (int i = 1; i < 5; i++)
		{
		    valRlpftfmofqc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valHwcfulbzlct.add(valRlpftfmofqc);
		Set<Object> valUrxyryzozdm = new HashSet<Object>();
		int valBplghrtdvcu = 275;
		
		valUrxyryzozdm.add(valBplghrtdvcu);
		
		valHwcfulbzlct.add(valUrxyryzozdm);
		
		root.add(valHwcfulbzlct);
		Map<Object, Object> valRartldmwssa = new HashMap();
		List<Object> mapValMnbxkyyvdxi = new LinkedList<Object>();
		int valSvhqebxplai = 363;
		
		mapValMnbxkyyvdxi.add(valSvhqebxplai);
		
		Map<Object, Object> mapKeyJsxcxhxyfqr = new HashMap();
		int mapValNqpeamatxal = 904;
		
		String mapKeyXyiyjapgput = "StrKdtnxhcuvkk";
		
		mapKeyJsxcxhxyfqr.put("mapValNqpeamatxal","mapKeyXyiyjapgput" );
		String mapValXyezloqpmkl = "StrMzsenihlzus";
		
		String mapKeyPkbtsflkgdu = "StrOphbkguzuqo";
		
		mapKeyJsxcxhxyfqr.put("mapValXyezloqpmkl","mapKeyPkbtsflkgdu" );
		
		valRartldmwssa.put("mapValMnbxkyyvdxi","mapKeyJsxcxhxyfqr" );
		Map<Object, Object> mapValAoogcfrnpis = new HashMap();
		long mapValWxxannzogzu = 8953457610157274118L;
		
		int mapKeyPqbcacaiknr = 955;
		
		mapValAoogcfrnpis.put("mapValWxxannzogzu","mapKeyPqbcacaiknr" );
		
		Map<Object, Object> mapKeyNcgvhwkcpab = new HashMap();
		long mapValJhkdwfsahfo = -4648678419227640825L;
		
		boolean mapKeyTqxxxxbwbha = false;
		
		mapKeyNcgvhwkcpab.put("mapValJhkdwfsahfo","mapKeyTqxxxxbwbha" );
		
		valRartldmwssa.put("mapValAoogcfrnpis","mapKeyNcgvhwkcpab" );
		
		root.add(valRartldmwssa);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Ksalk 6Ubbxvmm ");
					logger.info("Time for log - info 7Urfkgdub 3Geby 6Vkjcdcg 12Udqiffvtooylw 8Jwqbkgkxr 7Azfnlkos 5Czkbki 12Aufjonrynlgls 6Mpmbild 8Zzwnwoupq 10Nydywyulmrf 8Zljqwasan 8Ycfnbhykw 9Ybybzqfsfw 8Fvcxruope 10Oygglhlynhp 7Pibyoiob 7Pfkviwiw 10Euqjvhlamxf 8Qjmilzyja 8Xzwduuoef 6Jiuwfld 7Fjqjboxc 3Buuu ");
					logger.info("Time for log - info 6Oecdehc 8Lpzufvato 3Agho 6Gepclge 5Ztvflh 10Zzktfywxmvs 9Stltrqcxwb 7Ncoyejvt 5Vgtzzz 10Ietmdmxgkaa 9Lneaclabag 12Olyxcxlumpalt 11Pdwulzilxhum 7Grvdxiqr 9Fjeibwzrkg 10Htlxbjvjbfy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Abtvgwv 7Sbhkxjir 11Gwcgilqycjuk 9Jvksjoqrjs 3Gjcf 8Yuihogsov 11Sttxhmbltgri 11Vpfiakzcvzed 10Lewbiaceuuv 6Rebmxyx 4Pgqhw ");
					logger.warn("Time for log - warn 9Ikxtdmxzdq 12Rmsxoqirhclab 7Zqwbzhqb ");
					logger.warn("Time for log - warn 10Egwrncpmulp 4Bnlyt 6Uuamwwm 7Zxhkeqom 8Thdmlcugi 7Liewfuxy 5Oyyciz 10Osbjpxzjluj 5Mcqpiq 8Outpfdchb 11Zmqbwpgxjnle 6Eqzytgr 10Yfamdcbiazw 12Vmphvuucvhoup 9Wzyqadbnnw 6Uequzzh 5Nelnfp 7Ilnqhwyi 11Aadkaqecqlmf 5Fmbvhg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.eob.tzj.qiec.ClsEnjcnowop.metRglvwndsjd(context); return;
			case (1): generated.nxf.wvris.vmp.ClsGllyounxce.metExmyrcamcnqvv(context); return;
			case (2): generated.vqli.xqs.ist.rcg.ClsUlfrrjkk.metUracnapyxnrd(context); return;
			case (3): generated.bftm.jkb.lcr.ctpvk.ClsYfbhukzct.metRefjrhfmiyvoq(context); return;
			case (4): generated.nrrh.nxnu.xat.kha.ClsLoiagobs.metImjogkxzrsynw(context); return;
		}
				{
			long whileIndex23285 = 0;
			
			while (whileIndex23285-- > 0)
			{
				try
				{
					Integer.parseInt("numFsmzevzlabk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varHywoakwwirr = (Config.get().getRandom().nextInt(753) + 6);
			int loopIndex23287 = 0;
			for (loopIndex23287 = 0; loopIndex23287 < 5510; loopIndex23287++)
			{
				java.io.File file = new java.io.File("/dirKqkajdhszxo/dirNpgdziawklf/dirRmlgqgxabye/dirSwbrrjpialt/dirHmrzexgkrup/dirUnvqaeyzjqh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metFrfxj(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valFokcipmqbtj = new HashSet<Object>();
		List<Object> valDaeaouklhlv = new LinkedList<Object>();
		long valFbmqxzfkoyn = -1009782866823709790L;
		
		valDaeaouklhlv.add(valFbmqxzfkoyn);
		long valXbxarepyumb = 5962165984756304141L;
		
		valDaeaouklhlv.add(valXbxarepyumb);
		
		valFokcipmqbtj.add(valDaeaouklhlv);
		Map<Object, Object> valQramwufapqp = new HashMap();
		long mapValIcqokzlzvdz = -1548572679690517557L;
		
		String mapKeyAuunmyjzgny = "StrUpehlttlycn";
		
		valQramwufapqp.put("mapValIcqokzlzvdz","mapKeyAuunmyjzgny" );
		
		valFokcipmqbtj.add(valQramwufapqp);
		
		root.add(valFokcipmqbtj);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Filwhfb 11Xqjyonnbslut 10Cxhqfbwdnvt 11Rvifbxjogbdl 4Zfyek 4Ovgct 12Pfntxzirfmejn 10Qnhftbnsdsf 3Ukic 3Fjcx 3Ceru 6Xaunudu 11Orydawvuhrfb 11Baextwbpnhoc 6Nfdqvug 12Cgzbigolqlunt 10Touiuctbymh 4Byxok 4Rjafg 7Yrrwyesl 3Nhcw ");
					logger.info("Time for log - info 6Bvcdvuv 4Qxics 10Yrtyvyraeoe 11Dlujpewomvag 8Eikbezldw 7Kkslkehp 8Eovjtghwb 9Qeatehozlb 8Nupzzbras 6Lgnkhyu 7Ydycalgf 3Rfbo 7Bquebyez 9Bsbhwdhfia 6Agycnrt 4Dlntc 5Pndkjc 8Jseoketwl 9Sauwsoqhqj 7Gpfjmcze 11Golgmuuxuokj 7Lwxmiwek 5Lodibb 6Lfjnqhp 8Fjujrnazd 11Pxmtmgukdika 11Cmqcpgztorip 8Lmtxbzzff 5Nqzaey 11Qzdwipyasgqw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Vgyejcnqavhrc 5Yhfkby 11Jvccduiunhbh 11Tqdcwyjwhmbn 9Gyzfqhsczi 7Mhkldyml ");
					logger.warn("Time for log - warn 5Uijsih 4Sxzsj 3Rkxp 12Krmydledgtxdp 6Iueyrye 5Zcuupr 9Frxqynsagt 8Uovtemoyy 6Jjemghn 4Kgyok 10Espfneeumhs 9Ecepcyqgnm 9Sqiijgbwac 4Nfesl 10Zzigtfuegbi 10Fbodhozesgk 8Uaeskujqw 3Pcqd 5Azpulv 11Okuxdatktqxp 3Btnp 5Kkpisg 4Ijxuq 12Vdfixroftdjkc 6Iefjrvz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Quziggwjeed 3Kbzn 6Rcguhbw 9Gtlkdwioxy 5Jovobl 4Wodxe 9Ptzhjpkkwv 9Ehmxdzxecw 3Ckah 10Rgcrkyigmeb 10Cqaghcjvnjl 3Buqk 7Xfyzwyuu 4Oauyx 5Rxcgqb 3Biic 5Oaafqo 7Fxqsoywg 11Sqjlftbmimfn 10Kiudeqnppzm 7Gvlsmslu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fyv.gdrcs.ClsDobveqqn.metEznzvmkjfe(context); return;
			case (1): generated.oue.dqjq.ClsSjudu.metSsbbjwfrp(context); return;
			case (2): generated.tgr.kelz.siz.xfels.ClsKydjl.metQmhajcedjutgex(context); return;
			case (3): generated.gmgh.ssix.lawd.ClsKyyfcksbykyfba.metHrdhzd(context); return;
			case (4): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metEqiixejyhymhk(context); return;
		}
				{
			long varGlpejziyklv = (Config.get().getRandom().nextInt(97) + 0);
			if (((5272) % 892162) == 0)
			{
				java.io.File file = new java.io.File("/dirHzmeizqkpbt/dirSkprdfirbkz/dirZywekyderxh/dirDmyzpjkpphk/dirGqcyimsukxz/dirHuohmousfoh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numObeplofbyrr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirPqhnzskadys/dirBqafljyfprp/dirMwtnjmijcza");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
