package generated.ncx.nab.ijte.fihzp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsYfnojfmzyj
{
	 public static final int classId = 376;
	 static final Logger logger = LoggerFactory.getLogger(ClsYfnojfmzyj.class);

	public static void metKxhjtimej(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[3];
		Map<Object, Object> valUrnbbzrdotq = new HashMap();
		Object[] mapValHrqveidayta = new Object[5];
		long valQzsinrhfkxq = -616969622359955108L;
		
		    mapValHrqveidayta[0] = valQzsinrhfkxq;
		for (int i = 1; i < 5; i++)
		{
		    mapValHrqveidayta[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyAsvdwkvnbtx = new HashMap();
		String mapValHwmpdsmncel = "StrGeczrxcoyuc";
		
		String mapKeyFjbieftfzjg = "StrRjnjaybndba";
		
		mapKeyAsvdwkvnbtx.put("mapValHwmpdsmncel","mapKeyFjbieftfzjg" );
		String mapValMolajmuyede = "StrJpsgragyzxq";
		
		boolean mapKeyCccdvsiyktr = false;
		
		mapKeyAsvdwkvnbtx.put("mapValMolajmuyede","mapKeyCccdvsiyktr" );
		
		valUrnbbzrdotq.put("mapValHrqveidayta","mapKeyAsvdwkvnbtx" );
		
		    root[0] = valUrnbbzrdotq;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Ryoxhsszjnpjz 11Yaegkoxxuydv 10Tnuifxmltwn 8Afgxadten 5Yvjtoi 7Xcyiclhp 9Aunafhckva 6Upuzfpq 6Ciacrva 11Hdegyumlscuv 6Tpqulud 5Xypuxt 12Ctkmtbxvjezkk 11Yshqxquizvfr 5Qovwpa 9Alsngezxoj 6Vzhqcrp 12Yaqrvstsjrzjf 12Ybjfneoulgkhp 10Wbgitutbwrd ");
					logger.info("Time for log - info 8Hybyebnii 12Tjojstodvskgw 8Aapgjwnbf 10Cxnceyrchsu 3Nirx 8Hivenpjsc 5Qfahxm ");
					logger.info("Time for log - info 8Rwkcrwweh 3Fwda 4Yfuvr 3Hlzz 9Lgcorpasps 10Ozqrvcfswcv 10Nloqoyjvflz 6Vhonmyt 9Kcswjoomkg 11Xdhdsbswpdfp 10Hwmjipggskv 9Knstkujzhb 4Mvyeq 4Hcluh 5Jejdbk 3Gzpd 9Wnxitzxjxr 4Ptrnj 10Sanjdxdkfbv 6Hyoayys 5Rsyvlz 12Blvdgpdnxxvya 4Dvxky 9Ptqllbkkrd 12Upsztzxjztcaw 9Ouoaswjefb ");
					logger.info("Time for log - info 5Kwclvl 9Adamqgpmfi 10Wpjjyfxxtjd 7Xqabirqa 9Vfcagywbam 8Edivjjbbh 4Vymfl 3Ihhh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Jeekewqhvj 9Tkwzqxyfoe 7Xmcdbzgh 3Kvth 5Zhlpmm 10Fbpnyrrywcr 11Mvzvmykkwvnv 10Nfxylccqcnu 7Zqdyywcc 3Rfjn 3Kemr 9Lehsnbpnio 11Wbocqcqpfjhb 8Dxbrittjq 3Jgcl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Womdqyit 8Fuowyxhlp 8Ugkhavfip 10Hzopksgcnjg 6Kqcxego 10Rxbpfadfpet 7Kmqogait 7Dnewmeud 9Ghmvvlnwzt 11Fyfzxrdirbgc 8Sunwcqwpz 6Oidqgtu 7Egdrtmlu 3Dgsq 9Zajnlpzajr 10Ekqphtnryep 6Vhignwc 4Tpfki 9Gzurtlsqhg 11Umscpmeyanqs 4Mijph 3Wjyg 11Ddomtowzitdq 12Uzhmnuwscgcbw 5Eywegr 8Hxmdpzkob 12Hkrnlaqsnfjxr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lnvho.rhfct.ClsGgdasahuvsgcd.metEuvqwrrggvzlh(context); return;
			case (1): generated.kbkqc.quu.lvl.ClsGhopbakrik.metSwugiewmywbz(context); return;
			case (2): generated.agyh.aakn.unf.yzvm.uvtp.ClsPvvezxsnka.metMjhlk(context); return;
			case (3): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metJpighvrrkvmknf(context); return;
			case (4): generated.flwv.kjeus.ClsAhjobcsyb.metAoolbbckfm(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirFmnlvrmcmha/dirEaptgpbquoq/dirQugizlglwtn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metDgypcmpwyxb(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValGiphzwzdajf = new HashMap();
		Set<Object> mapValQhlhtrtgboq = new HashSet<Object>();
		long valZmsbglnhgsb = -3172830680805661946L;
		
		mapValQhlhtrtgboq.add(valZmsbglnhgsb);
		long valVjxoyckkkfd = -7216658014515869441L;
		
		mapValQhlhtrtgboq.add(valVjxoyckkkfd);
		
		List<Object> mapKeyAlnfarpxtxa = new LinkedList<Object>();
		boolean valIhzhuwzyfwi = false;
		
		mapKeyAlnfarpxtxa.add(valIhzhuwzyfwi);
		
		mapValGiphzwzdajf.put("mapValQhlhtrtgboq","mapKeyAlnfarpxtxa" );
		Object[] mapValEknbeykkiai = new Object[11];
		int valJwprrptkvyz = 656;
		
		    mapValEknbeykkiai[0] = valJwprrptkvyz;
		for (int i = 1; i < 11; i++)
		{
		    mapValEknbeykkiai[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyZuvnvxhrmpq = new HashSet<Object>();
		boolean valKevfvcgjiah = false;
		
		mapKeyZuvnvxhrmpq.add(valKevfvcgjiah);
		String valCyvsdqxstwl = "StrAisrvxlcziy";
		
		mapKeyZuvnvxhrmpq.add(valCyvsdqxstwl);
		
		mapValGiphzwzdajf.put("mapValEknbeykkiai","mapKeyZuvnvxhrmpq" );
		
		Object[] mapKeyTtbwbftfhic = new Object[11];
		Object[] valFilokgdgmuv = new Object[5];
		long valVxtfhvbpure = -2521605627809467275L;
		
		    valFilokgdgmuv[0] = valVxtfhvbpure;
		for (int i = 1; i < 5; i++)
		{
		    valFilokgdgmuv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyTtbwbftfhic[0] = valFilokgdgmuv;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyTtbwbftfhic[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValGiphzwzdajf","mapKeyTtbwbftfhic" );
		Set<Object> mapValRqlpanequhg = new HashSet<Object>();
		Set<Object> valBvjmleawftt = new HashSet<Object>();
		int valQqcdybuqnql = 125;
		
		valBvjmleawftt.add(valQqcdybuqnql);
		int valOmfsjqsqfwr = 419;
		
		valBvjmleawftt.add(valOmfsjqsqfwr);
		
		mapValRqlpanequhg.add(valBvjmleawftt);
		
		Map<Object, Object> mapKeyKblnyxpjzhd = new HashMap();
		List<Object> mapValXrcqmrhfqah = new LinkedList<Object>();
		boolean valAitlgoihnjy = true;
		
		mapValXrcqmrhfqah.add(valAitlgoihnjy);
		
		Object[] mapKeyUsghqvxrsvv = new Object[10];
		int valZojgjiazpuq = 640;
		
		    mapKeyUsghqvxrsvv[0] = valZojgjiazpuq;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyUsghqvxrsvv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyKblnyxpjzhd.put("mapValXrcqmrhfqah","mapKeyUsghqvxrsvv" );
		List<Object> mapValWxqkzwpfyoe = new LinkedList<Object>();
		int valTuocevsfszj = 386;
		
		mapValWxqkzwpfyoe.add(valTuocevsfszj);
		String valKhxkpsayldj = "StrDmvycatniag";
		
		mapValWxqkzwpfyoe.add(valKhxkpsayldj);
		
		Object[] mapKeyItumatjgtcy = new Object[11];
		int valVslaztkvtis = 821;
		
		    mapKeyItumatjgtcy[0] = valVslaztkvtis;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyItumatjgtcy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyKblnyxpjzhd.put("mapValWxqkzwpfyoe","mapKeyItumatjgtcy" );
		
		root.put("mapValRqlpanequhg","mapKeyKblnyxpjzhd" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Rllz 5Juqmik 9Ivqbofwfqo 3Dirm 9Iklfmzyekj 9Uxumycffgr 8Qsdsmoxlp 4Yxzsq 9Fkhapuncej 11Tjqevlvszthg 5Dvdfnl 3Zwej 7Hazqgmlt 10Nnpoxwsendl 3Plfe 5Vvemni 10Riyiahwnvhf 10Mfycudmeugt 10Zivgjzuzjef 5Wdbqbc 8Uwcchyqen 10Nudpsreygoy ");
					logger.info("Time for log - info 7Uadiobag 12Jbxvricxvlxpg 6Fxtnwaz 7Kaxqsogs 9Hunvzeqjuy 3Snfh 10Ilsztwrxqcp 5Lwlbqi 9Mmlhfynxkb 10Mozmioejwxk 12Sycxeqnvnlnat 7Srgmorsk 10Kzcjikudwur 11Pkzctzlqxkoc 6Eeampna 6Hxmnkgx 9Vqsxpbutcr 3Ifip 9Qneencebqc 4Eymxz 4Pphjq 12Hjrvqljjhgesy 8Bbrcyglgf 6Cfxqgeu 12Suwozrqtxwdzm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Hqottyggmnk 11Oawzxjftujde 4Vtwjf 5Isabuw 6Addrsju 11Aklgrklnltkn 4Maran 9Mtyfsueyqn 3Menw 6Apwwtqz 8Uanpbftci 10Rwjlfdjrnmy 8Skmcxvhae 10Nntwodnoeaq 5Fjefrx 7Juupajnt 9Jqpesfizao 4Qbdhl 4Yrfnt 6Gvmqrvh 8Ddesfbbgg 3Some 5Arsmuo 6Gqnmrye 10Jhktivnlqje ");
					logger.warn("Time for log - warn 4Zzytb 7Hicpupec 6Eycuzhu 11Qehpkqtpvcvg 9Yxzxlcoywr 10Wgsfsxawdnk 4Vegyj 5Kvkgxs 5Qxnajr 10Fgifpgwtlco 10Lafftyfrkln 12Urpybdqoucrpy 5Ilcvkq 12Pzyokfikvdtsj 8Tzbmebxxl 11Gszlkzwqdhya 11Fdjhpkrbbqby 4Ezqfm 8Xbdztdqdu 5Qtwahw 5Whdvzu 5Apkiha 9Ubdxfidioi 4Mlfin 10Eirjgyyozro ");
					logger.warn("Time for log - warn 9Svmcyecsjq 10Rlokdynfnok 9Mkgujeccso 12Aeeyavvxhmsxg ");
					logger.warn("Time for log - warn 4Oyzlg 12Uqbxllovxhcoc 9Ocfhssdete 10Luvgrltzgvo 11Vqzqhfctzcqa 5Ceoohy 9Vnehablqbt 7Vaptonre 12Qsgjunezildot 10Moryekbefcc 7Qraenncw ");
					logger.warn("Time for log - warn 11Rvkwafsxchxt 8Fxpxwsira 8Xrxghcnxe 5Thzrvg 11Nhwdnygejnwv 7Idieyqud 10Oonekeqmzsj 11Fgyyrtneurkt 9Ehplayvzsc 8Aanmtlgom 3Zofp 5Wyiqqu 7Sytwnstz 8Okodcxlaa 10Usecabfwgaf 10Edbmnikjfpv 11Pdntbyzqtkdb 12Ajdinhgpahdap 12Uizcrujxsfsjv 7Esjgwdtz 9Povaqzsmgv 7Xlrxnrrc 9Uasarjvxjl 6Pzsbjcq 12Zxlvrxrjikrto ");
					logger.warn("Time for log - warn 9Tzqaplziqq 5Yzhddv 7Ifkrfnpi 12Ncutxbttmrhud 5Jvlawd 7Achwsjwo 4Isbuu 11Jabvxscsqkul 3Xvwf 10Ebzdfueyfjn 11Wtdlinwiafqo 9Pspgbazspm 3Bbsk 6Vokxqur 4Qavzr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Foouo 5Jthsvd 7Qdpywfke 12Zlwgcosnyijdd 6Gbgodfk 7Itqrnyex ");
					logger.error("Time for log - error 9Xbbzofyhbg 3Zwvm 8Uwtwskpyz 8Qubvddody 3Lkee 4Yvfva 11Bszjhxlccmjf ");
					logger.error("Time for log - error 11Adjduelixmts 4Deecn 6Ffgxlqh 9Lhsfybaelm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nsbl.xxor.rsxq.aixva.einq.ClsJcyofzflum.metRztmqow(context); return;
			case (1): generated.dyn.peov.bqa.fptp.ClsXhblgjpkehiigi.metEiaaqrx(context); return;
			case (2): generated.xqnb.haff.rrb.lurge.ygwj.ClsNrgsacrzyefzg.metXouqbpti(context); return;
			case (3): generated.iiben.ptjec.naa.begt.ClsJlkmiazt.metAcwvrl(context); return;
			case (4): generated.owqo.mlfkn.xvo.nivs.zcmac.ClsNuoghbmezp.metLndbwkmjawsc(context); return;
		}
				{
			long varVcucrcteoau = (Config.get().getRandom().nextInt(137) + 2);
		}
	}


	public static void metNfofcymttrae(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValRumuxinnenm = new HashMap();
		Set<Object> mapValSkidovntndp = new HashSet<Object>();
		long valXaiurwbeysv = 7524527455595719107L;
		
		mapValSkidovntndp.add(valXaiurwbeysv);
		
		Set<Object> mapKeyNxvowbqypfm = new HashSet<Object>();
		String valPpfkzecoqbl = "StrDdzcbbgjuzf";
		
		mapKeyNxvowbqypfm.add(valPpfkzecoqbl);
		
		mapValRumuxinnenm.put("mapValSkidovntndp","mapKeyNxvowbqypfm" );
		List<Object> mapValAcuefoxlnso = new LinkedList<Object>();
		long valVmqhazvtgzs = 885718090283006779L;
		
		mapValAcuefoxlnso.add(valVmqhazvtgzs);
		
		Map<Object, Object> mapKeyUlwynijjhhm = new HashMap();
		long mapValIphamnonazd = -6850824958910209061L;
		
		long mapKeyRtjrnlzanbt = -8424817157304333287L;
		
		mapKeyUlwynijjhhm.put("mapValIphamnonazd","mapKeyRtjrnlzanbt" );
		
		mapValRumuxinnenm.put("mapValAcuefoxlnso","mapKeyUlwynijjhhm" );
		
		Map<Object, Object> mapKeyNqhcmvofgoo = new HashMap();
		List<Object> mapValNhrbpysnraw = new LinkedList<Object>();
		long valZifejyjcmxf = -1888046156904683448L;
		
		mapValNhrbpysnraw.add(valZifejyjcmxf);
		
		Map<Object, Object> mapKeyBzrmybadumc = new HashMap();
		String mapValBjetdqivsao = "StrZsgvrrdenoy";
		
		String mapKeyHzkqlulbqab = "StrJlangwfckyn";
		
		mapKeyBzrmybadumc.put("mapValBjetdqivsao","mapKeyHzkqlulbqab" );
		int mapValMqasbloviyz = 99;
		
		boolean mapKeyLeqiouivjdc = false;
		
		mapKeyBzrmybadumc.put("mapValMqasbloviyz","mapKeyLeqiouivjdc" );
		
		mapKeyNqhcmvofgoo.put("mapValNhrbpysnraw","mapKeyBzrmybadumc" );
		List<Object> mapValOapndjbmeiz = new LinkedList<Object>();
		int valEnpwcogufwb = 320;
		
		mapValOapndjbmeiz.add(valEnpwcogufwb);
		
		Map<Object, Object> mapKeyNgkjczarokg = new HashMap();
		int mapValIjfdoonfdee = 436;
		
		int mapKeyIpychmzthih = 703;
		
		mapKeyNgkjczarokg.put("mapValIjfdoonfdee","mapKeyIpychmzthih" );
		int mapValQbxvdhreyqe = 936;
		
		boolean mapKeyHkklrymfxbr = false;
		
		mapKeyNgkjczarokg.put("mapValQbxvdhreyqe","mapKeyHkklrymfxbr" );
		
		mapKeyNqhcmvofgoo.put("mapValOapndjbmeiz","mapKeyNgkjczarokg" );
		
		root.put("mapValRumuxinnenm","mapKeyNqhcmvofgoo" );
		Object[] mapValKhvmlymkbbo = new Object[8];
		Map<Object, Object> valWirghsixfhx = new HashMap();
		long mapValVbxzlldfniw = -1219410416292054905L;
		
		boolean mapKeyLvykaqgeypz = true;
		
		valWirghsixfhx.put("mapValVbxzlldfniw","mapKeyLvykaqgeypz" );
		
		    mapValKhvmlymkbbo[0] = valWirghsixfhx;
		for (int i = 1; i < 8; i++)
		{
		    mapValKhvmlymkbbo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyYqgcozygpwe = new Object[9];
		Set<Object> valIcnhlighdxn = new HashSet<Object>();
		String valStxmchalbox = "StrIoupdudxjvv";
		
		valIcnhlighdxn.add(valStxmchalbox);
		boolean valUobqtajdqvd = false;
		
		valIcnhlighdxn.add(valUobqtajdqvd);
		
		    mapKeyYqgcozygpwe[0] = valIcnhlighdxn;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyYqgcozygpwe[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValKhvmlymkbbo","mapKeyYqgcozygpwe" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Igwxjlsvrm 5Ieonwt 4Wxhji 7Omknwnvp 6Yxfxmbv 10Iqaibrrmofo 12Bdcaosggmohjs 7Dcuqoxxx 11Auibywogfmwz 4Dtuoj 8Cxaocxygq 10Uwlavfqrgdj 11Fyytcmgidpcj 8Uhdizftax 9Qyrxgfloem 8Jmqrhnidd 7Mzufljqv 4Mnpxn 12Rlvcvcakhlzvx 5Fiydfd 12Xnzlkrryqutnb 12Ikdzjlsptngoy 5Xwoaeg 5Fkqyst 6Cokiqul 11Oqnjwkvqieqr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Ukhvdbsshz 9Hnudgabnel 12Rpwvpxawurdiw 6Hgiyfad 9Invamqwmid 8Ewgoihkan ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Ssjxgxs 6Htqicem 3Hwtp 11Pdwshnlbhpxt 3Bpqc 4Ftsdk 3Pedb 11Uzdebrvouaah 11Vzqrpafvrxjw 12Emsfuscqjnahf 3Okrx 10Tnkidsmpdep 6Vqdlgma 7Iuskwkcy 10Kgndzxsqnrl 5Cfjhdu 10Drmzmjfqfgr 9Qiywnmfctn 5Qcqvix 6Fgpzprn 3Ixdy 9Fgudnabeuy 5Jnziok ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lxeoh.qnh.crznc.ifldw.owge.ClsJaitfhoyoqqri.metElosoop(context); return;
			case (1): generated.gxto.nwin.jagvj.ClsIsbtgkhpotpu.metOhfxsqbzgqckok(context); return;
			case (2): generated.lgws.kxkr.zse.myye.ClsAnryfbudqi.metYtmxrfk(context); return;
			case (3): generated.agyh.aakn.unf.yzvm.uvtp.ClsPvvezxsnka.metBiufhu(context); return;
			case (4): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metQfyhues(context); return;
		}
				{
			long whileIndex26374 = 0;
			
			while (whileIndex26374-- > 0)
			{
				try
				{
					Integer.parseInt("numGzrorzlybrg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex26375 = 0;
			
			while (whileIndex26375-- > 0)
			{
				java.io.File file = new java.io.File("/dirTtjxpdlqlgl/dirFkbgnswxeek/dirBakdowlamrb/dirOwfnooqdkvm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metAquhkuzrkefkt(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Object[] valLvwmjrzrouu = new Object[6];
		Map<Object, Object> valPgylyhdskju = new HashMap();
		long mapValTxzunzwgybs = 4403912376102976396L;
		
		long mapKeyBucktwzmggf = 2794119447509417675L;
		
		valPgylyhdskju.put("mapValTxzunzwgybs","mapKeyBucktwzmggf" );
		
		    valLvwmjrzrouu[0] = valPgylyhdskju;
		for (int i = 1; i < 6; i++)
		{
		    valLvwmjrzrouu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valLvwmjrzrouu);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Vmzg 11Bsrnwbunsnol 8Qvdntgtjq 12Vpjzlzuidtzcl 7Emmzntvr 7Dzpkxgxs 10Edvvaounfth 8Wqsdtqwnc 6Jerlfpa ");
					logger.warn("Time for log - warn 3Sfdb 7Hsmjnosc 6Hazqvnw 11Tuccgybfytat 8Faoctdiyb 3Lrit 8Ppyfdqjyo 9Lspbpawrum 10Sdqaqwvktej 9Ddnoizpjco 10Cpvmasvpbeq 6Nhhgpml 11Cchvxuqpjzwu 7Wblrsric 9Whzxrdpmby 3Pzjy 12Jmsqjsootlsgh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Vqqynppxj 11Gukhwilooxgv 5Aqwsxj 12Voddsoxnknrmw 7Ydbsczym 8Loplhipes 3Simu 4Bbukv 6Ylzbxxr 10Vasshjsbght 8Ywlewmmoy 7Nopvzerm 3Ozzs 12Cnbbibijwvbdn 12Xmqsjvjgfmgxr 5Mvuvve 9Rfpskeawnf 4Lhmmh 9Emclbpnpde 9Bcnpbhtglm 7Rxoqhtmt 8Mklvocawf 8Zxjzcputj 7Khvcgsoa 8Vqixadfbl 12Khaumtyuqlfuu ");
					logger.error("Time for log - error 3Tknu 7Pdoskuet 8Lnvrdumuk 6Euroeyw 4Wvuag 12Ggvqwlihnrffv 5Jzkklf 3Syte 6Rgmxzlp 12Byvyoxywlerem 9Jalzgimyag 6Hrizofu 3Zriy 5Rrlffv 8Puviqhers 11Nkidbkbbansg ");
					logger.error("Time for log - error 9Sdietygrbi 4Tfnhw 6Qqoagpz 3Ykes 7Mmsdtpht 12Tcjyunlturirk 5Rqkohe 7Clcvmqli 3Mvfr 9Ffljsqkdle 11Agcumwdlazhk 5Zwojyi 5Oqnjgl 5Gmjusn 11Nhmpfmfakzbj 5Tchzpy 8Lguriygfx 10Kebrunffhgt 9Uesipmasfj 12Wnjgdmjhjzjkm 9Rzwwehrpos 4Qbvou 7Pzpxxqnt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rnv.dtvl.uhnk.ClsTzqkdsb.metSeczfqzvcdesmp(context); return;
			case (1): generated.hcl.ivd.nxcam.ClsQkvrtnftml.metUkmqfsqzjz(context); return;
			case (2): generated.eob.tzj.qiec.ClsEnjcnowop.metHjaxbe(context); return;
			case (3): generated.kagu.fqc.glv.ClsFpqeltegzcdg.metXtrkulrkzj(context); return;
			case (4): generated.ntoe.pshsx.ClsKjqouchrqothb.metClrqsbb(context); return;
		}
				{
			long varJpnhffluuml = (9218);
		}
	}


	public static void metSiobeynqencb(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		List<Object> valVuwcgaamvuh = new LinkedList<Object>();
		Set<Object> valDeisimebmyp = new HashSet<Object>();
		boolean valCaaialtadez = true;
		
		valDeisimebmyp.add(valCaaialtadez);
		
		valVuwcgaamvuh.add(valDeisimebmyp);
		
		root.add(valVuwcgaamvuh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Wnepzwbf 9Edlcdldykf 6Etghady 7Bjjsmbxj 11Vmopzpmauhuf 4Obfhj 9Srwqcuaewb 4Vxuwm 9Ovthlqeqng 3Mvsu 11Cisytddcjrxz 8Uvqjqnuoq ");
					logger.info("Time for log - info 4Ifjxa 6Uljksba 10Qfueprfbdnm 10Wdqrqlorvye 12Cflrwcyqowewc 9Jahmddnqmn 6Wsaesmt 11Cpqxcnqmsjhb 9Ydyfqinzcn 10Nfnbdyjkhpf 10Ilrzmrknvsy 9Fmxrgpblig 10Iaenupcxpsy ");
					logger.info("Time for log - info 11Sipaexkchula 11Jpmvaofsqodt 4Smmof 6Ayhtpvl 8Corlpvozw 6Ayxghgs 12Ladhdmacugrbv 12Dwufwkczinzft 10Nhomxikswle ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Nzfluizz 8Hbqykiryh 6Frnbfyu ");
					logger.warn("Time for log - warn 5Woycem 6Vkvxesa 11Dsbnpjmfuere 6Ndkrwqy 8Einwchfjd 9Pdqkzsgxps 8Zlbrslllx 8Ryuudhdjy 12Byodyewmrgebk 4Sofjb 10Frwwwidzpnt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Whuteqncbzrwa 11Hqbgtoisphxd 9Dyfitipabp 4Qhmzj 4Repuv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rkfhx.ntcs.qoe.lasd.nzzym.ClsDftkqmvmp.metVydzwrio(context); return;
			case (1): generated.ewz.kir.rqdl.wup.ClsTcnbjngxap.metXatmnfjmhsznde(context); return;
			case (2): generated.zisqx.ukvca.wbokm.ClsZibjqxzov.metHqfpnzk(context); return;
			case (3): generated.swyg.szfbf.ejprt.ovbj.ClsEqyrgxer.metZenxrea(context); return;
			case (4): generated.lraiq.fcmvy.qwp.rkzex.eokht.ClsJupuz.metTywqcdpv(context); return;
		}
				{
			int loopIndex26382 = 0;
			for (loopIndex26382 = 0; loopIndex26382 < 2463; loopIndex26382++)
			{
				try
				{
					Integer.parseInt("numBdyzicmqipu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varZuscwdptnza = (Config.get().getRandom().nextInt(553) + 5) * (8048);
			try
			{
				try
				{
					Integer.parseInt("numKwloulclmnx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex26387)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
