package generated.rayp.ekfg.uust;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQhtttdalkvmcth
{
	 public static final int classId = 148;
	 static final Logger logger = LoggerFactory.getLogger(ClsQhtttdalkvmcth.class);

	public static void metYhiqkxerxikn(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valSuspqzphjhr = new LinkedList<Object>();
		Set<Object> valCejtcgfawmy = new HashSet<Object>();
		long valOiftxmcrgdw = -2887442640779522541L;
		
		valCejtcgfawmy.add(valOiftxmcrgdw);
		long valCpdrtthfmza = 236674337879307540L;
		
		valCejtcgfawmy.add(valCpdrtthfmza);
		
		valSuspqzphjhr.add(valCejtcgfawmy);
		
		root.add(valSuspqzphjhr);
		Set<Object> valHbduixgjqco = new HashSet<Object>();
		Map<Object, Object> valHmjyayaewlp = new HashMap();
		String mapValIangzfsmvbs = "StrEemyyfrslxp";
		
		long mapKeyNasdfyewhrv = 6040690721418714837L;
		
		valHmjyayaewlp.put("mapValIangzfsmvbs","mapKeyNasdfyewhrv" );
		boolean mapValWwmdjotoawq = true;
		
		int mapKeyIzsrlqgbroq = 928;
		
		valHmjyayaewlp.put("mapValWwmdjotoawq","mapKeyIzsrlqgbroq" );
		
		valHbduixgjqco.add(valHmjyayaewlp);
		Object[] valMvbdnsesggk = new Object[10];
		int valDgmjliqrrrr = 928;
		
		    valMvbdnsesggk[0] = valDgmjliqrrrr;
		for (int i = 1; i < 10; i++)
		{
		    valMvbdnsesggk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valHbduixgjqco.add(valMvbdnsesggk);
		
		root.add(valHbduixgjqco);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Ktkmkg 9Zgjajvmznu 4Crhqz 9Ucurfhweis 6Zbyzwqy 4Emyim 7Makgslpi 10Uyzoeukivkf 4Iiteo 11Iuxckmohsmjz 10Orifxjysdow 10Euoixotdnkz 3Hpvs 10Qtukxzhfgid 8Hizfgvput 11Jvnmmfsatsvc 7Plgotsjp 11Jyqhengfcied 11Zymzwmraohcg 3Vkdr 5Epbjwd 5Ciufim 6Uokhyzs 3Nbmi 9Wezcjhxbxx 10Gzfcugjkqvt 10Xaefoqboayh ");
					logger.info("Time for log - info 7Xyeocywp 12Zujublrjmlhfw 4Acqyo 9Pdtmouuypw 6Ccjrxbb ");
					logger.info("Time for log - info 8Cqltwqser 10Nhcbwlaeimf 8Tyvvbyija 11Sglxwipuyxin 9Afzdurcype 8Txzcyyzal 11Lxeijsyzcjay 8Ckyqqwupo 10Ymdfsvajmgh 3Fgnt ");
					logger.info("Time for log - info 8Tqwnusqjo 7Sgmrzbud 3Pzdm 12Apczzywbbaecf 8Galphthvg 12Vtnkarxujybrj 5Wqecas 7Wkjhrfoy 8Tnmmsxahk 11Ppbebliabega 6Grncfcl 7Frxbywbf 11Xhnwpzgxzvmj 8Fvxrytwdd 6Xrjbcxh 12Fgxazqldzozpw 6Lzypivh 5Ysmifj 12Wuaxuyylweuee 9Hofzfotxqa 10Wasiwdjdtqg 9Etkkleqebr 12Vnvdccqbbynpi 3Qomg 5Wvtncw 4Zglov 11Hjuacvxwaath 12Puijoekwcveyj 5Zahleb 10Bmotkmxpzro 6Jdzxntj ");
					logger.info("Time for log - info 7Vqqksmnz 8Ixairwehj 11Ejswsnzakhmf 9Pgxncqajvm 9Snmhfuiglf 8Ibeebaocw 8Fghldhpdp 5Oaitzp 10Dgwcoxlrajx 4Mnznj 4Tnywk 4Awyik 6Wbanqhv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Xkwshqrkyfxk 10Qxyjlmaawuo 8Slkjmlwru 5Lhybum ");
					logger.warn("Time for log - warn 12Vfvpdxxretqhg 7Axrqirnr 12Dhifjsnyrwtrd 9Ioxpmbuntq 9Xaywgiqcbw 8Qwimzggip 5Fkkjbb 5Xywjsa 11Rpeffxaxqrms 4Hscbx 12Ifxwvvavyxvkm 10Arxadlvcgmr 6Pximlzm 9Igegxxwuuu 4Cfmfv 11Notdqydmkujv 4Bfoui 3Shdk 6Bfmdemq 3Esyn 12Wvtlxqxizeliu 5Sbrkmm 9Gxddjklogi ");
					logger.warn("Time for log - warn 5Cbvekb 8Zxdzfsizq 7Jdrnezym 9Ibqdfonucy 8Ylflujtgh 10Akaqryqfxop 8Kuzumcqgv 5Qmsiqd 4Jcigs 10Kehjolhphwn 4Qlcbt 5Iomssr ");
					logger.warn("Time for log - warn 8Wsewctcqg 12Cdajhopkuwfrh 3Rsre 4Rvkcm 11Jetydurszyic 4Olycy 3Leji 8Myrmdpboe 10Qttvxzuduem 6Hfboeem 9Rysyhxpdgl 8Hifpkzwjs 5Iadjyt 9Fodfugpseq 3Lyrk 8Zavkmjxlf 10Ibrvixzluxs ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.eddt.homo.syk.wqll.dyeuq.ClsYzlmjqrjjp.metMqehtaaykikdy(context); return;
			case (1): generated.kqywo.pil.grw.dvt.ClsJduhsebfba.metHzxxu(context); return;
			case (2): generated.gpnn.qul.pdexl.hxjph.zmndq.ClsIcvyndtrplxfkf.metNldde(context); return;
			case (3): generated.wxgmf.hjxrw.ClsYvfyyrknqfec.metRjzexmwk(context); return;
			case (4): generated.dyv.vxo.ClsWrwpfswr.metWnivtvbltsfqlg(context); return;
		}
				{
			long whileIndex22687 = 0;
			
			while (whileIndex22687-- > 0)
			{
				try
				{
					Integer.parseInt("numUehrqwadicb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metLspuodoxysnrqo(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValRgunlgbfrog = new HashMap();
		List<Object> mapValUkvdogqxxqm = new LinkedList<Object>();
		long valIgdzoplgsuk = 6610963683620035055L;
		
		mapValUkvdogqxxqm.add(valIgdzoplgsuk);
		String valCeghglrzcuq = "StrIzqrhognlsh";
		
		mapValUkvdogqxxqm.add(valCeghglrzcuq);
		
		Map<Object, Object> mapKeyCcwjecpsswp = new HashMap();
		int mapValNgxerwvrfmc = 950;
		
		int mapKeyJaqwihcvlxs = 319;
		
		mapKeyCcwjecpsswp.put("mapValNgxerwvrfmc","mapKeyJaqwihcvlxs" );
		boolean mapValMebxodhjqko = false;
		
		long mapKeyZcesmnbbxnp = 4955704337361778335L;
		
		mapKeyCcwjecpsswp.put("mapValMebxodhjqko","mapKeyZcesmnbbxnp" );
		
		mapValRgunlgbfrog.put("mapValUkvdogqxxqm","mapKeyCcwjecpsswp" );
		
		Map<Object, Object> mapKeyFrwslkpwtor = new HashMap();
		Map<Object, Object> mapValSobnfwwdgmg = new HashMap();
		int mapValXfyiivvbpgy = 979;
		
		String mapKeyFkohtxrbgfu = "StrMbfelohwzet";
		
		mapValSobnfwwdgmg.put("mapValXfyiivvbpgy","mapKeyFkohtxrbgfu" );
		
		Object[] mapKeyQrxzalzrttc = new Object[2];
		long valDjrofdweymp = 1792418207476705823L;
		
		    mapKeyQrxzalzrttc[0] = valDjrofdweymp;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyQrxzalzrttc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyFrwslkpwtor.put("mapValSobnfwwdgmg","mapKeyQrxzalzrttc" );
		Map<Object, Object> mapValXxthzienhwg = new HashMap();
		int mapValSyxlfskdzfu = 878;
		
		String mapKeyEfueevrqlsb = "StrCozmbvmtcbf";
		
		mapValXxthzienhwg.put("mapValSyxlfskdzfu","mapKeyEfueevrqlsb" );
		
		List<Object> mapKeyCcerwjuwzrj = new LinkedList<Object>();
		long valWxhnwybwfec = 6245538278241689012L;
		
		mapKeyCcerwjuwzrj.add(valWxhnwybwfec);
		int valJmrbbdeqnsw = 525;
		
		mapKeyCcerwjuwzrj.add(valJmrbbdeqnsw);
		
		mapKeyFrwslkpwtor.put("mapValXxthzienhwg","mapKeyCcerwjuwzrj" );
		
		root.put("mapValRgunlgbfrog","mapKeyFrwslkpwtor" );
		List<Object> mapValPcjabugidko = new LinkedList<Object>();
		List<Object> valQpbzrhpyjbj = new LinkedList<Object>();
		int valXsnppgtijav = 910;
		
		valQpbzrhpyjbj.add(valXsnppgtijav);
		boolean valInnilrwlquy = true;
		
		valQpbzrhpyjbj.add(valInnilrwlquy);
		
		mapValPcjabugidko.add(valQpbzrhpyjbj);
		Map<Object, Object> valSjdwsjdvloy = new HashMap();
		String mapValXssyugblshq = "StrAuezvzmaxih";
		
		String mapKeyHptittdqorn = "StrUscautphijq";
		
		valSjdwsjdvloy.put("mapValXssyugblshq","mapKeyHptittdqorn" );
		boolean mapValTazhwruijnj = false;
		
		boolean mapKeyKpjscokliyj = false;
		
		valSjdwsjdvloy.put("mapValTazhwruijnj","mapKeyKpjscokliyj" );
		
		mapValPcjabugidko.add(valSjdwsjdvloy);
		
		List<Object> mapKeyLbsxlzssuvp = new LinkedList<Object>();
		List<Object> valRfpaymylhlw = new LinkedList<Object>();
		String valLjxwxzlkpaw = "StrDtptoxmikng";
		
		valRfpaymylhlw.add(valLjxwxzlkpaw);
		String valRxuuoahorfo = "StrJmeqkhqjcpf";
		
		valRfpaymylhlw.add(valRxuuoahorfo);
		
		mapKeyLbsxlzssuvp.add(valRfpaymylhlw);
		
		root.put("mapValPcjabugidko","mapKeyLbsxlzssuvp" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Noarjdhmel 7Odxvmflf 6Misyqyt ");
					logger.info("Time for log - info 8Gaxkzbmeb 7Akwferhh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Ljohizfvzei 9Truquavntc 3Xixd 10Bkdqoheqytf 6Cgscxaa 4Mhuxs 4Aijyu 8Cxlbyqkdf 7Gehxmevt ");
					logger.warn("Time for log - warn 10Rekzwgswjog 7Gxaxvozg 7Lmrozism 3Btyc 4Ixmhp 6Npvzlkn 8Xcuntsjak 3Vwqo 12Lzcafihgeiuzf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pef.kybz.yzpf.dzs.obqpv.ClsKizvnatyigi.metKzutin(context); return;
			case (1): generated.bde.vdlp.frn.zsrjp.eqwxd.ClsMvedn.metBrdejrtmmvqjyb(context); return;
			case (2): generated.ooziu.gzrop.rbg.ClsFthgefv.metSpwbethaetqps(context); return;
			case (3): generated.qku.vho.jtvuy.nvgy.zmvk.ClsVjaehh.metEpucadc(context); return;
			case (4): generated.yzf.fayrw.fbm.pexsg.rxfb.ClsSblyqahlwj.metDtinpwu(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numKhcstkjtcej");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numFrodlevqlvs");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex22691 = 0;
			for (loopIndex22691 = 0; loopIndex22691 < 3798; loopIndex22691++)
			{
				try
				{
					Integer.parseInt("numLxfnktwyfbp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numMuhimxkmrbe");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numOxtakpdiwto");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
