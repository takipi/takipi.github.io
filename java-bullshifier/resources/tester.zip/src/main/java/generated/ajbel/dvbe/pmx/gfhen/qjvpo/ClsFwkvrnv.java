package generated.ajbel.dvbe.pmx.gfhen.qjvpo;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsFwkvrnv
{
	 public static final int classId = 174;
	 static final Logger logger = LoggerFactory.getLogger(ClsFwkvrnv.class);

	public static void metXipxiwvyvncxvi(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[6];
		Set<Object> valQvccejnwssx = new HashSet<Object>();
		List<Object> valCnpugacmttz = new LinkedList<Object>();
		int valMgwmfyfxucf = 484;
		
		valCnpugacmttz.add(valMgwmfyfxucf);
		
		valQvccejnwssx.add(valCnpugacmttz);
		Object[] valUkbnfkhnvca = new Object[6];
		boolean valNhibrgdhilw = false;
		
		    valUkbnfkhnvca[0] = valNhibrgdhilw;
		for (int i = 1; i < 6; i++)
		{
		    valUkbnfkhnvca[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valQvccejnwssx.add(valUkbnfkhnvca);
		
		    root[0] = valQvccejnwssx;
		for (int i = 1; i < 6; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Gmbvbvmhprmv 9Ombtmnpcrv 5Fwzfhq 5Vqbntz 10Gvkgvooeigp 10Ryutwtnppuj 9Lxevdalnps 11Pwzmjvfyvhrm 11Zgxmrxqvivzi 9Asyzbhgyim 3Wqmg 4Xxouc 8Dbsnrnxdq 8Yglqkrcrw 8Jhnahfmsm 4Wtotr 10Baqhygcakfh 3Gtwt 10Rpobtfwdxjz 12Aclffpzjfdvur 12Cszsspdiggjej 12Ibptgfngthznx 8Upvimmqqc 6Mmxwdne 7Otadrekz 3Qkwl 7Ounyktox ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Luwcxn 8Kjgnlwgak 10Ssqhcmyxuam 6Jevaels 4Kirpl 3Njms 12Mvtaxfhsulpjw 3Nxeg 5Tooepe 5Fddvll 8Ffjdaqezs 7Phlhkfcb 11Jekupggzlvje 7Fyizgief 8Znhqfodia 12Zmwxuvacxtown 12Aduurrsclbdvx 3Xmzh 5Zhslvt 6Eqrhqjd ");
					logger.error("Time for log - error 11Dnynoerqaatk 11Zgkhrwbmzmtp 3Hkqy 10Fbwqmdeplpx 4Xhjwh 12Wkfhbcdnprmuf 11Utggmwjsojmx 9Vfnrqvstnn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pli.sac.lcrkw.ery.xwlo.ClsIghyijbnkvoubq.metAbfxcknztmtxd(context); return;
			case (1): generated.pfjp.usowt.ClsIsioyesmm.metZipgjwya(context); return;
			case (2): generated.ocmm.ezbtm.vxyei.kuseg.ClsUqzgoaq.metGzyab(context); return;
			case (3): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metDghubvohwq(context); return;
			case (4): generated.ucgs.cys.qrt.ClsGwmfnzjfaj.metEgvezjze(context); return;
		}
				{
			int loopIndex23143 = 0;
			for (loopIndex23143 = 0; loopIndex23143 < 4742; loopIndex23143++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((8860) % 318987) == 0)
			{
				java.io.File file = new java.io.File("/dirVoikdtzcdny/dirCdxlgqvywza/dirEjceiemlucq/dirSviuwemxebq/dirXwnamgaqjok");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metMgmvesnfqhsp(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valFbktjwzlcrp = new HashMap();
		Object[] mapValJoxrfutrlrk = new Object[9];
		long valCkppbyupenu = -7071248315555916470L;
		
		    mapValJoxrfutrlrk[0] = valCkppbyupenu;
		for (int i = 1; i < 9; i++)
		{
		    mapValJoxrfutrlrk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyElfveojgasw = new LinkedList<Object>();
		boolean valQcpgniuiyhx = true;
		
		mapKeyElfveojgasw.add(valQcpgniuiyhx);
		
		valFbktjwzlcrp.put("mapValJoxrfutrlrk","mapKeyElfveojgasw" );
		Map<Object, Object> mapValGsbtfrcjlfl = new HashMap();
		String mapValCuhiwfvraoy = "StrThdgyyqgfeb";
		
		long mapKeyEivhidynean = -2066256434259975697L;
		
		mapValGsbtfrcjlfl.put("mapValCuhiwfvraoy","mapKeyEivhidynean" );
		String mapValLdbxpydwehd = "StrXalwehmuiku";
		
		int mapKeyBwkdyluhkic = 326;
		
		mapValGsbtfrcjlfl.put("mapValLdbxpydwehd","mapKeyBwkdyluhkic" );
		
		List<Object> mapKeyGskssawkzdn = new LinkedList<Object>();
		int valRvxxjmmehuw = 654;
		
		mapKeyGskssawkzdn.add(valRvxxjmmehuw);
		
		valFbktjwzlcrp.put("mapValGsbtfrcjlfl","mapKeyGskssawkzdn" );
		
		root.add(valFbktjwzlcrp);
		Object[] valZqmahlmitre = new Object[9];
		Set<Object> valQygwyzzholy = new HashSet<Object>();
		long valYqclhqmkjlz = -3247373418225088853L;
		
		valQygwyzzholy.add(valYqclhqmkjlz);
		boolean valUnpzyfarmyj = true;
		
		valQygwyzzholy.add(valUnpzyfarmyj);
		
		    valZqmahlmitre[0] = valQygwyzzholy;
		for (int i = 1; i < 9; i++)
		{
		    valZqmahlmitre[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valZqmahlmitre);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Rirncmku 3Bcpl 4Ifdkj 4Vivkt 3Mlse 7Opqynltm 7Qjnridci 3Waxw 10Jybkskztmfr 3Zkki 6Xcywpgl 5Vobphf 10Mbpgxkdwrkn 10Zemqnaahbpi 4Oxfvs 7Eevurlmu 4Hjhdx 11Mndeuaodfxbx 12Csrmxzunhcdwh 11Ichdkpvybgqo 4Qrton 9Byefsgrfjv 8Gzauliepp 7Gmeobvwy 12Cbqfzbhsiuzys 11Xilnlvydxdyc 4Higqw 5Jutxky 9Sxciikkpaj 8Ngxdpeocm ");
					logger.info("Time for log - info 4Kugnt 3Hjcc 5Wnvmcr ");
					logger.info("Time for log - info 3Plls 11Sovbhithgyot 9Ucekulnmrr 3Mxdo 6Yuyxnte 7Scaetedx 4Aleel 3Axwv 5Lfkqwk 6Jfjqqkd 6Nnfiznv 9Eylklkdbrn 10Fityrmzwkap 7Mpxgrihh 10Ajrhyfrttxm 3Hucg 12Hfcmaskwkobiq 9Cxzydmrniy 10Nadeedwgwit 6Gpuacgd 3Enkl 6Hzrphmd 4Ryyvk 5Kgtazj 7Smnsomib 6Fvxkifi 3Umck 6Vtrljqp 11Qwjuhstmsxsg ");
					logger.info("Time for log - info 11Xyxdwxpsseop 8Jvrzrfelp 10Wdwntopnznu 4Sibts 7Cgzyibds 6Hfzvlqd 11Hkdwasqzlfnm 6Mjhgtfa 11Iakgdhrdyfyi 9Pzxaeruczr 4Hzowf 10Opwenznhkhg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Nrzamp 8Ffhcngplh 3Dltq 4Nnrhv 10Rsborlujvdz 7Tivnrfju 10Sowecpxsdyx 12Vxpvxummuhogd 12Puecuqibkcybh 3Bgzm 5Tfwmaf 5Yypdmz 7Ihzhfokm 3Tjhq 12Oohesjfrqhiga 4Dsmmp 3Vxzd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kwutd.ipdj.aoc.ClsFtolmgndn.metLhyuqqu(context); return;
			case (1): generated.jgye.cou.ClsWhiobyn.metUoalicwnco(context); return;
			case (2): generated.ulre.knov.ClsTukvjlscu.metSnzvazpuz(context); return;
			case (3): generated.xluq.wys.lexvj.ClsEsonclfnnvbg.metChkmtacwa(context); return;
			case (4): generated.mipzp.qfu.axrt.ClsJkbbmhkrxeo.metUvsxqnes(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numPuwhjschdvv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metJxbxbolmcyk(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Object[] valZtuoiaeejlg = new Object[8];
		Set<Object> valUvyfopeadyd = new HashSet<Object>();
		long valWqvnbvqkteg = -4316414023646852021L;
		
		valUvyfopeadyd.add(valWqvnbvqkteg);
		
		    valZtuoiaeejlg[0] = valUvyfopeadyd;
		for (int i = 1; i < 8; i++)
		{
		    valZtuoiaeejlg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valZtuoiaeejlg);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Hoizou 5Evuynr 8Xdcgxheii 4Htqjh 6Rhkhpch 7Rsqtrlff 7Ujbwuuna 7Bkwvsfzj 4Krtkt 9Jtraudommf 4Awrof 5Didwjf 11Hxlmihlsxmxx 11Ookfpuxpytfx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Xilvofravrwio 8Iwmgxijnh 10Rszskmwhdgc 4Isucd 12Zjnnpuuykqiaw 3Pzbl 7Oydndija 9Eqrjqcqqiw 4Fseie 5Lgxwsq 6Nrkvjxq 9Dlxxynacrq 8Inwlxbppq 3Pojn 3Ozgq ");
					logger.warn("Time for log - warn 4Zuasb 10Ximeejrujxe 4Imohk 5Givqoj 11Kqxvzslmdhxw 6Jknfqcc 7Ehvarzjs 8Ashppjqzs 8Hrbctrxet 9Zptrrmafre 5Fdrejc 11Vitwibngnmbb 7Ieuadxjt 4Syymv 5Wiubjx 9Elwzjcanbx ");
					logger.warn("Time for log - warn 3Aevn 6Rhprlqc 3Naza 3Lcgz 10Vswbpucfxcs ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Vxskq 12Qrhyxkctljaqe 10Zcitxbhupcp 5Wluxgj 6Tgbkzjw 4Erqwt 11Sszczgcmywfn 5Gsmusw 4Ziscq 7Huctwjbc 6Myqyzog 11Zvmxxxbfyuyj 9Qbvfnnqaak 3Ftie 8Aixiqywiz 5Efnpct 10Ddkidlfhwxh 12Mmunqjyahjglb 11Rjykrjqqlfqa 4Zagim 6Vxbawii 6Jqscgnb 11Jvkmciljloee 7Ohfdsksi 4Ydmlr 5Tedsnp 11Tactbssugror 8Yluqatprg 9Lugpkrytzr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lmq.wwll.mcjoz.ClsBqjxdpu.metGccfwaiyfrrux(context); return;
			case (1): generated.sxepk.qoxr.ClsOlkemveail.metSoyjjijmnpnjwu(context); return;
			case (2): generated.kdu.bhxiw.zym.ClsZlzcdqn.metFbnoxeuhjmavi(context); return;
			case (3): generated.vyac.iqbj.guc.ClsYpwwsvx.metMdzvgnzpzh(context); return;
			case (4): generated.lfb.pwad.aey.ClsGmnfes.metRujsenpfl(context); return;
		}
				{
		}
	}

}
