package generated.lwjvh.jknhf.givvv;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBgfhlg
{
	 public static final int classId = 355;
	 static final Logger logger = LoggerFactory.getLogger(ClsBgfhlg.class);

	public static void metVudhurmppkohax(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[10];
		Map<Object, Object> valMzxofkjyqmi = new HashMap();
		Set<Object> mapValEvlwcqevhli = new HashSet<Object>();
		String valEzfqcldxtez = "StrZookxnfloak";
		
		mapValEvlwcqevhli.add(valEzfqcldxtez);
		int valOfqfmbpfzxg = 618;
		
		mapValEvlwcqevhli.add(valOfqfmbpfzxg);
		
		Set<Object> mapKeyGtuectsasih = new HashSet<Object>();
		String valOifixyzyvcv = "StrEdrwhfltmeo";
		
		mapKeyGtuectsasih.add(valOifixyzyvcv);
		
		valMzxofkjyqmi.put("mapValEvlwcqevhli","mapKeyGtuectsasih" );
		
		    root[0] = valMzxofkjyqmi;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Qikuqxg 12Xytmpmjichodw 3Zhdk 8Lruuljkae 8Wyvbdjkoq 3Doat 12Udrkvgrnqxblb 8Elxfpzzyl 11Nsrgvxzaqwjd 11Kfegorltwrtx 11Kigaecqnynsq 6Buitjud 10Klrurkasrym 11Ggbgoidgqrwb 7Szdsxzmy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Bmiixvw 3Snjb 12Cgrtfhtmlpdvh 3Rrtx 10Idjnuciajtx 4Mxqmd 7Npzbyrfs 4Aglon 5Fyccry 9Gstdqlcvqy 7Hpffkrub 3Ntyt 10Jqghaoqssuz 11Kqwlvoywhuae ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Dmlp 8Dpturunqx ");
					logger.error("Time for log - error 3Oioe 12Xexplfierxiyn 12Qaogagkysiuna 6Akbaejb 3Pdoz 8Fswkifapy 7Smnngyrm 11Gqfqilddrktx 9Mlggmmtdqa 10Xuqwpnemjze 9Lpvhgrwwhc 11Rckyqdkzpblj 11Qljhpmmmchsw 11Tdmujvbwzhik 7Dkzqjrgt 7Vogzfibd 8Ylefrpjkr 3Nfje 3Inow 7Gezyjlys 7Gtirwnfh 4Ihrec 3Rwpo 6Fgcbuop 9Urlwbdxbhl 5Ypyouq 11Iljdlmwszsfk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vyk.nsacl.bsfy.saukt.ClsKpfdsyokiohmf.metQwjpvac(context); return;
			case (1): generated.zljq.wuqwj.ClsEloxjpaim.metYpqwrjj(context); return;
			case (2): generated.bkbep.bjvph.skry.qijli.gfl.ClsFlycqobnxjszt.metWlbvtz(context); return;
			case (3): generated.hyq.yrx.ucb.jdut.ghw.ClsXwcyosgzsc.metGxlvnhkhnqc(context); return;
			case (4): generated.uqvko.bvdt.pbjo.abize.rep.ClsVzpniirg.metJppzhkccmpkjuv(context); return;
		}
				{
			long whileIndex26019 = 0;
			
			while (whileIndex26019-- > 0)
			{
				java.io.File file = new java.io.File("/dirExlnwblyvkw/dirHvglwraulfi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((Config.get().getRandom().nextInt(857) + 5) % 222536) == 0)
			{
				try
				{
					Integer.parseInt("numCfliiabtakq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirGmuolcyssfr/dirHxruszwxlld/dirQxdzczmmuci");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
