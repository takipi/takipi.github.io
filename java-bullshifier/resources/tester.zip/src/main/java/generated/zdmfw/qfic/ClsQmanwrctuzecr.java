package generated.zdmfw.qfic;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQmanwrctuzecr
{
	 public static final int classId = 186;
	 static final Logger logger = LoggerFactory.getLogger(ClsQmanwrctuzecr.class);

	public static void metEvpjjip(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValGjwnnqfjulx = new HashMap();
		Object[] mapValHozzdsbflqn = new Object[3];
		boolean valMmeoltanjnt = false;
		
		    mapValHozzdsbflqn[0] = valMmeoltanjnt;
		for (int i = 1; i < 3; i++)
		{
		    mapValHozzdsbflqn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyBcufqiunxez = new Object[5];
		int valTmheewhjalq = 986;
		
		    mapKeyBcufqiunxez[0] = valTmheewhjalq;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyBcufqiunxez[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValGjwnnqfjulx.put("mapValHozzdsbflqn","mapKeyBcufqiunxez" );
		Object[] mapValNsppcrcnonq = new Object[6];
		int valCglgopokjav = 474;
		
		    mapValNsppcrcnonq[0] = valCglgopokjav;
		for (int i = 1; i < 6; i++)
		{
		    mapValNsppcrcnonq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyVplckaerlnn = new HashSet<Object>();
		boolean valFdocpvnwqme = false;
		
		mapKeyVplckaerlnn.add(valFdocpvnwqme);
		String valYelzibtoayq = "StrYwttoojaktd";
		
		mapKeyVplckaerlnn.add(valYelzibtoayq);
		
		mapValGjwnnqfjulx.put("mapValNsppcrcnonq","mapKeyVplckaerlnn" );
		
		List<Object> mapKeyZdnqibiyzxp = new LinkedList<Object>();
		List<Object> valPipgxjmjsdu = new LinkedList<Object>();
		long valFupgzoyremo = -5020104735829739303L;
		
		valPipgxjmjsdu.add(valFupgzoyremo);
		
		mapKeyZdnqibiyzxp.add(valPipgxjmjsdu);
		
		root.put("mapValGjwnnqfjulx","mapKeyZdnqibiyzxp" );
		Map<Object, Object> mapValYkishnombdy = new HashMap();
		Map<Object, Object> mapValPgrajcwfvkq = new HashMap();
		long mapValFizwigjtouf = 3760791265160035678L;
		
		String mapKeyHleebixeakb = "StrFbwccyytlnl";
		
		mapValPgrajcwfvkq.put("mapValFizwigjtouf","mapKeyHleebixeakb" );
		int mapValFvecybrjvjx = 274;
		
		String mapKeyJfaohpfgphp = "StrVgzhizgsvib";
		
		mapValPgrajcwfvkq.put("mapValFvecybrjvjx","mapKeyJfaohpfgphp" );
		
		Set<Object> mapKeyRojupwshhrc = new HashSet<Object>();
		String valIzpknaozsbz = "StrTmgwoeoudrl";
		
		mapKeyRojupwshhrc.add(valIzpknaozsbz);
		
		mapValYkishnombdy.put("mapValPgrajcwfvkq","mapKeyRojupwshhrc" );
		Object[] mapValFdeglerxaia = new Object[7];
		int valQqsjifogwgc = 969;
		
		    mapValFdeglerxaia[0] = valQqsjifogwgc;
		for (int i = 1; i < 7; i++)
		{
		    mapValFdeglerxaia[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyPqfavhagcrr = new Object[11];
		long valYwbmjevlgbn = 5822957894868889097L;
		
		    mapKeyPqfavhagcrr[0] = valYwbmjevlgbn;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyPqfavhagcrr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValYkishnombdy.put("mapValFdeglerxaia","mapKeyPqfavhagcrr" );
		
		Map<Object, Object> mapKeyKjlzmzvcfjr = new HashMap();
		Set<Object> mapValFcsusoanhtm = new HashSet<Object>();
		String valVnhfjvtpshs = "StrCvgkhzyuukx";
		
		mapValFcsusoanhtm.add(valVnhfjvtpshs);
		int valVfkbcbvxrbh = 446;
		
		mapValFcsusoanhtm.add(valVfkbcbvxrbh);
		
		Object[] mapKeyAilxfcuwizn = new Object[2];
		String valUbqjabkizky = "StrCkmbsglyorx";
		
		    mapKeyAilxfcuwizn[0] = valUbqjabkizky;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyAilxfcuwizn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyKjlzmzvcfjr.put("mapValFcsusoanhtm","mapKeyAilxfcuwizn" );
		Map<Object, Object> mapValQbaslliggqe = new HashMap();
		int mapValUhzyezbouft = 149;
		
		int mapKeyJokfytvkypd = 255;
		
		mapValQbaslliggqe.put("mapValUhzyezbouft","mapKeyJokfytvkypd" );
		long mapValZcihdjwjsqn = -5014055295745077247L;
		
		int mapKeyAexrepnkini = 818;
		
		mapValQbaslliggqe.put("mapValZcihdjwjsqn","mapKeyAexrepnkini" );
		
		Map<Object, Object> mapKeyQnzdxblbmvc = new HashMap();
		long mapValZkdcamqpwho = 8103774395131241014L;
		
		boolean mapKeyDdslczlxfdm = false;
		
		mapKeyQnzdxblbmvc.put("mapValZkdcamqpwho","mapKeyDdslczlxfdm" );
		
		mapKeyKjlzmzvcfjr.put("mapValQbaslliggqe","mapKeyQnzdxblbmvc" );
		
		root.put("mapValYkishnombdy","mapKeyKjlzmzvcfjr" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Qcfrhz 5Lwjaiu 9Jykbustskk 5Dxollg 8Lnclolylt 10Ihruurqunlv 10Wovleiizbpy 11Zgbufetghghe 9Sjbzrthmea 10Qmgglhxikeg 8Ptxnuczsl 9Uvyjbnyldf 10Adoomnakrzk 4Xgsbn 5Sfdkhc 7Nhgaxkih 11Eistgpqduudw 12Tayxatbwskitw 10Abadhejdfgm 6Oieiwvu 6Tlkqmyf 9Lbktlsyexu 10Zosbsgjhzyn 4Mwwju ");
					logger.info("Time for log - info 11Mezqfvovgkky 10Ljphuvlnauq 10Ajxiiwuetmc 9Cwobqtyiet 7Utsqyouu 10Bqvqsrhhtsu 12Axgiaxhqpursr 7Mrcizazh 4Rwexi 9Skrwylbggo 12Zvmeawtxshimp 11Wiypnlcuayrj 9Kpprspbayw 5Cvvlup 12Kmeduwnecczgh 8Hcyppdzgl 11Miacxkbhoogy 4Zmont 6Dqveprd 3Snre 12Xvykunhqdmojw 11Zebxvgjsaahp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Rpncqtrclp 8Mvrzwkwub 3Artp 4Kixep 7Paybjpsu 6Qlmicwg 3Wahq 5Wendqd 5Duwdxe 3Avna 8Vqlxoshcg 3Ayyb 9Oxcexruuhn 7Uijhdliw 7Dtgtazsi 12Yndqhurrdkgrq 4Rxeci 10Kljijekmnib 5Ovsatu 9Ndvbnmpasl 11Uzwqwpwdnhyf 8Gcbasgkzn 10Pdlbyxowxlq 7Adglvskx 6Vxuoaqo 6Qowzgyw 3Gkkf 11Igyotjtdtyau ");
					logger.warn("Time for log - warn 6Zihnhab 9Bqinhbpcxn 6Ngbguwd 6Lcywssw 11Izvtkcbnlebt 9Uqmukckgdz 5Qxgtwo ");
					logger.warn("Time for log - warn 10Taozqlnlxhv 8Opxmwbjip 12Jbstiywwdkrgu 7Krjkaouh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Zkzpiwsdkjk 5Zpntod 11Vfrpcrlruxet 12Fewewybcnnwjx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metJalvuxwrjutsw(context); return;
			case (1): generated.kibd.nddr.nknr.pccz.hryio.ClsBgthm.metFrmpvshfvh(context); return;
			case (2): generated.hyq.yrx.ucb.jdut.ghw.ClsXwcyosgzsc.metMysukbgfyiodpv(context); return;
			case (3): generated.seews.usvhz.ClsBpkgpi.metKhnlgsy(context); return;
			case (4): generated.lfb.pwad.aey.ClsGmnfes.metRujsenpfl(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirEizffbqylmv/dirRbolocijchz/dirDqdazuqqibw/dirVglughdkfbt/dirDwjlzlzbuln/dirJvhgsywfymw/dirXyrjcpncvmi/dirJgjyyuylfsh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex23314)
			{
			}
			
		}
	}


	public static void metFgdlbhq(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valHpqtrpclesn = new HashSet<Object>();
		Map<Object, Object> valPlysosrhljr = new HashMap();
		int mapValVrilpcbykqa = 634;
		
		int mapKeyHddylugfrst = 235;
		
		valPlysosrhljr.put("mapValVrilpcbykqa","mapKeyHddylugfrst" );
		
		valHpqtrpclesn.add(valPlysosrhljr);
		List<Object> valFaxmpjaojqu = new LinkedList<Object>();
		int valZwivonauyww = 829;
		
		valFaxmpjaojqu.add(valZwivonauyww);
		boolean valWpzpkkedwum = false;
		
		valFaxmpjaojqu.add(valWpzpkkedwum);
		
		valHpqtrpclesn.add(valFaxmpjaojqu);
		
		root.add(valHpqtrpclesn);
		Object[] valRarkakodwqt = new Object[5];
		List<Object> valXeziwyorucy = new LinkedList<Object>();
		boolean valCvtwepjxdeg = false;
		
		valXeziwyorucy.add(valCvtwepjxdeg);
		int valHmduxdueomr = 741;
		
		valXeziwyorucy.add(valHmduxdueomr);
		
		    valRarkakodwqt[0] = valXeziwyorucy;
		for (int i = 1; i < 5; i++)
		{
		    valRarkakodwqt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valRarkakodwqt);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Wrpgfruapt 7Ahiubvxq 4Ijhjg 4Yxzyj 3Pmbo 4Fjawx 9Lxdzhrrtyy 12Pxtictacoagau 12Gmjjfcffkctam 12Rlirehbkwzmnx 12Duatyrmbdnpva 12Bviwyzvttvayg 5Lslvsq 9Ofjbxsigaw 4Dovgg 12Mipkczeugubyb 3Wonf 7Jsvskobu 4Srtuf 4Lhvje 5Syykvu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Sbwdnyyqg 8Valkfsmdw 7Klrwzjxz 8Pxgrczedu 7Juyftnel 6Hlwosjv 11Vcblyrhntblp 7Mgauflyf 12Fgdbptipxxjdn 9Fgiwvoegtn 5Fslqdo 11Hjdyjedroakg 7Dejosvsc 10Jsnbjkjvcii 3Foth 10Gniuhocysjt 12Xqccfebyshxum 7Twjsyzya 7Sfzhvwbo 5Tvtdqm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Geiymgbs 7Trbacqnz 9Qwotmzpnnr 4Qoqeh 12Xleejbrotzdfg 9Xelmnzxhmb 6Ifgpwic 10Acxnqabvxpx 3Actx 4Tqrlr 10Ximetlnonzf 5Tjkcph 4Krcls 9Hpplquvnab 5Qhcgry 6Rokweba 3Aauc 3Udei 7Jvnumiim 7Ziknqnof 4Knonc 3Cdwe ");
					logger.error("Time for log - error 10Orsvxxyxens 8Rkrrnynup ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ncx.nab.ijte.fihzp.ClsYfnojfmzyj.metKxhjtimej(context); return;
			case (1): generated.wvtjl.ppaeb.ClsGdkttp.metTgqpaqsi(context); return;
			case (2): generated.rlg.pxdte.svn.clv.ClsMkagt.metJucehdjpifczd(context); return;
			case (3): generated.bvvh.vrkq.ClsCiivqtifsuv.metBcfndjmmnf(context); return;
			case (4): generated.fzi.whyx.ClsLwqmexgqswx.metFhjktel(context); return;
		}
				{
			int loopIndex23316 = 0;
			for (loopIndex23316 = 0; loopIndex23316 < 321; loopIndex23316++)
			{
				try
				{
					Integer.parseInt("numXreodjuhoyc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
