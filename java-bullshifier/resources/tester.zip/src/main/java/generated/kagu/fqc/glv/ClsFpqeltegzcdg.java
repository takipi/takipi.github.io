package generated.kagu.fqc.glv;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsFpqeltegzcdg
{
	 public static final int classId = 458;
	 static final Logger logger = LoggerFactory.getLogger(ClsFpqeltegzcdg.class);

	public static void metJxmcdabkbl(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valZijzgzukttg = new HashMap();
		Map<Object, Object> mapValXcxnfnykuub = new HashMap();
		boolean mapValVzsrgbblljm = true;
		
		String mapKeyAmjwjblmcdo = "StrBovebvjvuts";
		
		mapValXcxnfnykuub.put("mapValVzsrgbblljm","mapKeyAmjwjblmcdo" );
		String mapValIdatxcomjxv = "StrRgmdbrmndxl";
		
		long mapKeyKtupqqogugb = -3191180424985050881L;
		
		mapValXcxnfnykuub.put("mapValIdatxcomjxv","mapKeyKtupqqogugb" );
		
		Object[] mapKeyEgkiahxjjmh = new Object[9];
		long valPxeyojxgsgy = 5702176834457262402L;
		
		    mapKeyEgkiahxjjmh[0] = valPxeyojxgsgy;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyEgkiahxjjmh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZijzgzukttg.put("mapValXcxnfnykuub","mapKeyEgkiahxjjmh" );
		Object[] mapValIcnjcgjvhjp = new Object[9];
		boolean valJhxbksblejp = true;
		
		    mapValIcnjcgjvhjp[0] = valJhxbksblejp;
		for (int i = 1; i < 9; i++)
		{
		    mapValIcnjcgjvhjp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyTogimmycvng = new LinkedList<Object>();
		int valKtmtzinwwvr = 792;
		
		mapKeyTogimmycvng.add(valKtmtzinwwvr);
		
		valZijzgzukttg.put("mapValIcnjcgjvhjp","mapKeyTogimmycvng" );
		
		root.add(valZijzgzukttg);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Ecpt 11Souihvsxcrdh 10Dkzzmhgqrzu 7Wctpapcr 7Kreqglmx 9Sdxsiipvix 6Suqxigt 4Qofrn 6Yjeqhjt ");
					logger.info("Time for log - info 11Iowomgcrsrnv 11Ntesckfcvugv 3Mign 12Zgxvghfsjhiqk 10Jmnestamikl 9Qklafvvtba 5Gdaxgb 4Dtlzi 9Aadfjxphqp 4Bciap 6Purlvcf 3Cbmh 12Qupgezlbtgumc 7Kwliltxl 3Qjqf 3Nhyx 12Sffgsmlvqlbfy 12Sazturzuuauyv 9Braxrafcie 4Azvlm 4Izphd 5Ddmuwq 11Mjzgcguzwynk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Kfwzmmgobnnj 8Xidcpdggk 12Ogfcdjfverrro 4Ikvxd 11Laiwcjsracef 6Lsdslmo 10Aprqmvkzayv 12Rpndpjyrheyhl 3Deft 3Grjp 7Gxawogky ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Oppxoqowwo 10Vuvzkaaztuk 4Xxwwz 7Vcugajxw 7Ssknnqlp 11Hxvbxvebrocu 3Nvjn 10Toqtqioiece 12Onfapaemcoytu 11Defjbzmaicdr 5Ejmdzh ");
					logger.error("Time for log - error 6Jvirxxc 4Fikui 3Yabg 9Khosdttueu 9Eesiowhrue 4Xqqoi 9Cmgzqmkffx 6Mdkqicg 3Cmfq 9Edgfzplqen 4Ijkod 4Nebyr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.agyh.aakn.unf.yzvm.uvtp.ClsPvvezxsnka.metBiufhu(context); return;
			case (1): generated.ryyqn.hafq.oqfv.ClsRsktinox.metKcbbyaslqqejp(context); return;
			case (2): generated.yzf.fayrw.fbm.pexsg.rxfb.ClsSblyqahlwj.metPkvrinos(context); return;
			case (3): generated.hqq.wtuo.vap.ClsNidilkbt.metWxcpfhso(context); return;
			case (4): generated.lmq.wwll.mcjoz.ClsBqjxdpu.metGccfwaiyfrrux(context); return;
		}
				{
			int loopIndex27717 = 0;
			for (loopIndex27717 = 0; loopIndex27717 < 1308; loopIndex27717++)
			{
				java.io.File file = new java.io.File("/dirYytvlqpejrl/dirMfoljmtasgc/dirZyoovqjziku/dirWybxmgovfcb/dirKkybpimiato/dirHxlestheoiy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((Config.get().getRandom().nextInt(891) + 4) - (9929) % 988157) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varRvvpzavxjci = (7539);
		}
	}


	public static void metXtrkulrkzj(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[5];
		List<Object> valPucdrhvfaph = new LinkedList<Object>();
		List<Object> valBmapccukvsz = new LinkedList<Object>();
		long valTvckxzhlmxl = 6457334287926969343L;
		
		valBmapccukvsz.add(valTvckxzhlmxl);
		
		valPucdrhvfaph.add(valBmapccukvsz);
		Object[] valEbzdwnnasux = new Object[3];
		String valGntxcjstyei = "StrWuejyqcqfcs";
		
		    valEbzdwnnasux[0] = valGntxcjstyei;
		for (int i = 1; i < 3; i++)
		{
		    valEbzdwnnasux[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valPucdrhvfaph.add(valEbzdwnnasux);
		
		    root[0] = valPucdrhvfaph;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Uylotjyqswr 9Zpugwuqmcc 5Gzarir 6Hewgxip 12Ievsukgmnncwe 12Twjvmhmwlnrzk 6Fftxwxk 8Uvbtqnjsl 6Anoblkl 6Kwngjql 6Ofylreu 5Jmsnlb 3Pazs 5Peuqjm 8Dnrzrlaee 3Ucrn 4Hrtdx 10Qfzswjxrtxr 10Zzuunnesfql 10Aclzxkwwkel 8Rpzkydqdj 12Lgltemrbrvhkz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Xvze 11Vuiejwkhccfy 3Joyq 8Yphbieeua 5Zatzef 10Inthvikcfdf 5Arpfat 11Ecbkcgrubanq 6Ovuqvzw 5Hjemzq 3Xvck 12Dtmdcxzuikiox 8Lchtqwhtm 11Husbrvgskeqv 11Ojfrfwtemjvk 5Ivafdw 11Hgtclxpfwtov 12Kevchixywhesc 8Edzckbzfx 5Rimhwe 7Deddzemd 3Nbdn 6Wooxdcy 7Gpbtiqli 10Inehpukglrp 8Shdibunda 6Oxuuhqt 3Sdbu 5Srqleo 3Gutm 8Ttbcucfid ");
					logger.warn("Time for log - warn 4Mtgvi 9Vcdkcmuhkq 7Habfnxzj 12Xjokdgebrgouh 3Uajq 8Ukqvmoflu 4Lzlkl 5Oyonda 8Jvbsrdwhq 8Xuymabuzj 12Mcsxiobwhxnzm 6Kxqmrcp 6Jebshcs 10Brcjlselsfg 6Pdphpzv 10Ohzrpurzrux 7Kgrddxpa 11Ljiydptsudej 9Yahefmnuvs 12Aihppozukdhja 8Vmslkyqlz 11Gberpuepnafg 7Lfdxypik 10Pzluxcyzemw 12Wceyhxytkglrs 9Oymohvxaps 10Fiqamprfvty 9Ihliarircr 9Ocykixjiyo 3Ifmb ");
					logger.warn("Time for log - warn 7Hikjbnae 6Tjaiaro 7Rmhxlade 5Ynajkt 6Rlhdeky 3Bayd 6Soxxxdl 3Itzx 11Dnenuyifhwsi 7Syxswloe 12Gymtofiajxpzf 5Hhbdjn 4Fzmwf 6Umeqqgg 8Xofyllbqw 10Kkxbroerbbz 5Zwjhec 10Yfvonwjiqsj 10Ejlzftmwzil 11Hhqlfikppwzm 5Ovoieh ");
					logger.warn("Time for log - warn 4Hprdy 10Gmpcfqvcwqv 5Nymjwb 7Rloluqbp 7Xgihuqbn 4Jmowe 7Uqmzbfyg 8Wjettjhhu 10Tchazaxmsik 10Pbokvkyshhm 5Lktdoq 10Jmsgaacekca 3Plcr 5Pqzcbp 6Rfogprs 7Egamragr 11Lydqwkliyssw 8Wktcfbpsb 6Rpkpzgb 11Acmtbrrljbqy 7Ketftlcw 7Hlrbwzou 6Cfpqmaw 12Pnqcmyiifcqbu 12Jkpwlwybszjsy 7Xiitucmb 5Xmpvem 3Ymxa 6Tqytilj 6Acfctzb ");
					logger.warn("Time for log - warn 6Kyennph 12Yxremglzhnrrn 8Fktszvyct 5Fbgtps 8Ymmiryfwr 6Gpzlozo 5Atqpkd 8Dvxhhmbgu 3Lkrk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Qbrtwgyuhq 9Gcpacrnlhx 7Nypscphw 3Pugk 9Nfzmprmmml 11Rkhrcfqhvqti 6Vojgvky 4Yiuqj 4Sssuq 8Rzjukejqs 9Alpqhqcxkv 4Ydtbq 12Hdhycgpkfjlkz 9Tmhlvrvmzd 6Ntiguuw 3Jjhs 12Regeyijmzfmnn 8Ymaqydard ");
					logger.error("Time for log - error 3Rbpe 12Ftycckfdxmghu 4Dpmqy 3Qkgi 10Nsevcuemvhz 3Ogaz 5Qesrua 4Hjnmc 12Bspaemdcuyxey 8Abnalmdzu 6Caviimo 12Lkfparlklbpsb 9Ogndwfbimg 12Xcgvlpylhcgnw 8Ldyjvwnth 10Bphroxqskdn 10Tzstscvrhhz 6Xxmbxay 5Nzrzwg 8Xjrmjjjiq 9Qtkkwogkfa ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.eddt.homo.syk.wqll.dyeuq.ClsYzlmjqrjjp.metMqehtaaykikdy(context); return;
			case (1): generated.xqnb.haff.rrb.lurge.ygwj.ClsNrgsacrzyefzg.metXouqbpti(context); return;
			case (2): generated.usy.jqyb.aoxm.cmxc.tdb.ClsGdtxkhc.metYudmw(context); return;
			case (3): generated.pgg.urfbp.dpry.ClsLqnnoewxwh.metHqhcu(context); return;
			case (4): generated.dyv.vxo.ClsWrwpfswr.metTpeyljwzklrtjz(context); return;
		}
				{
		}
	}


	public static void metCggjvqrbftuem(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valMwecteeexny = new HashMap();
		List<Object> mapValUgysjrqyigu = new LinkedList<Object>();
		String valCidrmprdbyz = "StrMwajnkaxpwm";
		
		mapValUgysjrqyigu.add(valCidrmprdbyz);
		int valAzkrsyzteoi = 850;
		
		mapValUgysjrqyigu.add(valAzkrsyzteoi);
		
		Set<Object> mapKeyLllfceddczx = new HashSet<Object>();
		int valIcqcerwadia = 162;
		
		mapKeyLllfceddczx.add(valIcqcerwadia);
		long valCdpalyhlnia = -2829670137746803328L;
		
		mapKeyLllfceddczx.add(valCdpalyhlnia);
		
		valMwecteeexny.put("mapValUgysjrqyigu","mapKeyLllfceddczx" );
		
		root.add(valMwecteeexny);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Sblyjylgzp 9Wuoszvgemm 4Jjscp 11Kenwvpqvpflz 6Eahmnvp 10Pqjnvwektlr 8Vqymjceza 7Wehlfclt 10Mgfuhjivcge 5Goducj 4Fjpav 12Hqjmykgxyfwso 5Epqtol 11Ydjqkbppudcm 6Ailnvrt 10Tnovfkzblwy 7Ctibixbf 9Oeutedpexa 10Jpcrzmmpdfg 5Qxlodx 8Bqdbwnnqy 7Grdjxdeo 5Gptahi 6Pdsinzv 4Ivkvy 9Lxxontwcnk ");
					logger.info("Time for log - info 8Tcgnawicz 6Gbtrdow 8Wygvpbnow 4Neiit 7Nayrguzl 11Quljsgrauqzf 8Udmgnoihd 9Ztvbjqfxah 11Mrsnhcruahha 4Unigd 9Xropkranyt 10Kpbjnwlnahf 6Lnztomp 12Vabgmyejlzvbu 12Lxwpovgtmftrk 9Erjxdjiwcb 10Asvojpervfh 9Ntcsjndgrq 11Fdickfdyjcnr 3Sxkc 3Oenx 3Jurn 12Smqplmqlydfiv 12Vlwlxydkyoxij 4Tkwtu 5Dmdoyy 9Zevcfuzdti 5Xflyuf 9Lloiozpxcm 8Zlrwtctmm 3Pxjg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Akwwbzbmbiiwc 4Pbzjn 7Jkwfdluf 4Iqonm 9Wdvkwpabyr 12Eaibnhjragcgn 3Ujqw 12Wdyqcugtlhlen 8Wqnvwjdkq 11Ophganqkjzen 6Tuhsguo 9Ueddzmijla 6Xzhnbtb 7Qyxpybwh 4Raebu 11Oiigwjmdtfqj 5Ysldgz 5Dfbehi 4Klhjz 10Niiibjlchya 12Fuelyfhcytpdc 9Wkwdvrvnkk 8Ukiufrdvt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Izhtfdobo 9Brkibnwrzw 9Bnigkmjpfv 8Pcbipjsqp 4Oekku 4Zkydc 6Lhlhehc 3Stam 9Lfqudcgjol 9Sdtikqgwzz 4Vjjti 3Yklc 3Hsie 3Vwpu 7Utymzaip 7Dbvjjhiz 10Iwjnacmdydt 11Inxnnltgfqyb 7Atkjgkar 5Vfcysi 7Kdbpcfgn 7Mdjciept 8Bddlxiraq 10Qhysfaublmj ");
					logger.error("Time for log - error 10Ymrfckdiifm 7Njqlzxpx 7Liguoozf 11Ceamumouvhhd 10Tnynaevjjcp 9Boqjooejqm 9Jkjesfcyef 10Nanlbniaspf 7Icuiaisx 4Kxraa 6Uahykey 9Pronwaateo 8Ezrqbdgtg 7Ppvqfetv 10Uvdagricylz 12Gmvtsbtrxyhwc 9Ugpkyebrro 12Bqxkbxnbhmcgh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jrx.knq.qgl.klpmp.wqhuy.ClsPrfpvgkjefvagy.metFzjcvfpdxrxcop(context); return;
			case (1): generated.jgye.cou.ClsWhiobyn.metGldtri(context); return;
			case (2): generated.elv.qjwox.npj.oxv.jth.ClsNewmedi.metSlokswuz(context); return;
			case (3): generated.qyalc.lus.ClsKvouelboluo.metVctwjruk(context); return;
			case (4): generated.tei.zyt.ClsLkzwcb.metMtlppg(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex27728)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numYhbcsqnljzf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
