package generated.rludj.zqn.tuc;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsSdrvvvm
{
	 public static final int classId = 111;
	 static final Logger logger = LoggerFactory.getLogger(ClsSdrvvvm.class);

	public static void metSmvhpgejrya(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valXhchmthbywf = new HashSet<Object>();
		List<Object> valLgfawhjqgza = new LinkedList<Object>();
		int valQncydchabck = 514;
		
		valLgfawhjqgza.add(valQncydchabck);
		boolean valTqyzconwino = true;
		
		valLgfawhjqgza.add(valTqyzconwino);
		
		valXhchmthbywf.add(valLgfawhjqgza);
		
		root.add(valXhchmthbywf);
		Map<Object, Object> valMxxykvhdmnw = new HashMap();
		Set<Object> mapValOvqytsoyzkn = new HashSet<Object>();
		long valLvbdfmbjskg = -3586510633371075934L;
		
		mapValOvqytsoyzkn.add(valLvbdfmbjskg);
		
		Map<Object, Object> mapKeyGchjwqwkavi = new HashMap();
		long mapValLusnkovsiwz = -7574172369376589814L;
		
		boolean mapKeyBjmvqsqckuf = true;
		
		mapKeyGchjwqwkavi.put("mapValLusnkovsiwz","mapKeyBjmvqsqckuf" );
		String mapValFfifhbwtyqs = "StrNwgddvjrwwz";
		
		long mapKeyCuithjycuey = 8969743167808092615L;
		
		mapKeyGchjwqwkavi.put("mapValFfifhbwtyqs","mapKeyCuithjycuey" );
		
		valMxxykvhdmnw.put("mapValOvqytsoyzkn","mapKeyGchjwqwkavi" );
		
		root.add(valMxxykvhdmnw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Slkdydzudsys 6Fbkrqjk 10Vfigcuviban 9Holgimlkze 3Ykhg 12Qhkqtibbpaehc 6Txdfqtg 5Gbvpvc 7Umafeqcd 6Vbunpjy 4Jkbqd 3Ucsx 4Mhels 10Rigxggwwzkj 9Ddiboybhbd 8Gfvfulpfy 6Uulfasx 7Aarxwmcb 5Crefyt 8Qutfifljy 7Zrkgvczs 12Ojohoadlicwbv ");
					logger.info("Time for log - info 9Mmhyufucyr 4Eamtn 5Zlogkk 6Fldqsov 7Nbjykebb 9Dkrvkgpjeb 6Kzsjyte 10Zjisncmokhk 12Rrcwpsrpvqsrr 5Lnfuqa 4Igemv 8Zhppjqdbl 4Pkqsa 6Tfyktyo 11Mnhlqvhxvpeb 10Hjwkynxxrcs 10Gmvdvlrczed 9Lypyhbuhiv 9Repukvfrid 6Eweefed 7Zphbfboe 6Pcegywt ");
					logger.info("Time for log - info 3Kpjd 9Neqfjlaspb 4Kgtwy 9Npkbqvgray 6Mmtizfu 6Mrvavyj 6Zkclany 5Fumylm 8Ltnccnsua 8Jpqnuxeqo 10Eqdfmnxtmmy 6Fuhkndl 8Pngndzryl 11Dlzqnalijtbc 3Bdcv 12Gtmgqiulaftce 4Rjfmo 8Jtoewgerv 3Rotv ");
					logger.info("Time for log - info 12Bryqzlnxoeqxz 8Mwvwrmieo 7Qmhfrero 10Wjjmvcgdztc ");
					logger.info("Time for log - info 9Ecybiypwbv 7Ysojhjlm 5Gknjti 12Offhmrdfavwwr 7Bbxxepoc 7Dmzfgyqk 12Edlyoxjuygwrk 6Qtpehur 12Kccxiaudffahd 7Asdrdcyr 8Ciefgreuu 3Xump 10Pfspaspiwwm 11Vmfugkbyunrf 12Pvjjzafzybrjb 5Eofcnm 6Nuzjqyo 6Fwlcuvs 4Pqjtr 7Lejedbcy 3Gcwk 5Hfirki 3Nkbz 4Ukfud 12Vwsjducptkiea 6Dezznpq 4Lshqf 6Jmztgdn 11Prwbjjttkpbh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yckj.gphin.bfwh.sqsp.yue.ClsOefoqvazjwfl.metFjgyzxmr(context); return;
			case (1): generated.munb.ijbed.gztfl.ClsHbtirm.metFoavrf(context); return;
			case (2): generated.xvt.cmvm.fgj.efz.bawb.ClsIacmgbgh.metHijjkg(context); return;
			case (3): generated.rzy.sppai.eju.hupq.ClsPjendhgbojpy.metVwpivrvw(context); return;
			case (4): generated.mpex.dpd.nziyl.ClsMvkjogpaegzqh.metCcluioiaauedgi(context); return;
		}
				{
			int loopIndex22013 = 0;
			for (loopIndex22013 = 0; loopIndex22013 < 7372; loopIndex22013++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex22014 = 0;
			for (loopIndex22014 = 0; loopIndex22014 < 7088; loopIndex22014++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metOhtuehbexx(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valUivbsqopyab = new HashSet<Object>();
		List<Object> valWexnfxwblpj = new LinkedList<Object>();
		long valWaxpczxzyzk = -4317810118114552393L;
		
		valWexnfxwblpj.add(valWaxpczxzyzk);
		
		valUivbsqopyab.add(valWexnfxwblpj);
		
		root.add(valUivbsqopyab);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Ehgb 10Piggznmquxf 11Enhlnfpkenms 5Kjaucw 12Kbnydcgxwnqpo 11Eotximfwrijn 6Ltfdded 12Foaxxulmkujik 3Jdxy 7Zmbyqmsd 6Rfljqsg 6Hodkmta 8Dcubqltkh 6Ctzcfqv 8Gfwtbjxyt ");
					logger.info("Time for log - info 8Jzruqnail 3Wjko 12Hgrpfievpeurh 7Udghxqnb 4Ojekt 9Bckrsklzwp 11Wguhbpgukwzk 3Cejy 3Erdt 3Lixt 8Kiskqgtmx 9Nwxwjngclo 11Xellqquowezu 4Wmyqn 6Jqfqjoo 10Szssrvapgra ");
					logger.info("Time for log - info 12Xdouoeqveusng 3Jxal 10Icbxiqarbmg 11Kvxttaawjfcj 9Nvpfvmnpue 9Yfkumcjcaz ");
					logger.info("Time for log - info 6Pbugeje 7Llnkxwgf 3Lczo 3Dvgg 7Ivrhqwur 10Kncjvfobpag 8Jpcptkmhg 7Ouxmuyvm 12Lluwactnchyqb 3Ignu 10Cjmuhkfkhqp 3Uqvy 10Nqkizzbcigx 11Pdzxgspxvbin 12Foukwisareugi 10Nilucniubng 5Muuxfs 5Mveuqp 3Ipdn 9Rghmnmaicl 6Bjszmho 6Gnugwpj 11Rupqrlaychmo 4Jmnms 12Uidqsywsaxcif 5Snnshc 5Tznhvx 7Xtqdqeug 5Zkjhjn 5Nlajgv 6Jvimrhp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Htrikluhn 5Mulnub 4Qtwrd 11Znaadwtwgjdv 8Pfjfulrkq 12Xhmbwazpezhtm 5Qfangj 4Prxfj 10Fwhydpgshxx 8Oxftdauyw 5Xdaims 4Skucw 5Btzskr 6Bhueqne 11Xbqxrwryuzzz 12Mzzxtijczpojt 9Lfppcnbbdb 10Snghullpfnj 10Pvtfgadpcsk 7Sfeukrwj 9Bmcfsrjnjo 10Pczuaitfkbj 8Rpnxllbfx 12Knqgbdmwgmdbb 12Zlwslwlvtwfqg 10Guhevznikag 3Cvze ");
					logger.warn("Time for log - warn 12Lwoehquszybro 3Vnaj 3Qtrv 5Bqimnw 3Nefu 6Bkprhcq 8Hqjrjgpzl 9Fuqsnfzevt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Btfl 3Jwgt 3Vics 9Undokrwqit 4Nymov 12Yujemzunsfydm 9Pgazgyfpsg 10Thxxbtlkspc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qpe.ifudp.xgatn.jzg.qau.ClsJymdeqopgpbo.metZmvopmy(context); return;
			case (1): generated.lbx.ujwf.wayq.ClsEtipntwjjs.metYkgppbepgd(context); return;
			case (2): generated.wwon.szd.tew.ClsRzjcfflrioiqf.metRchlwwntsqlvan(context); return;
			case (3): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metTlqjnsfger(context); return;
			case (4): generated.kagu.fqc.glv.ClsFpqeltegzcdg.metXtrkulrkzj(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(806) + 4) * (Config.get().getRandom().nextInt(843) + 3) % 935183) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(853) + 6) % 465086) == 0)
			{
				try
				{
					Integer.parseInt("numHavxksshpgr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex22019 = 0;
			for (loopIndex22019 = 0; loopIndex22019 < 5627; loopIndex22019++)
			{
				try
				{
					Integer.parseInt("numGnkclsweoby");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex22020 = 0;
			for (loopIndex22020 = 0; loopIndex22020 < 6373; loopIndex22020++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
