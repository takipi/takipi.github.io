package generated.ylqx.lamew.rrd.tiu.hut;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBorecfhsp
{
	 public static final int classId = 274;
	 static final Logger logger = LoggerFactory.getLogger(ClsBorecfhsp.class);

	public static void metYiffmzigpfthg(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valDrhwepcupwv = new HashMap();
		Map<Object, Object> mapValKjbfspajofm = new HashMap();
		int mapValHahfftoegdh = 193;
		
		long mapKeyRvteoxpkuwj = 4887668440561287048L;
		
		mapValKjbfspajofm.put("mapValHahfftoegdh","mapKeyRvteoxpkuwj" );
		long mapValTlggxsiedcn = -1141976763252581800L;
		
		int mapKeyTnnrtbqkiez = 954;
		
		mapValKjbfspajofm.put("mapValTlggxsiedcn","mapKeyTnnrtbqkiez" );
		
		Object[] mapKeyUrmkgdbjcwj = new Object[8];
		String valVgzcggaforg = "StrXlbxbupdtmq";
		
		    mapKeyUrmkgdbjcwj[0] = valVgzcggaforg;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyUrmkgdbjcwj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDrhwepcupwv.put("mapValKjbfspajofm","mapKeyUrmkgdbjcwj" );
		Map<Object, Object> mapValDmbmxpasutl = new HashMap();
		boolean mapValGpebyhzjwog = false;
		
		long mapKeyRkfcxdbzxld = 8289632864134785970L;
		
		mapValDmbmxpasutl.put("mapValGpebyhzjwog","mapKeyRkfcxdbzxld" );
		
		Map<Object, Object> mapKeyTpxppnpgdvc = new HashMap();
		long mapValOefpkhnimau = 1444395777937433824L;
		
		String mapKeyHxgayjrjqsx = "StrHkrrblktanc";
		
		mapKeyTpxppnpgdvc.put("mapValOefpkhnimau","mapKeyHxgayjrjqsx" );
		
		valDrhwepcupwv.put("mapValDmbmxpasutl","mapKeyTpxppnpgdvc" );
		
		root.add(valDrhwepcupwv);
		Map<Object, Object> valFswkgtjgjrm = new HashMap();
		List<Object> mapValTaizheqwkuq = new LinkedList<Object>();
		String valHigkwouyecb = "StrGbjcsmoeunt";
		
		mapValTaizheqwkuq.add(valHigkwouyecb);
		
		Map<Object, Object> mapKeyVlswksckbmm = new HashMap();
		String mapValOovkombjall = "StrFetajpqyjrk";
		
		boolean mapKeyCuodqhhhywe = false;
		
		mapKeyVlswksckbmm.put("mapValOovkombjall","mapKeyCuodqhhhywe" );
		long mapValPhmnldtuxnk = -2474061508467951321L;
		
		boolean mapKeyCjfckupmark = true;
		
		mapKeyVlswksckbmm.put("mapValPhmnldtuxnk","mapKeyCjfckupmark" );
		
		valFswkgtjgjrm.put("mapValTaizheqwkuq","mapKeyVlswksckbmm" );
		Object[] mapValBxmrfsccich = new Object[4];
		String valXmchxzwxbds = "StrTwikrqanprv";
		
		    mapValBxmrfsccich[0] = valXmchxzwxbds;
		for (int i = 1; i < 4; i++)
		{
		    mapValBxmrfsccich[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyEpdevsfavwe = new HashMap();
		long mapValOylyulhornw = -4786042681116690685L;
		
		boolean mapKeyTutbcbzjjrq = true;
		
		mapKeyEpdevsfavwe.put("mapValOylyulhornw","mapKeyTutbcbzjjrq" );
		
		valFswkgtjgjrm.put("mapValBxmrfsccich","mapKeyEpdevsfavwe" );
		
		root.add(valFswkgtjgjrm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Gdzmyk 7Aunbnwmx 12Gpswucimioaba 10Lgtgfjeovkb 5Fwzndc 12Rawaonlqrnvqz 4Ghlsn 6Amdoxoo 11Yjctluxwcrxy 4Apsfx 7Cjnhwnfd 11Oxzkycgorfev 3Bzxu 7Nocztgdn 7Pfzldfns 8Syapzmvgd 10Fxutnnlhzwd 3Fmkw 4Hghaz 8Nqsfgkrea ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Ahrsxndw 6Jmpkdgp 7Bflvhwmz 3Moln 3Hrxd 3Axlh 12Chiraegmbuqhu 7Svupscaw 5Fmxnrc 6Hpuhdch 11Ppctpspfqdwd 9Nurrpzsqwp 9Faooapyvbb 10Kgqmzzyrtav 10Ryrwkytqzno 10Hlnnsvisdra 7Eaqldqwu 4Tgdlo 10Wwlqscfakep 9Tghgjkpkhb 10Gylkjjfbcry 3Xqfe 3Gash 10Dpaoduxyltl ");
					logger.error("Time for log - error 5Eiwlgn 3Bbmw 10Wvqwphkhufa ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vspck.scvf.gxvmo.ClsBudbedmvgnjpa.metHunirsyqpt(context); return;
			case (1): generated.vntk.clexr.ClsYpzzbhceuihjz.metHptaqt(context); return;
			case (2): generated.oucap.zcbrm.jbhm.yte.ClsEpzgpbjqjhr.metMcvlpssn(context); return;
			case (3): generated.iwmr.swhrn.ClsOqphojsm.metZpnazknfwlswat(context); return;
			case (4): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(563) + 8) % 173130) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(248) + 0) % 792380) == 0)
			{
				try
				{
					Integer.parseInt("numHvzsawqefmh");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numGrltnmyytfo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metVjvfkt(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValJeccblmjuyx = new HashSet<Object>();
		List<Object> valKgncfcuifey = new LinkedList<Object>();
		int valHvfscmcfyao = 88;
		
		valKgncfcuifey.add(valHvfscmcfyao);
		int valAdfooejnlot = 508;
		
		valKgncfcuifey.add(valAdfooejnlot);
		
		mapValJeccblmjuyx.add(valKgncfcuifey);
		Map<Object, Object> valImuggfwsgrx = new HashMap();
		boolean mapValVbnbhldxrru = false;
		
		long mapKeyEeorlphndvb = 5849580174985073211L;
		
		valImuggfwsgrx.put("mapValVbnbhldxrru","mapKeyEeorlphndvb" );
		
		mapValJeccblmjuyx.add(valImuggfwsgrx);
		
		Set<Object> mapKeyXjudiaafusa = new HashSet<Object>();
		Map<Object, Object> valIutsitymdvk = new HashMap();
		int mapValOgswebfteid = 941;
		
		long mapKeyIijxoxbmspk = -6255861256427477042L;
		
		valIutsitymdvk.put("mapValOgswebfteid","mapKeyIijxoxbmspk" );
		int mapValNxjauusaeac = 804;
		
		boolean mapKeyPxefqqwjtmy = false;
		
		valIutsitymdvk.put("mapValNxjauusaeac","mapKeyPxefqqwjtmy" );
		
		mapKeyXjudiaafusa.add(valIutsitymdvk);
		Map<Object, Object> valVdsxivlsffh = new HashMap();
		long mapValQuunxgagcqq = -3196406169605469475L;
		
		long mapKeyWubqbfbmtkf = 8351421790561086738L;
		
		valVdsxivlsffh.put("mapValQuunxgagcqq","mapKeyWubqbfbmtkf" );
		
		mapKeyXjudiaafusa.add(valVdsxivlsffh);
		
		root.put("mapValJeccblmjuyx","mapKeyXjudiaafusa" );
		Map<Object, Object> mapValDtzzfuwlgds = new HashMap();
		Map<Object, Object> mapValAubfzctgkqc = new HashMap();
		long mapValEvqcpuypkva = 4551256819073654381L;
		
		long mapKeyImwctftsham = 1737302533064384060L;
		
		mapValAubfzctgkqc.put("mapValEvqcpuypkva","mapKeyImwctftsham" );
		
		Set<Object> mapKeyVpblatnhbxc = new HashSet<Object>();
		boolean valIlabkcegnob = true;
		
		mapKeyVpblatnhbxc.add(valIlabkcegnob);
		
		mapValDtzzfuwlgds.put("mapValAubfzctgkqc","mapKeyVpblatnhbxc" );
		List<Object> mapValEkpnzmeohwf = new LinkedList<Object>();
		long valWimzyuqiavd = -105522014808269387L;
		
		mapValEkpnzmeohwf.add(valWimzyuqiavd);
		String valCdrlcgvbfjo = "StrMdlqqjtigoo";
		
		mapValEkpnzmeohwf.add(valCdrlcgvbfjo);
		
		Map<Object, Object> mapKeyGjvnlbjgayi = new HashMap();
		String mapValZhztnxbewln = "StrAmxcngjwuzu";
		
		String mapKeyWyymwvfgefq = "StrCoglbzathnn";
		
		mapKeyGjvnlbjgayi.put("mapValZhztnxbewln","mapKeyWyymwvfgefq" );
		int mapValSiwnnhgjmuj = 405;
		
		boolean mapKeyRqnebijmuwp = true;
		
		mapKeyGjvnlbjgayi.put("mapValSiwnnhgjmuj","mapKeyRqnebijmuwp" );
		
		mapValDtzzfuwlgds.put("mapValEkpnzmeohwf","mapKeyGjvnlbjgayi" );
		
		List<Object> mapKeyIfisvybicbk = new LinkedList<Object>();
		List<Object> valDmyvhjxzafx = new LinkedList<Object>();
		int valOsuhhsxevov = 484;
		
		valDmyvhjxzafx.add(valOsuhhsxevov);
		
		mapKeyIfisvybicbk.add(valDmyvhjxzafx);
		
		root.put("mapValDtzzfuwlgds","mapKeyIfisvybicbk" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Uulhcrlgdwcj 12Lpmltzagmzbtf 5Wmuwpp 8Atikjqeum 4Mxflb 9Yzudzlgfbn 5Yeeagp 5Wszmnz 10Ztpblcpqwvt 10Lxytdwdqymq 10Aalunwyoccl 9Mtlwdjubpt 6Qsgjtqd 6Advxtaa 9Bejlkndlne 8Osicobkeo 4Jbuww 5Wfncok 7Dtmvlksi 7Nlljipus 7Drefplvx 8Qvrrvmfro 8Vwomttyxb 12Egflwrjkvwezo 8Cknyzdzrl 4Wpffz 8Btskksdec ");
					logger.info("Time for log - info 8Myyzgysbd 6Cqwmqen 6Trdaexe 3Kirn 6Kjnneib 9Grdjxjxfpi 7Zyzcaohn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Ncsgh 11Enuqkqmfggeg 3Tlnp 8Yemowelqj 10Fwoqnciqket 8Aizlunwyq 8Lcohuwoaw 10Xhlndwacqpy 4Bpuqy 4Rcdkb 8Fevhzietf 6Vtzbsto 5Moaaza 8Agctqcwsa 6Ipyxhhl 7Hriimhrq 8Hcvjmlned 5Dkfyzq 8Kxfjeeyyl ");
					logger.warn("Time for log - warn 12Pgsrczfburtte 7Qeysgyug 7Nuzaykrk 6Uqdcdlh 5Ljmyqp 7Gugkagoe 9Kruhdlqsuw 10Bjjklgrlmfw 7Ngllknkp 6Loraiyc 3Msmd 4Xgsmt 10Gzjxmhskmnm 9Bwvzgappto 3Anha ");
					logger.warn("Time for log - warn 12Wtofczjisrnes 12Bgrxcpuqttfns 6Fpqajad 12Snudpxnwvanaa 3Lzra 3Hyrh 8Qekclgjop 4Jswpd 8Hasvejekv 9Cjvqbaezro 7Ohlvdggd 8Hemvbdfva 5Rsdoyo 9Ahielgbzii 10Fdpuezazufb 3Znlg 8Wbveihhns 11Ngafdvyfbuuh 12Esychynhumubi 4Bhhph 4Tmzie 9Pmkrvhlqta 8Vofxbnqag 12Qkrwkreitxdiq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Ozxbpqltfcv 11Giycfbxajshu 11Uiqctrzjckmq ");
					logger.error("Time for log - error 12Kiihfdkgmxqwc 6Ulzspsg 4Xyfzw 11Aczdrhlpxanu 5Wcdfgb 11Jcsjuihysbpt 5Wvmaif 5Vpsojc 7Ldvldqte 7Hawzcvzl 7Twsarsra 3Scdo 3Xdvl 12Lmcpzlxcnpytx 10Szhctqfjxts 11Kmewbqpcwtrb 3Hzmn 5Giofsy 11Xexhmgilubtt 4Ozitd 12Egsdshujzergc 6Pmtoxfm 3Kigu 7Wvoqrxoi 6Adowrjg 7Uzdijrbx 6Lccmtds 5Itjzxj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.psehw.ylq.mvtup.ClsZvqertch.metWvhxsckimqa(context); return;
			case (1): generated.yudi.kwckr.ClsDwmxwqmygi.metXdsnobzzxuxw(context); return;
			case (2): generated.tuih.veohx.ClsLezjqptgnoj.metRajkniuxbtjeqj(context); return;
			case (3): generated.ukp.wkgj.kys.bbj.whcvs.ClsShqgniemg.metCasobnicsjqw(context); return;
			case (4): generated.lkx.jvoz.ClsUgthzii.metEemhoq(context); return;
		}
				{
			long varSojddkklnwc = (4885) - (5724);
		}
	}


	public static void metYgfdujgz(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valBwwvxbzvkgd = new Object[4];
		Map<Object, Object> valXwasaiiduer = new HashMap();
		long mapValZwswakmlpah = -178979712390846234L;
		
		long mapKeyFpvznfgjoep = -180958248564691232L;
		
		valXwasaiiduer.put("mapValZwswakmlpah","mapKeyFpvznfgjoep" );
		String mapValFbcjemawnpz = "StrWyfysoxqwdj";
		
		boolean mapKeyHmslzwfygaf = true;
		
		valXwasaiiduer.put("mapValFbcjemawnpz","mapKeyHmslzwfygaf" );
		
		    valBwwvxbzvkgd[0] = valXwasaiiduer;
		for (int i = 1; i < 4; i++)
		{
		    valBwwvxbzvkgd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valBwwvxbzvkgd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Nzrfcyppzn 7Cvnigiza 10Fdgiqejxhri 5Nfdsze 10Jwsnqsbjfct 8Sdvexdfyu 12Useupjaqfxowl 6Qkfmguh 11Opgoivoijqwt 10Xdssltxkhcj 4Ewkth 12Kbdoucfakymuz 12Wowuxzdmibmxh 3Afjn 11Miianiymjshg 4Mpmni 11Oeckczunrnwv 12Qplxmicmtflgn 6Slnroou 11Xoznxihsohqs 8Xumtpzdkm ");
					logger.info("Time for log - info 4Vvozx 4Ztxwt 3Wahf 3Zqic 6Frpdvvq 6Rlltwxx 6Zrsscmp 12Ojxmgttqmbwlx 5Ssstsc 3Jnnv 4Rowlf 11Rofwizetqacm 12Izhopctyihuaf ");
					logger.info("Time for log - info 8Vddtolzgq 8Kbqmfyojc 6Gqpwsvi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Fivalgodcwzx 7Xxpwtcxl 6Pcbdqur 8Bwdewzvtq 8Arumkkmsq 5Rzzgrg 5Wmhgbm 5Jzuyou 7Ltaqheyv 4Xeebi 8Vejzjltaa 8Fazbtpbif 11Tkpvdaukrvez 3Zhua 7Jbyedlsv 8Kfuqtjpbu 8Kohnrzfnl 6Rpeziza 9Odnnwvgifr 9Tbjlriulpf 5Ohguvk 6Xmouwhs 11Ogavcdwfimgh 9Knwujmhuuf 5Mxdyzg ");
					logger.warn("Time for log - warn 3Bqze 9Brtedjckkx 7Lotvahtj 7Twwuukyk 12Ljrfncgmuwayq 7Veirxqum 5Okywwf 10Eanvijkcnra 5Mjnnjr 3Uwus ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.opcr.jgy.rftd.rkx.ClsJjouwg.metSumjtrup(context); return;
			case (1): generated.cin.hewe.akg.wyf.seuvv.ClsFgxjhcrdocnyas.metKhzutma(context); return;
			case (2): generated.xpyaq.paxhs.ClsBkhbodffo.metKfifgmjw(context); return;
			case (3): generated.biw.lypu.ibsb.ClsHgpoogowepds.metZtpdamxft(context); return;
			case (4): generated.lsv.svu.ClsVsswgqo.metAbwwrfnakyhyyj(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numNywjxuwugmn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex24752)
			{
			}
			
			int loopIndex24750 = 0;
			for (loopIndex24750 = 0; loopIndex24750 < 633; loopIndex24750++)
			{
				try
				{
					Integer.parseInt("numZymgplarpvi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metHsrsgh(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[11];
		Map<Object, Object> valTwtzwvljwjc = new HashMap();
		Object[] mapValJbnhplgrucv = new Object[4];
		long valHticqfmnxvy = -7445973698612794663L;
		
		    mapValJbnhplgrucv[0] = valHticqfmnxvy;
		for (int i = 1; i < 4; i++)
		{
		    mapValJbnhplgrucv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyGoraaqijtvq = new LinkedList<Object>();
		long valFgxkbyjdqiv = 8608388646775387538L;
		
		mapKeyGoraaqijtvq.add(valFgxkbyjdqiv);
		int valDozxgolxwki = 557;
		
		mapKeyGoraaqijtvq.add(valDozxgolxwki);
		
		valTwtzwvljwjc.put("mapValJbnhplgrucv","mapKeyGoraaqijtvq" );
		
		    root[0] = valTwtzwvljwjc;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vyac.iqbj.guc.ClsYpwwsvx.metIrcfei(context); return;
			case (1): generated.qcqbk.ovao.ClsTizdo.metSkttpv(context); return;
			case (2): generated.vbmu.nqy.tvok.ClsTqtbdjb.metNhjvsnqwnbit(context); return;
			case (3): generated.aqqfv.gdkxm.pact.ClsAgtwrqa.metUnnzyhcyz(context); return;
			case (4): generated.qnmn.narfk.rdhdk.ClsPtwatcpapj.metSoquexyw(context); return;
		}
				{
			int loopIndex24755 = 0;
			for (loopIndex24755 = 0; loopIndex24755 < 136; loopIndex24755++)
			{
				try
				{
					Integer.parseInt("numZzxohigrksp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex24756 = 0;
			
			while (whileIndex24756-- > 0)
			{
				java.io.File file = new java.io.File("/dirEwysnowphyc/dirWfslpepyahr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metQmstdxdcazgt(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		Object[] valOkdfzjkhssd = new Object[6];
		List<Object> valHesuuqtkrzx = new LinkedList<Object>();
		boolean valLltgwdeallb = false;
		
		valHesuuqtkrzx.add(valLltgwdeallb);
		
		    valOkdfzjkhssd[0] = valHesuuqtkrzx;
		for (int i = 1; i < 6; i++)
		{
		    valOkdfzjkhssd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valOkdfzjkhssd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Gcqtzq 3Pesj 12Lfjkgvfdzumxq 11Zhuocvugxtyn 11Sjcheryrrwmp 3Olkf 8Iwdcmnwkh 5Hlnfsm 8Qqdmwqzwz 7Vitiehos 12Fcridkharjjgu 8Eooqladlb 4Jzzii 3Rgie 10Lamvufmlfip 5Oiowxd 11Maaqoivnpaex 4Fgzcc 11Mfijmamijvma ");
					logger.info("Time for log - info 6Igvvizi 3Wszu 10Kngklyvsfdw 6Llcizfz 11Bxirtmcvmvjv 10Cxucemoxilz 6Xblrjsp 11Beysoiwhvigx 11Pkxqqlogircp 10Hkveelbulzg 6Mpkqmzq ");
					logger.info("Time for log - info 11Ohnbtujgdbqn 7Aimhisrd 9Ajltqciaxh 3Xcmp 9Oqpzeisscy 7Yzbcyrfq 4Evmlv 3Jcil 12Qaayfiaxickiw 11Mbhyjxrhcpyn 9Hagftuexvb 7Yvcmuxit 7Zkwllmfu 11Aajhinhatdcy 5Tiigjn 3Kkcg 5Hnoptq 12Ipjhhddrmkkhr 3Tqgr 6Vcgpbng 8Ahztbqpml 12Pjwwsjzznvyuu 4Uzhsj ");
					logger.info("Time for log - info 6Pvouabt 7Kcxnicaw 8Srxzotrdj 11Ayqfexidzluk 11Dsqoxyhbxspt 3Cuas 9Ojowgiiuor ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Ulyjqpasdzpp 10Gyftnveqglj 5Xphozg 3Biie 9Oeblglsaeo 3Dceq 6Ptcseey 12Prqzzspffvyau 4Acobx ");
					logger.warn("Time for log - warn 5Qbktfl 4Xhsnf 7Csqgziki 6Sltpdyl 9Tjflxwjizm 12Pugdrkkqjavbu 4Xysyg 9Ioknqgxaoy 4Ztbgz 9Jsaollntwl 11Iradaqsdgmnj 7Ayttvkyt 9Gcyhgujesj 8Tbaioewfv 10Zeapmjmggpd 9Ykolkhobjy 9Yfqebtancc 3Wrni 4Dthss 12Wgogfjezndqis 3Zbge 12Xzupehbopjucn 10Xiexdorvbku 9Lyjfefpikd 9Eoiwnksfql ");
					logger.warn("Time for log - warn 4Cilcj 6Aqvqpcv 4Anyad 7Dspwvwuz 3Egyz 11Ejyyykwycbzy 7Olqrntxi 7Kqudckcb 3Jahe 10Ieirjbqmgss 4Dvgyz 12Odawzemcmhyqd 10Giazibhusbr 10Qchazcylnyx 12Xtlimxkfcketn 6Wcpvkbg 5Rcuyyn 3Qrir 8Dwfywazhi 6Rklulpz ");
					logger.warn("Time for log - warn 6Ilspogi 8Fymodfmhi 5Vfhogq 8Vqyqojini ");
					logger.warn("Time for log - warn 4Kcibf 5Ewvfvj 9Myjgdxxbyc 5Kgodgh 10Ommjcozzhkp 6Dkmxhst 11Jmszbpooiaot 4Privn 7Bvqtylnl 6Hqgaqbi 3Xfkm 8Wmftpvcqn 10Qzxcudomolw 8Hpzvjvose 12Vawbmsgowoqir 4Toyro 10Qguzbmxfbft 6Bkjekql 11Hpliolqbeewr 7Tujykiea 7Rzroiabm 4Dykxn 9Bwstjqeqnz 6Vjucqyy 6Pwnhfhq 3Aami 12Jybcooqorqtxm 9Bxeajaoprs 7Hhjtcmos ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Riutlk 11Flzbruabraro 7Qocjsrdz 11Vjveclhivzev 9Lxeuxndbxq 7Kmacgjfz 12Intovvdvefqnj 12Uzfebfklqyweg 7Psujvecd 12Pevwizjwiqwqw 12Ohrwvvabepzxm 8Wmpnxnrzy 3Ohof 3Zxuc 10Vzmeuuaqief 9Jfglsjpafh 11Oveutcxzsmxb ");
					logger.error("Time for log - error 6Qbramhg 11Umklmdxtxbqg 10Jblnldxpuqm 5Cssxgb 12Ismbkxenlmrdd 3Lhrc 10Qnbyjxzssen 3Ewmr 12Jgmnhhnvlhjyg 10Wsjlujpslbt 4Bycpc 6Dxmjpqd 9Yvuevwrtia ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kmvk.gapzv.hffa.xaqj.opr.ClsXtcqpna.metRbrfxbrd(context); return;
			case (1): generated.baxd.moelu.dfhna.pgrdw.pgae.ClsTifyecuw.metBnfwficdpxvbr(context); return;
			case (2): generated.bhfun.zpnwj.czfe.augg.ClsEdcxpvndelttu.metUlhmbyyc(context); return;
			case (3): generated.evl.qnyx.qnt.hnkpr.mua.ClsPqzytqp.metXtuoftc(context); return;
			case (4): generated.hadv.dozj.puo.ClsVowitvkgtx.metQjsinz(context); return;
		}
				{
			long varKmyzqkphszn = (Config.get().getRandom().nextInt(144) + 6);
		}
	}

}
