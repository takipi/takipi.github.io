package generated.ocklj.sbz;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsVzertfboftzd
{
	 public static final int classId = 450;
	 static final Logger logger = LoggerFactory.getLogger(ClsVzertfboftzd.class);

	public static void metOvqborsb(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValJnlesbbetum = new HashSet<Object>();
		List<Object> valUacpdcffiyj = new LinkedList<Object>();
		long valLrfroprbigs = 2181194889231574003L;
		
		valUacpdcffiyj.add(valLrfroprbigs);
		boolean valWsivnhglfpk = true;
		
		valUacpdcffiyj.add(valWsivnhglfpk);
		
		mapValJnlesbbetum.add(valUacpdcffiyj);
		
		Map<Object, Object> mapKeyAruatxhmxus = new HashMap();
		Set<Object> mapValLegzudgkkyo = new HashSet<Object>();
		int valMvnuaxogtqk = 551;
		
		mapValLegzudgkkyo.add(valMvnuaxogtqk);
		long valIuwkffyabru = 3790273862109014841L;
		
		mapValLegzudgkkyo.add(valIuwkffyabru);
		
		Set<Object> mapKeyPvyryhtjqcf = new HashSet<Object>();
		boolean valYwxpezvoyzw = true;
		
		mapKeyPvyryhtjqcf.add(valYwxpezvoyzw);
		
		mapKeyAruatxhmxus.put("mapValLegzudgkkyo","mapKeyPvyryhtjqcf" );
		
		root.put("mapValJnlesbbetum","mapKeyAruatxhmxus" );
		List<Object> mapValRvyqueuqjns = new LinkedList<Object>();
		Object[] valZmhxfnxjgda = new Object[2];
		boolean valWanidjowlye = true;
		
		    valZmhxfnxjgda[0] = valWanidjowlye;
		for (int i = 1; i < 2; i++)
		{
		    valZmhxfnxjgda[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValRvyqueuqjns.add(valZmhxfnxjgda);
		Set<Object> valLlhhvzsxnto = new HashSet<Object>();
		String valLxaagikqdow = "StrUwxtjtotcem";
		
		valLlhhvzsxnto.add(valLxaagikqdow);
		String valRrooxexitxc = "StrXtuhlvpgcgg";
		
		valLlhhvzsxnto.add(valRrooxexitxc);
		
		mapValRvyqueuqjns.add(valLlhhvzsxnto);
		
		Object[] mapKeyVboaauknavh = new Object[3];
		Object[] valHqdvnrcvquo = new Object[9];
		long valOvrbpwioseg = 5734934907594511228L;
		
		    valHqdvnrcvquo[0] = valOvrbpwioseg;
		for (int i = 1; i < 9; i++)
		{
		    valHqdvnrcvquo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyVboaauknavh[0] = valHqdvnrcvquo;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyVboaauknavh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValRvyqueuqjns","mapKeyVboaauknavh" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Kjjrnlagsydc 6Cvgcevq 3Nfgh 5Lnhhvn 6Hnwglds 5Fffygz 7Hzorydwm 11Qqpltgtqrnzg 12Yyznshczwovbu 12Fiypfololzuss 4Nbvsn ");
					logger.info("Time for log - info 3Vggi 11Tnaaxzqaixpq 7Xpsgatic 6Fgsvwqe 10Lulaboxmyku 6Szvnltb 12Eemmfqitpxfhr 8Syoudsyoy 3Tuhz 12Fwyshuwrajwcj 5Qvvsmk 10Wjbvxwplhrc 11Rjqxgftynhtq 7Qyueqveo 12Aejbjagbuvsqz 11Ifcfawtsihxn 11Rbvxfvxvzdzm 6Qmupkcc ");
					logger.info("Time for log - info 11Bivwkvhjqdcs 5Hbgysr 3Rdds 7Usuhadtj 12Ezroogzdlwtys 9Uzdqnjgajk 12Gxulskcdxuobl 9Rzpsgyeqln 6Izokqum 5Iqhqbd 9Qdbpzqnidl ");
					logger.info("Time for log - info 8Jvkhxrldx 12Vfnhwshbaosws 11Eiabnwnrreoh 3Zapk 10Spkkvmpdvav 3Fpyc 8Kpvtethvs 8Lglqpawxz 6Bsmdpkl 11Gvldoavhxgeh 11Nocqwdnhjhxg 9Ftjkqylvfp 8Cnkxokvfo 7Lelcgfeb 12Jdxpoqxlibuvg 9Bbwgubhlyl 12Eioamvwaczazk 12Jrkpbpnzxubdv 10Orpuduokwbk ");
					logger.info("Time for log - info 8Vflgbgqkj 4Vxjbv 12Balrmwduncozh 7Wavwwhps 3Lpzs ");
					logger.info("Time for log - info 4Xohqi 10Rdjkdvkxxmd 3Niao ");
					logger.info("Time for log - info 8Teanlmwyh 7Djyrgppn 10Afqphqtrthk 9Mluajnldse ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Ieomfqljpd 12Lskrmcwpurpnr 10Xkbebrxvvdw 6Bllkqcm 7Eopfypcf 10Enltfgcmvbt 12Mmlqepwusfnvj 9Vubigunsxr 11Dptdclncocbf 11Uzslpdjxxgnn 10Hbhmxnnsync 9Cmcwbkxerf 10Knfgsvyciki 5Pdtajj 8Pmomtynne 12Rzyvnflbhztre 5Gbcpmt 4Iuqyp 5Lxneps 4Zmfms 6Nmkczsf 8Jvmfeaudu 3Seho 6Azmfnhl 7Qogulral 6Fekniwd 9Fjpolstxqy 4Opmzh 5Uoyjxp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jlzkx.vlyxg.uui.ClsYmzeuds.metMjkebsmedso(context); return;
			case (1): generated.lgwo.spy.sqb.ClsVtibt.metZawpt(context); return;
			case (2): generated.rjuw.mmbua.ClsRawvqxmhewbl.metBvnihykij(context); return;
			case (3): generated.lmq.wwll.mcjoz.ClsBqjxdpu.metLzmwjdeakzh(context); return;
			case (4): generated.cxoq.hzjj.hhxu.ClsXfvidhbawjojdu.metOcgmhat(context); return;
		}
				{
			if (((668) + (Config.get().getRandom().nextInt(279) + 2) % 415545) == 0)
			{
				try
				{
					Integer.parseInt("numUtqjqwljtgi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((5113) % 448155) == 0)
			{
				try
				{
					Integer.parseInt("numQzwuwbablri");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varJndtjyhdtfk = (Config.get().getRandom().nextInt(407) + 1) + (Config.get().getRandom().nextInt(496) + 2);
			try
			{
				java.io.File file = new java.io.File("/dirJdzoeawzbty");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metMglljtzxhvd(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValFhlykvhidtj = new LinkedList<Object>();
		List<Object> valRsrbgjkwqpu = new LinkedList<Object>();
		boolean valWyqkrasbxgj = false;
		
		valRsrbgjkwqpu.add(valWyqkrasbxgj);
		
		mapValFhlykvhidtj.add(valRsrbgjkwqpu);
		List<Object> valHdpdqutpyht = new LinkedList<Object>();
		boolean valSurxplndtoh = false;
		
		valHdpdqutpyht.add(valSurxplndtoh);
		
		mapValFhlykvhidtj.add(valHdpdqutpyht);
		
		Map<Object, Object> mapKeyMmpwskymfah = new HashMap();
		Set<Object> mapValZdvelsekphr = new HashSet<Object>();
		boolean valPiendyxwxyx = false;
		
		mapValZdvelsekphr.add(valPiendyxwxyx);
		int valRceaiwilqex = 119;
		
		mapValZdvelsekphr.add(valRceaiwilqex);
		
		Set<Object> mapKeyRlmfykieyye = new HashSet<Object>();
		String valGkheawqovas = "StrEcmcvizszcf";
		
		mapKeyRlmfykieyye.add(valGkheawqovas);
		boolean valGfbwqtrggti = false;
		
		mapKeyRlmfykieyye.add(valGfbwqtrggti);
		
		mapKeyMmpwskymfah.put("mapValZdvelsekphr","mapKeyRlmfykieyye" );
		Set<Object> mapValFgfbjdnlsuo = new HashSet<Object>();
		int valMsuoxveykok = 319;
		
		mapValFgfbjdnlsuo.add(valMsuoxveykok);
		
		Object[] mapKeyXdalzdyqmxy = new Object[6];
		int valStqrazukbrb = 672;
		
		    mapKeyXdalzdyqmxy[0] = valStqrazukbrb;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyXdalzdyqmxy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyMmpwskymfah.put("mapValFgfbjdnlsuo","mapKeyXdalzdyqmxy" );
		
		root.put("mapValFhlykvhidtj","mapKeyMmpwskymfah" );
		Set<Object> mapValQmvbnwraxoj = new HashSet<Object>();
		Set<Object> valAqowptjhdad = new HashSet<Object>();
		String valXxekggoawuc = "StrDscrjpxroaj";
		
		valAqowptjhdad.add(valXxekggoawuc);
		String valIsdhjkisyun = "StrRpmkxsjrwep";
		
		valAqowptjhdad.add(valIsdhjkisyun);
		
		mapValQmvbnwraxoj.add(valAqowptjhdad);
		
		List<Object> mapKeyOypdjlodnaa = new LinkedList<Object>();
		Object[] valLzzudaaussn = new Object[8];
		int valQsvpojqjywx = 11;
		
		    valLzzudaaussn[0] = valQsvpojqjywx;
		for (int i = 1; i < 8; i++)
		{
		    valLzzudaaussn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyOypdjlodnaa.add(valLzzudaaussn);
		
		root.put("mapValQmvbnwraxoj","mapKeyOypdjlodnaa" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Qwfikfkcvq 9Zateolkbxj 10Ayngvnvdxrq 11Pvhigufsbvvv 9Ttmujaibcd 11Zbrfochgfdjq 6Hlsikhx 10Cmngwqhrjkp ");
					logger.info("Time for log - info 9Lgjrogfcmm 8Rozkmclly 7Rzihptej 8Onwvecdad 4Smjey 7Dqixjgjw 6Kohvkqr 12Esbyddrtnrwbn 12Aqrkxwuoljauu 3Bbht 4Mpdfe 12Juifjwtihunuw 9Piqyfsxlnp 4Jfsfu 9Kyabgrfkcj 4Tobvp 10Fupuvioibja 9Wkemvofkyo 8Zlhkqnjtm 7Eqyojgrq 8Xxyrtfqnh 8Yssqhthoq 12Mqktmvvcrypww ");
					logger.info("Time for log - info 7Ffffbtnr 12Dapsdwwaxynxn 5Fbmrvn 9Oiemjtcnrz 4Hslps 5Wzewxt 12Zrjdxejmmtyxw 10Rvamegsiygy 8Fhgqkamdh 5Ctmsub 4Xnqkt 11Kifczbggzcgp 5Yvkncx 5Typuhk 7Rtacvlwo 9Bqvdbxalel 6Jzepixc 6Fftroqg 3Skea 12Wnivilvrfodqe 4Otdxt 5Fwexob 9Dneldmqwwm 7Yitrqubn 7Tcmxvauf 10Nhlgunhgqsm 11Vovmgeigmujy 5Gunfzv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Auxsnd 6Nflzzqx 5Kltrhf 9Pdxydgyzmv 6Kwexjbs 6Lhwahew ");
					logger.warn("Time for log - warn 10Amtabflhplm 11Auennwgjroyj 7Iqovxyye 3Dmve 10Ngdmcewgehi 11Ixdijrdwrlvb 5Vwanox 8Rtsyymhur 5Dfoiao 6Voswzbm 10Voxqtkfaabp 8Wrvilcbqf 6Agubren 7Ihfnhddl 4Svxbi 5Lcgmct ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qzl.yonxw.xanna.lsvx.pese.ClsHtvngej.metOsvavkmcyqli(context); return;
			case (1): generated.tcpo.xhov.ClsRfokukcdi.metFrfxj(context); return;
			case (2): generated.afllp.gwt.xvrk.rxvp.rryr.ClsQsqze.metUgmauegqryzcz(context); return;
			case (3): generated.hiv.mgg.zog.vzpz.ClsYqryx.metXcirnzx(context); return;
			case (4): generated.blsj.gki.ClsOuhbksvj.metOmfsztvrsb(context); return;
		}
				{
			long whileIndex27575 = 0;
			
			while (whileIndex27575-- > 0)
			{
				try
				{
					Integer.parseInt("numMoolbnujxsg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex27576 = 0;
			for (loopIndex27576 = 0; loopIndex27576 < 3213; loopIndex27576++)
			{
				try
				{
					Integer.parseInt("numMlldruhmcmb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metSzwoijjcwsu(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValDayilgomhva = new HashMap();
		Set<Object> mapValStmxrynoeko = new HashSet<Object>();
		int valHyajcrqrzfz = 681;
		
		mapValStmxrynoeko.add(valHyajcrqrzfz);
		String valDpcpjzpawzm = "StrKyayglivljr";
		
		mapValStmxrynoeko.add(valDpcpjzpawzm);
		
		Object[] mapKeyXaiotoxdnjz = new Object[11];
		String valDtuqfsqluyc = "StrXicqpeudlzt";
		
		    mapKeyXaiotoxdnjz[0] = valDtuqfsqluyc;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyXaiotoxdnjz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValDayilgomhva.put("mapValStmxrynoeko","mapKeyXaiotoxdnjz" );
		
		Object[] mapKeyPoljixyknwz = new Object[5];
		Object[] valQxblxzcrupv = new Object[4];
		String valGosqzikbxeh = "StrUcmvtipreun";
		
		    valQxblxzcrupv[0] = valGosqzikbxeh;
		for (int i = 1; i < 4; i++)
		{
		    valQxblxzcrupv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyPoljixyknwz[0] = valQxblxzcrupv;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyPoljixyknwz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValDayilgomhva","mapKeyPoljixyknwz" );
		Set<Object> mapValRayilazsfcc = new HashSet<Object>();
		Map<Object, Object> valFuaviecvicp = new HashMap();
		int mapValHdkxmyfxsgn = 457;
		
		int mapKeyBjpzpagdrbm = 834;
		
		valFuaviecvicp.put("mapValHdkxmyfxsgn","mapKeyBjpzpagdrbm" );
		int mapValItenczhjizw = 149;
		
		String mapKeyWuhooidtwbk = "StrJxexorwsadt";
		
		valFuaviecvicp.put("mapValItenczhjizw","mapKeyWuhooidtwbk" );
		
		mapValRayilazsfcc.add(valFuaviecvicp);
		List<Object> valLumicjqxrrg = new LinkedList<Object>();
		long valHlopasxwiut = -2366034668002227216L;
		
		valLumicjqxrrg.add(valHlopasxwiut);
		long valIfdlxcltuyf = 6001267064431909455L;
		
		valLumicjqxrrg.add(valIfdlxcltuyf);
		
		mapValRayilazsfcc.add(valLumicjqxrrg);
		
		Set<Object> mapKeyYgupwtmtakl = new HashSet<Object>();
		Object[] valWohhriwxcsq = new Object[6];
		String valRkgnsexgkgp = "StrQrgrgcgwnsk";
		
		    valWohhriwxcsq[0] = valRkgnsexgkgp;
		for (int i = 1; i < 6; i++)
		{
		    valWohhriwxcsq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyYgupwtmtakl.add(valWohhriwxcsq);
		Map<Object, Object> valXxtfdzevxpv = new HashMap();
		long mapValMjlpsnztsyk = 7462412124225268539L;
		
		boolean mapKeyLlfuymajozf = false;
		
		valXxtfdzevxpv.put("mapValMjlpsnztsyk","mapKeyLlfuymajozf" );
		int mapValTtefdqihxtc = 252;
		
		String mapKeyUhzigcawmnd = "StrKpmxktkvzri";
		
		valXxtfdzevxpv.put("mapValTtefdqihxtc","mapKeyUhzigcawmnd" );
		
		mapKeyYgupwtmtakl.add(valXxtfdzevxpv);
		
		root.put("mapValRayilazsfcc","mapKeyYgupwtmtakl" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Znwg 4Phvfq 8Kevhhwrio 7Ltndzmvk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Ocgwybff 7Mvlgujuk 12Ipvqandanxtqv 8Difkdkkxc 6Awdvcsl 4Ykuus ");
					logger.error("Time for log - error 12Ydmwukzznmkox 7Tksgquvb 9Kbhqbhugtn 4Vqlbr 10Jnsngentfiw 5Afsudc 3Btny 6Xipqssb ");
					logger.error("Time for log - error 5Xhddgn 8Imofeomls 8Vutldbvbg 10Hbwygdcsrvl 6Fuigudv 11Xtmwehufndyt 11Maxgjidbvdqx 7Andhaoyj 11Opbulpphhlri 6Jzoztgf 5Nvhqxr ");
					logger.error("Time for log - error 7Bbqshyha 5Bleief ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.liyl.sfhr.ClsNilzqakfd.metDymwfdjjlcu(context); return;
			case (1): generated.obfi.prawn.asr.ClsHvlzhrjejvoom.metTssprbwiuo(context); return;
			case (2): generated.sik.dyw.jmm.xdu.omh.ClsVarjcvcyur.metFesaihfuowja(context); return;
			case (3): generated.dvks.jsbpi.ClsXlatniflz.metIhawpoyjsfgfom(context); return;
			case (4): generated.hcdlq.enxjq.kqzt.pmk.vuc.ClsMdkbzdmkjxcf.metWuruvmffywn(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(927) + 5) % 742443) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex27582 = 0;
			
			while (whileIndex27582-- > 0)
			{
				try
				{
					Integer.parseInt("numLihbbtiouvw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
