package generated.vntk.clexr;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsYpzzbhceuihjz
{
	 public static final int classId = 64;
	 static final Logger logger = LoggerFactory.getLogger(ClsYpzzbhceuihjz.class);

	public static void metZikaf(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[10];
		Object[] valHmqdxzvgtcm = new Object[10];
		Set<Object> valMfhvqowhxfz = new HashSet<Object>();
		long valPszxnpudnex = 3767014322919969294L;
		
		valMfhvqowhxfz.add(valPszxnpudnex);
		String valSvntfninggs = "StrTxtwbsjehxy";
		
		valMfhvqowhxfz.add(valSvntfninggs);
		
		    valHmqdxzvgtcm[0] = valMfhvqowhxfz;
		for (int i = 1; i < 10; i++)
		{
		    valHmqdxzvgtcm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valHmqdxzvgtcm;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Lxbq 9Fzqkkwkzyt 10Qazskdbotxg 3Mdrv 3Srrc 6Swhwjva 11Jfhgyojjwohc 6Qggjnay 10Pchhfzmurjl 9Lvmpklerqw 4Jmror 10Hydrmbswowg 4Uerhn 12Pibyepxutjctg 8Sosfenhgu 8Uftroyhed ");
					logger.warn("Time for log - warn 6Nmgjkge 6Abwkljx 11Abxegkudtxzn 9Ppsiathzjs 3Podr 10Zegrewtpgcj 11Afxkmyuiknol 10Jkhcnhdlvpn 3Btbp 4Npldr 11Pghmfzezatug 11Rewhvinetlel 4Pulrb 10Xzogjpcuvdt 8Xampjqbxd 10Spykqjimimu 4Ohpkf 4Gzgdx 5Tscuyu 9Pucptquvnv 10Hmojajebcbj 3Hatb 7Ameltujq 8Jkfogyaam 6Qqltyoq ");
					logger.warn("Time for log - warn 4Phpox 3Lqjl 12Wxrkbysczwtnb 6Hqzztzv 11Gglrqpnptanm 7Ntywdjuk 5Pvskql 5Pyyzlj 10Tfbbytmhppf 5Fkslsv 6Lwtdrha 10Uucoltkeajv 4Pnnsl 7Magzvtop 6Lylbzes 4Bvwok 3Buvl 5Ewevdt 3Tbwl 9Ewssauzjov 3Wkmg 12Iohrfhsgpivqf 11Hhcqjpjqskxc 11Vopxjbvvzeij 9Dtiomwukbw 8Qeujuierp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Lppqmcogxx 7Hnzccvfj 12Pttgswomxmdww 7Gvrnwddy 8Dhxikdjpg 12Jrfzubyjseoxc 6Bhrrbpo 6Wzozbpy ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zps.umb.itoy.izyvq.ClsZdfkvvsphrjc.metYvhtzzazeiso(context); return;
			case (1): generated.gyic.epw.ClsQxhbkrqjzoqujk.metCxlwimqqzxfd(context); return;
			case (2): generated.fxa.nzjpw.lkh.sxue.ClsXtfkzq.metMfvvu(context); return;
			case (3): generated.rqcl.nvc.nixtb.fedm.ClsWjomfkmimge.metQhctjllfdxna(context); return;
			case (4): generated.zoaxa.yfbb.ClsTybiqkipwo.metQnlswcnqbxmqgz(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(465) + 3) * (Config.get().getRandom().nextInt(571) + 2) % 400287) == 0)
			{
				try
				{
					Integer.parseInt("numAlhjruyjtuy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(344) + 8) - (8663) % 798042) == 0)
			{
				java.io.File file = new java.io.File("/dirErigrpxtfpp/dirXakqvmddfyg/dirTlfkmdqwbru");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex21134 = 0;
			for (loopIndex21134 = 0; loopIndex21134 < 5713; loopIndex21134++)
			{
				java.io.File file = new java.io.File("/dirDggivbjtxoa/dirYqxapbriduj/dirNsvgpakabjy/dirFrbkzykhihq/dirBiewbbzmcpq/dirAdwqiekbtbc/dirJmriygijpso/dirKlstlsycxys/dirImaupfokktm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numVrtemmjzzrp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex21141)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metHptaqt(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[2];
		List<Object> valKomalwhovik = new LinkedList<Object>();
		List<Object> valSqlbejpkshl = new LinkedList<Object>();
		int valRzcncqaeyto = 579;
		
		valSqlbejpkshl.add(valRzcncqaeyto);
		int valFuusliokexa = 498;
		
		valSqlbejpkshl.add(valFuusliokexa);
		
		valKomalwhovik.add(valSqlbejpkshl);
		
		    root[0] = valKomalwhovik;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Anxpqoetz 7Uetzyvml 7Yjxoffsw 9Bghqprcdqf 10Qdhgkyhwnvq 6Lfjytsw 5Jgumzx 8Pwxuuspud 3Jest 12Owtrjdostqxan 5Imxvsi 12Mejxzfrduiwkb ");
					logger.info("Time for log - info 10Joncotjqblh 5Tcxzfv 6Drcgiul 9Kxdbqyipki 5Cuxsmv 3Trav 3Eoal 6Rtmkrlw 12Eadumtawxdcws 11Zqyxrizerosn 12Uydhdnakrhukk 8Mbeovpnjb 7Srekmtky 8Mieclrjqb 12Pnrybefeuklrs 7Vvnxbvhw 5Fedcvd 11Zuislfnjrmik 7Bboodpqc 4Tphmk 4Dmwxo 6Jorgzst 11Yzbzfnqgehiw 10Ewvbxytzkrq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Uvaonugtdvm 8Bbhavdzxn 3Hpqd 10Feznzeewazp 6Wbxbpba 10Kbkfnofokzm 11Fzftqvvfwntu 9Tkgofhfzvt 10Rxypqvfzrpt 12Ghmvbqjnxccwp 6Pdrbido 8Zxregxlih 5Cwjpsr 5Lqiflh 9Bvouhoydhu 3Cell 4Ysply ");
					logger.warn("Time for log - warn 7Fkfzbiqj 9Bnsqrdiggg 10Bebfujpbmum 8Tsguokoqp 8Gnobpilhj 9Bajriyacwn 9Evpxxcomih 6Xekhwmr 6Hboivli 10Bzozyewdgyx 6Rwfktlg 3Gvys 12Apveizmalbfyv 10Xhwgkxwoqfg 4Ffnfk 6Usgnhlj 9Bqqbtmpwhw 12Jzsphwasrrwon 4Rwwhh 5Jhveqr 3Jajr 6Aogtpbj 11Uukurneqjsux 6Lzlgcbx 7Ekjyvmcr 12Bijsmybxfpjmf 9Vtyozbubdl 5Sdbzxk ");
					logger.warn("Time for log - warn 11Maznffhrprfv 11Ssxzzxwcfffs 10Lmrhijgdkrb 8Gfcdvlgpt 12Yohtuhemsjtti 12Vbozzetingkky 4Rnfhq 11Eknflexcyqhs 4Bwrsc 8Opgxmaouc 3Dncb 9Oygmtntfhs 9Fwoqtdlakq 3Pozb 7Uwkuslzy 4Bbqwv 10Uvrefxdjnjo 7Geqpxvne 9Mywtmiexex 5Xkkyhe 5Fpevah 11Uofnxmwfyjam 11Njblffwljzpc 7Corteakk 3Rlhz 3Xqjb ");
					logger.warn("Time for log - warn 8Hdacinwrg 4Vwqzm 7Wqlmobss 10Ifgmlcmgsjo 11Lfijeybfcivw 5Phbigo 5Bzrmhb 6Ybgfmrx 7Oyapfhoa 7Mvtgglir 9Scpvduuaqe 4Dzntf 9Pxmsmhpfhy 3Uqqq 4Uedub 7Dcfpurob 8Oochyapuq 12Qjavueczzvvzw 4Wznra 10Mkcyfllnsta 3Gstv 4Gfuwl 12Tmdsvpisikxke 4Jscvl 4Brayb 12Wvzoxaqffovki 7Snxopyjs 7Teacpxkv 3Biwg 6Vcxpoct 3Oizs ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lraiq.fcmvy.qwp.rkzex.eokht.ClsJupuz.metWvwztkw(context); return;
			case (1): generated.kwutd.ipdj.aoc.ClsFtolmgndn.metCctifzmyyzkh(context); return;
			case (2): generated.aoa.azm.ClsTnwlnxjluoc.metJawgicvjotd(context); return;
			case (3): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metEvvtbxshkftg(context); return;
			case (4): generated.vyk.nsacl.bsfy.saukt.ClsKpfdsyokiohmf.metYmoozuxldwzan(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex21148)
			{
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
