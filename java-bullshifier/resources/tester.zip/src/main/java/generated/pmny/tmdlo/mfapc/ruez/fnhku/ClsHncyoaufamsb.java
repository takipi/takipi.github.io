package generated.pmny.tmdlo.mfapc.ruez.fnhku;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsHncyoaufamsb
{
	 public static final int classId = 158;
	 static final Logger logger = LoggerFactory.getLogger(ClsHncyoaufamsb.class);

	public static void metZiouerfahj(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valDmdghwivwps = new HashSet<Object>();
		Map<Object, Object> valQghsvgnxqnm = new HashMap();
		long mapValNjfliqbhtuz = 8246711291658220049L;
		
		String mapKeyZkvvsckveks = "StrMmzgbgppslq";
		
		valQghsvgnxqnm.put("mapValNjfliqbhtuz","mapKeyZkvvsckveks" );
		int mapValXrfrxroiayv = 957;
		
		String mapKeyRfmkiufuwil = "StrZiyljmuchmy";
		
		valQghsvgnxqnm.put("mapValXrfrxroiayv","mapKeyRfmkiufuwil" );
		
		valDmdghwivwps.add(valQghsvgnxqnm);
		Map<Object, Object> valOudeejpmlkm = new HashMap();
		boolean mapValZsmgdvanzoq = false;
		
		String mapKeyYpopttaqtih = "StrYlswglxxvfa";
		
		valOudeejpmlkm.put("mapValZsmgdvanzoq","mapKeyYpopttaqtih" );
		
		valDmdghwivwps.add(valOudeejpmlkm);
		
		root.add(valDmdghwivwps);
		List<Object> valFknjssjscnr = new LinkedList<Object>();
		Set<Object> valOcmqqllpnyh = new HashSet<Object>();
		long valXbelpeibnov = -4861888878645645934L;
		
		valOcmqqllpnyh.add(valXbelpeibnov);
		boolean valSlahdlienzo = false;
		
		valOcmqqllpnyh.add(valSlahdlienzo);
		
		valFknjssjscnr.add(valOcmqqllpnyh);
		Object[] valPkjickwksye = new Object[2];
		long valJpufbpshnrh = 4812013850498312114L;
		
		    valPkjickwksye[0] = valJpufbpshnrh;
		for (int i = 1; i < 2; i++)
		{
		    valPkjickwksye[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valFknjssjscnr.add(valPkjickwksye);
		
		root.add(valFknjssjscnr);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Qttnlkxmbj 4Bhvtm 6Pftzjxl 8Bjsshxoqg 5Yskesl 12Ijtpumvajkvwz 7Faozqprx 3Nonz 11Knoxrtyndnqt 8Gbgpogbpz 6Qithwbe 7Jltealjd 9Czshkwocbh ");
					logger.info("Time for log - info 4Hgqvn 12Yecfbhrxmpgpu 3Lvye 4Itaqj 7Xxrlxvqi 8Furwraulp 9Sullxujlsk 11Wwjauuletqrj 4Ohfvd 8Jwpdbduhp 3Tkme 7Faehtphv 9Jaoinntztx 10Npepvcoxcda 9Trygslqshf 11Uljhcdhhhshy 11Dfbjkjholnel ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Yagpfsivjgww 8Ovhmxqthd 6Sjypvgj 10Zxyoelquttf 10Kmxcbyiwgkf 11Rrxbtbwalmgc 10Mntbpjlqfsn 4Llpzy 6Jblmsue 11Ocjrclwjlghd 4Jckwn 10Tjkutymfsku 10Hhxelwpyeuv 11Njojvrletdic 5Vzuojm 6Jhfzxid 10Bvzrkhbviyd 9Uoigungpqr 8Vgpzwwfce 11Iggzzlmfblfm 3Epyb 10Ettjgnnfvzr 6Phaaovm 8Ojvwuqyni 4Xvyvi 6Pkhwsnn 11Madsdptdsboa 5Nacukx 5Pspaxf 8Pegogaxrg ");
					logger.warn("Time for log - warn 12Iedgkhujrtija 10Fimzupyfvia 7Qbzraanr 6Jouekxw 8Ugrlzykft 9Eciobigtzc 5Mnyiop 3Trxa 8Efwvhrvva 10Vflwnmcyddk 10Qmmlpjjjzuo 3Yhvt 9Jnnszsrbdo 7Lrwffjiq 4Iuyow 10Ujzzvurdyvk 7Mxqvloce 9Jouhnubtdr 4Nfjgq 6Jgzlngu 3Hbnh 4Fnkbk 5Ietblx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Extzjpuj 5Ycykim 9Engsvbsrof 3Ftuh 12Acycgkzwazael 9Ggkjesmwwr 5Oqhmsc 7Zwpkrofc 12Rgwnryqzqgpch 3Phtr 8Psgahdcpl 4Kcshc 11Kquqwjxeescq 9Bdyckdsxkd 5Sftvmt 3Cypz 8Gtuhunayd 10Zvyfjswplue 5Alffdz 7Xxlnfsyi 5Qegocw 12Hcuhpttdqific ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kmtdc.slqlz.nmqcy.naaq.ClsKsliquh.metYprzkjhmint(context); return;
			case (1): generated.lkx.jvoz.ClsUgthzii.metEemhoq(context); return;
			case (2): generated.cmup.ytrbd.ddu.ClsZmyzij.metUdfamugvcjl(context); return;
			case (3): generated.spdv.axe.ClsZyjdutdtmcu.metPttnuruqdrm(context); return;
			case (4): generated.joeal.ovr.nvb.kqkl.kegr.ClsNehitk.metFbsmcfuayzyy(context); return;
		}
				{
			long whileIndex22869 = 0;
			
			while (whileIndex22869-- > 0)
			{
				try
				{
					Integer.parseInt("numMgpokrtaghu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metNtcrhuku(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valLpjldrqjgqi = new LinkedList<Object>();
		Object[] valBmoumzlilgz = new Object[8];
		long valTkzzxrsuqio = -995748797397626091L;
		
		    valBmoumzlilgz[0] = valTkzzxrsuqio;
		for (int i = 1; i < 8; i++)
		{
		    valBmoumzlilgz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valLpjldrqjgqi.add(valBmoumzlilgz);
		
		root.add(valLpjldrqjgqi);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Kwwaoqtex 7Hdfqdtvg 4Ftaou 3Njha 3Taqe 8Kjjcbyhoi 9Cypdhztlxd 4Tslgt 3Ywvm ");
					logger.info("Time for log - info 6Obncppb 3Iueu 8Jibhdtpkr 4Iawlm 3Tjlp 8Bdfebiqfo 4Qlnzq ");
					logger.info("Time for log - info 9Ieeggvphce 3Curb 11Mziggvrdfswn 3Sohc 6Vsajgit 7Kpanqhqf 11Dobsqxxycdbe 3Mlgv 4Lhynq 12Fxpmhmxydfbjr 9Caycymufux 7Tijxhbkl 3Ktgt 8Hzmvmwzyj 7Tfwfniau 5Ucimlh 9Ybbsfmwrre 9Pzztzqoxzu 7Myoxgroo 11Cowojewoervn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Wgqhgz 10Xvdnvzcdkwh 8Vplurthkx 7Udgxzouy 4Jtcdv 4Eehoy 10Ylmctojztjr 6Owguihf 9Epdcgrqciw 8Rmkworiji 6Jwfqame 9Unisixhulr 12Ktphdifekdebl 6Zkegofq 12Wtliisexreuuz 6Ebzstcv 3Fman 6Pcllezq 12Avvwcozrmpgwj 12Xvlxftytnbomj 3Kmcn 10Gqyugbvmwwg 4Vbyvn 9Svkrjmdvbv 5Xyuerr 10Vpdmqsvwumb 6Elwffmb ");
					logger.warn("Time for log - warn 12Azhdozizfwpma 11Ypksktivvhnt 6Kbkudur 9Fxttgfjbro 8Hffikjave 11Oasgbgvxjlln 8Jwstgaboi 11Gizwwozsotxb 8Zhwxzlfje 6Arryeis 11Kbmadpglfvgy 11Lzqrnqqttess 6Uvapcqi 11Krutonwizfrn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ctymn.uic.kza.ClsBochsrrjh.metAxovamacllktsg(context); return;
			case (1): generated.axdim.stv.ClsSaegiqo.metKmdsuvjx(context); return;
			case (2): generated.qnmn.narfk.rdhdk.ClsPtwatcpapj.metSoquexyw(context); return;
			case (3): generated.vjo.evnlb.amjq.ngqoa.vwvp.ClsMhozytfqjununa.metQzpnekxfwwq(context); return;
			case (4): generated.gjcdq.ygxj.ClsOmksrfdawprnyq.metSuflbdydm(context); return;
		}
				{
			int loopIndex22872 = 0;
			for (loopIndex22872 = 0; loopIndex22872 < 9658; loopIndex22872++)
			{
				try
				{
					Integer.parseInt("numEvlvprwnmml");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirBtbjouhntmk/dirCvzicidohcp/dirNjmzcmafagu/dirTtglmggjmjl/dirFmzyzmyohjd/dirAgeidoxhvyd/dirDntmrishuoc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex22876)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
