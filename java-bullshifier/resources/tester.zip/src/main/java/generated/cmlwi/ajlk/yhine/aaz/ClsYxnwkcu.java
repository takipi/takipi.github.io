package generated.cmlwi.ajlk.yhine.aaz;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsYxnwkcu
{
	 public static final int classId = 426;
	 static final Logger logger = LoggerFactory.getLogger(ClsYxnwkcu.class);

	public static void metFaguljivuo(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValWmplmpjlhdx = new HashMap();
		List<Object> mapValKkdvrcmvzck = new LinkedList<Object>();
		String valSjlyvdpkhrv = "StrJzjgfcujunv";
		
		mapValKkdvrcmvzck.add(valSjlyvdpkhrv);
		long valQzvdyucxovi = -3296959071129905071L;
		
		mapValKkdvrcmvzck.add(valQzvdyucxovi);
		
		Map<Object, Object> mapKeyXejtijurmaw = new HashMap();
		String mapValSjwmfatamdi = "StrQmpffdugvzf";
		
		long mapKeyPitnmnmdpoa = 3766057923743829659L;
		
		mapKeyXejtijurmaw.put("mapValSjwmfatamdi","mapKeyPitnmnmdpoa" );
		boolean mapValPznylmpgyvf = true;
		
		boolean mapKeyLsslreqwmjw = true;
		
		mapKeyXejtijurmaw.put("mapValPznylmpgyvf","mapKeyLsslreqwmjw" );
		
		mapValWmplmpjlhdx.put("mapValKkdvrcmvzck","mapKeyXejtijurmaw" );
		
		Map<Object, Object> mapKeyMxkfnrptndk = new HashMap();
		Map<Object, Object> mapValMwgsdjofkew = new HashMap();
		boolean mapValXmmpuaudwcd = false;
		
		boolean mapKeyHcafpukccds = false;
		
		mapValMwgsdjofkew.put("mapValXmmpuaudwcd","mapKeyHcafpukccds" );
		int mapValLlnpecppwge = 89;
		
		int mapKeyVgptjqttxni = 861;
		
		mapValMwgsdjofkew.put("mapValLlnpecppwge","mapKeyVgptjqttxni" );
		
		Map<Object, Object> mapKeyJiihgpzotqr = new HashMap();
		String mapValXvoogauowkj = "StrXvprdrmytpn";
		
		long mapKeyBozwaazcqfj = 8668142618051549029L;
		
		mapKeyJiihgpzotqr.put("mapValXvoogauowkj","mapKeyBozwaazcqfj" );
		int mapValLfzhvzbsldf = 34;
		
		long mapKeyNuyrobehmzk = 3202780658305645702L;
		
		mapKeyJiihgpzotqr.put("mapValLfzhvzbsldf","mapKeyNuyrobehmzk" );
		
		mapKeyMxkfnrptndk.put("mapValMwgsdjofkew","mapKeyJiihgpzotqr" );
		
		root.put("mapValWmplmpjlhdx","mapKeyMxkfnrptndk" );
		Map<Object, Object> mapValPkwfmrjembf = new HashMap();
		Object[] mapValUxliykobsxw = new Object[9];
		boolean valOmmemkzeqcm = true;
		
		    mapValUxliykobsxw[0] = valOmmemkzeqcm;
		for (int i = 1; i < 9; i++)
		{
		    mapValUxliykobsxw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyEhdxvphnedt = new HashMap();
		long mapValOnasmaderzd = 5585815640903588045L;
		
		String mapKeyPcwboqiilgf = "StrDyokulpexce";
		
		mapKeyEhdxvphnedt.put("mapValOnasmaderzd","mapKeyPcwboqiilgf" );
		
		mapValPkwfmrjembf.put("mapValUxliykobsxw","mapKeyEhdxvphnedt" );
		
		Object[] mapKeyAudnfwyourj = new Object[2];
		Object[] valKtptjpmxtme = new Object[3];
		boolean valScefxkrxwhr = true;
		
		    valKtptjpmxtme[0] = valScefxkrxwhr;
		for (int i = 1; i < 3; i++)
		{
		    valKtptjpmxtme[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyAudnfwyourj[0] = valKtptjpmxtme;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyAudnfwyourj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValPkwfmrjembf","mapKeyAudnfwyourj" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Poregmv 4Xlsam 6Tazdvwt 9Iptbaippdy 11Kqrvvnubpqyc 6Gyyaxmy 5Unayke 11Rttoqmlkqerk 12Opwrihlpmqmsm 3Ycyr 6Kntpoid 8Fhahpehen 11Nijbixsxzcbd 7Nyoakgus 11Kqmwycabozdy 3Ewaa 7Tdxdnqby ");
					logger.info("Time for log - info 6Ikthqep 8Risxdmwar 5Xwmzhw 3Bttf 7Vupbaiof 7Iwpdixjo 7Xiokoemq 9Uqkiqjfgfw 3Jpjb 12Hnuqhuuiexryl 4Usyxv 5Lwuqyn 10Kvlhktdxauc 9Awsqqjusvh 8Xrybsicqw 10Kwwlbunswwl 6Uystove 11Aakgpitndyie 6Fywklaj 5Dkmodp 11Gkvrlfiapoqq 5Iropdm 7Ilwlzlhi 11Yboejrspihen 12Hqonnhzfrbezf 6Ieuetyn 9Eielaixdat 9Zvbhtyljzy 4Nwxqo 11Hsjeapvslauz 10Dbfetialcyx ");
					logger.info("Time for log - info 3Qxar 7Xhovexbg 11Orvxtuilgmnz 7Dnyhisru 5Ibptjn 5Gmxdml 8Gaastadpk 11Frxavudplqtc 6Beylgku 11Vvqmsbtbgdcq 11Xshagqwcawuo 7Erfwsbxo 8Ydixxlxty 8Jpnoyqqmd 4Ctazq 9Kumyhxuibm 5Nrhzyi 10Ewokprnybnn 6Srrrkoz 8Btfdjoivc 8Xrihqchnm 8Jlzccikeg 10Qhnevlgdyuj 11Lsqglywkjxws ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Nhhyszx 12Guhevamorknqv 10Oerjvleckxx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Gxmqt 12Cilyancciorsz 8Dflqrplbe 10Pnzrnszoboo 10Cuqguvhkpea 4Xodcl 10Wajaaxmrmqe 10Jnfxhxxwfss 6Ehsplbq 3Symr 4Ntgui 7Sxtlrdfh 5Hndutc 3Brvm 7Mucktfbk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vhkgi.kzbju.ClsAkkdrnlxagwy.metKsomxqgjrt(context); return;
			case (1): generated.dbr.dvpj.ClsKgmhp.metCrowwzphiuytt(context); return;
			case (2): generated.nrwq.xlmuw.ClsJifahbhi.metWahxogsbzqn(context); return;
			case (3): generated.vfomk.ywmw.ClsYphqbuncz.metCyvjbbsbxbyc(context); return;
			case (4): generated.hcdv.yknh.ClsEeaftdg.metXffnjwesvutru(context); return;
		}
				{
			if (((977) % 41134) == 0)
			{
				java.io.File file = new java.io.File("/dirBjdvgqvtaol/dirYkduwtnbfhq/dirXwudtfjqbjf/dirMawkchusyzi/dirNfwmxalemyu/dirVxztioqdoge/dirBnemrntmgdk/dirGqnajledmhi/dirHlhozfmahct");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((8012) % 748435) == 0)
			{
				try
				{
					Integer.parseInt("numRezbxwfrtim");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metFaqlrsyc(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValObleugpjwed = new LinkedList<Object>();
		Object[] valHrcjdhwctpr = new Object[6];
		String valQwcmzxyahhx = "StrIhuzsmnccjs";
		
		    valHrcjdhwctpr[0] = valQwcmzxyahhx;
		for (int i = 1; i < 6; i++)
		{
		    valHrcjdhwctpr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValObleugpjwed.add(valHrcjdhwctpr);
		Object[] valYyboakxidom = new Object[4];
		String valPanhqbbbypv = "StrRyqulcqgkhi";
		
		    valYyboakxidom[0] = valPanhqbbbypv;
		for (int i = 1; i < 4; i++)
		{
		    valYyboakxidom[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValObleugpjwed.add(valYyboakxidom);
		
		Set<Object> mapKeyAzxbykqqvqf = new HashSet<Object>();
		List<Object> valLppwdbcceat = new LinkedList<Object>();
		long valNhcpphidjxl = 699845476141933482L;
		
		valLppwdbcceat.add(valNhcpphidjxl);
		long valErcwemhscwv = -8313277432435391276L;
		
		valLppwdbcceat.add(valErcwemhscwv);
		
		mapKeyAzxbykqqvqf.add(valLppwdbcceat);
		Set<Object> valVaqqttgahyu = new HashSet<Object>();
		long valPihdidudmby = -8873410260183353486L;
		
		valVaqqttgahyu.add(valPihdidudmby);
		
		mapKeyAzxbykqqvqf.add(valVaqqttgahyu);
		
		root.put("mapValObleugpjwed","mapKeyAzxbykqqvqf" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Sgmtfvqgx 9Zaqfiwwdup 11Rqzqczqgqtxf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Qitpggqh 6Jratsex 5Uxeprn 3Fisw 6Msfkwjo 9Raqcktultr 4Fwivt 6Perfqnn 5Otjyjq 11Bgcqudgrtnvl 12Knbmaaioejuaa 6Yzrmigw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Qushmzgx 4Eakxl 5Kebzft 9Cvijkixgwj 9Sddjzrgtod 11Xtensajlaocs 9Xxwzuxzgjc 9Ylhkfxqpxk 3Ggcg 11Jsvlmnhdjjst 7Wwqyehid 8Vnyuzimml 7Nquncznt 4Kbmpf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wvkuf.rvtq.kcgfs.vezg.ClsKfeffw.metSgbkqkssvllef(context); return;
			case (1): generated.lvnhk.isns.uksl.tjjfx.ClsEfuazouhb.metLybrkriiked(context); return;
			case (2): generated.budq.anwwr.qie.tcx.ClsAvdrojvr.metVuphivdf(context); return;
			case (3): generated.rnr.pwsrq.cbi.tat.ClsQsqavl.metUgatrdxyhn(context); return;
			case (4): generated.ojyuy.hdvu.yij.nuf.ClsJtdiu.metUymohzkoe(context); return;
		}
				{
			long varUjdypqoonmh = (Config.get().getRandom().nextInt(365) + 2) - (3468);
			if (((Config.get().getRandom().nextInt(786) + 0) + (Config.get().getRandom().nextInt(117) + 6) % 634822) == 0)
			{
				java.io.File file = new java.io.File("/dirNvrtlpaexim/dirNfuhhsyqroj/dirMjcvcauletv/dirCbrmksxkiua/dirOcjvuugybkx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metLfnugxqxocfhpv(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValGabsghwqmin = new Object[11];
		Set<Object> valCqxwaxhbhcc = new HashSet<Object>();
		boolean valDagomjsngbc = true;
		
		valCqxwaxhbhcc.add(valDagomjsngbc);
		boolean valQsbzkbyjvsq = true;
		
		valCqxwaxhbhcc.add(valQsbzkbyjvsq);
		
		    mapValGabsghwqmin[0] = valCqxwaxhbhcc;
		for (int i = 1; i < 11; i++)
		{
		    mapValGabsghwqmin[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyFqyoyllskcm = new HashMap();
		Map<Object, Object> mapValUxicusmbuwn = new HashMap();
		int mapValXghcvgdxfdj = 944;
		
		boolean mapKeyNcirroolxvg = false;
		
		mapValUxicusmbuwn.put("mapValXghcvgdxfdj","mapKeyNcirroolxvg" );
		
		Map<Object, Object> mapKeyGncwiktnsvx = new HashMap();
		String mapValHnfwcpekurf = "StrQxubfghgooz";
		
		String mapKeyCariqlhxiur = "StrQxvrzbmnnki";
		
		mapKeyGncwiktnsvx.put("mapValHnfwcpekurf","mapKeyCariqlhxiur" );
		
		mapKeyFqyoyllskcm.put("mapValUxicusmbuwn","mapKeyGncwiktnsvx" );
		
		root.put("mapValGabsghwqmin","mapKeyFqyoyllskcm" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Hwyqluhsr 4Higsl 11Hphcfawqdbhg 6Kiuufnd 6Yhrqdzv 12Dwbnkqwunbpgx 9Hfbmzyjctu 3Epju 7Tnzlhezc 10Yogzmdzercs 9Imkjbxovaz 7Neruzron 3Dzng 5Zgsffc 9Hurwsmngsc 3Hspk 7Wkridzhz 6Jlfbhbs 12Pjiwwqsezdlzg 12Aefismicamybz 10Belicrzfcox 10Tfnhvsahwwj 4Yvhay 3Itha 9Nzwijuxyla 7Yapwtecs ");
					logger.info("Time for log - info 6Fcweavn 12Vjeuubbnjqrai 12Fbrfwhkqmjlzg 7Irhdjqbd 10Edgoqftkbxw 8Xgjetnrmm 10Ihfrbdwjggp 3Cueo 12Xnkizoxnftczy 10Zebpuljxcst 11Pmrdnujvdeol 7Rcrjsjif 10Caswyhxxacc 7Qoioevpf 11Yunxvurrjbxa 6Yshwqhg 4Sxvjd 11Dxsuulgbqdrx 8Eyjuemeed 12Iipiljpbqznrw 12Tfbrmuxvjppxt 8Zivtsmbmw ");
					logger.info("Time for log - info 9Kobszrgzhp 3Brmh 12Pzrpmdtgooici 4Iqbkp 4Eaqvm 4Teqlm 11Cwxyegdqszql 8Ckoglkkyd 4Norkn ");
					logger.info("Time for log - info 7Mkjoyydm 3Yxmu 9Thgncojudu 7Pfxcplgk 8Gvpohblsk 10Rbcindimwbg 11Chucpfbzbnnj 12Zpykyzgkhzxzw 4Mnqhc 9Krugjtlxwq 10Gszmcsnfhvh 7Rcfqedti 7Lulyynvu 7Rjihcolh 3Ildj 8Rupslvgdj 11Fvfhycrhebtu 9Qdpktwkxem 9Regpmmdjkr 3Puhh 3Rssq 6Nfiaybq 12Tzhhvjnkrluib 4Jipdh 12Wkruodcosulkq 12Wrslthbwzkldl 4Wboxi 4Kiplz ");
					logger.info("Time for log - info 3Afzf 11Nryehtlyerow 4Cwlyi 7Aydawqgx 7Uoakbedw 12Cfeagqcpcmipy 3Jwpo 10Xovnozfyjns 9Jqprhotjnh 9Kpdpusnicq 9Itcirlfosr 9Jqhpfrrnky ");
					logger.info("Time for log - info 6Mawcfpd 5Uuqbdz 4Cpxxv 11Saisausjhrql 3Apuq 4Pzewy 7Krbmzgjg 11Rdudnbqmqasj 3Tyno 4Zpjjh 3Baoj 8Dkancbexc 3Ebtj 9Rsyhicockt 3Akbl 6Hfhswuj 7Inwwpuuy 6Dyyfzad 10Kwsigvlvwba 7Jqgynhsw 5Zlbpma 12Kdtvwfahioptr ");
					logger.info("Time for log - info 9Fssovqilow 9Geqeksjeti 5Gydaui 6Paxjlfv 10Iiqvpomhyto 12Ymhzfimdxigek 6Rxxhspk 9Zaebnnpjwj 10Pzdzhjmtiuz 11Nmzbwbfhjnux 11Yigrdxkdetdg 8Uxtlfwtxi 8Uizyzpmyd 11Pkhyugiheetq 9Iibyxyewql 11Nxspgtpizjre 8Bvobfbrvg 9Qfmlzrgqmt 12Ynslwgkwucnmh 9Fzvlxydvrs 6Zzypote 6Wzwcilj 5Ajrmqg 10Twshsddyeeu 5Jedphc 12Pqxhpgrcfqkrm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Aojvfgcedxl 5Pakewm 6Ylvodea 11Npmxfalykujv 5Cujcda 6Upxtdpa 6Totijsp 7Hdfwqozu 5Flnqhk 4Znqgm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Nsqfrjj 6Puwltyc 7Spzzhvhk 9Dexdibzwvs 4Oiezz 7Fluhkmqb 11Dbczovaijwqv 4Xthcd 3Shei 6Tqaqwin 8Cylgvkbzn 12Ouszcemlszdbb 11Fhhuwpfayoyc 8Mnvqcekbq 3Qgmj 11Jhtodvtiiwga 8Nwwultufd 7Ukqnteud 12Bkrrngciofzha 4Fsmsj 3Qqqa 9Hdubfweffa 4Mocbz 8Cuasgshyx 4Nefkw 8Auhqdubbu 9Yybrrfkggv 12Ldvstflqwinmr ");
					logger.error("Time for log - error 6Bbdtmhq 10Ovwegrcovpi 10Qplfwnrdell 12Nlcwtimsdjtcm 7Wcykizuq ");
					logger.error("Time for log - error 10Fojylpsuhtg 10Aqrqciilpop 5Ekgrac 4Uptnp 10Rrcpldewzwo 9Ihkddgoato 5Wwlhjb 12Uylsqsukczbft 8Xwnkgghoh 9Joenocdugn 3Xpgj 6Ukeklfn 6Xjhbgtf 12Enonhudxhjyfw ");
					logger.error("Time for log - error 4Ougar 7Ijjattvp 4Lodwl 3Fymo 11Dvfralatfart 11Kgqgypjzrals 5Izxtqe 4Quvzt 8Juqvfunui 12Jntcvcevtrwnl 4Mwfdx 8Fyxkzrtet 10Bcdpnvdlxno 4Exjiv 12Xjyfqhrfvbuzk 9Qymnjozonb 4Zvhlu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ocmm.ezbtm.vxyei.kuseg.ClsUqzgoaq.metSglyom(context); return;
			case (1): generated.gyic.epw.ClsQxhbkrqjzoqujk.metVprfejv(context); return;
			case (2): generated.pema.ddj.ssuh.ClsIlinaijnkxxo.metPxgeyqlgriu(context); return;
			case (3): generated.qivmb.wlyy.vhwlw.ClsJhewvjqlcuh.metAouqfagpakd(context); return;
			case (4): generated.godw.hlszo.mtqbt.shx.tbgwd.ClsMygvrmsqnwlsdw.metUxxnltxclfyjd(context); return;
		}
				{
			long varQnrvmcqewox = (Config.get().getRandom().nextInt(394) + 7) * (Config.get().getRandom().nextInt(197) + 3);
			long whileIndex27154 = 0;
			
			while (whileIndex27154-- > 0)
			{
				java.io.File file = new java.io.File("/dirZuuoxwkwvfg/dirRkqvpbzcmao/dirLptmjcujish");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metTsnvquyweiwxo(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValQacnlcwufon = new HashSet<Object>();
		Object[] valBqedzgaltxb = new Object[2];
		boolean valZjmacmgijre = true;
		
		    valBqedzgaltxb[0] = valZjmacmgijre;
		for (int i = 1; i < 2; i++)
		{
		    valBqedzgaltxb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValQacnlcwufon.add(valBqedzgaltxb);
		Map<Object, Object> valJghqnasfcxh = new HashMap();
		String mapValYxxjlisxigo = "StrJgomjhpufyb";
		
		String mapKeyMezvyqfyxcf = "StrCdypfbugpak";
		
		valJghqnasfcxh.put("mapValYxxjlisxigo","mapKeyMezvyqfyxcf" );
		
		mapValQacnlcwufon.add(valJghqnasfcxh);
		
		Object[] mapKeyFdtxjyaintw = new Object[9];
		Set<Object> valYjlowgwhamq = new HashSet<Object>();
		int valDvbnihtzkti = 487;
		
		valYjlowgwhamq.add(valDvbnihtzkti);
		
		    mapKeyFdtxjyaintw[0] = valYjlowgwhamq;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyFdtxjyaintw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValQacnlcwufon","mapKeyFdtxjyaintw" );
		List<Object> mapValOuwdrgzkmmk = new LinkedList<Object>();
		Set<Object> valTnygumpvhgd = new HashSet<Object>();
		int valLekayybibpj = 262;
		
		valTnygumpvhgd.add(valLekayybibpj);
		boolean valOjgvulmvudu = true;
		
		valTnygumpvhgd.add(valOjgvulmvudu);
		
		mapValOuwdrgzkmmk.add(valTnygumpvhgd);
		List<Object> valFnkkzkygeqc = new LinkedList<Object>();
		long valQbnrukbscyy = -4112913590735066226L;
		
		valFnkkzkygeqc.add(valQbnrukbscyy);
		
		mapValOuwdrgzkmmk.add(valFnkkzkygeqc);
		
		Set<Object> mapKeyBqaydfgqmof = new HashSet<Object>();
		Set<Object> valKcdvcduszpm = new HashSet<Object>();
		String valLmbfmdxofdt = "StrKcsaiwrbxjo";
		
		valKcdvcduszpm.add(valLmbfmdxofdt);
		long valVypvmzpttjr = 6106228005961263770L;
		
		valKcdvcduszpm.add(valVypvmzpttjr);
		
		mapKeyBqaydfgqmof.add(valKcdvcduszpm);
		
		root.put("mapValOuwdrgzkmmk","mapKeyBqaydfgqmof" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Yqibwm 12Mcyszmgffbtjw 5Zreoqx 12Zwvbvnrstvqpq 12Oilhpbrkwlzqi 3Hael 9Qlofnbxshr 7Jexhjsyr 3Kgjj 9Cxefoxwjid 10Kjrxaaxpabs 10Towqqhxmbfc ");
					logger.info("Time for log - info 6Ywjpbqp 12Wztutxaiefeki 3Lcpn 12Fbotsmimnhcob 3Sgsp 10Pxnrjwkamiq 9Yahrdzuqyv 10Pedgqswlvya 9Ksgfneqmmi 8Mhyiwrxzy 6Dbagxhp ");
					logger.info("Time for log - info 12Gytyjmhwrhpnh 3Afcp 4Sgtgw 6Gtroqgt 10Luqsuhnanfg 8Quyrecoan 9Ehaysvfdkl 7Bfhgtlul 12Cacuohfkbfbyd 11Iprjnadchjhj 5Hvnodw 4Vvdrq 9Zzueltxwfc 3Halk 11Ltijodtmagsu 12Hzfziouavikya ");
					logger.info("Time for log - info 6Aqrglfs 5Bvlgha 3Cvlt 4Ldnng 7Sholecvi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Uwjhagb 4Kiiuv 8Jrawgbixl 9Reeddfmaab 10Iupzddqhwxi 7Lqbmppdk 6Wbtmjuf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Gyne 8Ugecuvhso 5Gaicrv 3Wgyy 4Ckfuh 8Inksmijig 3Fxmn 6Nlnsaax 7Cxfpzvwu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.exhp.ngeqz.saycv.ClsTbfjaj.metZrbit(context); return;
			case (1): generated.psl.vgj.rgm.ikl.ClsWqomoi.metLwbkg(context); return;
			case (2): generated.swyg.szfbf.ejprt.ovbj.ClsEqyrgxer.metGhwucfmqcy(context); return;
			case (3): generated.siinn.hrk.mef.ClsDcfbqxc.metPlpmmksy(context); return;
			case (4): generated.mvh.wsi.ClsXxvtrnameonpg.metVrdqdrupoen(context); return;
		}
				{
			if (((3203) % 268125) == 0)
			{
				try
				{
					Integer.parseInt("numTeuhgsaiepu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(509) + 8) % 562927) == 0)
			{
				try
				{
					Integer.parseInt("numUmjvzvqhxtq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((153) + (Config.get().getRandom().nextInt(452) + 7) % 991533) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
