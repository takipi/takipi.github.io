package generated.jczh.tiox.sfe.qsygg;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsFcpmoenzb
{
	 public static final int classId = 309;
	 static final Logger logger = LoggerFactory.getLogger(ClsFcpmoenzb.class);

	public static void metNmlht(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValIfmkwzbbaok = new HashSet<Object>();
		Map<Object, Object> valNtgoxevxwln = new HashMap();
		boolean mapValOjaajpsmefp = true;
		
		boolean mapKeyJmsnehssriz = true;
		
		valNtgoxevxwln.put("mapValOjaajpsmefp","mapKeyJmsnehssriz" );
		boolean mapValYktbprmjzbs = false;
		
		long mapKeyKiqdsdmoocj = -6697085585860052167L;
		
		valNtgoxevxwln.put("mapValYktbprmjzbs","mapKeyKiqdsdmoocj" );
		
		mapValIfmkwzbbaok.add(valNtgoxevxwln);
		Map<Object, Object> valIguymtvqhbn = new HashMap();
		long mapValYjxguayznuf = 5115465596569091063L;
		
		int mapKeyPgivxqqggsi = 375;
		
		valIguymtvqhbn.put("mapValYjxguayznuf","mapKeyPgivxqqggsi" );
		int mapValMmwiooidjvo = 917;
		
		long mapKeyUvjlljbhkkf = -7252981292129692787L;
		
		valIguymtvqhbn.put("mapValMmwiooidjvo","mapKeyUvjlljbhkkf" );
		
		mapValIfmkwzbbaok.add(valIguymtvqhbn);
		
		Object[] mapKeyTrwqkgpqekt = new Object[3];
		Map<Object, Object> valEwzdygdilfa = new HashMap();
		boolean mapValKtqsqmuwhis = false;
		
		int mapKeyKjmzlewkwqr = 530;
		
		valEwzdygdilfa.put("mapValKtqsqmuwhis","mapKeyKjmzlewkwqr" );
		int mapValGzweseazkjr = 456;
		
		long mapKeyLayxjoiwoyx = 4581082403714145629L;
		
		valEwzdygdilfa.put("mapValGzweseazkjr","mapKeyLayxjoiwoyx" );
		
		    mapKeyTrwqkgpqekt[0] = valEwzdygdilfa;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyTrwqkgpqekt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValIfmkwzbbaok","mapKeyTrwqkgpqekt" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Dvvu 7Wsswyidv 6Rxjropb 6Bdbvcgk 9Xhqabgqnom 10Mozqhhtqeqi 7Wrvjefkn 3Rjvj 5Ajnefq 7Wdkvwzpo 6Qzhlsdm 12Eljkngoznytzg 11Ulawipayaren 10Rdxdfrvvknu 5Mxrehb 5Jqibvd 4Fspyz 4Kafwk ");
					logger.info("Time for log - info 12Lznrwkipyutbu 11Dhyyubcvicib 9Cqltuhmfgt 12Rcoubpijpkjvz 9Qqozebgfog 5Frpxrm 10Ekuhuzxhsth 7Nnvrzlyv 6Kfzlplc 4Ipjch 11Aogpqntoijxg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rlg.pxdte.svn.clv.ClsMkagt.metJucehdjpifczd(context); return;
			case (1): generated.wunj.xtrc.rfx.aikz.yopv.ClsTejixmzc.metAhxfdsezzruvtx(context); return;
			case (2): generated.hbqjp.kifli.leg.jlyd.ClsYgtwztbknhdmc.metHsrmkfyvnv(context); return;
			case (3): generated.qivmb.wlyy.vhwlw.ClsJhewvjqlcuh.metAouqfagpakd(context); return;
			case (4): generated.uxbqo.pcskv.udre.ClsKillneqmm.metIokufnwdnpfcxt(context); return;
		}
				{
			int loopIndex25242 = 0;
			for (loopIndex25242 = 0; loopIndex25242 < 8560; loopIndex25242++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varLrxhwfvzinm = (Config.get().getRandom().nextInt(545) + 7);
		}
	}


	public static void metMdeingizamgtx(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valAollkwwulvs = new LinkedList<Object>();
		Set<Object> valDqhmqnwjlxq = new HashSet<Object>();
		String valOongppuedna = "StrYimuplralql";
		
		valDqhmqnwjlxq.add(valOongppuedna);
		
		valAollkwwulvs.add(valDqhmqnwjlxq);
		
		root.add(valAollkwwulvs);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Viszzbympcaab 9Tgukfypxxr 5Hcpyxn 5Ydtijs 10Hqocbgxtczk 4Xdipq 11Urejdircisee 11Bzhjuppfxevg 4Zklql 10Omqfonwzjwl 7Ttccvqso 12Uwszhlplbskmm 3Toek 8Rxsxisrug 3Iper 6Rpzuufq 11Pekafvodhupf 5Edwqdt 9Jfqzmmrpjx 11Juamanawjtoe 4Aatro 4Mqzfu 5Dyvpka ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Gbyoxofj 3Qqiv 3Gxdf 5Mxejsl 5Nfyxlu 7Jrjauvyr 10Fdaqybcaaft 6Fmdxysf 4Bzbbc 5Hvtyjn 5Inhnjb 6Hdtlfwh 10Ggjicaqpyoz 8Vzyygnnim 6Hbugjln 12Bhawsiairbywk 10Ctefsdtkdws 11Kdllwzzcuopd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Ufnhoku 12Avoyqacuqrabs 3Wpmv ");
					logger.error("Time for log - error 12Jkaqfrtbsgtxp 9Tldiyewpdp 6Owfulxn 5Imdurf 4Iraou 11Zlycjgfhjyks 7Ercverxu 7Rlvrwhin 12Kzpvblvlhoork 9Yhjuvdevlf 5Ieqjay 10Ufdqjetwcsv 10Bnrfvkddxsw ");
					logger.error("Time for log - error 11Ujxiiqfhpjko 4Hxlbs 8Otcgrjhtf 3Uvlo 10Tsslxdobyrq 8Qphujthmv 5Phanwu 10Xyygmjbsujf 6Tamuelc 7Bcmwzebo 11Pskrivwshibe 11Utninbezkglq 6Gamhuyd 8Yjdmovmnb 10Huelkneuluj 11Ltxfxyabcrls 10Nipxixxgvme 8Fdcjwzlcf 5Uutbpo 5Bzvpov 4Soqan 5Ovtbaa 3Kzep 8Vhmlhbnyw 8Ewoeinvyr 7Xtkashiq 11Qyxcfdgpdqjp 6Wudynpq 7Gxvajbcd 7Zpgtwude 5Kpfvju ");
					logger.error("Time for log - error 12Gqkraddeigsfd 12Iryhflyhsddsb 3Dajc 10Ntkrocsuiup 4Umxvx 10Nbrsruxucau 12Znuazbtvqwzkk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.axdim.stv.ClsSaegiqo.metVwtuv(context); return;
			case (1): generated.nrrh.nxnu.xat.kha.ClsLoiagobs.metTrfqw(context); return;
			case (2): generated.dxrru.qphkk.sigfx.fho.qtrx.ClsXgcfqnkax.metJqylvdbl(context); return;
			case (3): generated.gyic.epw.ClsQxhbkrqjzoqujk.metGcqcxmaffuic(context); return;
			case (4): generated.crkmz.uuny.smq.vvmxn.khxb.ClsQbvzuhroxdituh.metVqzfw(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numZedbdmdrvsj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirAewlouruwys/dirGnygijoivsn/dirQvpijnwwxbw/dirVujzlcdsjgu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex25247 = 0;
			
			while (whileIndex25247-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varMsncrsmuoaw = (Config.get().getRandom().nextInt(21) + 1) * (193);
		}
	}


	public static void metEjlwxaxrxcgtq(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[6];
		List<Object> valQgwbkfvbcts = new LinkedList<Object>();
		Map<Object, Object> valBdrvcvfwqsl = new HashMap();
		String mapValOtvihqdqzyk = "StrEjnekkplcci";
		
		int mapKeyStkfrkjibkb = 235;
		
		valBdrvcvfwqsl.put("mapValOtvihqdqzyk","mapKeyStkfrkjibkb" );
		
		valQgwbkfvbcts.add(valBdrvcvfwqsl);
		
		    root[0] = valQgwbkfvbcts;
		for (int i = 1; i < 6; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Rlyfuwmgqnlh 8Lhnaxyglv 8Qzbgtcdte 11Hrhzwovapxjy 4Xotll 4Tpnbw 3Molg 8Hyibvrzgy 5Typlnf 12Klsgbkpbjfqbs 7Hohlazah 9Stxzfifwrx 3Nbcy 12Iahcfmnpfooxn 7Momirjnp 9Grqrbwsjnk 10Eccqxohipxd 12Biwgflihvbcuv 12Fqlncrcykjcku 10Nihphnatbrk 7Mpwbvvsw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Slrfxfh 7Gdffbgvo 6Rowlieh 9Pewmwqdvix 8Dhbbgjzfl 9Hdgdkyyogs 8Verwesibl 5Mjiuta 4Mcltn 11Oqiqtzpandib 6Vswihup 11Cuyjvjzemejh 12Wpqsfadcvdvon ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Ppduh 6Tqopkmr 6Njhqkjg 6Ggnkcrc 3Gfrr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pxdt.vcuzq.tfk.bjngo.ClsCaopcwu.metNrjzvdamjddqk(context); return;
			case (1): generated.jgye.cou.ClsWhiobyn.metQbdzxppzc(context); return;
			case (2): generated.wcc.zfysf.ClsYrxejsiwymmrbw.metKnfdaxts(context); return;
			case (3): generated.ayxg.baac.ClsIciuzantocwhkq.metBmijwhb(context); return;
			case (4): generated.fflc.jdncn.ClsHubvnnx.metSnkfjhjtib(context); return;
		}
				{
			long whileIndex25254 = 0;
			
			while (whileIndex25254-- > 0)
			{
				try
				{
					Integer.parseInt("numUexaifcrhmi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metFrwhzgmtiki(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Object[] valFqsyqfnwxot = new Object[2];
		Map<Object, Object> valClyfvvyyvwo = new HashMap();
		boolean mapValKxvqkoznucj = true;
		
		int mapKeyGnhqinubenq = 252;
		
		valClyfvvyyvwo.put("mapValKxvqkoznucj","mapKeyGnhqinubenq" );
		String mapValEntyajhcvnc = "StrCfnrnjsfubh";
		
		long mapKeyCpxojgnilob = 3860098560041155458L;
		
		valClyfvvyyvwo.put("mapValEntyajhcvnc","mapKeyCpxojgnilob" );
		
		    valFqsyqfnwxot[0] = valClyfvvyyvwo;
		for (int i = 1; i < 2; i++)
		{
		    valFqsyqfnwxot[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valFqsyqfnwxot);
		Set<Object> valOmtmozywsnn = new HashSet<Object>();
		Object[] valDxbdsqvcxyi = new Object[4];
		int valVqlouolesmk = 273;
		
		    valDxbdsqvcxyi[0] = valVqlouolesmk;
		for (int i = 1; i < 4; i++)
		{
		    valDxbdsqvcxyi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valOmtmozywsnn.add(valDxbdsqvcxyi);
		
		root.add(valOmtmozywsnn);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Bxtnwqxt 10Rkxuvjyuxys 11Njavvudgedlv 11Sgbiugbrsxxx 3Begn ");
					logger.info("Time for log - info 6Cvpcqdi 11Ikjrsyakazyl 6Kvvwcqx 9Omkffjhdyy ");
					logger.info("Time for log - info 7Snvsrskn 5Pykskb 12Tzfoywgcwkpes 6Iwjiqiw 5Gphwjd 7Wmriyzbw 7Mbektzcc 10Itgkctomfci 9Dzoyhqsxfm 9Atyhipmigo 9Ndmskbeuzi 3Rpet 11Hbffxtsetyri 4Tphdn 3Otsp 10Vrxoabohuep 5Gdybmv 4Wugnf 8Hzqbzilwa 10Oytfcjydtug 7Lpazurqa 10Tdfcbtebtrv 4Xuwcd 12Hbmbeiktemess 10Vvqzunfamwh ");
					logger.info("Time for log - info 11Ehqmffgdsbow 9Opqvhnatbd 4Ebfer 8Ayosofunh 4Sjylv 5Sqyqdv 5Wsfoyw 12Fmubebmthkqvi 4Vympm 10Dfbimvikmsn 7Kalajnwu 11Oflquibdpdcy 6Kvtwmln 12Hwlysnialcvrn 5Mnrcch 3Isnc 10Vwpaxujzfck 3Jlqe 11Juisdfjqoula 12Tvhhcbcrptwlv 5Hworpq 7Izmeijal 10Ihzvptqzlts 7Wxsctduz 12Calpmwrfooztk 3Pxez 10Mlvltzyfkpq 9Etlpwmzesl 11Kyxrhlmyebmm 11Udrhuarhkjpb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Lposclyw 6Lsaavuo 8Xqupcnugg 9Ljutzdetpn 3Hial 7Vivogwnk 10Dfmqqouwyvw 10Lgymmjekjzp 4Chgpo 4Svtnw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Kxvjjrpoim 3Dzrf 12Obkgopzzmxrrj 10Vfcddsiapni 4Vfima 10Ynplijjkwjr 11Tiplhnyymzoo 7Opogkoia 10Fgrwzgiybpi 10Radncurooce 3Mkef 12Pganhzzklpdmi 9Ropbgvmvbd 3Nlqh 5Wgtzax ");
					logger.error("Time for log - error 11Cshdhdrhrixh 11Hppwhoootyyd 6Eamyyxw 7Rfhukswk 11Kccultptwdbj 3Hlxl 5Yavwoa 10Qedzmekqilw 6Htqdiru 9Ruitoalikv 3Opts 8Ywbchrjzi 9Heqppchbin ");
					logger.error("Time for log - error 12Lxhvdexawgxtd 12Qkldfwgujmqtl 11Ixixerbugvoq 9Mcmdofujsd 6Wnblvlr 7Aacwthce 12Bwmouyqupbpnj 5Hctzlb 10Jfmwqsbqvtr 5Aaeygv 4Jfbfw 10Jhffjevkyre 8Htubueowl 12Otbllfggijlsb 3Nvff 12Ifyulvacyuqvj 3Rirt 7Dmhrbfck 6Kjbkhgx 11Zlzxhvgwioxv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wgclb.xej.jxqsz.ClsVlhpzchb.metWmoop(context); return;
			case (1): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metDghubvohwq(context); return;
			case (2): generated.kcrh.cmo.yws.ClsBlekldezyl.metOblagvlrzevtay(context); return;
			case (3): generated.sik.dyw.jmm.xdu.omh.ClsVarjcvcyur.metQssjvtchemcju(context); return;
			case (4): generated.ulre.knov.ClsTukvjlscu.metSnzvazpuz(context); return;
		}
				{
		}
	}

}
