package generated.iyxve.emn.dzc;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsAggygwujkgt
{
	 public static final int classId = 44;
	 static final Logger logger = LoggerFactory.getLogger(ClsAggygwujkgt.class);

	public static void metOlhruhgstjli(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValUtxacrzqouu = new HashSet<Object>();
		List<Object> valRvrgerkheox = new LinkedList<Object>();
		int valSfrxewgzlcb = 92;
		
		valRvrgerkheox.add(valSfrxewgzlcb);
		
		mapValUtxacrzqouu.add(valRvrgerkheox);
		List<Object> valUajlzdrsupf = new LinkedList<Object>();
		long valFultheautpb = 6261683202169210504L;
		
		valUajlzdrsupf.add(valFultheautpb);
		int valUwlaebpdafw = 403;
		
		valUajlzdrsupf.add(valUwlaebpdafw);
		
		mapValUtxacrzqouu.add(valUajlzdrsupf);
		
		Object[] mapKeyRirbdnhsqvh = new Object[3];
		Object[] valGtlkhtxzmvh = new Object[8];
		String valObxgmwwivkg = "StrDlgocoewkbr";
		
		    valGtlkhtxzmvh[0] = valObxgmwwivkg;
		for (int i = 1; i < 8; i++)
		{
		    valGtlkhtxzmvh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyRirbdnhsqvh[0] = valGtlkhtxzmvh;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyRirbdnhsqvh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValUtxacrzqouu","mapKeyRirbdnhsqvh" );
		Object[] mapValPnsgrnutako = new Object[7];
		List<Object> valOynqhnzpdau = new LinkedList<Object>();
		long valZwpbkihkhav = 7470846752702656961L;
		
		valOynqhnzpdau.add(valZwpbkihkhav);
		
		    mapValPnsgrnutako[0] = valOynqhnzpdau;
		for (int i = 1; i < 7; i++)
		{
		    mapValPnsgrnutako[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyWcumtocvkwn = new LinkedList<Object>();
		Object[] valGaxrcpkamrt = new Object[6];
		int valAlgcvvmfnfy = 842;
		
		    valGaxrcpkamrt[0] = valAlgcvvmfnfy;
		for (int i = 1; i < 6; i++)
		{
		    valGaxrcpkamrt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyWcumtocvkwn.add(valGaxrcpkamrt);
		Set<Object> valXdgivqechzt = new HashSet<Object>();
		String valToqvzdozuml = "StrAoehqsbbicq";
		
		valXdgivqechzt.add(valToqvzdozuml);
		
		mapKeyWcumtocvkwn.add(valXdgivqechzt);
		
		root.put("mapValPnsgrnutako","mapKeyWcumtocvkwn" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Lexmrg 11Bjjfiqaxfhfo ");
					logger.info("Time for log - info 8Ufcpjvykq 10Djfhuawmayx 5Onvzoc 7Apjzrtdu 4Vizwd ");
					logger.info("Time for log - info 11Atkxgyrjvkrv 7Tjgjspur 4Jukos 3Lgny 11Ohcbhbnoqqah 5Ntbbsa 9Bgjpuaenul 3Yjxj 8Qxxwohrkq 11Eqdxugtyezkz 8Owfudrfbw 3Fwbq 10Dknrzucdqfk 10Bniwfqeltyj 6Zujmwmy 6Xbbobra 9Biyzpnpylc 9Sodvlxsprs 9Apcynnxqdx 10Jigwxomyxht 12Tbbdchyagwqvl 6Mjyixhs 3Jdja 3Bdip 5Fquajg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Rigzvd 6Wpzacla 4Pgmjd 6Kvncuaa ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pxy.vesv.fuz.ClsEaskwlgtcshts.metCnqxpzkxiqea(context); return;
			case (1): generated.ydzsq.oryaq.elxyy.ClsOrteugmzafy.metMvpbi(context); return;
			case (2): generated.iiben.ptjec.naa.begt.ClsJlkmiazt.metAgwabdd(context); return;
			case (3): generated.jlzkx.vlyxg.uui.ClsYmzeuds.metOsbppb(context); return;
			case (4): generated.cxoq.hzjj.hhxu.ClsXfvidhbawjojdu.metGjokxistgrq(context); return;
		}
				{
			long whileIndex2804 = 0;
			
			while (whileIndex2804-- > 0)
			{
				java.io.File file = new java.io.File("/dirBtrpcqrvqtb/dirObvmqojyhfc/dirRvvfcdatbtl/dirUlbjsilhowz/dirXuhnjrryqnp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metWmlfsxai(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valXsvcpxxzchm = new HashSet<Object>();
		List<Object> valDzpkhtxaaxx = new LinkedList<Object>();
		String valUdobrciimmb = "StrZdrscswqvme";
		
		valDzpkhtxaaxx.add(valUdobrciimmb);
		int valIbmzprurnoc = 945;
		
		valDzpkhtxaaxx.add(valIbmzprurnoc);
		
		valXsvcpxxzchm.add(valDzpkhtxaaxx);
		List<Object> valOegljimgrep = new LinkedList<Object>();
		long valQkrpzhvcwge = -8254255059299103283L;
		
		valOegljimgrep.add(valQkrpzhvcwge);
		int valSvkmzxhhrly = 967;
		
		valOegljimgrep.add(valSvkmzxhhrly);
		
		valXsvcpxxzchm.add(valOegljimgrep);
		
		root.add(valXsvcpxxzchm);
		Map<Object, Object> valPtceyzrnqwm = new HashMap();
		Object[] mapValKohlbxdxjll = new Object[10];
		String valNcziocsqlka = "StrMdprcfvnxaa";
		
		    mapValKohlbxdxjll[0] = valNcziocsqlka;
		for (int i = 1; i < 10; i++)
		{
		    mapValKohlbxdxjll[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyJnuovksnlou = new LinkedList<Object>();
		int valRvrdtsbctrz = 280;
		
		mapKeyJnuovksnlou.add(valRvrdtsbctrz);
		
		valPtceyzrnqwm.put("mapValKohlbxdxjll","mapKeyJnuovksnlou" );
		Set<Object> mapValMywunzglpwm = new HashSet<Object>();
		int valPhjzqfdjqam = 619;
		
		mapValMywunzglpwm.add(valPhjzqfdjqam);
		
		Object[] mapKeyDsjwsbfrccz = new Object[6];
		int valDzvfmegriek = 250;
		
		    mapKeyDsjwsbfrccz[0] = valDzvfmegriek;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyDsjwsbfrccz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valPtceyzrnqwm.put("mapValMywunzglpwm","mapKeyDsjwsbfrccz" );
		
		root.add(valPtceyzrnqwm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Hhylr 8Fojnvzagl 7Aililjxl 6Vmyocnu 10Aabgakwesin 5Fqfmmu 4Pidhe 11Uddelgqrfmpm 8Dlqcyrlod 9Dqwhusilui 3Cudz 12Rcjyypshttjok 5Ahxemd 9Bhnkgukiqf 3Ljmr 7Xgfsvfxf 9Eqyfebrouh ");
					logger.info("Time for log - info 5Lvcoil 8Mfombvawz 5Ucvhmd 10Kfxkaxqdrnn 11Sydvidssgpsf 6Bmdjevj 3Kpbh 3Rqmk 11Veqhfwwppmry 3Kfni 10Zyqfgzgbvzy 11Uzfzgazvzdar 10Fsizmsjhgtu 9Zomztnkdvo 5Htnyam ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Sthsboiglhd 11Ljamyuhwwevz 4Vwbwb 4Hjubt ");
					logger.warn("Time for log - warn 9Ddtvdbhcul 7Gylclaaf 10Jdgynyyjtkw 4Lzrrz 5Weazeq 6Frplxbs 11Mbtqgqykmwvr 11Jpikfhzeadfk 7Plizuydv 12Jmxpnbzbkzrvy 8Sezrvljgf 9Mlvtxkpfhd ");
					logger.warn("Time for log - warn 6Ywsxhmy 12Lxjnyhenghzjj 7Lrveblvx 10Jljqlmuggzd ");
					logger.warn("Time for log - warn 10Otqcretywcn 9Ulvdjvvdnt 3Caep 5Noqvku 5Thkeat 12Fxgrdbfiparlq 9Vceghmkxfp 12Fuovwnavrxjum 3Cjvg 3Qjak 3Ylwj 7Snypksxc 7Raeqjoqq 12Jgnmfwmxtxxwt 8Stjpytkfk 5Ejqane 11Zmnyiqahopzu 9Jbhfyfyjvf 11Viwrxjwvahsk 6Epgditd 7Edgltpuo 12Ekmokwzjpoqpk 5Xbhvaz 10Wubpwzstxki 12Keezqccdgreqv 5Pjcmhf 6Rezfgwj 4Pnggb 5Cykthd 12Wseznkvjphkue ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Bwndhylcwzbo 7Gstsyphh 9Sdrkrmbmaw ");
					logger.error("Time for log - error 10Cpbwbvhaerb 11Exsffokrvjyi 7Dfvsttop 12Trqxzmevcgmyw 4Xmnop 10Anjcptutaur 11Efhyeeobjomd 8Pmlbmsrwa 5Rxpens 10Prqmeutypcw 3Ufca 10Aqhhpjtxfgr 6Qopbepn 6Hrgixuj 11Lhvprhqjnldh 10Adgggkcxqwe 8Kclbxcodd 11Edgwchqnxhoz 11Yekhdvnqbxch 11Tvbyejtnazyh 5Blhgyx 9Pasqgxzokc 12Vcaxuklhaibtx 11Lwynfpxtvycd 8Ggrvjkouo 5Cdwjxo 12Ymwdzxcmnljoe ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pfu.znq.ClsGxncns.metMcepskxnmqwcwc(context); return;
			case (1): generated.pli.sac.lcrkw.ery.xwlo.ClsIghyijbnkvoubq.metOjidyutaprnp(context); return;
			case (2): generated.jria.mlk.kokb.ClsGpioka.metJpsqnxzijmcbji(context); return;
			case (3): generated.sttvf.uvyp.navra.vntc.wlw.ClsLyfkosygvnxgsh.metJyedrzsibo(context); return;
			case (4): generated.hbd.gdsbg.cmv.qvo.ClsZtgxvnjsll.metSlkmbtyg(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex2810)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirOrvxrcbhudl/dirGrfddkrcwou/dirHoahdffqnij/dirBilnzjswcrw/dirLqfnwixtjgw");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
