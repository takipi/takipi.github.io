package generated.jdhkq.nnb.eopx.xiteo;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsVoejnnonjnbn
{
	 public static final int classId = 131;
	 static final Logger logger = LoggerFactory.getLogger(ClsVoejnnonjnbn.class);

	public static void metDghubvohwq(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValMozfgdjszgu = new HashSet<Object>();
		Map<Object, Object> valKvuttacmxlt = new HashMap();
		long mapValAsxkfwumhbm = 5863048493655777335L;
		
		long mapKeyAkryuwcdfzv = 2616569746817736639L;
		
		valKvuttacmxlt.put("mapValAsxkfwumhbm","mapKeyAkryuwcdfzv" );
		
		mapValMozfgdjszgu.add(valKvuttacmxlt);
		Set<Object> valLgwrsunxhup = new HashSet<Object>();
		long valCjhmcmwhjpz = -569979089504791984L;
		
		valLgwrsunxhup.add(valCjhmcmwhjpz);
		boolean valGkmtsvsypcm = false;
		
		valLgwrsunxhup.add(valGkmtsvsypcm);
		
		mapValMozfgdjszgu.add(valLgwrsunxhup);
		
		Set<Object> mapKeyLuiglkaijtu = new HashSet<Object>();
		Map<Object, Object> valJcpddsxtefx = new HashMap();
		String mapValRfhcabzbsso = "StrPsmjtgwpfzt";
		
		long mapKeyYfbuyajzuul = -2908558974964236592L;
		
		valJcpddsxtefx.put("mapValRfhcabzbsso","mapKeyYfbuyajzuul" );
		boolean mapValZhrbrciscrr = true;
		
		long mapKeyIermxoehzio = 2830442750198082659L;
		
		valJcpddsxtefx.put("mapValZhrbrciscrr","mapKeyIermxoehzio" );
		
		mapKeyLuiglkaijtu.add(valJcpddsxtefx);
		List<Object> valBecyuorixwu = new LinkedList<Object>();
		String valWdleqkchcah = "StrRnrzczxmjem";
		
		valBecyuorixwu.add(valWdleqkchcah);
		
		mapKeyLuiglkaijtu.add(valBecyuorixwu);
		
		root.put("mapValMozfgdjszgu","mapKeyLuiglkaijtu" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Tejddrtkf 9Rndzdjjiga 8Iyiurbcdg 4Srfuy 9Nrumnkwcal 5Dkycfe 12Ambovugggbpzo 3Piez 4Tquxi 8Ascovregj 12Ltoexduvvgyli 7Kffdbfhp 8Pogirpilk 11Nksjcdppjyko 4Xusfi 9Yxmglbpwgm 11Ebzxvxceyjdt 9Aoedywudia 3Ygjz 10Ntuieujhrfq 11Qdwoagnjuoyk 8Qhexdtieh 6Pzdbavn 10Dmaqghmssvz 10Orraocgfpdl 9Gdknvzwegn ");
					logger.info("Time for log - info 5Irkvnx 7Fthddgpu 8Ynxazogee 7Tulufdlc 10Baigsbvzrmn 3Txpf 5Jsovfc 6Rmtwcav 3Rdbm 7Ycwsukrl 4Ewdzx 5Oajouo ");
					logger.info("Time for log - info 10Comwjctjzxu 3Zfoq 11Grhohqlbrocs 6Cncoplr 8Wdsmtvsev 7Gbmtfcog 4Fpkbm 5Gupupl ");
					logger.info("Time for log - info 10Ntxqbuylmtr 9Vqzbnorfna 10Vgymgbzbxgg 9Vyymmduuuu 9Tvntmugcba 8Rrtylmxkl 5Dsmqxz 4Rooqy 7Bactcddm 12Eldbejjothlqx 12Dczaoiwjifpnf 4Qhooc 9Uhxjxoplnm 5Qjjoje 10Zvlsqwzxmmg 10Fydkrqbwdle 5Soewig 11Fayzrgfytfqw 4Ttkgl 6Rqbzeth 5Rfxxgi 3Wfsl 10Bofqhuivgev 4Gnjmd ");
					logger.info("Time for log - info 5Qttujt 7Qpfvonaz 5Ngnmzv 4Pgevi 12Foaubtjblwczb 6Eadylap 3Oprs 10Jdgaoftnbbb 9Tuiujdbarv 8Ummnmpgzh 10Nygrxqrhtvj 3Nrfz 4Vaxqw 9Pifwljtesu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Cusygdpjijihc 11Ukuwvhgltzdp 12Kyqkorxjwiedi 5Xqpasq 3Otqn 7Roepukon 12Ookwkcsnywmpl 11Bpcricbddrzr 11Lpssvpnyessq 10Niqzphcmcpn 6Weqpspz 8Olybonlsu 5Cutjzm 9Wvljoskdiy 12Loazmzttzyeph 12Wphtcervwgobo 7Bnkzscty 12Cdjhmiswcchux ");
					logger.warn("Time for log - warn 3Wpvx 6Dzbdkia 11Ngufzqtmkgpx 6Ucspehi 6Exhezjx 11Scjoiorntmpy 7Taygoorc 5Czwyhj 10Yisskvuyeun 9Lpupuqfrdr 6Stmgccb 12Xoqjpaztzrweb 7Umkovihc 11Rpafwonqhgut 9Ptwtvtiksw 3Hosu 6Smuqxqf 3Thlb 12Syyvhsmdzaneq 12Piwvkggjkybmp 3Vaff 8Vtfdhcohu 11Tjtsbhesyuku 10Fxvjbvjfoep 12Ukbxhvtiizhwe ");
					logger.warn("Time for log - warn 6Xwwmgsq 4Mnzof 8Wdqibzvcw 10Fcbrdfkpins 4Eckmf 12Vgawqxurvnwjp 6Rchrqgp 12Tfdrunpihphhd 6Ykrnego 5Rkslwu 9Ocnmzeumbw 12Fcnniszqenmpw 3Uquu 5Gvppee 11Jretofhbjqwj 8Ukwcnzumn 10Ahynvmyvglh 5Oxwquj 4Dgqvi 12Yfcgifbiuqogi 3Ipfl 7Occncjjh 4Mvbmz 7Egmotate 11Bsaogtwktctb 10Dlzgfpfzusz 7Uydyottd 3Isew 4Bcuph ");
					logger.warn("Time for log - warn 8Hoycphaqe 8Hpodrqraa 5Qsnexx 3Ufqe 9Axzqqtbwvc 4Xzato 6Kuwladb 7Xeeqspsz 6Gbgobzm 12Ewuzpcfriudch 5Gscnzn 9Swnaxkmypc 11Xmeusxrmbcqj 4Vjyrj 8Ggejgfyoj 10Llxamfuiugk 5Mqavta 9Rehkazxivx 5Swhqvp 11Tmyftxfcgnwv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Xniqctf 8Kordclhbd 4Lxkfn 5Anpaed 12Uqhkctzpmmddi 4Lqfyx 6Wohpymf 8Mjcamdlgw 8Ntzbbyclf 5Zuwfrt 9Mtpivscbxk 8Uljtmsfzz 7Vbymzchy 10Osidsprkcuh 3Zffc 7Uiuxktxn ");
					logger.error("Time for log - error 8Jduehlddh 4Wztyw 10Xaxigbndmmu 5Nwopov 11Dfvvfafkljbu 5Wpvues 7Ihsupnne 7Kxzmxzri 12Mczyfunglchkc 12Ophwsruobqhlh 4Upkji 8Pqxyitnbc 7Jspirajv 5Vysnfn 12Gzfflxpsherrl 9Cafaafgjvu 9Mrbmqrcfad 8Fugwcmmac 11Wmibfndmvaid 6Ghgmaoo 8Nhubsxhpj 7Skxvjyrf 8Ukeytqner 7Glutqbtc 12Eusxbbxtoreex 3Plbb 11Bbbxbeacbspo 4Smslz 11Agnedlbuommf 5Lajijt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bywcf.xycgt.wqguo.ClsDsjomnr.metDdfotoep(context); return;
			case (1): generated.opcr.jgy.rftd.rkx.ClsJjouwg.metSumjtrup(context); return;
			case (2): generated.gxto.nwin.jagvj.ClsIsbtgkhpotpu.metArlow(context); return;
			case (3): generated.qrzc.frg.utv.itv.ClsGoyvsxo.metOllflngqrpzh(context); return;
			case (4): generated.laaxy.myh.ClsSglobn.metTagvcylidx(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numSzuukzsimuj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex22387)
			{
			}
			
		}
	}


	public static void metJpighvrrkvmknf(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valTjwjvncmmeu = new LinkedList<Object>();
		Object[] valXijtaisyoah = new Object[6];
		int valZisacmumlew = 631;
		
		    valXijtaisyoah[0] = valZisacmumlew;
		for (int i = 1; i < 6; i++)
		{
		    valXijtaisyoah[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valTjwjvncmmeu.add(valXijtaisyoah);
		
		root.add(valTjwjvncmmeu);
		Object[] valXnacpmawhds = new Object[11];
		Object[] valLqembbawath = new Object[9];
		String valBmcchmmlzdv = "StrPabnxfdsnvl";
		
		    valLqembbawath[0] = valBmcchmmlzdv;
		for (int i = 1; i < 9; i++)
		{
		    valLqembbawath[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valXnacpmawhds[0] = valLqembbawath;
		for (int i = 1; i < 11; i++)
		{
		    valXnacpmawhds[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valXnacpmawhds);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Uylmtidsp 6Hgkwefe 11Ezqiiauubxbx 12Kbcasuqqmmfyi 5Amvtgs 11Wmgpukiikwaf 12Prftqlpejszkw 10Bpienbjygcy 6Ectzber 9Pqyzegxvfk 10Uhiwlusyifx 3Pxyf 6Rtqraef 8Ezzxkjceg 3Eyzp 9Afluxltxwx 7Qsmhmfhk ");
					logger.info("Time for log - info 12Fodhwfvelrhbv 6Vktemga 7Qvjatkoz 4Avxhw 10Liqcqoxpslz 10Pixpscwcuyo 7Mnrfkvmn 5Spekno 9Pejhkbeaeq 4Deiab 7Mxagmkiq 4Jznot 9Fuulerkjgx 4Yjyus 8Uikhtmzdb 6Dfqikyj 11Cesclmzwiqfm 7Nzusyexe ");
					logger.info("Time for log - info 10Mxqoiewrmhz 4Wyysp 3Luyq 11Algjwrmkpgzd 11Hkkswytknhjm 9Azycasurih 5Xlwaxg 12Fakrlqhbftzyg 10Errtyvowtpi 3Kbyp 8Sfepzqqlr 3Taue 4Vgcfa 9Youkmlbmrm 5Ipkyfw 11Ftselxokuqpb 9Hubcccsvmy 7Sluzcvpo 11Giilxnyearbd 3Gprf 12Ogjpezvccqnlu 8Jhtifxtcj 9Mciiywqmth ");
					logger.info("Time for log - info 9Xzaxqoeqzc 12Ctteuajjzhlxv 9Aesppinxfv 12Txhdcgjzyszhp 12Llvsybcbuehxn 6Gijczkr 6Lcokhlu 12Ipfvyrugppiis 8Hpwjpjupz 4Hhowf 7Voabcyei 9Xvxkdiyblo 5Kqyphf 8Wgjiltxie 11Tgahzzknuoxi 11Fnaycqwiimlu 4Uwugl 4Nayuw 3Cbak 11Zfylorexlgwo 11Fbyiprlwjfke 6Hsqoolj 5Iprehc 9Ugbrfqwiun ");
					logger.info("Time for log - info 11Ucckttajssjn 7Vvnwzvtd 10Dcwkqxkwmjp 4Slklo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Wmnhextnwwzr 5Qiuyjp 11Mjaadqbrvmrb 12Fgturrheodzuj 7Tvpfqsxn 4Jvmxh 7Wmiaamyb 3Yteh 10Ajrkisvznjf 11Lnhsquxlafat 6Dvyqrka 5Qxxjdg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ctymn.uic.kza.ClsBochsrrjh.metGygnvmjatcdvgy(context); return;
			case (1): generated.vtvwz.yobg.lldg.auey.xwd.ClsDdnvjde.metHxwjgboi(context); return;
			case (2): generated.uym.yiu.voiig.deif.ClsUwvuontynja.metIvjieifumyhc(context); return;
			case (3): generated.kmvk.gapzv.hffa.xaqj.opr.ClsXtcqpna.metRbrfxbrd(context); return;
			case (4): generated.xbfov.nkh.ClsAkppmbind.metHtbkmz(context); return;
		}
				{
			if (((2998) - (8380) % 891362) == 0)
			{
				java.io.File file = new java.io.File("/dirAwxkhkvvnra");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(940) + 5) % 952639) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varXpnzivkzegz = (3671);
		}
	}

}
