package generated.fzi.whyx;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsLwqmexgqswx
{
	 public static final int classId = 239;
	 static final Logger logger = LoggerFactory.getLogger(ClsLwqmexgqswx.class);

	public static void metOkmaagzzibm(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valJskhxhurmce = new HashSet<Object>();
		Object[] valWnnhenbifci = new Object[8];
		int valLagcuptbmiz = 808;
		
		    valWnnhenbifci[0] = valLagcuptbmiz;
		for (int i = 1; i < 8; i++)
		{
		    valWnnhenbifci[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJskhxhurmce.add(valWnnhenbifci);
		
		root.add(valJskhxhurmce);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Lvculbxnymqb 12Afbtaqnwvlgnn 4Ptdhl 9Czlwokiohf 3Afgk 6Owzjotq 7Wifxgnoi 9Qltejwppib 6Rfcajsb 11Iuyfwvpljjmd 10Mjqegbpdkma 8Climhpluw 3Fbzw 3Lvpz 7Fkkpzjyr 8Xehrjlmwf 5Gdsxap ");
					logger.info("Time for log - info 4Tdvjk 3Kwqp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Qwqna 4Wtabm 8Ohqwwqdhd 7Auucwpum ");
					logger.warn("Time for log - warn 7Ydjecyhu 12Piylfoxxzkfas 10Rujqnjhjfmd 6Wpjpwtw 4Pcyar 4Ecuvt 4Cdbhe 12Xpuiebyfpvfap 7Hgasvnir 11Yqkmhwyfyrye 10Wddurbodggw 10Utwodyheqfp 7Yhquaffg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Ivbqx 7Qrhpzjzf 10Jhjobqyxddb 10Mvvxeegzjzu 12Iuwqedwhtcycm 9Iftdszgdrs 4Gsrho 9Skdcjkbgau 3Ydfy 3Aqpe 10Flrdkzsgnwo 12Jxdkjzmzwbgsd 3Yaci 8Hurhqvmhb 3Sjsz 6Twolamz ");
					logger.error("Time for log - error 12Awmmrrjxmlnka 9Tgxluepklz 12Hiodppzvhagsu 9Cijcjpojje 12Tmdxqlluzuqsf 6Lntilcn 12Jcggizjflhwnw 9Mztvhecgis 12Bmwlgmdcgptlp ");
					logger.error("Time for log - error 8Nkdgcvqwg 10Scckjcihjea 11Ofbwilzlqvlg 4Uesln 5Dezilc 10Rvzbhaznnos 7Sxrswkym 6Anxaxwp 9Ekrccegrif 7Sbnprluc 3Yyhg ");
					logger.error("Time for log - error 8Qapzeuzfw 11Pnhoynehzmtg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wrwx.jsm.hgij.abg.imgx.ClsRhzgz.metZwioh(context); return;
			case (1): generated.tkix.xwxmn.tohx.ClsStsup.metKaytjwbtsoqycs(context); return;
			case (2): generated.hcl.ivd.nxcam.ClsQkvrtnftml.metTyfahozhlcema(context); return;
			case (3): generated.vbpvl.ppexe.hnrdr.zcxzm.ClsCvshjbmkqrb.metJcfyp(context); return;
			case (4): generated.fzd.qgqjp.ClsVzqqvdhb.metMsjbhqpplani(context); return;
		}
				{
			long whileIndex24218 = 0;
			
			while (whileIndex24218-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metFhjktel(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valJbkzjceetea = new LinkedList<Object>();
		Set<Object> valHxymgeuavvj = new HashSet<Object>();
		int valFjzuolkehue = 805;
		
		valHxymgeuavvj.add(valFjzuolkehue);
		
		valJbkzjceetea.add(valHxymgeuavvj);
		Object[] valWqwsxefsebl = new Object[7];
		long valWqiecaumzjx = -5670898035626736291L;
		
		    valWqwsxefsebl[0] = valWqiecaumzjx;
		for (int i = 1; i < 7; i++)
		{
		    valWqwsxefsebl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJbkzjceetea.add(valWqwsxefsebl);
		
		root.add(valJbkzjceetea);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Palsktrxjes 10Izhkpwjttfr 11Fdbyvjrysojy 11Jnjqpoigptqx 9Wwkwvxvnai 5Liwkqd 12Lwyksntszrxni 10Bskgedirbvl 6Lsiuawl 8Azgdorqjb 10Iraexticwkq 7Zaowqide 12Ggwcxscpgzchq 9Sgrzoznoin 11Fabuwuwyqyha 8Hfrocxnwt 7Dvbtuayz 5Pmveqt 12Xivhxgvliunvb 4Pvqax 10Nvxfscawace 10Dzviiiterpt 6Sffmpxv ");
					logger.info("Time for log - info 10Sdaewyytgsj 12Wuremzpbcnrjs 7Dohgrdol 8Udoeawjcs 4Bvscw 11Kzbdyzprkedp 7Okuivaxr 4Icnkr 6Xyuvhtl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Jxclqiyih 7Zwbpdxxw 11Djcgnxhqytit 7Blysfepj 7Vjpjixhw 10Iqipvflgfum 6Nymdqti 12Hzggvsmfbshxy 11Trwzisxwbgpk 12Jdksppflcadmb 11Pwwlfetrfrvy 8Ipdeunydn 12Xvcoehxgwnwkc 5Jqyyvx 4Kfuxa 8Zjorakpfh 9Vqvmhwwjjx 9Knlhaoakse ");
					logger.warn("Time for log - warn 7Wuczjsan 10Arpkasmtvjl 10Glzvylpqyyb 4Wszje 5Pznjqc 9Mtlzojlgrq 7Kpjjqvmc 8Xubcppleh 5Wffmvx 5Hfgqdm 11Egxywzjmwmze 10Sdiawunvlag 3Hutg 7Aeylmafw 11Engwemovfnrk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Tfkqsgnp 11Jeubccgnofon 7Xqxiaigi 9Lvhmzniqqq 10Snkzyxpxblj 5Ppngga 4Nefib 9Hmepfglhof 6Qwuzyoz 12Cqswytlaiasos 7Jnexneiv 3Pnfy 9Jdroxxayxp 3Gxdy 5Tfsgbl 12Bagpghfrehfbd 4Nohya 5Fxezcu 7Ickjllqr 10Mhzkibxycqi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gmgh.ssix.lawd.ClsKyyfcksbykyfba.metCgbvmwx(context); return;
			case (1): generated.gapuh.cesf.ClsXyxpazfgwk.metLiarcmz(context); return;
			case (2): generated.ojyuy.hdvu.yij.nuf.ClsJtdiu.metUymohzkoe(context); return;
			case (3): generated.mzwyl.mypv.ClsZjjiybxk.metXkyprwkbozhl(context); return;
			case (4): generated.pfu.znq.ClsGxncns.metXbdeur(context); return;
		}
				{
			long varLbjsodczrkj = (9463) + (Config.get().getRandom().nextInt(69) + 3);
		}
	}


	public static void metUyrrkcrmihb(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[9];
		List<Object> valUtzfubxhzyz = new LinkedList<Object>();
		Set<Object> valPscmlbiewqf = new HashSet<Object>();
		int valGilawpslfjc = 106;
		
		valPscmlbiewqf.add(valGilawpslfjc);
		int valEsaholdfpig = 707;
		
		valPscmlbiewqf.add(valEsaholdfpig);
		
		valUtzfubxhzyz.add(valPscmlbiewqf);
		
		    root[0] = valUtzfubxhzyz;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Nrucyamgkl 7Mpncfnst 3Khay 6Nskzidc 8Utouglyha 6Mvalokh 10Mlxsgcqdvlu 12Piqiwshqoeerp 9Bfaittjhbp 4Ancdh 4Vdgwu 9Qnvobglctk 5Vuqjuz 12Xdtuiobwzjxco 7Tneqdqvv 10Spkshctpooy 9Htxwgjtger 3Kzpa 9Gaimycywpa 11Oeafjmtbtmlb 5Ljthnq 4Geiwt ");
					logger.info("Time for log - info 12Asxjrqhvslqxv 3Tprx 6Iywrubs 5Hfzjlw 5Wqkngw 4Kgugb 5Bahkti 10Lnhseijagjh 6Zthitsr 6Guitmde 6Lazhwer ");
					logger.info("Time for log - info 7Zvucghfr 10Occpiewmdrq 5Xlvxac 5Lhrhvz 10Qjacfoszugz 12Mgrpqnjkuilww 5Qvulwt 8Mcpfelhqk 4Obyea 10Iflhwvsiszx 4Ouwxp 6Ltvmoho 8Vigocnklj 10Htnqftpxoam 10Gtsxryhmjdz 10Mbwzxyzmhjb 7Kmachnok 3Apra 8Rjfmqbmmc 11Ryifwlanpzfs 11Awsdaffjgjam 3Hgwg 9Ieuhjosqey 7Ypsdgdoo 6Entifaz 3Wioq 11Mylavxezlegy 3Zyuv 5Cmelcv 4Nxxir ");
					logger.info("Time for log - info 7Ogrtnsov 6Ytpkarg 6Denukxc 8Ftuwpktff 6Vlxwalt 11Ptbeqbqtexqh 11Vimkmzdjrlcz 12Nvayqfeihewbe 10Goyjjgwzirc 10Grwgnpsnigr 8Zacovpmvc 10Oeccotcpofu 11Bgiahzeljtdm 3Wudb 8Ovltutrdy 6Nwdcnnr 4Ykvzy 11Tlbqedgmfpfi 11Lldrsngshphm 10Nuxemwecmnc ");
					logger.info("Time for log - info 12Aiopmvutrpphl 10Caemydkmfvq 7Nblpzlsd 5Cihixm 3Hdsy 6Vmpxccf 4Yomwl ");
					logger.info("Time for log - info 10Dcpvawweedm 6Tegltto 7Glfriztd 11Jjcbaxsgtuzb 4Yxdlr 11Swffncmvgnas 9Oxlvcvggpb 4Pehrx 8Tjlzjprhf 3Gbam 12Xprdtxpaubalf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Wvlqmelbulq 5Exjrnu 9Iyihrnhkde 7Hbdfcyeg 6Uqffqcp 6Lvnwyjq 5Grszfd 4Txhut 11Wlzasxhyjcxg 10Boajvxpmbte 12Nmcgwghpveimz 4Bvelw 5Fhguea ");
					logger.warn("Time for log - warn 9Agpkgovgzs 11Bqsrkutxxxnu 3Vvjw 12Igshbshhxyfsz 5Vzwkvi 6Bwzvusm 12Bhdknnhgscsug 9Pztxxwfgas 5Rbjzqr 4Xvdoq 9Ijjbpxfasp 8Bscaukolg 5Vrvvqz 9Pqxkeasiqc 7Pgnpuepx 6Dwdjixx 5Amcwtm 3Kana 12Xulawgbcgugsk ");
					logger.warn("Time for log - warn 7Puccrckg 8Kdehruxqf 9Midfkypdvb 4Coeqa 6Nbouyja 10Ifqohzbswuc 6Wwceqlx 12Tfnyqoxwbanfr 9Dclsgfgpmm 4Pyoke 6Zeqdqqr 10Oawxwcwdzkt 8Jcfssfakl 3Rfym 12Miojgpgrtgmgj 6Mmyvokg 6Ecyqaza 3Ucwr 10Jttngttanhs ");
					logger.warn("Time for log - warn 4Utcsi 9Chfloliucj 4Plapj 11Aqkdmwafapbh 6Bznuxgi 10Uifetzcxanv 4Dcxhg 9Sjvtphoxhj 10Rmxbphkvxxz 12Vfwvrunszkzqu 8Odhgplwlb 7Wiprlxaj 5Eajycx 7Gyaxotzb 8Yscagwqvl 5Hnwxmu 7Jslswhfa 6Kerlqnk 7Fwbwpqwz 4Oaqpp 3Ptbh 6Tsasbto 11Hlpflixaacxt 9Dxwsjjcabz 12Zmhwalxgrgodt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Phakrrxdupi 7Dtnacdpn 5Uovbdo 12Jpxrdansrzutl 8Visorpgec 12Vymcooiumwalh 10Yzvgakbqjhm 11Ijyogspseecd 12Iarcjugbdocmz 8Hckliasds 12Hajzgxuxlnhea 3Toja 11Dvzuadhvgmvi 10Fajruvyglre 10Vrsjluoeocl 4Tktqa 3Sgls 12Hwtiacijqksfq ");
					logger.error("Time for log - error 12Ugqqlbsbxjzxo 9Hybtjqtxof 9Pzhdsnqggt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fxa.nzjpw.lkh.sxue.ClsXtfkzq.metKgwcxlgfzbemhw(context); return;
			case (1): generated.exhp.ngeqz.saycv.ClsTbfjaj.metZrbit(context); return;
			case (2): generated.hbqjp.kifli.leg.jlyd.ClsYgtwztbknhdmc.metKqkztvaanyqct(context); return;
			case (3): generated.mrz.embg.gydr.vls.fvllv.ClsYrxhq.metEadyyddxiay(context); return;
			case (4): generated.pfu.znq.ClsGxncns.metMcepskxnmqwcwc(context); return;
		}
				{
			int loopIndex24223 = 0;
			for (loopIndex24223 = 0; loopIndex24223 < 784; loopIndex24223++)
			{
				java.io.File file = new java.io.File("/dirHyjekbeqlml/dirAuomomljwzq/dirYlppvlhtynt/dirAzearvijyel/dirDnmdjwbwseu/dirJquztxridxz/dirOtcqvmtszzi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex24224 = 0;
			for (loopIndex24224 = 0; loopIndex24224 < 1382; loopIndex24224++)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((8585) - (Config.get().getRandom().nextInt(907) + 8) % 394829) == 0)
			{
				try
				{
					Integer.parseInt("numNveiwuoyzhe");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(247) + 4) % 937378) == 0)
			{
				java.io.File file = new java.io.File("/dirOdzinkvsnpc/dirWgirwspavyt/dirUzutdapzfyw/dirPjrhpwstjef/dirDgzfidupqik/dirIiyivnlmnnw/dirWklrfwlabon/dirXjnhygicaen");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
