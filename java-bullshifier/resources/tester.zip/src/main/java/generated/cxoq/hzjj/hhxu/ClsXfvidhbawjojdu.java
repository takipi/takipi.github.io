package generated.cxoq.hzjj.hhxu;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsXfvidhbawjojdu
{
	 public static final int classId = 35;
	 static final Logger logger = LoggerFactory.getLogger(ClsXfvidhbawjojdu.class);

	public static void metGjokxistgrq(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValDhyzrcanvhc = new HashMap();
		Set<Object> mapValNmrxwchytoh = new HashSet<Object>();
		int valJmufekwcfnm = 296;
		
		mapValNmrxwchytoh.add(valJmufekwcfnm);
		int valNowwllkbxhg = 338;
		
		mapValNmrxwchytoh.add(valNowwllkbxhg);
		
		Map<Object, Object> mapKeyDlcvnxtjizu = new HashMap();
		String mapValWolbjkhxwbx = "StrSjbkbukwmzw";
		
		int mapKeyRohfewyrnjs = 927;
		
		mapKeyDlcvnxtjizu.put("mapValWolbjkhxwbx","mapKeyRohfewyrnjs" );
		
		mapValDhyzrcanvhc.put("mapValNmrxwchytoh","mapKeyDlcvnxtjizu" );
		
		Map<Object, Object> mapKeyBkolryisyke = new HashMap();
		Object[] mapValJuppqibjgqf = new Object[8];
		int valXdukqehdncw = 342;
		
		    mapValJuppqibjgqf[0] = valXdukqehdncw;
		for (int i = 1; i < 8; i++)
		{
		    mapValJuppqibjgqf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyZnexgqkzeid = new LinkedList<Object>();
		boolean valTeimsukznrc = true;
		
		mapKeyZnexgqkzeid.add(valTeimsukznrc);
		
		mapKeyBkolryisyke.put("mapValJuppqibjgqf","mapKeyZnexgqkzeid" );
		
		root.put("mapValDhyzrcanvhc","mapKeyBkolryisyke" );
		List<Object> mapValHtrtacocxnq = new LinkedList<Object>();
		Map<Object, Object> valMfpgqrypane = new HashMap();
		int mapValHowslkmdxmg = 771;
		
		String mapKeyXknzflhnpbu = "StrDnjbfdghvmp";
		
		valMfpgqrypane.put("mapValHowslkmdxmg","mapKeyXknzflhnpbu" );
		
		mapValHtrtacocxnq.add(valMfpgqrypane);
		Set<Object> valQkgauiduwrr = new HashSet<Object>();
		boolean valKgqlwzoaudk = true;
		
		valQkgauiduwrr.add(valKgqlwzoaudk);
		
		mapValHtrtacocxnq.add(valQkgauiduwrr);
		
		Set<Object> mapKeyUgfijbpbvtw = new HashSet<Object>();
		Set<Object> valUlefjydyrdm = new HashSet<Object>();
		boolean valYvzwjqqwipk = false;
		
		valUlefjydyrdm.add(valYvzwjqqwipk);
		boolean valLrcuyufzeeg = false;
		
		valUlefjydyrdm.add(valLrcuyufzeeg);
		
		mapKeyUgfijbpbvtw.add(valUlefjydyrdm);
		Object[] valRtdlmewdmmy = new Object[4];
		String valWdeuyomzbrw = "StrPgcbuqepnzf";
		
		    valRtdlmewdmmy[0] = valWdeuyomzbrw;
		for (int i = 1; i < 4; i++)
		{
		    valRtdlmewdmmy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyUgfijbpbvtw.add(valRtdlmewdmmy);
		
		root.put("mapValHtrtacocxnq","mapKeyUgfijbpbvtw" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Igfvzktz 4Cxcnv 12Lgliyyshnewdj 12Fsghehwiqttrm 4Ojdus 9Mvenzmknpo 8Pahwepvju 3Ypwb 4Hjelk 9Qjmmqahclt 3Bumn ");
					logger.info("Time for log - info 9Kevygeliyf 12Xjeksgxddgphd 8Mrrhbbgkm 11Brrhqbqyacfy 12Cbcruxbpsyuax 12Xnvezvongahkf 11Myjiehoaczaw 9Lgvxzrynok 9Mexudxrpto 9Codsumvprq 9Pqvoeeslbb 11Mtdjqspqtylk 10Cwtdrzxlfhj ");
					logger.info("Time for log - info 10Gyzabaofpok 11Hpomaheubwsz 7Eecxfljq 10Osgtabwflql 4Cuhaw 8Qhzlxqaha 9Dpagcfstix 11Jahyaakpriro 3Ntvs 3Eqch 12Kqgtlmfyhqrxo 7Necwhzlk 5Ugocnc ");
					logger.info("Time for log - info 10Kaajeyebffa 10Gzmcymdfmwf 7Ymierckg 3Yojg 8Nnwdghyua 12Dxqybqhjbzdqk 7Pivifllv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Vciaykudfd 10Taeilbdqjji 4Unnrb 6Mrghsvb 5Dlzsql 8Tltbdwddz ");
					logger.warn("Time for log - warn 6Aetmzdc 9Ckiibiqfbu 7Axrnpxog 4Tkqwb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hrks.gbo.qgg.fgvtm.ClsHtrpxdwwowcxea.metDgjcrvmdu(context); return;
			case (1): generated.uwqq.rznca.ubddn.auo.ClsOkthnaihqahfl.metLmnxqvpe(context); return;
			case (2): generated.zsia.unbq.ozcif.caj.yiysy.ClsRbxlkiybibs.metDwuywtpaislqn(context); return;
			case (3): generated.vqli.xqs.ist.rcg.ClsUlfrrjkk.metUracnapyxnrd(context); return;
			case (4): generated.qrzc.frg.utv.itv.ClsGoyvsxo.metLdwaocfgpjot(context); return;
		}
				{
			long whileIndex2618 = 0;
			
			while (whileIndex2618-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((726) % 745213) == 0)
			{
				try
				{
					Integer.parseInt("numMfurqvcmttz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(923) + 4) % 68927) == 0)
			{
				try
				{
					Integer.parseInt("numAksbtnsjviy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metOcgmhat(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valEllucarqmqf = new HashSet<Object>();
		Set<Object> valInnbwxhguhg = new HashSet<Object>();
		long valIlavyasnvnr = -5089110306985694330L;
		
		valInnbwxhguhg.add(valIlavyasnvnr);
		boolean valIwerposkske = true;
		
		valInnbwxhguhg.add(valIwerposkske);
		
		valEllucarqmqf.add(valInnbwxhguhg);
		
		root.add(valEllucarqmqf);
		List<Object> valPtnmttmoxmh = new LinkedList<Object>();
		Object[] valImefztkjwrq = new Object[4];
		String valSxyksptharj = "StrCkbyxfkzvzv";
		
		    valImefztkjwrq[0] = valSxyksptharj;
		for (int i = 1; i < 4; i++)
		{
		    valImefztkjwrq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valPtnmttmoxmh.add(valImefztkjwrq);
		Map<Object, Object> valLethrupvcik = new HashMap();
		boolean mapValJrxyhddlcnu = true;
		
		int mapKeyQpobnkigwov = 616;
		
		valLethrupvcik.put("mapValJrxyhddlcnu","mapKeyQpobnkigwov" );
		
		valPtnmttmoxmh.add(valLethrupvcik);
		
		root.add(valPtnmttmoxmh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Kafp 10Ftzfhlthhuo 5Srwhdk 9Xshtrllmig 12Uxueyuhlbqcol 5Iszdfb 3Vovg ");
					logger.info("Time for log - info 11Pwnkefgfvzoq 3Ycxc 8Dwjsasktg 9Coyjplslyb 5Zhbwyh 8Vkrmwanxh 8Mjqrmpwmk 11Alolpqppzyxj 6Faxwqsg 11Bmewjhzhplxm 8Aeztrjfzy 10Hghffdtxpkz 10Iqwuqhbatlz 11Gfwuonzlaafn 12Ukoautrratbmi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Jegcsijy 9Olyvzbvzem 10Twufgpcbprd 3Lvoq 12Piedvrvrkxvgq 3Vgqx 9Drxjidvhyh 8Kggoqvnno 11Avvjavoixkji 6Accroyl 11Txijyljtlfmp 4Irmpc 9Bwkdvphhps 12Apjhrztabevnq 11Afofsvrafezn 3Mytv 4Xmoiz 8Zduqkanmj 5Erdnpw 10Lwoykmgoowr 7Wwtjqkba 12Lkgdtgqycploc 6Lfynlnl 10Knxviipnjxv 3Czhs 4Gfqub ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.eedk.kvsj.tzabg.tqpy.ClsBuuqqzvjfxdiao.metOjmuclkrr(context); return;
			case (1): generated.avme.rnc.ClsUgqeozcqx.metIsegbgah(context); return;
			case (2): generated.pema.ddj.ssuh.ClsIlinaijnkxxo.metUxznbuacrrpc(context); return;
			case (3): generated.ado.osup.ClsKlojrrjbtxsxbb.metVtywqndsf(context); return;
			case (4): generated.yvbmb.hnmr.uqxw.ClsYomdrwntzuxawb.metAeacazp(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex2628)
			{
			}
			
		}
	}

}
