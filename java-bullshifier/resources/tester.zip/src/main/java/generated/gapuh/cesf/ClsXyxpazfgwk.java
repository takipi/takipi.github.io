package generated.gapuh.cesf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsXyxpazfgwk
{
	 public static final int classId = 299;
	 static final Logger logger = LoggerFactory.getLogger(ClsXyxpazfgwk.class);

	public static void metLiarcmz(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValThpxvzetpgm = new HashSet<Object>();
		Object[] valIbouetsvhma = new Object[5];
		long valYfliufshtgj = 3855771837878140625L;
		
		    valIbouetsvhma[0] = valYfliufshtgj;
		for (int i = 1; i < 5; i++)
		{
		    valIbouetsvhma[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValThpxvzetpgm.add(valIbouetsvhma);
		
		List<Object> mapKeyDjaujwfpwho = new LinkedList<Object>();
		List<Object> valYthdmslfnkg = new LinkedList<Object>();
		String valEkvjtcendpp = "StrUmfjntgzhob";
		
		valYthdmslfnkg.add(valEkvjtcendpp);
		String valZraadejtphe = "StrDizbnujiwxj";
		
		valYthdmslfnkg.add(valZraadejtphe);
		
		mapKeyDjaujwfpwho.add(valYthdmslfnkg);
		Map<Object, Object> valZxuynhjepci = new HashMap();
		String mapValHaejfvihojc = "StrUosnquighje";
		
		boolean mapKeyOtmuzfewglv = true;
		
		valZxuynhjepci.put("mapValHaejfvihojc","mapKeyOtmuzfewglv" );
		
		mapKeyDjaujwfpwho.add(valZxuynhjepci);
		
		root.put("mapValThpxvzetpgm","mapKeyDjaujwfpwho" );
		List<Object> mapValOruoxrsarfk = new LinkedList<Object>();
		Map<Object, Object> valEokjcazrvgf = new HashMap();
		boolean mapValTbztnzppibw = false;
		
		boolean mapKeyYrjyczlmfzu = true;
		
		valEokjcazrvgf.put("mapValTbztnzppibw","mapKeyYrjyczlmfzu" );
		
		mapValOruoxrsarfk.add(valEokjcazrvgf);
		Map<Object, Object> valBmfskwthjim = new HashMap();
		int mapValSkscskwjqjr = 65;
		
		boolean mapKeyAoiuekqfaat = false;
		
		valBmfskwthjim.put("mapValSkscskwjqjr","mapKeyAoiuekqfaat" );
		
		mapValOruoxrsarfk.add(valBmfskwthjim);
		
		Set<Object> mapKeyYeolnkywqgb = new HashSet<Object>();
		Object[] valFwkzqpaftnv = new Object[8];
		boolean valJvirmbzqpbh = true;
		
		    valFwkzqpaftnv[0] = valJvirmbzqpbh;
		for (int i = 1; i < 8; i++)
		{
		    valFwkzqpaftnv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyYeolnkywqgb.add(valFwkzqpaftnv);
		List<Object> valImdansqwxrl = new LinkedList<Object>();
		int valWrcxdlrtzxx = 18;
		
		valImdansqwxrl.add(valWrcxdlrtzxx);
		
		mapKeyYeolnkywqgb.add(valImdansqwxrl);
		
		root.put("mapValOruoxrsarfk","mapKeyYeolnkywqgb" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Xzscvifq 11Dtacdzrtjfzt 9Owqkfevuwn 5Uztcmq 9Jocfpofnxj 9Lpszekqwvx 3Agsw 4Wxcyg 8Wrhwtgkmf 7Xwopsfgw 11Bgogbamgsvpm 11Lrbqhniynzjn 8Tkrhopqar 7Spcfibdh 7Vprctlkj 3Hrxt 3Hweu 11Jxbztpgrbygk 6Wmnfcmk 4Exvqd ");
					logger.info("Time for log - info 11Kzagwaeuuaet 10Sbwqifcmvze 12Gnjyezwszculz 5Rqqiqt 8Gzcuaazno 7Bjhveevi 7Iserhejw 10Ghkrsjzjmko 7Wpnynzza 11Wzzrprdlhrjn 9Tuowehwyma 12Agqgauajavuve 4Hebdk 8Avmjkqcgf 3Ezts 3Utip 4Owvdv 10Bxjcaxwkfpc 10Orqaqlaoyma 6Mribapl 3Rfzt 7Sdwvvefn 12Gubgqgtiaxasn 4Cmahi ");
					logger.info("Time for log - info 7Ukbkanbp 11Wknhjrgcrktb 4Xktsm ");
					logger.info("Time for log - info 10Ohqwrjiavbi 9Mjgfnxurdi 10Himzbdliccl 4Yljuo 11Dlrbznqyqvhk 8Kgiaphbho 5Brjwto 7Mqgmtmib 3Ovxm 6Uhovkzw 10Ttcvvycptix 9Awaokygjwz 9Dtyqykienw 11Hopddzjbgdba 7Sajploji 12Rvcpbmhiidkfo 7Jodmmzvc 6Eohwtpb ");
					logger.info("Time for log - info 8Feaeaprrz 3Gjzv 3Heui 7Wvbhonvt 7Btwzjjdb 11Cyzapqhhyhhh 11Goosrlffbkwf 7Edqicpgg 9Hgvukjiekt 3Bamd 12Tzqbdovglmejs 4Cgavl 3Eyfw 11Cuxsampmjuzh 10Wwyvjuktqmg 4Ojcwq ");
					logger.info("Time for log - info 10Yccaksaslky 8Mrvntahqm 6Imomonx 3Bekv 12Xqcjozxaolfjg 8Tuwtxacgy 5Ukchvz 9Xmwnazfvhf 12Bjaidjgapdvgs 11Wlbtmsnlekky 10Oyosrcsqctv 11Nevfmwuqgyze 4Bbcdm 9Wymdgebxaf 10Xxkwfoawjpm 11Ibviuycobvdl 8Xaajawftq 11Irpsmbzydifc 9Nbcddkktcz 11Atorjnmslaqe 4Dzxky ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Ephawqnz 10Hjkwphfgipv 4Lkiqx 5Jksglm 12Kvijrgxzgpqey 12Avrjetmifusuc 6Qygidfd 12Fhcimpoappnug 6Xwttzik 9Mjexzuwpzq 5Swxjib 3Ghaz 4Wxhxp 7Itoautnq 4Ljhzm 6Gttvzbb 12Ccudcaysvrifg 4Wvxac ");
					logger.warn("Time for log - warn 8Sebqkwgbi 12Sgqfsrcersrwq 3Azlx 3Uhsk 10Hpccrqfkkim ");
					logger.warn("Time for log - warn 5Opzvxa 5Txgzrk 5Hqkapb ");
					logger.warn("Time for log - warn 8Vzbjgsohz 5Dwahkc 8Ihljnymmz 12Ykjyemlcizlni 7Wqqhjjvd 9Qwfxvqoeyj 9Esfcqegatp 12Hzougodjdrmyk 8Giycbngis 7Xqbejxvq 7Nxxrrpqf 10Ddkoqctiiul 8Hynrwmoev 12Rdqchwhlpummj 7Gumfcnhz 9Njdbrczsrk 12Pctsigiuzgjwl 4Levfm 7Usxvtfcd 11Xnjbedautxmf 8Gruqihonp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tbf.qnyk.tdd.dnbuc.fexg.ClsFiknxpviyjlxbx.metSjlzkmra(context); return;
			case (1): generated.flvo.tuwfx.wlpxx.jysnd.tuk.ClsFuuvt.metYllionx(context); return;
			case (2): generated.wkonu.vce.nspm.ClsXupklxzgrjs.metGhpwtlnnq(context); return;
			case (3): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metQfyhues(context); return;
			case (4): generated.hkyc.tzi.ClsYwknearnl.metPahqec(context); return;
		}
				{
			long whileIndex25089 = 0;
			
			while (whileIndex25089-- > 0)
			{
				java.io.File file = new java.io.File("/dirXhqwthteygr/dirCcgnkncmaex/dirEdljfokxfaq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex25090 = 0;
			for (loopIndex25090 = 0; loopIndex25090 < 410; loopIndex25090++)
			{
				try
				{
					Integer.parseInt("numEjgrrvgialu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex25091 = 0;
			
			while (whileIndex25091-- > 0)
			{
				try
				{
					Integer.parseInt("numFbhkneqljei");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metNunfetlxuqsy(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValMxfcwwnbnab = new LinkedList<Object>();
		Map<Object, Object> valBehowxizvel = new HashMap();
		boolean mapValProbxxkzfao = false;
		
		long mapKeyOqprvbyyuxe = -326732351647002695L;
		
		valBehowxizvel.put("mapValProbxxkzfao","mapKeyOqprvbyyuxe" );
		int mapValOantphagycv = 32;
		
		long mapKeyOrhldanynap = 5179948923547071907L;
		
		valBehowxizvel.put("mapValOantphagycv","mapKeyOrhldanynap" );
		
		mapValMxfcwwnbnab.add(valBehowxizvel);
		
		List<Object> mapKeyGomwlyhhnkv = new LinkedList<Object>();
		Object[] valIesauficxsx = new Object[10];
		boolean valHcbbnyzvetz = false;
		
		    valIesauficxsx[0] = valHcbbnyzvetz;
		for (int i = 1; i < 10; i++)
		{
		    valIesauficxsx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyGomwlyhhnkv.add(valIesauficxsx);
		
		root.put("mapValMxfcwwnbnab","mapKeyGomwlyhhnkv" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Yfmsdazb 4Tgfiv 5Nfyluq 8Rximzkpip 3Xrsn 9Olzbfudbpx 12Pchetvtqqqdqq 10Ydlqgyljsup 3Vulz 4Sigwg 5Cqkamg 12Zblypeivtsxqe 5Wkrlro 10Cjlhnwewtpv 3Jthy 9Iwbipyzwql 7Ballgfeg 11Njfljavgejib 6Jrinzlv 6Cuspejm 6Sooxnik ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Zdueu 3Dihe 10Kxtvprkbmob 7Koxeuwwb 5Pzdtnu 8Xtcqmcsao 8Evvokkeum 10Uavsaosaauh 3Mjrl 10Lgelumkxpkd 10Luqgdtoumrz 6Pdgowjo 11Tnflnvnyrhrn 8Ozfnqryac 11Alfeqlzyncro 9Yuxukzxuix 10Mgioczgivlx 5Zduxiq 5Ypgaov 7Uzbddlwu 3Fvdk 11Qtkvdirsngxh 4Gxvkn 7Ezcpskwk 3Zigx 7Fsdvanrm 7Kosefcza 7Yqcyxytc 5Btdinw 4Guvqh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Nioowpbjssg 7Llfvilwb 8Comanyshz 10Njzbjlelrlw 3Ttwn 5Arbssj 6Tximvbw 9Kdesgoshco 5Nbscgk 3Hnyk 12Uhapbwgrcnwej 3Lvcc 7Tluwqyfk 4Tamkb 9Rmcqyqyobt 4Unjjn 10Ujawxkbqwuz 9Scwzwkmueu 6Ttxnmea 10Xtkwmnssmzy 4Udkll ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hcdlq.enxjq.kqzt.pmk.vuc.ClsMdkbzdmkjxcf.metOfbbjymp(context); return;
			case (1): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metWzqrqrjxhdrs(context); return;
			case (2): generated.bde.vdlp.frn.zsrjp.eqwxd.ClsMvedn.metBrdejrtmmvqjyb(context); return;
			case (3): generated.wspiu.cmqv.pvdxy.isdgi.ljwn.ClsZpnvzubxm.metRztaj(context); return;
			case (4): generated.ncx.nab.ijte.fihzp.ClsYfnojfmzyj.metDgypcmpwyxb(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirNsmhtmkkqmm/dirLwhezorpseg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((3435) * (392) % 187981) == 0)
			{
				java.io.File file = new java.io.File("/dirTbguaatkcjr/dirKrorjzjavhi/dirGqskzekeixq/dirLergjyesxxb/dirZmnjpzoxxqq/dirUzoshuuaunt/dirNhbzvrqmdqw");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((9921) - (Config.get().getRandom().nextInt(294) + 2) % 679597) == 0)
			{
				try
				{
					Integer.parseInt("numVrsmfhrqnin");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex25098 = 0;
			for (loopIndex25098 = 0; loopIndex25098 < 6256; loopIndex25098++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
