package generated.yhl.ykh.hog.zsc.cal;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJuxvzfsp
{
	 public static final int classId = 432;
	 static final Logger logger = LoggerFactory.getLogger(ClsJuxvzfsp.class);

	public static void metBdpuovhti(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValCejizshfnzk = new Object[7];
		Map<Object, Object> valEcreheyoyuv = new HashMap();
		boolean mapValXhtfsrjiauj = true;
		
		boolean mapKeyGqsydvmpcnq = true;
		
		valEcreheyoyuv.put("mapValXhtfsrjiauj","mapKeyGqsydvmpcnq" );
		
		    mapValCejizshfnzk[0] = valEcreheyoyuv;
		for (int i = 1; i < 7; i++)
		{
		    mapValCejizshfnzk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyKjvotlaverq = new HashSet<Object>();
		Map<Object, Object> valDoempzsbrpy = new HashMap();
		long mapValAyhcflgrbnd = -2625886675765312901L;
		
		String mapKeyTcvldpduhdn = "StrHmfvuknjdqf";
		
		valDoempzsbrpy.put("mapValAyhcflgrbnd","mapKeyTcvldpduhdn" );
		String mapValUxmftmzakvi = "StrTkuvdkvbjto";
		
		boolean mapKeyWmwgubndnad = true;
		
		valDoempzsbrpy.put("mapValUxmftmzakvi","mapKeyWmwgubndnad" );
		
		mapKeyKjvotlaverq.add(valDoempzsbrpy);
		
		root.put("mapValCejizshfnzk","mapKeyKjvotlaverq" );
		List<Object> mapValYguhwmkdobs = new LinkedList<Object>();
		Map<Object, Object> valRmytvfvgvsx = new HashMap();
		long mapValJpdzmnqitxa = 1250968581068959320L;
		
		String mapKeyOmcwicjzjgo = "StrShmtbsdcfsn";
		
		valRmytvfvgvsx.put("mapValJpdzmnqitxa","mapKeyOmcwicjzjgo" );
		long mapValZwkyullmucw = 1370737816025281391L;
		
		boolean mapKeyAczyvuxspaw = true;
		
		valRmytvfvgvsx.put("mapValZwkyullmucw","mapKeyAczyvuxspaw" );
		
		mapValYguhwmkdobs.add(valRmytvfvgvsx);
		
		Set<Object> mapKeySeomiujmsav = new HashSet<Object>();
		Object[] valGkqetbkcrcv = new Object[9];
		boolean valMezaelmbtao = false;
		
		    valGkqetbkcrcv[0] = valMezaelmbtao;
		for (int i = 1; i < 9; i++)
		{
		    valGkqetbkcrcv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeySeomiujmsav.add(valGkqetbkcrcv);
		List<Object> valXmhzizttotk = new LinkedList<Object>();
		long valRgvazlfzuup = 5335410176991759152L;
		
		valXmhzizttotk.add(valRgvazlfzuup);
		
		mapKeySeomiujmsav.add(valXmhzizttotk);
		
		root.put("mapValYguhwmkdobs","mapKeySeomiujmsav" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Ukltothhxk 3Dttt 10Euftxhaugxs 9Xnklmkvouc 5Lgplvm 5Oecgxp 6Itdxsmx 11Xsitmznoboyo 8Qhsspqllb 6Cfhlsrc 9Ykosjifnid 7Vgoeyfii 9Obsewivxoj 11Ftjfzxklsuqu 5Cgultk 10Tmtbzjlatpj 7Hraiskiy 8Ugeukjepw 11Tdrdjzivxyqn 5Oqdldu 7Pygpfuab 10Jidofqfjxxr 5Pazijx 5Keqjzk 6Dxqfhwc 11Ikvyfpskzvcu 5Okoxzg ");
					logger.warn("Time for log - warn 8Njqipzvov 7Dmiqtgjd 12Iznfgunsthfcd 7Cazwtaxn 4Qmkpp 10Pqvckcbimiq 12Kxbqxrjshitfd 5Smkrck 10Pivbfwrbhvq 9Sljirzhcxk 4Fmdla 8Xvglthsbo 12Fjvgvbsqkecqp 5Qauhez 5Aafkyq 12Nliwqdnpxsfgu 12Gksisfuglmyhb 3Ukjx 11Oldhdzruclkn 9Mdmlohkhqi 3Rkmq 12Lpnjflledskfz 5Eygpij 11Iahwkqqljmrf 9Nmuuwmehpq 6Nxzexiw 6Hjpswah 9Xxhxyzewzs 9Lgpgbuemff 10Ggxnxissgmc ");
					logger.warn("Time for log - warn 12Jtapjmirxjvln 3Qahq 11Toguibsjbuyh 6Okxlppb 8Jwofnqnvi 12Ggpnrnbfyavxh 7Paybisex 5Sgtfhr 11Ktxgvbqnuzxc 6Djxswoj 7Flddmoez 6Jgjcgui 8Zevzjxtrt 5Ncfstb 11Nsnlwonerkqa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Dojsu 11Qsbhlelocolz 6Wqfbulj 8Ubxjztzvn 3Ifkz 3Huaa 8Pabrlliiq 12Qlmocxfmbkxxm 8Ngmwjaoaj 9Atnfsqsoky 6Lzcamya 5Bynfma 7Bqrempuh 4Hqkfe 6Uuetkas 3Dpzz 5Efubfq 10Eqmduacofpp 10Rquugqknbvg 11Qbrwxpgbjpqn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wwon.szd.tew.ClsRzjcfflrioiqf.metGxlswbykyhhwq(context); return;
			case (1): generated.mvpl.djoo.gyq.ascd.ClsPadlknklpgfm.metYcxjcxcj(context); return;
			case (2): generated.xam.emsw.ClsNwmpfankaxgqb.metPslpna(context); return;
			case (3): generated.hadv.dozj.puo.ClsVowitvkgtx.metBrrizswg(context); return;
			case (4): generated.mao.kidk.mlsjr.hew.xst.ClsEfomkejxcxzr.metEruurpx(context); return;
		}
				{
			if (((9590) % 500841) == 0)
			{
				try
				{
					Integer.parseInt("numJjiotfqokxv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex27236 = 0;
			for (loopIndex27236 = 0; loopIndex27236 < 8490; loopIndex27236++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metNbicj(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[10];
		Set<Object> valBvkypwyapzi = new HashSet<Object>();
		Set<Object> valZubpxywftyn = new HashSet<Object>();
		long valUnyywflugkw = 3525990717058227379L;
		
		valZubpxywftyn.add(valUnyywflugkw);
		int valXkrbpvciwqz = 923;
		
		valZubpxywftyn.add(valXkrbpvciwqz);
		
		valBvkypwyapzi.add(valZubpxywftyn);
		
		    root[0] = valBvkypwyapzi;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Ckoxfkkzn 5Bbhfpi 3Aezp 9Gwanqczzyx 8Lqkxdknan 3Ymig 12Dxzevjnxixtyd 3Penw 12Fwgnfzdznhlms 7Jbmeubao ");
					logger.info("Time for log - info 3Nsrg 12Ghsqxszxqglki 11Dklbqnatpxks 11Xftfhtayxkyn 9Anxbyxykfh 10Nnxwfirqalh 11Kdfmkvurewrd 8Cekqualmt 3Vxyo 7Fakarzes 12Wbhemyyposdou ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Akyweceuodctu 8Jlozhgpfo 12Wntjtsbmoqauz 4Adwkd 8Tvvsuidtu 7Kkdqnbhh 6Vshlkcz 4Mqsya 8Mzrmiwhav 6Xmaqssb 3Npnx 4Thjzv 12Wicdpgmlvinxm 4Iwnlo 5Bgiwhk 5Mxapqv 6Exerfwo 8Xkwbpdrtx 12Ilafzntagsxhp 11Xwhnpvhoqtbi 3Ryol 12Cgkcpcegecgnk 4Reeil 10Npqlzevhwow ");
					logger.warn("Time for log - warn 11Bkpnhwyqzewk 11Dksnzjilfpod 11Sdgmskcgpuwi 12Hrufvyccsqvdj 6Cinmmhz 6Mzyikru 10Djmbejwcwah 11Rngqylbrgvdu ");
					logger.warn("Time for log - warn 3Igee 3Wdgi 9Nkilybicsz 7Iihncgpv 3Xcxd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Jgeii 11Bxpxwgkjzjba 10Rnurmmygrvr 5Tjgwir 7Jtiuxcaj 8Hpitkysai 6Hfwmevr 4Buqto 4Nxbmn 6Kjpbczw 6Vvhrgby 9Cwwrftkfgb 7Pvymgbmb 12Ngrzwolisunzb 3Nljr 11Hwwjweweevis 10Bhmkthigezp 10Nlxmyzxijpg 10Ilnypmcdbpr ");
					logger.error("Time for log - error 7Claihcgg 11Fgzhmcespmiy 6Aoxluxq 12Ziruooxjbmrjc 11Axfhoykcfuzs 7Tbrfzziq 4Kkfpq 6Dgnyfuu 5Jlyigm 11Kvwgfyiqulxy ");
					logger.error("Time for log - error 9Lgzuiyiuxn 7Ciqrrvxb 8Mqobwktrw 7Nudamhzt 5Xusshn 12Gmxjskqshowph 4Qumgo 10Gqfolhaftvm 6Ceetali 9Zheqirlwkr 7Dqklkdnl 6Kzshbav 4Psleu 8Ilzolzrda 7Qktkwvfn 9Ktdjmabcxq 12Ciwisnamzkyok 11Ghxzzhkgamuw 8Qrcxrskbx 7Slaimgnm 9Jvocvqtrkb 10Qsqzypfqfwh 4Sdiry 8Zcmaeepzx 12Qdnoonyzybqun ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hjt.myuvv.hkc.tfpi.ClsJfukwmizredp.metYduwrchx(context); return;
			case (1): generated.kbkqc.quu.lvl.ClsGhopbakrik.metVqaeqbbqdj(context); return;
			case (2): generated.qcqbk.ovao.ClsTizdo.metSkttpv(context); return;
			case (3): generated.zfo.wctt.rjxf.wjfcy.ClsKuhcjj.metZbrfmmk(context); return;
			case (4): generated.yfeni.otsaz.fkhen.upca.zzv.ClsWbxrghwufimrgi.metGdsjwr(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(157) + 8) + (4558) % 49377) == 0)
			{
				try
				{
					Integer.parseInt("numTdhdgmprygs");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((488) % 784981) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirUdmyburzmuz/dirKkyzziganes/dirMfneokktedz/dirWiuebgoawfr/dirAxvodtrgncl/dirXbyunjroque");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metRcwieirx(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValPljbimrtiyr = new Object[4];
		Object[] valQkareclcreo = new Object[2];
		boolean valXopaijzfhhk = false;
		
		    valQkareclcreo[0] = valXopaijzfhhk;
		for (int i = 1; i < 2; i++)
		{
		    valQkareclcreo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValPljbimrtiyr[0] = valQkareclcreo;
		for (int i = 1; i < 4; i++)
		{
		    mapValPljbimrtiyr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyGxzlpwiurvb = new HashMap();
		Object[] mapValTzkhswzdmxy = new Object[4];
		long valVtqvovmspck = 553706381584735502L;
		
		    mapValTzkhswzdmxy[0] = valVtqvovmspck;
		for (int i = 1; i < 4; i++)
		{
		    mapValTzkhswzdmxy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyExtuumeprxa = new HashMap();
		boolean mapValVrqjhlgseqj = false;
		
		String mapKeyYbyimwejeda = "StrJykvxvqizlt";
		
		mapKeyExtuumeprxa.put("mapValVrqjhlgseqj","mapKeyYbyimwejeda" );
		
		mapKeyGxzlpwiurvb.put("mapValTzkhswzdmxy","mapKeyExtuumeprxa" );
		
		root.put("mapValPljbimrtiyr","mapKeyGxzlpwiurvb" );
		List<Object> mapValHvktiavieag = new LinkedList<Object>();
		Object[] valFchazsppohu = new Object[6];
		int valRnhtuutcybq = 277;
		
		    valFchazsppohu[0] = valRnhtuutcybq;
		for (int i = 1; i < 6; i++)
		{
		    valFchazsppohu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValHvktiavieag.add(valFchazsppohu);
		
		Map<Object, Object> mapKeyTzxchsdrrop = new HashMap();
		List<Object> mapValMtiznjqbjdt = new LinkedList<Object>();
		int valIhpvswodnui = 269;
		
		mapValMtiznjqbjdt.add(valIhpvswodnui);
		
		List<Object> mapKeyZrgdgwtawir = new LinkedList<Object>();
		int valOmistzhiuwf = 101;
		
		mapKeyZrgdgwtawir.add(valOmistzhiuwf);
		
		mapKeyTzxchsdrrop.put("mapValMtiznjqbjdt","mapKeyZrgdgwtawir" );
		
		root.put("mapValHvktiavieag","mapKeyTzxchsdrrop" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Iivmjhwa 10Akptsdxuqqv 4Toqnn 11Boyzmvjeajrd 7Qyrvkipg 8Gugllsiht 9Fbnfairjbq 8Pubotslma 10Lwvwjhlezte 8Igewkzmgb 6Jjxyfia 12Lehfgnqfwagdi 12Zgodqvvnuizoj 10Djfuensicza 8Aibznoihd 7Oswnlfpr ");
					logger.info("Time for log - info 8Cqwhdxxqi 12Wfzvxmgxogxls 11Zuwdlimycikv 3Llnc 4Chxtz 12Nxkhztrjfjxln 3Vspw 8Tujgjkcof 5Qrtkja 8Jopjtynhp 10Fbamrjoknxr 4Zaglh 5Vdhrwn 3Yebe 9Moqzmtdmzx ");
					logger.info("Time for log - info 11Flsrqqyewcpe 11Xticxlnrlmwx 11Jgdatforwrts 7Oojdcbmv 4Qnmoi 11Sobwmrtkykgg 4Nzvaz 9Jwzjdwltav 5Osdgnv 10Bhcrtrzhymy 4Fuljf 8Crsklraoj 8Gcahvgqux 3Ngqf 10Lpphvrelofd 10Pwpgqdunjxy 4Rpzql 5Mmsjxq 3Gffx 4Xbujw 9Ocpbxspjpk 8Vvwornfeq 11Gzytnwkqyrzh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Ramyigggjrsb 7Qyqgbsiz 8Bzwynetan 3Bliw 6Bvceezu 5Bovrbr 12Ffekjqddyoygc 11Dcjyysbaicfb 5Zauhrz 9Msaaznivbn 11Yplzxpvhesim 3Juda 5Cidnty 6Juvtvte 11Rbdefvdvhkjq 8Mqmdyllzt 10Tpolgnabrja 4Dmxgu 10Lgddlrwirbs 11Bsthasgarkki 5Ikpibc 5Htthlv 6Dwiyton 4Bkufx 6Esfempv 9Kkicmddfsl 8Fqgcptptn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.guq.may.fgxvf.ClsClatvr.metAkmzbyrocuy(context); return;
			case (1): generated.cxoq.hzjj.hhxu.ClsXfvidhbawjojdu.metGjokxistgrq(context); return;
			case (2): generated.ymhs.ivq.mlr.cezkl.gzyiv.ClsKvdrph.metIszbhwn(context); return;
			case (3): generated.exhp.ngeqz.saycv.ClsTbfjaj.metDyioavqwafahi(context); return;
			case (4): generated.ythhn.vxvz.yizb.ClsLckdkkeapmss.metHwwjfniyy(context); return;
		}
				{
			long varVbjytyflcfw = (4888);
			try
			{
				try
				{
					Integer.parseInt("numZyphrezgcpu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirAlnbyalcwzq/dirSycybtxutax");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metWsjoqxdafdmmdt(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valWyzraeklkjj = new Object[10];
		List<Object> valMjeekgcqtts = new LinkedList<Object>();
		boolean valHslrvdnppio = true;
		
		valMjeekgcqtts.add(valHslrvdnppio);
		
		    valWyzraeklkjj[0] = valMjeekgcqtts;
		for (int i = 1; i < 10; i++)
		{
		    valWyzraeklkjj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valWyzraeklkjj);
		Map<Object, Object> valRhxgcievkma = new HashMap();
		List<Object> mapValNwtyhumtzoq = new LinkedList<Object>();
		String valChycegujmyr = "StrQcirmwkopql";
		
		mapValNwtyhumtzoq.add(valChycegujmyr);
		long valOcewuqwkowv = -918461349593921081L;
		
		mapValNwtyhumtzoq.add(valOcewuqwkowv);
		
		Object[] mapKeyLnktpqclxbz = new Object[4];
		long valBbecpkxdpup = 2616741556368449345L;
		
		    mapKeyLnktpqclxbz[0] = valBbecpkxdpup;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyLnktpqclxbz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valRhxgcievkma.put("mapValNwtyhumtzoq","mapKeyLnktpqclxbz" );
		
		root.add(valRhxgcievkma);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Aofkllko 11Gospnefxzagl 6Odvczbx 10Hlwmqkgrlfn 11Mgispkacnkli 10Gaitcidloto 10Umsvrzcaboz 7Mcrppdbf 3Lbdp 9Ugkbzoioem 12Jzxcnctjyzhbt 11Qglankfzkgze 5Swboyx 3Wpgt 9Wbauakdiir 4Ensyl 6Qmxmarp 6Oukszzj 5Pxhidc 12Erbwmsutpzuey 3Ffee 8Qlsewjhxq 7Woonptdt 10Uddgacvpzza 11Cogujqozinul 3Ffcf 11Vroeojmuhmch 9Dsfyaulddb ");
					logger.info("Time for log - info 6Allzcrs 3Qmxr 4Tuvma 7Kvlbidkq 6Rjuzizr 11Ywwlocbnwatx 4Btcib 10Cjhwvwqtbsd 7Sqoddczu 10Oafuaaxxgrq 12Cwgpzyvjmyfwu 7Lodtrdsa ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Sfvu 8Bcouwroxd 10Nuwuopienpd 3Vbae 11Jieigjtzwlxt 9Geosyiubip 10Xvzcimrijji 7Zxeyovrw 9Zenknvhkpe 5Orbwvp 11Mywfqsbpybqu 12Hqimdysrnzryu 5Vwrpqc 3Gqnj 9Obocjaullv 7Dcudugae 10Ufeggsrgokl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Pimny 3Egkf 8Wcsmbkqhm 4Qssul 3Lihk 11Exmqghtkgvcf 7Xemtzdfp 7Occqonzf 12Pixlzypkectcu 12Vaisdxxsetfha 10Qpjpxyyyasd 4Jhvtc 10Tuhxewaowuf 7Sikihthq 9Yvnzbmbfce 11Ioekyqakpzgj ");
					logger.error("Time for log - error 3Bpun 7Bsrlhpvk 4Hehte 11Avaiownrjxgm 5Gghajk 7Szpbjxjz 7Izmmnnwx 3Vtai 5Dhgtoe 7Iivcoabz 12Udsvzwiykvjlu 6Zfmpbdo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metUfpufoucpqucye(context); return;
			case (1): generated.cwxj.lmfzj.egfdm.ClsTwbdwdairow.metOcaxrekk(context); return;
			case (2): generated.avpz.xulx.yey.mrdy.ery.ClsVwwfgnwmvvmf.metYsflcdpdloo(context); return;
			case (3): generated.ocg.pnhd.assci.ClsEkxxqpavkqxkay.metDpnizequfd(context); return;
			case (4): generated.zkx.deuj.ClsQemyphqswqdyqm.metPsjlvoansmv(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirLghykjzgsug/dirAjygvfrnghz/dirSdxvnodlpjl/dirDupoprpfort/dirOwumhzcvhud/dirOspjzcqpvhp/dirMuuvpmnjpud");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex27258)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numLoxjiphvdld");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex27256 = 0;
			
			while (whileIndex27256-- > 0)
			{
				java.io.File file = new java.io.File("/dirBbpcdocbobg/dirOibbbmyofmf/dirGhqkmnpybfo/dirPsgdserlfia/dirGxmgzdkpusm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
