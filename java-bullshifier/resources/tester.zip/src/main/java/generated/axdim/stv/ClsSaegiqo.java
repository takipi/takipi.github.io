package generated.axdim.stv;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsSaegiqo
{
	 public static final int classId = 237;
	 static final Logger logger = LoggerFactory.getLogger(ClsSaegiqo.class);

	public static void metKmdsuvjx(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValJsiagbnquth = new HashMap();
		List<Object> mapValVutilkixgbw = new LinkedList<Object>();
		int valZwdbsulajxk = 651;
		
		mapValVutilkixgbw.add(valZwdbsulajxk);
		boolean valSxennnhnnxe = false;
		
		mapValVutilkixgbw.add(valSxennnhnnxe);
		
		Set<Object> mapKeyAbdjgnenhlo = new HashSet<Object>();
		String valXvnvfkevnmx = "StrLjwrimvnfun";
		
		mapKeyAbdjgnenhlo.add(valXvnvfkevnmx);
		boolean valWhoffrvnamg = false;
		
		mapKeyAbdjgnenhlo.add(valWhoffrvnamg);
		
		mapValJsiagbnquth.put("mapValVutilkixgbw","mapKeyAbdjgnenhlo" );
		Set<Object> mapValFttaxlfpmob = new HashSet<Object>();
		String valNpxcagukhzk = "StrGqtxznctbgt";
		
		mapValFttaxlfpmob.add(valNpxcagukhzk);
		
		Map<Object, Object> mapKeyEahcsmpvreh = new HashMap();
		long mapValLfnpgeuytbp = 1212133243780455537L;
		
		long mapKeyKtcqiewrcxl = -7531109577304035077L;
		
		mapKeyEahcsmpvreh.put("mapValLfnpgeuytbp","mapKeyKtcqiewrcxl" );
		long mapValTeptjzmlikb = -1098932446452613434L;
		
		boolean mapKeyHigpsrgqvhl = false;
		
		mapKeyEahcsmpvreh.put("mapValTeptjzmlikb","mapKeyHigpsrgqvhl" );
		
		mapValJsiagbnquth.put("mapValFttaxlfpmob","mapKeyEahcsmpvreh" );
		
		Map<Object, Object> mapKeyRqnxqbkkfdk = new HashMap();
		Set<Object> mapValMbqmflollqf = new HashSet<Object>();
		String valVofbsrzvwco = "StrKzliyzukbhh";
		
		mapValMbqmflollqf.add(valVofbsrzvwco);
		
		Map<Object, Object> mapKeyBwknfxfjhei = new HashMap();
		String mapValLzjbbouxwiz = "StrCphmpdzlopj";
		
		String mapKeyHjosqgwhwog = "StrXpjawzgspwd";
		
		mapKeyBwknfxfjhei.put("mapValLzjbbouxwiz","mapKeyHjosqgwhwog" );
		boolean mapValQrcqprallxy = false;
		
		long mapKeyInhiuuhsynk = -5600694186835666249L;
		
		mapKeyBwknfxfjhei.put("mapValQrcqprallxy","mapKeyInhiuuhsynk" );
		
		mapKeyRqnxqbkkfdk.put("mapValMbqmflollqf","mapKeyBwknfxfjhei" );
		Map<Object, Object> mapValAilejxahjus = new HashMap();
		String mapValQcsxztqqexo = "StrQfigqnjxtuv";
		
		String mapKeyBbjljsccanp = "StrZbrrwlbvyzq";
		
		mapValAilejxahjus.put("mapValQcsxztqqexo","mapKeyBbjljsccanp" );
		String mapValLuzbkhlfuwj = "StrTboflwqgrfa";
		
		String mapKeyCxwwipgqjcb = "StrCmkzrklgwro";
		
		mapValAilejxahjus.put("mapValLuzbkhlfuwj","mapKeyCxwwipgqjcb" );
		
		Object[] mapKeyWtyskjmrthb = new Object[9];
		int valEyqszygubnm = 470;
		
		    mapKeyWtyskjmrthb[0] = valEyqszygubnm;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyWtyskjmrthb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyRqnxqbkkfdk.put("mapValAilejxahjus","mapKeyWtyskjmrthb" );
		
		root.put("mapValJsiagbnquth","mapKeyRqnxqbkkfdk" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Mzayhpjjjow 5Odwhyo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Sehv 6Ewtzuuh 10Kswhoflcrmv 10Okmbifbbfdc 7Cnshhzis 11Dmqumdebabwr 12Ptaozounejfcc 10Jcrrfytdjbm 7Tdgxqksn 6Eielsps ");
					logger.warn("Time for log - warn 10Dxmuvnfddos 6Wakpvhi 8Kvpphiuzh 8Hsskpxuls 11Bivyajfpmpns 9Jljauzdmjb 3Vrtv 11Sbxohoiiknsr 6Kqimfbv 6Msbffav 5Fmnqyj 12Suzuugqrrbpmd 11Tdmeohotabsm 7Pmchhlul 11Dyinmeckjikw 11Pfplsyqtrwoj 11Ddaqxpxlqfwa 12Gsczlytrfepkn 10Bswgkcmejtm 8Lyoycwsfj 11Wcbwqayrddzm 12Uqbblbdxwksfy 9Yrirapqbiv 6Cpjlfxd 4Dwvdu 4Pekyb 12Eepdmkxuyjwlq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Fmoaksadvkot 9Zivfvojiiy 5Eyccfs 12Uacqgykkcurlb 5Yrjqzj 4Nuinf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.munb.ijbed.gztfl.ClsHbtirm.metPhueixmhj(context); return;
			case (1): generated.ldtgt.vdfx.cdz.lkx.ClsLvvwnymti.metFkrjypkkw(context); return;
			case (2): generated.kfjp.bzn.mda.sfyxf.ClsAguszlzt.metWsvlopnliexx(context); return;
			case (3): generated.mvrs.ywr.ahvi.avyw.whash.ClsQifjwldjrqu.metOmmhlelmwob(context); return;
			case (4): generated.tjsh.wlc.kyb.psqfd.qzhn.ClsOhdwrykfu.metDqdnyemypbugl(context); return;
		}
				{
			if (((5298) % 593552) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex24208 = 0;
			for (loopIndex24208 = 0; loopIndex24208 < 2845; loopIndex24208++)
			{
				java.io.File file = new java.io.File("/dirUehahedwpts/dirWogwjbizvsl/dirHsqbxnmvpcg/dirSlupixocqnn/dirZjlydwuecxf/dirQxalqbhtpzc/dirEmrsfuefsnx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metVwtuv(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValClkpyakfowg = new LinkedList<Object>();
		Object[] valPgnagvhsolf = new Object[10];
		long valAnhdgrbtwpc = 5360162856241314450L;
		
		    valPgnagvhsolf[0] = valAnhdgrbtwpc;
		for (int i = 1; i < 10; i++)
		{
		    valPgnagvhsolf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValClkpyakfowg.add(valPgnagvhsolf);
		
		Set<Object> mapKeyWnzsfifguym = new HashSet<Object>();
		Map<Object, Object> valDaimqdudhwp = new HashMap();
		boolean mapValBryfleornoa = true;
		
		String mapKeyXsmrypbowrn = "StrStzrcrjwfxm";
		
		valDaimqdudhwp.put("mapValBryfleornoa","mapKeyXsmrypbowrn" );
		
		mapKeyWnzsfifguym.add(valDaimqdudhwp);
		List<Object> valIyiolyrorsh = new LinkedList<Object>();
		String valPjisdtihkhr = "StrWasrjvmnpmk";
		
		valIyiolyrorsh.add(valPjisdtihkhr);
		long valOtcldfbmfob = 4763376508881529091L;
		
		valIyiolyrorsh.add(valOtcldfbmfob);
		
		mapKeyWnzsfifguym.add(valIyiolyrorsh);
		
		root.put("mapValClkpyakfowg","mapKeyWnzsfifguym" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Crijzfnus 8Icuopykxo 4Kubfb 11Vazkembrvlrq 11Mywzacqnxkkk 8Eruszacvi 12Dhmdnelngzjfq 3Vtks 3Yykw 9Bovnoxsfhj 9Dzyjuglvvq 11Mistjycokyzy 7Iowpwjtj 3Jfnn 9Zkdhwndelw 7Edebnovn 9Ebngzebhvu 7Uwnqbbrr 9Qhjaqznofv 4Jztkh 4Qwvpc 10Pwwptkqearq 11Ahzcyvksnvbw ");
					logger.info("Time for log - info 6Ffapsqp 4Cntiy 4Jlkrk 3Mujz 7Tibxcxkr 9Utlpwxrpof 12Pozfspjmpkzei 8Lxotayurd 5Ketfni 12Irdcwfmsftkkt 10Eebuarwroij 8Myvbtljvm 7Ddvfpthl 3Xlbv 12Kgmdilxiqpgvd 3Xobm 10Thhvdotgmhp 7Lcmyedkk 8Suwzjkjzl 8Bxagzkcxi 12Jcbitvpqtrphh 5Uuwlzc 8Staukymdn 10Spdqziqjguo ");
					logger.info("Time for log - info 3Ijit 10Pmocljgssfc 6Cbbrfnf 7Bodiyrhy 11Jnezsyngqyou 5Uawure 11Skrtkbarziwv 11Kzbdfuybgmgz 8Iuhuotbrk 5Yktdph 6Mmuwvuf 8Vkcnmjftl 6Bhglfyx 3Otum 3Fcbb 7Xmubazqd 11Wzvxgstfxdnd 8Sgnlbyosh 6Ttahxlu 7Epebbwlf 9Yiybxjibyz 11Tdpjtmizrona 7Zoqxfxgf 6Vcosfdg 7Lzehpdqr 3Ycmt 5Qoqvav 4Anhqe ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Apvacvhrqdjh 10Iuevdwaxfvh 3Bqvt 9Zwklsalupg 4Wrcqa 11Iphakjthljix ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rnr.pwsrq.cbi.tat.ClsQsqavl.metNujgqvqobxeyw(context); return;
			case (1): generated.vhk.matvp.xpri.ClsIidoitanl.metGxvhrbomkawxu(context); return;
			case (2): generated.nmwme.qnfne.zsgam.zytf.yqrto.ClsDkqpghfzzf.metFtplshpnymzm(context); return;
			case (3): generated.lvnhk.isns.uksl.tjjfx.ClsEfuazouhb.metZyecchsshso(context); return;
			case (4): generated.jria.mlk.kokb.ClsGpioka.metMvndkc(context); return;
		}
				{
			long whileIndex24212 = 0;
			
			while (whileIndex24212-- > 0)
			{
				try
				{
					Integer.parseInt("numEobhzwvlwwf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varWxgsxjhiqvg = (3177);
		}
	}

}
