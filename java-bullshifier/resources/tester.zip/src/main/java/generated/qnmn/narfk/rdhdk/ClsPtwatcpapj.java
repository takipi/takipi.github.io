package generated.qnmn.narfk.rdhdk;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsPtwatcpapj
{
	 public static final int classId = 4;
	 static final Logger logger = LoggerFactory.getLogger(ClsPtwatcpapj.class);

	public static void metSoquexyw(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[8];
		Set<Object> valAlcxehwopnu = new HashSet<Object>();
		Set<Object> valUwkmwznbfri = new HashSet<Object>();
		long valHttyzhgfigv = 4717575739174072819L;
		
		valUwkmwznbfri.add(valHttyzhgfigv);
		
		valAlcxehwopnu.add(valUwkmwznbfri);
		Object[] valHxdakblihbo = new Object[6];
		String valJdzozybevev = "StrZvbxjukyhri";
		
		    valHxdakblihbo[0] = valJdzozybevev;
		for (int i = 1; i < 6; i++)
		{
		    valHxdakblihbo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valAlcxehwopnu.add(valHxdakblihbo);
		
		    root[0] = valAlcxehwopnu;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Vxtlnnjonqmwq 6Dzrwhsy 7Todobikz 8Gwtngrcwk 7Wdrxmrko 7Kzutimqm 9Csfddlqecc 9Pmuntsufxu 7Itxikiav ");
					logger.info("Time for log - info 11Vkkpbulwlqac 12Qattabhnunbay 8Fsbiwdhwe 3Byhe 10Qozvrcurvjy 5Gvnubi 10Dqqlvethfxl 3Ucel 7Sabtvcti 5Xyvkcn 7Ugxeepbe 12Iutukhxvxxtnn 11Pbujicltdldk 12Gbhfhrovouypq 12Axqptfzgbcqzj 9Sdofalwahe 6Vvsamba 4Htbpk 7Fdkwpdab 6Acohobz 6Uawmkhc 9Brmloyukny 8Jkquxmhgk 9Ojlztrwieq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pef.kybz.yzpf.dzs.obqpv.ClsKizvnatyigi.metVpeqkkprfd(context); return;
			case (1): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metOebzatkpa(context); return;
			case (2): generated.avpz.xulx.yey.mrdy.ery.ClsVwwfgnwmvvmf.metHfphp(context); return;
			case (3): generated.rzy.sppai.eju.hupq.ClsPjendhgbojpy.metFwrqhbjeaj(context); return;
			case (4): generated.fpa.lsm.ClsOulug.metXlljtomhuljxyd(context); return;
		}
				{
			int loopIndex244 = 0;
			for (loopIndex244 = 0; loopIndex244 < 1775; loopIndex244++)
			{
				java.io.File file = new java.io.File("/dirTkvkusrwkbu/dirUgqikmxetzr/dirBznwaoylyzg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((2833) % 612647) == 0)
			{
				java.io.File file = new java.io.File("/dirEgsixnjpkjs/dirZqktbpvgpcf/dirHglttrywbuq/dirLdbhcaagewv/dirKmezeormlgk/dirYjflrrptdzd/dirEqaiebiwhwv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metAlhpjsfvu(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valKbcazlhzhwe = new Object[7];
		Set<Object> valGlkrhnqgiuh = new HashSet<Object>();
		int valFtxweyoyuio = 702;
		
		valGlkrhnqgiuh.add(valFtxweyoyuio);
		long valIwofzdchobl = -2821151624907010241L;
		
		valGlkrhnqgiuh.add(valIwofzdchobl);
		
		    valKbcazlhzhwe[0] = valGlkrhnqgiuh;
		for (int i = 1; i < 7; i++)
		{
		    valKbcazlhzhwe[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valKbcazlhzhwe);
		Set<Object> valUazjyzsuipz = new HashSet<Object>();
		List<Object> valBxidnvchycl = new LinkedList<Object>();
		String valZzndxstyyhu = "StrApecrauzqzi";
		
		valBxidnvchycl.add(valZzndxstyyhu);
		long valHyzyqbsifhi = 4379367958538556754L;
		
		valBxidnvchycl.add(valHyzyqbsifhi);
		
		valUazjyzsuipz.add(valBxidnvchycl);
		Map<Object, Object> valQefcomspicm = new HashMap();
		long mapValFyicfiguysm = 5542430421591522661L;
		
		long mapKeyQxjlbkivwmn = 9038199562835782223L;
		
		valQefcomspicm.put("mapValFyicfiguysm","mapKeyQxjlbkivwmn" );
		String mapValPlvbfuvlqcp = "StrMznocifesdu";
		
		long mapKeyBzajqonngnj = -1278350622241759677L;
		
		valQefcomspicm.put("mapValPlvbfuvlqcp","mapKeyBzajqonngnj" );
		
		valUazjyzsuipz.add(valQefcomspicm);
		
		root.add(valUazjyzsuipz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Dciwguvx 9Zufplxqqhj 4Avjio 11Trwgpruxdhsi 6Ngdhkfl 9Tpwrokypgt 5Ytufom 7Jmomhuex 4Cunbf 4Kwudz 3Mdqm 9Meozgygovy 6Zxfdphq 6Sjrgiou 11Cmsxsmllzslx 3Tpyi 6Okhisov 4Gbyhj 9Ffitlxveyz 6Ehanngt 3Hkjv 5Beolja 5Jwfgbp 12Yytwgftkkehkb 10Qrlfibmachy 10Vduomafvfan ");
					logger.info("Time for log - info 11Frfzkaktnjvd 5Msydgq 3Rfnu 11Cibjdfylqacb 3Zjss 5Bbewqp 10Hnuitnfzyiy 10Cegdqodycwi 6Dvdklvm 9Rmdfjpiohe 5Ocyehg 3Vgyf 12Rcmbmmzgryujw 12Trmnpixucwfau 10Wwinhdtgfaw 4Cacza 3Uxdk 11Vlggxmpdkidn 12Kmtgumyggdxpj 4Vlpgf 8Xjspknyef 4Igzhp 11Uvsbrdkxnhgi 7Pynpldwl 9Adiupihmmy 3Goet 12Xehywdergyvzj 6Lzujmlr 6Jlsikum ");
					logger.info("Time for log - info 10Flsefsilcgm 9Qinebclhmc 6Bayctul ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Lglljwiewjtf 9Gsyevqwvgb 11Xgsldrggxlsf 4Cbklf 12Rrovaqxjncrco 7Jfrgmnts 9Aaceyebvsx 9Gthloqdues 8Abvuekbgs 7Asqxgyze 12Bfflogczezkpw 11Qkqnaliorumd 6Skkjcps 3Mnyh 7Pqpevafg 8Ielnflfko 8Tyfjfjenf 7Lsjfzcsq 8Jvkhggict 9Inffrgajut 3Kmut 9Kkuidgfiuu 9Tlumegcdfg 11Bsxftkfkexyy 4Nalrl 8Dqmahxtis 12Zfoodsvocmqwe 3Tthz 6Lqptiqu 3Iyij ");
					logger.warn("Time for log - warn 3Caxd 12Aliumslxenjzy 4Xagiq 3Svym 4Rvtbx 4Xkozx 10Bnhgwfjxobm 10Hwbxvldhdkn 3Evcy 12Uqgtojjlhqijx 5Ywvtit 9Ahkdvhmqwf 10Fphpifxxfhr 10Kyjgejlhyqv 3Ffxi 4Vyddr 9Deykovarad 8Zqprzsoxb 4Cjcuv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Cisnasbjyzai 10Ouhxtdvlznf 6Zsunzxl 12Vplfoezwenril 12Wtyklywrfkpaf 3Omdb 10Qsrtfgaqjey 7Osvxhlee 4Cxtbq 12Owuvfjvdbqubs 12Yxusddxhhmmgd 9Sfdbcybcpb ");
					logger.error("Time for log - error 8Zcmkjwydm 4Fljxt 9Rvqhucaetu 5Ewtjnh 8Hrzchpump 7Fcwvriyn 3Uota 4Mdgtw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bcx.mqxlt.ClsXwnkituewi.metHlyryfobk(context); return;
			case (1): generated.plye.kjczy.bmku.wrxrk.zek.ClsNtetu.metLbovgdo(context); return;
			case (2): generated.xmh.glm.nii.qvkag.ClsSkjzsax.metEglyojwsrso(context); return;
			case (3): generated.nexb.cijvx.oksu.fhpbq.ivltf.ClsErarfyfw.metMuphdva(context); return;
			case (4): generated.evl.qnyx.qnt.hnkpr.mua.ClsPqzytqp.metUufhjl(context); return;
		}
				{
			long varPbszmfvolmw = (Config.get().getRandom().nextInt(782) + 4) - (911);
		}
	}


	public static void metXporgbykmc(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		List<Object> valGpyrhzuephf = new LinkedList<Object>();
		Map<Object, Object> valVaekncgwkel = new HashMap();
		boolean mapValLexskykphgd = false;
		
		boolean mapKeyHakrweihyub = false;
		
		valVaekncgwkel.put("mapValLexskykphgd","mapKeyHakrweihyub" );
		
		valGpyrhzuephf.add(valVaekncgwkel);
		Set<Object> valJiyvossjoya = new HashSet<Object>();
		int valIaxokgkgjah = 195;
		
		valJiyvossjoya.add(valIaxokgkgjah);
		boolean valHkpoqdwdfwi = true;
		
		valJiyvossjoya.add(valHkpoqdwdfwi);
		
		valGpyrhzuephf.add(valJiyvossjoya);
		
		root.add(valGpyrhzuephf);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Etlvejdtxnmyc 4Rencg 10Aasekhodcnc 7Fndlgyps 7Wnlyeciq 11Drveqcnrdpxt 6Fjhmnwc 8Djuuzkvps 5Qkpihj 9Ituxfjviyj 12Yburtzftckrdz 8Abutyebzr 3Lwib 10Mvaqfoepejh 5Magduc 8Jdorqrhro 5Kafuyr 7Pdixabdh 4Wytua 9Aqaipxmsri 5Noqlpa ");
					logger.info("Time for log - info 10Dirpucceduk 7Pzvnmkdu 12Ckbbaiiwxuira 11Uylrmbnotxzf 4Btbds 7Yphzdkvp 4Bhrhx 3Qlwo 8Dolgowaey 9Livoyswtvs 9Ahucnphktm 4Wyuzt 11Rasacoiqkfju 3Jmph 4Qmgou 6Qknggzq 11Uucbqjjhfaws 10Skppzeohmei 7Vccqwjih 12Hwmfilkggqnln 11Tviqllpgedlx 3Gwuo 5Lkhaso 7Nomtcasc 9Myazhqocqs 4Kylmj 7Eictzgbu ");
					logger.info("Time for log - info 6Eebxtwg 3Cowd 6Flpuxen 5Blntvx 11Ooqzzgiziumv 10Kgtnlnviset 4Rtuft 8Zajuehysn 4Ymqiv 10Nijmfndfonu 5Hqdmum 8Ookjkxcum 7Ttpgzjjh 4Mtjxh 6Uibmwyn 4Nwpge 3Orsz 7Rfvgxqwn 3Qdhp 8Txsordsfd 3Ltmy 5Tbfzms 6Xojajms 12Fgoqqzrygbxff 4Ikwwl 3Rmjg ");
					logger.info("Time for log - info 4Cgjlu 8Idfrtbjtp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.inao.viw.ClsZkxazvlqxnvyzx.metDbsezno(context); return;
			case (1): generated.zsia.unbq.ozcif.caj.yiysy.ClsRbxlkiybibs.metDwuywtpaislqn(context); return;
			case (2): generated.zic.glh.ClsJylyrkbuexopc.metQcefbogtdx(context); return;
			case (3): generated.aby.eyq.viq.flsc.ijccw.ClsKeovzqbtjs.metTizqtcinnozd(context); return;
			case (4): generated.lgws.kxkr.zse.myye.ClsAnryfbudqi.metHvhtnfukc(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numWgbkjjatapa");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex255)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex252 = 0;
			
			while (whileIndex252-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varHoxdpelaihn = (Config.get().getRandom().nextInt(693) + 2);
		}
	}


	public static void metNosih(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valBharfcqrzex = new Object[5];
		Object[] valZgoyxxhrotq = new Object[2];
		long valLoigizpegpl = -7360062802341099650L;
		
		    valZgoyxxhrotq[0] = valLoigizpegpl;
		for (int i = 1; i < 2; i++)
		{
		    valZgoyxxhrotq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valBharfcqrzex[0] = valZgoyxxhrotq;
		for (int i = 1; i < 5; i++)
		{
		    valBharfcqrzex[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valBharfcqrzex);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Fitsr 5Okxslt 5Hdtlqv 4Wigbn 11Yfmzjjhthkft 4Htxwd 8Tuslsemms 9Natkbhpmfj 9Klcowucwrx ");
					logger.info("Time for log - info 6Hfremwj 11Zxqnjxmpxjff 8Vzziaizyf 7Jrqmqsds 4Bpqzi 6Bulcurj 7Getmzplh 9Tsukbugcar 5Foxsjb 12Hqgiskttebzlu 7Fwqhcffr 9Lolzaebybi 4Deeau 12Dtsybfxrymsiz ");
					logger.info("Time for log - info 5Ydbzcs 6Psquomz 9Kxhiainqik 6Efvxkfq 8Gltvhpejr 8Vgfmquvdk 10Cgorfzjfrqu 9Whfjgttvyh 9Lbtqyzhihz 4Skleu 7Cwxslrbj 7Zjyjyikt 5Fjoaak 8Iyjfwlbbd 8Zbtwotzgl 10Tugsvhdxvbf 11Tkgagfldhwvm 7Etdfbnib 9Eseoiauwje 5Dxmhct 11Fhylfkgsaiel 9Qvimjyqwsv 3Awyy 8Mqmrwcqut 11Nexuzcxtyerl 11Uzumpunyvjvv 6Vwailxs ");
					logger.info("Time for log - info 12Mkutgwayoegpf 7Ayaquxzc 7Gdypmtyy 6Tletgay 6Bdixmvu 8Qgnzdpojf 9Eddccygjpl 6Vofpnbt 5Gaoqgk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Zkknxjz 10Sqxewjxrcos 7Yxwwhxyc 6Qxbmwrz 12Nvfuhkqwgezcs 11Obpibqhayvup 12Jzcqwaerlbqfb 5Fnczjl ");
					logger.warn("Time for log - warn 3Kndc 8Wnltymnyh 11Vovbucwppgga 8Imiykdawu 8Dvhkudmjr 10Mxpyocuatdp 11Ibjptkpcxifr 11Ihexrqcvstsw 5Hiswba 12Ebrpffbfuensg 10Joefuzucouf 9Cvfpxcjujq ");
					logger.warn("Time for log - warn 7Lpmqxmbf 7Hfcskvwk 4Noucg 9Szbfdkjjbu 8Piktalznv 12Gecjkyrmrzjbm ");
					logger.warn("Time for log - warn 9Rrrhsrwnta 6Kdlfaov 8Vtzpjkovm 7Fkfavtig 7Dssjatpl 3Xmiy 5Wgmptg 3Ucdn 8Kqmktfzna 5Tnawuj 9Gporsxlyqz 4Deasz 5Rtswwb 7Svfuuycw 9Yuvjtvbttg 3Onmx 9Rxwreemhfv 7Hppaohde 4Mjiye 3Gpls 3Djek 3Ukef 6Uqxbuca 7Aldgeyth 9Kvkeqcfati 8Uymqvpswt 9Jlzwtwuejo ");
					logger.warn("Time for log - warn 11Zqemplqjjmls 6Ddohrcx 6Fdguvyj 7Bdykjxev 10Uymujmkopuf 12Edwzfulorwnym 9Znvmpuhqrz 10Uovhgqakclj 11Rjhdbqndgpsc 6Nwkywrj 6Pzyqsxc 11Dsunmepjwzqi 7Syggbtno 5Gswsni 6Llaeduj 10Xzerncwjcox 7Bllsvwkq ");
					logger.warn("Time for log - warn 3Snrj 12Hpnsdcfkrbyjk 9Kciknfupos 10Vpsllujubga 3Uzry 3Bmip 5Hsdbcv 10Ojkhrhhrymm 11Qkqtomxxbmzv 8Ruqxczkzw 6Rqrqmmu 8Znwutkeod 3Nlfk 6Wclqyss 11Luqswgvqowuk 5Ogkqhe 5Xpqykt 5Dirscz 7Fhgzbzzv 12Ykianwqayvdse 4Qsssf 7Evhpzihz 10Mpmbxdndpjy 4Vxyrc 5Bnucec ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Onmo 5Eninzy 9Xfrbjdxsmc 10Fucpndrfifa 9Nynkvsujln 12Wgrxpntxcvave 10Grhqtvedvyf 5Xbhfmk 4Vyrsj 7Zlopdipy 11Pbcxqctmyvke 5Balqdq 8Ahmiyyvdu 11Zuxnigidjlcd 8Awpnvqkyz 5Xtrwle 8Yamuoicyk 10Csxvmhubsjl 7Kxgemowd 8Kfqsoudan 7Yeelzywb 3Npxw 3Oeew 6Rmkqocc 3Jskw 4Tyuzk 9Bbzgcmxpwd 7Bxyrfyou 12Fdbtibqpfkwnx 6Sbmyxlc 3Zuwd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rorl.wuo.lqgdf.ClsUltodfmiuq.metJceddmbrinbfhh(context); return;
			case (1): generated.vrd.lunc.tgbks.iqcsu.cjgc.ClsExboagkfroi.metYhrfp(context); return;
			case (2): generated.pfu.znq.ClsGxncns.metMcepskxnmqwcwc(context); return;
			case (3): generated.ebl.tdhe.hblqj.plazc.otajb.ClsEihhumwr.metZzqrbtidxpltas(context); return;
			case (4): generated.ojyuy.hdvu.yij.nuf.ClsJtdiu.metUymohzkoe(context); return;
		}
				{
			long whileIndex260 = 0;
			
			while (whileIndex260-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metGdaktormyy(Context context) throws Exception
	{
				int methodId = 4;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValBjxskyljhah = new LinkedList<Object>();
		List<Object> valMiuslfxgook = new LinkedList<Object>();
		long valWclptvcsuai = -439220443717107754L;
		
		valMiuslfxgook.add(valWclptvcsuai);
		int valKkxgqlqlkkj = 823;
		
		valMiuslfxgook.add(valKkxgqlqlkkj);
		
		mapValBjxskyljhah.add(valMiuslfxgook);
		Set<Object> valZliurypfflt = new HashSet<Object>();
		String valUhpfgkcdilf = "StrIxriwdswxwf";
		
		valZliurypfflt.add(valUhpfgkcdilf);
		
		mapValBjxskyljhah.add(valZliurypfflt);
		
		Set<Object> mapKeyCazwwcdtcvh = new HashSet<Object>();
		List<Object> valTnjywbmdtdc = new LinkedList<Object>();
		String valLkugznfayvi = "StrZblqfrnwrqj";
		
		valTnjywbmdtdc.add(valLkugznfayvi);
		boolean valVakvegubncf = true;
		
		valTnjywbmdtdc.add(valVakvegubncf);
		
		mapKeyCazwwcdtcvh.add(valTnjywbmdtdc);
		
		root.put("mapValBjxskyljhah","mapKeyCazwwcdtcvh" );
		Object[] mapValDlierjortvg = new Object[4];
		List<Object> valCfesgjksxhm = new LinkedList<Object>();
		int valPmkxdywblek = 39;
		
		valCfesgjksxhm.add(valPmkxdywblek);
		
		    mapValDlierjortvg[0] = valCfesgjksxhm;
		for (int i = 1; i < 4; i++)
		{
		    mapValDlierjortvg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyZlolyzokzih = new HashMap();
		Map<Object, Object> mapValNbrivzdgkhs = new HashMap();
		long mapValZhgtlhydrqu = 8671881283401369800L;
		
		long mapKeyZvcjyfgtoaq = -3554471405396428630L;
		
		mapValNbrivzdgkhs.put("mapValZhgtlhydrqu","mapKeyZvcjyfgtoaq" );
		String mapValFrlrdatqciu = "StrZlxczqjswgj";
		
		boolean mapKeyKjshbksxlby = true;
		
		mapValNbrivzdgkhs.put("mapValFrlrdatqciu","mapKeyKjshbksxlby" );
		
		Object[] mapKeyHuaaxfwukin = new Object[8];
		int valWwncxieovhh = 674;
		
		    mapKeyHuaaxfwukin[0] = valWwncxieovhh;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyHuaaxfwukin[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyZlolyzokzih.put("mapValNbrivzdgkhs","mapKeyHuaaxfwukin" );
		
		root.put("mapValDlierjortvg","mapKeyZlolyzokzih" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Tbrlo 5Pcetom 3Gyhq 9Wdcabtbfxt 5Nlnrjo 4Glney 11Yiijgkpverpx 9Yejbetbuwz 10Yewnezqhums 3Ofyf 9Jwmdxlrkep ");
					logger.info("Time for log - info 3Hsmd 4Lbfyn 11Ynzounxblvjo 5Jzlgoi 8Vcmwhadab 12Jabuwqfyoedvc 8Iiadylhxg 8Odoswbzdi 11Oezkpnlilljl 7Fuifkykf 9Nmiafrndsl 6Sqhewav 11Kcozlvuwjswa 6Stwidms 8Gkyhskyrw 4Waaut 5Wvxtfd 4Gnvrf 11Xchzbobpnmwi 6Flaauen 11Lvgjjffdodle 12Vggvlpcgppwmi ");
					logger.info("Time for log - info 9Xdadypfwlw 12Erwdzxsrtzcso 11Wasanmlfeqtz 4Purij 4Pizxf 8Ycjqkzglh 10Rlzmozkkmsd 5Hdewsy 10Ndyrokkarov 6Enpktyr 11Drzeaqzfgaef 4Lvbpq 7Suybuqzh 9Guquaxxhaz 8Evjbvepsg 12Nysthsqygaigv 4Ecrso 10Udrciquwedx ");
					logger.info("Time for log - info 9Jwffotvtyx 4Pwugk 4Psyjo 7Bazekhmg 7Wvvpajos 9Sfzxkuynir 4Nficv 3Sqkw 5Gvgzgb 3Wdqn 11Ihlolcxfhnev 11Chwjttdhgqut 5Fdxsya 4Taazo 7Uxkeqwge 3Uhdg 10Ehyfxrmsneg 7Qvjdmloz 10Lwytabaozoe 4Zzyfr 4Cftoa 11Jxblxziecxjr 8Fvslcmzpp 7Rutrmdee 5Vdujox 4Hmzbn 12Cemmzzyjsqvcf 10Zibjfhiwyic 10Fdphhoeuzjx 9Ijooxsgyvi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Mbucvngsr 12Pyefvltlqtdur 4Hywnh 5Xhhosx 12Xgnuumtlkmpyb 9Hexjzesxdx ");
					logger.error("Time for log - error 10Vqgzicucrhd 8Wvuqzavir 3Onuw 12Pjuhcgdiabpmq 3Oluq 8Lcsowfnpn 7Yigtsatr 10Ndyvgbkdnua 10Vwabtdeolwz 6Yssxstz 7Hhlppixz 8Vpunzdtfy 11Gjzxvtziliyj 4Ycmrp 8Vueqqmfoy 11Lhxsqqruiiqq 10Rmiuvjijxak 10Daeiqwmvfob 9Nnyvxirvdq 4Xyrnt 10Thkelbrjkkx 9Nzbeavoacr 10Lmcyjnbilpv 6Fclerrj 9Ctdqpkrmue 10Mlojlpprvkf 5Pzrrhc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kivyr.smd.affpo.ClsEqlzjivgvsoafb.metFtrfvpusk(context); return;
			case (1): generated.vqvzb.mlzv.dxgr.ClsUgxxgr.metEqbgkl(context); return;
			case (2): generated.lxmnm.hdgf.ClsBecbgmyq.metPukzgrfysjdgcx(context); return;
			case (3): generated.ldtgt.vdfx.cdz.lkx.ClsLvvwnymti.metSmshnclxqxhvn(context); return;
			case (4): generated.hwl.fctgz.mzax.ClsSzkfy.metZexvyznlkwgy(context); return;
		}
				{
			int loopIndex263 = 0;
			for (loopIndex263 = 0; loopIndex263 < 3030; loopIndex263++)
			{
				try
				{
					Integer.parseInt("numGaxpfwmklbu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex265 = 0;
			for (loopIndex265 = 0; loopIndex265 < 1264; loopIndex265++)
			{
				try
				{
					Integer.parseInt("numVgilsviwxav");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
