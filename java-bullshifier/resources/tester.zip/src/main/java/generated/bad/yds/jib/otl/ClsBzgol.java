package generated.bad.yds.jib.otl;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBzgol
{
	 public static final int classId = 59;
	 static final Logger logger = LoggerFactory.getLogger(ClsBzgol.class);

	public static void metFiipzeiyfjfs(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValDyqkracmgxu = new Object[9];
		List<Object> valSrpyyjgdyim = new LinkedList<Object>();
		String valPwihsbibxlv = "StrZjbsfzovlzk";
		
		valSrpyyjgdyim.add(valPwihsbibxlv);
		
		    mapValDyqkracmgxu[0] = valSrpyyjgdyim;
		for (int i = 1; i < 9; i++)
		{
		    mapValDyqkracmgxu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyAjorsyeghnx = new LinkedList<Object>();
		Map<Object, Object> valEbxhpjdjuuw = new HashMap();
		boolean mapValMqvqeuhrsbx = false;
		
		boolean mapKeyZpdkmmloklw = true;
		
		valEbxhpjdjuuw.put("mapValMqvqeuhrsbx","mapKeyZpdkmmloklw" );
		long mapValJjknzckbydu = -7216452275418463580L;
		
		int mapKeyKqaqtfjsdmu = 737;
		
		valEbxhpjdjuuw.put("mapValJjknzckbydu","mapKeyKqaqtfjsdmu" );
		
		mapKeyAjorsyeghnx.add(valEbxhpjdjuuw);
		
		root.put("mapValDyqkracmgxu","mapKeyAjorsyeghnx" );
		Set<Object> mapValFzupvcaajra = new HashSet<Object>();
		Map<Object, Object> valUidmvqppnjk = new HashMap();
		String mapValPdjbtmarlhy = "StrQriwigrkjtb";
		
		boolean mapKeyIxvmrxlwrht = true;
		
		valUidmvqppnjk.put("mapValPdjbtmarlhy","mapKeyIxvmrxlwrht" );
		
		mapValFzupvcaajra.add(valUidmvqppnjk);
		Object[] valJbayhywducl = new Object[6];
		long valMzwokhjqueg = -3655951740345785647L;
		
		    valJbayhywducl[0] = valMzwokhjqueg;
		for (int i = 1; i < 6; i++)
		{
		    valJbayhywducl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValFzupvcaajra.add(valJbayhywducl);
		
		List<Object> mapKeyMxnxgykvswk = new LinkedList<Object>();
		Map<Object, Object> valWmenythutfh = new HashMap();
		boolean mapValPddfulvyeht = true;
		
		boolean mapKeyBcdymzijndx = false;
		
		valWmenythutfh.put("mapValPddfulvyeht","mapKeyBcdymzijndx" );
		
		mapKeyMxnxgykvswk.add(valWmenythutfh);
		
		root.put("mapValFzupvcaajra","mapKeyMxnxgykvswk" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Fgjohpk 6Zaallcs 9Qouqfgubdn 5Swagfn 6Yrtdund 10Fvrjqtvyjer 7Sdpxjwcp 11Deqjggqpahww 8Thuzqqkvv 9Gwvyzuvsso 8Ghpubtuov 7Saworkdr 3Navi 10Vgpfncevljh 8Fsnjhovok 4Vtvbi 4Ksrks 8Ecoveixrj 3Rkbw 8Vzjbddqfn ");
					logger.info("Time for log - info 10Qxjtpjmvvrt 8Ugkhkgyjj 5Nqkdmv 10Mbqvupxkxfw 10Dokfnjynioh 8Uurrvxlek 3Vzgx 4Pydev 10Lopdqkrvhac 9Vzksixtxuw 8Vjlzzxpnq 10Hyyftmnuhqh 9Ltirvrkpnz 10Asbollgyzgu 12Cickosdwfsnqi 10Pejpouhnhqn 12Erjwnlzftnqno 5Gvotoh 6Ogvosho 3Xfqt 11Ypyxdtgoyprr 4Rwdil 6Wnpzqdn 4Arcla 12Spleqbsvbsffm ");
					logger.info("Time for log - info 11Tycedpuvzmhw 6Mjtcvcg 7Zpwpjzqo 11Dnstrxgkjsta 12Abnlvdyavfail 5Kiygwx 7Graiqfrk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Fscbr 7Bbgfnvbf 8Pvfakrwpb 8Trqscxcsn 9Ldzhfejkwg 5Tnjkkz 12Lzdwtbbdrgsgq 11Gwqpuefqutsu 3Iivh 9Ywgqpiuqdf 8Nydbtqdhc 6Ktovjqa 9Zyfkyulfjl 10Rswxloodxxn 7Ljjxtaav 7Fzskrbbo 3Xjop 5Tcixtf 12Epnroixljmxgt 4Erkxt 7Nfdghuxv 8Xhlyznoca 6Yrubvax 7Zspuefme 4Dtsch 5Bnouta 8Nrvgpadnm 6Vqsfypo 7Huytohdv ");
					logger.error("Time for log - error 4Xmqnc 10Xxcozywftst 4Ynlgb 6Cgtoque 3Btml 6Knybnmd 5Hmdruz 3Eihy 6Hqecnwt 4Zbmda 7Enqgxolj 11Zkhtvfikgnju 9Uliyehchzs 9Uvcadxoeoy 9Clvioptbqv 6Wohkegh 6Rjoozyi 3Smdv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.phtjf.bzplf.izqn.pznr.nxe.ClsUtlzborau.metGtnmttouutf(context); return;
			case (1): generated.kivyr.smd.affpo.ClsEqlzjivgvsoafb.metFtrfvpusk(context); return;
			case (2): generated.hcl.ivd.nxcam.ClsQkvrtnftml.metTyfahozhlcema(context); return;
			case (3): generated.seews.usvhz.ClsBpkgpi.metKhnlgsy(context); return;
			case (4): generated.gfhvs.nuhuq.qbk.rwbku.erqpl.ClsOuzdnnqrt.metYemauozpyth(context); return;
		}
				{
			long whileIndex21083 = 0;
			
			while (whileIndex21083-- > 0)
			{
				java.io.File file = new java.io.File("/dirEjeznecykpu/dirTeetvfzxsuf/dirEmisogdhzdu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex21084 = 0;
			for (loopIndex21084 = 0; loopIndex21084 < 9880; loopIndex21084++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metXuevg(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValOsdubjnvtex = new Object[4];
		List<Object> valRcwygnjouyu = new LinkedList<Object>();
		String valEctckbcirfm = "StrGeqsrtxgvug";
		
		valRcwygnjouyu.add(valEctckbcirfm);
		
		    mapValOsdubjnvtex[0] = valRcwygnjouyu;
		for (int i = 1; i < 4; i++)
		{
		    mapValOsdubjnvtex[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyQsclxzqwrce = new HashSet<Object>();
		Map<Object, Object> valKznvpxxmhgp = new HashMap();
		int mapValGcjprsouhrq = 557;
		
		String mapKeyVremecjffly = "StrNbcptxpkoqu";
		
		valKznvpxxmhgp.put("mapValGcjprsouhrq","mapKeyVremecjffly" );
		boolean mapValViyegrtltfo = false;
		
		long mapKeyDyvfritvkqv = -8265643330941854010L;
		
		valKznvpxxmhgp.put("mapValViyegrtltfo","mapKeyDyvfritvkqv" );
		
		mapKeyQsclxzqwrce.add(valKznvpxxmhgp);
		
		root.put("mapValOsdubjnvtex","mapKeyQsclxzqwrce" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Oydkkrjxi 4Ngioa 5Aliucw 10Bfwrcfbwjil 5Qdicgc 6Fqyzdvw 5Pnnics 8Gsdukidag 5Ilqchi 8Ukiebjgxk 10Imtsgvqaibx 6Pcxahhe 12Wotraybehosnt 5Hkmqcr 4Nmloj ");
					logger.info("Time for log - info 11Siawsuznapro 9Tmhkpjpdlt ");
					logger.info("Time for log - info 11Etlgidwjqyxl 12Lpkdtkqgnlxvr 4Mwpgt 8Wsnwcryqh 5Azjqhn 9Onuidsnxxg 7Kxstgzub 11Kvxbgwkjaunq 5Mcypfj 8Jdrqpidch 8Nimzobpoe 5Iykzze 6Omyzzrj 8Mwdwmuhdm 6Zuillhv 8Cjfzjfkou ");
					logger.info("Time for log - info 6Wexfclx 11Wywdyvbdxrcx 8Pwyjvayki 8Acgwjgqxx 11Yfbwgrtveajz 6Wxefugh 10Pwrrsxfkvkd 9Tizbafiumr 3Qbhu 4Aigyc 8Dlmvqpvuc 6Nijbbkw 12Putyxwurhapmu 10Nqiduuczrjm 8Tsofhpklw 4Tindt 9Wyrkxullod 12Yeknajfrwlemw 12Lbbebrwadumnt 3Wofm 10Guxobmtnsra 7Iafyczia 9Eeqmbmlemj 7Ttwvkmyr 12Aygufgycftqrw 10Qdssngrrgio 8Ifhrmkopu 9Lgpnvtimjq 5Bvpyzy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.afz.qen.lrlj.ClsTvxlbccvg.metWrkbglgpwrbj(context); return;
			case (1): generated.cin.hewe.akg.wyf.seuvv.ClsFgxjhcrdocnyas.metKhzutma(context); return;
			case (2): generated.mvrs.ywr.ahvi.avyw.whash.ClsQifjwldjrqu.metZuirhqgb(context); return;
			case (3): generated.twx.gyla.ClsYuzgeqywoqmok.metZrjgdmb(context); return;
			case (4): generated.zdn.ayby.ClsMelkmphvwjkgwh.metAcvmturnoh(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirMnwwzvmqsnk/dirJvmliyevmhc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numYfdwmapdvtt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((5938) % 875376) == 0)
			{
				java.io.File file = new java.io.File("/dirDlhlwhefred/dirPkgfhhmxjtg/dirIpxbzrbxoiy/dirWdbkvscfgil/dirVpleocybnhu/dirHbhypqyikom/dirPcyiltmwueb/dirGiqojqusauy/dirTbbmqifxhgc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirDyokhszrqiw/dirDxrqooqhkjo/dirYraiykfoktq/dirCiykxfivikm/dirLyhmrnrlbnu/dirUryvylxncwy/dirIszvvrvfowi/dirDzqwtdmsxts/dirDnbipcxmsfw");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metJlqnadqe(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValHbjnybayeln = new HashMap();
		Set<Object> mapValBwyfbnmlafu = new HashSet<Object>();
		int valAcxarxcobnb = 397;
		
		mapValBwyfbnmlafu.add(valAcxarxcobnb);
		boolean valRyqntthjqvq = false;
		
		mapValBwyfbnmlafu.add(valRyqntthjqvq);
		
		Map<Object, Object> mapKeySdjxzmgkjue = new HashMap();
		int mapValAkhkukrykjo = 19;
		
		int mapKeyGuifpvpdtye = 60;
		
		mapKeySdjxzmgkjue.put("mapValAkhkukrykjo","mapKeyGuifpvpdtye" );
		long mapValThnsllszpbd = -776941197933110380L;
		
		String mapKeyVtydhdlnjiy = "StrOhrocgvpwvg";
		
		mapKeySdjxzmgkjue.put("mapValThnsllszpbd","mapKeyVtydhdlnjiy" );
		
		mapValHbjnybayeln.put("mapValBwyfbnmlafu","mapKeySdjxzmgkjue" );
		Set<Object> mapValJksnatidihk = new HashSet<Object>();
		long valUgfafjkyfxe = -1247619187979009859L;
		
		mapValJksnatidihk.add(valUgfafjkyfxe);
		int valRqpmghoyplm = 44;
		
		mapValJksnatidihk.add(valRqpmghoyplm);
		
		Map<Object, Object> mapKeyIqjfvpmcvjv = new HashMap();
		int mapValVcsjgwitxml = 478;
		
		int mapKeyIufwcgiegmq = 267;
		
		mapKeyIqjfvpmcvjv.put("mapValVcsjgwitxml","mapKeyIufwcgiegmq" );
		
		mapValHbjnybayeln.put("mapValJksnatidihk","mapKeyIqjfvpmcvjv" );
		
		Set<Object> mapKeyOzklkilzkft = new HashSet<Object>();
		Object[] valPqabdejfonz = new Object[6];
		String valXuxthvasnwh = "StrJywlkdeexoq";
		
		    valPqabdejfonz[0] = valXuxthvasnwh;
		for (int i = 1; i < 6; i++)
		{
		    valPqabdejfonz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyOzklkilzkft.add(valPqabdejfonz);
		
		root.put("mapValHbjnybayeln","mapKeyOzklkilzkft" );
		Object[] mapValCiznsdebvdb = new Object[9];
		Object[] valVlemmptrita = new Object[11];
		int valOiwjrfqgmzb = 454;
		
		    valVlemmptrita[0] = valOiwjrfqgmzb;
		for (int i = 1; i < 11; i++)
		{
		    valVlemmptrita[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValCiznsdebvdb[0] = valVlemmptrita;
		for (int i = 1; i < 9; i++)
		{
		    mapValCiznsdebvdb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyEnoumkmnsqp = new HashMap();
		List<Object> mapValInvuccpsssx = new LinkedList<Object>();
		long valYorgmywkdld = -2793417781925565902L;
		
		mapValInvuccpsssx.add(valYorgmywkdld);
		boolean valDlsrrhohuxc = true;
		
		mapValInvuccpsssx.add(valDlsrrhohuxc);
		
		Map<Object, Object> mapKeyAsyklterjcr = new HashMap();
		boolean mapValCjpldkyuvtb = true;
		
		boolean mapKeyHftmjjwqhvs = false;
		
		mapKeyAsyklterjcr.put("mapValCjpldkyuvtb","mapKeyHftmjjwqhvs" );
		
		mapKeyEnoumkmnsqp.put("mapValInvuccpsssx","mapKeyAsyklterjcr" );
		
		root.put("mapValCiznsdebvdb","mapKeyEnoumkmnsqp" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Ffrwgkfq 4Hhxoj 5Pmmeia 12Rywxxcqsjledm 4Mahrc 8Okvaamuda 11Donjhiuqyhyz 6Uervevi 12Iqufhirzgoxoc 4Lygxu ");
					logger.info("Time for log - info 9Lmrwxuqejf 11Eewvduxuduzr 9Wjogeqovel 7Ezjwpsko 7Gpxruotj 7Ldvtwzvp 5Mgrkde 12Siktgjpwqsryp 3Rwhd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Vkcyxdnlx 6Tyttnju 3Tpky 4Ayxxp 10Ekkqerigkja 5Vpjogn 8Qmldkacwh 8Nhkkgfyyh 3Xjdk 11Azsfpqwnctwe ");
					logger.warn("Time for log - warn 9Xxkgneqvoe 8Neddvzedb 11Yzpzsfevazvr 6Wiwztjo 4Mfvrx 8Avtqtfhsx 12Pbfisuibdrzrw 5Phxlqc 10Udtydhnilqn 5Fyvqpf 4Zxrqo 5Dgunjl 6Qfulelg 7Kigynuig 6Bvayhkf 7Parfqkza 3Vesn ");
					logger.warn("Time for log - warn 9Zdierfzhdk 9Bfbbtpvuoh 5Sndkrk 9Orpmiopcal 10Kmvfqwhluon ");
					logger.warn("Time for log - warn 9Ouxfmhmeip 7Kgigahmd 4Diabm 10Vlzjdwwebuo 12Mujvycrxdhlpn 3Iwmt 10Glogryenzid 5Skkdis 3Bqyu 10Cmsstwfuezf 8Gmlpxvauu 12Rwddateomzqvf 6Tbspoiy 11Vnddqrscafey 6Phasvnz 3Sgsx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Twnswvmifpnpo 5Gqfxgj 7Mnebvzyc 3Gvdt 4Dtccg 11Ntgcwlstgxjl 5Txzgsk 11Wpzxbojvsdlr 11Szzwksyydogk 6Oetmanu 4Wcuth 5Kebdos 9Ftlgfzxwtx 10Gstrfrbqudw 6Haeodme 6Fexespb 5Dtuiso ");
					logger.error("Time for log - error 7Mmfwgbpk 4Klzfe 4Oweiq 4Muiic 9Ibmytoxobc 7Cvumzusw 5Qvymts 10Dkrhqosvgyv 10Uexndzwupfo 7Cgvrgsnc 6Nyknzcl 4Npxkb 9Okilvitzcz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.uooez.nez.ipsx.tenui.ClsCrgtl.metUnmartob(context); return;
			case (1): generated.ucgs.cys.qrt.ClsGwmfnzjfaj.metEgvezjze(context); return;
			case (2): generated.fpa.lsm.ClsOulug.metQkxwhcwddo(context); return;
			case (3): generated.dxrru.qphkk.sigfx.fho.qtrx.ClsXgcfqnkax.metJqylvdbl(context); return;
			case (4): generated.gbss.lmi.dvqsw.ClsLptludgibvpvw.metJevsr(context); return;
		}
				{
			long varApfbfimluad = (Config.get().getRandom().nextInt(13) + 9);
		}
	}


	public static void metOnfznlwhtrhjye(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valDgzsfxelafz = new Object[3];
		Object[] valPfxbfugxkzc = new Object[6];
		boolean valHcjlydbyihh = true;
		
		    valPfxbfugxkzc[0] = valHcjlydbyihh;
		for (int i = 1; i < 6; i++)
		{
		    valPfxbfugxkzc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valDgzsfxelafz[0] = valPfxbfugxkzc;
		for (int i = 1; i < 3; i++)
		{
		    valDgzsfxelafz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valDgzsfxelafz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Xxbgjyvx 5Oouuxx 10Zjojrkrbhnm 12Mfilyhymsmljp 7Dpakwwak 6Otkwvtd 9Hwtoineknb 7Pbvgkppf 9Gaepbhefjb 10Caxbmgayrrf ");
					logger.info("Time for log - info 3Caei 6Ydnylvs 4Zietj 5Cliavh 12Kxlxbidmnayjh 3Wrem 8Dmfudbdsr 9Sifyjzlsku ");
					logger.info("Time for log - info 4Oaogs 3Frgr 5Kptdhi 12Kgeoiariiegxf 12Cjchqefozkume 12Idoavmfakgfnn 8Hsantnjge 4Gwwcr 10Ijtdlcztele 6Cccexpf 10Zefckijybbz 5Jdpxnd 8Wsjzndnfj 7Tarulnuz 5Gxydib 12Pbzlzjofskzqi 12Rnpcxhwfjrnet 5Skietw 6Bnxvgcg 8Fiqbgcrbg 12Kancfbofuugnf 3Fkya 11Oeifvymfqkqx 6Qtgtglw 12Anrtpumiywtes 7Irrzcprw 6Fwrcdnv ");
					logger.info("Time for log - info 4Bilqx 9Zwrzkwpsjd 3Ycnv 4Mutgd 3Bhtz 6Sdqvgtl 7Pfduwvgg 3Khzv 6Auqfgyi 8Yoanwydqt 3Kwmf 12Yqfvwqcdfuhze 7Mxpigycz 9Vbouyxagxy 8Bptfpavwa 7Jprynapc 9Sucksrznnh 7Briifdue 9Sckjevxzan 5Zhmstf 7Mxuarnio 4Jrjmz 9Mqdkabrrnd 3Nkeb 8Yquptxuyu 12Wqadeudsjydxu 6Esuxaqk 3Jzlq 5Cnnmxw 8Dxpkoufih ");
					logger.info("Time for log - info 5Covokk 11Aiccicyyujpq 10Howkywweibf 7Xmewnguz 9Uhvnuwzejn 8Qascnpdtl 3Uoqx 5Dtcumy 4Dxruf 6Uaxdgee 3Apji 10Jhanikswsqi 10Slpoiblyutw 4Sjmsr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Oroojoihndzp 9Wshltsuiud 5Hxkknl 10Lcirtlwrvzs 12Alpsnlszjgmug 5Htqmyp 5Rhfmkl 7Kyjizqbm 3Bbyn 11Ulamzpxoowgp 7Owbtphnn 4Ccmqe 12Mjvjduikkxmkw 9Iddzzugaak 3Tnys 7Ltllzbij 10Imayvcjgnql 4Dzpdp ");
					logger.warn("Time for log - warn 12Yufdusgypyudm 7Dthnlazr 12Rahwalazvlihx 4Bxtay 10Ghrtetfrutm 8Gupopypvx 11Yxbsagignxff 10Yiabdzuvgns 12Hgiitnntwthfr 12Mesyeytvhyjop 7Outcfaxx 5Jkvniq 4Hjncq 8Fophsinnf 9Ltfaqxgagd 5Bdebbs 8Audhcxpdc 8Ktgqnvjgw 4Hfelr 4Ulptx 10Wrdjxtaeumo 5Tgybqu 8Hyqjmhvnv 4Asqro ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Msinkaljbjgf 10Nobuyyiacsz 3Fpqb 4Yzwkl 3Jgwg 7Vscpnjic 7Einuewci 12Cscelyegokqaf 11Ynazafklvcvm 11Zsolkivnxukq 3Zkbb 10Avlwpfhfudk 5Ogfxdd 10Ptmitachofl 8Yhwtjkezq 10Pukledvgdqj 3Vtca 6Rhuezww 7Cawtzfoi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metJpighvrrkvmknf(context); return;
			case (1): generated.biw.lypu.ibsb.ClsHgpoogowepds.metZtpdamxft(context); return;
			case (2): generated.cmlwi.ajlk.yhine.aaz.ClsYxnwkcu.metLfnugxqxocfhpv(context); return;
			case (3): generated.gfiaw.wgvz.askqs.ClsGbqekumwdbwfn.metOynzozsdtcw(context); return;
			case (4): generated.zfo.wctt.rjxf.wjfcy.ClsKuhcjj.metZbrfmmk(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirYffhcipokdf/dirQgbjowmqnaf/dirJgmlyjhieqg/dirNioeljqegmp/dirYvrqwaltmeu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex21102)
			{
			}
			
			int loopIndex21100 = 0;
			for (loopIndex21100 = 0; loopIndex21100 < 4452; loopIndex21100++)
			{
				try
				{
					Integer.parseInt("numCinweqeigjg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
