package generated.kivyr.smd.affpo;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsEqlzjivgvsoafb
{
	 public static final int classId = 398;
	 static final Logger logger = LoggerFactory.getLogger(ClsEqlzjivgvsoafb.class);

	public static void metFtrfvpusk(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValArpzeaezrmp = new LinkedList<Object>();
		List<Object> valHzrumcbzdpw = new LinkedList<Object>();
		boolean valMwazemroxrn = true;
		
		valHzrumcbzdpw.add(valMwazemroxrn);
		
		mapValArpzeaezrmp.add(valHzrumcbzdpw);
		
		List<Object> mapKeyGfwtbxsizzh = new LinkedList<Object>();
		Object[] valJjoxtnruzbg = new Object[4];
		boolean valUiaywrgwswj = true;
		
		    valJjoxtnruzbg[0] = valUiaywrgwswj;
		for (int i = 1; i < 4; i++)
		{
		    valJjoxtnruzbg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyGfwtbxsizzh.add(valJjoxtnruzbg);
		
		root.put("mapValArpzeaezrmp","mapKeyGfwtbxsizzh" );
		List<Object> mapValFnqfdsomtnl = new LinkedList<Object>();
		List<Object> valHlgclhracst = new LinkedList<Object>();
		String valNqnrfllibsm = "StrWtfzngunjsk";
		
		valHlgclhracst.add(valNqnrfllibsm);
		
		mapValFnqfdsomtnl.add(valHlgclhracst);
		Object[] valHqnwowzcjqz = new Object[11];
		boolean valWtyspqffrje = true;
		
		    valHqnwowzcjqz[0] = valWtyspqffrje;
		for (int i = 1; i < 11; i++)
		{
		    valHqnwowzcjqz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValFnqfdsomtnl.add(valHqnwowzcjqz);
		
		Set<Object> mapKeyFpquvbscwjm = new HashSet<Object>();
		List<Object> valFtsktyrplym = new LinkedList<Object>();
		boolean valWztibozxpdy = true;
		
		valFtsktyrplym.add(valWztibozxpdy);
		String valTpwxixjpspx = "StrHnnkevefbci";
		
		valFtsktyrplym.add(valTpwxixjpspx);
		
		mapKeyFpquvbscwjm.add(valFtsktyrplym);
		Set<Object> valEevimmxdtgn = new HashSet<Object>();
		int valLsyskgvbuvd = 845;
		
		valEevimmxdtgn.add(valLsyskgvbuvd);
		boolean valVlrluivvavo = true;
		
		valEevimmxdtgn.add(valVlrluivvavo);
		
		mapKeyFpquvbscwjm.add(valEevimmxdtgn);
		
		root.put("mapValFnqfdsomtnl","mapKeyFpquvbscwjm" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Srqfysruzgw 7Lvwkluwy 8Qxomcwwzx 7Mqbkwwxh 8Epwnaotmj 4Enkvn 4Veekb 10Cqengalkqpk ");
					logger.info("Time for log - info 11Zzfwoqxiypvw 6Yljoxna 9Whiaouxjdu 5Pxwziz 4Dgqyg 6Rrsudib 6Ljnebsi 5Njahqz 10Quwnsewrgge ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Etwhfwif 7Nzygkrtx 7Pwchgeou 3Nqwq 6Vjhthdo 11Tgryofysnanc 4Hzncl 4Kptna 8Ojbnbllsu 9Lygihuwcxx 3Dmmo 4Xqkab 7Rgeflhnr 12Hpcyclbsqtybz 12Jfqwzvftpkzox ");
					logger.warn("Time for log - warn 6Sfahmau 9Pxfgysstea 3Ikrd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Npnofuabbqro 12Jzcmzeezmverm 9Fpofrbppui 4Chjbu 6Dacarhz 6Reukbgs 9Tpzxpvkozm 12Pqgbwxdsbqaus 3Vryr 7Jynamavf 8Xefpjyzpr 6Pdyokua 10Yzptzxztbst 10Ljrygnhbrbh 11Hfbfjpbomiug 9Dowxizkzbs 5Yrnywa 12Nftefziwyhuzo 8Lgrleckzo 4Ebrgn 12Pduozoclkuagd 11Bbwuncagdafb 4Bxhue 6Pacxaee 7Nunvptor 9Enkbwinoqf 9Ilmuiwgqgf 5Lzjfzt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vqvzb.mlzv.dxgr.ClsUgxxgr.metAqgou(context); return;
			case (1): generated.kivyr.smd.affpo.ClsEqlzjivgvsoafb.metFtrfvpusk(context); return;
			case (2): generated.yfeni.otsaz.fkhen.upca.zzv.ClsWbxrghwufimrgi.metGdsjwr(context); return;
			case (3): generated.hnmnf.dxh.laih.zpf.ClsDfldwucgkze.metVnovmwgbhe(context); return;
			case (4): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metHnipemdqhlr(context); return;
		}
				{
			int loopIndex26744 = 0;
			for (loopIndex26744 = 0; loopIndex26744 < 411; loopIndex26744++)
			{
				java.io.File file = new java.io.File("/dirSzaictuglhx/dirTlcmnaiiabm/dirSlpxhprvdvi/dirWovczapnorf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
