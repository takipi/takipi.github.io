package generated.uffsk.vmiw.dvm.uejb;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsHwejuhoirpcucb
{
	 public static final int classId = 178;
	 static final Logger logger = LoggerFactory.getLogger(ClsHwejuhoirpcucb.class);

	public static void metTioel(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valDsvjvtbriyq = new HashMap();
		List<Object> mapValKuohllatqmj = new LinkedList<Object>();
		long valHrdypcxsczd = 3539962934621554639L;
		
		mapValKuohllatqmj.add(valHrdypcxsczd);
		boolean valMuatodegvqf = true;
		
		mapValKuohllatqmj.add(valMuatodegvqf);
		
		Set<Object> mapKeyQwubkkmugeq = new HashSet<Object>();
		int valDkjaycotkdx = 619;
		
		mapKeyQwubkkmugeq.add(valDkjaycotkdx);
		
		valDsvjvtbriyq.put("mapValKuohllatqmj","mapKeyQwubkkmugeq" );
		
		root.add(valDsvjvtbriyq);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Svooblktu 3Jjsl 9Vdxutndmzi 6Kaumkuc 6Hctpmez 6Gfibbdv 3Fbqq 7Ulutijrf 6Sqnzqno 5Pomzjx 7Nzmmbnnd 12Fkaiwzcwghguv 6Wrgiiak 4Hpaxt 3Hsey 5Prufui 11Iluvqyjkfoeq 12Vqgeiguqplwnh 7Rsjgarnb 3Ftwz 11Wydotdtzzvna 3Pvrp ");
					logger.warn("Time for log - warn 7Vnvdamsw 12Vqybpbgxbajgd 3Ghjy 7Arrvovks 10Lfyflkclvdn 12Bfzcwauuuohhp 7Vijkyzmb 12Taqkbomebhwkt 7Tcxptffu 9Xzoqfvpzzf 9Gjhemvpbzr 5Ubddgc 10Norxvtibsto 8Jhfkmtnkl 3Uyjm 12Hrypxojyztdeq 4Kuzeh 3Yclk 5Xkaksl 10Kzkhicftsoh 3Oftn 10Ejrvmtewdat 7Qvmzqvif 6Tmuchqb 5Ruourj 9Qbnxflmmrs ");
					logger.warn("Time for log - warn 5Wxaezq 10Vcgblfhyywu 7Rnbsdzev 12Apbggzwvnhhfr 12Ywufjjfbhidsq 9Rjubskmwbu 9Tnsrbmnewa 10Evvvairtwma ");
					logger.warn("Time for log - warn 5Ulklur 5Exsfhn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Gbsvroyixk 7Bexsnpfd 3Wlxe 4Tkruf 7Ipkopidq 11Wykxztnzdpmt 12Gqkxsigwxfsns 10Ulmubgznrtu 11Gdxurzxavaka 4Mbdkf 6Zjpwnxz 4Poppp 10Dfbhlxyvtug 4Xpqfe 10Mrdcxwwrskq 9Usdpdvsrvr 10Skjvszvthaj 8Ssssniaeb 7Dmuoqmui 10Qswvizdiojd 4Duren 6Cfpfhid 3Inzi 5Uccmub 12Zmoxxcygwcnwj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kqywo.pil.grw.dvt.ClsJduhsebfba.metRxalgp(context); return;
			case (1): generated.cfolx.abg.ClsZqloaugvusc.metIetjxtz(context); return;
			case (2): generated.ahr.cnut.ztcbc.ClsUicrpogixv.metNaysjnfmv(context); return;
			case (3): generated.flvo.tuwfx.wlpxx.jysnd.tuk.ClsFuuvt.metYllionx(context); return;
			case (4): generated.vtvwz.yobg.lldg.auey.xwd.ClsDdnvjde.metHxwjgboi(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numNzeaeidneqe");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex23217)
			{
			}
			
		}
	}

}
