package generated.rzy.sppai.eju.hupq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsPjendhgbojpy
{
	 public static final int classId = 87;
	 static final Logger logger = LoggerFactory.getLogger(ClsPjendhgbojpy.class);

	public static void metFwrqhbjeaj(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValFggzyaimzyt = new LinkedList<Object>();
		Object[] valRpeuaiyynrp = new Object[2];
		boolean valUwmccuzhpeo = true;
		
		    valRpeuaiyynrp[0] = valUwmccuzhpeo;
		for (int i = 1; i < 2; i++)
		{
		    valRpeuaiyynrp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValFggzyaimzyt.add(valRpeuaiyynrp);
		
		Map<Object, Object> mapKeyFspmqomfeyy = new HashMap();
		Object[] mapValRmhhxkqppnt = new Object[2];
		int valWzjcvracbfi = 829;
		
		    mapValRmhhxkqppnt[0] = valWzjcvracbfi;
		for (int i = 1; i < 2; i++)
		{
		    mapValRmhhxkqppnt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyTaoqiqpmjaa = new LinkedList<Object>();
		long valEvmnckcbgtq = 680731717806438909L;
		
		mapKeyTaoqiqpmjaa.add(valEvmnckcbgtq);
		long valJlrbqwbnnbw = 6222789739524338653L;
		
		mapKeyTaoqiqpmjaa.add(valJlrbqwbnnbw);
		
		mapKeyFspmqomfeyy.put("mapValRmhhxkqppnt","mapKeyTaoqiqpmjaa" );
		
		root.put("mapValFggzyaimzyt","mapKeyFspmqomfeyy" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Craddbboim 3Xhqo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Zwiboht 4Siuuf 10Fjuxmcghpjd 4Mxqqq 9Gurboqhiva ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zdmfw.qfic.ClsQmanwrctuzecr.metFgdlbhq(context); return;
			case (1): generated.fgkp.bvpjp.tisw.nifap.ygoni.ClsBmkimj.metEbkiw(context); return;
			case (2): generated.kcrh.cmo.yws.ClsBlekldezyl.metSkcclsizcjpfri(context); return;
			case (3): generated.fgkp.bvpjp.tisw.nifap.ygoni.ClsBmkimj.metEbkiw(context); return;
			case (4): generated.axdim.stv.ClsSaegiqo.metKmdsuvjx(context); return;
		}
				{
			long whileIndex21572 = 0;
			
			while (whileIndex21572-- > 0)
			{
				try
				{
					Integer.parseInt("numSstqscbocee");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metXspjdvsvflkh(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[11];
		Object[] valGmlipnxrbto = new Object[11];
		Set<Object> valNtddsfpkxrw = new HashSet<Object>();
		String valBgdmdppzuoo = "StrCsrqjhnzugm";
		
		valNtddsfpkxrw.add(valBgdmdppzuoo);
		
		    valGmlipnxrbto[0] = valNtddsfpkxrw;
		for (int i = 1; i < 11; i++)
		{
		    valGmlipnxrbto[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valGmlipnxrbto;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Nqsxe 12Gmytsijgfzmlk 10Jvzqrtjhbeg 9Qkvrovlhmi 11Hpvfepgwcerl 11Gyyonuijqjwm 9Apfuonocqe 6Zuyeaiv 6Nykkxce 12Sqkpxccdowfcx 7Nkyqnjle 11Iitcvoyuhajm 5Pemgwz 4Ygpxa 9Ydlcowgggf 7Cdmfkrxd 4Rjzod 12Hrnifbvhvwicv 12Bkbijortpyfkm 10Dxdjzhqnbwu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Cxvdcddlpxh 8Prfatrjnq 7Fiuvdxvh 7Lfmkyfhx 12Pkqmtelgbolwd 10Manzaojwujw 8Clmzzkunr 6Seqrlfz 3Myjs 11Egfexrtzxyry 5Mapomk 7Rhxbjlwr 9Wwpuvwaway 11Kbgmedyjrhpz 12Vsjaiicyevfjd ");
					logger.error("Time for log - error 11Udyobndgcrcq 5Gjweny 12Meemymuybieyx 6Ugchvem 5Pkcnda 11Ailjastkuokf ");
					logger.error("Time for log - error 10Gfmpwszfcyo 5Tpxygi 10Ttiqnfbrzre 10Kquzvbakgus 3Ehfu 7Qlphpqim 3Yhjg 11Bbufmmwjnhzx 8Pxpbxguwv 12Atzpcbjosfizp 10Gmxlzacavvm 5Iypktp 7Zbzcltli 4Lvlds 5Vtgzcy 11Ccultvllaqdz 10Ibakfrdyled 9Wpinnjnuob 6Gneosdo 6Rwxqjjx 8Tgbrsiuwb 7Bshuhkce 6Itdyvov 4Bwzyq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.app.atudj.div.xmvbx.csga.ClsIfahtjloa.metYzbiexwszx(context); return;
			case (1): generated.tyg.mzcly.ClsYmwmvdb.metOjvgmec(context); return;
			case (2): generated.zisqx.ukvca.wbokm.ClsZibjqxzov.metHqfpnzk(context); return;
			case (3): generated.zfv.ypwo.wuncq.ClsFveqnpanl.metApyyqiuohqp(context); return;
			case (4): generated.bhfun.zpnwj.czfe.augg.ClsEdcxpvndelttu.metLjdhznxjbmt(context); return;
		}
				{
			int loopIndex21575 = 0;
			for (loopIndex21575 = 0; loopIndex21575 < 2642; loopIndex21575++)
			{
				try
				{
					Integer.parseInt("numZppvwjtncpv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex21576 = 0;
			
			while (whileIndex21576-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metBiigjbvggllkr(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[2];
		Object[] valXenvwwxebcf = new Object[2];
		Set<Object> valGwjyfepqlcd = new HashSet<Object>();
		long valJbhvumorlki = 9169096498709100403L;
		
		valGwjyfepqlcd.add(valJbhvumorlki);
		boolean valMqrplnouvrw = false;
		
		valGwjyfepqlcd.add(valMqrplnouvrw);
		
		    valXenvwwxebcf[0] = valGwjyfepqlcd;
		for (int i = 1; i < 2; i++)
		{
		    valXenvwwxebcf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valXenvwwxebcf;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Tashdwqnrij 4Uoqoc 11Ldbwnqgfuqyo 4Efthe 6Edigdji 7Rddwollc 11Hfnucofnqsrc 4Urxgw 12Ocfibexuxdnda 11Cyjwpgyyjwep 9Wntjrzopvx 9Soktuhwjtr 5Qxkvrj 9Cabktbxysk 9Wqimmevxve 5Eburky 7Yxohnbwb ");
					logger.warn("Time for log - warn 9Tolilcqvjf 6Cpdqsaa 6Cufpmms 11Enwhbtlfsesk 6Ufuhbfl 5Thifzw 10Jljowvmelcg 3Jcvi 4Uwulc 11Fjynhuqcgrtu 9Flryawnzut 3Pozo 4Yhgbn 10Oqqmksnpfkd 8Lzcokrtzt 9Wsomjrwbwv 12Qfqkcjsqqsrix 8Dinzkozms 8Bacjlsuro 4Fmwxz 11Vbivjvrqtyps 8Zwtcyrduz 7Kxjxpkbk 12Srwsfemwlrmrj 8Nvmzeaejj 4Tsxac ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xbfov.nkh.ClsAkppmbind.metCoxqxndopdgbb(context); return;
			case (1): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metEvvtbxshkftg(context); return;
			case (2): generated.opcr.jgy.rftd.rkx.ClsJjouwg.metKtdrtpazip(context); return;
			case (3): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metWpheeqsxvjk(context); return;
			case (4): generated.spdv.axe.ClsZyjdutdtmcu.metUjulwqqjkfq(context); return;
		}
				{
			long varZqcrpqdtuog = (5413);
			varZqcrpqdtuog = (varZqcrpqdtuog);
			int loopIndex21582 = 0;
			for (loopIndex21582 = 0; loopIndex21582 < 5164; loopIndex21582++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metVwpivrvw(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valUvgzptziook = new HashSet<Object>();
		Set<Object> valCiwjbxupker = new HashSet<Object>();
		boolean valRnqbbljnlqb = true;
		
		valCiwjbxupker.add(valRnqbbljnlqb);
		long valPanhahbbhft = -7516165665117743620L;
		
		valCiwjbxupker.add(valPanhahbbhft);
		
		valUvgzptziook.add(valCiwjbxupker);
		
		root.add(valUvgzptziook);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Pozcrov 4Hrytr 11Wainszptbcxr 12Axhmszdkaeexv 5Uwsbip 5Urpjtk 5Zeados 7Vukqibcj 11Zrcqsqlvitxn 5Quzygw 5Qdgakp 9Uifsfhymra 3Eyoy 8Izczpcduy 5Asrwxn 7Tbheosct 11Jczbfxuxvhpj 4Ibalk 5Mnxlua 6Yivviug 7Wwdlgafo 10Risgpmavrgm 5Jmphek ");
					logger.info("Time for log - info 4Wttgi 12Iyybxhqepffdn 3Jwsb ");
					logger.info("Time for log - info 9Hjonfsbiod 8Zqdkojuww 9Auziwwqmij 7Svcwcbrp 11Nckfyejrxzmu 12Zyvlkdgpmrrru ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Mzijvekn 6Slqsabs 7Xwqcxcsz 7Hdkigmjq 4Wxdne 4Temng 8Lklmgepkj 8Zvwvkcwsv 5Jocair 3Omud 11Mviuywpbizbk 3Hqsl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rayp.ekfg.uust.ClsQhtttdalkvmcth.metYhiqkxerxikn(context); return;
			case (1): generated.aneiz.novw.ClsBxulfvm.metSgvcxn(context); return;
			case (2): generated.bde.vdlp.frn.zsrjp.eqwxd.ClsMvedn.metBrdejrtmmvqjyb(context); return;
			case (3): generated.aqdnu.puvg.gdad.ClsIxzvdsuksw.metWaxopqbol(context); return;
			case (4): generated.hor.ymu.xve.ClsFtiqqajkdixb.metBmlepaig(context); return;
		}
				{
		}
	}


	public static void metExrdz(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		Object[] valIhkhlbkfiao = new Object[6];
		Object[] valZiguefnzwkj = new Object[6];
		boolean valTjumzhxhndv = true;
		
		    valZiguefnzwkj[0] = valTjumzhxhndv;
		for (int i = 1; i < 6; i++)
		{
		    valZiguefnzwkj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valIhkhlbkfiao[0] = valZiguefnzwkj;
		for (int i = 1; i < 6; i++)
		{
		    valIhkhlbkfiao[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valIhkhlbkfiao);
		Set<Object> valPkgbprveofu = new HashSet<Object>();
		List<Object> valWvjuwgwurfz = new LinkedList<Object>();
		int valUlhrzwlemkj = 77;
		
		valWvjuwgwurfz.add(valUlhrzwlemkj);
		long valPedgzsrgttr = -9125628919200797161L;
		
		valWvjuwgwurfz.add(valPedgzsrgttr);
		
		valPkgbprveofu.add(valWvjuwgwurfz);
		Object[] valWzrsvrdcrdk = new Object[2];
		String valYtlwjcxygod = "StrQbulsnrazlt";
		
		    valWzrsvrdcrdk[0] = valYtlwjcxygod;
		for (int i = 1; i < 2; i++)
		{
		    valWzrsvrdcrdk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valPkgbprveofu.add(valWzrsvrdcrdk);
		
		root.add(valPkgbprveofu);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Cplhqpmtlc 5Jrzopa 12Xqnbnlswqszan 12Isionzdnzdlbt 4Nnwhd 7Yanxtisx 6Fbuxosg 5Synznd 7Ycazfiiq 6Cgemltw 6Wdymiyd 9Qzktwnbfsv 10Asrliemwqhb 6Cqomjii 11Yctrdyiahoky 8Swpdiqihq ");
					logger.info("Time for log - info 4Xokiu 8Pscdqzjyv 10Ipmkhzzzifn 8Bzvhhcftj 9Uwpfbpvnin 4Mdgno 5Nyhsff 8Gxxjxadmx 11Uqzizorsmjkw 9Pwxkqlfnpr 5Ibzsan 7Rtfkilqy 4Fmmqb 12Vlqwwhukcudux 10Bfvmfcrrbtd 6Kwcvdfv 7Fffnralu 5Ninjmw 8Mvqjkfnxy 12Tbkrqqsiglinh 10Pawaitxuuxu 11Einlqtcgmxyl 10Sirrqluhrsq 11Ckaagtzbujsi 6Cijdhju 9Iwjzzcxkaf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Cackzkl 6Mxskvoz 5Kdmtmg 6Badgtzc 3Chiz 7Btjcljmc 3Ybwf 9Fbuqolgylp 3Jghz 5Oszqfb 3Zere 10Uxqghvfeiwp 5Sirihw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lwjvh.jknhf.givvv.ClsBgfhlg.metVudhurmppkohax(context); return;
			case (1): generated.gar.mdz.moh.znab.ymyxm.ClsZduvwawzb.metYcebrjtxrz(context); return;
			case (2): generated.gfpc.pbcpl.isevo.syh.yqsp.ClsDuasxzsefdmugn.metAprvs(context); return;
			case (3): generated.gasq.isr.fpndy.jhzr.ClsNxizwkdumgga.metFwsdurntbm(context); return;
			case (4): generated.bywcf.xycgt.wqguo.ClsDsjomnr.metNwhqqalj(context); return;
		}
				{
			long varFuufypueplw = (Config.get().getRandom().nextInt(733) + 8) + (5121);
			long whileIndex21590 = 0;
			
			while (whileIndex21590-- > 0)
			{
				java.io.File file = new java.io.File("/dirRcvtsibctow/dirEikvmunolcf/dirWrlngjhuuoh/dirEengyesllic");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
