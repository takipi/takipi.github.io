package generated.kyd.fxg;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsVvcevjvyz
{
	 public static final int classId = 108;
	 static final Logger logger = LoggerFactory.getLogger(ClsVvcevjvyz.class);

	public static void metSjikefnlhdbobi(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valGkayarkrtqz = new HashMap();
		Set<Object> mapValZusoylofryf = new HashSet<Object>();
		String valLubshogomlj = "StrMrkzinulmpi";
		
		mapValZusoylofryf.add(valLubshogomlj);
		int valYeqtskmivry = 364;
		
		mapValZusoylofryf.add(valYeqtskmivry);
		
		Map<Object, Object> mapKeyTgtjckxvnyt = new HashMap();
		String mapValJqneemwkjiy = "StrWrfxkhmnfvj";
		
		int mapKeyCdpqoqfxrlz = 126;
		
		mapKeyTgtjckxvnyt.put("mapValJqneemwkjiy","mapKeyCdpqoqfxrlz" );
		long mapValJdkrryilnsq = 7642386385813757954L;
		
		int mapKeyNkazqcngjow = 446;
		
		mapKeyTgtjckxvnyt.put("mapValJdkrryilnsq","mapKeyNkazqcngjow" );
		
		valGkayarkrtqz.put("mapValZusoylofryf","mapKeyTgtjckxvnyt" );
		
		root.add(valGkayarkrtqz);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Dqkfd 12Nkryleionupjy 7Knyonxtx 7Bonixmyj 12Qolgcjrcadiyl 8Niismqkkb 11Muowjaulhykg 6Xftwkfn 5Vegoea 4Ltakp 4Wpxic 8Dkqmqfzqp 7Nvvxrhwh 7Qjnjzbvt 7Wcjjezxx 12Lvmxzyshmpxin 10Lmeqliciyoy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Awmznkhwxynfk 10Quhtopouhhs 6Dddmggi 12Hzyehpyrttnmd 8Jnsigdowy 5Gjnzyy 6Hgbnxvj 10Aezlcbikhba 9Rnclccbxmq 3Tzxo 9Riwgslywne 7Ggqphalp 8Xxgwsykax 3Eykg 12Dveqeghnnewlz 10Qixgsbvxjff 3Arpu 12Rtgkagncdsbjn 7Efryrtqe 10Gzramueydma 5Ogmkqs 4Pglpt ");
					logger.error("Time for log - error 9Qftidsnkhs 7Rrzxpthx 9Mdkpcybuxf 4Shdpx 12Bxgxrmxbizfww 12Iyjapojqkgyci 7Yvvqjyxy 10Irobuzsbtiy 3Wnfr 8Apnlupwxw 9Sykoxznxoi 4Lyvqu 7Bkjbgjhn 11Kgixqfflmkiy 6Nocizeq 7Jwdmcbfc 8Wpaxtkikr 10Lrzcquqhcaa 11Rfsazbxflsbw 4Ixjck 4Vfnuj 9Aozxrjidyf 12Ccbcfxgrrkvxq 4Fpacy 8Vucwhoebm 8Fmmoleybh 8Pjucubbct 6Crrwgmf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rludj.zqn.tuc.ClsSdrvvvm.metSmvhpgejrya(context); return;
			case (1): generated.dxrru.qphkk.sigfx.fho.qtrx.ClsXgcfqnkax.metKgwdczuyoh(context); return;
			case (2): generated.exb.zww.kausx.ClsMnvrore.metBgumsxik(context); return;
			case (3): generated.mbf.jauhv.phe.sowu.arz.ClsAtgovrsbvzxguw.metNzrbcudifbng(context); return;
			case (4): generated.vbmu.nqy.tvok.ClsTqtbdjb.metQkzwdoc(context); return;
		}
				{
			long whileIndex21967 = 0;
			
			while (whileIndex21967-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varOatbauwpdap = (2751);
			int loopIndex21969 = 0;
			for (loopIndex21969 = 0; loopIndex21969 < 5096; loopIndex21969++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metAvlkamwowqupb(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valCzscqporqcy = new Object[10];
		Object[] valNcyjlumgnjf = new Object[8];
		String valRhngdvqlmey = "StrOsucrxgoeqz";
		
		    valNcyjlumgnjf[0] = valRhngdvqlmey;
		for (int i = 1; i < 8; i++)
		{
		    valNcyjlumgnjf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valCzscqporqcy[0] = valNcyjlumgnjf;
		for (int i = 1; i < 10; i++)
		{
		    valCzscqporqcy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valCzscqporqcy);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Ymueiungzaj 8Nzfqxpqte 9Mvutyjgifm 4Htakw 11Scmpkewwsosy 10Vvvdagohuwj 8Rmqpxfuvu 9Mtzvblzypy 7Jimzpmky 3Fflf 8Tgoxpdjar 3Arni 9Ygiubdjyef 9Gbojepibjn 5Buvubs 7Vuqylxbi 11Fvtdmbrzdumq 10Ftbfkoxjmke 12Wjlboactzuolo 5Cngnxf 12Dttkusoljpluh 6Ioypmlq 7Kyvkpkfa 4Rdnpq ");
					logger.info("Time for log - info 10Smfgrurhmcs 4Djrvd 6Tfefnyq 12Wtafsdbvyiqxs 8Ezxvhlnpx 7Yjcpzeyq 5Bruxhc 5Uqhfuy 3Tzbo ");
					logger.info("Time for log - info 4Pdewr 6Srhtdgv 3Veju 9Gwfjsjdalg 10Coxduqiokun 8Keqoscbcm 7Yhqcsiya 3Wwvm 3Kbhi 3Qsss 10Nwjoobmccfl 7Rtyegzov 10Dqimfyritwh 12Kohtoxqrnfwtl 8Rqpnmibfc 3Yzss 4Iusrv 8Xzzvyjnac 5Qkxezh 9Vofuhcgtal 11Urfbytfrgyjh 7Usfqwrxt 8Sauoreenr 7Xrklmbrc 12Prjhajpjbttep ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Gxrfascxhmkfe 3Ytnj 9Tfteaiocgy 11Rwnwapvewjjk 4Huvdk 4Ckkri 5Ywwnqk 11Tyanijiorrqv 6Iiuawdz 9Oinzicovpx 10Eitndjvizjt 12Fqpptxtkzbzuq 5Iptdni 12Aqbmxzhzubzmz 5Evqpcx 11Wuzmecenxahc 6Ocejftz 5Xgritt ");
					logger.warn("Time for log - warn 12Dacnkqswsihay 11Wffqgkxeoqnk 11Mfslblhvnurs 4Ilqri 7Yoonnqjj 8Vamtzomtp 3Kkiy 9Cmqagngrgc 4Ckrnw 4Lsdzj 11Cowhknyouirb 3Onek 7Axqetdzl 7Ttiwzisi 3Fvae 12Huqqjxkobbwef 4Bripa 11Xmcvsgispqln 12Plgetttbyagul 3Aefx 9Mjnnkbjoom 8Ybotrgpot 5Srtyfb 12Mvkjtnhmdstvr 5Syfwqe 11Yzszdcacctgj 5Nzzvsh 10Kwgjexsdxwk 8Cotowhtyd ");
					logger.warn("Time for log - warn 4Rbysj 3Wowa 11Jnftgwmvylun 7Omlnwimt 6Tgfnkps 9Phcbuzsmdj 5Birrov 6Eowntgw 9Ffdolrwwfy 11Ambkkqgjtzxn 9Kjuhjttgpl 12Ebomagksmtgtt 10Mgludvcrfip 8Lqajhekaq 9Hcbeplcuuy 4Qzypw 10Jveznsqbfqd 6Ykaivzo 11Qkkvqqrlxymo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pef.kybz.yzpf.dzs.obqpv.ClsKizvnatyigi.metVpeqkkprfd(context); return;
			case (1): generated.gfpc.pbcpl.isevo.syh.yqsp.ClsDuasxzsefdmugn.metSkowruz(context); return;
			case (2): generated.zfv.ypwo.wuncq.ClsFveqnpanl.metApyyqiuohqp(context); return;
			case (3): generated.nhgg.zrfev.xud.glekl.ClsBewmjgrswbo.metWsxyvoaooe(context); return;
			case (4): generated.tyg.mzcly.ClsYmwmvdb.metOjvgmec(context); return;
		}
				{
		}
	}

}
