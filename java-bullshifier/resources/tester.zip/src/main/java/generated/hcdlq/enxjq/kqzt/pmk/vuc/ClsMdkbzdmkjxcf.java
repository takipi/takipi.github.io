package generated.hcdlq.enxjq.kqzt.pmk.vuc;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsMdkbzdmkjxcf
{
	 public static final int classId = 57;
	 static final Logger logger = LoggerFactory.getLogger(ClsMdkbzdmkjxcf.class);

	public static void metOfbbjymp(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valBxipysqnaqe = new LinkedList<Object>();
		Object[] valJgudiuqlmjq = new Object[7];
		String valOyyzfswmfze = "StrQagktbqmxow";
		
		    valJgudiuqlmjq[0] = valOyyzfswmfze;
		for (int i = 1; i < 7; i++)
		{
		    valJgudiuqlmjq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBxipysqnaqe.add(valJgudiuqlmjq);
		
		root.add(valBxipysqnaqe);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Kthoadedwxrj 10Qeqptpxuprb 8Ikrutzzro 11Zzcsuzgnoqtd 7Ysfzoxvy 3Qque 10Auupthrkhyi ");
					logger.info("Time for log - info 8Sefqsgovy 10Qkuzwbmkupl 5Wexcww 3Znmo 11Xxkzjhoksbxt 4Xwdwj 7Pegxpecr 4Urxwp 6Yrpttsu 6Ysynnju 6Bclwdcf 6Hqsxqoj 8Kuuvcawbk 9Mrarixuncz 7Czpcwooe 6Fjfkhmq 7Lbipzdiu 7Jscuxvwl 9Jkbexaznrr 11Ksxposkuobye 11Nxgqlpjzbccb 12Emydfjomzloon 11Fqrlueazpgcn 10Ptnozjraduy 4Crajb 10Ipgwvvzdxbr 7Lmzvztkh 7Wtyjplqk ");
					logger.info("Time for log - info 3Xetm 9Ogydgvrrij 10Pinvsejcdis 6Juqfguc 9Kjsfmdekzk 8Zmjiqyyvh 11Ruzspfopkuwf 5Fvndbz 12Orytpuhcpozpz 3Bzbc 7Rntdhtva 8Khbocuhxt 7Zzktnzaw 7Ifjsltob 6Oezuhjy 7Nxehkagi 6Anzrhrr 5Eegeym 10Tdylwtftuhh 6Khaluqp 9Debiqjcfaf 6Jrwszxg 6Qzmuyna 5Ugcdyi 10Srdtmotsoxq 4Zvwxf 7Oyfpjwnl 8Veesqxtib 9Utuplslhex ");
					logger.info("Time for log - info 4Elwqo 8Ueyzifios 7Hlugditq 5Aeyyan 5Nkrqkn 8Qlgoolhqc 11Folyafmiogqu 12Irpqfawxzrqwm 9Zllhxnhonc 3Bujj 8Rqrluibda 10Etaoamngotj 12Wteupprwjekku 9Imbqzdnomw 7Qqkhbren 10Nlgeegwaczr 10Fiooofkgyej 6Stvjhrt 10Idvxybwdltx ");
					logger.info("Time for log - info 5Xstnic 3Dxep 10Exmhmcsezci 10Osqvtaunyoi 6Yenhnho 7Jluujboj 5Miyhuc 10Eugtatsxdkd 12Fimcnzvwechjs 7Girkhtck 10Qruipcoedxa ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Mjiexlw 10Cqzzlkcxzxv 12Rlwabumvcxwms 11Hggcmcayymfb 11Ltqmhzpypzfg 9Rbzovcfnwq 6Nhekaaw 6Hzfdiab 10Dapskorltbk 7Wnjcrttq 6Uwtvdse 8Ftsqmsptj 8Addyecdoe 11Growkirwyikw 6Znaswtm 3Wnkt 3Nelq 12Rbycioewgcijl 5Dtvsap 4Zbebr 11Zstcnepvinol 10Ufdmjqgwism 9Cmqkcsqarm 12Rekikigyppdbt 5Hmnrzw ");
					logger.warn("Time for log - warn 4Kmrtp 3Gxdm 5Opmrak 4Pswff 8Xcdodfkus 6Mmizbob 6Qitmyae 11Wyawyquyxfsb 11Olfblhxlwups 7Eundejxo 9Svryduwmgl 12Gvxtcjtvgwgci 9Yuwvqszzpv 4Wbuky 5Sbekkp 10Uhuegxzccmr 3Jugk 3Gcro 10Tnwwmrlmkmz 7Nobkmezb 11Igvvfxccfkau 9Yhmdrqaezo 6Hfpkkmb 3Ahts 12Szgpxxawvrnbn 10Bsdrtgwsclg 4Euoar 3Kdxs 12Gjhffhwvlbcxp 7Puwwfqhq 5Drgpoo ");
					logger.warn("Time for log - warn 4Dlkfy 3Bamn 8Qaatsfqff 9Xwvjqqshbh 10Matccvlmbns 10Uefwmsbzlnl 9Skdhcbdwki 3Bafj 11Apbdcjintpif 9Jnsansweiv 10Qawvjtknkaq 6Yrkeagg 9Ycgcybzqgb 6Olkjgzz 10Ldqhdfzucio 7Prodcvym 3Uisn 10Smfgcfzfjuu 10Igoiffnyhbf 4Wtvra 3Zbld 4Bruqz 7Vjtorysb 6Ghpzngs 5Qcghof 12Kvrgzkepcvgec 8Eostlkeoh 12Dfrzgihttmapi 6Sacrkdq ");
					logger.warn("Time for log - warn 5Idhvxs 11Izxqbtfapyej 10Oizagxcsisf 7Hbprporz 4Fitlz 4Frufe 8Wcbwqmykb 6Cdyqjzq 6Sjxasbg 9Nmlmeqbhth 6Vhfwhok 8Udezvjyqm 7Mnprpmkc 9Wnxjlbpvuv 10Zojumbfracu 3Owxb 6Emfgjmj 12Hxzxuodfcshck 4Igxdp 10Jujwmlvnral 12Peuqmezagupyp ");
					logger.warn("Time for log - warn 11Lkxeuycrrlvo 7Slokszxg 5Hfvikd 11Espwlbitynsz 12Lavvwklsnafxx 11Yoyhuhkfrtkr 6Tuuvhau 4Pkbdw 3Ypvi 5Hsdrtg 3Kols 4Mhpvm 4Pzgaj 8Lgmaqagrv 11Srvtukejcfsq 10Iejgmanaeur 3Lgyf 5Xovrat 10Fwfpkrfccml 11Keijsdidplev 6Weckhre 4Zqlhz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Pedulutww 7Yreiojny 11Cnakajlqyzqy 9Bfuprmlwna 4Crdfd ");
					logger.error("Time for log - error 10Sbdezmysxnf 7Altjhpnw 3Xfhr 3Desh 9Kajdbnwfxm 10Djcjdzqblse 8Kxqsebtcv 3Pgar 12Ewwpxmnpcywon 8Hlwoofyak ");
					logger.error("Time for log - error 11Vrpxnwqvxapc 10Damjkqhgmjt 3Vvhz 7Zctlizhp 5Anrwjs 12Oaltchhsiirkx 4Wjgop 4Lriqh 5Bzasoe 12Bbtpcdmzgstev 12Aicrbhrsoyzka 9Bvxjnpaseu 4Fhuqp 8Zfhtzpfhu 12Xxjopqbnybrce 12Pixoatdbchcxu 10Ffahxhjjpwh 3Hgqp 12Wylnegmkovzot 5Gbtzil 9Bxsftlhwbi 12Xmtjvliaaorpq 9Knyqwpdwzu 4Crqcw 6Pycxomw 4Jcghg ");
					logger.error("Time for log - error 8Sdbyxvhre 5Qblrnw 8Piunwamek 6Lhwgnhh 5Syadjw 4Smbel 4Owmxi 8Brueceohn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wgclb.xej.jxqsz.ClsVlhpzchb.metWmoop(context); return;
			case (1): generated.crkmz.uuny.smq.vvmxn.khxb.ClsQbvzuhroxdituh.metVqzfw(context); return;
			case (2): generated.fhy.qnk.brj.xhy.ClsYgumeudbf.metEcwaz(context); return;
			case (3): generated.psehw.ylq.mvtup.ClsZvqertch.metWvhxsckimqa(context); return;
			case (4): generated.spdv.axe.ClsZyjdutdtmcu.metZnyfnrroyfp(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(1007) + 9) + (Config.get().getRandom().nextInt(549) + 4) % 188315) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varCgeytmposbh = (Config.get().getRandom().nextInt(254) + 1);
		}
	}


	public static void metWuruvmffywn(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValMagmhfhkeot = new LinkedList<Object>();
		Map<Object, Object> valGadykbpbnsw = new HashMap();
		long mapValUvgfszwnckc = 3105914841395648061L;
		
		long mapKeyYmnhdbvhhdf = -8877903717408477860L;
		
		valGadykbpbnsw.put("mapValUvgfszwnckc","mapKeyYmnhdbvhhdf" );
		String mapValEqsdwkhvsfw = "StrPqsgfrpsohy";
		
		String mapKeyGezmihjqwmh = "StrInyumtwhuvw";
		
		valGadykbpbnsw.put("mapValEqsdwkhvsfw","mapKeyGezmihjqwmh" );
		
		mapValMagmhfhkeot.add(valGadykbpbnsw);
		
		List<Object> mapKeyQerusoeyven = new LinkedList<Object>();
		Object[] valEpawqznzmqg = new Object[4];
		int valCnlqqsvfzns = 916;
		
		    valEpawqznzmqg[0] = valCnlqqsvfzns;
		for (int i = 1; i < 4; i++)
		{
		    valEpawqznzmqg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyQerusoeyven.add(valEpawqznzmqg);
		
		root.put("mapValMagmhfhkeot","mapKeyQerusoeyven" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Bcdyfyrsafp 4Qkqtc 6Zumelue 11Azdttsecxwhf 12Ucixxxwvrvyiw 12Orejgqkkvtpwe 5Kjmphb 12Orxqzjobxvxrs 10Hdvtlhlpkbq 11Nhozbvudwyvp 11Qguzneyyjjdl 3Anaa 11Lwserqrfrnzi 7Peobftnw 6Mkgcmxa 7Vegfeubr 6Bkqexcn 4Sigim 5Qtnbso 6Dcsyjlo 8Ecxvwwdmi 11Bdlrokipwiea 12Xmkufytdxkllj 7Btszgzfq 4Iqvyd 8Raztvklpb 6Thbmkzv 7Yweynctj 11Lhlonkdeoxcb 3Cayu 3Nvin ");
					logger.info("Time for log - info 3Tyeq 3Myvr 8Zcsttrdzl 6Prfymjp 7Qhgaiyxm 12Pjtgcactapieb 7Qwxlqgen 6Kmwfqeq 12Gksqizmdehieo 9Mvstoxpiss 12Eypikzwcuyscz 8Aiwtoilhr 3Naey 6Mbdauew 5Obwgps 5Zdhvgp 11Nmwoogvdozos 7Llckmusw 11Fkqescapwzqq 12Onxrezdwkibfv 6Rvbrdvz 10Spojemuylwq 5Zkxjbm ");
					logger.info("Time for log - info 4Yrurb 4Wdgyu 9Xrmaypenmu 8Pzpretbgo 12Koucezgyngckp 12Vrnosgyvhkujl 9Whdnejtgqb 8Aocuhbyov 6Mtmkuim 7Gtjrjzno 11Krymjphlhuxu ");
					logger.info("Time for log - info 6Dcqjcye 11Grygmbjizhec 9Gyrqdhfnyz 7Sybpbrqs 11Dstvotolsdwf 8Otehjoojy 12Jdaipnxcokpdk 11Trohuevrpded 7Iuothmtm 6Mmeaxqb 11Fixeleozczza 10Lfjhswscvwa 9Pthyorubjh 4Hzswi 5Ewgzlp 3Lfaa 12Ffnukikeseunq 12Dzcgbdjqdgupa 3Bddx ");
					logger.info("Time for log - info 12Gcuefamhrcfwe 3Nnyy 12Bkohxexwbzoka ");
					logger.info("Time for log - info 6Bibcyiw 3Tiea 9Mcrwshjjxz 8Fflkesyuw 12Nrjlflnppqych 8Viyomqmcq 10Rkdzgnmwxfg 4Jkhtm 12Rfiuwyjewligr 10Baznxvyfuqp 12Cdinbbswklqvk 9Yysmkciajg 5Jtgalb 3Pbib ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Hpaxxolkjtiu 10Xxoybcswceq 8Lhtwprlau 8Ogmtwnyfv 3Xgnx 4Ldsfv 3Mikn 4Rmqva 5Oxwvae 6Ukvafyv 10Rxmputxdprv 4Reqog 10Begotxygrry ");
					logger.warn("Time for log - warn 12Ygdibsxgoqoxk 10Qjahkxwknse 4Ttyzi 8Hbbircwfm 11Kofdsivechef 3Rzqz 4Ylwtg 9Xlufdrbnxy 9Tvcazsfwgd 8Phlyugmis 5Vflswy 11Pvtjhbpuofdn 10Zycmblolplr 5Lzbqrw 5Uwqqeq 8Ypwrjyohf 9Efquyarrak 3Cahs 4Kqxre ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Sbferindxg 3Yeda 6Ujdlsfg ");
					logger.error("Time for log - error 9Mdzntmqxfw 12Zqadoiepepqbz 6Okwbpup 11Tffhahxpzhfy 6Vghhill 4Huzqe 9Svkgkrvhab 12Jtpyourdnsuwl 9Zgemmkkpjq 8Fhqdajfzd 4Djntp 5Fzzxmg 6Xluxred 5Nkglqq 7Dzmmcdzt 7Lxewseif 4Beoiy ");
					logger.error("Time for log - error 10Qrvawtllyyy 8Bpenzvsqe 11Pfwdrgtjkhuc 3Zryc 5Cpsfpd 10Jgfqlzhxera 12Rdmxqcvxwupyq 4Yovnm 3Zdjj 9Anxkeydwmh 12Efvrbdnjydsbu 8Trkcmdnno 10Qjdoholajcx 3Qgls 11Nxqdcctosisx 5Lwxelu 8Eexwqilyi 10Himwbnwdkbj 4Xmesh 8Jbjgkkifw 11Rskzatxdjrwh 11Pdznbhvtfzuj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ebdo.cied.ClsIqlmeepdcmuqo.metKtzhn(context); return;
			case (1): generated.ionxn.lbvax.tzn.gjpzs.dvu.ClsMscwr.metOajkgn(context); return;
			case (2): generated.dvks.jsbpi.ClsXlatniflz.metIhawpoyjsfgfom(context); return;
			case (3): generated.gucbl.hxhv.qux.siytf.ClsVpdrty.metXdgufsukawoajk(context); return;
			case (4): generated.hcl.ivd.nxcam.ClsQkvrtnftml.metUkmqfsqzjz(context); return;
		}
				{
			long varPqsygqplbzq = (Config.get().getRandom().nextInt(575) + 4);
			varPqsygqplbzq = (7300);
			long whileIndex21063 = 0;
			
			while (whileIndex21063-- > 0)
			{
				java.io.File file = new java.io.File("/dirAysrywjwbrf/dirLdbhdmdgcku/dirIkewynsptsl/dirNctewkcbtxc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
