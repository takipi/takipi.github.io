package generated.iotb.mlgn.hcur;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsAdwtsoupvuwy
{
	 public static final int classId = 54;
	 static final Logger logger = LoggerFactory.getLogger(ClsAdwtsoupvuwy.class);

	public static void metTfsczzma(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValSaavkaotokt = new HashSet<Object>();
		Map<Object, Object> valLmelazambdq = new HashMap();
		int mapValPibbxervfdr = 557;
		
		boolean mapKeyKspnytjppvn = true;
		
		valLmelazambdq.put("mapValPibbxervfdr","mapKeyKspnytjppvn" );
		String mapValRajblivpayz = "StrVgixqfowvfm";
		
		boolean mapKeyHfnpltmjtud = true;
		
		valLmelazambdq.put("mapValRajblivpayz","mapKeyHfnpltmjtud" );
		
		mapValSaavkaotokt.add(valLmelazambdq);
		
		Map<Object, Object> mapKeyKajhmdeygmn = new HashMap();
		Object[] mapValRphvugseeqw = new Object[11];
		int valCzrlyokpyrx = 770;
		
		    mapValRphvugseeqw[0] = valCzrlyokpyrx;
		for (int i = 1; i < 11; i++)
		{
		    mapValRphvugseeqw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyNiackermgrr = new HashMap();
		boolean mapValYduxrcuqkra = true;
		
		boolean mapKeyTfrmmhoingl = false;
		
		mapKeyNiackermgrr.put("mapValYduxrcuqkra","mapKeyTfrmmhoingl" );
		long mapValJcievxjcyho = 1762528055320993315L;
		
		String mapKeyBvypzqiknji = "StrWbijntsutmm";
		
		mapKeyNiackermgrr.put("mapValJcievxjcyho","mapKeyBvypzqiknji" );
		
		mapKeyKajhmdeygmn.put("mapValRphvugseeqw","mapKeyNiackermgrr" );
		Map<Object, Object> mapValHutsojwjvvk = new HashMap();
		String mapValMnadyirjvsj = "StrVjrakekprzs";
		
		long mapKeyPcwsmkqytbp = 8275489927363829541L;
		
		mapValHutsojwjvvk.put("mapValMnadyirjvsj","mapKeyPcwsmkqytbp" );
		
		Set<Object> mapKeyKcljhjpxwdq = new HashSet<Object>();
		long valShtvjamwglw = 7681941068890581819L;
		
		mapKeyKcljhjpxwdq.add(valShtvjamwglw);
		
		mapKeyKajhmdeygmn.put("mapValHutsojwjvvk","mapKeyKcljhjpxwdq" );
		
		root.put("mapValSaavkaotokt","mapKeyKajhmdeygmn" );
		Object[] mapValRjyyihhllzd = new Object[5];
		List<Object> valIybwemtfqbx = new LinkedList<Object>();
		long valVtlrfrdwkhz = 7958965660117752292L;
		
		valIybwemtfqbx.add(valVtlrfrdwkhz);
		
		    mapValRjyyihhllzd[0] = valIybwemtfqbx;
		for (int i = 1; i < 5; i++)
		{
		    mapValRjyyihhllzd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyHxbxmxqtbea = new Object[7];
		Map<Object, Object> valBraaficddwx = new HashMap();
		long mapValHfwwofebosn = 904689330454017667L;
		
		boolean mapKeyCszyhtlbryw = false;
		
		valBraaficddwx.put("mapValHfwwofebosn","mapKeyCszyhtlbryw" );
		
		    mapKeyHxbxmxqtbea[0] = valBraaficddwx;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyHxbxmxqtbea[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValRjyyihhllzd","mapKeyHxbxmxqtbea" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Risu 6Rdrdeya 9Gllskjilnz 11Odyvfceuclsu 7Wstqcvvc 3Julm 7Mdqtrwwr 8Dequajpmf 5Osbyhq 6Hwitlyu 6Kaayrwb 4Hrdxw 10Jfyjunofykj 11Cyzwjjusrmdg 12Rkpyxirlbdbuw 7Fihdvpmd 3Jaaj 4Ctlmj 7Uuodgchu 7Wgdirnbh 4Exgjd 8Lzlddxjrk 6Fvrfqgp 9Myvjdewqsk 8Eobnvrquq 7Tzcweftn 7Cfytwqxy 7Pechkgbh 6Ujvwshx ");
					logger.info("Time for log - info 11Ukeekmatypxx 12Lpesrcetjxere 12Wfoxgxruytxfu 6Vdusups 7Cujrcgga 9Wnjskpmdqd 12Kjzzvzjfuicqw 10Xfjvxmocuns 4Hzawp 10Bsgjdpiendy 11Tatjqsbqvwuz 3Wbqs 6Rptdgih 6Cwashra 6Mqnyimi 4Ldwdc 4Euvxf 11Nuaratifzivt 6Yrxpjht 5Yjdsxb 11Slnhzoavupjj 10Ochzlirqobg 12Exgucfnevptyl 5Vrydmq 12Xcdrezoxivdzc 5Sponmn 9Smgpdlaikm 3Qgsu 11Dlpayhndfqbl 9Rbxglwnrvp 10Pstxgoddxvj ");
					logger.info("Time for log - info 5Odbaad 4Uucyd 3Zwcr 12Wxqgzsubgtobu 12Fmdkbnokinuii 8Gjlinvkxp 5Tyanxy 11Lmmqmofbqvke 7Rsrqjhie ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Bjibiqfdleaz 4Rxhiw 4Qrsqh 3Yyoc 4Bjbee 12Trykuluzszcmw 6Wuoiypn 4Bzlml 8Ajjhnzhrc 6Ujxwqnq 12Rghapbhihmqjw 11Mcvuxnntbaeb 6Naekcvl 4Wfkuz 9Cofdiuvzjv ");
					logger.error("Time for log - error 7Qbwouuld 6Vcbxioa 8Ofahfehgh ");
					logger.error("Time for log - error 3Yjkr 5Epoxxs 5Gvvtqn 12Ejjrjjphqjswh 7Cluvdrrf 12Fjruasxibbiqh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tcpo.xhov.ClsRfokukcdi.metPgyzztnxhblraq(context); return;
			case (1): generated.ncx.nab.ijte.fihzp.ClsYfnojfmzyj.metAquhkuzrkefkt(context); return;
			case (2): generated.tcpo.xhov.ClsRfokukcdi.metFrfxj(context); return;
			case (3): generated.rprz.twb.ozdl.ClsMnahuieydv.metLsuejvaasjahy(context); return;
			case (4): generated.psl.vgj.rgm.ikl.ClsWqomoi.metBvzuwktozvf(context); return;
		}
				{
			long varOxlwvwdojpn = (Config.get().getRandom().nextInt(53) + 5) * (Config.get().getRandom().nextInt(99) + 9);
			long varYzdempfteoe = (690);
		}
	}


	public static void metMpwarwswa(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valYxytygujkqr = new HashMap();
		Set<Object> mapValEzbiegcqptw = new HashSet<Object>();
		String valEcjcqmbplgh = "StrJqpnlutoglk";
		
		mapValEzbiegcqptw.add(valEcjcqmbplgh);
		int valXurekcrychr = 35;
		
		mapValEzbiegcqptw.add(valXurekcrychr);
		
		List<Object> mapKeyMozphibspni = new LinkedList<Object>();
		boolean valZhzvvdjtkhl = true;
		
		mapKeyMozphibspni.add(valZhzvvdjtkhl);
		
		valYxytygujkqr.put("mapValEzbiegcqptw","mapKeyMozphibspni" );
		Object[] mapValFyunaloptuv = new Object[10];
		boolean valXfpxpumzgwc = true;
		
		    mapValFyunaloptuv[0] = valXfpxpumzgwc;
		for (int i = 1; i < 10; i++)
		{
		    mapValFyunaloptuv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyZhagrezcqmw = new Object[8];
		int valQuuntcoldkm = 272;
		
		    mapKeyZhagrezcqmw[0] = valQuuntcoldkm;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyZhagrezcqmw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYxytygujkqr.put("mapValFyunaloptuv","mapKeyZhagrezcqmw" );
		
		root.add(valYxytygujkqr);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Dllfvcvayqpbi 12Tajvmbzfiatzu 3Tovs 11Ufpadfmofuer 12Eldtnqrfrjdht 8Zpxmmoend 12Plgxrfixvgtkl 8Hmdgyymyz 10Lwmqwrewrej 9Rfhbfqondz 10Gsqaoolighm 3Eimj 12Bcfcaxvfzlgnk 5Voejzl 11Mfggnwgmgzaz 12Pxhuuwprjjpwj 11Bgwvlfnkjcru 6Gtxvock 4Gimch 4Zvgbi 8Kuimfcioz 11Uwgbsbwucdmk 10Lnmmrubvelz 9Qgqgmrbnaz 8Htavslyle 7Tohuzttu 5Chhqzl ");
					logger.info("Time for log - info 5Ulaazh 8Sfjwqnueg 9Lokgckmjcl 8Nkekablmr 9Swdyoyutmx 7Oxbgvwnc 10Jugdyqfjqvf 11Bpejlbjjopmi 11Pwbtxwfrkdxh 8Ekuclafcs 6Jlfdsci 10Epqnrlyuzoq 5Hbgxig 12Adhrtlkcfbyzy 4Usdjm 4Lbsrs ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Tffcmixswm 9Wxglpifrbq 4Xdsnn 3Nmuj 6Afztovl 11Akfnpdednspz 4Rrzox 8Lysthcdom 12Ghmutjrhlsgsk 8Mbxzuucbs 11Eppkeynwlghk 8Kjpuhcpaz 3Efsr 5Yhaqtt 6Eeeyrll 6Xuqsqxn 6Mgmwnyy 11Wfnjnwgmibth 4Seatd 6Rcntjfa 7Sblvxwjq 6Sxxlbtk 9Jlpdmodoql ");
					logger.error("Time for log - error 4Oyqsx 6Zugqoln 7Gbmuimur 7Lmlkhatv 3Otzl 12Iruljtpvnfwkt 12Pjscebzthhspq 5Empzph 12Wrfaalfcdsuyj 8Dfxyfbhim 3Qouq 6Srsaqyt 11Osviaqvobpwl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zic.glh.ClsJylyrkbuexopc.metQcefbogtdx(context); return;
			case (1): generated.pacx.kivel.ClsQdjis.metMeptrrqxg(context); return;
			case (2): generated.fzd.qgqjp.ClsVzqqvdhb.metMsjbhqpplani(context); return;
			case (3): generated.qpe.ifudp.xgatn.jzg.qau.ClsJymdeqopgpbo.metZmvopmy(context); return;
			case (4): generated.xij.sqewq.cevz.qdd.iar.ClsAxzlzievw.metNunaxfbnokb(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirLdencbvsehn/dirKpaojnpakbe/dirNzseliigvqj/dirTfqauagzzcj/dirRkxkhfssady/dirOdeefftpypd/dirLhphlbtqqrj/dirTitbwtiohqf/dirQpgwrplmnfc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex21041)
			{
			}
			
			long varUzhciwacbkv = (7065);
		}
	}

}
