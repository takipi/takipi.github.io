package generated.zvc.zkqw.sqxhe;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQioplriwzgyw
{
	 public static final int classId = 313;
	 static final Logger logger = LoggerFactory.getLogger(ClsQioplriwzgyw.class);

	public static void metLtxcprhjnjohkg(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valQrhlctenzti = new Object[8];
		Set<Object> valTdwnyncryvl = new HashSet<Object>();
		long valUherxtnzfnd = 1593865467178420578L;
		
		valTdwnyncryvl.add(valUherxtnzfnd);
		
		    valQrhlctenzti[0] = valTdwnyncryvl;
		for (int i = 1; i < 8; i++)
		{
		    valQrhlctenzti[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valQrhlctenzti);
		List<Object> valLfmiteoaceq = new LinkedList<Object>();
		List<Object> valSihvngdvskf = new LinkedList<Object>();
		String valZrjuzendkmj = "StrFhnoatevslr";
		
		valSihvngdvskf.add(valZrjuzendkmj);
		String valLbbefptwucp = "StrFjkaasbsvle";
		
		valSihvngdvskf.add(valLbbefptwucp);
		
		valLfmiteoaceq.add(valSihvngdvskf);
		Set<Object> valAowfdhxuoqc = new HashSet<Object>();
		long valTgxswpeylqo = 6242264613251645220L;
		
		valAowfdhxuoqc.add(valTgxswpeylqo);
		
		valLfmiteoaceq.add(valAowfdhxuoqc);
		
		root.add(valLfmiteoaceq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Imfzeblfvjxh 9Vuxklmmfya 4Fxmbj 10Dykktfspojl 7Rljvrhxu 9Ouovncvrny 8Lhnkxbfpx 10Snsyujeeehl 3Xwno 8Kghrlwpuh 10Wwgeavevaaz 5Ehjubh 6Sjhggqm 8Alfdeteil 3Wmmj 8Hliwuzmlq 9Zfgawvsrcu 12Eeychrpripekl 6Dbqoiii 3Gsai 11Udguhtbcywbf 7Mkiburxd 4Fxaso 11Bbtpqqnxtgzn 10Fouhyjabhzt 5Bnovkv 7Sizegphs 11Dlbhbwacnxbz 9Hhdjnsmmnf ");
					logger.info("Time for log - info 10Blutnwuppja 8Upwsxbjlo 3Fdep 7Ipgglwtn 7Kqgniqyw 5Goafqk 7Hxtuqseu 5Lmadep ");
					logger.info("Time for log - info 10Ududimkpicg 11Dkrkjftytela 6Pabthin 7Ndmcuuup 4Eujfq 10Gwkvzwjnokv 4Tmiwo 8Zlsplbtoh 5Ecestu 8Uwcqgaxxf 7Esopayuo 5Zmdrux 11Cljqjqtyvama 8Ouslqvtnj 4Wlwyg 11Zfnzkofvqvtz 10Smhkfnxobms ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Hyjqgj 12Ddhnzfwkixaxz 11Nxgiaehfxjmy 11Vctnojqsigtr 4Hsnao 8Ahrqvqlxa 4Ofrwe 10Ezsmnbvotib ");
					logger.warn("Time for log - warn 11Rgojdzvergno 3Jhjs 4Ducrk 12Auhfjqdaaxmpi 10Stqzjaswxpv 3Dbfo 12Cpafsqqvsfbah 5Dbyyhg 10Janrmefkhny 10Uqtxolqtlvb 10Qdrmhcrgjqe 3Bmqf 8Tsnrodpdv 11Exjdsyhuxkgk 10Qowvjhxbgzj 10Orlatcrabgd 5Krtgcb 7Olqputqn 3Cscc 7Aicsohwt 6Lsvvutv 7Dvpfzotj 10Gtaqbpfrtjd 5Jchyhq 8Dicjcsuti 9Aikhprzyqz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metKycmtt(context); return;
			case (1): generated.ghyrj.islj.cfyq.ivyv.ClsPvvifymh.metMqkfvb(context); return;
			case (2): generated.munb.ijbed.gztfl.ClsHbtirm.metFoavrf(context); return;
			case (3): generated.lzrmm.bjgfs.ClsQdamrbuivuq.metJaltcvoopburb(context); return;
			case (4): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metVduhhhsluhwuv(context); return;
		}
				{
			long whileIndex25318 = 0;
			
			while (whileIndex25318-- > 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metHhzxayn(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValXthekzkoalu = new HashSet<Object>();
		Map<Object, Object> valFhfexaciioe = new HashMap();
		long mapValFazlcvkemml = -4304435353198076372L;
		
		boolean mapKeyYbfwqpnnnck = false;
		
		valFhfexaciioe.put("mapValFazlcvkemml","mapKeyYbfwqpnnnck" );
		String mapValRwficktlzoc = "StrOkwotumjaui";
		
		boolean mapKeyLskfbsemdhr = true;
		
		valFhfexaciioe.put("mapValRwficktlzoc","mapKeyLskfbsemdhr" );
		
		mapValXthekzkoalu.add(valFhfexaciioe);
		
		Object[] mapKeyVhvlaqospbj = new Object[9];
		List<Object> valQajmmalonwg = new LinkedList<Object>();
		long valQancefpodfy = -7732646662815067351L;
		
		valQajmmalonwg.add(valQancefpodfy);
		String valTuepsaurmke = "StrVndfkhytuvs";
		
		valQajmmalonwg.add(valTuepsaurmke);
		
		    mapKeyVhvlaqospbj[0] = valQajmmalonwg;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyVhvlaqospbj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValXthekzkoalu","mapKeyVhvlaqospbj" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Zxdumfuvffgt 3Juzi 4Mhwfp 3Inym 5Wjzano 4Wcfkt 8Qefumxfxl 7Nlotcxil 5Cjncgb 8Qdnuirxtf 12Gjnakfiypvbxf 4Giufg 9Dpzhgnkvia 4Mcooi 4Sgayq 12Kizhzpvsdmxht ");
					logger.info("Time for log - info 12Jcbyqxwatigbq 10Jbixcgmjjwz 10Rkkduynjbez 10Hideawvvffp 5Ccqecz 7Lunjkvtd 5Wwvjhk 5Hgeoqi 6Hlwwrlj 6Efxwjtv 11Vlzfnawmzmjh 10Pfeqyckydsy 10Gidhmjcjurf 9Rooixeqzpc 11Gihklepphcds 7Tvrzjmdy 4Avysj 3Trbj 8Fupphhcok 12Utebzjqcqtown 8Kikkzlxrq 9Iyhcrrfryh ");
					logger.info("Time for log - info 8Vocmclkeh 6Eruyixc 3Scfk 3Qkwn 10Rfvpvxhwdww 12Heotvaxdzwiyd ");
					logger.info("Time for log - info 3Iwcb 12Xkdxyabchvcfn 3Sulq 6Vvkuhxn 10Cqfpicxonmh 12Irazmtptopbwi 8Sasllreeu 3Skxc 5Iqhzyz 8Jrihusjkd 10Jzrnsdfjmgk 4Sjejc 3Qjlc 3Hnrp 5Fbmine 10Pdlompaaqvr 5Lchhxm 11Nmakkmhdcjfu 10Vcwdmhvbloy 8Hcmqfekif 9Agofnrvnqq 4Giuym 6Kqvtnyq 5Iysgfz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Cysmokob 12Lhgazudvfjhui 8Mvoeremvb 9Xtfldygtvc 12Vyzkjmwdkodyf 7Zguffguw 7Vsisavur 11Ifxeliwygsls 7Tctfexto 10Btebrdgvccc 9Zlbplzzdom 12Frcenczaismxl 4Bozyc 6Uqpudxp 11Dhmyweawpkkf 11Zwypvifsqcrq 7Icxaxfaj 11Txtgrtmngycc 8Zfvgqchgc 6Uvgwuui 5Bzqrup 5Qsbldz 5Qnifvf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Lywl 6Gzbbbjq 4Fensi 12Uahhovndymhbm 11Ghwccjiinpva 9Cmocodajms 5Mzbgql 11Tjlyyhcgqnam 5Tloyhs 12Qjcvbuvbiacii 4Qdgxu 3Xfkq 5Mtwwtt 7Pwaaowqk 4Ljpkn 3Ixoy 10Igwjthdbvbc 6Lbqmsiq 7Uzxxyvci ");
					logger.error("Time for log - error 7Hndmlmrw 9Gewepyzphp 10Tgtmzcpnlxv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tcf.quma.ClsZzrrflp.metZjejbmakhczdx(context); return;
			case (1): generated.obqk.bihpl.ehwd.ClsWcpejgvq.metUrpeeajbj(context); return;
			case (2): generated.ucgs.cys.qrt.ClsGwmfnzjfaj.metFonacuizikxef(context); return;
			case (3): generated.jgye.cou.ClsWhiobyn.metUoalicwnco(context); return;
			case (4): generated.svs.oxvq.ClsHqpfa.metBgvjclpbm(context); return;
		}
				{
			long whileIndex25321 = 0;
			
			while (whileIndex25321-- > 0)
			{
				java.io.File file = new java.io.File("/dirQgviccmyyhn/dirKnrswbhrfzs/dirNihstdtkptk/dirMlhfzexazar");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex25322 = 0;
			
			while (whileIndex25322-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metRdrunjnhq(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valWnxbepabldd = new HashSet<Object>();
		List<Object> valQumkgycbduw = new LinkedList<Object>();
		long valUqkjqjgeyud = -4762300907014944440L;
		
		valQumkgycbduw.add(valUqkjqjgeyud);
		boolean valDiaesxzcolq = false;
		
		valQumkgycbduw.add(valDiaesxzcolq);
		
		valWnxbepabldd.add(valQumkgycbduw);
		
		root.add(valWnxbepabldd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Jotpctwctkds 3Ksqs 3Roeo 12Dzckuyjvjidey 11Wfcldqlnshcf 7Cwyesnhj 4Vgldo 9Afkxlnagkx 4Ulwcg ");
					logger.info("Time for log - info 8Nvxejdsow 4Yntwv 5Xvijte 6Vbfjusf 10Wsvznlkxmtv 5Kbsjnm 10Slfzcqsnywm 7Wlxkrinu 6Rzkfnpx 10Yngwrhiyxlf 6Abhgpdh 6Cbkymod 3Pnru 7Kjstgbpz 5Kxwkcd 12Bnxjoniukchpg 11Fwdtulevmero 7Srtakasm 11Njjwzvctvejg 4Klbmb 11Lwhianhcxvsl 5Shwcco 4Lwfwl 4Zdlrz ");
					logger.info("Time for log - info 7Iqqnbizs 3Lfbq 9Ofaxekrnjj 7Irwmiqbg 9Gwwqhawxfi 3Yfei 11Tspvlejenesp 4Zlqup ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Sooungg 4Gmevj ");
					logger.warn("Time for log - warn 7Xgdhicup 6Eeqswtf 11Doombrlngwks 5Kjjefo 5Fbmzbv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Uwasaay 11Epgimfidkjgr 11Gzlyrcnsenhf 11Rjohfufesysc 11Zblzheedcatz 12Veoeirffzqfmt 8Njeiisxol 8Zzthewqdo 11Ppnnowxblnda 12Bhhgefeuzpagl 6Nnspbfw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ncau.ibhi.ttuvu.ClsHlbobsu.metTahxaryiutr(context); return;
			case (1): generated.enb.ktdil.ClsEqcfzlhpy.metEbqhhysso(context); return;
			case (2): generated.zic.glh.ClsJylyrkbuexopc.metFfxpbxjn(context); return;
			case (3): generated.budq.anwwr.qie.tcx.ClsAvdrojvr.metVuphivdf(context); return;
			case (4): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
		}
				{
			int loopIndex25326 = 0;
			for (loopIndex25326 = 0; loopIndex25326 < 811; loopIndex25326++)
			{
				try
				{
					Integer.parseInt("numGsekkraaahf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((6646) + (Config.get().getRandom().nextInt(41) + 8) % 988998) == 0)
			{
				try
				{
					Integer.parseInt("numRpqskzjbmbi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirFpwuoxkqill/dirZdtykjhutkk");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numFwulucikibk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
