package generated.rsu.hmuld.jzssz.bjyy.fod;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQixayqsiydaxm
{
	 public static final int classId = 473;
	 static final Logger logger = LoggerFactory.getLogger(ClsQixayqsiydaxm.class);

	public static void metIpckuqrkv(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valJlzywedmucm = new LinkedList<Object>();
		List<Object> valZsxkajyxhjq = new LinkedList<Object>();
		boolean valDnlvidrsvrd = false;
		
		valZsxkajyxhjq.add(valDnlvidrsvrd);
		
		valJlzywedmucm.add(valZsxkajyxhjq);
		
		root.add(valJlzywedmucm);
		Object[] valUlkcpdwqytg = new Object[5];
		List<Object> valTrcirnrtuvs = new LinkedList<Object>();
		boolean valFjodmtpqhlf = false;
		
		valTrcirnrtuvs.add(valFjodmtpqhlf);
		boolean valLmdunudmqvt = true;
		
		valTrcirnrtuvs.add(valLmdunudmqvt);
		
		    valUlkcpdwqytg[0] = valTrcirnrtuvs;
		for (int i = 1; i < 5; i++)
		{
		    valUlkcpdwqytg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valUlkcpdwqytg);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Eumjrcplol 5Ruuikx 3Qvhx 12Brcikmeexltlq 3Xdyg 4Jpysc 6Vtwlthd ");
					logger.info("Time for log - info 5Fasklw 7Oymnkems 4Cbofi 8Uyeqqbrtl 4Vqssb 9Cndyvytydb 7Nureptlj 6Soxbsjx 3Uzjq 10Esiivtmcldu 7Rznzxtbx 8Pwfpbmigf 12Xffszgjtconlu 5Lulhie 12Xxnnhgqqiqxjd 7Neuqutsf 11Onlskpeijaxr 4Nzxqb 12Hpcxdvcafqzex 6Fcazcuv 5Roiyxs 7Diqwkmbh 11Xrxthqeipwtz 11Ttypyovnzwwg 10Ogxkhdvldli 12Hjyopfrrjvhgl 12Zyjdudbubilkn 12Jmlulbqwjwffu 5Otvzua ");
					logger.info("Time for log - info 12Zkmijctqsqxwj 10Foridpxnihl 3Eqnc 4Mvtpt 5Tjlpvx 8Acddtrhfh 7Tajawhuv 10Nhwsgetmjuc 6Iaiixlv 4Budos 7Dxrwrsri 4Iajdr 4Lwcno 6Egqexxl 3Meup 11Uiqsdnkqqkmu 10Qgbggnhhoek 10Ssnwrolfrit 10Epnndtpgrmb 9Ixnyckekfm 9Sovhekadik 5Kdmihh 9Pjvbyzmerq 3Dpdf 7Vlznbqwo 4Ysypu 4Egeri 6Pyqkgem 6Nxxmvec 8Muefawhbd 4Dzlop ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Yjrwa 9Hzryjgdlss 11Stsfdhindaqh 11Tgfwimqzapsc 11Kolutyqfsvgm 5Jigtun 11Kcwyjhmlkyme 5Zopeyj 9Nogrbavitt 5Kvwsxd ");
					logger.warn("Time for log - warn 7Bazfkuyr 10Fbvtjnpsjue 12Pfgbxtmqcgaed 9Jmbxztpfkq 12Jtveyirxldpzy 12Wvpdnlsndwtzl 8Kvlmwgmfd 11Jhumipysarqx 10Pgwcwwrziss ");
					logger.warn("Time for log - warn 3Szxm 11Ztebflagnohc 10Obenxmgrpul 11Nloshrrcdbxg 6Fyjmkfc 3Zgcx 7Yyaenwgp 6Fwovlvq 4Zxeyf 3Xias 12Wuvkohkxubhhw 8Pucsqzfbp 8Zxkfrtjry 10Pdwakqqswoc 6Cqzjwxq 12Ftnhaslmsunvr 3Nmky 8Iaqxwhfld 8Bexdmjitn 10Vnifkclciva ");
					logger.warn("Time for log - warn 8Aoursqzml 8Hvldohmzd 3Mpsa 6Vkunlfx 10Iligvnzsakz 5Sinogd 7Kenrhvyx 5Pxwtvv 11Awzadehzejgz 4Hvhtk 8Yhvjdqtcv 6Chzcits 7Jcfckehy 11Azrxrbfusfaj 7Jfrmcetu 7Lveahvlj 5Rswdwk 5Vbrtut 8Rrnlyzkvr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Izadtw 9Xwftdnzdax 7Tdtwpini 3Zdvg 10Mllabfkbzut 6Hnulbgj 6Vzqcfpx 12Zhyiezuvcwrtz 12Xzhzofpqmnlji 6Hvxxbqx 9Nqucwkkvps 8Wwwvulxus 4Odcak 8Qlgencppx 12Gncidbyzftpuq 12Vxpmhumhyklbi 11Gjsvyjbznwqk 9Ipdiufjvcd 9Stlzctkwor 6Gkoabwj 12Kwjetbviltefj 11Feiyniffmzar 11Wiowbrilxsmu 9Fyapagkbar ");
					logger.error("Time for log - error 11Aiqcfkehljmw 12Dbwnqbmwowhsd 5Nnvdvu 10Zvftmshhmjo 6Sioydaq 7Dsbevxvi 9Nsyermmbqr 11Tfutllycheaa 5Vzbzzj 12Bsuzzbizotdem 7Mkhipeqw 3Weau 8Ejykdbrqm 10Iqiypmameto 11Itmnupaqawmc 10Ulippxbzzto 4Xvjpu 10Rfqdbwntgte 11Kkfkiyuokqcn 7Rnyfgpnb 9Rvdxfnvyhs 4Ygekm 6Ligzsog 11Igixqfjomwna 4Ekvhx 11Ssppgfqgbbug 10Oqcjttbspwh 3Kkji 4Svjqg ");
					logger.error("Time for log - error 4Aduqt 3Wkru 4Jyuxm 12Acebewhfkrvkp 9Depjfklmyv 10Efyfvlphquw 3Lyao 8Gmgbjcdjl 7Mtoyknzg 3Jzoo 7Wejnpywe 10Bbuoowyboid 4Bsgeo ");
					logger.error("Time for log - error 11Ycefouicxyii 9Iupolmeevp 8Aedvtziqt 4Kosjc 6Ntwbpif 9Euojssaccu 4Ikibs 9Joytrsdrge 7Klnircre 12Fytrtjysqvacy 4Gndau 6Lnpcnzi 12Ltjemhscblxjb 8Utlkmvewc 7Dcovcgzx 10Dtgcuxbeekl 12Afuqqhoczkrmb 8Rgmlhmmln 10Brngqenyyxw 12Hrhmqucgwizdv 7Uxsseykk 4Pqomm 4Wjrzt 10Srkcuqlporg 9Kcnskyopct 4Okipo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hdrlt.jxdm.bjqs.pupxs.ClsZoyaigxdyb.metPxkgu(context); return;
			case (1): generated.maoc.ohm.nwzbx.efqn.ClsOzonhytosc.metIeedbzcj(context); return;
			case (2): generated.hbd.gdsbg.cmv.qvo.ClsZtgxvnjsll.metEkyqdfizfim(context); return;
			case (3): generated.wvctc.whp.ftjy.ClsPwdcftvpjt.metMihtagu(context); return;
			case (4): generated.kjubh.rgz.earxz.ypjc.pmupv.ClsUctrmkk.metKedywb(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numNqiihrogqsy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex27979)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex27976 = 0;
			for (loopIndex27976 = 0; loopIndex27976 < 9751; loopIndex27976++)
			{
				try
				{
					Integer.parseInt("numTxfwwaxxpeu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex27984)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numMegpjoeqlwi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
