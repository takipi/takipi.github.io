package generated.naf.suq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsSzodbxxywsfz
{
	 public static final int classId = 488;
	 static final Logger logger = LoggerFactory.getLogger(ClsSzodbxxywsfz.class);

	public static void metKihakbig(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valHtrydznmsri = new Object[4];
		Map<Object, Object> valRfggcopiskv = new HashMap();
		boolean mapValZihrtegotun = false;
		
		String mapKeyIlynrrncfnk = "StrYcpfjgfnvqa";
		
		valRfggcopiskv.put("mapValZihrtegotun","mapKeyIlynrrncfnk" );
		String mapValFydjpfvgset = "StrLsmqbyclwph";
		
		long mapKeyWbpkwhercdz = 2965644429701221108L;
		
		valRfggcopiskv.put("mapValFydjpfvgset","mapKeyWbpkwhercdz" );
		
		    valHtrydznmsri[0] = valRfggcopiskv;
		for (int i = 1; i < 4; i++)
		{
		    valHtrydznmsri[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valHtrydznmsri);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Xwjtzzqcnvuli 4Lmlzt 7Aywausnc 9Hkoprdkebu 6Mufsevc 10Ymfwihjjgtj 6Vxlxfvt 10Ebecklwqasr 5Vyrcut 4Zepsc 3Hjwk 7Petlfiga 3Kzgt 10Xdwvjaoidtj 7Xkuwgvhe 4Pgqns 10Qjurkuktram 12Fmtlpwoyympzl 11Beccageiixyz 12Qqbzfvufghtth 10Nvinjtdrttr 12Vjawbxaikieoa 11Elhkftboofwr 5Lwnexw 3Dopf 12Stahhqcdsjjhs 10Tfspjobuhuy 6Dlnmsjz 3Nkyv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Fzhcsjih 9Oamzddbnxi 5Pflesg 8Bhzpkbmjq 9Zbicbuvsqr 7Dlznppmw 6Rojilko 10Fkkgdpzsxro 9Wcwxskypol 5Xfdozv 12Fxncdpltalzmz 5Eswtkc 10Fptbonssqpx 4Fvtbl 8Wtniwjkfy 7Bniccryq 8Fwqbhjyzz 12Dspscfdplopjy 12Vupypqegkavtc 5Lnimwr 5Tpczeb 8Hrmfajfit 12Xnusyvyafpxpe 9Pmbowmakbi 12Zhvfzectumsng 4Vbldj ");
					logger.warn("Time for log - warn 5Xbtnzr 11Nlrdakwauqmz 12Ujgfxedpnxowy 10Jfnugleuzko 9Xvnxejstso 9Tytruvdjdm 8Ruqwpdgwv 3Dhzr 6Pulzrhn 6Orhncid 11Okmgqvyfabzt 7Dxwihogk 9Qwpjpirnlp 7Yazqntaf 6Jedrrfz 12Jvfuisrqfwfxw 3Ecps 8Blcngjdkv 7Splmwyfm 6Rnvsjyc 5Bcegmr 5Byfmph 10Xosqugptqbx ");
					logger.warn("Time for log - warn 7Taupsfzx 9Rcdvyclenw 4Tkckq 4Xjscl 8Rlmusidab 7Cnhdkirb ");
					logger.warn("Time for log - warn 9Oedmgrbssu 4Igmza 10Tvovkzcvjvp 6Gbvhbej 3Eyvf 3Foqc 8Zvtnvkkga 4Bbepv 10Wzedljoolry 6Jpieveg 3Sifq 10Pvfaxnefyaq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Okiedua 12Rctzrbthrtaez 6Yhbrqsg 8Vxfxnpqna 5Mofhhj 5Lyecpr 10Rzepkmiuick 3Ojes 8Rsbudenvg 8Dcigyscrc 11Fsyvsqcuvsuk 11Eluogvuoeils 8Uxehsjpgo 12Zkkxwspibepln 8Vheqqxbqn 10Fwyafegiwko 3Ldai 5Wiwfra 5Kfmlup 5Avhhmv 5Oevxpe 10Edoxkyvvdpa 6Roaxtaa ");
					logger.error("Time for log - error 12Vxvtedpjntgcm 3Guke 5Qdtmst 12Hdrqglyornzeu ");
					logger.error("Time for log - error 3Pscp 6Yedifjq 9Ftjfnhobqa 7Gshwgegj 12Gvwxqqnwfltze 3Oqgp 12Rwzvmdbsvflee 7Crfglerx 10Sktspifutlg 11Gpfeswroiwug 12Acqtbfxaoridv 4Qdreo 9Awfbfkcvxx 4Gtons 4Pkmfm 4Tuktg 6Mwqryyq 10Spqtvbxfvlm 5Faytjc 11Rgriwswdacxd 12Xypupymwkjrqu 8Sthknbyos 8Kezboqakq 7Zxljahbp 11Dnauvypfpndg 11Kzimjeftxxss 8Ojvlrwrmr 10Kdqrhruarvf ");
					logger.error("Time for log - error 4Xyenc 3Nybg 8Fuywtiihu 10Djexescuaiw 10Nukkqpztcey 3Nrpd 9Whfcakrkch 9Jijjsclnbk 11Snwffiwytcgt 8Ecqakkaah 10Ffpbramkfcf 11Xpofwgqpljwj 10Reabfinabww 5Gkjdee 6Rusysww ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wxgmf.hjxrw.ClsYvfyyrknqfec.metIuqusbvrsb(context); return;
			case (1): generated.lkd.eckd.hdtbd.unse.scvn.ClsCjccpmy.metQahumxsfmpvl(context); return;
			case (2): generated.xcud.xbp.eztj.gexk.ClsTupoxajhjshtec.metEsfpmpnsdd(context); return;
			case (3): generated.gapuh.cesf.ClsXyxpazfgwk.metLiarcmz(context); return;
			case (4): generated.ihzj.znflp.qxbc.ClsAwlcqzadsqn.metFzhzhegctncb(context); return;
		}
				{
			long whileIndex28225 = 0;
			
			while (whileIndex28225-- > 0)
			{
				try
				{
					Integer.parseInt("numUqyoqfxuaqz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metSchywqyyskuuf(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[5];
		Set<Object> valQmeupcpwdcg = new HashSet<Object>();
		List<Object> valNvoitwhpnal = new LinkedList<Object>();
		boolean valWneofkhmewx = true;
		
		valNvoitwhpnal.add(valWneofkhmewx);
		
		valQmeupcpwdcg.add(valNvoitwhpnal);
		List<Object> valTitgnrzwxrq = new LinkedList<Object>();
		String valPfosxgxybpe = "StrFcjtaqeohsu";
		
		valTitgnrzwxrq.add(valPfosxgxybpe);
		
		valQmeupcpwdcg.add(valTitgnrzwxrq);
		
		    root[0] = valQmeupcpwdcg;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Qtraksiueu 12Aoojlymtoktrv 3Mcxl 9Fczruljucc 10Hzvtehurfwk 6Vhmzieb 4Wyliu 4Ipgcp 8Wyxfrddcq 9Trralcspgu 9Vvyhluigwk 3Xfxy 7Wetqckrh 12Xuguqytmalcaz ");
					logger.info("Time for log - info 6Wnietub 4Hjyel 5Hptvrb 3Ujvf 5Kuhczz 6Dubtwgf 5Gjsxir 10Vtowbkdpvot 6Jqqynnl 11Glsawlrjsvhn 9Vwntcinakk 8Hozukihdw 7Rzwftfkl 12Gfwfwibyphgqt 9Qyjwonriny 6Gwhtqwf 10Mincvtvxxnk 8Fjyolgxms ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Maklnvdf 11Xpzmzfusnfyb 7Vsxsoazk 9Ivgrpzxdhp 11Dsmugavarzgs 10Jrmrxnbtmjy 6Kwwfdaw 5Syqhyf 5Imxbzp 7Utpniwiw 5Gjsxav 8Taptherlr 11Qckrrvewlsca 4Whxaz 11Xyeoqalhdvrz 10Dtpstcloiir 7Dpfupvqt 12Jisauavzitnnz 12Klbaeqxcoptdb 10Jtxupcahyxa 8Lxgwsyuyu 11Mhljawsicbly 3Vycg 4Bbnkw 8Sygfqftgm 10Auhmyparchq 8Ujoxkulru ");
					logger.warn("Time for log - warn 4Sacpe 12Hdpcjuztdnkbs 12Cjxfxvmuocewk 5Bgngla 12Jzrizkyjihftt 3Vkan 9Bexbkbbkwq 11Myckrloutdml 7Arbugfvj 4Duyvt 3Cckq 12Kbwayyuymzsmm 3Bzrj 8Luakwdunt 10Vjnppqvegrb 12Dfcllpgdeujqh 12Quwhttwvthyqt 9Oxcxsehatl 6Vbnwama 7Ddgaztas 8Wwmghpwwk ");
					logger.warn("Time for log - warn 7Ludlknmc 7Mswtyact 10Unxbqldttur 11Ejyxnbtamcer 3Pmnj 3Qssv 4Wwafh 5Brkrel 7Peilzhid 12Obwrebvksavzs 6Cyfdhbv 10Xrajppqihge 3Knty 3Ygon 4Ugqup 10Nqznkofentw 12Ddxqdkcwpvhvx ");
					logger.warn("Time for log - warn 7Gvuiujju 12Gvpmvqybuzvli 10Sbnqpsgmexi 3Sxib 8Ldvrslsop 9Xsztbnwtzp 8Ujdzfaatu 6Symumsp 5Fbdtnl 10Duwviadiimm 3Lywc 4Mkdxl 4Tvuzn 4Bjmvc 8Xguyasqrk 5Zbkxxl 7Sgflwprq 9Dzsowvydwt 7Kosmtgvi 10Iupjhtsudoy 11Toqftlndwbqa 6Bgilxff 10Dkijhxigaxl 5Mgvaly 10Xzyjuwgjwsg 8Fkpkkglyd 8Hezsxcyul 12Jawwqtevpripb 12Hwvayxmcqpmfm 5Ivvdzq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Jaacxw 7Sslnbwwh 9Uifqbkshck 4Wuunc 7Unkrgkye 4Usffn 12Fvszdvxkxmfrz 7Nvluwsjd 12Kggubattcrhpr 4Gjhur 4Qebrt 11Ivhskumscthe 6Snhgvkd 9Xmzlbufjnu ");
					logger.error("Time for log - error 5Emiwhy 6Bkofvrn 5Jgjbfq 8Fjdwkpwej 11Nzxptjowlseq 11Rqxhswkqjdpc 6Iqwwrmv 6Avpqlod 11Lbzmealzuosx 10Jvdfwyeoaza 9Ppqoemcgrb 10Cflmxntbohy 5Hvyqlh 7Yysgeuth 9Ojoinijbme 9Kgwblywujq 12Nglfdgzlhoaum 12Tymveazopaudc 7Murfdolu 5Ugtjva 9Yjonxnpyqz 9Aiiwwslifq 10Ogxgjmiddyz 9Xtzxsryufw 12Zntvqusnkvrnq 5Sftmcr 9Gglocemwog 5Zlwden ");
					logger.error("Time for log - error 6Dwkjscy 9Xprkpkddxs 11Vyxaeniehjrm 12Bhgjbmwezbfbn 8Okarrbvhx 5Faajxx 9Hobzcxmigb 8Evcjftopp 10Roycgbxejiq 6Azddupb 10Fyiasedxxvd ");
					logger.error("Time for log - error 11Azjxgqzywjym 5Fmjalw 12Udmejzgsxlpsq 8Vzbzqfpkt 12Xemtnyxrhmotb 6Uheuajd 7Adkfqxol 4Xkgjx 6Dvnfwop 3Awat 4Ntcnu 11Larsrgyzswrr 8Itsyrysph 9Caclqofrws 11Azrxdwyuqjey 4Pvxhe 10Uxwljeepnmq 6Zjkijmr 12Qoofevzqprxbp 9Zhzrdwftpl 10Smalxrblpuj 9Ujxywcjbzh 5Sesgdu 9Itdxueexsi 7Iqvfagor 10Ovnqkvvukyi 7Cptepwpf 7Jpoxfdmz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ulj.ogxe.vbwy.ClsQmshqdjff.metXvyria(context); return;
			case (1): generated.eedk.kvsj.tzabg.tqpy.ClsBuuqqzvjfxdiao.metTljcnrnstomu(context); return;
			case (2): generated.fkhk.aid.ztzxu.ClsQjlasdqvzflfd.metYjmossro(context); return;
			case (3): generated.ado.osup.ClsKlojrrjbtxsxbb.metFvuph(context); return;
			case (4): generated.fkhk.aid.ztzxu.ClsQjlasdqvzflfd.metCcnwvtmpiltc(context); return;
		}
				{
			long varNnmszxnbyux = (1369) * (Config.get().getRandom().nextInt(620) + 0);
			varNnmszxnbyux = (4271) * (6791);
		}
	}


	public static void metXvowxmginonzs(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[8];
		Set<Object> valBxdwnrhjnkb = new HashSet<Object>();
		Object[] valRfgebrelsha = new Object[8];
		String valRsjubrbnrhy = "StrLdznfuszrkz";
		
		    valRfgebrelsha[0] = valRsjubrbnrhy;
		for (int i = 1; i < 8; i++)
		{
		    valRfgebrelsha[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBxdwnrhjnkb.add(valRfgebrelsha);
		
		    root[0] = valBxdwnrhjnkb;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Nrnocyrez 7Ligfzlop 7Qetgkjvq 12Hvsyadwqkixip 8Mxtdhxebr 5Owtliq 12Fjcyosyafviet ");
					logger.info("Time for log - info 8Unwgrmdry 11Cildndgdtohb 6Zwfsgpv 4Tgnjr 9Djmilebwsj 3Pfdy 11Yzimxldoaanf 6Fanghhi 9Kusexdwpng 9Rkmjgjqnzz 11Yxbjlxzgxdwn 4Xjowt 7Yhkfihnz 10Lumrnzlwsgc 11Gnhxwtxsiltu 10Andecgfuxrj 3Cyvb 5Axhtxi ");
					logger.info("Time for log - info 11Uyzdnfxgtlwz 9Wrywmvszrb 7Pybvckpv 8Gqtzadahh 11Hmewwnwzambu 11Uxajjcryubww 11Infvvirdeeen 8Qeqhpwvyn 9Vrbhzkvrwh 12Xzhtqsgaehljt 6Vohcneo 6Pwkplal 4Drodf 5Izdqbk 5Huanvh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Xcpi 9Xkrqluwphv 12Xcygcbiwrvoli 12Klziujcimwjiq 3Adhm 9Vnrkfndxso 12Hfemfbfsvvkbg 11Rfqnhjmmljzg 8Dbasthfda 6Ewrxhxc 12Vvniwhggfiooj 5Ncesdt 3Kmxf 12Dlymqerlldcwa 9Rzmwbjapcs 5Qbbnka 7Adlxhwht 5Patjbx 7Lkvfaqkg 7Dzdkuzai 12Kthiglovhwgrz 4Psekn 7Vcevgtgx 4Crvpt 10Qicgwjukmbz 6Lkjgrjn ");
					logger.warn("Time for log - warn 7Tellcbed 11Vnaqgbncgigq 12Slporjvlgaivq 6Uaszwty 7Rohifoat 11Fghqkmkhdmjh 7Riyaesvi 12Ykmhyusysgzqn 12Ebfzwynrkgmdx 4Uorrx 8Oaltxbnqi 5Ztzmvp 9Herlhnhvgz 6Lfboisk 9Eoiomlmwjs 10Kvxthskuaoo 9Crdnmosqma 7Ugxscffs 6Mjbnleb 8Xqtebsziz 11Dlyedumlmwfd 10Vxsnzisrnao 9Qtrjntgvdj ");
					logger.warn("Time for log - warn 7Rkghhwoz 8Crdvourlw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Nhfiff 6Eposxet 5Nrfalm 4Rteka 6Kkuvkxx 11Xwvviljqptup 4Nbktk 12Pbhoxvjkrewhs 9Simvcuogln 11Efjgepvjxhvr 12Kuszritsggomq 6Smjuokm 3Jxov 7Xslnodlw 12Papltsjwasqos ");
					logger.error("Time for log - error 11Weaslaxtsfeq 3Behy 6Pkbrizp 3Tffs 10Sfvhseynnph 8Lsdorhlhr 9Gkpdskllnd 6Gpmqvxo 10Feujgonnpcm 11Pfwalkdvaxqq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jzpii.ixwl.ClsCvgimgq.metCiomqaueaxz(context); return;
			case (1): generated.ghyrj.islj.cfyq.ivyv.ClsPvvifymh.metPuldf(context); return;
			case (2): generated.ucgs.cys.qrt.ClsGwmfnzjfaj.metFonacuizikxef(context); return;
			case (3): generated.wvkuf.rvtq.kcgfs.vezg.ClsKfeffw.metVcvew(context); return;
			case (4): generated.zic.glh.ClsJylyrkbuexopc.metXfvmhgsf(context); return;
		}
				{
			int loopIndex28232 = 0;
			for (loopIndex28232 = 0; loopIndex28232 < 268; loopIndex28232++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex28233 = 0;
			for (loopIndex28233 = 0; loopIndex28233 < 9456; loopIndex28233++)
			{
				try
				{
					Integer.parseInt("numZszojnloslb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metFhdpmoxdz(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValKwwhhoeqxec = new HashMap();
		Object[] mapValIyyxwkpkhrr = new Object[7];
		long valDogjempqhev = 6540938809552346082L;
		
		    mapValIyyxwkpkhrr[0] = valDogjempqhev;
		for (int i = 1; i < 7; i++)
		{
		    mapValIyyxwkpkhrr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyZhgbtqwaiux = new HashSet<Object>();
		long valBxmdeuultqh = -2049014181089173675L;
		
		mapKeyZhgbtqwaiux.add(valBxmdeuultqh);
		
		mapValKwwhhoeqxec.put("mapValIyyxwkpkhrr","mapKeyZhgbtqwaiux" );
		Object[] mapValIrbctbtwzyv = new Object[4];
		long valEmowzeiblvu = -3251227675495660558L;
		
		    mapValIrbctbtwzyv[0] = valEmowzeiblvu;
		for (int i = 1; i < 4; i++)
		{
		    mapValIrbctbtwzyv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyRcywjbeynbz = new LinkedList<Object>();
		int valRqugmzdkrls = 557;
		
		mapKeyRcywjbeynbz.add(valRqugmzdkrls);
		
		mapValKwwhhoeqxec.put("mapValIrbctbtwzyv","mapKeyRcywjbeynbz" );
		
		Object[] mapKeyLcbupcvtsan = new Object[7];
		Set<Object> valTewdxlrxxul = new HashSet<Object>();
		boolean valChafoueycyi = true;
		
		valTewdxlrxxul.add(valChafoueycyi);
		int valCymowwowzkt = 818;
		
		valTewdxlrxxul.add(valCymowwowzkt);
		
		    mapKeyLcbupcvtsan[0] = valTewdxlrxxul;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyLcbupcvtsan[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValKwwhhoeqxec","mapKeyLcbupcvtsan" );
		List<Object> mapValInmfibxjqnd = new LinkedList<Object>();
		Set<Object> valQgomyxtkuzt = new HashSet<Object>();
		long valKwuzjomfyec = 3935463039448447198L;
		
		valQgomyxtkuzt.add(valKwuzjomfyec);
		
		mapValInmfibxjqnd.add(valQgomyxtkuzt);
		Map<Object, Object> valTlkxhvxbqny = new HashMap();
		boolean mapValImbshmspsbv = true;
		
		boolean mapKeyXzftcpbagzr = true;
		
		valTlkxhvxbqny.put("mapValImbshmspsbv","mapKeyXzftcpbagzr" );
		
		mapValInmfibxjqnd.add(valTlkxhvxbqny);
		
		List<Object> mapKeyScxodekjiku = new LinkedList<Object>();
		Object[] valRytkpqwpmzc = new Object[3];
		boolean valBftiupcdumn = false;
		
		    valRytkpqwpmzc[0] = valBftiupcdumn;
		for (int i = 1; i < 3; i++)
		{
		    valRytkpqwpmzc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyScxodekjiku.add(valRytkpqwpmzc);
		Object[] valNzzfkjbuqlj = new Object[11];
		boolean valNiqcofuzarg = true;
		
		    valNzzfkjbuqlj[0] = valNiqcofuzarg;
		for (int i = 1; i < 11; i++)
		{
		    valNzzfkjbuqlj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyScxodekjiku.add(valNzzfkjbuqlj);
		
		root.put("mapValInmfibxjqnd","mapKeyScxodekjiku" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Bdtkojzfhhu 4Trmie 8Pbhdjkqmh 9Ojjhehikvl 3Tkvt 11Nlptsxjhuaff 7Yqsojged 9Xtswcaucsf 4Fpuyv 10Yzcqcmwsivg 9Hmwphrcohg 12Ttnlqwagpibzg 3Ditq 10Wlpublmgxjm 6Uuwjlcc 5Zcmxpi 10Rjubwmhzymp 5Mwjllb 9Hsyztrcpgc 8Ykguuhasx 4Aeuop 4Iuybz 7Nenesenx 6Uohrruu 4Mnkft 9Mtgknhzqpe 10Ashyhwchiwp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Cuvkummloffpi 10Hhqgeyrmtjd 9Bybgxjgaft 3Mqsl 12Qrwfmzhjyctvs 4Doywe ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wmjc.yywge.qivf.ClsNtnaiojgyo.metNewjeyyudocce(context); return;
			case (1): generated.fgkp.bvpjp.tisw.nifap.ygoni.ClsBmkimj.metEbkiw(context); return;
			case (2): generated.fpitj.gxmf.ClsSfcuawq.metAlcxbwza(context); return;
			case (3): generated.erjvc.bth.rgln.usqa.ClsYyzexetbgpowz.metEbfljsamwzq(context); return;
			case (4): generated.xpyaq.paxhs.ClsBkhbodffo.metKfifgmjw(context); return;
		}
				{
			long varRiczsmxybnu = (Config.get().getRandom().nextInt(232) + 4) - (Config.get().getRandom().nextInt(383) + 6);
		}
	}


	public static void metUkmntmbfb(Context context) throws Exception
	{
				int methodId = 4;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValGgiwxbfrypv = new HashMap();
		Map<Object, Object> mapValThufemtobjn = new HashMap();
		int mapValCdvenliuzfb = 556;
		
		String mapKeyBeftgcvwnyj = "StrOisejnkittt";
		
		mapValThufemtobjn.put("mapValCdvenliuzfb","mapKeyBeftgcvwnyj" );
		
		Map<Object, Object> mapKeyRyokgjbqibg = new HashMap();
		String mapValCddkmuuixva = "StrYjccocsdoda";
		
		String mapKeyJhzmhjetnpx = "StrXketfegeuug";
		
		mapKeyRyokgjbqibg.put("mapValCddkmuuixva","mapKeyJhzmhjetnpx" );
		
		mapValGgiwxbfrypv.put("mapValThufemtobjn","mapKeyRyokgjbqibg" );
		Set<Object> mapValYdjmvgdymjc = new HashSet<Object>();
		boolean valGlvomdjowqw = false;
		
		mapValYdjmvgdymjc.add(valGlvomdjowqw);
		long valUhzydomvaxa = -6808960851694066825L;
		
		mapValYdjmvgdymjc.add(valUhzydomvaxa);
		
		Map<Object, Object> mapKeyPlruyqikhlh = new HashMap();
		boolean mapValAaufzlmzlel = true;
		
		long mapKeyNuoyvigbexn = 1531589335255804002L;
		
		mapKeyPlruyqikhlh.put("mapValAaufzlmzlel","mapKeyNuoyvigbexn" );
		String mapValSdtcugjsaco = "StrRgyszbzdwae";
		
		long mapKeyPoweaydeihw = 1164537868220917993L;
		
		mapKeyPlruyqikhlh.put("mapValSdtcugjsaco","mapKeyPoweaydeihw" );
		
		mapValGgiwxbfrypv.put("mapValYdjmvgdymjc","mapKeyPlruyqikhlh" );
		
		List<Object> mapKeySqyhrzkhhrz = new LinkedList<Object>();
		Object[] valXszgzsknqrv = new Object[11];
		int valRiskupeiwfg = 93;
		
		    valXszgzsknqrv[0] = valRiskupeiwfg;
		for (int i = 1; i < 11; i++)
		{
		    valXszgzsknqrv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeySqyhrzkhhrz.add(valXszgzsknqrv);
		
		root.put("mapValGgiwxbfrypv","mapKeySqyhrzkhhrz" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Ynqujvi 7Bzzmihxw 6Axgkyrq 6Lhwwhmm 12Pvzazjuslkbjk ");
					logger.info("Time for log - info 4Nmbfs 3Aodt 4Mxkwn 6Lxlysnd 5Nnsnfg 9Efcplaltpx 5Pubzhb 11Zbxaynbcyfve 4Fnlje 5Nxfbqf 4Svujn 6Talizmd 12Zkdplqulvkxqh 7Nbcqgwaz 4Lzpjq 3Eiwn 7Sqxupblo 10Tgwdjlusonp 5Ocdmhc ");
					logger.info("Time for log - info 5Vttlpg 5Wwaojg 7Hgcrnvbd 4Mrpnp 6Iwartvw 5Ykxiwd 4Ntxjl 10Drlacdacxta 11Nelwlwoeyydu 9Ragpdhgjrx 4Omacf 12Fbrafcjbhmcse 11Yilpybdgkfsh 3Kxnt 11Sdufbnvdsvvn 7Cahujiuz 4Rvqym 8Mqgfcokxf 6Aehvtle 9Xcnpqulhbz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Muklscxieokt 7Qicqajaf 7Iawnqytd 8Lmqxyspah 10Wakxrkseqtl 4Ogtym 9Poepshcjoi 8Aesqiggei 3Cyzy 4Nqlex 8Pmcuzllqp 3Zohx 8Eolwubgvd 5Dfiaoz 12Nahvkcnmrjzwb 4Bqvuj 10Ryuygqjqewf 3Jors 7Pmlmfxgl 8Firktesec 5Hwqtqt ");
					logger.error("Time for log - error 8Ekuqzflxi 6Oqngeci 9Icmqmogwpl 3Ezva 11Orroajhvkgwv 8Dsqqspyya 9Pbvfciwylb 4Afdqc 12Bvvxxoxdmknbt 12Ijmkxkhfvjcsg 4Uuhbn 7Zhgqcspj 7Rmjvovld 10Myyycpmpofb 12Dgjinvqtgxjtz 6Bibpgrw 6Roqxnhu 9Ihklpjrtop 7Fpfawufa 8Nznuifsnp 6Tuovzbl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kkpa.egwla.xylej.ryfr.zebdf.ClsUznbtznd.metLeqdeppbikfpz(context); return;
			case (1): generated.ythhn.vxvz.yizb.ClsLckdkkeapmss.metUtevjjtyd(context); return;
			case (2): generated.blsj.gki.ClsOuhbksvj.metOmfsztvrsb(context); return;
			case (3): generated.jlzkx.vlyxg.uui.ClsYmzeuds.metMjkebsmedso(context); return;
			case (4): generated.zdn.ayby.ClsMelkmphvwjkgwh.metAcvmturnoh(context); return;
		}
				{
			if (((4249) + (8436) % 45395) == 0)
			{
				java.io.File file = new java.io.File("/dirAmislxbsokk/dirLmxffaznkff/dirNidjaokuidr/dirJtvavrhzgmq/dirNatqwqhcdgs/dirVsckhchqfxd/dirOgpskjqiwwd/dirLasbsjyxvuz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex28240 = 0;
			for (loopIndex28240 = 0; loopIndex28240 < 4599; loopIndex28240++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
