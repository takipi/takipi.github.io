package generated.tyk.hlfrx.jaeuw.vvzz.yws;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsMwqznwnz
{
	 public static final int classId = 331;
	 static final Logger logger = LoggerFactory.getLogger(ClsMwqznwnz.class);

	public static void metWpheeqsxvjk(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valEoesaspjmam = new LinkedList<Object>();
		List<Object> valXccrjmbafqm = new LinkedList<Object>();
		int valMsobjlmuxlv = 697;
		
		valXccrjmbafqm.add(valMsobjlmuxlv);
		
		valEoesaspjmam.add(valXccrjmbafqm);
		
		root.add(valEoesaspjmam);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Jiiwnzpzrk 12Jcfhoapenlhqy 11Kttfvvgiraqu 7Jejbzaad 5Wjcach 7Wcmmjygf 3Empk ");
					logger.warn("Time for log - warn 5Oyondb 3Dirf 6Tnffevs 12Djiupaabczaop 7Fkyoohqn 8Uqtslxyrr 11Kvsnazerlwcs 10Qsqerjdhnfl 3Bdzw 11Yoeekwrusqpp 6Vpapfvb 7Xownmkkf 11Qcpnpbpctgif 8Osdfnwxaj 9Ubcegxfcap 9Wwcponomsa ");
					logger.warn("Time for log - warn 7Pablhxig 8Isgqxiimx 4Juvis 11Ulobqielbdum 7Qzjsrskt ");
					logger.warn("Time for log - warn 12Amcbcbvywifjs 6Icujzmb 7Aswutotq 10Ojfffgukgpg 10Rzmzfxlknmx 3Tmuv 12Wbmeyfhidzopu 8Fnwlwgogo 5Gnkxye 6Lowphxi 9Hdwurzgsrz 9Wgajnquiwc 10Jnojvumkpcn 3Zben 12Zwkuirlnxwqyp 3Jirc 7Xqxiylqf 9Mqldjvtusb 12Zwlnjogsuudwp 5Xqodcs 6Xyfsuqz 3Lrnf 9Kcbphwkece ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Woenezr 11Tptjhkcepmju 7Wpfnbszy 12Npvwatnzmzfqe 10Kadacevffgl 12Pjisyfibnawup 8Vkxhutjuq 9Ccmtrlatnk 12Yeuqmguywkjma 7Mqltmzhh 9Owswoyhblc 3Txal 11Oaxipyncqjyn 12Uustdbofaynil 8Phgrteuay 3Oxha 4Srjuf 8Odgdmmmcr 7Fcivipek 10Abzjvlqhmnf 8Amlgmiiav 7Iiyidwov 8Fxfomahzj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vqli.xqs.ist.rcg.ClsUlfrrjkk.metUracnapyxnrd(context); return;
			case (1): generated.rorl.wuo.lqgdf.ClsUltodfmiuq.metZqbkch(context); return;
			case (2): generated.zpk.fdt.njvbu.tupx.ClsEdhqwzx.metAuiggyjja(context); return;
			case (3): generated.mzwyl.mypv.ClsZjjiybxk.metXkyprwkbozhl(context); return;
			case (4): generated.xluq.wys.lexvj.ClsEsonclfnnvbg.metAvsgvixigx(context); return;
		}
				{
		}
	}


	public static void metKlgcwsafmqppr(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valDxyfrowvuoh = new HashSet<Object>();
		Object[] valQaapmhmqpie = new Object[2];
		String valRjtsgcqsglg = "StrNhnapsnriyi";
		
		    valQaapmhmqpie[0] = valRjtsgcqsglg;
		for (int i = 1; i < 2; i++)
		{
		    valQaapmhmqpie[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDxyfrowvuoh.add(valQaapmhmqpie);
		List<Object> valPpjjjthayox = new LinkedList<Object>();
		int valTrtztjpxirr = 327;
		
		valPpjjjthayox.add(valTrtztjpxirr);
		
		valDxyfrowvuoh.add(valPpjjjthayox);
		
		root.add(valDxyfrowvuoh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Qpcd 3Xmzf 8Nvmzurlde 9Glzwwoiitf 4Kavhd 9Iqrhmgwlwx 11Hiqweqzwpwhc 6Plzkhuh 6Ylkwzaw 5Ytpapy 12Ajdmanlqgdpsq ");
					logger.info("Time for log - info 8Mkufbhpag 11Zuesxjjdpjzz 6Ydpumwr 11Cenydchdxqtm 4Qpwqm 12Jsmmhltntesgj 3Lnuv 8Npvlucfzf 11Ruivembvfojc ");
					logger.info("Time for log - info 12Jrgutdhtjfafl 3Blqa 11Whipfrvvpykp 10Rvaqnekmbtl 5Nzxtjq 9Xtzuonjpok 3Mcei 6Noxqikw 8Aoxjjktlq 5Adcymu 9Raymmibnhl 8Ximbidfui 9Bimgzmtmax ");
					logger.info("Time for log - info 12Daupxhkqjkpii 12Zrinfuevdhtcm 6Tdxvelv 10Dxnqaswirlu 12Oofegfiwxeclh 10Anblhmqmuon 10Vcmsdalxtpe 5Knsjuw 3Dmxi 9Convolgrmq 7Rabzypgb 3Pyxc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Usblejaigaruw 11Specmmfxqjam 3Tlzt 4Deckh 8Ukvmihxyd 3Yxts 5Xoyqnv 7Enqbfwsi 7Wlxbxftr 7Aujrsuje 5Wkozqq 5Pnzgpk 12Pdjjtpyjikyml 10Kdqehszarje 6Xwoosxq 4Yixoy 10Otvtwmtycbn 12Bgginhkedqwik 5Ukykoj 12Ydwenujueecld 8Ycabmbumo 5Mhenbt 9Bmlyculzvu 5Hsxyde 11Jbsqrcwuubup 8Enkgfcroa 3Qphr ");
					logger.warn("Time for log - warn 10Rsoycrdczze 8Yomrvpghz 4Lfrqw 8Jcwqshwxd 6Aqcsobu 3Vbyt 10Kvijfavdjfq 9Ypkpwopwej 7Gahqcqwl 9Pholbvfvkp 9Wkuyyenahz 9Yeovtbvaiq 4Hitzu 11Vzpkfvxjsfkc 4Fnsja 9Irlzjbbxsv 4Nwdai 10Tchiajwohwy 6Vbtjcct 4Qhkdt 11Ojummwvhgqtm 3Bbzr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metWfolwtyhy(context); return;
			case (1): generated.ojyuy.hdvu.yij.nuf.ClsJtdiu.metTlubvqwqs(context); return;
			case (2): generated.hqq.wtuo.vap.ClsNidilkbt.metNpdszselke(context); return;
			case (3): generated.fkbuh.vawj.ClsXsqsadsvdke.metGrquryhkwyi(context); return;
			case (4): generated.rqz.hcilq.dfk.rynet.yixkl.ClsVplcl.metWbvzhfkfpdkx(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(296) + 3) % 527845) == 0)
			{
				try
				{
					Integer.parseInt("numMyltqmncvsz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(642) + 4) % 56097) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numUlfodxbffdj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
