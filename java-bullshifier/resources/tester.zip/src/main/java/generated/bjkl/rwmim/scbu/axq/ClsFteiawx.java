package generated.bjkl.rwmim.scbu.axq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsFteiawx
{
	 public static final int classId = 469;
	 static final Logger logger = LoggerFactory.getLogger(ClsFteiawx.class);

	public static void metUpikxxqrqxf(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Object[] valIanrdyzehyd = new Object[3];
		Object[] valNbwlkxgztgy = new Object[4];
		int valHhsnlnonfak = 164;
		
		    valNbwlkxgztgy[0] = valHhsnlnonfak;
		for (int i = 1; i < 4; i++)
		{
		    valNbwlkxgztgy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valIanrdyzehyd[0] = valNbwlkxgztgy;
		for (int i = 1; i < 3; i++)
		{
		    valIanrdyzehyd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valIanrdyzehyd);
		Set<Object> valLirtaevlqkm = new HashSet<Object>();
		Map<Object, Object> valCvjemqbpxke = new HashMap();
		int mapValVehajgewjqr = 950;
		
		boolean mapKeyDtydzpcwlkz = true;
		
		valCvjemqbpxke.put("mapValVehajgewjqr","mapKeyDtydzpcwlkz" );
		int mapValInixapnbcwu = 410;
		
		int mapKeyXpjtkdmiwhg = 333;
		
		valCvjemqbpxke.put("mapValInixapnbcwu","mapKeyXpjtkdmiwhg" );
		
		valLirtaevlqkm.add(valCvjemqbpxke);
		
		root.add(valLirtaevlqkm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Ixxowjq 7Ajfxoxnr 6Opwgtqa 3Wafu 3Rbvk 7Dfgyibbf 6Zpyalpa 8Psvapngtu 5Fxfjqc 3Ajgi 4Eickh 5Trwaku 8Oymhoghne ");
					logger.info("Time for log - info 8Tghsquxzl 5Llaasl 12Dsouejchmcrxp 12Njwqrikvtcrla 6Ahwyqzf 7Yeeaufmc 4Giigp 4Khbwn 7Hmcouqnb 5Eycvnv 12Dnokyhqsdfiur 9Lqkxddgdew 9Vxxqybhiog 7Zouvvdso 11Aexmefqpvcdd 8Urmkkfirc ");
					logger.info("Time for log - info 4Yyqdf 11Wpinikdojzpp 9Ruhletzjcp 7Qnindanh 8Vgquurgqx 4Fkibt 4Yinyn 5Hgissw 6Ukdkosw 3Yhpn 12Lomcaeqpqjqvj 11Upxosnwamkti 5Jhwink 4Vyrdm 7Gnsfrqpq 12Zanyhajjyumsg 6Dflujho 5Rabehu 11Rpwvvxhcrpbh 5Cflsoq 12Kymqxpwoqrdma 11Zyalmdlsarqw 3Hrug 5Vokgfl 7Igwledvu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Uiiexperzyh 12Rerwdtnqcptdc 5Mcejfz 6Qkoubnl 12Qmrpamfgxvnzq 7Qbhvbesg 9Fwwlmbeciy 4Mzksn 6Bhpiweb 4Otjsp 3Afzu 12Qupxqiukpxlen 5Zjolwx 7Ajockisp ");
					logger.warn("Time for log - warn 8Rqxxhucqe 8Ijyckgyfm 12Omjatgjqobrhe 9Trvjxwtigr 11Wcortpizcpfx 3Vwpt 11Pebwztalcbyr 12Zpicfqabqbtlp 12Gtutjvkfzzzpp 5Hakfwq 3Dhiw 6Fziiklf 11Ykctteuauynl 4Aawbi 5Dyleom 7Wuvgeysa 6Hfnxjpr 4Pmbtg 12Onksamvprnxvh 10Csypdtdljzl 12Edtocjgbsygor 11Ooxkvsvirepa 9Dxetjubbwg 5Kgniyx 10Sedbhxusqig 12Emqrbbcxxwadp 5Wbesul ");
					logger.warn("Time for log - warn 7Nszmhsgo 4Aiare 4Pixaj 11Asbgzwionjbu 4Dpenk 7Ngjoaxcq 12Akvcquclgxigq 3Bycw 12Exluxtlpxwzjv 12Kyrbeardmkscg ");
					logger.warn("Time for log - warn 11Fxbwevkhnjvx 12Gblmnnbjzsctq 8Ubcgbeibo 9Pakqpmxjhx 10Zvlbdrldgva 3Lwfh 6Abqniyd 5Abuwra 9Efobmscjth 3Ckeq 5Dsvwww 11Epftowjrgmmm 7Dsfnsqfu 11Xtmpzmokdnxg 5Ddwtqa 6Qjveodx 10Aegrtkktody 3Mxtg 3Ltwj 12Rjwudhncrduzw 12Mzuqfnkjahfvi 8Fgtocgcgx ");
					logger.warn("Time for log - warn 8Bjjvkxgmj 6Ihbczyj 11Eozahlcohajf 12Aepofhjdxwglg 5Sfmrqm 10Lpsohlsisax 12Ztvmdvuacbhzz 11Udipnzrmchsw 4Neyng 11Tnuywwmspirn 12Uxwfbrnhbvexh 4Vjbjx 12Boxuponhwhczu 11Mheanbytibxe 6Djkvddd 10Nqixdeopljp 8Suzdubhrt 9Pwcolugyik 12Uvvythqpwntcr 3Simc 7Boipxgop 6Hdfespu 4Glynn 3Lkjr 3Wkir 6Itavngz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Ayjcav 4Oqyiq 6Ddjwxif 9Nvfczrstus 7Fkrfrnde 10Jtrbyyyxfid 8Vvcfegnts 3Dpam 11Bbgikzankufj 12Lxfhpevqzhhhe 6Oafgrzv 5Nnlnqh ");
					logger.error("Time for log - error 9Utfkskdtzr 8Jmdkykgth 6Kxfdmjp 8Wyrnbgkio 12Yxdgseghhrabz 7Bmcyoasm 8Rqvequqax 11Expdxaspazgt 7Pfomfnhm 5Edwkdk 8Jpfxlfoid 9Jvoaeuuuba 4Csexa 5Yplehe 3Ftjy 3Gair 10Wlbfmgtlffr 12Fugsampafueic 12Pbutvwfnzpwqh 12Tazrxnfmrupue 3Zuht 4Pvpne 12Ifaztrwpxqncg 10Dshlvteqnlo 9Fwtbgeisxs 7Qqgurixq 9Ltdvphxfgu 3Hwlt ");
					logger.error("Time for log - error 5Rnrmyj 11Kvhiyuiuodlb 5Thlwwi 8Tdzlokcwj 9Hfhahcpncx 7Toggjvyv 6Hotamjk 4Ozagg 10Zzwmzwcxkai 7Yzprexiv 9Wusxrqoety 10Zkomdeqwmaw 8Vogivgjhp 6Fxboswv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.afllp.gwt.xvrk.rxvp.rryr.ClsQsqze.metHxgvbl(context); return;
			case (1): generated.zuj.yzx.nga.pvup.ClsJyskqhfglgbk.metCxwonkfw(context); return;
			case (2): generated.kmvk.gapzv.hffa.xaqj.opr.ClsXtcqpna.metZsipiz(context); return;
			case (3): generated.rprz.twb.ozdl.ClsMnahuieydv.metLsuejvaasjahy(context); return;
			case (4): generated.qpya.todk.woo.rrzxr.ClsQlmcomguvtqu.metVbgwaaycr(context); return;
		}
				{
			long varEeefewmyyxm = (Config.get().getRandom().nextInt(191) + 9);
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numZyzbuofbrfr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metAcpizc(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[6];
		Set<Object> valTwkiiwfkmdr = new HashSet<Object>();
		Object[] valGszsyaqjyvy = new Object[8];
		long valUqkcickphmo = -3542356553202766213L;
		
		    valGszsyaqjyvy[0] = valUqkcickphmo;
		for (int i = 1; i < 8; i++)
		{
		    valGszsyaqjyvy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valTwkiiwfkmdr.add(valGszsyaqjyvy);
		
		    root[0] = valTwkiiwfkmdr;
		for (int i = 1; i < 6; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Aqpewhrko 8Svxnactrr 11Tvmwruesrqrn 11Edtirxxcmiej 5Lhgekr 7Nrmtbrxd 9Hlygnnfpas 8Xxmshcrsh 10Nwymljyacnz 11Vineihxmhzka 5Nwnurf 3Tulv ");
					logger.info("Time for log - info 8Eispqndkl 4Npudu 3Stcq 9Blprwrmyar 9Rkdmaxncsf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Itad 7Tyignxys 12Woxrldvtycuqb 8Uxfevgsfn 3Pdnm 4Arldf 10Nnaemkpisxn 12Asspyyyaypeaf 11Xdedkieivdbb 9Idrklmkroy 4Iwrni 9Ygrswnvwxe 6Oetdaah 4Rtcyx 12Gucbshwcbbnfj 5Mnmuet 7Yjkoqmnh 4Ilxjb 8Wfqtywstx 9Mtdhnvvrks 4Qtqbn 5Vgemxf 4Tlccm 9Drcwrfamvz 12Rewxxcyfejdsj ");
					logger.warn("Time for log - warn 9Zeahrvbxoo 9Bgchcyplvg 4Lwpoi ");
					logger.warn("Time for log - warn 4Kvsur 9Crfnetfndc 10Blvbkvzehpl 9Xjjuywmppt 9Pvpfvglafe 4Vilkc 12Mqxhjnezpdodh 7Mzeukzxr 6Xzdhnab 9Dlzvtfdqhs 12Xghjzswihbfxd 10Mdqfjdtaudn 9Jomijvelsb 9Ybzdqthagp 7Epxuwyer 4Rouvt 3Ekif 5Znlsul 5Tdecdr 3Gumj 6Athepdz 9Aolruygwsw 5Bxsvaz 8Injpcpqxd 5Qaccpc ");
					logger.warn("Time for log - warn 8Lpaowavld 3Ifao 6Bpdeqvp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Mnauo 10Aefntkvmdpe 11Sdimnuzjceta 3Zjtq 8Fntkakbyg 7Lanbvblg 10Ckidndpoduk 12Rafwrevrvwrpe 5Uvvcat 6Josnrkt 4Rmgla 4Otvru 7Enjbbqeu 11Yvreulcynhvb 4Muhbo 3Urwp 9Exbbyfeseb 4Zlhax 11Xhcqtlcxzdka 6Zbxehkk 11Kdpfjznlxntc 11Ovnvleepdfwr 4Otpov 9Hwvxrcvstj 6Ajdfmkd 4Cfsmq 8Rdqznvmpl 7Pyniyksp 4Rxjyq 7Slhrwpks 5Jovdov ");
					logger.error("Time for log - error 8Qvyhwsoiq 7Ffgdsogm 3Hjbj 10Sotqeqftjgu 11Qbcpfusaoeyn 8Mrzrqaxfa 6Lmndplt 12Kkcsapbldecka 9Jmmcvqbixq 5Cvksrj 3Jglc 11Ufnlkenkbgqi 6Tprrxkp 10Lhkceudnamu 11Mnhvfehghnqt 6Rroyuvg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mzwyl.mypv.ClsZjjiybxk.metGgiymbt(context); return;
			case (1): generated.qdt.cqf.kkjo.xjulh.ClsLodna.metBwwvtt(context); return;
			case (2): generated.ptg.tkf.rnlmy.ClsDuqumbrp.metReqewc(context); return;
			case (3): generated.cjexh.ehrl.mtwqa.ClsVshethruisurxt.metQbgbwpmyakda(context); return;
			case (4): generated.lnvho.rhfct.ClsGgdasahuvsgcd.metSxkgdfchrlbdm(context); return;
		}
				{
			if (((3830) % 465817) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((5178) % 288907) == 0)
			{
				try
				{
					Integer.parseInt("numOutorsqniew");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
