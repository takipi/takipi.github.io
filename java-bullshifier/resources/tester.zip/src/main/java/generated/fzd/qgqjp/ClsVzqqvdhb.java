package generated.fzd.qgqjp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsVzqqvdhb
{
	 public static final int classId = 356;
	 static final Logger logger = LoggerFactory.getLogger(ClsVzqqvdhb.class);

	public static void metMsjbhqpplani(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValYrjhogtedpu = new HashMap();
		Object[] mapValQkfghmbfmyq = new Object[11];
		long valMexnchpeuyc = -7567925324262457136L;
		
		    mapValQkfghmbfmyq[0] = valMexnchpeuyc;
		for (int i = 1; i < 11; i++)
		{
		    mapValQkfghmbfmyq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyQfmripidxtw = new LinkedList<Object>();
		long valKfkuxjtwysj = 3381833102573132210L;
		
		mapKeyQfmripidxtw.add(valKfkuxjtwysj);
		
		mapValYrjhogtedpu.put("mapValQkfghmbfmyq","mapKeyQfmripidxtw" );
		Map<Object, Object> mapValTzkwiertkss = new HashMap();
		long mapValXjjoizdbhoa = 7534283961094995794L;
		
		long mapKeyRhyclbevrby = -4608749890974415300L;
		
		mapValTzkwiertkss.put("mapValXjjoizdbhoa","mapKeyRhyclbevrby" );
		
		Map<Object, Object> mapKeyGzfpudwvbxb = new HashMap();
		String mapValZcanptpzxuv = "StrChqagmejqsn";
		
		String mapKeyLidgacpklrt = "StrNqtcfszmbik";
		
		mapKeyGzfpudwvbxb.put("mapValZcanptpzxuv","mapKeyLidgacpklrt" );
		
		mapValYrjhogtedpu.put("mapValTzkwiertkss","mapKeyGzfpudwvbxb" );
		
		Object[] mapKeyJtuzvfkcnrw = new Object[4];
		List<Object> valWswglatyfaj = new LinkedList<Object>();
		boolean valCjgreznfvbu = false;
		
		valWswglatyfaj.add(valCjgreznfvbu);
		
		    mapKeyJtuzvfkcnrw[0] = valWswglatyfaj;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyJtuzvfkcnrw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValYrjhogtedpu","mapKeyJtuzvfkcnrw" );
		Object[] mapValTreggybbybi = new Object[3];
		Set<Object> valIkrdjtjockk = new HashSet<Object>();
		boolean valVsurbxumlsw = true;
		
		valIkrdjtjockk.add(valVsurbxumlsw);
		boolean valHgaeqxknekc = true;
		
		valIkrdjtjockk.add(valHgaeqxknekc);
		
		    mapValTreggybbybi[0] = valIkrdjtjockk;
		for (int i = 1; i < 3; i++)
		{
		    mapValTreggybbybi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyYxuualcekin = new LinkedList<Object>();
		Set<Object> valLuxyamtcgot = new HashSet<Object>();
		int valVzaclyvwigt = 642;
		
		valLuxyamtcgot.add(valVzaclyvwigt);
		
		mapKeyYxuualcekin.add(valLuxyamtcgot);
		List<Object> valVmzitasegps = new LinkedList<Object>();
		long valZmzplbqlciu = -5960665625590867402L;
		
		valVmzitasegps.add(valZmzplbqlciu);
		
		mapKeyYxuualcekin.add(valVmzitasegps);
		
		root.put("mapValTreggybbybi","mapKeyYxuualcekin" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Dzphniauelj 3Uqdm 3Imwz 6Yraugnx 12Cezbzzgpawrfq 11Tnecskwmjhhl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Wxfiksyqpxyk 12Eczgmnebobwqd 5Ffkamz 8Jqxhjhuas 4Pnins ");
					logger.warn("Time for log - warn 4Evidm 12Eisbuxrrbqklf 11Wbnxfnwrjxoi 5Qvfsno 12Otujysgbczzim 5Eobwdt 8Jpefcvzly 11Aebjzkjmzhhc 10Mzdqcvguueg 12Zgqurdrkmxufk 3Kgok 10Gyquhpbsppe 3Ctur ");
					logger.warn("Time for log - warn 8Auhsyraue 10Mbnsevtmcyh 3Dmhq 11Rrdroxzajenk 11Qupugzdbajyp 6Rsxkoiq 10Wbeiopfzfuh 9Mlixuofptc 10Xvatmjuzork 8Ywvuggwza 12Pfsivnadyletw 7Palrpysc 3Dldp 3Wcuk 9Ierkvtoltp 8Nylxlxnrm 5Eydshl 3Qwgg 3Nfox 5Tlbxit 8Wpihlogas 11Vqlftswdkjkr 11Xgqsjvhcighb 5Ojgyao ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Wkauqptiqq 7Kpkkqiqp 10Vhtpdqdngum 3Emcs 10Mkomuypvamc 5Jznkyv 3Cynz 5Oofshy 5Cwcyaz 12Pnbllzjnwxgyw 8Fnvfkyihj 11Hznvgdwhevka 5Joesok 5Jsftot 7Plzcavtf 8Bgxdmpmre ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jmrw.ryri.ClsDmqllltcxdlzd.metZvfqiitm(context); return;
			case (1): generated.bcbrr.mrpx.ClsJcswauwrr.metIydcpeyrd(context); return;
			case (2): generated.kfjp.bzn.mda.sfyxf.ClsAguszlzt.metWsvlopnliexx(context); return;
			case (3): generated.fkhk.aid.ztzxu.ClsQjlasdqvzflfd.metCcnwvtmpiltc(context); return;
			case (4): generated.oucap.zcbrm.jbhm.yte.ClsEpzgpbjqjhr.metNxbcwnp(context); return;
		}
				{
			int loopIndex26026 = 0;
			for (loopIndex26026 = 0; loopIndex26026 < 6662; loopIndex26026++)
			{
				try
				{
					Integer.parseInt("numEttggltgcyf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
