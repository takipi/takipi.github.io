package generated.yfwg.zmane.bbbip.wqsm.tbdz;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsSzekb
{
	 public static final int classId = 441;
	 static final Logger logger = LoggerFactory.getLogger(ClsSzekb.class);

	public static void metZjimsrct(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[10];
		Object[] valAhuquugpkwy = new Object[2];
		List<Object> valTrljvtgjhxo = new LinkedList<Object>();
		long valGwamsmgesew = -5500311778675748736L;
		
		valTrljvtgjhxo.add(valGwamsmgesew);
		
		    valAhuquugpkwy[0] = valTrljvtgjhxo;
		for (int i = 1; i < 2; i++)
		{
		    valAhuquugpkwy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valAhuquugpkwy;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Ssvnyg 6Ylfbscu 6Ljafheq 11Hshehdovytfe 4Diyqw 4Rflsn 9Gvjtobqegp 7Kotuabax 5Boxymq 6Teaiika 12Rrchmxknumpzb 12Acldmiysveoxy 9Qytjaeajrw 4Qjvbg 10Oqzlfypweob 6Ccracja 3Xejp 9Rcmeesmfpw 10Wausjhigfxk 10Bvwhpybqmio 7Yrxlnxqf 5Njfmab 10Kvfnyhxcwur 12Dwmeyjzefyskf 9Ifgxvzbyiv 7Qgtqzijt 3Sdnq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Hsbecvu 9Tmuyodcxia 7Toetxhof 7Xiafsqdb 8Zjmmlurld 11Cqhkmtbwbfuz 6Vkjrjkp 7Rupqnsdl 12Bxnfcrjwezhoy 12Ntwflunwyjyvt 9Jjxtkkdxio 7Ljvwmtyk 12Ubfpkxcviexsf 8Brpynbrvx 9Emmmzsyugf 10Esjnrznqqge 12Vdqjjnmaoclxl 4Skxme 7Zbfmktjo 3Sybt 8Hywpyjvhr ");
					logger.warn("Time for log - warn 10Pgwmvvkhrmw 9Iwpouyydgg 6Bfgrkfi 6Yxwpith 3Hoix 5Rzgfgt 10Phzocfrwtmz 4Csheo 8Rhaezgpkg 6Mdstbnl 6Mmpjywq 8Cizpzdbtu 6Hntxzdm 10Kosroyuajax 11Qluvmhswtdpj 10Mggednnbdph ");
					logger.warn("Time for log - warn 5Lebnyp 5Umftnz 8Kktpmunvt 7Ohxminlt 11Xzowlpbjzsvt 7Hcndvnhs 9Juhccglrit ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Jezyxumzxq 5Jwxiwv 12Tdzypfyiewyia ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ukp.wkgj.kys.bbj.whcvs.ClsShqgniemg.metCasobnicsjqw(context); return;
			case (1): generated.qdml.hmlho.ClsQuiharvpvfv.metXrurj(context); return;
			case (2): generated.kivyr.smd.affpo.ClsEqlzjivgvsoafb.metFtrfvpusk(context); return;
			case (3): generated.ild.bkgt.edyie.ClsCisruxi.metYtcmjebybd(context); return;
			case (4): generated.zhzbs.ylhl.ytr.cges.stvq.ClsYeenuinrut.metRuxodvwf(context); return;
		}
				{
			long whileIndex27439 = 0;
			
			while (whileIndex27439-- > 0)
			{
				java.io.File file = new java.io.File("/dirTxzwqfnqozv/dirSliehhnpkcr/dirBwhxggtxenu/dirAayhnifhvdk/dirAgcjzqiopcm/dirKzrdazyjjgf/dirEanenwowjak");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metIinmswx(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValFwluotemhcf = new HashSet<Object>();
		Object[] valXrecqawmkwu = new Object[9];
		String valXdngesmnwdz = "StrYpnyvqtmfje";
		
		    valXrecqawmkwu[0] = valXdngesmnwdz;
		for (int i = 1; i < 9; i++)
		{
		    valXrecqawmkwu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValFwluotemhcf.add(valXrecqawmkwu);
		
		List<Object> mapKeyNmtotlffluj = new LinkedList<Object>();
		List<Object> valCaeninqtjqk = new LinkedList<Object>();
		String valPjcaccykdge = "StrPokvjqxykga";
		
		valCaeninqtjqk.add(valPjcaccykdge);
		
		mapKeyNmtotlffluj.add(valCaeninqtjqk);
		
		root.put("mapValFwluotemhcf","mapKeyNmtotlffluj" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Eggfy 5Fruwrq 6Bbndtff 3Vafy 11Nnpzdrmdrcpa 5Wmsaja 9Vrdtsomtax 5Gsdael 7Rtubebnk 8Ufhmqperj 3Zoco 11Piqpfrrqqemt 10Kswvifxdpxs 9Kvimcluope 7Smadphwj 7Pugbgqun 12Bhfmugiufnspb 11Lbpsnntglcxj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Wnivvkgyqpisx 9Lkdfixsvzl 3Wpdn 7Llbpghdt 5Faryaq 4Pvomr 10Glfbqzaffvu 11Mxtdxljtbwpd 9Doucyrwxjk 12Bfhnkevqznaao 12Lcleubfgcidog 12Pgodxvpttdfku 9Rcvbwjacce ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Bdywbb 7Uqphzhwu 7Rfycvfjv 7Hrffsjhz 6Cstefek 8Prplhmvce 3Hszh 8Lvwrnqobc 9Wyzrqjhfgq 10Hnqglllrlae 3Wskd 8Sfjeyvhtg 3Btua 8Udezhuyfk 7Hxgzuzhc 4Wsehn 5Tdfoig 7Fvdbbzrq 7Vzlkkeyi 6Leiwhfa 7Ywhtnwlm 4Rpofk 8Ytmkrgojg 10Bhwdayaxehf 11Ttfzeznpjiia 5Kgrnnu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jyx.gyzt.djq.ClsUotdhdlfsrycjd.metYizmohxnia(context); return;
			case (1): generated.bxw.hza.cjj.bpzns.qzgt.ClsQbxnaxsj.metCcillrjcyusqec(context); return;
			case (2): generated.obwsb.fweao.vluj.ClsLnkmgpfh.metNbeuqlcmickmxa(context); return;
			case (3): generated.wyah.shgd.ClsOoifqzin.metNjigbxfkhw(context); return;
			case (4): generated.seews.usvhz.ClsBpkgpi.metSagewrwqtbzsvw(context); return;
		}
				{
			long whileIndex27442 = 0;
			
			while (whileIndex27442-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex27443 = 0;
			for (loopIndex27443 = 0; loopIndex27443 < 6672; loopIndex27443++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metBgnfqxcnk(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valRzipgelzgkh = new Object[5];
		Object[] valBagnkhxgxas = new Object[8];
		long valMmgljsdvbay = -4048614106934340256L;
		
		    valBagnkhxgxas[0] = valMmgljsdvbay;
		for (int i = 1; i < 8; i++)
		{
		    valBagnkhxgxas[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valRzipgelzgkh[0] = valBagnkhxgxas;
		for (int i = 1; i < 5; i++)
		{
		    valRzipgelzgkh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valRzipgelzgkh);
		Map<Object, Object> valCwtcfamcoua = new HashMap();
		Set<Object> mapValDpqxhxposbs = new HashSet<Object>();
		String valNxfpcpqttne = "StrLjujwjpprwa";
		
		mapValDpqxhxposbs.add(valNxfpcpqttne);
		
		List<Object> mapKeyDubcsnnnuwf = new LinkedList<Object>();
		long valDkzpooedrgj = 1956758971093913531L;
		
		mapKeyDubcsnnnuwf.add(valDkzpooedrgj);
		long valXqkzdqasmrj = 6609988795057394936L;
		
		mapKeyDubcsnnnuwf.add(valXqkzdqasmrj);
		
		valCwtcfamcoua.put("mapValDpqxhxposbs","mapKeyDubcsnnnuwf" );
		Set<Object> mapValKddklhhckge = new HashSet<Object>();
		boolean valVipbwfumour = false;
		
		mapValKddklhhckge.add(valVipbwfumour);
		
		Set<Object> mapKeyMgqmwjljekt = new HashSet<Object>();
		boolean valZanjfmdxuoy = true;
		
		mapKeyMgqmwjljekt.add(valZanjfmdxuoy);
		boolean valFpiwekqpvzk = true;
		
		mapKeyMgqmwjljekt.add(valFpiwekqpvzk);
		
		valCwtcfamcoua.put("mapValKddklhhckge","mapKeyMgqmwjljekt" );
		
		root.add(valCwtcfamcoua);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Jcgpjgp 7Qyctncse 4Ygiph 3Iptp 9Rhyuhedduv 5Lwiydv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Szgwklz 9Omcemqqplr 4Ydhqw 6Mhnbqmm 4Dtozk 12Ytskpeamzjlsj 8Tggobgjpa 8Rhrhejfpg 8Nsokdnllb 3Brtv 3Bysj 7Pxueacwp 7Xztrimen ");
					logger.warn("Time for log - warn 3Jkqe 7Zjwtbzdh 7Pephgydq 12Fubsbpkfgyjck 9Zhbfhehftc 12Rrlozedagsogx ");
					logger.warn("Time for log - warn 9Cjdgctypti 7Nxsljfgh 4Glejs 12Owwsyqoqfzarh 9Ssbmmjftnp 8Kkowoiqaq 4Voinv 7Maaibzso 8Zxswefhrd 12Lgpkspqcbkjla 5Uvfmqb 5Ysolmn 3Hwvt 6Tkkqbxz 4Yhssy 8Qqesbuyrd 7Owmcgnwq 6Qiikkqb 10Wwljzdqdjcx 10Frfwxyvptiv 11Idconverpote 4Jzvbd 12Fmgwlnjawnkte 11Kophygjlbree 10Dsmnahsqfdy 4Aeflo 6Fvcoybx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Ytrpcmjhnxh 4Vzsis 12Jfhmrcywqjqqv 5Lrzdja 10Yxjgrplhwfb 5Fmgyag 3Lqqo 3Lpsx 6Bmdbkwq 12Zlzlgkdfkoslc ");
					logger.error("Time for log - error 12Fsirbpgqmjukf 9Pxzhxstqup 4Itxfr 5Clpwqr 11Jgyabsjmzhvu 12Akxmfnfzmhqof 5Zfmgni 12Lbgwlqkvxgrcd 4Pzmey 12Bnkbyxvdwjhyn 8Llwyfolxs 3Sgro 7Wjbjuxar 10Cmgyytpajnh 6Hrvpfui 10Vmlyffsmrme 4Rtmpa 9Bspfacmgtn 3Lckc 6Icofpru 9Uddwebkksq 5Awzyor 6Iybnesj 6Eppmmcl 4Mitis ");
					logger.error("Time for log - error 6Ompnysx 12Mshgfxpsebvwy 9Ekqbtwqrkx 4Ysafp 5Otafvy 3Zofc 11Evzqeunmudrs 6Uxupdfk 8Yihhpcbwe 7Lhrhlcnu 5Qwjeeq 12Pwcgmumdkcnvw 5Xcbjcy 5Xhvhqp 4Ghkbo 3Egov ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zyq.cql.abcyr.bxocy.ClsPzdxphao.metBqhsdqlrug(context); return;
			case (1): generated.cbscy.vax.ifmv.uvjll.ClsXprhoql.metUsqqbascqyi(context); return;
			case (2): generated.xvt.cmvm.fgj.efz.bawb.ClsIacmgbgh.metHijjkg(context); return;
			case (3): generated.lxab.bkb.mqw.ClsMiouvnamcvsap.metKsjeyneapvdv(context); return;
			case (4): generated.fdupg.slw.vpest.ClsBfbtvkikd.metEmufwvtoyfmv(context); return;
		}
				{
			long whileIndex27447 = 0;
			
			while (whileIndex27447-- > 0)
			{
				java.io.File file = new java.io.File("/dirSoxjbhhsjde/dirQevzzmqfesu/dirPqnncrmtetk/dirPqnpilmalre/dirHhsxoyqavgv/dirUfqmhmjvaqg/dirNbilepelwij/dirEjbocautcou/dirGsmfsjwqwhx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex27448 = 0;
			for (loopIndex27448 = 0; loopIndex27448 < 1549; loopIndex27448++)
			{
				try
				{
					Integer.parseInt("numCfsizzjoobt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metJangle(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valIcojrtjflnp = new Object[7];
		Set<Object> valTvkcmgfcndc = new HashSet<Object>();
		int valGtvldxocoxe = 732;
		
		valTvkcmgfcndc.add(valGtvldxocoxe);
		
		    valIcojrtjflnp[0] = valTvkcmgfcndc;
		for (int i = 1; i < 7; i++)
		{
		    valIcojrtjflnp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valIcojrtjflnp);
		List<Object> valYcrxpmwyjia = new LinkedList<Object>();
		List<Object> valPpxgdgncdde = new LinkedList<Object>();
		boolean valNuozmxxfukw = false;
		
		valPpxgdgncdde.add(valNuozmxxfukw);
		
		valYcrxpmwyjia.add(valPpxgdgncdde);
		Map<Object, Object> valCzdqvqucolq = new HashMap();
		int mapValMovnfedqhaj = 413;
		
		int mapKeyDfkwhvlgloi = 530;
		
		valCzdqvqucolq.put("mapValMovnfedqhaj","mapKeyDfkwhvlgloi" );
		String mapValHgnajiiumkv = "StrTesogorqmmv";
		
		String mapKeySvfilvjmxpr = "StrXxtdczmcvzv";
		
		valCzdqvqucolq.put("mapValHgnajiiumkv","mapKeySvfilvjmxpr" );
		
		valYcrxpmwyjia.add(valCzdqvqucolq);
		
		root.add(valYcrxpmwyjia);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Sigxloxaxzs 5Mvkswd 7Uojohowd 7Djourubz 5Gojthq 8Qspcaueyr 3Wupz 4Rzndc 7Lqdcwbsm 8Kbmxpvjgv 10Gtvjspaxjlt 12Zmwcdcegdeioz 10Clkciddgwst 3Zyij ");
					logger.info("Time for log - info 6Bjhdcuu 10Jcqtizvltzk 5Rpzdhi 8Ozufbmbkl 5Eouhdl 11Wiirmqaaohrn 12Ksttlaximpdan 11Tftqgbiajclq 12Gmvngtbvlfgah ");
					logger.info("Time for log - info 4Nwdbm 7Srjdhvyo 9Bwmyvpvbdf 11Kjgrlymhafnq 6Ikmeihp 11Dudivuecrxhv 11Vxtynprlhvaq 5Uqrohv 4Zxppv 11Pdtnfwydvvfj 6Mdpbdvd 8Kyweuwroe 8Glwvpceqp 6Mqerbtz 3Fpgc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Idduzdyky 8Oruvpqvhv 6Qatsshq 9Kotmrpuejq 7Atsxhtjt 8Egzpmajqc 9Qbajpvhwtu 5Ncviul 9Qzomvyackm 3Qbwb 4Lrdtg 3Zkbl 11Ypmscxukzljd 8Sohemaazw 11Dvtfbxjtxwea 8Ojepzinzu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.elv.qjwox.npj.oxv.jth.ClsNewmedi.metIiejbdfz(context); return;
			case (1): generated.qer.bwl.ClsCbeyhqqy.metYolltwvxohl(context); return;
			case (2): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metCxqaycr(context); return;
			case (3): generated.jbipj.zrsb.daypv.qszx.ewk.ClsVnncvmwdx.metEgxuxcqraj(context); return;
			case (4): generated.gfpc.pbcpl.isevo.syh.yqsp.ClsDuasxzsefdmugn.metSkowruz(context); return;
		}
				{
			int loopIndex27452 = 0;
			for (loopIndex27452 = 0; loopIndex27452 < 6675; loopIndex27452++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
