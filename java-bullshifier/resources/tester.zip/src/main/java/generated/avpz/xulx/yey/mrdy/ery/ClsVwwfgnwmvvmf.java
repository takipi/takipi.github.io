package generated.avpz.xulx.yey.mrdy.ery;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsVwwfgnwmvvmf
{
	 public static final int classId = 486;
	 static final Logger logger = LoggerFactory.getLogger(ClsVwwfgnwmvvmf.class);

	public static void metFklslbzkstpawh(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[2];
		Set<Object> valGmyioexhijy = new HashSet<Object>();
		List<Object> valFskmflzzkao = new LinkedList<Object>();
		String valIxumlbkbyjc = "StrGxfdytzesap";
		
		valFskmflzzkao.add(valIxumlbkbyjc);
		boolean valHaxhcsrwnpd = false;
		
		valFskmflzzkao.add(valHaxhcsrwnpd);
		
		valGmyioexhijy.add(valFskmflzzkao);
		List<Object> valMjbbuqishtm = new LinkedList<Object>();
		long valEqicjwkvixx = 5541848308826982185L;
		
		valMjbbuqishtm.add(valEqicjwkvixx);
		
		valGmyioexhijy.add(valMjbbuqishtm);
		
		    root[0] = valGmyioexhijy;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Glvuw 11Huxvgftcvsgg 6Tkvfklr 12Bmmbrzlsplxgc 9Eikjzemgft 5Svsgiy 10Piwapkfqahu ");
					logger.info("Time for log - info 3Xaer 4Qijfj 4Bpjgx 6Kegdbhb 4Wwujw 11Mrykgmewavco 8Ersdxkwyg 4Ryvkj 10Idlzqdutpwm 5Nqzxto 7Trtobydg 6Vtgduer 7Ebbsxjdb 4Mtooh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Iuxwk 9Bpmgkoeivg 9Chkfxowiaa 6Gptoxve 12Hrgpfysehgvgf 3Ayoi 11Wbkwlcghaeuy 11Jiukkatrtmff 8Quxsbtsne 9Jyhijcilww ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Zwwopohfmsx 6Ooyaalf 12Swtcmstqvquil 5Crbeka 4Vhmsd 8Hyowjfuak 3Kcse 3Vcot 8Cyxuxclch 9Gdesmhkyuy 10Tqxiwvzuzbc 8Nlvhdqpsh 3Ppgw 4Sklru 7Abawdeev 11Gqeoehuxhfcv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mipzp.qfu.axrt.ClsJkbbmhkrxeo.metJhzcshfps(context); return;
			case (1): generated.swyg.szfbf.ejprt.ovbj.ClsEqyrgxer.metZenxrea(context); return;
			case (2): generated.wgclb.xej.jxqsz.ClsVlhpzchb.metWmoop(context); return;
			case (3): generated.ncau.ibhi.ttuvu.ClsHlbobsu.metTahxaryiutr(context); return;
			case (4): generated.gww.spuw.jrq.nmv.xowli.ClsKosigq.metKvdsmnqs(context); return;
		}
				{
			long whileIndex28184 = 0;
			
			while (whileIndex28184-- > 0)
			{
				java.io.File file = new java.io.File("/dirXyjnugzuhvs/dirRksoxnvoggw/dirStwhqepiuen/dirGgozitcneba/dirEtrmvsqrquv/dirJunexzvkgtc/dirWvavwxcqxmr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varMsvweupvlsq = (882) - (Config.get().getRandom().nextInt(53) + 2);
		}
	}


	public static void metLnwlgzrb(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valWwogbjqmple = new Object[7];
		Object[] valHhvxozjozlx = new Object[2];
		int valPktiqqsxfuc = 972;
		
		    valHhvxozjozlx[0] = valPktiqqsxfuc;
		for (int i = 1; i < 2; i++)
		{
		    valHhvxozjozlx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valWwogbjqmple[0] = valHhvxozjozlx;
		for (int i = 1; i < 7; i++)
		{
		    valWwogbjqmple[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valWwogbjqmple);
		Set<Object> valNogaeoaaemx = new HashSet<Object>();
		List<Object> valNyymkoprtwf = new LinkedList<Object>();
		String valLqyeuqrsjdr = "StrOmtfucqcsty";
		
		valNyymkoprtwf.add(valLqyeuqrsjdr);
		int valWusenhpdtrt = 531;
		
		valNyymkoprtwf.add(valWusenhpdtrt);
		
		valNogaeoaaemx.add(valNyymkoprtwf);
		List<Object> valFupryrtvbdw = new LinkedList<Object>();
		int valFrdbgxbjmei = 258;
		
		valFupryrtvbdw.add(valFrdbgxbjmei);
		int valGwjcsjqrink = 833;
		
		valFupryrtvbdw.add(valGwjcsjqrink);
		
		valNogaeoaaemx.add(valFupryrtvbdw);
		
		root.add(valNogaeoaaemx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Psvwlp 9Pqvnusrbeu 3Jrvz 12Vvtovvtwcrhkx 7Tytbnxuq 9Ytcubkpzsf 11Duysbuewkvhi 3Jszf 6Uxlrbus 8Nmhmtnexk 7Urttuhtl 5Krgmtj 5Cjiobu 4Itvne 11Fhjrhvpupoac 6Qntnqlf 8Jekkmnkdc 7Fhougdxj 9Upxgzslsbe 3Ehhy 12Ybftypknnqxfr 6Eipzufa 7Sjvtvgtu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Ymhcfopowxdxm 6Ikmzmmy 3Rkav 5Tmbohj 6Spgcvjs 5Adiken 6Wpwfyfp 6Rjlpqpm 3Hqik 10Qkybwfzjaei 6Tbifdza ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Dfjhmxdepf 12Muhxseaacrpui 4Sbqrh 5Adtpcc 4Nctbj 6Trnqwdd 5Amrxwc 12Xjitffhrrwwxl 10Qilnmblwuyd 3Qlzb 12Zzabhrzuksdil 9Qrsrmddqnl 6Twqfdoa 7Xtiaunvj 7Btshplaj 12Lnmjdszwtjpxi 11Dudghvgjpgtf 6Cwkajaj 5Kxcrdy 5Dtixkb 8Yidgzlxxc 7Krkpcktt 12Tbplnyybsalfe 4Evwcu 9Keuxdfwmzt 11Jwxvssaempio 4Dfwyc 9Uazlyvooxr 9Vvefhovryi 12Gebbofzubgkaz ");
					logger.error("Time for log - error 7Lklcheff 3Uibr 12Cvfadxrdncycw 7Yatgnqjw 3Oxte 12Kslvnpvtuyhkr 10Bmagsghxgzd 8Uaxwutnem 11Wgvssusutljj 5Ijdyyv 9Ilxbpatoga 5Kzwyyj 4Menrt 10Wjlptstpgqz 10Eojjgwelhua 3Hapw 12Bgeixaedgcvkt 7Nopqizov 8Lspxeoler 6Rdjcscx 3Zyaf 8Mkxiyuprc 9Vyxivtuyni ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.axdim.stv.ClsSaegiqo.metVwtuv(context); return;
			case (1): generated.nexb.cijvx.oksu.fhpbq.ivltf.ClsErarfyfw.metMuphdva(context); return;
			case (2): generated.idk.jvavb.vjuwp.iuzf.fawz.ClsRtwkffyfhbvpjl.metHdimsltzwuwz(context); return;
			case (3): generated.cfolx.abg.ClsZqloaugvusc.metIetjxtz(context); return;
			case (4): generated.wyah.shgd.ClsOoifqzin.metXlaat(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numArztqmotkev");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirOvoorockvfb/dirAjqhaspugxj/dirNipgaolednn/dirEygsnywbfyv/dirFoyxtpmzyxz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metHfphp(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		List<Object> valSdqwbqfppti = new LinkedList<Object>();
		Map<Object, Object> valEvjrllfzafm = new HashMap();
		String mapValMngkbefzxye = "StrKxolrmbqsbd";
		
		long mapKeyPzlhadfhegz = -7108808652752587760L;
		
		valEvjrllfzafm.put("mapValMngkbefzxye","mapKeyPzlhadfhegz" );
		
		valSdqwbqfppti.add(valEvjrllfzafm);
		Object[] valUcdhbqtheri = new Object[2];
		boolean valChnchbsgudc = false;
		
		    valUcdhbqtheri[0] = valChnchbsgudc;
		for (int i = 1; i < 2; i++)
		{
		    valUcdhbqtheri[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valSdqwbqfppti.add(valUcdhbqtheri);
		
		root.add(valSdqwbqfppti);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Eiqz 7Piluswuq 10Jccaexantvh 12Ibwmbogxvfhob 6Clsjegv 7Kyyixjwj 8Ujwnzywvs 8Zboibagjs 6Pkaggrd 4Tmrju 3Elcv 12Wwjurrdhmqxdl 8Fzmuqswqm 12Clhcdpghdktvs 4Dungu 9Jvhnvajupl 8Kweoltxfv 7Jimalvtr 11Wgeidfachwql 11Ufftvplxvcjk 5Tgwylk 3Mgde 11Tbkisqtrgunr 12Ufdazkqofborm 12Qdyrnpzvxordf ");
					logger.info("Time for log - info 7Wbjwcyqc 12Ofdungtyuabme 5Etqjsc 10Jzfpgkckslw 7Gnyufney 8Foudbvuaj 7Tjitqyse 3Kqnq 5Mrtqlt 3Aoto 11Qnppackawmpx 12Nlljnucxkqzyw 7Mtwmquze 10Wefbrticuiu 7Wyzljbny 11Hsjjqxxcinaz 3Fowr 12Qvszfjqcytovz 7Atklvbfm 7Dtpgarqp 9Vibiworlep 8Okcbgsgmg 11Cehjdcmrfqzj 11Khgnjlrkilko 6Nwwwled 11Rbuxycbiiexd 6Xcnwkem 11Zeduomhpskyp 4Vduqg 3Iohc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Zeydrfszktctu 6Vjoqloq 9Wrywgvzqqa 12Toxvtszegbpwn ");
					logger.warn("Time for log - warn 6Hxswmxc 7Zokuyits 9Bofygkjnbe 11Xbzegutwejsa 11Saoxhsijfthn 9Mbvtsgcdps 3Ksut 5Wohsdf 4Sqabk 3Raii 7Tcombupk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Lwgg 8Utmtdrhzt 7Msqpnbrk 12Knjcywjxiangb 8Adgzfrzsc 11Ebjjqpfipiqe 11Zpcgdmvaxqft 3Vbpl 6Birjadz 6Hasyvyr 7Guhzvupi 11Dmgtlzoukncf 8Ytsmvaope 9Ycjmvxzwuk 4Qktdd 7Stlnivcu 3Hfbn 10Czqryupeeia 6Ttzbjzo 3Tisf 7Uxoevdcu 4Xtjyz 11Ovhfpqelexry ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nrrh.nxnu.xat.kha.ClsLoiagobs.metTrfqw(context); return;
			case (1): generated.iyxve.emn.dzc.ClsAggygwujkgt.metWmlfsxai(context); return;
			case (2): generated.ajbel.dvbe.pmx.gfhen.qjvpo.ClsFwkvrnv.metJxbxbolmcyk(context); return;
			case (3): generated.amxo.ekvdv.ClsShqqngjhvyrxx.metFyiihinzb(context); return;
			case (4): generated.hbd.gdsbg.cmv.qvo.ClsZtgxvnjsll.metSlkmbtyg(context); return;
		}
				{
			if (((9391) * (1868) % 838237) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varKxjlqlqqsvb = (5332) * (7592);
			if (((varKxjlqlqqsvb) + (varKxjlqlqqsvb) % 12085) == 0)
			{
				try
				{
					Integer.parseInt("numVrjyqgnuksg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metYsflcdpdloo(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valXpjolvaesad = new Object[7];
		List<Object> valBvpjxqucoij = new LinkedList<Object>();
		boolean valRqnmlcpbjop = false;
		
		valBvpjxqucoij.add(valRqnmlcpbjop);
		
		    valXpjolvaesad[0] = valBvpjxqucoij;
		for (int i = 1; i < 7; i++)
		{
		    valXpjolvaesad[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valXpjolvaesad);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Wadlcxwibfz 5Kqzxal 7Tswmiyzk 4Efocn ");
					logger.info("Time for log - info 3Dtev 12Bdwccapjraltd 7Vrpklnep 7Bjdvcmlr 9Spjfegfocj 8Fumvrfhkh 9Uvjdgrtyhc 7Ekgalelr 4Mgmjc 12Mfxffvxtkwqkg 6Eudnucz 12Nnthgxmqktwfm 5Hnacfd 3Jxuu 10Vcascfolhps 12Pocwswtsbzyml 4Veiud 10Xahvpsdbofi 10Yixivnfijnv 12Uiwllzywrytww 5Ijvvmr 11Ejtnjenljfnl 8Nljlttimn 9Oxbfpdlrhk 3Rsvl 12Wrxqjxsqgdrcx 7Kuhvzjiu 7Mqjvjluz ");
					logger.info("Time for log - info 4Rfjye 7Qvoqxhwu 12Fnhlgexggedor 8Hnzxzklmu 4Rwgrb 5Fypytl 5Crzhvu 6Bovlaei 5Mxrpou 5Dbthcz 5Kbbkyc 7Npicyvws 9Bwzmevkezy 9Jfvxjeqnjx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Nbwvbz 11Buvgtfeapqtp 5Jlseoh 10Dtqlltqemgq 5Ypbbtt 5Lqeiud ");
					logger.error("Time for log - error 10Ihzthzmaagl 12Dbpfoszhbamsy 5Ctagvd 4Vilmn 5Jmocai 7Iuhyljsq 8Npzsbzitl 9Qiscjqkocj 7Drkhqsub 7Eeusobzg 6Yawtcqa 6Ataxzab 11Rsmsphiofhjp 10Iakyippjwmc 6Ozqbykj 6Jockufc 11Eaqfxhrhrsys 4Uhyfz 10Gvileyvkvgq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kfvy.ymxa.end.hazk.nwqfn.ClsXakhsfoyrlse.metSihzklw(context); return;
			case (1): generated.enb.ktdil.ClsEqcfzlhpy.metPzfwhbxomd(context); return;
			case (2): generated.ptg.tkf.rnlmy.ClsDuqumbrp.metIxitbe(context); return;
			case (3): generated.fdf.qdha.fywc.gjubl.dtsb.ClsBinezgxhqjfe.metSxeoz(context); return;
			case (4): generated.xvt.cmvm.fgj.efz.bawb.ClsIacmgbgh.metHijjkg(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numOobaqhfsyol");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirUxjxchgcrou/dirTyfzqojqcsr/dirOtwtdskqpnc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex28200 = 0;
			
			while (whileIndex28200-- > 0)
			{
				java.io.File file = new java.io.File("/dirAuijwwamuxa/dirWsogtnpbhny/dirNzixfucjbej");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex28201 = 0;
			for (loopIndex28201 = 0; loopIndex28201 < 5459; loopIndex28201++)
			{
				try
				{
					Integer.parseInt("numKrdnuruyohh");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
