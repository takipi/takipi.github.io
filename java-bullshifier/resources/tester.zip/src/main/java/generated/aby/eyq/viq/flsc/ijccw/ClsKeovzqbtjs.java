package generated.aby.eyq.viq.flsc.ijccw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsKeovzqbtjs
{
	 public static final int classId = 29;
	 static final Logger logger = LoggerFactory.getLogger(ClsKeovzqbtjs.class);

	public static void metTizqtcinnozd(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valPvgzlstbkei = new HashSet<Object>();
		Object[] valLjjpfnwlnal = new Object[6];
		long valUmqadhjrsla = -6757723762401976207L;
		
		    valLjjpfnwlnal[0] = valUmqadhjrsla;
		for (int i = 1; i < 6; i++)
		{
		    valLjjpfnwlnal[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valPvgzlstbkei.add(valLjjpfnwlnal);
		
		root.add(valPvgzlstbkei);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Fqae 7Mxmwustx 5Ryytmx 4Grvlo 11Cikctojffsgm 4Jdpbt 6Kgdpogu 5Fgpipa 12Zvcuezqbmdvyq 9Lnkuvfkdek 3Qjvj 9Iskvxviaej 11Cvwhjbzznaju 3Nmkj 8Wuoflzrqa 11Rcstabplvvuv 11Cyqrugruvinp 4Olamr 10Nvljmlikmso 11Edsluifvmlym 12Siaszgbpoiwcg 12Zuxppkytqtxle 5Rfqyej 6Gcoagxh ");
					logger.info("Time for log - info 8Pwbipubhx 6Lvmemgk 6Woytjmw 6Ibwjidh 9Fbazaijcyl 4Lrdlf 5Pzukxq 5Moblec 4Ubdhq 7Lpuezkvt 3Abur 9Uguvbcunws 5Evdgjj 4Whily 4Ddcht 12Rihabwtiepxnc 6Epjcoal 11Lpqsfjolycxp 8Lusmhsgkk 8Nudhqjgrx 11Hdwsagycqjjw 4Tqfxt 10Afigkpaxmdv 6Fpkxwxq 7Tcmwsfgw 6Bbnlflb 7Cuhdioju 5Izhglk 5Gogsez ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Xlejtklrazmbk 8Thiasxntk 3Hpjp 9Cuwhvogdnw 6Lotlgjr 8Zovqqzidp 12Psffdadmmhtlt 4Nqsox ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vyac.iqbj.guc.ClsYpwwsvx.metMdzvgnzpzh(context); return;
			case (1): generated.ulre.knov.ClsTukvjlscu.metSnzvazpuz(context); return;
			case (2): generated.egtuf.tby.poy.tetgn.cnw.ClsOidjvegh.metCzhml(context); return;
			case (3): generated.sttvf.uvyp.navra.vntc.wlw.ClsLyfkosygvnxgsh.metRmutz(context); return;
			case (4): generated.kdu.bhxiw.zym.ClsZlzcdqn.metFbnoxeuhjmavi(context); return;
		}
				{
			if (((6868) - (1479) % 698711) == 0)
			{
				try
				{
					Integer.parseInt("numAayllsewrks");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((Config.get().getRandom().nextInt(40) + 3) * (Config.get().getRandom().nextInt(467) + 9) % 223274) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
