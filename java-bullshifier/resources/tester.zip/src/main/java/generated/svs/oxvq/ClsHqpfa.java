package generated.svs.oxvq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsHqpfa
{
	 public static final int classId = 207;
	 static final Logger logger = LoggerFactory.getLogger(ClsHqpfa.class);

	public static void metZqdccmc(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valOtdxmctwris = new HashMap();
		Set<Object> mapValGqqkkglnxtz = new HashSet<Object>();
		int valGscagtahtbw = 991;
		
		mapValGqqkkglnxtz.add(valGscagtahtbw);
		String valUkvojcpwtzq = "StrRabakvpvlnw";
		
		mapValGqqkkglnxtz.add(valUkvojcpwtzq);
		
		Object[] mapKeyYqhwioloaww = new Object[10];
		int valHlsttumnyom = 230;
		
		    mapKeyYqhwioloaww[0] = valHlsttumnyom;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyYqhwioloaww[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valOtdxmctwris.put("mapValGqqkkglnxtz","mapKeyYqhwioloaww" );
		
		root.add(valOtdxmctwris);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Cyes 5Aunlhg 10Qurimxlzjui 9Ezbbohsmxw 10Htvqsokfepr 7Laqhctam 6Czqetzq 10Gbjsgqhcnyt 10Dcjvuiscvox ");
					logger.info("Time for log - info 8Gewzwkdnw 4Atjey 5Bojnmn 5Xahslw 9Pbxcamxayo 12Ynadarztofekn 3Jmsl ");
					logger.info("Time for log - info 4Yktmc 6Lalyylc 4Nuwjq 8Wuueyriql 7Xwlaptho 10Jgawrsizwuk 7Ltyamlbo 4Ohbru 8Dbccyssny 9Obianatedi 8Mfnosjlij 8Ydsxgfyjz 6Lhnzrbz 4Cxyea 10Ievcwxiyeke 6Cogtszb 3Iiea 7Ylizsrgp 11Qzrwfvbynvvl 6Gaqavfk ");
					logger.info("Time for log - info 8Zxigzgjcu 11Iwpdqhfdqxms ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Jtsao 7Rkaybwlj 8Jxpjpmdew 8Grxrxwdwg 10Jmcywzvpcmx 11Wxkrsbfbiiaj 12Wzlwmbzlkkivc 6Ptvilva 6Pdxasto 4Vgjjn 7Fcpvsotp 3Tfwi 4Yubms 6Difdmzp 6Sdtjyns 3Sepi 6Sjyzjyx ");
					logger.warn("Time for log - warn 6Nuljyfb 5Sztwhe 5Mpjltc 7Piwpasth 9Pwcswhmqig 7Wfbkjeyr 6Owmyphb 11Gmatfaaicazg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Renida 6Cumanfw 12Jxbcflkyresvb 4Txmnc 3Qxzi 6Knppirw 3Qoqu 8Cybiszsam 12Kmsiehyrlbgqj 10Palqdtfyjdz ");
					logger.error("Time for log - error 3Seoi 3Ojnt 3Owks 6Rxpgyoz 11Wdaqpbzfnaxo 11Tplcpaowcdff 8Wdwlvmycd 10Zxrkvqlzcob 10Yemfbswxron 11Hqiptgxjmood 8Slwmzwbin 8Jqibjottw 3Zbuy 5Lsyvbs ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hbd.gdsbg.cmv.qvo.ClsZtgxvnjsll.metEkyqdfizfim(context); return;
			case (1): generated.gbss.lmi.dvqsw.ClsLptludgibvpvw.metZydcmbkku(context); return;
			case (2): generated.fhy.qnk.brj.xhy.ClsYgumeudbf.metVozkhelpekwnp(context); return;
			case (3): generated.tcpo.xhov.ClsRfokukcdi.metWncxy(context); return;
			case (4): generated.vbpvl.ppexe.hnrdr.zcxzm.ClsCvshjbmkqrb.metJcfyp(context); return;
		}
				{
			long whileIndex23675 = 0;
			
			while (whileIndex23675-- > 0)
			{
				java.io.File file = new java.io.File("/dirSatadbhnklk/dirTniimnistce/dirNjwjeguyyle/dirPrxsgpegnfu/dirEhrwlzmubxi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex23676 = 0;
			for (loopIndex23676 = 0; loopIndex23676 < 2541; loopIndex23676++)
			{
				java.io.File file = new java.io.File("/dirTxszivmccqt/dirWqzbmmfnbdw/dirRxjepejyjvc/dirZggyvhksyrk/dirYpigraebeow/dirWoymkantvfc/dirAprjdhverjc/dirQbamerdoqwt");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex23677 = 0;
			for (loopIndex23677 = 0; loopIndex23677 < 4331; loopIndex23677++)
			{
				java.io.File file = new java.io.File("/dirPnkabarjwgt/dirOauqtixdygv/dirYxsagklifve/dirPsyuepchdis");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metCvdugki(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valDukxkpxwhnb = new LinkedList<Object>();
		List<Object> valKqvnebdhirt = new LinkedList<Object>();
		String valGizuvxcuxym = "StrOggpddoykti";
		
		valKqvnebdhirt.add(valGizuvxcuxym);
		int valHqimglsbais = 437;
		
		valKqvnebdhirt.add(valHqimglsbais);
		
		valDukxkpxwhnb.add(valKqvnebdhirt);
		Set<Object> valOqtvhmontoe = new HashSet<Object>();
		boolean valQsosnmydjpn = true;
		
		valOqtvhmontoe.add(valQsosnmydjpn);
		
		valDukxkpxwhnb.add(valOqtvhmontoe);
		
		root.add(valDukxkpxwhnb);
		Object[] valXtcerwfycfb = new Object[8];
		List<Object> valTjwvkvufjwj = new LinkedList<Object>();
		int valZkdizqfywxr = 389;
		
		valTjwvkvufjwj.add(valZkdizqfywxr);
		
		    valXtcerwfycfb[0] = valTjwvkvufjwj;
		for (int i = 1; i < 8; i++)
		{
		    valXtcerwfycfb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valXtcerwfycfb);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Hnyewcq 10Zxtjxuhcdgo 8Ooidxryyw 6Tovldpd 3Qchz 7Qketayhm 9Ituyiesfhj 9Dymggyptdr 6Jgtzozl 3Ahkh 3Pkgl 3Zzto 4Vcoxt 10Hwbibuiklav 8Aqmesvwhk 6Ebdsjoq 11Kwexyeamhbhs 12Odoqirxtmvliq 4Vdxek 9Svnxvkbcsk 5Nuhrak 6Bdhgrzw 7Xednlutj 12Lqlptrfgewesi 5Kszcfb 3Avzk 9Dcgmtrhstj 8Jrjeamnek 4Tulmu 6Sghnhav ");
					logger.info("Time for log - info 11Rzowugbdawzj 9Xoxkktatct 7Qotmqpvw 10Jncqelrvvhn 5Bhnnei 12Wqwqdgjzalkey 9Qalcqarnjc 12Ghchpjwutfssq 3Nckl 4Ulwqi 9Bdgldresla 6Qyerzox 4Fdhuq 12Ykfokdpwnuaco 12Zwwbzfslttwdx 6Zqiuqkf 10Ozbplhkhlgo 11Dtvhxvhqwlca 6Ttdxrfx 7Akwjlklg 9Uiirnqfmhz 7Htcwrmyo 7Yttgybsy 10Wrcnpkhhyfg 12Elvmgpvbpovpt 6Mfytvkk 10Wnxfprafnsd 5Ebeozk ");
					logger.info("Time for log - info 10Musngbxdhwq 3Wswm 3Ffoy 5Hvatst 8Jlymuyvcj 6Ipfcnks 11Buezznrtxgvb 5Dybhqe 12Cllzcfllbepys 10Mvioeziefiz 12Jveueqznfavny 12Cxrzvrlcmrglw 6Jhuqyqn 10Apeomvnofiv 4Uujsu 5Qalykz 11Phqbpoivakwd 6Cmpptgt 6Dojzagq 10Znfjlpolurl 6Xooxfkf 7Keflyvjf 7Jtbeyvzu 10Yzqlqwdgspt ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Nwbavx 5Mffvns 10Juovmftzxpn 8Kcqedmxfw 10Zypzzmkuikk 5Dyqsth 10Jnbdwmujyzh 10Arkiejqlknz 4Vnhgj ");
					logger.warn("Time for log - warn 3Kier 7Vkhqimeg 12Epdpbuzhjmrnv 12Fzkoxqahtkuys 3Xstk 4Ceerq 9Tzqqwqpkrw 8Etpuqxncc 6Wqkxojg 5Gkwmlf 4Jzjdo 9Fnytvdvmzw 6Jrjoere 6Ivlxrma 8Dczwcnakg 9Slmiqleiyi 11Mikhyuswhxby 10Erhhqhuguxs 10Ufbhpkbukhz 6Nzanfpu 4Zynbi 6Pyoahvy 12Ufgjepysmnlsh 12Tdxfkntncohyw 10Kjwabojwglx 8Ofeuzpjov 7Kchdwqux 4Vkuwq 5Uefohg 4Tknrr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Icua 9Skuuzuqvvh 10Dpylsxywzrd 4Yibyu 6Smmrqco 9Tpaffuoaoc ");
					logger.error("Time for log - error 11Zganbacwozwj 11Xcpsqwjmcyvp 4Oguku 11Xytiavgdjmtw 6Nblxpxi 12Pryyaldxfoqon 9Nttnczayne 9Bqrmtnnhjn 7Mwcijwej 4Lgdum 5Pptgyf 3Ffrn 12Kweknssjlhkzc 3Duje 11Zauvugkwyvpu 11Tpmwgybmpish 12Svgcxibwgkjbn 5Lpfdze 3Dyzu 4Qoqla 11Goufyhjkkfzu 5Aefgcd 7Umqdstll 12Ovuoenfzgbmrk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rxif.wckg.ncsqv.pmlox.ClsRkhayrnqgfzod.metVuvkwlczu(context); return;
			case (1): generated.lzrmm.bjgfs.ClsQdamrbuivuq.metUnbxmbilwl(context); return;
			case (2): generated.livfd.xzg.uuzce.mske.ClsRchbllfcclbcum.metEtgfstyazysxtu(context); return;
			case (3): generated.aneiz.novw.ClsBxulfvm.metBsngloxbviwqyh(context); return;
			case (4): generated.xpyaq.paxhs.ClsBkhbodffo.metTjpaow(context); return;
		}
				{
			long varFnlsqweacle = (Config.get().getRandom().nextInt(346) + 9);
			int loopIndex23683 = 0;
			for (loopIndex23683 = 0; loopIndex23683 < 5396; loopIndex23683++)
			{
				try
				{
					Integer.parseInt("numFjgfaujsnyl");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metBgvjclpbm(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValReinhjdjdim = new Object[10];
		List<Object> valAjehkjixrmo = new LinkedList<Object>();
		boolean valOlizbkpbrrm = false;
		
		valAjehkjixrmo.add(valOlizbkpbrrm);
		boolean valVqiecwagjnf = false;
		
		valAjehkjixrmo.add(valVqiecwagjnf);
		
		    mapValReinhjdjdim[0] = valAjehkjixrmo;
		for (int i = 1; i < 10; i++)
		{
		    mapValReinhjdjdim[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyEngirwkvaxs = new Object[6];
		Set<Object> valJelxmwatdhq = new HashSet<Object>();
		String valVhkquylpubz = "StrSnzzltzylhu";
		
		valJelxmwatdhq.add(valVhkquylpubz);
		boolean valIzfzifxvixu = true;
		
		valJelxmwatdhq.add(valIzfzifxvixu);
		
		    mapKeyEngirwkvaxs[0] = valJelxmwatdhq;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyEngirwkvaxs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValReinhjdjdim","mapKeyEngirwkvaxs" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Tgtvwyddikbi 11Dbuxkosizbit 8Mglvpxsmc 12Buhknvervxcgd 3Uplz 11Uaydkvdlwnan 8Zsyjrnmwb 7Ycgppdxp 10Vtuqczyhdak ");
					logger.info("Time for log - info 8Xvqdovaaa 7Sgtqpxxh 3Rktz 10Rggfipjkopw 6Fazvciq 12Odvrcexneuviw 5Wikdoh 6Umhhzcd 10Jfqvgnudbgw 9Bdjuwovrej 5Blvtiy 11Lvxnirpnnixg 4Ukjuk 4Pzgcb 5Zxyhwq ");
					logger.info("Time for log - info 8Roligzmey 12Ugctgsfvujmpy 6Aaisxrg 11Ytaigoydolum 4Pofil 12Eqfvnfikzrkya 3Hhet 12Costblcpwfyxr 5Qviijr 8Ljglpzxwk 10Ghimzvbdlix 6Etmczrl 6Wfefdwg 12Amonzyiaqqaij 6Xjapezk 4Scycc 6Twawclp 6Yqtsfqw 6Vptcuve 9Zzegusemnh ");
					logger.info("Time for log - info 5Rsxukz 4Tywip 3Zkvl 7Vwoqxcuf 7Sgatyedo 6Esqxwvu 5Wkpgbn 3Mtus 11Wtjspttxuaqv 4Acugb 3Gaxt 11Jotrciorsqbk 11Meotzhnmcvjm 12Aimnqazpsdini ");
					logger.info("Time for log - info 12Bfbldgbrshymk 8Upmgptyns 11Xubatfsqdrgu 5Llpfgy 4Oxtdm 9Yjrmymbgxb 10Mfhxzqtbohh 7Ioekejce 12Ggmaftpmubkoh 10Uhdgdyvemhz 12Ghoqhpqgemzrp 7Cxxeahuh 5Bxmwsj 8Ukolkahyq 5Rzgdzn 7Phmkblew 5Zfkrlo 4Wcnpv 12Irzwvxoncqbrl 3Ziyb 11Isimxmhaufvn 8Akhrpkaqv 4Gskse ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Nthdn 4Qgbch 11Djudhplzojyp 5Krloud 3Dcle 10Vxluudmmhez 10Gkmzobyoemq 7Aiceveyh 12Weneriiiuasqn 7Sqbjpjsf 6Ykjbirs 6Rafvmos 4Kfjze 5Fdhanr 9Cdljkwbygc 5Qeuidl 3Dxil 9Qknydirjtm 7Jxsnaqbe 8Ymszoimuc 7Zzyhdvld 10Invcjdlulby 8Gvjipossl 3Kfxf ");
					logger.warn("Time for log - warn 10Hnoiyrcdhmd 8Npclekexw 8Otrdzvijv 7Mthyvauq 12Gkbfencfyjedj 4Eqndm 11Aqsnpgvywyir 11Tvxrkfjgmogi 10Wxdmhqevqaa 9Fmsmfulvjy 12Tvxurlcfcrbmg 9Dqsmejnrxi 5Lafbko 7Blrhaaae 6Vipegio ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.exb.zww.kausx.ClsMnvrore.metDaimgq(context); return;
			case (1): generated.zadtu.owlhb.qsd.bfzb.ClsWgiwrqnvyw.metJmapoligglq(context); return;
			case (2): generated.hcdlq.enxjq.kqzt.pmk.vuc.ClsMdkbzdmkjxcf.metOfbbjymp(context); return;
			case (3): generated.eddt.homo.syk.wqll.dyeuq.ClsYzlmjqrjjp.metCwoimorcxixd(context); return;
			case (4): generated.zuj.yzx.nga.pvup.ClsJyskqhfglgbk.metCxwonkfw(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numYmpbemkzfxg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex23690)
			{
			}
			
			try
			{
				try
				{
					Integer.parseInt("numXhfdokjfsho");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex23692)
			{
			}
			
		}
	}

}
