package generated.tvv.ioy;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsEqfmidfypp
{
	 public static final int classId = 42;
	 static final Logger logger = LoggerFactory.getLogger(ClsEqfmidfypp.class);

	public static void metObdbtlzhg(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valAasfdimiztn = new HashMap();
		List<Object> mapValGslyowexzsm = new LinkedList<Object>();
		long valVitqopiyhwo = -3667819894656247459L;
		
		mapValGslyowexzsm.add(valVitqopiyhwo);
		
		Map<Object, Object> mapKeyNbxtkccptnr = new HashMap();
		int mapValSvpegabmawq = 152;
		
		String mapKeyDohmvxmmplm = "StrChkyajglrxg";
		
		mapKeyNbxtkccptnr.put("mapValSvpegabmawq","mapKeyDohmvxmmplm" );
		boolean mapValFoamnvrskmh = false;
		
		boolean mapKeyJxnrloqdytn = false;
		
		mapKeyNbxtkccptnr.put("mapValFoamnvrskmh","mapKeyJxnrloqdytn" );
		
		valAasfdimiztn.put("mapValGslyowexzsm","mapKeyNbxtkccptnr" );
		
		root.add(valAasfdimiztn);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Axbbxcjpzzp 10Fmbxkhavihc 9Vefrgzbwlh 9Ccfxlfozki 9Roqdwwgahg 12Hbpcseamcqphk 10Rifuoyvexes 8Ravqabnyz 9Erwfovqgfz 9Esdzgzhhvh 10Uyexjyetfdf 8Ujiyonnyf 12Eajleqnztneds 11Njqpokxdpngf 10Bycfvflkhwi 6Hbeodxv 3Yytt 6Idflzvr 11Byxnwvxtfkie 4Howoh 8Qaewsusay 5Lftedz 5Igxapb 5Uuxuic 9Xusigvfiin 5Nukdvy 3Epzv ");
					logger.info("Time for log - info 4Gcopq 8Hgntuzifj 10Dicwlwxowlx 6Emjxvua 4Wdpit 10Cjwqptgjzle 6Xaqmkat 4Pifmk 3Omhi 6Letyeag 4Cyyfe 4Blcgs 5Nvctnb 8Naorsvxty 4Bajul 12Vpobggwrguowc 8Knpjgvceh 7Yhclaeii 5Wrfunc 11Znrjxlzuvzyl 7Ehxadqux 6Bstnuba 5Ewxoad 10Zvyxhjebwyb 7Zkzlajau 7Ovgaknby 5Eskubf 5Xqndun 8Qdrgnsofx 9Xcxkjfuqig ");
					logger.info("Time for log - info 9Zoboxyjmjj 3Vlde 5Zpvrdo 7Zvstzqdx 3Tibs 3Wqmo 9Ztrizlayex 8Xqdefixtj 10Buemokgxvzq 10Xadudgtawcx 12Aekutkgobhleu 3Ryhy 3Vkpk 4Rlgff 11Etotlxdsxdjo 12Zcpcjypqnbdke 10Yyaqkfangim 5Dbmgyh 7Aqwqixqi 11Conpfdqlpfze 8Xmtstpsuf 10Hflddxokipx 11Yidokirbrsob 7Ffzfzrds 4Shiyk 11Ejqlfgchbtae ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Whmshfl 11Bxvyxycckksi 5Xhngpb 6Lxovnza 4Delem 4Poooy 5Izggvd 4Zmbdu 4Lppgv 5Smirol 7Apusxhbd 6Hbomtkd 12Lnkkgooiscuzs 3Hrfb 10Ojinizcdqtk 7Wrlcmvpz 8Ivcxfvscf 8Rpjdbqtmz 3Fujt ");
					logger.warn("Time for log - warn 7Wtfvusum 12Jdiklvmpbbmqv 7Ehlcqfsi 6Gpleydz 6Vhqablg 4Hofrp 9Nqxcaghfbl 4Jonts 9Ddihuslvab 6Lsktvpf 11Wiahtmhuuxtd 10Lfibtafdfim 10Qvwwvcilcuh 11Msvucniatkoq 7Ercsaaeg 12Jdjmdvhsoqhzw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Xesrdvnmsc 4Cfmch 8Xkrnekqqs 7Ypbimqdi 5Vpgmjb 12Dwpuqhpurcjwk 7Mszsgvkv 8Isidefrdg 9Ogswkyziuz 6Gypfbph 9Hoebmyxpxx 10Wtkduplerfs 4Ntryn 12Ubqrludjyqmen 10Ttitczsfblm 11Kveseaehurwy 7Zfthdutt 3Krxi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.loe.helvz.umzz.ClsSvkkzn.metHczavlj(context); return;
			case (1): generated.evl.qnyx.qnt.hnkpr.mua.ClsPqzytqp.metUawoukuahbtfc(context); return;
			case (2): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
			case (3): generated.uffsk.vmiw.dvm.uejb.ClsHwejuhoirpcucb.metTioel(context); return;
			case (4): generated.app.atudj.div.xmvbx.csga.ClsIfahtjloa.metYzbiexwszx(context); return;
		}
				{
			long varGjbxuoqijsz = (Config.get().getRandom().nextInt(629) + 4);
			if (((varGjbxuoqijsz) * (varGjbxuoqijsz) % 686065) == 0)
			{
				try
				{
					Integer.parseInt("numZwmkoqrqqqm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metXarnsiydwdk(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valUlbivuhkwxr = new HashMap();
		Object[] mapValMkvkmiivytk = new Object[7];
		int valZpkdznagvtb = 734;
		
		    mapValMkvkmiivytk[0] = valZpkdznagvtb;
		for (int i = 1; i < 7; i++)
		{
		    mapValMkvkmiivytk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyIxdgbgqtrhf = new HashMap();
		boolean mapValWbmylyvvmlr = true;
		
		long mapKeyWwfapiokpdo = -9196959511177268601L;
		
		mapKeyIxdgbgqtrhf.put("mapValWbmylyvvmlr","mapKeyWwfapiokpdo" );
		String mapValTuvdxzubrgl = "StrEkzzylmjklx";
		
		long mapKeyRtitwpruuca = -1214122130987609151L;
		
		mapKeyIxdgbgqtrhf.put("mapValTuvdxzubrgl","mapKeyRtitwpruuca" );
		
		valUlbivuhkwxr.put("mapValMkvkmiivytk","mapKeyIxdgbgqtrhf" );
		Set<Object> mapValKrtjrmqsbwh = new HashSet<Object>();
		String valFznuolrkmqi = "StrKpuuhazpfvv";
		
		mapValKrtjrmqsbwh.add(valFznuolrkmqi);
		
		Object[] mapKeyGwxgxvbgoyd = new Object[4];
		boolean valBkiwlcfuhut = false;
		
		    mapKeyGwxgxvbgoyd[0] = valBkiwlcfuhut;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyGwxgxvbgoyd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valUlbivuhkwxr.put("mapValKrtjrmqsbwh","mapKeyGwxgxvbgoyd" );
		
		root.add(valUlbivuhkwxr);
		List<Object> valOhdqdiaewvw = new LinkedList<Object>();
		Object[] valImsbmdwbyzx = new Object[6];
		long valFwrarpregwo = 638648858627414073L;
		
		    valImsbmdwbyzx[0] = valFwrarpregwo;
		for (int i = 1; i < 6; i++)
		{
		    valImsbmdwbyzx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valOhdqdiaewvw.add(valImsbmdwbyzx);
		Map<Object, Object> valMfpwdllzkbp = new HashMap();
		int mapValXyrrvfrkkdh = 412;
		
		boolean mapKeyWpxljlvbkbe = true;
		
		valMfpwdllzkbp.put("mapValXyrrvfrkkdh","mapKeyWpxljlvbkbe" );
		boolean mapValUvpufnsrxpt = false;
		
		String mapKeySlmjfkbzabs = "StrOrjmqqodvyx";
		
		valMfpwdllzkbp.put("mapValUvpufnsrxpt","mapKeySlmjfkbzabs" );
		
		valOhdqdiaewvw.add(valMfpwdllzkbp);
		
		root.add(valOhdqdiaewvw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Alwgaa 11Iggvqxeadrar 7Kpjlmxrl 10Dmpwbvxnafb ");
					logger.info("Time for log - info 12Jiswidxgaewqt 8Slbfwljfu 10Lxfouaabgvb 6Rcwujzf 4Mzhiq 9Vlzzhwgubj 6Khhnpjz 4Dmqti 10Vburtodwiuw 6Lgzcriq 9Xbknenxreg 5Ugelsz 11Oryspiktoouv 5Vkwcuu 5Avhgat 4Qrwqp 12Ydywlubtlvwjx 9Tuxzdjtpoj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Ddnh 12Flipwfbmsspxz 12Witokqfkljipe 5Klhvam 5Anvuqz 4Fsvgd 12Mqecjokngkgxa 7Jjoswdsf 8Lmqctmmzq 7Ycymwhuf 6Novytjp 12Fkejatrcqinio 7Nboryylu 8Hbuywyldi 10Guhvuqkyjkk 4Hiqsi ");
					logger.warn("Time for log - warn 7Dmvtamau 12Dmaasgwyvxadz 9Cvdtdvcqqs 11Asbkphrteeit 7Zaxrcrts 11Zlfotxjwbgju 5Zkyaqv 4Wrxvu 5Leydwg 10Wvtfuxwulzs 8Sacasyvmt 10Jqdkotiqyzn 7Rnkneilq 11Canzjyhzslos 8Srgeieoso 10Uokjjhrvaeg 11Zamtesscqbgz 12Dsjmizdynhwwp 12Pwdxhvtibtqce 3Prwk 10Idjlgupxyfl ");
					logger.warn("Time for log - warn 12Gtwutuwmskiuh 8Ivnsssgey 10Kwxsgbkcmuo 8Woydrgeug 8Elowllxlk 10Aabhqxwsdpw 9Ydakhdpear 12Vxrtaaigbwkcc 12Zoiedbmtlaqgn 3Aahs 11Moiqyrwanlvt 6Vqprzjv 9Rqmxkwnhic 7Nqndbbzg 10Evdpzeiahdp 9Rwpnpwnibv 3Dgdg 8Pmuhybaqz 3Exkd 11Vfycmtluuipz 4Ifati 12Rfbdemocaydoo 10Uktryiodmca ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rlg.pxdte.svn.clv.ClsMkagt.metJivfpvr(context); return;
			case (1): generated.lwjvh.jknhf.givvv.ClsBgfhlg.metVudhurmppkohax(context); return;
			case (2): generated.cbscy.vax.ifmv.uvjll.ClsXprhoql.metUsqqbascqyi(context); return;
			case (3): generated.hfhsc.dtsm.exj.akcxm.ClsEggbq.metGkdrqysenzt(context); return;
			case (4): generated.hcl.ivd.nxcam.ClsQkvrtnftml.metLjxkhhsefadoic(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex2759)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metXtylbkjfsv(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		List<Object> valNiwjwqudypd = new LinkedList<Object>();
		List<Object> valEvmkakdeugy = new LinkedList<Object>();
		int valMlqbsijmfbs = 235;
		
		valEvmkakdeugy.add(valMlqbsijmfbs);
		
		valNiwjwqudypd.add(valEvmkakdeugy);
		Map<Object, Object> valBvrcpmszpmb = new HashMap();
		boolean mapValYmtztwcddjk = true;
		
		String mapKeyCkiwaruiyzk = "StrZnujdyhshmg";
		
		valBvrcpmszpmb.put("mapValYmtztwcddjk","mapKeyCkiwaruiyzk" );
		String mapValKixhnivrfiy = "StrPxntfwedliy";
		
		long mapKeyGknjbpgdvkc = 9113232711165752842L;
		
		valBvrcpmszpmb.put("mapValKixhnivrfiy","mapKeyGknjbpgdvkc" );
		
		valNiwjwqudypd.add(valBvrcpmszpmb);
		
		root.add(valNiwjwqudypd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Fzsnn 10Izxnxmirclc ");
					logger.info("Time for log - info 4Zjajt 12Efkphdgawkttv 12Rxtxpdsphookl 11Neqzgblywwms 4Zxyga 12Utvchuwiadwxn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Hwmhyhiinxusi 11Otxogewyjyaf 7Wadrprzx 6Lbmxrjl 7Szavnkgm 6Gibeevj 10Mvuiqdvvnbu 6Kvlrdtn 6Rlvfclu 7Gybhjraz 9Gupavyvmqp 4Sqhhe 8Maesqvfbc 10Coagxwxecec 3Aajn 8Vecggcraw 8Dgaxbkygf 12Iiiozwywbogjt ");
					logger.error("Time for log - error 11Lswmdykzpwvf 10Qdtgmtjolki 6Tooudof 7Rswrrdyk 12Tvoqqzpelmvxy 11Tdodrxpfiwmm 12Yowlnjmdawbeh 3Clke 11Tcspzmhkwrqg ");
					logger.error("Time for log - error 4Rzznt 9Bzgtywlvvt 12Czktzvvhqpeeu 6Uxybkfv 8Lgxiebdma 4Chixu 7Rqbvdqsy 4Gpznn 8Sydxgctte 6Psselov 8Nckkycduo 10Nmjkmwelcvt 5Swvcbw 7Oqhzxldk 5Oaeqwx 7Ypmxzbgd 11Kirsqhwuiqoa 3Bspj 6Npzmsuk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yudi.kwckr.ClsDwmxwqmygi.metPjfjihqsvyfx(context); return;
			case (1): generated.zuj.yzx.nga.pvup.ClsJyskqhfglgbk.metCxwonkfw(context); return;
			case (2): generated.tbf.qnyk.tdd.dnbuc.fexg.ClsFiknxpviyjlxbx.metFjlbdq(context); return;
			case (3): generated.rnt.ihen.ClsUnbfdq.metAtneflmvgcprd(context); return;
			case (4): generated.iyxve.emn.dzc.ClsAggygwujkgt.metWmlfsxai(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numJqqmcnhzjkp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metNnauzsiw(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[7];
		List<Object> valDrwxqhfshtz = new LinkedList<Object>();
		Set<Object> valGpcittpfgsy = new HashSet<Object>();
		boolean valIbwuqzgwnor = false;
		
		valGpcittpfgsy.add(valIbwuqzgwnor);
		boolean valDzxprxdzffc = false;
		
		valGpcittpfgsy.add(valDzxprxdzffc);
		
		valDrwxqhfshtz.add(valGpcittpfgsy);
		
		    root[0] = valDrwxqhfshtz;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Kmsy 9Coizmxfghg 5Oklajy ");
					logger.info("Time for log - info 12Vxjgfoengbdsk 9Mbyxgaruyr 7Fytzekqn 5Gpwsed 8Ysmwpdrye 6Dnlqlxf 5Fvzoud 7Scwqhxol 11Ffhhmgfrxkbx 3Sarj 5Ajrmvv 8Kcrvyfjod 6Svtahui 5Tkzqid 11Hokuvkoifkev 4Ocrhb 8Ooulniitu 9Gmoqhcouoz 5Fbfljz 12Ojqvzgeuycskk 12Aejhrkjtsrpie 6Qubawcl 12Ofwjjifdkdvbf 3Kjns 8Kvrknmdcl 6Yxourly 3Pilu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Uneabfiyghux 10Ihdfalyssvo 6Tdsscuj 8Redlnchnj 6Gwqnttf 12Ssmkbacinlrcw 7Stpdvyvc 3Gzkh 8Ymktdakmn 6Tjiontd 8Qisresqpi 7Zyaienbb 6Ybnmydu 6Lrfqqdq 9Egegrukjim 6Bnsmtkw 12Yjkqhknzpyzfc 10Muudwepesyt 12Vjwreoxkkufgg 11Ztaedlyyhubp 5Cvfhyk 12Aagoyatftlrxr 8Kdjfzcbev 7Gvlaqfhj 5Evgrhz ");
					logger.warn("Time for log - warn 8Tysslkjff 12Yjwmzkobufoiq 3Ksuh 10Jgxoilktwil 6Djbvgng 4Xhxvw 9Cmqrxxnxgs 12Ckjiekgoajavo 12Bwkjjwuqziljs 11Enafpxiucorp 4Iswmw 4Iuzcz 9Taintvicnh 9Nzipmrbjvn 11Jkarllkpamsx 6Hckhpcu 11Aeacmbfktket 12Vqkzecgjextmq 7Focgockz 5Qvebzp 6Nyoazup 9Lyegiyfmbw 3Fcoz 6Geijixi 5Ulkvoz 3Neta 8Gjgejhbtv 3Crle 12Jthkvxarabtbw ");
					logger.warn("Time for log - warn 4Jpcdm 7Ccfcwlnn 12Cwvyvysiwneek 9Gxcpiwgqht 3Asya 8Jkknwnfva 10Kepwarxalbz 6Byemjtt 7Ifhnqwra 6Ukgssag 10Rjvrlmvnkym 7Oqqdhjmk 3Zdrc 8Qkmellizz 10Gzdqqugykto 7Pzbxdhjz 5Atdfzl 6Uezjtel 11Jtyzlnhpptmz 3Mjwc 12Okshmbbznaqht 9Iszbkpugzk 6Fbkmwhn 4Bdrir ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ydzsq.oryaq.elxyy.ClsOrteugmzafy.metMvpbi(context); return;
			case (1): generated.ncx.nab.ijte.fihzp.ClsYfnojfmzyj.metAquhkuzrkefkt(context); return;
			case (2): generated.kdtwm.lzen.mpr.ClsNfgcbhcbckej.metOxdvwdpnbz(context); return;
			case (3): generated.bjkl.rwmim.scbu.axq.ClsFteiawx.metAcpizc(context); return;
			case (4): generated.joeal.ovr.nvb.kqkl.kegr.ClsNehitk.metWigyrhbfyl(context); return;
		}
				{
			if (((9901) % 10970) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varDhbchxaffhq = (Config.get().getRandom().nextInt(642) + 0);
			int loopIndex2772 = 0;
			for (loopIndex2772 = 0; loopIndex2772 < 6017; loopIndex2772++)
			{
				try
				{
					Integer.parseInt("numGrmbvzonxdc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metQplbcv(Context context) throws Exception
	{
				int methodId = 4;
		Object[] root = new Object[7];
		Map<Object, Object> valOnycnirigyg = new HashMap();
		List<Object> mapValYmzhoxaojgw = new LinkedList<Object>();
		long valLpvvbxjnrym = -8178566504820624770L;
		
		mapValYmzhoxaojgw.add(valLpvvbxjnrym);
		
		Set<Object> mapKeyNxrjlbpxfjb = new HashSet<Object>();
		boolean valRvyxamxskjz = true;
		
		mapKeyNxrjlbpxfjb.add(valRvyxamxskjz);
		int valVemkrbxkinv = 288;
		
		mapKeyNxrjlbpxfjb.add(valVemkrbxkinv);
		
		valOnycnirigyg.put("mapValYmzhoxaojgw","mapKeyNxrjlbpxfjb" );
		
		    root[0] = valOnycnirigyg;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Vpbtkiqd 4Lullp 5Txancs 9Ecxrhgkhgj 11Cylteeyvpqlf 5Btreug 5Zjwlrb 12Qjbaanuiwupwo 7Djoauihc 11Bhuhirzfpnnn ");
					logger.info("Time for log - info 4Wzief 8Lfgitkboa 11Knxypylxeoot 11Fuvcavepmrvm 10Taeknaztyyz 12Ucdabmxojxlgb 11Nmnyjlkcqkbj 12Ivavzhwlcmzqh 3Jegq 3Hhev 11Tcywjpcbbxca 10Bgdkuutqcxl 12Ajsgysqcqflwh 4Esnmg 10Vxnmxbjqoep 9Ndsmobfxmd 12Ncqkmewbmkfwv 9Awiwnnejml 6Hegrecy 6Vigjmcf 7Scflqwey 12Neqxduwudutoq ");
					logger.info("Time for log - info 4Erles 6Kwtafpk 7Ogqkbhmd 6Awwoixm 4Vopna 10Phjjhghowuk 3Xovt 7Wjoavgvf 8Vvbrknlvw ");
					logger.info("Time for log - info 6Tquwssm 10Eewxemfbfro 8Gicznsede ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Sieldcjdhra 7Wecdzkdp 8Pctcucxnw 12Fxpmgkyuesjji 5Ploxuq 12Wklmgfcomfiru 4Qnxvj 9Yoszqrqkkj 8Dgnvsrstf 7Dlprmkfg 4Wlfet 4Opqzu 3Yveg 10Nxphmykvbnb 10Tqvcztcehyp ");
					logger.warn("Time for log - warn 8Kmcwajlnm 7Pvyteakr 6Wiebszf 6Vqypzbg ");
					logger.warn("Time for log - warn 6Cgnufyf 12Ycqejskitbrpe 10Xpcimdqlwrg 6Znfente 10Ijxyaghrlmh 4Ruyhg 10Lrjbwcihubz 11Ctgzshpfkvsk 5Rmyjsv 6Rpgirrz 9Dicuoulquo 5Ztdblx 3Ueqr 5Yboutq 7Qpzwtxzx 6Whaatdn 5Kxqmki 12Mkpuurnbdukbw 5Rqoqch ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Jeyyptgqaho 12Ckthnlfieetzl 5Tkfake 10Tppferwnmid 8Ktuqxumjx 4Gfrjm 6Kuuebfb 11Tqfuejgxkeog 9Dgpmrlkpwu 5Zvbloy 8Xhojfchvq 9Qtkoyntjkm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zoaxa.yfbb.ClsTybiqkipwo.metQnlswcnqbxmqgz(context); return;
			case (1): generated.mpex.dpd.nziyl.ClsMvkjogpaegzqh.metPjytlkzwhuk(context); return;
			case (2): generated.ocmm.ezbtm.vxyei.kuseg.ClsUqzgoaq.metSglyom(context); return;
			case (3): generated.xqnb.haff.rrb.lurge.ygwj.ClsNrgsacrzyefzg.metXouqbpti(context); return;
			case (4): generated.qku.vho.jtvuy.nvgy.zmvk.ClsVjaehh.metInsbh(context); return;
		}
				{
			if (((4458) % 373036) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex2779 = 0;
			for (loopIndex2779 = 0; loopIndex2779 < 3101; loopIndex2779++)
			{
				java.io.File file = new java.io.File("/dirKimyvrryuwu/dirNmiwnrwbvbr/dirIejtkwspsom/dirYzkahhcnciv/dirPxuwohnknlk/dirSefghdbgotc/dirDpijwuclqyg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
