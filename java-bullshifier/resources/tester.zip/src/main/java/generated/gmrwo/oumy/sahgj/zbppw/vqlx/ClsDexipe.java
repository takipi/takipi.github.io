package generated.gmrwo.oumy.sahgj.zbppw.vqlx;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDexipe
{
	 public static final int classId = 344;
	 static final Logger logger = LoggerFactory.getLogger(ClsDexipe.class);

	public static void metElwawj(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValNnrvcsahmmp = new LinkedList<Object>();
		Object[] valFfkywjwnrub = new Object[6];
		int valYsjwxnfgdpb = 940;
		
		    valFfkywjwnrub[0] = valYsjwxnfgdpb;
		for (int i = 1; i < 6; i++)
		{
		    valFfkywjwnrub[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValNnrvcsahmmp.add(valFfkywjwnrub);
		
		Set<Object> mapKeyCjafnbepabw = new HashSet<Object>();
		Object[] valUhehqkzlock = new Object[11];
		String valKxibmvxnylm = "StrZsrmurictkk";
		
		    valUhehqkzlock[0] = valKxibmvxnylm;
		for (int i = 1; i < 11; i++)
		{
		    valUhehqkzlock[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyCjafnbepabw.add(valUhehqkzlock);
		
		root.put("mapValNnrvcsahmmp","mapKeyCjafnbepabw" );
		Set<Object> mapValCtnzaocxixu = new HashSet<Object>();
		Set<Object> valVxciflazyxz = new HashSet<Object>();
		int valPghwzbjnvae = 382;
		
		valVxciflazyxz.add(valPghwzbjnvae);
		
		mapValCtnzaocxixu.add(valVxciflazyxz);
		List<Object> valGghweydvvii = new LinkedList<Object>();
		boolean valJptgztbmxad = true;
		
		valGghweydvvii.add(valJptgztbmxad);
		
		mapValCtnzaocxixu.add(valGghweydvvii);
		
		Set<Object> mapKeyBylzpnimhed = new HashSet<Object>();
		Map<Object, Object> valRfdududcqpd = new HashMap();
		boolean mapValMolqiyznnnr = true;
		
		long mapKeyHfuctucbbgp = -6797248779402594859L;
		
		valRfdududcqpd.put("mapValMolqiyznnnr","mapKeyHfuctucbbgp" );
		long mapValGmkwxlxjrbi = -565620777773754362L;
		
		long mapKeyEpdsqlhlnky = -5393204660950210158L;
		
		valRfdududcqpd.put("mapValGmkwxlxjrbi","mapKeyEpdsqlhlnky" );
		
		mapKeyBylzpnimhed.add(valRfdududcqpd);
		List<Object> valOflcwfkirgz = new LinkedList<Object>();
		boolean valAyydjjqivmb = false;
		
		valOflcwfkirgz.add(valAyydjjqivmb);
		boolean valElyfhoagueb = false;
		
		valOflcwfkirgz.add(valElyfhoagueb);
		
		mapKeyBylzpnimhed.add(valOflcwfkirgz);
		
		root.put("mapValCtnzaocxixu","mapKeyBylzpnimhed" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Sybldhjnrekn 9Eldvxbpyyt 8Tuvtrdiku 3Ruxf 7Umwqmtpx 11Hndsjgjavkro 11Fcgosggmihwk 12Cyvzhckffaqzz 9Phsrmhtkdt 7Lnhhflou 10Zkvwpqcarkf 10Dvlpnxydqjn 10Njjlfdruqir 4Mcbaa 11Arbqeizdernw 10Xhkbrutuzjq 6Mvgvwin 12Jphesbykbawvt 7Esteqzll 7Pexotthe 7Oyyxeptl ");
					logger.info("Time for log - info 5Laxqti 7Usslfxmh 3Tbwx 9Ggizcfidmx 4Bkpdx 6Cehaxid ");
					logger.info("Time for log - info 12Rlmjalnkqlbaq 9Htqquzkckn 7Pqpliwfa 10Jrrkracbsdn 11Mhoexjqgpnkn 8Snmoffsgv 4Dwsxs 7Yjyylgkt 10Hlhsdsfsnkm 8Eujraiviz 7Cqzpnxek 5Ziirxb 9Vycqihqbua 7Wovvdtru 5Fwwyhn 10Wuknzzsulbj 9Ljjmvvuisc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Qoulpyumy 12Dcpjlirleggsy 11Lyrohuypquml 4Unpti 11Xugpbkveeiav 8Uznrkdnbu 10Qcouiglohjx 3Dklq 10Rbtfmvoqqat 5Uwjmpn 4Kftvs 8Ezcydqbig 9Eurccfyxbo 5Twbvkl 9Glivkmrnbw 3Qwkx 4Rlqcy 5Hwazoe ");
					logger.warn("Time for log - warn 5Lcahao 11Xtnkncdujtnm 5Lrgoap 10Axwadkdfmpc 7Hiryxbrm 6Lhglfue 10Uwyutaylxqt 8Rlzgkmfun 12Zyksywqtvcsqq 10Znsgevwdxep 12Dkldhijfazsle 8Rwpxtdgfx 10Alqfuhuhxje 9Qstfcacddi 8Rdgbzeqym 4Klpgu 12Ptyuofugncrcf ");
					logger.warn("Time for log - warn 7Cdwtckdr 3Honh 5Gikldq 12Jvuiigzrlvwbr 5Johpfb 10Yjvtyprzmri 5Teazah 6Jvibvvb 3Mynk 11Crlwsmmabqlt 5Haxeqh 7Wdzmamjy 10Dmohidksmgb 5Dgllso 11Mbrvrdwewidv 8Geqyivnvi 8Yvcrvjzfy 3Ujbr 8Nfmhiwkjn 3Ixho 9Xkograewnr 12Trnvyadnpdggg 3Sjqa 8Gghztgbhg 8Nxnmhujwl 10Arhzesesdbz 9Idpllcxuex 4Jchgm 7Dzcgvsfn 12Ejvboxrdospfw ");
					logger.warn("Time for log - warn 3Cuzw 9Sszexvzauc 6Kpysdoi 12Uehygiccrauro 3Fqsm 9Nlbbizfksu 9Zwscssbqge 9Cppkvnbwsr 3Fzxr 3Ztzo 4Lfzef 10Tpansfidkfo 4Dzqfe 7Hfvdyloh 8Alqpkkgmd ");
					logger.warn("Time for log - warn 11Difnqoqpcnjt 6Pcesmab 8Ppdbpfdvv 7Jptdmoqh 7Jmunvheh 8Obypoqvet 5Gnnehw 6Ujmhfsr 4Uspbg 7Wawswwdi 9Mqokctmcge 11Pjobwxloburp 6Sqkbwcm 10Wfwjgdslvfc 7Dsjmguqh 12Ytlbvkhlgnybz 5Karupk 6Lbouuwe 12Xxxbsjbnqmxzz 7Xwpjunxa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kivyr.smd.affpo.ClsEqlzjivgvsoafb.metFtrfvpusk(context); return;
			case (1): generated.liyl.sfhr.ClsNilzqakfd.metXwuoarwg(context); return;
			case (2): generated.alv.nmsc.bjnyq.zit.ClsUxjrwrfu.metWcnramwnolmtp(context); return;
			case (3): generated.qer.bwl.ClsCbeyhqqy.metFgzkaoqzw(context); return;
			case (4): generated.bxw.hza.cjj.bpzns.qzgt.ClsQbxnaxsj.metMcvovzzcwbpnsh(context); return;
		}
				{
			if (((172) + (Config.get().getRandom().nextInt(166) + 6) % 170954) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(77) + 4) + (4572) % 769811) == 0)
			{
				java.io.File file = new java.io.File("/dirJtnnabaenin");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metMyagpq(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valOiwztzvjeqv = new LinkedList<Object>();
		Object[] valFrmdtlblkpq = new Object[4];
		String valVmkuklgjquv = "StrNqfnrkhquji";
		
		    valFrmdtlblkpq[0] = valVmkuklgjquv;
		for (int i = 1; i < 4; i++)
		{
		    valFrmdtlblkpq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valOiwztzvjeqv.add(valFrmdtlblkpq);
		Set<Object> valUtdqsxslsio = new HashSet<Object>();
		int valZpctwkwyxru = 359;
		
		valUtdqsxslsio.add(valZpctwkwyxru);
		
		valOiwztzvjeqv.add(valUtdqsxslsio);
		
		root.add(valOiwztzvjeqv);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Mckpzolhu 9Ourpgpkbzv 9Exelvhuzfq 8Jqrnrctsz 12Tdqwufikukiqx 8Oauzyitao 4Hbrff ");
					logger.info("Time for log - info 12Dyyvdmeygjgwb 8Qoockkdgt 12Tuhicnvjgyqze 4Wpajq 5Qdrvxm 12Ivvuomksvcmsg 11Gwhbmqvgrotx 4Krxse 11Diyjscqguhkk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Kgjbaw 11Cdcxhgkocyzf 7Xxdeievn 12Qowayeouwgmhk 10Jqtsokbvpjx 9Mdpcpnenci 7Pyouajaj 7Orwtlqpp 12Ctmxzqwwpavng 9Ifenmubsyc 6Qgnoako ");
					logger.warn("Time for log - warn 4Mvudf 9Udhsgcforo 5Vpqhjq 9Qxbchxekfc 6Dpofnjb 5Hmijin 12Qcxzghjogjsri 5Azdbgl 11Zffxxzalfamb 4Collb 3Otpu 6Fwyaffy 4Cugtr 7Ritskcwh 11Oanytbcdidsx 5Pftvuh 8Oldncjemf 12Diimadlkjnrbd 12Iwnzgmpesdfnj 11Cyfaskgxwula 4Ugqwz 10Bjlgvhqmbgx 3Ycni ");
					logger.warn("Time for log - warn 11Xwxclxntoxfd 8Szzyhdrcf 8Qbpffdfje 5Uagauf 3Uezp 7Ftprdiqk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Mwrjzdixfkj 8Iodajymyc 3Lfhs 8Gqdcmuyin 8Hefbmgivl 7Crxvwgwf 5Oonsii 12Inghpflkbvfnd 12Dskxnhoeltanf 4Mhdpq 9Enyiiulcbp 12Gmddtoqtkkbms 12Acmrugmjpwagi 7Txkwvmes 6Wpxufnh 8Zvvrdixja 5Tnluts 11Pwnvrlypywhc 4Bpqbj 11Dbbznfbaaknn 9Mryqamtvkp 5Uuuhbn 5Fodlnf 10Fkzpplqqjyv 9Axgzpshlmv 11Ozgpwmydlrhw 11Mtazuawdraqa 5Wneewr ");
					logger.error("Time for log - error 8Jsquvmkfd 6Vrdjpku 11Icdavbfiztgg 11Wstaairyzuni 6Qluoxlc 3Fumr 10Fvuomoreihw 12Xlzgieurgdrpi 4Pypap 10Ruldhiyaoqw 9Uoicqcjwzc 7Vdglcglj 4Xxzhc 11Vktqwezlvkaw 3Pfvv 12Hsftaclsnqrxh 4Uikda 7Ztxoexsc 12Bqhawgoukhycm 10Bzhimxmsnph ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nlkyt.zasi.ClsQaxysyqic.metUadhackqygx(context); return;
			case (1): generated.ndkx.exo.qju.brvd.ClsMxlcse.metFbamruj(context); return;
			case (2): generated.idk.jvavb.vjuwp.iuzf.fawz.ClsRtwkffyfhbvpjl.metHdimsltzwuwz(context); return;
			case (3): generated.hjt.myuvv.hkc.tfpi.ClsJfukwmizredp.metYduwrchx(context); return;
			case (4): generated.lhhp.jdgtq.lkhh.mkg.wzb.ClsZnuut.metLrcocicqjkqlv(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numAeovvszpbot");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex25829)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numPcvaytwzdcc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metBsktjpxjygwoz(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[3];
		List<Object> valNgfqeconwbq = new LinkedList<Object>();
		Object[] valXkfmylyezzy = new Object[8];
		String valOqnpvaphynx = "StrYismctodhjt";
		
		    valXkfmylyezzy[0] = valOqnpvaphynx;
		for (int i = 1; i < 8; i++)
		{
		    valXkfmylyezzy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valNgfqeconwbq.add(valXkfmylyezzy);
		
		    root[0] = valNgfqeconwbq;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Rmrnyzh 9Tjzlvninuq 5Hinovf 11Orgctoszdurs 7Jcxlxaoc 10Bjxzwpezviz 12Lyvzxcbwxwzux 10Wydolzqbbas 8Gjygqlfgn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Dgvj 7Fawcxnmf 10Hmkazpgxnju 11Xeredwdjdxty 7Tbuqdoms 7Qchsinku 11Prergvhxzgah ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.laaxy.myh.ClsSglobn.metWaahty(context); return;
			case (1): generated.iyxve.emn.dzc.ClsAggygwujkgt.metOlhruhgstjli(context); return;
			case (2): generated.kibd.nddr.nknr.pccz.hryio.ClsBgthm.metFrmpvshfvh(context); return;
			case (3): generated.xnl.gdx.dmkh.hpyan.ClsNxgzyqd.metRbhfzkkxtnc(context); return;
			case (4): generated.cqy.ffep.ClsWvinhicphnl.metWwbnpyd(context); return;
		}
				{
			long varGddzrdfxbja = (Config.get().getRandom().nextInt(923) + 6) - (4583);
		}
	}

}
