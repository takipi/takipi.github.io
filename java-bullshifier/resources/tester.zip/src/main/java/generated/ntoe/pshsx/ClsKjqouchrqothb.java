package generated.ntoe.pshsx;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsKjqouchrqothb
{
	 public static final int classId = 434;
	 static final Logger logger = LoggerFactory.getLogger(ClsKjqouchrqothb.class);

	public static void metMqidtlggwab(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Object[] valFsqvyyhxtag = new Object[7];
		List<Object> valDpvxpgugxwu = new LinkedList<Object>();
		boolean valCexvdvjpxxo = true;
		
		valDpvxpgugxwu.add(valCexvdvjpxxo);
		int valLsibatkamkc = 569;
		
		valDpvxpgugxwu.add(valLsibatkamkc);
		
		    valFsqvyyhxtag[0] = valDpvxpgugxwu;
		for (int i = 1; i < 7; i++)
		{
		    valFsqvyyhxtag[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valFsqvyyhxtag);
		Set<Object> valLsjamtshcdy = new HashSet<Object>();
		Map<Object, Object> valFrsgygohkim = new HashMap();
		int mapValUrsvxanuhnp = 452;
		
		long mapKeyEjzraohjjhn = -2188045833867676808L;
		
		valFrsgygohkim.put("mapValUrsvxanuhnp","mapKeyEjzraohjjhn" );
		
		valLsjamtshcdy.add(valFrsgygohkim);
		Set<Object> valHnlnhgsryly = new HashSet<Object>();
		long valDflvfsxcqiv = -6656321977250104360L;
		
		valHnlnhgsryly.add(valDflvfsxcqiv);
		
		valLsjamtshcdy.add(valHnlnhgsryly);
		
		root.add(valLsjamtshcdy);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Ujpx 9Tngeqvwmja 9Ikhwkjzvls 5Kpqygl 7Wedpdrhi 5Dahodv 3Warb ");
					logger.info("Time for log - info 6Wakukry 7Uqtyumov 12Sbtigmeumayhr 10Qxsglhvxiag 6Rmnymaz 11Lexvnllpskro 9Megmdaflrm 3Xcpv 5Uzgxho 6Uppjbqs 11Qewuhmhdyyfq 11Dubpagionkcp 12Efpevqseiblcw 11Eqsiohlronhq 4Ioszr 11Xcchdklumsvf ");
					logger.info("Time for log - info 3Zwlx 9Ajnbddcafj 9Jnggmxboxf 5Ltuoab 3Mubs 9Pwntvttmrc 7Aitqaens 7Ysyufuna 3Rusx 8Emzmectrq 10Sgbwuozgmrl 5Jpysjb 7Wkrzekru 5Hqghkn 12Zxttlpmotdyri 10Lmbkuibdxvb 7Zqsmoysq 8Rxhxnbffa 12Cmqxwlcgwtlzh 11Yyatygsuncae 9Mudgoxjudg 7Lysezcas 12Jcbizmfpudqmn 12Uhxtxgkmcnzbj 12Vifqwsuxercij 11Fatlcsogbzuj ");
					logger.info("Time for log - info 5Mneyjn 12Jqrvathmoeaij 6Zidtciq 5Fwqrrj 8Ioqcvzrlv 12Vsayjmcpyinkm 6Wbeclhw 7Xugmhjmk 4Ybjku 10Qvsbmgojsgb 10Ujwbrzntfhw 3Umja 8Lycvhiimb 12Lvdfuixzxourq 9Wgxbatywcr 5Spmouu 9Cuoltokxpu ");
					logger.info("Time for log - info 6Twqacod 4Mxkwk 7Ekpbmvol 6Nflhrwo 4Cympk 11Fgtucahqdqva 10Brzqntzwtqc 7Xgxxmzkc 5Acvgmv 11Pficavxkoogt 7Bdiesuda 11Ynqmrqrudxyp 12Taucomfzxberr 7Cylpwxoo 10Xayftvhifyw 3Uafz 5Rjrhab 5Cmopeo 3Cukd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Cfdbfjxdd 4Vpaoj 8Yyojroidt 11Rtuheelulrxp 5Apwxzm 11Ufuncdlmokeo 10Vjjtfulhpug ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.swyg.szfbf.ejprt.ovbj.ClsEqyrgxer.metZenxrea(context); return;
			case (1): generated.zmpxh.humct.jpc.zcr.uswj.ClsMmunby.metPsfhf(context); return;
			case (2): generated.mipzp.qfu.axrt.ClsJkbbmhkrxeo.metUvsxqnes(context); return;
			case (3): generated.vbmu.nqy.tvok.ClsTqtbdjb.metQkzwdoc(context); return;
			case (4): generated.zmpxh.humct.jpc.zcr.uswj.ClsMmunby.metAhzyvaxwwvb(context); return;
		}
				{
			if (((1160) % 47653) == 0)
			{
				java.io.File file = new java.io.File("/dirXuwxmhmtcza/dirHzeaouzurgc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex27285 = 0;
			
			while (whileIndex27285-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((whileIndex27285) - (whileIndex27285) % 692908) == 0)
			{
				java.io.File file = new java.io.File("/dirAqltvaktmrt/dirZmfnmrjddvg/dirSyxfchwnzlq/dirCukkyhlawsm/dirUlydrydbkja/dirMxuyhhujodt");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metYmqdhslyo(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[7];
		Set<Object> valQjvgvfdcwtd = new HashSet<Object>();
		List<Object> valMoherjwnxdj = new LinkedList<Object>();
		boolean valZigspgfyaip = false;
		
		valMoherjwnxdj.add(valZigspgfyaip);
		boolean valFmtzfxcvxqi = true;
		
		valMoherjwnxdj.add(valFmtzfxcvxqi);
		
		valQjvgvfdcwtd.add(valMoherjwnxdj);
		List<Object> valXtuyhbxncca = new LinkedList<Object>();
		long valLjainxjpzio = 1948310278373351683L;
		
		valXtuyhbxncca.add(valLjainxjpzio);
		String valHqpvyzapywi = "StrIeuifnlmxgh";
		
		valXtuyhbxncca.add(valHqpvyzapywi);
		
		valQjvgvfdcwtd.add(valXtuyhbxncca);
		
		    root[0] = valQjvgvfdcwtd;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Znowjiqaeit 9Qxfmzxlxfb 5Hawfpo 9Syjactvhyc 12Bmjovfqubbttk 7Lrsocfrt 11Muqlxqforfmf 8Ihmmotvxl 11Kzynijvdymgf 8Whewvwudr 12Dayafcxnteiak 4Exslk ");
					logger.info("Time for log - info 11Zojwymonpsuc 5Gremgf 6Kqgbtvb 6Ahhyaae 6Ebpcado 4Jqgnv 11Udgfruliwmek ");
					logger.info("Time for log - info 9Drslbqnkpg 4Ugoib 11Goadumlizyza 4Wmiel 12Ajqbvsfqsmadx 6Ydyjdxo 5Gzjnqn 10Bqgazmkfgof 5Jdpxup 10Epioqrqeroy 9Nsbxsozrjz 11Bgabvwuiqdbq 8Jbayanabw 11Fjkgbiqwxxhw 12Olvyyspdgodoc 8Zeyhffgvx 11Vanbnhxormcc 8Tylgenmkr 11Lojndhrxwctr 4Hracr 8Inmltcjkc 5Sopyjv 3Cfrd 8Hemfsluel ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Rdianxjtnmwb 9Eedrvgorhh 3Runl 5Mbttjf 7Agbzbcpi 12Wptsqqnxijbwm 10Evqdnulesyy 11Awfxffqsnhnk 9Kobjstykkn 3Ifgb 10Mzpwlvcxbil 6Sdujlol 12Mjzafzcaijfbb 5Ieetfr 7Snerlyiu 3Cppo 10Tdwmqzzdtqs 4Plvth ");
					logger.warn("Time for log - warn 3Egnn 12Aggbnbengmisw 4Dsvyu 7Cqrmsral 6Ijjkrvi 10Bjkcabdnaws 8Uvhrkshar 5Muxhhx 11Yugmjaoekjkh 3Vczi 5Afyube 8Fxdavgfjj 5Dujvyz 7Jqwclrmh 4Pbila 6Ydpkkcd 9Hrnacmeivj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.axdim.stv.ClsSaegiqo.metVwtuv(context); return;
			case (1): generated.kdtwm.lzen.mpr.ClsNfgcbhcbckej.metRvvjmdhdx(context); return;
			case (2): generated.rayp.ekfg.uust.ClsQhtttdalkvmcth.metYhiqkxerxikn(context); return;
			case (3): generated.flwv.kjeus.ClsAhjobcsyb.metMaqmdna(context); return;
			case (4): generated.rludj.zqn.tuc.ClsSdrvvvm.metSmvhpgejrya(context); return;
		}
				{
			int loopIndex27293 = 0;
			for (loopIndex27293 = 0; loopIndex27293 < 7643; loopIndex27293++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((loopIndex27293) % 921458) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirUkvrnwoullc/dirXajmosfvbpv/dirYfuhltssidn/dirYeawtslxjxf/dirOunxnfoocgz/dirEbsrabnlaoo/dirOvyfeejvckt/dirXmrcvghnpom");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metClrqsbb(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valUzhgzoizhil = new HashMap();
		Object[] mapValSrhslhvtddf = new Object[7];
		long valGndipyehvvp = 6431584524198773136L;
		
		    mapValSrhslhvtddf[0] = valGndipyehvvp;
		for (int i = 1; i < 7; i++)
		{
		    mapValSrhslhvtddf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyQjmbwlpjoni = new LinkedList<Object>();
		int valIvjcfnvcpbc = 423;
		
		mapKeyQjmbwlpjoni.add(valIvjcfnvcpbc);
		
		valUzhgzoizhil.put("mapValSrhslhvtddf","mapKeyQjmbwlpjoni" );
		Set<Object> mapValGyskrqignbd = new HashSet<Object>();
		boolean valSnjdniklhwh = true;
		
		mapValGyskrqignbd.add(valSnjdniklhwh);
		
		Set<Object> mapKeyDibdzntvmpb = new HashSet<Object>();
		String valIqsbjnuofmk = "StrFhhiphqpisl";
		
		mapKeyDibdzntvmpb.add(valIqsbjnuofmk);
		String valAnuiqwmzszv = "StrAmdlqrpxncg";
		
		mapKeyDibdzntvmpb.add(valAnuiqwmzszv);
		
		valUzhgzoizhil.put("mapValGyskrqignbd","mapKeyDibdzntvmpb" );
		
		root.add(valUzhgzoizhil);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Qvpglyhrzu 5Hvlklt 7Mqehveyv 11Cbocthsvxleo 8Kfjmnflsu 10Senwjftsjka 8Mzwvoxldm 3Qedt 6Onksfuu 8Wzlnprgxv 5Enthml 11Qpjijygyxwgy 11Amxgvfnnbnsc 7Jtpftnud 9Gfnggqqmto 8Rkhdjwltu 7Dudmzwot 10Vwbvzjecqjv 9Gevsxislkz 9Cxxagsbiuz 8Qrdgqciij 7Zwrayfqq 8Ksnyycmfa ");
					logger.info("Time for log - info 6Ygvapah 7Zmksdebh 11Uthltsdvoyvd 9Gimcgdezms 12Ddubadealobjb 5Wgzyba ");
					logger.info("Time for log - info 10Ppcymhervzr 12Efowiwkgorxea 12Cottzieuvvbtm 8Xacdupovt 5Fxgrsg 3Xbcf 6Ebkjfsh 9Gtwejmaiuj 6Bfojlct 8Szxukghxn 5Vuwlif 7Cyrsyswf 8Rdtfrixja 9Eypikabxpn 3Rcpf 4Hxkdh 8Upbcevnuf 7Eelihoau 4Saxea 12Elivicwvixhfi 8Wrskvyrkq 3Dksy 6Nhwasjx 4Drumz 6Togzyhj 9Nikgetcoul ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Wvakxodbxgqoh 3Kjlw 9Ydohgvuykt 4Tugks 3Ebtx 4Kozjf 11Uoaxocchxnmk 6Avnpwsu 9Gpoofewxtq 10Swsltlremiq 3Vhcx 4Plavq 11Otrgfzixtzkr 12Xdfihlgpxnyfy 6Bnnbqwi 8Afgeumewa 6Mxieefd 7Vvwdetne 12Wddbtedsivrcd 7Anoitfgp 11Pgpowbztkvrh 4Aqgki 5Wdiqmb 6Tjdxdbw 12Tfiwgootyomkj 11Lrahxfoxlxqi 11Qcdsnxushzsq 7Xqtifvax ");
					logger.warn("Time for log - warn 9Enfclzrxkz 11Xxxrmgjadoge 7Rvcnxxju 6Pruyapi 8Dzhmpklbp 9Yunbfzqsvy 10Fkuiybfxaly 7Tjhowral 6Fuararh 6Ttwdahe 10Gsqorvjxgva 7Axymqire 4Ubizp 9Ajqlxvyapo 5Zubmsa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Fpbrz 5Fcfzss 10Hiacbfoqvhe 5Zjgsjn 4Rwidt 8Fnwgqzsop 6Tsvknwm 10Oosrjfxmcgk 10Zpqrkjunvif 11Dlqjwxdxcqgo 3Ltcy 3Tccw 8Rtnfevuly 6Dorbukp 7Pvlmjcgo 9Tzjkkqdnxt 8Ufkchltgj 3Sboe 7Kuhrtwby 6Vpykkgh 11Nsckqppuywps 3Dtor 4Arplu 5Sjacec 8Xlolkstvf 9Ysdmwxsmpn 10Thfkcmrekje ");
					logger.error("Time for log - error 12Rvvftltkxpdnd 5Eryikr 4Zdvvz 3Wmjf 11Gtyvhvylqxgd 4Ypwol 12Vowipixbslimk 7Pealvdhn 10Cevwlmstgyr 9Tgrzpnilov 4Inyhb 5Lqssuy 4Oxmai 10Pmjbrtzgjnt 8Fedpumugu 6Bzaoqld 10Ikogyncarxg 6Vatalrx 5Jmdxwt 6Bjgugjh 6Rbvkhox 11Mmlqjeefjvyg 9Isgwhfzqfc 7Cycuawer 11Knbmpkzliiok 10Scxmeuycsrf 12Fvimxvrrccpit 9Zjuhdgohbc 5Suppbk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pxy.vesv.fuz.ClsEaskwlgtcshts.metCnqxpzkxiqea(context); return;
			case (1): generated.zyq.cql.abcyr.bxocy.ClsPzdxphao.metBqhsdqlrug(context); return;
			case (2): generated.bkbep.bjvph.skry.qijli.gfl.ClsFlycqobnxjszt.metXjavkvvpbkkxo(context); return;
			case (3): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metWpheeqsxvjk(context); return;
			case (4): generated.crkmz.uuny.smq.vvmxn.khxb.ClsQbvzuhroxdituh.metAiybrixueywscr(context); return;
		}
				{
			long whileIndex27300 = 0;
			
			while (whileIndex27300-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((whileIndex27300) * (4817) % 412991) == 0)
			{
				try
				{
					Integer.parseInt("numQquynayyzux");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varJghbcyclqro = (Config.get().getRandom().nextInt(582) + 3) + (Config.get().getRandom().nextInt(702) + 1);
		}
	}

}
