package generated.siinn.hrk.mef;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDcfbqxc
{
	 public static final int classId = 463;
	 static final Logger logger = LoggerFactory.getLogger(ClsDcfbqxc.class);

	public static void metPlpmmksy(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valUvirklhupkd = new HashSet<Object>();
		List<Object> valOwdgzeufujh = new LinkedList<Object>();
		String valKpnzexvqjhl = "StrDnyxymdgqvo";
		
		valOwdgzeufujh.add(valKpnzexvqjhl);
		String valRvbhvbrzfia = "StrGtxqyjteldn";
		
		valOwdgzeufujh.add(valRvbhvbrzfia);
		
		valUvirklhupkd.add(valOwdgzeufujh);
		
		root.add(valUvirklhupkd);
		Set<Object> valWjnwfircfpv = new HashSet<Object>();
		List<Object> valDdcxcgmxtop = new LinkedList<Object>();
		int valNgsptnokwdj = 615;
		
		valDdcxcgmxtop.add(valNgsptnokwdj);
		boolean valMfqvwsahssx = false;
		
		valDdcxcgmxtop.add(valMfqvwsahssx);
		
		valWjnwfircfpv.add(valDdcxcgmxtop);
		Set<Object> valPnsckogfngy = new HashSet<Object>();
		long valPrgdortkwvg = -6513012154370179787L;
		
		valPnsckogfngy.add(valPrgdortkwvg);
		String valWfnzebuzrmv = "StrKvwopynslqy";
		
		valPnsckogfngy.add(valWfnzebuzrmv);
		
		valWjnwfircfpv.add(valPnsckogfngy);
		
		root.add(valWjnwfircfpv);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Dvihvjo 4Ubisa 6Pldxpqq 4Dpele 8Bpztskbwo 3Xzub 8Yfchcsswt 5Lnmwix 4Xvddh 9Axswnmtnoi 3Tyse 7Lzkvefoa 6Pvziice 12Ajekfhqhzkobj 7Qkqcjvle 5Qpqvlp 4Ympmx 12Jkuoliooviybe 8Yjqsiaqpj 6Huieyqf 5Rafoib 3Dpce 9Ghyklofwsq 3Izpd 7Dzgfgckt 7Kxwxjxlh 10Ovepgydsprw 7Rkqirtyu ");
					logger.info("Time for log - info 3Fgaz 12Xphefztpwroue 6Xoehnrn 12Wcrxczjpkaxha 8Dozuonfqc 3Mvxe 4Zmgak 12Xbbyfxypuqtcb 11Bbkxlitizeyy ");
					logger.info("Time for log - info 12Xkvxnqbnpfhhe 11Rzovpxvzmzva 12Dnetqfjrirxlm ");
					logger.info("Time for log - info 9Reddlnuwgj 10Ziytyfmeggj 12Yyfsptkibtnly 8Pfmjcrbrt 7Loeyyanw 5Dbsetx 6Konhdrz 11Bshpwnfcezpo 7Acktwvds 9Pefhxcfezr 8Eqywebsmi 7Jtquzmzr 8Xbrzxchmq 5Zxmjby 6Zcvlzkq 4Heebq 8Uwcvtmrhg 11Nwaxrotprtat 4Rljbd 6Ttfygow 10Dbljstxdybt 3Byph 10Mhocycsdbhe 5Qqruir 3Vwdx 8Zjigffnlo 7Okekxget 7Iioqrzda 10Uanthvtcvya ");
					logger.info("Time for log - info 11Prrqgrkidkey 3Beht 12Jxeaizfjnxuja 12Cwvxzpitgrwfy 6Zdwuozo 11Smfbfpafgvoo 7Qbiasrmw 7Gxohkuqr 11Gxpbislgxxmd 6Coosuqz 8Dsddjpszy 10Wvyirqnkzjd 9Qgvnajlnum 7Rkcznjsf 6Omhumeu 4Cusoi 5Xcrfts 3Qsfz 11Xakuvagocrqt 7Kbtmpkto 6Tuudmun 4Cpfkz 6Erdnrhe 8Ksufubzzi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Vpigwkjcfsejf 10Hvycmrsbglz 4Ikxuk 3Bpqf 9Erentvpnwm 6Dsjcxik 8Rwbnzyxeh 5Pjqltn 9Cwbgwaqodc 4Tkhxr 7Bljqpbqb 3Uhve 4Rpczn 11Icnbrhajtsnr 8Lrhaxzbwq 10Xsdmaxkbwwb 8Rnxcqsote 12Fpaqcbmwafhoo 9Zynytcbizn ");
					logger.error("Time for log - error 7Ncnomjuh 5Ylesrt 12Oocutfjvdoimw 6Rbiaisn 11Yqgftzfoqyyl 4Znymi 10Xndyvljnscg 12Pdxczedadlnln 7Itbpnuip 9Mdzfrcwycp 4Tecmg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qwlax.zei.ClsAdxloruwrrth.metHsjxayjzgkwe(context); return;
			case (1): generated.fzrxl.bpx.ClsFendqr.metYsszpgrbh(context); return;
			case (2): generated.krka.pbdp.kxfhk.gqt.tfv.ClsAdvwmtrn.metGbpohttt(context); return;
			case (3): generated.inao.viw.ClsZkxazvlqxnvyzx.metDbsezno(context); return;
			case (4): generated.tjsh.wlc.kyb.psqfd.qzhn.ClsOhdwrykfu.metDqdnyemypbugl(context); return;
		}
				{
			int loopIndex27790 = 0;
			for (loopIndex27790 = 0; loopIndex27790 < 8704; loopIndex27790++)
			{
				try
				{
					Integer.parseInt("numQknmfopedaj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varMlbldgfmpzz = (Config.get().getRandom().nextInt(934) + 9) * (Config.get().getRandom().nextInt(549) + 8);
			try
			{
				try
				{
					Integer.parseInt("numWesnhndvaxm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex27795)
			{
			}
			
		}
	}


	public static void metIvygazu(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[7];
		Object[] valVfhvqfviepv = new Object[9];
		Object[] valGgkfnfrfadp = new Object[4];
		long valQwwcqkzqxsa = 3214068228350084725L;
		
		    valGgkfnfrfadp[0] = valQwwcqkzqxsa;
		for (int i = 1; i < 4; i++)
		{
		    valGgkfnfrfadp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valVfhvqfviepv[0] = valGgkfnfrfadp;
		for (int i = 1; i < 9; i++)
		{
		    valVfhvqfviepv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valVfhvqfviepv;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Lxgxmbyokxgbl 7Cmczpzej 3Oant 9Onmynjmqrp 10Deijryprfoi ");
					logger.info("Time for log - info 11Fipmkzhrawpg 5Rqvdoy 11Aumfwztrjxeg 5Sxvlvb 10Mgnhddukqxp 12Abrzplgplsagj 11Bzcivsuedeac 9Nljfkacnoa 8Jamidvjyh 4Mkorn 7Qezrgqeb ");
					logger.info("Time for log - info 4Kxzjv 9Wuhrvdertf 12Egxzwvajhgkxj 3Dvhr 7Zjkjaigx 12Hkvnbbzyhspsn 6Qjuyiwv 7Axzoprvk 9Gkvsthvawn 11Ciwvfegjixtf 10Nxmtcvtqmvj 7Gbewdhka 11Bastcrkwctgj 4Nrisf 4Nxjao 6Bqrddna 9Rhaldubxyc 4Opteo 5Xfgaiv 4Kynlq 10Dbkzorzwcdg 12Zvjfqdjsfnhip 3Rgai 9Hjqghyjqis 9Hqwnhvqbst 7Pjyjeaqg ");
					logger.info("Time for log - info 7Mzveygyo 5Orjetq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Cvux 7Unoerbpi 4Phhet 5Dbplxg 12Wernbooytdcjh 12Glmwqxyurjeas 11Cwfxccgqhuvu 6Dbdovkx 3Uyrj 3Aabp 8Rsgjcpbfm 8Zzwagyyjj 6Pbcubye 8Qabacusch 7Wdlpcjqs 7Yjoomwud 9Nutnkmnkmv 9Ddsokyghls 8Dzgplkhff 5Xqsttg 6Bxvwzfc 8Mxjrhgkxn 5Rxxzjj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Xotqj 12Hnixzmscuzykj 4Symwz 10Eqzlyxtwifj 10Xyfqulkzflh 8Bvbopzzjn 5Cmygep 10Ejrmrldqvjb 7Oiedndqx 4Cijtf 8Aqhbejflu 9Ayhenejyuj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metEvvtbxshkftg(context); return;
			case (1): generated.meo.tvmj.xqqix.qdpb.crypd.ClsCqiefbhpitkzjs.metRkiiokfveuzir(context); return;
			case (2): generated.mvh.wsi.ClsXxvtrnameonpg.metGcmnvyet(context); return;
			case (3): generated.yaahc.bwx.upsjn.ClsIxadk.metPvfldng(context); return;
			case (4): generated.gjcdq.ygxj.ClsOmksrfdawprnyq.metSuflbdydm(context); return;
		}
				{
			int loopIndex27798 = 0;
			for (loopIndex27798 = 0; loopIndex27798 < 3022; loopIndex27798++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((7063) - (loopIndex27798) % 356093) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(89) + 9) - (Config.get().getRandom().nextInt(741) + 4) % 209326) == 0)
			{
				try
				{
					Integer.parseInt("numWimimbfvyqw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metVimubl(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valTakvmwhjhyz = new HashMap();
		Map<Object, Object> mapValCticojmfcts = new HashMap();
		String mapValGdwpwceknno = "StrDtwxdqnjcka";
		
		long mapKeyRqgclaxnbqi = 6605599188180018883L;
		
		mapValCticojmfcts.put("mapValGdwpwceknno","mapKeyRqgclaxnbqi" );
		String mapValTnyrbjghiuz = "StrJhtfgyhnegn";
		
		long mapKeyCjexumatiyj = -3422503704336064928L;
		
		mapValCticojmfcts.put("mapValTnyrbjghiuz","mapKeyCjexumatiyj" );
		
		Set<Object> mapKeyDrwhtxzxxby = new HashSet<Object>();
		boolean valFqresyjqzat = false;
		
		mapKeyDrwhtxzxxby.add(valFqresyjqzat);
		
		valTakvmwhjhyz.put("mapValCticojmfcts","mapKeyDrwhtxzxxby" );
		Set<Object> mapValKufmhwrrtzr = new HashSet<Object>();
		String valSbdddttyisc = "StrSyblpzdjiqj";
		
		mapValKufmhwrrtzr.add(valSbdddttyisc);
		
		Map<Object, Object> mapKeyDuqdpqngnnu = new HashMap();
		long mapValDdctcfmompt = -4945618235878112991L;
		
		long mapKeyDmvunytzdra = -6507812337754918191L;
		
		mapKeyDuqdpqngnnu.put("mapValDdctcfmompt","mapKeyDmvunytzdra" );
		boolean mapValAnjpcwxppoj = false;
		
		int mapKeyLpuyhxwbort = 697;
		
		mapKeyDuqdpqngnnu.put("mapValAnjpcwxppoj","mapKeyLpuyhxwbort" );
		
		valTakvmwhjhyz.put("mapValKufmhwrrtzr","mapKeyDuqdpqngnnu" );
		
		root.add(valTakvmwhjhyz);
		List<Object> valKfvinljurpr = new LinkedList<Object>();
		Map<Object, Object> valClozalpncuy = new HashMap();
		boolean mapValFvwhcyuqeqe = false;
		
		int mapKeyCrkznekroou = 345;
		
		valClozalpncuy.put("mapValFvwhcyuqeqe","mapKeyCrkznekroou" );
		int mapValViadcieuhgx = 409;
		
		boolean mapKeyJbayegurnbw = true;
		
		valClozalpncuy.put("mapValViadcieuhgx","mapKeyJbayegurnbw" );
		
		valKfvinljurpr.add(valClozalpncuy);
		
		root.add(valKfvinljurpr);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Cgdhtibx 10Tprmakivunh 7Tmoqdszt 12Jcqwgwcrkdllu 5Jwoadi 8Urwjfvbme 12Eoevdsucrzvbi ");
					logger.error("Time for log - error 10Igorsqyujra 11Stumuimgenom 7Wifbtvlr 3Ydue 3Kyuj 12Felcynmflfrms 9Arwzxbkvww 4Mappa 3Utzw 10Jeigntonwbn 6Awaxlps 7Kypxpjpv 5Djlxwu 9Eowjxoxogq 12Nwkavdfuqosyo ");
					logger.error("Time for log - error 9Uqfbtksqmn 12Odmzrvnzjjbuc 7Kzrhvlsz 12Guefovblcqsnb 12Wlcqqddzllquz 5Wrgowf 12Lvkunkpjnsiwf 4Rljmw 5Oofbsv 8Zpmjvamde 8Vyzogubbb 4Ycxnb 7Hsbqmxeh 9Mrbgwekzyw 6Fqxhiia 11Avujvkpjeqrr 5Zlmpya 12Cpjvhaybukcjp 12Fstdmvinydkso 9Jryklepnal 4Goinl 5Mclbyg 8Oxydtanqh 7Pzpoybqd 11Xuwmifnsqtra 12Nfbiclfkwuhrh 10Zfbjdmcvzec 4Rwwdf 6Savdkzt 12Nxyatcymmfqjj 6Xmbzdwa ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qny.ksq.ClsEbyoh.metGwxnyvgevqb(context); return;
			case (1): generated.xluq.wys.lexvj.ClsEsonclfnnvbg.metKsdklzxlnfg(context); return;
			case (2): generated.wwbmr.iqko.nht.ClsCnzakidxmh.metYvzavpzpnbo(context); return;
			case (3): generated.naf.suq.ClsSzodbxxywsfz.metKihakbig(context); return;
			case (4): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metUsjlmntvgpvw(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(853) + 7) % 300414) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(104) + 1) % 269578) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metTnfgkqflqf(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[11];
		Map<Object, Object> valDybvcpmwtrp = new HashMap();
		Object[] mapValZengqetczha = new Object[5];
		String valIyqjpflnsck = "StrAkzljfmdrge";
		
		    mapValZengqetczha[0] = valIyqjpflnsck;
		for (int i = 1; i < 5; i++)
		{
		    mapValZengqetczha[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyBesfcgllmuq = new HashMap();
		long mapValPndpdrcjflg = -7150271318766687126L;
		
		boolean mapKeyXhobwenbpcs = false;
		
		mapKeyBesfcgllmuq.put("mapValPndpdrcjflg","mapKeyXhobwenbpcs" );
		
		valDybvcpmwtrp.put("mapValZengqetczha","mapKeyBesfcgllmuq" );
		
		    root[0] = valDybvcpmwtrp;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Worqrsllguqm 12Xkppuncoargcp 9Yxfmvbekzm 10Tqxrruttvoi 7Nszixaam 7Sbalmcxa 8Bbqggqhjf 6Rizsgdk 7Chnzvfou 6Smofboo 8Zdikrlbmf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Bpbrvdlbz 10Rnsrjfefbvl 6Gtlwhlf 6Zciduky 6Yrjachw 3Avlm 10Yhuxsaeprzd 11Lxdeijqccmmq 10Mciotcljwnj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Dttzm 9Fgdfzryary 9Vmozzegjgn 7Zbmweccl ");
					logger.error("Time for log - error 5Sezxwz 4Cdejx 3Irqr 4Ukpnx 12Ibfgahehhzubf 5Lrsage 11Nuolxtngtmti 7Ekyniayd 11Siebqglylukm 11Cveszijhbuel ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gpnn.qul.pdexl.hxjph.zmndq.ClsIcvyndtrplxfkf.metWyrdoedscqrw(context); return;
			case (1): generated.hbd.gdsbg.cmv.qvo.ClsZtgxvnjsll.metSlkmbtyg(context); return;
			case (2): generated.uffsk.vmiw.dvm.uejb.ClsHwejuhoirpcucb.metTioel(context); return;
			case (3): generated.ncau.ibhi.ttuvu.ClsHlbobsu.metTahxaryiutr(context); return;
			case (4): generated.tei.zyt.ClsLkzwcb.metYgqywxliqwprfr(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(710) + 5) % 898740) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(1000) + 2) % 399768) == 0)
			{
				java.io.File file = new java.io.File("/dirTiyvtsgwfaw/dirYrtxuuzenyx/dirMmyiylbikig/dirWkpmyjgiris");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numAcvglgbkrso");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
