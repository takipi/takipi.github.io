package generated.pfjp.usowt;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsIsioyesmm
{
	 public static final int classId = 310;
	 static final Logger logger = LoggerFactory.getLogger(ClsIsioyesmm.class);

	public static void metEsxosbsfuwm(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[4];
		Object[] valWpdezktxtik = new Object[11];
		List<Object> valFvufxbmywdg = new LinkedList<Object>();
		long valKoviczgrrog = 5771311727827368474L;
		
		valFvufxbmywdg.add(valKoviczgrrog);
		
		    valWpdezktxtik[0] = valFvufxbmywdg;
		for (int i = 1; i < 11; i++)
		{
		    valWpdezktxtik[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valWpdezktxtik;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Mfpcetjylt 4Slrox 8Fdxjpdlpj 3Nmja 11Hjcjujkmocjv 4Edxhe 10Bhdeuyoeaqb 5Oxcqzm 5Iavvha 5Kqbhaf 10Ghuglbdpuxy 11Acqzfhydqdde 3Iitb 3Mavk 7Cletmitr 7Rqgxoudp 4Eamfz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Qysbk 7Vjuwnldz 10Tjhmoslbkwd 11Jsoesgutljej 5Clqtgv 5Mjvlii 5Mqtqau 6Syvkrfo 12Kfbfozvfiqzld 4Trzqt 10Ymftdbzeebu 8Oodhvjbnm 4Geklj 9Lgmsjalndu 4Eiwhu 11Zgsacvfrqzmq 3Qhcd 9Sqyrsfklyq 3Ohrm 3Ysmm 12Psvvysolndaxo 8Qblxvdldf 12Xzwjjhugbpnpn 10Arqitnowkfw 8Jpryqjuee 6Ynjglce 6Vmiohlw 5Rrgbro 12Ubyowogfyzyyc 4Fksjw 5Irryhn ");
					logger.warn("Time for log - warn 5Utsccp 9Jdqvualcsl 11Ddtidiyetcnw 10Vplagejrbew 7Iwtltvab 4Iwgjh 5Vsqkrw 12Guuujogvslchw 11Yavdoiqamjyq 12Dfwvaviukqtrq 12Hzuwiieulspne 7Cmvgxhkd 3Gccn 3Owtm 10Bjqwfxvzfku 11Mcazpjacuhhv 3Zkco 7Tihrnvrz 7Aszredej 12Vpfhcthtlcfcq 3Yxvx 11Jtwailczrwov 12Fonbgmmkphrxg 6Pfzxzio 6Odhuphe 7Ehnhdpwh 8Uxsiwnzte 4Iqbay 11Zeeoiogoxbvr ");
					logger.warn("Time for log - warn 7Gulcdnls 6Scximfl 5Bnufit ");
					logger.warn("Time for log - warn 5Bdzcmz 6Qgzrnmu 8Shhqrowxq 5Wxacsh 7Htysests 3Lmpz 11Bkitaiezpyjw 12Rqhhnzsgpeffj 6Ztvlkqz 8Almofnfwv 5Erlzob 12Ypzrpdpxbwzwg 6Djfqmuz 12Fahdgqtrnhfjq 11Zqwqyzmwzodo 12Dvuvkcbvvzquk 6Dheeaat 7Euobcodd 5Ydpnku ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Ttwcoblnq 12Aghuwwlismmqq 4Iddaw 5Bzuift 4Shitb 10Jznhytfbfrm 8Ytqozjjkq 10Bpxobteyjur 9Xbsqjvsurg 11Sklvgcnjtukn 7Pyagresf 12Ljyyjpkascrop 5Pykuln ");
					logger.error("Time for log - error 12Nlmofvabiegkm 8Pdmrllkog 6Rjykwsf 7Vzjmbfji 10Urizojscwrz 9Gjksnylbkb 6Inaxzfk 10Vjtzasflrzf 3Vqin 3Rgvh 11Mtbwjdernbku 6Rntnnif 11Dbrwkumlbysq 3Lhro 8Tewpmnleb 8Epxexczfi 10Kwuijtwnbjr 3Vwrq 4Ulvap ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ebdo.cied.ClsIqlmeepdcmuqo.metKtzhn(context); return;
			case (1): generated.duzy.rxrsw.ClsQbnde.metFgxdseboz(context); return;
			case (2): generated.xbfov.nkh.ClsAkppmbind.metHtbkmz(context); return;
			case (3): generated.zkx.deuj.ClsQemyphqswqdyqm.metCqxdmugdembti(context); return;
			case (4): generated.xnl.gdx.dmkh.hpyan.ClsNxgzyqd.metRbhfzkkxtnc(context); return;
		}
				{
			long whileIndex25259 = 0;
			
			while (whileIndex25259-- > 0)
			{
				try
				{
					Integer.parseInt("numGbpmlszreul");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metWvpjrpagibthng(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valUdpondjlcxw = new Object[9];
		Object[] valLzhvbouwgjb = new Object[9];
		long valJhxhojsxvpl = 3424670879337401386L;
		
		    valLzhvbouwgjb[0] = valJhxhojsxvpl;
		for (int i = 1; i < 9; i++)
		{
		    valLzhvbouwgjb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valUdpondjlcxw[0] = valLzhvbouwgjb;
		for (int i = 1; i < 9; i++)
		{
		    valUdpondjlcxw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valUdpondjlcxw);
		List<Object> valXwbkcjujsos = new LinkedList<Object>();
		Object[] valGatbciennvw = new Object[7];
		long valQduyqrvjstv = -3632660368528167922L;
		
		    valGatbciennvw[0] = valQduyqrvjstv;
		for (int i = 1; i < 7; i++)
		{
		    valGatbciennvw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valXwbkcjujsos.add(valGatbciennvw);
		
		root.add(valXwbkcjujsos);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Mdpccw 9Rmswhjqjaj 3Zqfe 10Hyiygfdhkmc 10Xmjykikwrim 4Czdbm ");
					logger.info("Time for log - info 7Rocmmgox 5Varcyi 8Ufebndgvx 10Nwxmsrnjiwm 10Occfhzhguye 5Llbagp 9Bspdtgwyip 7Zeuijoxc 12Lailnnglbsaap 3Sxmu 11Gdiibhfvmgaj 5Kcdsua 10Pldtcqvuhgb 10Qganfqmxyom 3Ytcc 7Irieaodh 5Xpguoc 11Yyktzxsjgqdh 6Jayqppo 8Qqkfivgnh 12Bjfcqzuomkkyl 3Pztq 9Fsvveeredt 9Xezjznkkyi 3Sqbi 10Bksxecvafrm 7Kkzmsnfc 6Lixesag ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Ikmq 11Rpvgtbitaskb 10Ctwopnktygw 12Huamjintkslzz 6Haevrab 12Agulxoprgtxqk ");
					logger.error("Time for log - error 7Eodwcran 4Dvzwd 5Qswliy 5Buqkeo 11Hkvaepmslhea 10Ouevjajqazy 9Wnwatrcxlq 9Bxiuqrteyn 7Aniwhqbn 8Rnlltsqtf 11Fortkrksybbz 10Nojmygsiiwv 8Jnbffhlel 9Mmtsjcowrb 8Nmuciluys 5Bscsqe 11Psazhwxgezmc 9Vwkyvhsbsh 9Lhefyuvlkj 12Ffeeqivvlrvfk 12Yqqobmpywfoxu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qikh.hgtag.amhgk.ClsEpqxnohalceif.metUhwjekipowr(context); return;
			case (1): generated.olnh.vng.ClsLcraqevyogmja.metHhcagl(context); return;
			case (2): generated.decno.psqz.bhc.ykgc.ClsIhnrz.metWxnztwbdh(context); return;
			case (3): generated.jlzkx.vlyxg.uui.ClsYmzeuds.metMjkebsmedso(context); return;
			case (4): generated.tcpo.xhov.ClsRfokukcdi.metFrfxj(context); return;
		}
				{
			long whileIndex25262 = 0;
			
			while (whileIndex25262-- > 0)
			{
				try
				{
					Integer.parseInt("numNtchgfgkrsg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metZipgjwya(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[5];
		Object[] valCvpajtcymym = new Object[5];
		Set<Object> valFezbmsamvsg = new HashSet<Object>();
		boolean valNncuyovltft = true;
		
		valFezbmsamvsg.add(valNncuyovltft);
		String valWutusfwenec = "StrLyklzmyzwus";
		
		valFezbmsamvsg.add(valWutusfwenec);
		
		    valCvpajtcymym[0] = valFezbmsamvsg;
		for (int i = 1; i < 5; i++)
		{
		    valCvpajtcymym[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valCvpajtcymym;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Rqvvahomvbkz 12Pnbapdpfxcakq ");
					logger.info("Time for log - info 9Rxwhakpueq 10Yoqhgjgzdnk 10Tqdxvpxlpsb 3Qyjk 8Iblmnryrf 5Glggdy 3Uprn 6Htkcups 6Qpzbupg 9Mtopkxghbx 5Rnvvyj 9Fapquoxgwz 9Ffvfgffvbz 10Sthbetfnaly 12Ydytagaqykgld 4Fwtrr 12Aswkavuxtdpmq 11Yrmzmukkcfyn 8Dpwunhiml 8Fjvgyvnct 11Jkrgmblrgkjv 3Imyk 8Ynpwpgbfl 8Xriyscqiy 12Akbccufazowre ");
					logger.info("Time for log - info 12Osgfdsrnlddgy 8Jcldcjequ 10Lryygfcrvrt 4Alavp 12Amsyffhzanjub 3Nfdt 10Tatynxgftpx 10Twwxantsmrs 5Sdxnpt ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Hvux 9Lpqbjtqihm 7Oaijsqhz 7Httbrpgr 5Mhnaos 5Bueblp ");
					logger.warn("Time for log - warn 8Zutudtskn 6Xluihlk 5Mdddyi 7Unrgzurv ");
					logger.warn("Time for log - warn 10Kviimtnzjys 6Mzyftdy 5Cvdobm 11Lkmdbrbwcmva 12Jhycwkfyzkxkp 4Mbalw 3Ckbj 3Imsu 12Qggprkegpnhzz 3Hxqu 11Sfkzdcqhwxhg 7Trcavwzp 3Tgca 9Wukgzhsfvo 10Abonauskpey 11Kdmgfmjolgbg 9Qsfnqdejlu 4Eigqz 4Xinwz 12Xgaonvpyhjniq 11Pyczoipohjpn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Pyqiloufso 7Nyjfsetj 10Tspwqzlmocs 4Nklnx 5Aonovi 3Lbig 8Musjbjozs 4Dqggn 8Impuyvzia 12Xvcnhibglhzzv 5Lssuvv 11Zmkjkcjyjgpl 4Xtjck 12Fdljkullyluxp 7Hwewsiti 8Fsqjvljle 7Jqdcsxtl 3Utla 5Bvxpno 3Jwoo 8Zxietdxml ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fzrxl.bpx.ClsFendqr.metYsszpgrbh(context); return;
			case (1): generated.gyic.epw.ClsQxhbkrqjzoqujk.metLlbnuvvzsghg(context); return;
			case (2): generated.opb.bkhm.vos.ClsExbhmceyku.metSsatibnunaru(context); return;
			case (3): generated.rnv.dtvl.uhnk.ClsTzqkdsb.metKrrjeushc(context); return;
			case (4): generated.jyd.enpnr.ClsZxueqcgpd.metEwimth(context); return;
		}
				{
			int loopIndex25265 = 0;
			for (loopIndex25265 = 0; loopIndex25265 < 5762; loopIndex25265++)
			{
				try
				{
					Integer.parseInt("numPxfnigedhpm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
