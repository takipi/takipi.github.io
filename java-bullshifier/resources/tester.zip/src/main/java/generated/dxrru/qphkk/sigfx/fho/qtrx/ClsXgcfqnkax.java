package generated.dxrru.qphkk.sigfx.fho.qtrx;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsXgcfqnkax
{
	 public static final int classId = 201;
	 static final Logger logger = LoggerFactory.getLogger(ClsXgcfqnkax.class);

	public static void metBpzoot(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValMiktgudllzv = new HashMap();
		Set<Object> mapValPlcahzhlydw = new HashSet<Object>();
		int valZkvqfwtpoum = 77;
		
		mapValPlcahzhlydw.add(valZkvqfwtpoum);
		
		Map<Object, Object> mapKeyFhlswbztzbj = new HashMap();
		long mapValWqqnrvkubxe = 594165590863712412L;
		
		long mapKeyVffgipaetjq = -5426009284534534342L;
		
		mapKeyFhlswbztzbj.put("mapValWqqnrvkubxe","mapKeyVffgipaetjq" );
		
		mapValMiktgudllzv.put("mapValPlcahzhlydw","mapKeyFhlswbztzbj" );
		List<Object> mapValQobdnhxuadh = new LinkedList<Object>();
		long valKnnxrlzopjq = 8282459839045093524L;
		
		mapValQobdnhxuadh.add(valKnnxrlzopjq);
		
		Map<Object, Object> mapKeyAthwlnxgbwf = new HashMap();
		String mapValSpripxzqofd = "StrHtjvnqlnojp";
		
		String mapKeyXnmgiabpmfy = "StrMzivaopsuns";
		
		mapKeyAthwlnxgbwf.put("mapValSpripxzqofd","mapKeyXnmgiabpmfy" );
		
		mapValMiktgudllzv.put("mapValQobdnhxuadh","mapKeyAthwlnxgbwf" );
		
		Map<Object, Object> mapKeyCnuzalwpcpy = new HashMap();
		Set<Object> mapValAqkzocdmgdi = new HashSet<Object>();
		String valNlwrnbgaavn = "StrNwwrastjpze";
		
		mapValAqkzocdmgdi.add(valNlwrnbgaavn);
		
		Map<Object, Object> mapKeyWgwctccawms = new HashMap();
		boolean mapValBybgqbnvelz = false;
		
		long mapKeyMkgcqgmxlmi = 953741479662411733L;
		
		mapKeyWgwctccawms.put("mapValBybgqbnvelz","mapKeyMkgcqgmxlmi" );
		
		mapKeyCnuzalwpcpy.put("mapValAqkzocdmgdi","mapKeyWgwctccawms" );
		Map<Object, Object> mapValWtnptingwpj = new HashMap();
		int mapValYdpiquxixnv = 626;
		
		int mapKeyUeqsauaexuy = 971;
		
		mapValWtnptingwpj.put("mapValYdpiquxixnv","mapKeyUeqsauaexuy" );
		boolean mapValZddojcyhkkb = false;
		
		boolean mapKeyLzrvixazqzd = true;
		
		mapValWtnptingwpj.put("mapValZddojcyhkkb","mapKeyLzrvixazqzd" );
		
		Set<Object> mapKeyOtozsiksqdk = new HashSet<Object>();
		boolean valOvlabylnetn = true;
		
		mapKeyOtozsiksqdk.add(valOvlabylnetn);
		
		mapKeyCnuzalwpcpy.put("mapValWtnptingwpj","mapKeyOtozsiksqdk" );
		
		root.put("mapValMiktgudllzv","mapKeyCnuzalwpcpy" );
		List<Object> mapValIxllxqjspup = new LinkedList<Object>();
		List<Object> valPaucvfttlul = new LinkedList<Object>();
		String valEpvqnsnvfwb = "StrCqukfytokih";
		
		valPaucvfttlul.add(valEpvqnsnvfwb);
		
		mapValIxllxqjspup.add(valPaucvfttlul);
		Map<Object, Object> valZpzyogegzcg = new HashMap();
		int mapValNhaiapakgfp = 18;
		
		String mapKeyYxjubqxcilj = "StrCckazcrkstz";
		
		valZpzyogegzcg.put("mapValNhaiapakgfp","mapKeyYxjubqxcilj" );
		String mapValQnaertzzjnp = "StrMogdiyvyjvo";
		
		long mapKeyLwftjsaxdpp = 5375148975721073917L;
		
		valZpzyogegzcg.put("mapValQnaertzzjnp","mapKeyLwftjsaxdpp" );
		
		mapValIxllxqjspup.add(valZpzyogegzcg);
		
		Map<Object, Object> mapKeyNdismhmcqgk = new HashMap();
		Map<Object, Object> mapValDuashpixzqn = new HashMap();
		String mapValNjruvcplmmc = "StrTdzzwcdnzhu";
		
		boolean mapKeySgiwglvohol = false;
		
		mapValDuashpixzqn.put("mapValNjruvcplmmc","mapKeySgiwglvohol" );
		int mapValUbcchghdzsk = 40;
		
		long mapKeyGjckhfpeqbp = -2993241715985373091L;
		
		mapValDuashpixzqn.put("mapValUbcchghdzsk","mapKeyGjckhfpeqbp" );
		
		Set<Object> mapKeyDaxdutjfvql = new HashSet<Object>();
		int valQtyhthfrtiv = 198;
		
		mapKeyDaxdutjfvql.add(valQtyhthfrtiv);
		long valFodkbwxbrbc = 2152081294280726639L;
		
		mapKeyDaxdutjfvql.add(valFodkbwxbrbc);
		
		mapKeyNdismhmcqgk.put("mapValDuashpixzqn","mapKeyDaxdutjfvql" );
		Map<Object, Object> mapValQaaqlmtueaa = new HashMap();
		String mapValGzrdkgomkbo = "StrNbwlrfljuub";
		
		String mapKeySyfxmjdrban = "StrRbjbtxvileb";
		
		mapValQaaqlmtueaa.put("mapValGzrdkgomkbo","mapKeySyfxmjdrban" );
		
		List<Object> mapKeyTclkhyjtiaf = new LinkedList<Object>();
		String valCvpqzpithmt = "StrBglupfufher";
		
		mapKeyTclkhyjtiaf.add(valCvpqzpithmt);
		int valAxfwirmhzoy = 53;
		
		mapKeyTclkhyjtiaf.add(valAxfwirmhzoy);
		
		mapKeyNdismhmcqgk.put("mapValQaaqlmtueaa","mapKeyTclkhyjtiaf" );
		
		root.put("mapValIxllxqjspup","mapKeyNdismhmcqgk" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Brejw 4Jzlqa 7Nhdivylh 12Mnezhkhuviphw 3Bgrc 7Nmmnynch 10Eamvxicojbn 9Dcfqjdnzry 3Qsou 12Yadimzpakmzye 3Vjub ");
					logger.info("Time for log - info 8Eesmbbzsk 6Cuyvydn 7Fatssowd 7Ygkqhedq 8Kqtczlogs 4Jjred 3Wbvs 10Ptqkxdhqolz 4Yioaa 9Jqkuzgtdij 9Xzwfdgxoda 3Uulf 10Ghhxeaaqndl 8Cnrwyfgpp 8Rnoirbssj 10Vtitjaobsyu 5Anjodf 5Ofezte ");
					logger.info("Time for log - info 8Ntgcthews 9Wglwqphfiw 7Unywcjbp 7Zsqpdpfn 10Rfzhorjggiz 3Wdec 3Fzco 9Jbcqbczaic 10Bcvdonrdsck 12Auuzvyqvelstt 9Embwaszmcv 5Wiwygy 10Pgxjcofhbut 7Irtelozu 3Gqne 9Msbqlmpkcx 4Sjuaq 3Uofz 6Zhgcunv 4Mrbit ");
					logger.info("Time for log - info 10Pssbjxpgwjd 11Rzeyadzpmzkh 3Xkjt 12Prjbdgiqxnqbh 7Olzgrjwt 10Dvkjyaxgypo ");
					logger.info("Time for log - info 3Nney 11Okyoookrusvi 4Jwnpu 5Qksjkj 12Twwknaiurqyci 5Fsqnpk 8Mszlzvaxb 10Bufyzviceil 5Yahpds 8Pqwrnlrpo 6Tkkphnk 5Ynvsby 4Evgsi 12Uwoywwyrhpene 12Yuhvmjkzfrusv 5Eaugff 5Lwryah 5Rftwiq 10Gsyqsfuotsn 4Sdgtf 3Psfi 4Llpoa 9Urkrjbixdf 11Nqpikleqnbck 11Gxewcijiwcuw 8Spcdeunkc 4Qcljl 9Klqjvpnxhc 6Eiyorfk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Llku 12Fjmyyslcwjosq 10Qdiyzrpbflh 3Reeq 3Fkrj 12Gjcfhipjsxrgx 10Pjuuheoqefq 3Aoyi 5Ypxnyw 12Xclxekbpewcnc 5Ypeymb 11Dtxvrwqwuppf 10Snrctrpnezq 5Agvcda 7Yotuvvee 5Brvmvj 5Cwwrtb 6Qyomxys 9Trrauaagfz 12Xiabpsmgpelsz 5Iwodtr 3Nvcf 11Mgmbsmsnbnnr 10Pxbzpnjqcni 8Xcvijnopt 12Dphfgpmrgxhkf 7Ykkjodxm 11Zlymjqqatmyu 6Ttrakme 12Slojrtjtmrzhz ");
					logger.warn("Time for log - warn 5Qapwgv 10Tfwtcztcrcu 5Hauglf 5Uiyawi 5Exbncs 12Rgzzbuljcautp 8Zrrpacepp 11Gwkjusscxooi 7Llebawhb 3Pjde 12Rgkkfprlyfvsz 5Phjvxs 4Vcnsv 11Bojrgytsxoru 6Nlfepba 3Lzme 9Hjwglnvjng ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Suvlhkirt 8Gqafcwfen 9Kvjjanuxzm 5Rbuqbl 7Mfjlrbjf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.unn.flt.iyr.tjmvm.ClsFuxljnbiciwosz.metIhsje(context); return;
			case (1): generated.zuj.yzx.nga.pvup.ClsJyskqhfglgbk.metUwrvr(context); return;
			case (2): generated.cqy.ffep.ClsWvinhicphnl.metWwbnpyd(context); return;
			case (3): generated.cymhf.zmxu.aqlat.ClsTwlvztmhvdbz.metIzesypeo(context); return;
			case (4): generated.ecksk.wvb.ClsNtqfbmlui.metChuplbpiowm(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex23514)
			{
			}
			
		}
	}


	public static void metJqylvdbl(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valIddylzotbzg = new LinkedList<Object>();
		Set<Object> valFawuoffulwo = new HashSet<Object>();
		boolean valFpmnwqhqhlk = true;
		
		valFawuoffulwo.add(valFpmnwqhqhlk);
		int valMpiqpseuybv = 864;
		
		valFawuoffulwo.add(valMpiqpseuybv);
		
		valIddylzotbzg.add(valFawuoffulwo);
		Map<Object, Object> valUhpekbhwxsd = new HashMap();
		boolean mapValKroxhlulyto = true;
		
		long mapKeyVfzdfyhgski = -7730777162365339035L;
		
		valUhpekbhwxsd.put("mapValKroxhlulyto","mapKeyVfzdfyhgski" );
		long mapValYoubotfanaf = 8043611203682907795L;
		
		int mapKeyRerkwghelqf = 364;
		
		valUhpekbhwxsd.put("mapValYoubotfanaf","mapKeyRerkwghelqf" );
		
		valIddylzotbzg.add(valUhpekbhwxsd);
		
		root.add(valIddylzotbzg);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Zvdsxmpcm 12Rzjatwfzmvbjb 3Kxuq 4Lhlsg 7Eiafwwep 11Uzmzmakptdtd ");
					logger.info("Time for log - info 4Rhkuu 3Inwe 6Ifckdgg 5Azqtow 4Ffrdk 7Vtexmtnd 3Muan 12Jhphioeqsuyye 10Oyicjbtenkv 8Rcvvyktpq 12Komztishbelbx 11Pcwtvinztrpe 12Kcpyssotccxqw 10Ytstkngslqy 8Dwwvyvcgl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Zyaihy 10Wqedaysouie 12Trjogdkcxwobs 11Xvxfjnxnwzxi 11Bfzojcgrnutl 3Jwvr 9Gypegjmdxb 12Pxylddjtjrgqi 3Hixs 6Vjnnjoq 12Ptsodmggfgcax 11Oakjxpetdrmp 9Pdzdryxtex 8Fnvfgweta ");
					logger.warn("Time for log - warn 3Obad 3Dshp 11Zbeqaevwetgf 6Lruizna 10Fggbkeoukcz 8Hpsrbujqc 7Trssuteb 6Gnsshsb 5Jqcavw 12Liobkxqxojsec 9Snlsbfvgvl 3Cyuv 10Ewxxhhgjuxm 5Yrponn 11Uzdogqgeeisn 4Zwmkx 7Ykeqcsbs 3Pzrc 3Fezx 7Hiyhlses 5Mszxwq 9Prkvfaogqo 8Ovewlyehy 11Kctcbpxnzaxl 10Jcjtnmkmmtu 5Rnvynz 11Axjifosizacj 5Gvjscx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Lakbdc 8Ghrhwoejh 8Lwpnmzfct 4Zazxd 11Ovhsacuuxuez 4Ccdhe 7Qvzodfbu 12Wdzsmkzgydyee 4Excah 10Smizmqrwagq 3Smjg 8Qwfmoiphq 12Cipbmpdzuskxx 12Oswybuzfxjuqk 4Eyfjr 6Qrclvcj 8Zsjpletij ");
					logger.error("Time for log - error 3Toaa 4Bglow 9Cblrbamnok 12Nbbsfnvnbfkxq 4Bnwhz 12Ljxkmegyvybku 11Pfycxwokchkr 7Uoatwzhf 6Ehlbpte 12Lhnqehyiyulib 6Pggxqfw 6Pqghoyz 5Suulvz 12Phbanolodaxvg 3Tcpi 12Xzbebzufmjpqt 6Jblmtsp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fxa.nzjpw.lkh.sxue.ClsXtfkzq.metKgqnorcoyqk(context); return;
			case (1): generated.xpyaq.paxhs.ClsBkhbodffo.metDqshp(context); return;
			case (2): generated.mzwyl.mypv.ClsZjjiybxk.metVrycjw(context); return;
			case (3): generated.yvbmb.hnmr.uqxw.ClsYomdrwntzuxawb.metAeacazp(context); return;
			case (4): generated.ryyqn.hafq.oqfv.ClsRsktinox.metAtshswjvgunkn(context); return;
		}
				{
			long varHnbehbjtcwk = (2326);
		}
	}


	public static void metZnofaojibmjqy(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[8];
		List<Object> valRxdltoitslq = new LinkedList<Object>();
		Object[] valIwzpdythhpb = new Object[11];
		boolean valDgyqgknnuhh = false;
		
		    valIwzpdythhpb[0] = valDgyqgknnuhh;
		for (int i = 1; i < 11; i++)
		{
		    valIwzpdythhpb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valRxdltoitslq.add(valIwzpdythhpb);
		Set<Object> valVvipdbakpxc = new HashSet<Object>();
		int valFragbpvjoqm = 49;
		
		valVvipdbakpxc.add(valFragbpvjoqm);
		int valTqxyryvyrdq = 695;
		
		valVvipdbakpxc.add(valTqxyryvyrdq);
		
		valRxdltoitslq.add(valVvipdbakpxc);
		
		    root[0] = valRxdltoitslq;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Zywvbybyej 3Kdxx 10Fvflhlzcujn 12Zjprfjqkpcwjv 5Zbixyo 6Ichrorq 8Quedzxaet 12Xycupksgsuplb 12Cmjgfppslgmmn 4Nnvfe ");
					logger.info("Time for log - info 7Zopqmvjr 12Jigupmcnjlksb 5Bjoiff 3Gwte 3Xklf 8Nxvatlmlc 3Owzw 11Iyvtnxltrzil 6Wixepma 10Dagfskkjmls 12Edafexnjpkzup 4Sxawh 10Egkmpaabaxq 10Ttskdlhrnds 9Gheowkmhba 12Anggkqdfixtkm 10Coivuazfhvy 11Rngsjasefogq 5Goyvsy 3Yupw 8Obhlghymv 5Txqcjd 8Xfcncveam ");
					logger.info("Time for log - info 6Xocawah 3Yben 8Jafeqklsa ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Cwge 7Ppxzyird 4Lwsuj 12Hidldajnspaok 3Yhht 3Chgx 5Iyhbec 3Lnyd 12Qrbtkyumznith ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Tsktm 3Cadc ");
					logger.error("Time for log - error 6Pyoeotg 9Zxmrejndfz 10Phgtibyeflj 4Cwnuf 11Meqjpmjczlaw 11Zgripikpsxot 8Klbgkahsz 4Aabro 5Bqpehm 12Hhyzkdyvmfjao 3Gzvt 7Junbjqfm 7Nobmlomu 11Hlgfyfeishfo 10Nnkitrqduqm 4Yyfhh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wvctc.whp.ftjy.ClsPwdcftvpjt.metEsqbhpd(context); return;
			case (1): generated.tvv.ioy.ClsEqfmidfypp.metNnauzsiw(context); return;
			case (2): generated.wunj.xtrc.rfx.aikz.yopv.ClsTejixmzc.metAhxfdsezzruvtx(context); return;
			case (3): generated.mee.zfhy.ctgm.thcf.dyc.ClsWmiwkyi.metPalkfswklq(context); return;
			case (4): generated.afz.qen.lrlj.ClsTvxlbccvg.metWrkbglgpwrbj(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirWphsttwetuu/dirZxzbwrzhsyw/dirNwbvacejrve/dirBnzesqcgexm/dirUdwzkeuqkdf/dirEnurbnwwzag");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numQtmezkcidxw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex23519 = 0;
			
			while (whileIndex23519-- > 0)
			{
				try
				{
					Integer.parseInt("numOhbkgxjkssd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metKgwdczuyoh(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valWrfmdxssryw = new HashMap();
		Set<Object> mapValLjmmswssnrc = new HashSet<Object>();
		long valRsnrhnnpijw = -7518009276248019987L;
		
		mapValLjmmswssnrc.add(valRsnrhnnpijw);
		long valXihfsyjwqpw = 3108162990947425475L;
		
		mapValLjmmswssnrc.add(valXihfsyjwqpw);
		
		Map<Object, Object> mapKeyNzcukoqfcxx = new HashMap();
		String mapValVmpztocfpzq = "StrJxpcjmmizba";
		
		long mapKeyAcaeohuegng = 5331202169824758714L;
		
		mapKeyNzcukoqfcxx.put("mapValVmpztocfpzq","mapKeyAcaeohuegng" );
		String mapValMhdoesflszf = "StrLkpkqqjdojp";
		
		String mapKeyPluuakafhet = "StrIscmcgahluo";
		
		mapKeyNzcukoqfcxx.put("mapValMhdoesflszf","mapKeyPluuakafhet" );
		
		valWrfmdxssryw.put("mapValLjmmswssnrc","mapKeyNzcukoqfcxx" );
		Map<Object, Object> mapValRfwnqovgaxe = new HashMap();
		boolean mapValPxmgkylynwc = false;
		
		long mapKeyOjnrunvmfkl = -6945567339361703307L;
		
		mapValRfwnqovgaxe.put("mapValPxmgkylynwc","mapKeyOjnrunvmfkl" );
		
		Object[] mapKeyUdsawvizovg = new Object[11];
		long valQpcfpspfcle = 4750922832670911432L;
		
		    mapKeyUdsawvizovg[0] = valQpcfpspfcle;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyUdsawvizovg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valWrfmdxssryw.put("mapValRfwnqovgaxe","mapKeyUdsawvizovg" );
		
		root.add(valWrfmdxssryw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Ylnkllqdqzvfu 3Zluv 5Yvqnom 3Umsy 9Dyvhmnpvkj 10Xpthrljootz 4Bovnc 4Dqucl 7Fgbllcfy 9Cmuaolhdaf 4Jonlp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Rbsrkcxuciis 8Eporqwfpx 6Kmbekkb 10Mkwskgfdpwu 11Bjzrzlfjhlqf 7Sjtryyrs 8Xuykqlipl 11Irshdhpoujno 12Ifzpnrycfrtzm 12Adkknvrqpoavd 9Bcefmkdynl 9Mworkqnbhc 12Kpltgesezwkbw 8Rqbkbvbbw 3Zgyo 9Gugfhiizky 4Aohps 11Fjxkdvekqkpa 7Knjbzkyx 3Zkwn 8Oamclagdu 5Ysnfsn 6Gxbnnlb 10Zbusubvhngf 4Ljrfd 4Ciloa 4Fyvei 9Cgmkrqhymo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xpyaq.paxhs.ClsBkhbodffo.metDqshp(context); return;
			case (1): generated.rzy.sppai.eju.hupq.ClsPjendhgbojpy.metFwrqhbjeaj(context); return;
			case (2): generated.tei.zyt.ClsLkzwcb.metYgqywxliqwprfr(context); return;
			case (3): generated.gfiaw.wgvz.askqs.ClsGbqekumwdbwfn.metPzonhuiu(context); return;
			case (4): generated.ntoe.pshsx.ClsKjqouchrqothb.metClrqsbb(context); return;
		}
				{
			int loopIndex23525 = 0;
			for (loopIndex23525 = 0; loopIndex23525 < 9207; loopIndex23525++)
			{
				java.io.File file = new java.io.File("/dirGjtxsjqvscw/dirDfaniuiywii");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex23526 = 0;
			for (loopIndex23526 = 0; loopIndex23526 < 9700; loopIndex23526++)
			{
				try
				{
					Integer.parseInt("numQzqtxrqsiiu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metFkfxhq(Context context) throws Exception
	{
				int methodId = 4;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValYeriuyqifyl = new HashMap();
		Object[] mapValStogaadyogm = new Object[8];
		String valIrbrujjestn = "StrOnjfqcmcyaz";
		
		    mapValStogaadyogm[0] = valIrbrujjestn;
		for (int i = 1; i < 8; i++)
		{
		    mapValStogaadyogm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyFynfhygpina = new HashMap();
		long mapValCmignyydqkc = 931684617390754408L;
		
		long mapKeyYksqablowsk = 2117511576831457525L;
		
		mapKeyFynfhygpina.put("mapValCmignyydqkc","mapKeyYksqablowsk" );
		String mapValWuophelsjcr = "StrNhbuxybajhl";
		
		boolean mapKeySijpvugagai = true;
		
		mapKeyFynfhygpina.put("mapValWuophelsjcr","mapKeySijpvugagai" );
		
		mapValYeriuyqifyl.put("mapValStogaadyogm","mapKeyFynfhygpina" );
		List<Object> mapValEuwehxyifko = new LinkedList<Object>();
		long valJfhbarxblut = -7824836376961626015L;
		
		mapValEuwehxyifko.add(valJfhbarxblut);
		
		List<Object> mapKeyQbvsgrjpndo = new LinkedList<Object>();
		int valBuyimbbjsxo = 799;
		
		mapKeyQbvsgrjpndo.add(valBuyimbbjsxo);
		String valVoxsonwhywq = "StrSyhqhmsuupb";
		
		mapKeyQbvsgrjpndo.add(valVoxsonwhywq);
		
		mapValYeriuyqifyl.put("mapValEuwehxyifko","mapKeyQbvsgrjpndo" );
		
		List<Object> mapKeyPvfegohqalh = new LinkedList<Object>();
		Set<Object> valNtvxpwtdbrn = new HashSet<Object>();
		boolean valHwcqdxtszic = true;
		
		valNtvxpwtdbrn.add(valHwcqdxtszic);
		
		mapKeyPvfegohqalh.add(valNtvxpwtdbrn);
		
		root.put("mapValYeriuyqifyl","mapKeyPvfegohqalh" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Hztycduek 6Evvnbbf 5Buptrt 8Fsjhtdgsc 5Eaujfy 6Uhfgfnd 4Kaepn 4Dmqrs 3Hoyu ");
					logger.info("Time for log - info 8Jyvkrskud 5Tzmtjt 12Cjxaysfpccrun 12Jnppepdrlrbcj 8Bwkhwqaku 9Vqtcdvpudv 11Opiagcyupdpq ");
					logger.info("Time for log - info 10Bwqwxydhonn 10Sdfxrbtjbfo 5Wfmjmd 8Gemotwxvv 9Pejpsbumdp 9Wixelvbvat 9Yytkuqireh 5Tetlfn 3Umuc 8Xstdpeqbo 3Lsbv 4Krslf 5Ytaxaf 8Omeczzdec 8Pzfociebu 12Wytnpoenhqowg 3Doon 6Ksspiqk 12Sxvfengdidttr 12Gpjlrefkaoxpe 12Wwkzjbpnvooym 12Pzorbvgnurhtm 11Nhuxxrsozuki 9Everbxxgtt 9Tyegxcxdwm ");
					logger.info("Time for log - info 10Auljmpxddxd 10Rqeddmbbree ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Rdxwraa 7Epbzfafs 3Ytpr 6Xwbqaqc 11Ymqklqefryvw 4Udjcd 10Gsukooreaxe 7Rcywqriy 9Aazuiofkmw 9Zkzyhqxapl 7Oxreebqy 10Elsfjlbvxeg 9Ttqtjlcmol 9Gaiuikxdww 9Gmcddwssxk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qspb.cjle.nfu.jdnb.hwx.ClsNgqnidoia.metQznahmdoj(context); return;
			case (1): generated.xnl.gdx.dmkh.hpyan.ClsNxgzyqd.metRbhfzkkxtnc(context); return;
			case (2): generated.lvnhk.isns.uksl.tjjfx.ClsEfuazouhb.metWdieisfxwfvz(context); return;
			case (3): generated.ndkx.exo.qju.brvd.ClsMxlcse.metQwwqeaq(context); return;
			case (4): generated.jyd.enpnr.ClsZxueqcgpd.metEwimth(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex23532)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numYauldzspyzg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
