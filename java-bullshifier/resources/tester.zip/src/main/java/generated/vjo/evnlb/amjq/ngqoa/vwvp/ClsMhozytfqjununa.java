package generated.vjo.evnlb.amjq.ngqoa.vwvp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsMhozytfqjununa
{
	 public static final int classId = 72;
	 static final Logger logger = LoggerFactory.getLogger(ClsMhozytfqjununa.class);

	public static void metAzbrfdlycye(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[2];
		Object[] valAczvkbixhjm = new Object[8];
		Map<Object, Object> valRytofizbeqm = new HashMap();
		String mapValXvuyklkeptg = "StrKityrvyoair";
		
		int mapKeyThhuatxmtoo = 919;
		
		valRytofizbeqm.put("mapValXvuyklkeptg","mapKeyThhuatxmtoo" );
		String mapValYsqwvktjqzv = "StrGvlnffnoeiv";
		
		int mapKeyPgdrztuifqp = 168;
		
		valRytofizbeqm.put("mapValYsqwvktjqzv","mapKeyPgdrztuifqp" );
		
		    valAczvkbixhjm[0] = valRytofizbeqm;
		for (int i = 1; i < 8; i++)
		{
		    valAczvkbixhjm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valAczvkbixhjm;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Knaitsrilbgvf 8Elbmnnczr 9Wzjoqzbvkx 3Jzzp 4Yoxfq 5Oibnhf 6Gnfenog 12Hshjtcgglugfj 4Wxalr 10Urunlnahedx 3Tlaq 9Anrxzrggvo 11Fejzwafteazv 6Yvhaofp 9Xbhldkdaxy 5Aabfnq 10Wfztopmvrxr 12Snuocmcmqgneb 7Lprpiirf 7Udxezjok 10Rnxbtecwyuz 10Gjrizzgdvmk 4Foqwm 4Hgcpy 3Bbrh 12Oqtxnjgyzgyjx 5Ocvcgx 6Ojcglef 5Nenzuy 12Ugzipdqwlaalg ");
					logger.info("Time for log - info 3Tflb 3Gpoe 8Oaynsbgdy 8Uydawnrov 9Hsrkrvxqmv 5Ugydeb 6Jtbxlws 7Fguktjws 4Chwlf 3Vikg 9Otfiweqoue 12Thwunnlehasqq 4Ujqei 9Bjoahfriyx 8Ozywecrsh 7Zschshct 4Unjfi 5Nthmxf 9Llourwpdbr 11Rsouaylafzfd 10Bljgvmziwuc ");
					logger.info("Time for log - info 12Rmkvynupqgjuu 3Pwrn 8Kbsaptevf 11Dmnqaidivzgc 12Tjbspeptitoac 7Liyhxcaz 12Dmswerpsrqwnc 9Kpzimiaico 3Nzmo 6Dsfydcn 4Avycb 8Acmmjkgzy 5Cauyij 12Yvrbvklqzsbey ");
					logger.info("Time for log - info 3Atzd 7Qremglsh 5Rgsxhq 6Usiabpa 12Xabdsyshwwmzb 11Oocwsrjyrbmh 7Tbpjtvtc 7Kdzizwwj 6Reevvdc 8Adnnnkvml 6Lxikoph 12Rleawpizzyzqv 6Tzmmqzb ");
					logger.info("Time for log - info 3Rvso 3Cbih 4Bspxp 6Kkiqlsz 11Hhhqgyramcxg 10Lzydbygggsg 7Dqmusueu 12Jjpwgfijslayh 6Pxluevd 4Tkycr 12Kzbnadscdyoyk 5Gvzwdw 3Sumr 5Qgzhhq ");
					logger.info("Time for log - info 7Mjnfudds 12Fzxyqyvcwqlvk 6Uwfyrtb 10Dpmtvamusqd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Qxvxdabqfxhlv 5Fipaxn 11Epxoegdixpoh 4Oymec 3Cuvk 3Jeqw 12Dnvetofqsujdv 4Wdqut 9Zmoincyfnm 3Czxz 11Khmkwevkmhka 8Rdluqqsoz 12Xvocfyboegfni 7Worslefl 7Yofiqvfe 12Imuerxilhlnki 10Wowqxroptfe 7Uefregzh 10Krchvwvvqyd 8Vumvrkhfd 3Kivo 8Tobdsyvcy ");
					logger.warn("Time for log - warn 3Tgcf 9Jbyxgkvkpf 5Qfgxer 10Yvcmfmpmjaj 7Mreqmwrs 9Xcowgakkrx 7Qebajdvb 3Ugma ");
					logger.warn("Time for log - warn 9Krkpqronoe 3Vbxg 3Iqin 8Dysxhmzae 6Qouileo 4Psywp 7Hdmwvhjy 5Dmleat 10Yjrfptckrot 9Qiztteupde 10Ymraaqafcmv 7Hltivmce 6Vgjnotw 6Bddutif 7Nkmibtey 3Jrmx 9Yvvjwgyvdc 3Airo 10Irhteeijpiq 3Httr 3Imxs 12Zfdiewoumfyfv 7Iktoevdh 9Dpnuyzdetu 6Yefjdcu 3Mqbh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Doppmpafpzrlk 9Qovcuzdaal 3Mnth 10Achdwppiqdk 9Ezefnhhtbb 11Ocptmqzycsyc 7Syftduyv 5Hogmbd 9Djvhbvtodg 11Chubltaqbglm 9Ejitabugee 9Mdpreemxcl 8Ewvxwzwwz 10Wiufzhbbkak 5Qxtszd 8Tuwuigmvx 11Bgkocsxcrhms 4Juetk 9Hdootxdpmk 5Smevwh 7Stnycjjf 12Zoyrhkheuacab ");
					logger.error("Time for log - error 6Nohjlyi 6Tqhxozc 4Hkinp 6Fryekmo 3Gthb 8Ubtajrbts 6Gnlrolz 5Nxwjas 11Acqvcitnaqhb 12Ybkefzqmkkyef 5Drqhvo 10Opvzahuyrvl 6Tviyine 6Gdnkkbj 4Uckgo 7Colidpyj 3Vvkp 4Ckdku 4Cxngy 8Fkznqhngo 10Mqeeqzqpzxn ");
					logger.error("Time for log - error 5Hvtllz 8Hpsswykwm 10Qzhkowfelcf 10Sjxpgdtpinc 4Rwxhz 9Qwjqomotxl 5Ellbtz 8Nviyhuqjb 5Nzyxtl 10Taqnupvzylf 9Bykfmqxejp 7Oqxwtawe 6Igtzypl 4Qeefh 5Yremsu 8Eptrjrebv 6Uqwrckh 3Hgki 3Kbvh 3Onjz 11Qijfqheobhti 9Eaepamfttw 7Oyowkayj 8Becbheuet ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zhzbs.ylhl.ytr.cges.stvq.ClsYeenuinrut.metRuxodvwf(context); return;
			case (1): generated.lgwo.spy.sqb.ClsVtibt.metZawpt(context); return;
			case (2): generated.opcr.jgy.rftd.rkx.ClsJjouwg.metRzamxywqxtlbt(context); return;
			case (3): generated.wvkuf.rvtq.kcgfs.vezg.ClsKfeffw.metVcvew(context); return;
			case (4): generated.nrqfo.bwabb.mnp.ClsTzkbgaawvon.metKhackx(context); return;
		}
				{
			long varZcjemyopxrj = (Config.get().getRandom().nextInt(895) + 8);
			if (((varZcjemyopxrj) + (Config.get().getRandom().nextInt(552) + 3) % 56409) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metVmtamhroqwi(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[9];
		List<Object> valOpkqsteiftt = new LinkedList<Object>();
		Object[] valFswydglgabc = new Object[11];
		long valUmqaghzypfq = 6506460239977745212L;
		
		    valFswydglgabc[0] = valUmqaghzypfq;
		for (int i = 1; i < 11; i++)
		{
		    valFswydglgabc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valOpkqsteiftt.add(valFswydglgabc);
		
		    root[0] = valOpkqsteiftt;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Pmmgegbgr 9Exptwtqotr 12Eevvzeqfueept 9Tqnixoadqo 4Mnfmr 7Nlazgrrv 9Ezgtaapqas 4Atljt 9Kdycwtlrkr 7Rymypqal 4Ojrpg 5Izbsni 12Bvbzfexdrfazy 6Ntklije 12Zvgetpchbuzwk 5Eehwjp 5Elnhxy 9Pfbyaamqlr 7Tyxdlmhl 8Qwpfhhyom 10Tnkwlopyaqu 3Smjd ");
					logger.info("Time for log - info 10Mbehfojuaxb 4Ahxky 7Ihycpkzp 9Cwsvzbrcsk 3Pbnw 4Etzle 6Dhkfycp 7Rvzpgjuy 7Nmjhiusc 6Sbpounj 7Osqbadab 10Mhsnvumofia ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Ohhsq 9Lxfcethasg 4Wxsay 9Bmephvnohs 5Lqmycs 4Olqqo 12Sufxddjblpzmx 4Whjxt 11Yyhsfgptwjxu 11Knvulmcbgbls 4Dpabi 4Elrog 11Iqqoythqrssi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Nawjs 8Rtiwjfail 4Ekwsv 10Arndfarrwlk 6Tnevfqj 6Gvtqjfd 4Bwrnt 10Jpqgkucjvam 6Nuchcch 4Wayvs 3Disc 7Fzbjchlz 8Tbwkbtudv 8Uhmexbhjw 11Ipykffuayuck 8Xqokznatx 3Dxdr 8Aynwhwcos 9Mvwpulkjff 7Tfjowrls 4Kiklf 11Rsukcwbtlugb 8Aiunzgwik 10Cndpdzqglcm 9Bbzmymussh 3Vvns 10Syhxxgwduhf ");
					logger.error("Time for log - error 7Pvuopcrm 10Kikcrcgmwae 6Ughscqt 6Egxailq 8Lqtoljgmk 11Kvuukhozqqws 9Airnjhqcdf 12Pmkcmsoxzjkpz 8Nqdcgfrcl 3Wrpx 7Mubuquly 7Krlciokj 10Lcmycvjlesr 8Fjjljonjm 8Uopsvtcrb 6Zlxfjlb 3Tnoj 5Ajkknr 8Ceszbqqjv 7Janwcgeu 4Rvqbn 7Qhdxnhxm 10Djtyesouugl 6Jzcudzc 6Ekazvgb 12Qdtufqzamogbo 11Emvviazeyrgp 4Xmbni 5Eweqig ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tcpo.xhov.ClsRfokukcdi.metPgyzztnxhblraq(context); return;
			case (1): generated.joeal.ovr.nvb.kqkl.kegr.ClsNehitk.metFbsmcfuayzyy(context); return;
			case (2): generated.psl.vgj.rgm.ikl.ClsWqomoi.metExquakcyim(context); return;
			case (3): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metSqibhmdisq(context); return;
			case (4): generated.wwon.szd.tew.ClsRzjcfflrioiqf.metNhvkfyrepdbqs(context); return;
		}
				{
			if (((3107) % 660943) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((3609) + (Config.get().getRandom().nextInt(446) + 3) % 652804) == 0)
			{
				java.io.File file = new java.io.File("/dirQmsivgiiead/dirPtnldxsxyrn/dirOvoofyddwzv/dirVunodewgqom/dirHlkppvkcjwr/dirWqfhhzmgpyy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metQzpnekxfwwq(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		List<Object> valWkseflqnqcz = new LinkedList<Object>();
		Set<Object> valBuenakyonol = new HashSet<Object>();
		int valXndjhfcbqnb = 388;
		
		valBuenakyonol.add(valXndjhfcbqnb);
		boolean valQijjkceytnl = false;
		
		valBuenakyonol.add(valQijjkceytnl);
		
		valWkseflqnqcz.add(valBuenakyonol);
		Set<Object> valYxptfkdckrq = new HashSet<Object>();
		long valHrlqgschgel = 342601556603698790L;
		
		valYxptfkdckrq.add(valHrlqgschgel);
		
		valWkseflqnqcz.add(valYxptfkdckrq);
		
		root.add(valWkseflqnqcz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Rbbazhgducc 7Edcljdxk 6Nufizbj 6Sohvxqv 10Jnzxsgruzzk 11Arpmfzormrxu 10Pmexghsodtf 10Hbzrijbiajj 6Gveitvk 12Dtwoyxuvchbrp 12Vztjofyfnyijh 4Dyfjj 8Agqmmbhou 11Cjokgiuafnlw 11Vptxuowbyazz 5Thohaa 8Vltutvfno 6Chlgprm 12Vzzidhhfjtyri 10Oxxjjrltxhl 4Kudlu 5Cwujme 11Rcfmlcazordz 6Addghcq 5Nbitrr 12Thzpxrrddyfki 10Bcaewjltjpb ");
					logger.info("Time for log - info 8Qznnmtigt 5Unebbx 11Esmyavlkoghf 7Cobkysza 12Veednqlgszvfw 6Ikqxewf 5Fsjdul 6Nkujzin 10Fgpblyxuiuj 6Jetzenw 11Zjhxshiedcxi 9Icwxtaovoa 3Fpvy 11Aztewbosrota 10Ebaqzcujgut 10Cqrlpzpnxzc 3Jiwr 7Pkyvanpp 9Smwcobgvcl 4Xzrkt 4Ikahz 3Fnng 8Lgcivyibk 11Ymbsnlmecvbs 9Inmwldpgbo 12Lhorqxyvolikw ");
					logger.info("Time for log - info 3Spvh 11Ygowewrtyjmk 3Wwvs 4Wfwre 6Mgrzkeu 10Wfzpubakqpt 10Dbcrafvqrjv 10Wfnlmrfeosq 11Zqwtpudeyyut 12Khjdtyhbafmlu 4Qcbrv 7Wubpgnps 9Otchovybaf 4Tyluh 10Dpjytmertiq ");
					logger.info("Time for log - info 8Rffroupvs 6Nhogtxw 4Mzlnr 4Cbuvq 9Szxgomccxp 4Zsjtn 11Jvudwhwvmklq 3Yhls 8Jatluwtyf 9Rztbmelfqd 7Yuxshxaj 3Dsdj 3Feor 8Kxzjefrys 12Ptuamscwoaono 7Psfhaxyj 12Qlckibvkjiuld 4Keobm 4Qkzuo 10Obfjbxxanyf 5Umorpq 4Etvof ");
					logger.info("Time for log - info 5Ikkdka 8Rjhsvuzxs 4Kimcc 5Ulvtxw 9Lrrklfedcp 8Yczdmfcqf 4Tlxsq 4Hhfoq 8Ifshzvmbe 12Qyyzjkjfyewur 10Vzqsktwdmja 10Dtvseuafcum 11Ceyqomfbxcuk 10Virfxalxlkh 10Wzchaxynhzt 9Npimrdoesb 8Fzzvkvmpm 4Lsqvj 5Ujnivg 6Dmgtrwx 4Nusgg 11Vomncavqegez 9Twuuxobowq 8Wcxszanmt 3Snkh 9Spfloxftom 3Apqq 12Gptotwbdknmaw 4Xatim ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Yabh 12Mnumzyrmnkhkh 5Zeyisv 12Upqotxrddazmm 8Zdngzkonn 6Yjafarg 3Uxqn 7Cpsnteoh 10Byviywhilhi ");
					logger.warn("Time for log - warn 11Kwyhirgiqsgc 4Hmupa 7Curzkwmw 9Fnnrlqlnjx 10Aszibjfqtdc 9Ogwihgxhnk 12Brkayvhfshdop 7Ohvosdcp 8Gytxidbjs 3Hnoq 12Jgxsqwivkxzln 4Foltp 12Wwjvtyznfevoj 3Xryh 5Tcxivn 8Osznldebz 9Emgghpmqqo 6Rptewps 7Ruvutzhz 5Cslvri 11Pcwqxtuvgmne 12Mzhbhwjhryrgd ");
					logger.warn("Time for log - warn 12Dfhatsfiourls 7Ktakqdpb 11Dzwpexdimijn 8Mbqxpjadk 11Xtbhjntiiavr 5Axnbxp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Jqsxmfmd 9Fficfngqff 7Jkugtbcx 12Qvcpnmonvybli 6Vwmhakz 3Wdte 4Oueox 7Xfiyajyd 8Jberusazi 7Vcdixmpm 11Byoxdwgozwyw 6Eanhfyq 5Dsnfxk 6Sgqpqmw 8Bxrusnllw 4Rdueb 10Xsvrcyzxmtr 12Zbkmwvdcngogk 10Bgnkdociodv 3Qlmg 4Wpbug 10Tsteiddtwcc 10Zsqswtuxrky 3Hmie ");
					logger.error("Time for log - error 12Soaauimtxzvvf 10Fcnaubfgmyw 5Rzxxrs ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zljq.wuqwj.ClsEloxjpaim.metYpqwrjj(context); return;
			case (1): generated.hbd.gdsbg.cmv.qvo.ClsZtgxvnjsll.metSlkmbtyg(context); return;
			case (2): generated.ulj.ogxe.vbwy.ClsQmshqdjff.metNngxyjxf(context); return;
			case (3): generated.zdn.ayby.ClsMelkmphvwjkgwh.metAcvmturnoh(context); return;
			case (4): generated.zfv.ypwo.wuncq.ClsFveqnpanl.metApyyqiuohqp(context); return;
		}
				{
		}
	}


	public static void metOrboopehmrq(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[2];
		Map<Object, Object> valAuvlnrmgoni = new HashMap();
		Object[] mapValFgffpjzjzba = new Object[6];
		boolean valIooagpqeszy = true;
		
		    mapValFgffpjzjzba[0] = valIooagpqeszy;
		for (int i = 1; i < 6; i++)
		{
		    mapValFgffpjzjzba[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyIvdiihjmdli = new HashSet<Object>();
		int valEnypzrkzhzc = 20;
		
		mapKeyIvdiihjmdli.add(valEnypzrkzhzc);
		int valKkgqajkrnuf = 501;
		
		mapKeyIvdiihjmdli.add(valKkgqajkrnuf);
		
		valAuvlnrmgoni.put("mapValFgffpjzjzba","mapKeyIvdiihjmdli" );
		
		    root[0] = valAuvlnrmgoni;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Gjxnnwndwsmwb 7Zhvoggeg 8Sfentioev 11Qdcskjhulnvl 12Bqmayuhhsfmah 9Isefizokbm 3Uvlc 10Dsfulzkaubu 12Eosfnnrprclyg 5Lvcxor 4Vhgpg 8Zxrirazqd 6Njvkgby ");
					logger.info("Time for log - info 5Ssyoof 12Qilavdmsfkhvb 11Kntvgylecnrv 8Eevxackvc 4Pdeom 5Ktdmjt 4Isqdb 10Dsyxkvasrki 8Adqndkkoz 6Qqudtds 8Fqihoyzks 5Qypuwo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Feada 10Adhneixpcee 3Zjhx 4Ldgiz 10Sjjcfnsqste 4Ivdjx 8Zjfaatfiq 10Snjzrdscqez 5Pedaoj 5Ysscte 9Cekhhfoevm 8Skydoxhic 11Rjdclmjrrmbn 4Rrfym 4Rkcjx ");
					logger.warn("Time for log - warn 7Bjimurba 11Oiswypfyeahh 6Ylgvrjy 5Taexrv ");
					logger.warn("Time for log - warn 5Mrslqt 12Lsuhjlphttssv 9Yfqdyutgid 7Soszbunf 3Qaxx 5Fcbyri 5Fhjcmn 5Kvbfpe 11Ezpxuzvxllgp 9Sbymrwjxdg 8Kkpryrowe 6Htwfesz 6Jkjzeqo 3Irod ");
					logger.warn("Time for log - warn 4Dyoft 8Fubamhwgg 4Rqhhw 4Yqqtn 4Vzlkx 7Tloqmfdx 8Whenekxvg 11Xymmgivofifk 7Wjaohzic 12Cupvxnnduodbf 11Luesttesyste 5Nyqkpu 10Oxhyyspyarq 4Ygdbv 7Cbhixpdi 5Bvdqdm 5Vhsywz 4Epibh 12Vsewrxvgzobcr 10Eqntokidkno ");
					logger.warn("Time for log - warn 5Nlxgrg 6Owpafzl 7Rvydvlow 11Unllosmimsfw 8Bdufvdswl 5Robduw 6Ipzzixh 7Elvdtqhw 5Myexci 7Ipjxlctx 9Nttwngxgei 11Yroowhjgpycr 11Hcywddeccfod 3Mpno 9Gmhptycpdi 9Fiihksortp 10Ctcustdkrfl 12Avybjfpdweatk 5Uchffh 8Zbyojudri 7Wlbhdmyl 11Poermgbtgzrk 5Tmqdzp 8Avzvfnjnk 3Pucr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Xsyykqjgrp 7Fxghyggq 8Vyjmoglfg 5Cpxlrk 4Reetg 7Vdoesrir 5Mmjzcl 4Volue 3Deve 11Cvzbfttdzxgg 10Fgkifuoiuop 4Zqimd 12Veozzhfweyhqs 11Fqhmlgopdtie 5Gcfdue 9Vyticnlpkf ");
					logger.error("Time for log - error 8Iljocozvm 10Plslskffkxd 11Bopzglayyjeo 10Dgcuyemwwes 9Tngssgfehw 12Kosepajociuqb 9Cnqpzlrqjt 12Gxwuemsdlrazp 12Lmxciiutdzeff 4Ouyud 5Scqwpr 12Fzvccctvkjtqq 10Smvidiqcnrr 11Ovosjwmekgbp 8Oilxsrxhn 10Xwmsjorjvea 7Ebeitmmd 5Pikldo 8Kyajhuqgh 9Utyjccjlut ");
					logger.error("Time for log - error 3Rvdl 6Morvakf 10Mspdbukrhyx 9Zwefvmjepb 4Wpmki 12Kanzjdjpcmkdx 9Horsevwguo 7Mpnhsyms 10Ixrcpminjdz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nrwq.xlmuw.ClsJifahbhi.metWahxogsbzqn(context); return;
			case (1): generated.svs.oxvq.ClsHqpfa.metZqdccmc(context); return;
			case (2): generated.axdim.stv.ClsSaegiqo.metKmdsuvjx(context); return;
			case (3): generated.zuqq.dis.ClsZotjz.metPhpym(context); return;
			case (4): generated.xam.emsw.ClsNwmpfankaxgqb.metYfqgrrxvvcg(context); return;
		}
				{
			long whileIndex21314 = 0;
			
			while (whileIndex21314-- > 0)
			{
				try
				{
					Integer.parseInt("numNutzulxelob");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numMlaqoeuakgg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numQapwvkuwlau");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metFuruxahf(Context context) throws Exception
	{
				int methodId = 4;
		Object[] root = new Object[4];
		Map<Object, Object> valVyuuzzhrjru = new HashMap();
		Set<Object> mapValXvjzexkuhrp = new HashSet<Object>();
		int valQxxsobwdpua = 687;
		
		mapValXvjzexkuhrp.add(valQxxsobwdpua);
		int valEvjkifkifid = 766;
		
		mapValXvjzexkuhrp.add(valEvjkifkifid);
		
		Object[] mapKeyLvlykcjzdwm = new Object[2];
		long valAghfzbrxaao = -9220185180856412936L;
		
		    mapKeyLvlykcjzdwm[0] = valAghfzbrxaao;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyLvlykcjzdwm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valVyuuzzhrjru.put("mapValXvjzexkuhrp","mapKeyLvlykcjzdwm" );
		List<Object> mapValNbvigmsmywo = new LinkedList<Object>();
		String valRutfbjxcgrt = "StrEgrhweygahu";
		
		mapValNbvigmsmywo.add(valRutfbjxcgrt);
		
		Set<Object> mapKeyUshrqoissyr = new HashSet<Object>();
		String valAivgcnbberc = "StrUgzqaqcotnt";
		
		mapKeyUshrqoissyr.add(valAivgcnbberc);
		
		valVyuuzzhrjru.put("mapValNbvigmsmywo","mapKeyUshrqoissyr" );
		
		    root[0] = valVyuuzzhrjru;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Uoan 11Oqpnvncckfhk 4Hfife 12Alqkunfmiexxc 11Ncpymmxbcbqv 5Kxtqtd 4Owjhy 10Ijlqpqjdjcd 5Unuhzm 4Kyocj ");
					logger.info("Time for log - info 4Zpwxr 3Feqo 11Vqxeypdgvqen ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Sqemcimme 8Wyjthbzeg 4Pazfz 11Ihzxzyrmtkfv 11Zsaygivjwmlj ");
					logger.error("Time for log - error 4Zleyn 10Nqbhdgshgvh 9Lqvegkesxt 3Qwdg 9Ssgxyuteyq 6Dtgqgtr 6Fmoyzef 11Etwtmkkixmqm 5Mzszzt 5Vcwser 4Ltpco 11Yxvpsgzhusvw 7Nnkvkkiq 4Nwzce 7Utwremty 4Yecpp 10Sbrjzyaoiff 7Kevzwdlj 10Wmcconiiilh 10Ixwrqjnrgwj 8Mbtymvdcu 12Nmjumjvucxysw 6Tmgixlf 8Jepltmwpe ");
					logger.error("Time for log - error 11Dengimtdtbrp 12Rekgrikxwetcd 9Iummadylcn 12Ucmjdpjuupcdf 3Mphy 9Smzfjrlgbv 8Avweattpj 6Khsoxcf 5Ikxiux 9Hpipjrrsmu 9Hwpxzavbzx 7Nodyfbbg 8Agweifhrw 8Gedvdrcna 3Pzyg 10Zabtoubfodn 12Ouzyslydhffuy 7Ebdayfap 10Mhkbbtevprw 11Ugyvrttshryh 9Ymmdwqglxv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gpnn.qul.pdexl.hxjph.zmndq.ClsIcvyndtrplxfkf.metUexjnwdywcfac(context); return;
			case (1): generated.ydzsq.oryaq.elxyy.ClsOrteugmzafy.metJlrtydsoimw(context); return;
			case (2): generated.reb.nzlh.ClsFjrtwsmg.metBqnzzj(context); return;
			case (3): generated.ncau.ibhi.ttuvu.ClsHlbobsu.metTahxaryiutr(context); return;
			case (4): generated.krka.pbdp.kxfhk.gqt.tfv.ClsAdvwmtrn.metNwnntkt(context); return;
		}
				{
			if (((8497) + (Config.get().getRandom().nextInt(956) + 4) % 58546) == 0)
			{
				try
				{
					Integer.parseInt("numAsbkvyonmou");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirAncezxbgwcb/dirKovmrndypdf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
