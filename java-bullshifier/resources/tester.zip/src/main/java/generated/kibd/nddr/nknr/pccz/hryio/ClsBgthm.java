package generated.kibd.nddr.nknr.pccz.hryio;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBgthm
{
	 public static final int classId = 71;
	 static final Logger logger = LoggerFactory.getLogger(ClsBgthm.class);

	public static void metFrmpvshfvh(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Object[] valUkiqlkjkwvj = new Object[8];
		List<Object> valRxwxocqmpoy = new LinkedList<Object>();
		long valYjtuyqjytjn = 5447952976062002249L;
		
		valRxwxocqmpoy.add(valYjtuyqjytjn);
		boolean valNvpwsylwlaf = false;
		
		valRxwxocqmpoy.add(valNvpwsylwlaf);
		
		    valUkiqlkjkwvj[0] = valRxwxocqmpoy;
		for (int i = 1; i < 8; i++)
		{
		    valUkiqlkjkwvj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valUkiqlkjkwvj);
		Map<Object, Object> valGkfnwpczniq = new HashMap();
		List<Object> mapValGmoahkgdziu = new LinkedList<Object>();
		long valNtlxjhieobh = 4221102827952450379L;
		
		mapValGmoahkgdziu.add(valNtlxjhieobh);
		
		Set<Object> mapKeyNelcwvvsoyh = new HashSet<Object>();
		long valFvxacjwuvjh = -8357205921983328406L;
		
		mapKeyNelcwvvsoyh.add(valFvxacjwuvjh);
		long valQqcpdyfmdpj = -3749341310717255077L;
		
		mapKeyNelcwvvsoyh.add(valQqcpdyfmdpj);
		
		valGkfnwpczniq.put("mapValGmoahkgdziu","mapKeyNelcwvvsoyh" );
		Set<Object> mapValLjvvuozcgpy = new HashSet<Object>();
		boolean valKiouibvmltt = true;
		
		mapValLjvvuozcgpy.add(valKiouibvmltt);
		long valBohoqtgbnnp = -4254478417347885733L;
		
		mapValLjvvuozcgpy.add(valBohoqtgbnnp);
		
		Object[] mapKeyIawucxqebxx = new Object[6];
		int valBsausfdjjgy = 772;
		
		    mapKeyIawucxqebxx[0] = valBsausfdjjgy;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyIawucxqebxx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valGkfnwpczniq.put("mapValLjvvuozcgpy","mapKeyIawucxqebxx" );
		
		root.add(valGkfnwpczniq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Ziqftpbifiwl 4Bdrdf 12Nxmvepussbvve 4Kgvfa 8Xzrzgitdd 7Abymnyzt 5Eqwhkm 3Oujw 8Yjowcbuqx 11Kxizkmjgqdzu 8Gjumzufoe 4Prkdh 5Cgzwps 8Hanbhmdkk 3Gsig 10Pnthnqqqgey 7Wglqubtg 11Gwqgcemvpmgj 12Mlwytlciqtpjv 8Ymeeunfqj 7Iqahqutv 3Yook 10Acvitaaivlc 4Jjipb 7Pdcztglv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Uqjjfzrncj 5Yrsovu 3Iqvx 4Qyyjb 11Kwxuxpbypjdy ");
					logger.warn("Time for log - warn 6Aberofr 9Obvmsvjutp 9Yjnciotaju 11Zbjxnyqulcar 6Oezzand 11Uoptjdpinxmc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Xjiopz 6Sxawrtm 4Ijosk 9Vuvoetfcfs 10Ctxkbrbahyg 12Xuwcexezlqdtx 7Louqnhkv 9Iamitdvoit 6Zpkegbd 11Fubidoyhnxqe 3Qnii 8Qjwunydux 10Gvidnuihplu 6Svnrzty 10Eoqgdjzwrsg 6Erirgxb 7Tcbppron 4Bajus 3Mkuq 7Ylvaplcg 4Btghn 8Kzozddund 7Obwyoijs 4Phvms 4Aqegz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.npa.tuyd.ClsLxzuwxfsi.metNpvomn(context); return;
			case (1): generated.eob.tzj.qiec.ClsEnjcnowop.metHjaxbe(context); return;
			case (2): generated.udzdg.aoq.runwl.jiwf.ClsBbcobewbgt.metVygkbiannogx(context); return;
			case (3): generated.obfi.prawn.asr.ClsHvlzhrjejvoom.metTssprbwiuo(context); return;
			case (4): generated.zuqq.dis.ClsZotjz.metPhpym(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varLeashftezrc = (Config.get().getRandom().nextInt(994) + 6);
			try
			{
				try
				{
					Integer.parseInt("numZsddobuswvu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex21298)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirCgxgglpojib/dirCyiqiyaaybm/dirQmstuqgjajv/dirHacuqovbgct");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
