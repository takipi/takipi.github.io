package generated.xvt.cmvm.fgj.efz.bawb;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsIacmgbgh
{
	 public static final int classId = 244;
	 static final Logger logger = LoggerFactory.getLogger(ClsIacmgbgh.class);

	public static void metHijjkg(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[7];
		Map<Object, Object> valEjazeypgozq = new HashMap();
		Object[] mapValJdytqwxlcam = new Object[2];
		int valFxrihkywkro = 697;
		
		    mapValJdytqwxlcam[0] = valFxrihkywkro;
		for (int i = 1; i < 2; i++)
		{
		    mapValJdytqwxlcam[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyGbyebprymcz = new Object[5];
		int valGvmbwabymlb = 497;
		
		    mapKeyGbyebprymcz[0] = valGvmbwabymlb;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyGbyebprymcz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valEjazeypgozq.put("mapValJdytqwxlcam","mapKeyGbyebprymcz" );
		Set<Object> mapValFkexjimxjoj = new HashSet<Object>();
		long valFgfbvipqlhx = -4232495118667767808L;
		
		mapValFkexjimxjoj.add(valFgfbvipqlhx);
		int valMshehwlsunx = 269;
		
		mapValFkexjimxjoj.add(valMshehwlsunx);
		
		Map<Object, Object> mapKeyJqmwcucpdee = new HashMap();
		long mapValMarhrqjmkbo = -6056590055808843748L;
		
		long mapKeyPeqmvqbthoj = 8622129422126025462L;
		
		mapKeyJqmwcucpdee.put("mapValMarhrqjmkbo","mapKeyPeqmvqbthoj" );
		int mapValThyskmnoaic = 38;
		
		String mapKeyZuxcsnuxwqn = "StrPoafilggrpi";
		
		mapKeyJqmwcucpdee.put("mapValThyskmnoaic","mapKeyZuxcsnuxwqn" );
		
		valEjazeypgozq.put("mapValFkexjimxjoj","mapKeyJqmwcucpdee" );
		
		    root[0] = valEjazeypgozq;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Odfrvujbjsjgj 10Npjjpbercau 10Fptjvwhawod 3Rihk ");
					logger.info("Time for log - info 11Hmondhsdudug 6Stmhkhr 8Olmutodwj 5Fsdgkz 10Bkwtrftvkkn 6Qtgqugp 8Hcclmyuuk 10Uwhybxwttdm 7Mibftgex 6Qtmkufb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Ihiciaowhnrrs 10Qzsfunokpla 10Gpmyswclzeg 9Iytzlvehbq 10Lwerityeszv 4Imgza 10Fyyjsxecsfq 9Qqdafyvdld 4Wxofe 10Hpuebiutyqn 8Iodapoapb 7Essvwozd 12Vypcjkkbgxjkc 6Fxgwwoz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Dwcoogrhib 9Zozcnkpktb 10Fsdsovqhtzx 10Qgwshdrstxo ");
					logger.error("Time for log - error 7Wgwclegs 9Bdudugxzwh 4Pcvtc 3Bzxa 9Hwdkzqahob 5Cvxvyf 10Uuqvufywgnc 12Cidcwbkterjeq 4Knqpr 9Crwpacgvlw 6Ljcqjch 8Hyuotxwsu 8Tfcqwnaox 7Acqyjnjc 10Quwlivrlouq 8Bfjlpyxcs 3Wkez 5Uyxiab 9Hqbwiapuhn 5Ieriqt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
			case (1): generated.fur.dagce.oeqx.ClsTsqthfwvzszch.metJmxhhbj(context); return;
			case (2): generated.gmgh.ssix.lawd.ClsKyyfcksbykyfba.metHprhetizwb(context); return;
			case (3): generated.udzdg.aoq.runwl.jiwf.ClsBbcobewbgt.metVygkbiannogx(context); return;
			case (4): generated.hjt.myuvv.hkc.tfpi.ClsJfukwmizredp.metKzuep(context); return;
		}
				{
			int loopIndex24314 = 0;
			for (loopIndex24314 = 0; loopIndex24314 < 9695; loopIndex24314++)
			{
				java.io.File file = new java.io.File("/dirUshqyqixurb/dirVzlohxbtawz/dirWsagcxrafwc/dirOmvyrdhvrgp/dirGmbdacfppxa/dirNfkdsvttfls/dirNjkwzjudoww/dirSgoqltkigqg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
