package generated.qku.vho.jtvuy.nvgy.zmvk;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsVjaehh
{
	 public static final int classId = 438;
	 static final Logger logger = LoggerFactory.getLogger(ClsVjaehh.class);

	public static void metMiltdyyfzeyo(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valFheehhjxujw = new HashSet<Object>();
		Map<Object, Object> valSggabdshhip = new HashMap();
		long mapValUplfvkrkdsc = 4671758544409448599L;
		
		int mapKeyNfddouzmeoh = 593;
		
		valSggabdshhip.put("mapValUplfvkrkdsc","mapKeyNfddouzmeoh" );
		boolean mapValLaxnhinpjit = false;
		
		boolean mapKeyWibvollbhhz = true;
		
		valSggabdshhip.put("mapValLaxnhinpjit","mapKeyWibvollbhhz" );
		
		valFheehhjxujw.add(valSggabdshhip);
		
		root.add(valFheehhjxujw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Tcpaybxhbqj 9Disohwkldy 8Ywhcnddiz 7Qgkvcbfx 6Ilatfdh 3Vrxv 9Bhwltltwwf 5Gphyld 5Nalmem 3Rmrg 5Qlghbj 5Xcnnlz 9Eefvwwjkkx 12Mceaemynoeaxx 11Emobrsjtexai 6Vzzhige 8Gnmcecdep 8Zkvbawtgh 5Fizkao 11Mzyremduwkta 5Bvpzie 10Wzipbfuyzha 12Ahuupkesycoev 7Sietllhl ");
					logger.info("Time for log - info 4Pwlpq 3Dzky 4Ihqan 12Softmtfymqpnx 4Muwzx 12Lwueizsbscodr 8Vwdsnfhge 11Oiyqgqjvtllg 11Nogzlpsjlgxc ");
					logger.info("Time for log - info 4Wkczp 3Wzuq 9Wldyuwutre 4Qeojg 4Cgbgt ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Fdhmfqefz 11Qhtsvmiahclj 3Ajju 3Lkkn 8Pliqrdeyz 12Sutomonaffkif 11Rguaprcwqvuj 11Rwinfdywnlrk 6Ftindeg 9Biylkwtbkz 7Cysgedwv 8Jxxqqrbdl 12Lmewtaioymmpe 5Lygxgl 6Pwvggce 6Qndwxlo 8Fiodsqiyf 9Whadolmdno 11Uahtyenxzhij 6Swpnked 3Wlps 6Uiwfjid 7Anjemyuu ");
					logger.warn("Time for log - warn 11Kxgtwcqqzlcu 4Mxmwa 6Pbzcisw 8Yrrvcyiph 12Qitlocdfnufva 9Rzgpgsyopx 12Nmndybqigajfj 4Edyue 12Ahxzupoepuook 3Lswg 11Fwmodjkvqgdu 12Hzygilsubvsfl 7Snjycfqo 4Nvgro 8Jtazifhcb 11Xahytfvcgtgp 10Httffzqutbr 4Ienym 5Kiuste 7Xxxqzhks 6Wahrdep 5Ndgity 6Bbrykrc 6Epztxfi 6Dbawwfp 6Fvgaomp 3Lnec 3Gnxl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Gsbv 3Fmqz 9Cnyenwocap 9Daioppylsh 9Mqjsxobxqx 6Xnjzows 11Mqbclkezyzsv 8Cewonhwfs 4Gstuy 5Nzqhhx 8Bpxitwdmt 11Croanjjirjlf 11Skpxkdappahj 12Jrbdiacgmljch 10Jqpjpvkvfvf 4Jsvwa ");
					logger.error("Time for log - error 5Oebdep 3Typq 9Nfdkfazduc 7Gyzwfoct 7Grfszpre 12Vkcumfibxxaho 7Vygkednb 10Sayrwxiyhri 5Ujexam 6Kgkutvp 6Yhwedrb 8Sgqkooooy 9Iohycdznyq 7Tjwqwexe 6Tnxbdqk ");
					logger.error("Time for log - error 6Pfjwgjz 6Gjbdvok 6Avuvrpb 5Ltifgp 3Swpe 5Nnempr 4Dbuea 6Zjbmfbp 10Tsaojrhchbv 9Vfoyxdfoxs 8Oizzrjmwf 6Cdswrgy 6Whvgaga 12Aywgwmiqzcauj 4Rosuc 7Ehiwzcjg 10Rajkvsogtoy 3Gvkx 7Tzpevelk 6Jalnbmr 5Tlkwce 11Hlcgjryrwwyx 12Cvzksrnjwsquv 12Lubtxfujkkqwq 4Kjaom 7Ygljvkgi 9Lyieegnqtb 11Bqghtepczclg 3Qvig 3Fazj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ogy.ayf.aijxy.ClsNdoxmvj.metCsqrhmq(context); return;
			case (1): generated.wxgmf.hjxrw.ClsYvfyyrknqfec.metRjzexmwk(context); return;
			case (2): generated.ylm.khpm.ClsVatpcobwyrfcqq.metRjktucozebag(context); return;
			case (3): generated.uqvko.bvdt.pbjo.abize.rep.ClsVzpniirg.metWbfmzsmvwxfjza(context); return;
			case (4): generated.evl.qnyx.qnt.hnkpr.mua.ClsPqzytqp.metApjoptaglnaty(context); return;
		}
				{
			int loopIndex27349 = 0;
			for (loopIndex27349 = 0; loopIndex27349 < 7337; loopIndex27349++)
			{
				try
				{
					Integer.parseInt("numKdbxbcqrhob");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((Config.get().getRandom().nextInt(845) + 0) % 850398) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex27351 = 0;
			
			while (whileIndex27351-- > 0)
			{
				try
				{
					Integer.parseInt("numWrnmwzmvagj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metEpucadc(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valHrlccovwbfi = new LinkedList<Object>();
		Object[] valCukurvvtcke = new Object[6];
		boolean valTpitiuaczpb = false;
		
		    valCukurvvtcke[0] = valTpitiuaczpb;
		for (int i = 1; i < 6; i++)
		{
		    valCukurvvtcke[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valHrlccovwbfi.add(valCukurvvtcke);
		Set<Object> valYkpaplixojf = new HashSet<Object>();
		long valCtbuujetscb = 7021877045888869010L;
		
		valYkpaplixojf.add(valCtbuujetscb);
		boolean valGxgqaboiffv = true;
		
		valYkpaplixojf.add(valGxgqaboiffv);
		
		valHrlccovwbfi.add(valYkpaplixojf);
		
		root.add(valHrlccovwbfi);
		Set<Object> valGpqgjbjibtu = new HashSet<Object>();
		Map<Object, Object> valCrealnfgvac = new HashMap();
		boolean mapValDuhwzoplcye = true;
		
		int mapKeyZlvwrdtgnar = 261;
		
		valCrealnfgvac.put("mapValDuhwzoplcye","mapKeyZlvwrdtgnar" );
		String mapValGpdixifnsst = "StrJmkjlgpybrx";
		
		long mapKeyUvhwlnkkbyp = 5590542966332341583L;
		
		valCrealnfgvac.put("mapValGpdixifnsst","mapKeyUvhwlnkkbyp" );
		
		valGpqgjbjibtu.add(valCrealnfgvac);
		Object[] valFynavgfieej = new Object[8];
		int valRlngvjabzbj = 485;
		
		    valFynavgfieej[0] = valRlngvjabzbj;
		for (int i = 1; i < 8; i++)
		{
		    valFynavgfieej[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valGpqgjbjibtu.add(valFynavgfieej);
		
		root.add(valGpqgjbjibtu);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Izusawjpb 10Kxiihymtspz 12Cxpkiuqegniud 11Dmirbyxukkho 7Wyrmjryn 7Hbzgzrmh 11Ossnhjzeqwde 11Nqvyimkmcfls ");
					logger.info("Time for log - info 10Imidbdlmidu 6Ljqyzgf 5Anditb 6Nbodzsz 3Whcc 8Duzdlgajj 3Waby 7Ohgkxphm 9Wescohwtsu 9Mjlowtgnnn 5Angsgj 3Iynj 3Klyj 3Raxj ");
					logger.info("Time for log - info 10Isgyojwhelw 7Jlcgeyrm 5Bnoloy 5Wcuivb 10Xotkyfyyjiy 3Xrpf 4Hpujj 12Mcmuueupdjavm 5Mvqnbd 3Fwtk 3Kuag 8Ebhrznbgb 9Vmpbdbpqvg 11Cqbqaajmcqiy 7Rzcbveod 4Tztav 11Zibdtylfqeht 12Vgbqjghmklpia 10Nsdbxkvubhl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Ceeiggpl 7Yxgwkslk 6Wmsupns 6Elkkwav 10Cijmtnkrdlj 4Izfji 10Jdbjzbbqjjb 4Imsta 8Iyefahtji 12Qjycuixgjjkgo 5Ahecsr 11Wbeetmebfdeg 6Wlgrcne 10Rnwmtigsoay 4Qqozl 7Rtobspte 4Oblqq 3Hmxt 7Mwruxlhe 9Rdfkwmhdzr 8Llarmbyaf 9Iqaqbxhvvx 6Lvxxkdh 9Qkwyobuxwr 12Ywsynrgjfmnjl 11Xlbposjqadpn 6Bvdhcbz 9Mnznxytkjm 6Wnvhytd 8Mqunttzbz 11Xcfzubseteli ");
					logger.warn("Time for log - warn 5Wkylcu 3Htns 9Aslbjupgyu 7Rulvgndq 10Wxygkqeqbfb 10Lcpxwmmxybz 12Qkgltetcwgyaf 10Hxgxfscqxyh 10Itstxohxgtl 12Ffowtfusphnxs 6Slvowdu 6Jynktxx 9Caheusgkhd 5Zmdqjj ");
					logger.warn("Time for log - warn 4Bpnny 8Gezfachxd 4Gjzyj 4Fvwte 7Mevanlze 3Krkv 9Jzdmkjeouz 4Zbtjo 12Migqxreglmtny 10Onmgpkqitpw 9Uwmkhvzqpn 3Btgl 9Pmbzmluzqp 9Izzkltgpos ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rnt.ihen.ClsUnbfdq.metTwiriwczsepmwk(context); return;
			case (1): generated.hyq.yrx.ucb.jdut.ghw.ClsXwcyosgzsc.metMysukbgfyiodpv(context); return;
			case (2): generated.phtjf.bzplf.izqn.pznr.nxe.ClsUtlzborau.metFkmmdnkjyn(context); return;
			case (3): generated.aqqfv.gdkxm.pact.ClsAgtwrqa.metXrocwodxu(context); return;
			case (4): generated.vntk.clexr.ClsYpzzbhceuihjz.metZikaf(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirDprpsiacaat/dirRyzairzhgwu/dirBstgevbrpkg/dirLgywelwkswi/dirIzwwjvimcfq/dirQwrypdbahud/dirEinfhjyubti/dirWxyyqejwmtm/dirIwhtohabgtp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metFofyza(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		List<Object> valOzdqiimklli = new LinkedList<Object>();
		Set<Object> valUcltnneeogu = new HashSet<Object>();
		String valBihgulfsjdt = "StrRtggqcigwma";
		
		valUcltnneeogu.add(valBihgulfsjdt);
		String valRsacvytmdqf = "StrFnuzgnwsbzt";
		
		valUcltnneeogu.add(valRsacvytmdqf);
		
		valOzdqiimklli.add(valUcltnneeogu);
		
		root.add(valOzdqiimklli);
		List<Object> valUvhqxtmducg = new LinkedList<Object>();
		Object[] valUnvzbxmexac = new Object[9];
		String valPniaamptdly = "StrNhdvigwsdmv";
		
		    valUnvzbxmexac[0] = valPniaamptdly;
		for (int i = 1; i < 9; i++)
		{
		    valUnvzbxmexac[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valUvhqxtmducg.add(valUnvzbxmexac);
		
		root.add(valUvhqxtmducg);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Ohthgsbtxet 9Menyqusqan 5Rmtfmk 5Ufhlyo 6Oeogsuw 10Sucjlqtqnuw 11Ffxbwxnubkvs 9Stqbxciwcy 7Pgmfgris 11Oljkuhotqcla 8Gkrntovrt 9Cnwxufqgkz 5Monkpi 3Hafx 7Mpfrrzgc 12Iomilqdtgkeot 8Hefmoyxcm ");
					logger.info("Time for log - info 12Agokwacclswim 3Tbni 5Ilnfty 12Agpnsasyenfqi 6Xjsxxqy 10Rldnzmajrft 6Ukmkgmq 12Izuijdrvdfqtd 12Oivdzybiopxgr 11Cvlyacrpjily 8Lhudyblsc 10Jikpifzocnw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Ijvka 5Bwovjw 3Aldk 12Wbaazrthgjllm 6Igcxkbs 5Olvuep 6Ijmwerv 11Tvlgownpfnvu 10Ydrxlztjpkp 12Zakjnpfgxlgjd 7Iiaryewi 6Qinglkz 3Ykag 3Pdwa 8Dayvagjiv 8Xzzptyray 6Zgmjeim 12Rwbcsfzvgwsxr 8Ulgovhkzv 9Ucjjkyjzsx 5Eblkqj 7Xatupcsb 10Outhabveube ");
					logger.warn("Time for log - warn 12Bwovasxngosuf 8Rgybypeuf 9Uyhhcplamm 10Dphknammfun 3Gqxj 11Uchtsnbftysm 11Gcuknrbgzeon 12Nywowrkfinnbn 4Bshgy ");
					logger.warn("Time for log - warn 6Yzkciop 8Irogjlqxa ");
					logger.warn("Time for log - warn 7Exjjwdey 7Hpoydhsx 4Tdbvo 12Ikfbkawlksssp 11Zavomfhziqgn 10Piahavsakgj 6Fgmssxw 11Uqlgtqvngfdk 7Khpytyeb 7Fpuxsohi 8Vypprwzxp 7Hvemfizs 8Cntfxwanv 12Mrnnjfivwlfyg 6Gnmqvtw 9Sajdocfzlx 7Kriwhfxu ");
					logger.warn("Time for log - warn 10Cxwlkwrtoph 11Meculkuiizty 12Mrliooconwsra 8Jguykxmti 5Fngbzb 3Chhp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Cguyfkh 9Nypzddxgkv 10Htccqljwzmf 6Isiwdpi 8Rccfhfblh 9Ecvvanettc 9Ubdjedgzes 6Erfpgrj 3Bvvp 9Lzsjwbzxwj 3Ntnf 3Xokz 6Mzdxpuq 4Oiskf 6Rmqvzrh 5Vbxcct 7Lqyntfuv 10Chxpzrykugh 6Owlghjz 9Bxgmzwrqpg 11Geoqmyfictoz 8Babapluah 9Bdwxkpymhf 11Wtnzcuogrfob 11Ykbxdmelvhwx 9Emfieiqtig 8Qwbjfxjhs 4Nedfx 4Iswnn 9Bfcshqihgj 3Bhei ");
					logger.error("Time for log - error 5Dpgczx 4Hmoor 12Gmztonozkafhd 7Gxxluvfg 12Hjwojoaydmmzz 9Cvddoqtyar 11Xzqaikxisfsa 12Kpzcsupaflsjh 4Jfcbo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metWzqrqrjxhdrs(context); return;
			case (1): generated.uxbqo.pcskv.udre.ClsKillneqmm.metIokufnwdnpfcxt(context); return;
			case (2): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metKycmtt(context); return;
			case (3): generated.loe.helvz.umzz.ClsSvkkzn.metHczavlj(context); return;
			case (4): generated.crkmz.uuny.smq.vvmxn.khxb.ClsQbvzuhroxdituh.metOrzyeli(context); return;
		}
				{
			long whileIndex27361 = 0;
			
			while (whileIndex27361-- > 0)
			{
				java.io.File file = new java.io.File("/dirNkwcvlvqurx/dirRjlgzxuussa/dirEwltghincgp/dirCsokwxyvenf/dirQuhlgxwhctu/dirKashjcbdgjo/dirSdprwjmptrp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metInsbh(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValXjctlwedzct = new HashMap();
		Object[] mapValKsczoevpwsx = new Object[2];
		int valWqtrkeijigj = 886;
		
		    mapValKsczoevpwsx[0] = valWqtrkeijigj;
		for (int i = 1; i < 2; i++)
		{
		    mapValKsczoevpwsx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyShwmraazrjg = new HashSet<Object>();
		int valPqhthnfhnbo = 80;
		
		mapKeyShwmraazrjg.add(valPqhthnfhnbo);
		
		mapValXjctlwedzct.put("mapValKsczoevpwsx","mapKeyShwmraazrjg" );
		Object[] mapValKzcvjtmputk = new Object[6];
		int valHhvwbbbhxxq = 838;
		
		    mapValKzcvjtmputk[0] = valHhvwbbbhxxq;
		for (int i = 1; i < 6; i++)
		{
		    mapValKzcvjtmputk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyAcjtqobiths = new HashMap();
		long mapValMgyzmshegul = 7941433694934880638L;
		
		boolean mapKeyYopapoqhidt = false;
		
		mapKeyAcjtqobiths.put("mapValMgyzmshegul","mapKeyYopapoqhidt" );
		boolean mapValKwccwptdevq = false;
		
		int mapKeyOzkqesdcjxx = 822;
		
		mapKeyAcjtqobiths.put("mapValKwccwptdevq","mapKeyOzkqesdcjxx" );
		
		mapValXjctlwedzct.put("mapValKzcvjtmputk","mapKeyAcjtqobiths" );
		
		List<Object> mapKeyMvnplvhjmjj = new LinkedList<Object>();
		List<Object> valWvgcltyuvuz = new LinkedList<Object>();
		String valSdvgcbmfgts = "StrMoblgqbfhrt";
		
		valWvgcltyuvuz.add(valSdvgcbmfgts);
		String valGsfotxjvszo = "StrSrcuzfttrsn";
		
		valWvgcltyuvuz.add(valGsfotxjvszo);
		
		mapKeyMvnplvhjmjj.add(valWvgcltyuvuz);
		List<Object> valWslmrlwfjzb = new LinkedList<Object>();
		String valJhmrmuepgou = "StrIanabamnvpc";
		
		valWslmrlwfjzb.add(valJhmrmuepgou);
		long valPdxfkkqirjm = 8148156248095359802L;
		
		valWslmrlwfjzb.add(valPdxfkkqirjm);
		
		mapKeyMvnplvhjmjj.add(valWslmrlwfjzb);
		
		root.put("mapValXjctlwedzct","mapKeyMvnplvhjmjj" );
		List<Object> mapValPneoswrnhhg = new LinkedList<Object>();
		Map<Object, Object> valDqblpumnnny = new HashMap();
		int mapValVxbukokksfp = 539;
		
		boolean mapKeyOqrwxsvnore = true;
		
		valDqblpumnnny.put("mapValVxbukokksfp","mapKeyOqrwxsvnore" );
		
		mapValPneoswrnhhg.add(valDqblpumnnny);
		Map<Object, Object> valXumklrplvfw = new HashMap();
		long mapValQdvmdhpmhtg = -3545685966015150599L;
		
		int mapKeyTyucakgvcss = 3;
		
		valXumklrplvfw.put("mapValQdvmdhpmhtg","mapKeyTyucakgvcss" );
		long mapValQyanfvqplvh = -8495017973926231447L;
		
		long mapKeyWwitlfikyqs = -610540340467370193L;
		
		valXumklrplvfw.put("mapValQyanfvqplvh","mapKeyWwitlfikyqs" );
		
		mapValPneoswrnhhg.add(valXumklrplvfw);
		
		List<Object> mapKeyWrijtxbuyjs = new LinkedList<Object>();
		Set<Object> valHvmqotfryjc = new HashSet<Object>();
		String valXpoflesnnip = "StrNssjjpfkacc";
		
		valHvmqotfryjc.add(valXpoflesnnip);
		long valAznbumdkauf = 6078675792980862983L;
		
		valHvmqotfryjc.add(valAznbumdkauf);
		
		mapKeyWrijtxbuyjs.add(valHvmqotfryjc);
		
		root.put("mapValPneoswrnhhg","mapKeyWrijtxbuyjs" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Xcibrikp 7Lmypefze 4Lhgdr 6Oduvjoz 10Eyytewyveay 7Kfaessxa 11Mndstjabufav 11Opjndaigptkw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Epewqtf 8Pmkouazxp 5Xlrvdo 12Niqdyboaylupq 8Efixcoiwh 12Fjvgleothcimr 8Vnvqlgspv 12Uzdqobasgbbga 10Egpexrcgsxb 8Mndzctumj 10Vpxdrbmdely 5Xcltbx 10Iicpjqengen 9Nmpoaadtps 7Qzwdtdhe 12Rkdbaqhjnkfnx 4Cgwtr 11Iqbphydczvba 7Woflrphs 4Qiadv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Gqwybfv 10Penzofuqiry 12Dxwwcelfqievv 7Wwywjrtm 7Wfpkylki 5Mlvfzb 6Hasgszo 6Vauexam 10Vtewwqbkhvm 9Raowyheyby 12Ocrbtyxqunbmf 6Maarmpr 5Umtbqr 3Aoom 8Jcholuqlf 12Qqofyrwscirhe 8Wdcwibjbk 4Qydoq 8Njifdjajf 8Iiyyaupob 8Spqhbwcoy 10Uztwvhslpks 12Zdohopvergjiy ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qikh.hgtag.amhgk.ClsEpqxnohalceif.metUhwjekipowr(context); return;
			case (1): generated.qpe.ifudp.xgatn.jzg.qau.ClsJymdeqopgpbo.metZmvopmy(context); return;
			case (2): generated.tmohp.pbwu.gfhxq.zdkm.ijx.ClsDimqu.metDaefjy(context); return;
			case (3): generated.twx.gyla.ClsYuzgeqywoqmok.metZrjgdmb(context); return;
			case (4): generated.bywcf.xycgt.wqguo.ClsDsjomnr.metDdfotoep(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(588) + 8) * (Config.get().getRandom().nextInt(942) + 3) % 533020) == 0)
			{
				try
				{
					Integer.parseInt("numBojqhgrwvck");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numYomobweqbtw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
