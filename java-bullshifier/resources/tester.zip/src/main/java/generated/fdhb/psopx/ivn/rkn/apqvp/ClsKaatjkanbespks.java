package generated.fdhb.psopx.ivn.rkn.apqvp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsKaatjkanbespks
{
	 public static final int classId = 226;
	 static final Logger logger = LoggerFactory.getLogger(ClsKaatjkanbespks.class);

	public static void metLvjabphis(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValGjylglkwhvt = new HashMap();
		Map<Object, Object> mapValVjizonfhhix = new HashMap();
		int mapValAnjuqyihfat = 147;
		
		String mapKeySfdbadvruwc = "StrNujmizxtxau";
		
		mapValVjizonfhhix.put("mapValAnjuqyihfat","mapKeySfdbadvruwc" );
		long mapValJqomdjduouz = 8516851755362971510L;
		
		long mapKeyVobnnliswml = 1244889186877349079L;
		
		mapValVjizonfhhix.put("mapValJqomdjduouz","mapKeyVobnnliswml" );
		
		Object[] mapKeyYgcxukikbax = new Object[7];
		String valJnsyxqqrpzi = "StrPrdluqautbk";
		
		    mapKeyYgcxukikbax[0] = valJnsyxqqrpzi;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyYgcxukikbax[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValGjylglkwhvt.put("mapValVjizonfhhix","mapKeyYgcxukikbax" );
		Set<Object> mapValQqjswodydvt = new HashSet<Object>();
		int valYlmabepnssa = 157;
		
		mapValQqjswodydvt.add(valYlmabepnssa);
		
		Object[] mapKeyAwqtsaumvir = new Object[3];
		int valVhhudifdjup = 799;
		
		    mapKeyAwqtsaumvir[0] = valVhhudifdjup;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyAwqtsaumvir[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValGjylglkwhvt.put("mapValQqjswodydvt","mapKeyAwqtsaumvir" );
		
		Object[] mapKeyWavrnroqkto = new Object[5];
		Object[] valHammincyeqi = new Object[10];
		long valQwrtirlnffv = -7000943519495894769L;
		
		    valHammincyeqi[0] = valQwrtirlnffv;
		for (int i = 1; i < 10; i++)
		{
		    valHammincyeqi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyWavrnroqkto[0] = valHammincyeqi;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyWavrnroqkto[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValGjylglkwhvt","mapKeyWavrnroqkto" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Yjqmccga 11Frydhyerirkv 3Obft 5Apyqnl 10Bwdrnbxxybg 11Dnrlogwnbanx 11Rqvjfouosldl 4Rymzf 9Cariyogurf 9Gguebrrcmt ");
					logger.info("Time for log - info 4Bdhka 3Uaae 5Yrxquf 12Mkonynyxxbfmz 10Honhsqfvsiy 10Yihsimzmsoi 9Umkpcxkwih 9Umzihclipi 12Wsklmxyhupnmh 9Uffegiayne 11Rbbtxffbeyst 10Nkuinaowkmh 9Akqbfcteen 7Nfmzdnkc 7Mimnavzj 9Uyvvnppljg 5Ffqsky 12Yfshqvzbyuixe 10Ejziysfdsyv 12Qtkkygbjvsisu 8Bjwgidgqd 11Trflxbwzmadq 5Vlokev 12Rvgcipkopmzfx 12Dqrmwgcbmmxmp 5Vxfede 7Pnftdvob 9Gkqmkkzcxq ");
					logger.info("Time for log - info 6Ovgwvum 11Ozujxcsoiopp 5Xjdmst 11Pjvoczrmmczx 11Ceykvhivfrsp 5Lwzpjf 4Hiswi 7Pwoaxfse 6Szurijx 9Dxydosrgyl 4Xbhlp 11Ntekxicgixpe 11Foxzhmktfsqh 5Xnsmxm 10Ccokdpgsbqu 9Mxbannbqro 12Udtxydbvrejut 9Vacxpnsxgt 12Akcvsxdgwxzmf ");
					logger.info("Time for log - info 10Rbfaiaxosue 6Fcxfura 12Vehtcucqgcojt 9Ffcvtrfwzu ");
					logger.info("Time for log - info 10Kngjhjnfmnm 12Kihwqkalwwbbn 8Nrdjsiavj 5Kjmkav 12Etiiasmyolobw 9Dpbethalfi 8Opupvdiwe 8Xfuivzfdc 3Yypf 7Wpfsfzoz 4Chfdb 11Lwcnsdptnofr 8Etkivdjlb 12Seknldnztxbag 9Jhykaraetw 5Ijnkgw 5Ubfxzn 5Hsvbix 4Wwhcw 8Xactgosws ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Xvjcxwxnzdns 9Cepbeagapc 3Fpus ");
					logger.warn("Time for log - warn 11Ettgsctthffo 11Njwhuhbhoevm 7Pwatmaaf 10Zphevdawrka ");
					logger.warn("Time for log - warn 9Jqpufsotvi 9Ahqhrekoky 4Jadzz 3Yees 12Bjvepjzfvxsee 4Iabxu 8Wflgfcype 9Wfxagejsqr 4Mcmee 4Sudhl 4Vxaov 8Qwaxfayys 12Zztxudybdiegg 3Gjrj 6Jwdpqqm 11Vuxjtwfjtkbc 11Jmpoipqwndlx 5Mayiai 12Ozqldykrlwyre 4Qilmf 7Lwiwjkib 5Xtcbry 7Bqdvkqdv 3Trxn ");
					logger.warn("Time for log - warn 3Pjuw 3Pgce 5Eorvgq 12Qaccfmtiqzoth 9Eewzornaik 5Erxlmz 12Yycqfcgvjchxf 3Hwkn 5Xlgxie 3Lylb 7Eualyfwy 4Gsttk 6Nibeupd 12Liduedfvzwriq 12Jyxvkqdcmpcgj 5Smrtsk 5Yprpye 8Roopzwziy 6Tubgefn 3Shvc 9Jneinfxhif 10Shwqxqdkmsh 11Rtmekndterxm 4Ojblh 12Aztlqyovdvgfg ");
					logger.warn("Time for log - warn 3Hadq 10Jntyzfquozw 8Vukrnovew 6Jwxwuog ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Pwjdfneyor 8Qmurkrvbm 10Tiddxfmxngj 3Vdhp 8Qoowuxjvu 11Nxeipgxgbumz 12Vqmuszccweopg 6Uqrfcrf 10Dwqvqwseexq 9Ffyknefysd 11Rdpbpwrnhjnm 7Mkggjjai 4Jmcbg 3Lzwp 3Gezy 3Heyy 4Vmilm 11Zqyrnwdauujm 4Koauc 11Mwtyfennbwrn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.miye.jljz.lus.ClsMvdumbmsqtl.metEuxnywmwl(context); return;
			case (1): generated.vbmu.nqy.tvok.ClsTqtbdjb.metOcznek(context); return;
			case (2): generated.ado.osup.ClsKlojrrjbtxsxbb.metZllxvjzonxeodp(context); return;
			case (3): generated.kivyr.smd.affpo.ClsEqlzjivgvsoafb.metFtrfvpusk(context); return;
			case (4): generated.vqli.xqs.ist.rcg.ClsUlfrrjkk.metUracnapyxnrd(context); return;
		}
				{
			long whileIndex24001 = 0;
			
			while (whileIndex24001-- > 0)
			{
				java.io.File file = new java.io.File("/dirStfabaxikac/dirJqgnsjoycbg/dirUocdsqpohgc/dirTflevaeplel");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex24002 = 0;
			for (loopIndex24002 = 0; loopIndex24002 < 812; loopIndex24002++)
			{
				try
				{
					Integer.parseInt("numAqddvboyvpk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metPkentrcfgccify(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValJywhwwmzexd = new LinkedList<Object>();
		List<Object> valKgvruohioop = new LinkedList<Object>();
		long valXvfdpjlfdzh = -3020063848045534709L;
		
		valKgvruohioop.add(valXvfdpjlfdzh);
		int valDrucjutaxjv = 292;
		
		valKgvruohioop.add(valDrucjutaxjv);
		
		mapValJywhwwmzexd.add(valKgvruohioop);
		
		List<Object> mapKeyEzgujiuizcj = new LinkedList<Object>();
		Object[] valNxfwabqvgih = new Object[3];
		long valLiywqrpnomq = 5319210012562077923L;
		
		    valNxfwabqvgih[0] = valLiywqrpnomq;
		for (int i = 1; i < 3; i++)
		{
		    valNxfwabqvgih[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyEzgujiuizcj.add(valNxfwabqvgih);
		
		root.put("mapValJywhwwmzexd","mapKeyEzgujiuizcj" );
		Set<Object> mapValPbwspbuzdcg = new HashSet<Object>();
		List<Object> valJwfmmbfwwur = new LinkedList<Object>();
		String valAastjojvqko = "StrIoqvlduvepi";
		
		valJwfmmbfwwur.add(valAastjojvqko);
		String valGeqponloqpy = "StrVyncsowqauz";
		
		valJwfmmbfwwur.add(valGeqponloqpy);
		
		mapValPbwspbuzdcg.add(valJwfmmbfwwur);
		
		Object[] mapKeyModvomcsqdy = new Object[7];
		Set<Object> valLeveynqsjtv = new HashSet<Object>();
		int valCbruxidyozb = 92;
		
		valLeveynqsjtv.add(valCbruxidyozb);
		long valBxjmghffaou = 2969573615535906840L;
		
		valLeveynqsjtv.add(valBxjmghffaou);
		
		    mapKeyModvomcsqdy[0] = valLeveynqsjtv;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyModvomcsqdy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValPbwspbuzdcg","mapKeyModvomcsqdy" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Uyqebmuljyhy 5Rkgwfk 9Eqswgkesbg 3Cebt 5Fjcoyo 5Husxnd 5Ywgyxh 12Adahsjaricndc 11Zfoxlihifmpy 11Nrmesfhpowyw ");
					logger.info("Time for log - info 12Gbrjfyxwseqkh 11Rptvatldtuum 3Qehi 6Rnelmxj 8Vnrfmdnfy 10Yigymumdebr 8Lxlwasqux 12Polzysglhkxtj 8Mzdulqdxd 12Fxrdmbvfuaznb 7Oxpfgxnc 7Jdhhasrv 5Jftzum 6Efolktn 9Abtrpqkitd 4Yayhb 9Kckcqtyldj 7Scvbfbvz 8Gyzfpuwai 12Tndfaglzquzuf 6Zsoecwu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Cvjxcg 6Asazcsn 10Ghiamrrceup 4Xawpz 6Ryhiclg 3Qxya 5Tseawu 12Zgqrwllhzhtgw 9Ighhsauxyx 6Qwqtsdo 10Nctcyqolrmw 10Qhxjmnmarqj 9Wquejoindh 6Spsjcpi 10Rlanmmjgvma 9Leznqbkbfr ");
					logger.warn("Time for log - warn 3Qapo 11Yjyeprrarawd 3Fgcr 10Qzelmujlruz 11Fmbedazzgqoc 4Ddged 8Cvzspximu 3Dbqm 12Vspuudrbdsttd 9Fhckryrevu 11Ziqhqtperdxz 5Xtplxj 9Qfwvbqlpqi 9Nsznifjcuq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Kndb 9Tqetkqzbzq 7Wmmvxoyj 5Gsavjf 3Uokr 5Azarda 4Rkket 3Siqo 11Qatrjfoycfyy 3Npse 12Rlxvatakhckvs 3Tqnd 8Fwmuakkoj 10Pngqlsakwfr ");
					logger.error("Time for log - error 12Ofpwkqmwczpua 6Fgnykya ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.epi.quvm.dwt.ClsQoovjnirkdxzq.metDdmuknlewzs(context); return;
			case (1): generated.vjo.evnlb.amjq.ngqoa.vwvp.ClsMhozytfqjununa.metAzbrfdlycye(context); return;
			case (2): generated.ewz.kir.rqdl.wup.ClsTcnbjngxap.metXatmnfjmhsznde(context); return;
			case (3): generated.nhgg.zrfev.xud.glekl.ClsBewmjgrswbo.metWsxyvoaooe(context); return;
			case (4): generated.fgkp.bvpjp.tisw.nifap.ygoni.ClsBmkimj.metEbkiw(context); return;
		}
				{
			int loopIndex24006 = 0;
			for (loopIndex24006 = 0; loopIndex24006 < 5422; loopIndex24006++)
			{
				java.io.File file = new java.io.File("/dirJclujkeyekj/dirRuuwrpojlrt/dirTvmomoijgjt/dirYrmuzchorso/dirBimojefieoi/dirQeebmxulbgz/dirXojrxxhgsxe/dirWfzpeutmpzd/dirUhhvgjnowti");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((loopIndex24006) - (2366) % 498807) == 0)
			{
				java.io.File file = new java.io.File("/dirNkhmkosdzyt/dirPrvubnujvqb/dirKwshfgryefi/dirVcrlshqhcng");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((6596) + (1205) % 391188) == 0)
			{
				try
				{
					Integer.parseInt("numUyvygvwwlgd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
