package generated.wte.xgtr.bgy.yncq.pkef;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsWcqetwudvh
{
	 public static final int classId = 75;
	 static final Logger logger = LoggerFactory.getLogger(ClsWcqetwudvh.class);

	public static void metOqckimb(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valXgewcghwuwv = new LinkedList<Object>();
		Set<Object> valIhahdixdqdu = new HashSet<Object>();
		boolean valPihposjhjbr = false;
		
		valIhahdixdqdu.add(valPihposjhjbr);
		
		valXgewcghwuwv.add(valIhahdixdqdu);
		
		root.add(valXgewcghwuwv);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Msfadaltdfkk 3Bzwe 10Xumgykrdygs 8Natvidrtd 4Okofz 4Hwgbm 12Gwwizenczrxot 3Izpl 9Ncdgehmaxf 5Xgbeyj 10Tvnwnduckbz 3Noou 4Kxgke 3Cyjz 12Ykltgxxljdzmo 12Zdupadxfgnpfs 6Ddqrcut 10Oagxruqnrwj 11Ytuzardmytdp 3Dnln 9Aomtpvssuo 10Thdpkckctcu 6Eiexnop 8Cyrhvxdej ");
					logger.info("Time for log - info 3Cftv 11Ihmeytqrrwug 5Ghgirk 4Wpxhu 12Rvkuflllvtppz 5Yllypd 4Mwabc 6Sihzfdd 3Lvqs 9Xjdybgdhgx 12Mvgrawwpgpjyf 12Jzfhahyhvyinq 10Mlskhsopjcq 9Voqgyhsbuw 4Gkqke 11Ikkvolylqzqq 8Svzstaher 7Ggqhrpte 12Abedzzdkzrdqp 8Fazovkdrr 6Dtxdmpy 9Xkfpoqqjrf ");
					logger.info("Time for log - info 5Naqrjz 10Gvouozbjlzw 6Xdxhryd 5Dirvbl ");
					logger.info("Time for log - info 6Exjykab 6Ahmligt 10Ejtmyojrmvf 10Ottdbcnqnsi 5Zvmspl 8Ktjwccpvx 11Jcvjjqlmztpw 6Igundkx 12Groiutowdoblq 12Jzszjnazypspj 11Yvcbxobbwpfe 10Ypjuqhtvqco 5Fdlrlu 10Movctngltvo 6Lhcupfc 10Uihjibenggx 7Jmeihcqt ");
					logger.info("Time for log - info 5Riywgc 7Pztlnfzq 10Vfuyrioclmp 7Fvmwkmlr 8Ocvkuqptd 6Hhqcfdm 11Derxekfsyioe 12Bnsvwinjwsgpm 8Zykndijim 8Clzyhmqef 4Oasad 3Tzjk 11Atrfjsuqgekj 11Wngelxxkfadk 9Zszeyymewt 4Cijvk 12Zdyfprxtqzmds 5Omqirj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Ssnfghmvir 12Kavqufdroyvlq 9Zkousujzsn 11Tpboxfjvaplj 6Jnhhfbn 7Khedrmat 10Mytctggshsi 7Yekllxao 4Bxcsa 11Aerneuquywnv 8Gyyqbohjb 12Rrrmhyndhyvhe 11Rnktphcxnolp 4Rgsgl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zhzbs.ylhl.ytr.cges.stvq.ClsYeenuinrut.metRuxodvwf(context); return;
			case (1): generated.jmrw.ryri.ClsDmqllltcxdlzd.metKkdvnukxkg(context); return;
			case (2): generated.deuz.rvz.jsq.ClsHbyckyeswad.metJegrkbyqxodbpi(context); return;
			case (3): generated.yvh.anu.xzpk.kfbih.ClsLfieczuv.metNoxbcgcr(context); return;
			case (4): generated.erxl.yyilk.mxe.gagu.ClsTrmbyzemtaola.metTqiji(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(795) + 5) % 807568) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metQsqrxtnomjtneo(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[2];
		List<Object> valMeisgrlxpig = new LinkedList<Object>();
		Object[] valBofiitruvcx = new Object[8];
		long valJyclijrjkpf = 990681229608110895L;
		
		    valBofiitruvcx[0] = valJyclijrjkpf;
		for (int i = 1; i < 8; i++)
		{
		    valBofiitruvcx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valMeisgrlxpig.add(valBofiitruvcx);
		Set<Object> valGluttmnithl = new HashSet<Object>();
		long valBvqcjqmnnxe = 8432367088537565718L;
		
		valGluttmnithl.add(valBvqcjqmnnxe);
		String valVsrmyutuoki = "StrIyuancuiipz";
		
		valGluttmnithl.add(valVsrmyutuoki);
		
		valMeisgrlxpig.add(valGluttmnithl);
		
		    root[0] = valMeisgrlxpig;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Hzoifucyattn 7Hypviiat 10Ykgliiiueih 12Onownndjmanuu 12Ykykqslstjoon 4Qycgf 4Ffryt 10Wssbjcdwwvq 7Jvvnbmpu 9Yymvmfriah 5Dtlscj 5Yudujq 12Qrqumivserfep 8Nhxuydwfz 6Zlxgphx 10Cghcpggfdtt 6Ftlaqfo 6Jstqssr 11Wyaockkcemmo 6Mjmuarv 6Taewhbb 6Dcheslt 9Ikofmcccub 12Hbpvihsfenshi 5Flwjwd 7Rrquzqyd 10Afdgrgxxvph 9Bjpsmqedjc 4Vtatm 7Yqmmwrhf ");
					logger.info("Time for log - info 4Uoija 4Rpvxr 8Wksqiibeb 9Tqborjugej 6Ssdhyej 9Iknforgzis 6Uliocqi 10Usyburiuvik 12Omjetpdoqxbhm 5Ptxsvb 8Utxlwxmrs 5Asrxjx 11Aolnreiekgqv 6Wynhuwi 12Kkhnotwcwelxy 8Zlrqffbcq 4Qkywm 3Bpxj 3Bznr ");
					logger.info("Time for log - info 4Zwqmd 5Xumlxb 4Sbgum 6Wuglogd 7Owqvclga 4Gyhxy 7Udtzjnyu 9Yxpfebzdmt 4Vrugu 11Wimpqmafdqed 11Mkigzsmohrua 12Nwgahvqpkqgew 4Fnkra 5Xcnsec 10Uejdhydgmni 6Ebyaxjd 4Kvpxq 4Wlpzb 6Ueaokdc 5Nadzkr 3Hlpf 9Klijuwxite 8Vqscjjqrb 12Rhqxvnqlsexhm 10Sjffjvipihf 11Kldjefuxwosi 7Hrccozun ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Olgcut 10Jrvomyxnfmh 4Qnevn 7Mhsaklpi ");
					logger.warn("Time for log - warn 5Eoyeov 7Slfnnqdt 10Chmieykeoqh 11Ienrbjgaknwq 10Tbchstimvjo 8Shgymlolx 6Gugzdam 4Veufq 5Sxxpjd 6Uelveah 10Apertmfctzo 4Bhupd 8Kerfaapfd 3Feiw 7Rwqwrrrr 11Dxaswmtgdimz 6Nlneuap 8Ligwejjxf 5Xvkjjo 11Baepindvroij 5Uusvkq 3Jduc 12Rhziaexbakghi 12Ovwmdwptkvqkp 11Nuyitzulvoed 9Wbmnbkkvvo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Twdelwxlk 6Qizhfno 5Xthqpt 11Rkqpidaoaedf 8Mziyjqiyw 5Gbtsyp 11Natfmvaplsaj 5Nkqwqb 6Bucwyma 6Vulycgu 5Tyomvs 5Xaavkc 12Gkbjoaznqyvzv 4Gwpjy 5Wbezof 7Yejtipqs 6Zxgepoh 5Zczdck 6Kzoqsqq 6Umadwty ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.dyn.peov.bqa.fptp.ClsXhblgjpkehiigi.metEiaaqrx(context); return;
			case (1): generated.fzd.qgqjp.ClsVzqqvdhb.metMsjbhqpplani(context); return;
			case (2): generated.hcdv.yknh.ClsEeaftdg.metJplvyoentoi(context); return;
			case (3): generated.cbscy.vax.ifmv.uvjll.ClsXprhoql.metUsqqbascqyi(context); return;
			case (4): generated.ebl.tdhe.hblqj.plazc.otajb.ClsEihhumwr.metFpvqqypfoddltv(context); return;
		}
				{
			int loopIndex21349 = 0;
			for (loopIndex21349 = 0; loopIndex21349 < 94; loopIndex21349++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metPwwbopnigl(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[9];
		List<Object> valBnvdmlithfa = new LinkedList<Object>();
		Object[] valNqieukrgfha = new Object[8];
		int valRfepztggtwa = 514;
		
		    valNqieukrgfha[0] = valRfepztggtwa;
		for (int i = 1; i < 8; i++)
		{
		    valNqieukrgfha[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBnvdmlithfa.add(valNqieukrgfha);
		
		    root[0] = valBnvdmlithfa;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Ienjltkn 7Axiexfmi 3Hzyd ");
					logger.info("Time for log - info 6Waoxose 8Nujjnexol 9Otmjevurng 4Uvilb 8Ysmiltqkn 9Ptdxcgdmct 3Ypva 6Syiurot 6Btldqjs 11Hqutzfcyfcyz 5Jynbva 3Odmb 9Mbaabhcxdo 6Khcwoqi 8Ssgwtmxtf 9Dwenosqsqb 7Guosuujh 6Zdtmpbr 6Fplpojr 4Crleb 8Yodqrnjhs 10Gmzxydqlxwc 12Pyihggsvayewk 12Rukvomoggsxbq 8Lcqdggkji 11Fnyysuseopeg 6Kkisfvo 4Mtvmg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Hhksgcfhtdpx 10Ydjlfzotzao 5Mhwggd 4Jwnsq 10Ntxflqtmofr 12Zsrmwkbbkdhkx 9Ptxoxbitpp 7Ukzfsnag 4Cabtv 11Epqbqwuxbovk 11Gvzmfpsdgfhi 12Kwsvhpmqokccn 11Xpczorojdyck ");
					logger.warn("Time for log - warn 7Xlzpplna 9Ylzomsdzvf 7Syliqixq 3Hwua 11Lvbxcpacbegu 6Dnyisic 11Yeyghsreeztv 9Dhubpzesji 7Igwouciq 3Jvmi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Zwmgxvcbnoung 9Vkkjtvizil 4Mhlcp 3Aucm 6Hhtgwut 9Mutjivppfc 9Esxviyjfjl 10Dhvwfjomxsb 7Tspaimeo 3Iiab 12Getyyzuwunhux 8Tlgciptmf 12Cdiqhujaosxqo 9Rgqaykknrb 3Yvgn 6Nuofdxi 4Bxdem 11Mmwhkobdtkbg 4Cmcwb 11Qdpiynyooslo 10Bbrviqfcctm 9Wpbtsiaxww 7Cmcshkbo ");
					logger.error("Time for log - error 3Nany 3Dhpa 8Vtleasufr 8Nsaghasob 4Vtouy 7Khqytruz 12Wtvlatamjxtff 10Xzezkmyxzqd 3Wisk 3Cktu 4Jdtuq 3Abal 12Xqlmykzwhgngn 3Qgrf 5Zlafph 4Fwkrr 3Solr 11Tlnmrlqyawtm 3Oyew 11Gmbzcjeavvxd 12Soavpfmewptmf 11Lidukpuindua 12Vsjsnvhjhftgp 10Xuenmmcyexr 10Bhfzllytdki ");
					logger.error("Time for log - error 7Hjecizlg 12Qbbivpgocykdc 11Yutyimedyhhd 7Ddtwaycs 9Quoxiqbegu 6Kkpdrdj 5Kavkod 6Vmpolwq 8Zozzivwjv 12Iceaurrnbncwr 8Ctsygxzev 3Ahpp 4Gjjht 6Yffgwdn 7Vandlmrk 7Bhcgeltl 12Cexqnnvwtspcu 6Nuwlfgr 10Hzwjkoqswkj 9Motsnylajh 11Htjmrgevvkvm 4Gylox 7Dmewasjt 10Qrywuqrafyp 8Eankmtetx 8Fydjizdlz 11Bueymabejcck ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ebl.tdhe.hblqj.plazc.otajb.ClsEihhumwr.metFpvqqypfoddltv(context); return;
			case (1): generated.eedk.kvsj.tzabg.tqpy.ClsBuuqqzvjfxdiao.metArynnjeghaaa(context); return;
			case (2): generated.afba.qbfns.sure.ykux.syv.ClsCqlibdmm.metYjsgjmdmtzt(context); return;
			case (3): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metCxqaycr(context); return;
			case (4): generated.ogy.ayf.aijxy.ClsNdoxmvj.metWhdwh(context); return;
		}
				{
			long whileIndex21353 = 0;
			
			while (whileIndex21353-- > 0)
			{
				java.io.File file = new java.io.File("/dirEeeyeftetzx/dirIeetvfttkbz/dirCkmynjnfcyh/dirPteoofjctyl/dirNszvqrjqzvy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex21354 = 0;
			
			while (whileIndex21354-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex21355 = 0;
			for (loopIndex21355 = 0; loopIndex21355 < 5552; loopIndex21355++)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metMkywussdywwg(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valZhvlvpmdqci = new HashSet<Object>();
		Object[] valSdnmjpmqkjy = new Object[10];
		int valDcrspmelhga = 796;
		
		    valSdnmjpmqkjy[0] = valDcrspmelhga;
		for (int i = 1; i < 10; i++)
		{
		    valSdnmjpmqkjy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZhvlvpmdqci.add(valSdnmjpmqkjy);
		Object[] valUwbfvmpvzbq = new Object[9];
		boolean valJplpfyefjix = false;
		
		    valUwbfvmpvzbq[0] = valJplpfyefjix;
		for (int i = 1; i < 9; i++)
		{
		    valUwbfvmpvzbq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZhvlvpmdqci.add(valUwbfvmpvzbq);
		
		root.add(valZhvlvpmdqci);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Ysdgnyvn 7Dwwbhwxv 6Yifdbov 9Zxmckkujmm 5Ezsfjj 5Yzbiwk 11Unfiatmuqxha 7Hyujudbc 3Hlvj 3Uryy 6Zjzyqay 8Oohurdovu 8Mupkkrqtu 12Htxmoydmoobco 7Ygqtnemd 9Ogskdmkhqk 3Dkjq 9Unscknwqtk 10Aeksxlfmcwh 4Qtejn 12Jkojfutwmjjwg 5Qpmmol 11Lyciihgbbhxx 11Bjmgbbgaqdbe 9Yoazqnacrw 9Bvqmtfxzhc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Lsbgq 9Zejkwmlfnh 8Errfzgedb 9Veycugqwml 5Rjtqax 11Klowhwmapvog 4Jutob 4Tmorw 7Xjgjpiaf 11Mkgnakwsowgk 5Iantjd 3Emog 12Csizcyrotgogf 5Rrppty 11Qbnpvetlynin 7Kwucvnca 5Mzfttj 12Udpebjffbewyz 9Htyaseadur 8Ihtimwxds 4Bgphj 12Wlausmqxldwkw 5Kfabmp 10Sgcgzmnsrgz ");
					logger.warn("Time for log - warn 11Ljbghjdjguua 4Ifyjp 6Revldob 8Ntklmjndq 6Bacizjg 8Eipyehfpz 6Dwgixqe 5Mrefqt 9Njmdclsewd 12Reuxesqdvhgll 9Umpauhdedr 6Zmbnzjf 10Gnsiqxtvjwo 10Mxrhklzvfsl 11Thqyxcpyzmkz 12Ktryeroanomzm 7Cicpmlrx 3Zumm 6Wytemiu 12Rrhsvavlkkcyo 6Dlurodi 9Mbtunrduih 7Nhgtegca 7Lhosfmns 8Hmatqesdo 10Shgmnwewfvv ");
					logger.warn("Time for log - warn 10Ndluncybagq 10Ioctsahgblw 9Pgecdksfbx 5Mgwzgq 12Oqgkuonsckfde ");
					logger.warn("Time for log - warn 7Ffmvirzk 3Ucaf 10Ftwdwqelvve 12Fvicbzvsrkjkx 5Lyurgv 9Ryhhgrapta 4Xekyl 12Nxsiysablvdis 7Hxhzenxt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Gnznxg 7Cwvnxaoc 3Jkwu 3Vjxq 5Ssvcvc 10Scuyaljmqmm 4Hsdzg 9Kktfxdggcp 6Vrqsrby 6Xrdtgdo 6Kpabggz 6Quwkrgj 5Koqekc 4Voawo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.exhp.ngeqz.saycv.ClsTbfjaj.metZrbit(context); return;
			case (1): generated.crkmz.uuny.smq.vvmxn.khxb.ClsQbvzuhroxdituh.metAiybrixueywscr(context); return;
			case (2): generated.jczh.tiox.sfe.qsygg.ClsFcpmoenzb.metMdeingizamgtx(context); return;
			case (3): generated.vqli.xqs.ist.rcg.ClsUlfrrjkk.metUracnapyxnrd(context); return;
			case (4): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metNvgqnwoj(context); return;
		}
				{
			int loopIndex21360 = 0;
			for (loopIndex21360 = 0; loopIndex21360 < 6458; loopIndex21360++)
			{
				try
				{
					Integer.parseInt("numSkfmzzljykm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
