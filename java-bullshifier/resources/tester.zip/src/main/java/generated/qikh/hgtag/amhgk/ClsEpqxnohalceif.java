package generated.qikh.hgtag.amhgk;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsEpqxnohalceif
{
	 public static final int classId = 295;
	 static final Logger logger = LoggerFactory.getLogger(ClsEpqxnohalceif.class);

	public static void metUhwjekipowr(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valFcvodnzeuvp = new HashMap();
		Map<Object, Object> mapValIwgvvwdcoss = new HashMap();
		long mapValEvejpcpselo = 7804200934112449318L;
		
		String mapKeyQwwduyalkzn = "StrMtzktaxpmqa";
		
		mapValIwgvvwdcoss.put("mapValEvejpcpselo","mapKeyQwwduyalkzn" );
		
		Object[] mapKeyNwfvtlylzgc = new Object[4];
		long valOgmpzzteghm = 6412622035084050824L;
		
		    mapKeyNwfvtlylzgc[0] = valOgmpzzteghm;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyNwfvtlylzgc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valFcvodnzeuvp.put("mapValIwgvvwdcoss","mapKeyNwfvtlylzgc" );
		
		root.add(valFcvodnzeuvp);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Sdcjknivcl 7Hgvbtpst 10Jzksfmrdggg 12Qzrjvfaznfkkx 8Lsmuoairl 11Yghwnieioqjt 5Wrwsfh 5Sbhklp 3Zpqd 11Frdsfuldfcpn 9Yrfepjitqw 4Ndyua 10Hiiltpohoyp 11Yyurcbgwgdwm 9Zjfqfyisme ");
					logger.info("Time for log - info 3Pklp 9Tfkwaofsog 4Xqzqw 10Aakcexfwbcz 11Icgnqcpthbmv 5Jtepvd 4Ipvxe 9Nbjwzuznjf ");
					logger.info("Time for log - info 3Gkyc 12Uynfkcjpiddgw 12Lnzqxmthwcyta 9Hkasfuugbf 8Hvgzcfiuw 10Ifnaupgfrzr 5Hhtafk 9Kkkxfjymab 6Sgefxxk 11Lgwamvaasbse 5Rxrjdx 9Pkbtrtfkdb 5Unskof 9Rhgjysysuo 12Qmmpdhryxgqbt 8Badhzxwbm 8Iobgfwdrp 8Wsefohhod 11Xhdwufcytehd 7Coxtzkxh 9Njvjvfheij 7Cdzsjmpn 7Utncxzab 10Buhuakggmkp 7Fscpsefx 12Ybqdfrmykjexz 9Olhqllrcid ");
					logger.info("Time for log - info 12Isvqtanrqtflt 8Epapfkxwv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Qwznev 6Jymuvpf 8Rwopafqly 5Gghjop 12Zfmxiahobxdgb 7Awvykpeu 3Azjl 9Nejmilicjl 9Eixhpnwfci 6Bhagyiw 3Siru 11Orbqnceikkxa 5Esnmny 11Hklwunxahiqw 12Ruslvuogukeka 11Lsolfiovtoqd 5Lrevbt 6Umexelg 9Mmjaljghwe 9Zqgukwmhqv 12Katgauxkpycxb 7Ochlbjjw 3Mvwx 9Hwoysazrvf 12Dwstqschlpubw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Bctthozlsrzc 10Evnvvtolhda 6Dcoided 3Femk 3Iuvu 4Mmfoy 4Liwdw 12Mwhgltlagsocv 12Koxhbwjhqovjv 6Pcljiwb 4Rykkj 4Scsgj 7Bwjplkfw 7Xnzkltqy 5Ixizsb 3Plca 12Hcdvqwhdszfaa 5Jlpnnn 12Exxpfjoptkanf ");
					logger.error("Time for log - error 11Acbvomradffj 8Uqyfxayjq 9Pfsidfvdck 12Wzkiaycyhcvvk 5Qkcoad 12Xycjmciswodik 6Jsbmwdu 5Efbtwn 6Jrvrjhj 5Hvpksp 11Rwzgghqdhqcz 7Vxuinggs 5Zndtqu 5Rjyqno 11Uyxiqcmxjxgv 12Xhhswottgcxus ");
					logger.error("Time for log - error 7Abrwslyx 12Uqtlyydcbpswx 4Haikl 4Elpzn 7Rnsnxplt 11Kjuieeizfvtr 12Ilthjtmggbnxz 3Iehd 3Qsbr 5Vfqsky 9Qfpgcpkskr 8Txepodsie 4Hgkhu 3Fzid 7Wtvrpnkn 6Nnhpnlt 5Ufgiaz 12Nzcszgfmzqndm 7Aecmgczh 7Pyvdafei ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lkx.jvoz.ClsUgthzii.metEemhoq(context); return;
			case (1): generated.gpnn.qul.pdexl.hxjph.zmndq.ClsIcvyndtrplxfkf.metUexjnwdywcfac(context); return;
			case (2): generated.flvo.tuwfx.wlpxx.jysnd.tuk.ClsFuuvt.metYllionx(context); return;
			case (3): generated.tvv.ioy.ClsEqfmidfypp.metQplbcv(context); return;
			case (4): generated.mrz.embg.gydr.vls.fvllv.ClsYrxhq.metEadyyddxiay(context); return;
		}
				{
			long whileIndex25035 = 0;
			
			while (whileIndex25035-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metBjfkpwuutlibc(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValIcxeerwalzo = new LinkedList<Object>();
		Set<Object> valVlisvwledsp = new HashSet<Object>();
		boolean valUtcngypbhnq = true;
		
		valVlisvwledsp.add(valUtcngypbhnq);
		
		mapValIcxeerwalzo.add(valVlisvwledsp);
		
		Map<Object, Object> mapKeyZbqxazizfhb = new HashMap();
		Object[] mapValMqbmzwrtbjp = new Object[5];
		boolean valRctgcjoeqlx = true;
		
		    mapValMqbmzwrtbjp[0] = valRctgcjoeqlx;
		for (int i = 1; i < 5; i++)
		{
		    mapValMqbmzwrtbjp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyXkecahliunu = new HashSet<Object>();
		String valSczdzxeeptt = "StrLtohwnrielq";
		
		mapKeyXkecahliunu.add(valSczdzxeeptt);
		
		mapKeyZbqxazizfhb.put("mapValMqbmzwrtbjp","mapKeyXkecahliunu" );
		
		root.put("mapValIcxeerwalzo","mapKeyZbqxazizfhb" );
		Object[] mapValJgjqybxngis = new Object[4];
		Object[] valLhewmosjqzc = new Object[4];
		long valKzhwmyodqlp = -4173084523825387587L;
		
		    valLhewmosjqzc[0] = valKzhwmyodqlp;
		for (int i = 1; i < 4; i++)
		{
		    valLhewmosjqzc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValJgjqybxngis[0] = valLhewmosjqzc;
		for (int i = 1; i < 4; i++)
		{
		    mapValJgjqybxngis[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyCmbbphqlvpx = new HashSet<Object>();
		Map<Object, Object> valAvyshbyrsqh = new HashMap();
		String mapValJietkogbhhu = "StrZorhmsiuonj";
		
		boolean mapKeyGpjtqjpufsw = false;
		
		valAvyshbyrsqh.put("mapValJietkogbhhu","mapKeyGpjtqjpufsw" );
		long mapValRmahseptfem = -2395014493910053873L;
		
		boolean mapKeyUvxqbferyln = true;
		
		valAvyshbyrsqh.put("mapValRmahseptfem","mapKeyUvxqbferyln" );
		
		mapKeyCmbbphqlvpx.add(valAvyshbyrsqh);
		Object[] valTyqfqyzlftx = new Object[4];
		String valFhpcxepthiv = "StrBouhbhaearh";
		
		    valTyqfqyzlftx[0] = valFhpcxepthiv;
		for (int i = 1; i < 4; i++)
		{
		    valTyqfqyzlftx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyCmbbphqlvpx.add(valTyqfqyzlftx);
		
		root.put("mapValJgjqybxngis","mapKeyCmbbphqlvpx" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Eeguhobj 12Qcpsdrdtqgwgn 9Suotogjdnn 10Bybjijvocrd 3Kanw 9Vxlusdxbgn 12Yoblhikbptcus 11Hfqxiuyufghv 4Plisb 3Ulwg ");
					logger.info("Time for log - info 4Vnjia 10Mqbtjuzrzzj 6Wdfxbgg 7Tydmeabd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Envpkpx 7Tytaystf 12Krijgsgzekhah 3Tbsv 12Xsfwpaemqwpor 11Gmealhzevxvi 3Lfll 12Toyqxmjekpxkx 10Teuaegqrnhx 7Uoayhujl 5Ylgfoh 10Rthjlqojpdn 3Syhp 5Dxdyfn ");
					logger.warn("Time for log - warn 3Trnw 11Nfosekfuxjiv 6Joguqhv 10Tmzctmowkwf 3Nhrt 12Retatapgxehuj 3Spsc 9Alxflwoxth 12Uoazryizbuwzd 4Heqjk 11Cmgwpnqzyope ");
					logger.warn("Time for log - warn 11Wnlpmvpxgksm 10Olktmxrflpn ");
					logger.warn("Time for log - warn 10Mqgqcdoyvew 11Pnwvxnjftwqw 3Czmz 8Mumyenkip 12Xgvaalyjhasot 3Dech 11Mejekqlmthuf 7Hqwakuqy 8Jxohpovjk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kcrh.cmo.yws.ClsBlekldezyl.metLtlpxelwrxf(context); return;
			case (1): generated.xqub.fxwha.ClsHlclqblgzonjn.metQwtvbhpti(context); return;
			case (2): generated.dyv.vxo.ClsWrwpfswr.metBamfflypcsi(context); return;
			case (3): generated.dxq.xrcc.nnuf.jgcjn.ClsUxqzuz.metMerkfgxadscigo(context); return;
			case (4): generated.uxbqo.pcskv.udre.ClsKillneqmm.metIokufnwdnpfcxt(context); return;
		}
				{
			long whileIndex25040 = 0;
			
			while (whileIndex25040-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
