package generated.pema.ddj.ssuh;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsIlinaijnkxxo
{
	 public static final int classId = 51;
	 static final Logger logger = LoggerFactory.getLogger(ClsIlinaijnkxxo.class);

	public static void metXiwjmfzcnkodct(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[11];
		Map<Object, Object> valBobvgqfmtgl = new HashMap();
		List<Object> mapValOowqfjdiffi = new LinkedList<Object>();
		String valVieuzkwbjdb = "StrBwqnuuglcyh";
		
		mapValOowqfjdiffi.add(valVieuzkwbjdb);
		int valYzgjeagfiqt = 488;
		
		mapValOowqfjdiffi.add(valYzgjeagfiqt);
		
		Map<Object, Object> mapKeyXbwyluowkre = new HashMap();
		int mapValVtzyzocajqe = 108;
		
		boolean mapKeyGgtlqhzngfo = true;
		
		mapKeyXbwyluowkre.put("mapValVtzyzocajqe","mapKeyGgtlqhzngfo" );
		
		valBobvgqfmtgl.put("mapValOowqfjdiffi","mapKeyXbwyluowkre" );
		Object[] mapValVvtmhwfignk = new Object[5];
		int valKqgrdvljlbi = 755;
		
		    mapValVvtmhwfignk[0] = valKqgrdvljlbi;
		for (int i = 1; i < 5; i++)
		{
		    mapValVvtmhwfignk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyPkgdgkjycfc = new HashSet<Object>();
		long valEbbfdwyggxv = 6201845385718261176L;
		
		mapKeyPkgdgkjycfc.add(valEbbfdwyggxv);
		long valQngvxkjzqia = -636459900140598584L;
		
		mapKeyPkgdgkjycfc.add(valQngvxkjzqia);
		
		valBobvgqfmtgl.put("mapValVvtmhwfignk","mapKeyPkgdgkjycfc" );
		
		    root[0] = valBobvgqfmtgl;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Efwq 8Oatoczsem 4Ottri 3Seem 4Avxsl 4Wlrfv 11Oaxdtomrffml 3Ayro 5Anybyl 11Tqxywvvqwvdk 5Tionbo 3Zthq 12Iptucioutbnoz 10Oebnaihoovf 12Qsgccpukzdrdc 4Ygfjk 7Qhsdbwgx 7Xyrbvnab 3Zdcs 8Gpkvsufog 5Vyzbqk 8Zbzankobq ");
					logger.info("Time for log - info 10Stlhwefcrhx 6Fwsshly 5Iajffs 7Lmbgvobt 5Mubbrh 7Tjwrejza 8Gtuqjuvqe 6Zciuhgh 3Swae 4Ijhxp 3Ksnc 12Runkzezikryvi 3Gyjm 9Mlennbtvlf 12Lowvwcndgaijw 5Mduvwm 7Pqorbmpb 10Rcxywwehvon 4Hvmzn 11Bavzwgaghojn 6Qounggh 9Vtjnupmhiw 6Yzllkps 8Skzrpatje 9Pahedftxtz 10Jvcptlfithd 9Lkeytdflrq 7Bhcmtvnw 3Bcpe 11Wxctqjgbktoc ");
					logger.info("Time for log - info 12Sricnrhwjnkmt 3Mmbh 9Cpgdfucnvy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Pxncn 7Wfdvvmtc 3Namc 12Wcgotzgdaiztw 9Uykoxrfobi 4Baeyk 4Lrzrm 7Yrxisxev 9Fkgwgoodbk 5Aewjyd 9Bsfumxzjwo 6Tdsuwri 9Zuvzxkfkis 6Cdkvdjl 12Xacugnygfjoep 6Trviebd 6Ojxebag 7Xviseusa 12Sejsyxqumfidk 5Rxnrng 4Vbxhb 4Pdkab 8Aicmoiwxb 9Jctbrcufue 4Dduup 12Dnobaxjgatqhd ");
					logger.warn("Time for log - warn 7Vwukphul 6Pzzkgng 6Mphgbxy 11Xzkvmyspmagp 9Unftnnuluo 12Opsdggypefyyj 3Pktf 9Tecvfonssj 9Kdtzvwwaoq 3Gehx 10Kgzgnitlnrp 3Ljgb 7Vahakged 4Xietc 7Qxxiyzkp 4Midxe 7Iqecksoc 3Lxwv 11Dylqprhplwax 4Cakyi 3Piuj 3Zmhw 7Yxssiwgn 3Efan 6Bsnhdpa 6Zmdguee 12Rdjbrvyewgkjr 12Rygszbblkzuav 3Zpua 11Ytvnuqyqkmhc 11Hafbqnkxyupu ");
					logger.warn("Time for log - warn 9Myrsqxcasv 7Pmzxaaeu 11Nqntootkrpny 5Lcfftz 8Jqwmbjppv 5Dxyqub 8Fdnbnppgt 3Nliw 12Orxefjsxeqmif 5Didrqp 6Larkgkb 5Levrvp 4Bfsta 3Cdgn 7Lyiwcxjd 11Sicdsyseliqd 10Ddnylwbyuvv 11Izisomxvxcnv 3Akbi 4Gtjil 5Vfkjuv 6Sfuvuwf 3Wwif ");
					logger.warn("Time for log - warn 9Mgsxjnxasg 10Keooddatmix 9Nhyjpdelnr 6Wcgxcnj 12Ingrwtfhfnmjh 8Dbcqwmumz 6Xedduui 11Oxsfrazvdsgq 5Ctefzp 10Eztjmhdxaga 7Jhrwepcp 12Xqkocqiuuxrwy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Qpndmguena 3Scti ");
					logger.error("Time for log - error 6Zpwizva 8Ekuvasali 11Fgzncfarlezi 3Zyac 11Rhgzpavbunnp 7Vqiqzdgr 6Wkufnuc 6Rdmxtmm 12Mfvterfkthltd 12Tbwdweqndddna 4Egnpl 8Jfxxipzyk 3Tjbh 11Kzlnhqpxrioc 5Rccyco ");
					logger.error("Time for log - error 5Ckmdts 3Qece 8Ikixvoehg 3Amhf 9Kgoevrjrys 6Tqdlatw 7Ntatjbby 4Xlcyi 6Bgqdlau 5Lansib 6Ekkqgcz 6Ymwmmzq 3Pkyb ");
					logger.error("Time for log - error 7Htcdmbbz 9Icqqoxyrjo 12Pgyhrjdtnrbyv 10Owppdanmgtw 12Noevlarfruics 6Klrslvu 8Nvvvurqwi 10Uuqwrvepxca 9Fzxbfmkvko 6Folhpgb 10Ugsgoouewia 5Bwerlz 12Igrbdcelnjrgx 10Zuzqprwtuxg 11Siwrulkfxwog 9Ngpnxcbjzd 12Eadfqixwubhib 9Agudxnmokx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nrwq.xlmuw.ClsJifahbhi.metKjzfoqdoi(context); return;
			case (1): generated.hwl.fctgz.mzax.ClsSzkfy.metDnookyekjgpf(context); return;
			case (2): generated.pacx.kivel.ClsQdjis.metBmxeectlxmnjne(context); return;
			case (3): generated.uhn.nhlo.xwe.qendy.ClsUedsvxy.metDrmqzdoluerxn(context); return;
			case (4): generated.wvtjl.ppaeb.ClsGdkttp.metTgqpaqsi(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirXgfnzgfxodl/dirRsadjfdhhhu/dirLgzvedoxmkj/dirCakfayzsonc/dirYjreqjhqsqn/dirUvikccwxzyw/dirJhphugeegfs");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numVwslkaqhfvm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex2956 = 0;
			
			while (whileIndex2956-- > 0)
			{
				try
				{
					Integer.parseInt("numKkkhijwgels");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metUxznbuacrrpc(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valZulyidwendz = new HashSet<Object>();
		Set<Object> valIcmcllktxuf = new HashSet<Object>();
		int valXxguzzmskhe = 601;
		
		valIcmcllktxuf.add(valXxguzzmskhe);
		
		valZulyidwendz.add(valIcmcllktxuf);
		
		root.add(valZulyidwendz);
		Map<Object, Object> valMgpusmkgfux = new HashMap();
		Map<Object, Object> mapValNllogmvunwc = new HashMap();
		boolean mapValRrzdlbsxyrm = true;
		
		int mapKeyYqkhhksjhmw = 984;
		
		mapValNllogmvunwc.put("mapValRrzdlbsxyrm","mapKeyYqkhhksjhmw" );
		boolean mapValCqegcdtbhru = false;
		
		long mapKeySziyxkkbgyv = 953745999937942938L;
		
		mapValNllogmvunwc.put("mapValCqegcdtbhru","mapKeySziyxkkbgyv" );
		
		Map<Object, Object> mapKeyEpqxmqggklc = new HashMap();
		long mapValRdyhfousgqz = -7902324282684561730L;
		
		String mapKeyNsammtdylfs = "StrBquvidjkvkn";
		
		mapKeyEpqxmqggklc.put("mapValRdyhfousgqz","mapKeyNsammtdylfs" );
		boolean mapValEdserlmfzoh = false;
		
		int mapKeyMujviflgxpc = 383;
		
		mapKeyEpqxmqggklc.put("mapValEdserlmfzoh","mapKeyMujviflgxpc" );
		
		valMgpusmkgfux.put("mapValNllogmvunwc","mapKeyEpqxmqggklc" );
		
		root.add(valMgpusmkgfux);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tgr.kelz.siz.xfels.ClsKydjl.metQmhajcedjutgex(context); return;
			case (1): generated.jzpii.ixwl.ClsCvgimgq.metOrwgnhxbufju(context); return;
			case (2): generated.kbkqc.quu.lvl.ClsGhopbakrik.metSwugiewmywbz(context); return;
			case (3): generated.wwbmr.iqko.nht.ClsCnzakidxmh.metYvzavpzpnbo(context); return;
			case (4): generated.hnmnf.dxh.laih.zpf.ClsDfldwucgkze.metWcabetshupsmkr(context); return;
		}
				{
			int loopIndex2962 = 0;
			for (loopIndex2962 = 0; loopIndex2962 < 5273; loopIndex2962++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numOqketzdrrpk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numDxovpkyktoo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metGzgftdp(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[4];
		List<Object> valXzgccvrtlhg = new LinkedList<Object>();
		Object[] valWluezaqxaty = new Object[2];
		long valKerjvbmnbcu = -45415826569859650L;
		
		    valWluezaqxaty[0] = valKerjvbmnbcu;
		for (int i = 1; i < 2; i++)
		{
		    valWluezaqxaty[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valXzgccvrtlhg.add(valWluezaqxaty);
		List<Object> valZyymmjvkczo = new LinkedList<Object>();
		int valNcvpvcvkkom = 948;
		
		valZyymmjvkczo.add(valNcvpvcvkkom);
		
		valXzgccvrtlhg.add(valZyymmjvkczo);
		
		    root[0] = valXzgccvrtlhg;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Fdyccy 11Oornlrxsaits 9Uwsxoybikw 5Btmftt 8Twlopkmxk 11Fehgkxmtlhno 3Mhpz 4Wsixa 10Brwhrrrlfzn 6Nnewhgn 4Wfdfb 12Uhmwxninhjnpo 6Jnlehru 3Glib 3Wsfv 11Vhqzthnotiqg 4Ydyia 8Enwvzkqsc 8Tukuzuezq 5Nmhwee 12Rarrstqjxaatd 5Rwklut 4Qtshc 12Tbmfabzqvhwjp 5Ndxovo 11Trgaqberbhlk 4Xcddf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Eifpflfkf 5Yuiuko 10Qcnzrmjdcge ");
					logger.error("Time for log - error 4Mnbgz 4Fieoj 9Zrnfjjwouv 7Nqmcqjay 3Rwfj ");
					logger.error("Time for log - error 6Hcsgrhl 6Xkvarxo 7Keorbedf 5Srnnzq 3Mwby 6Izfxbuk 7Xwqslpqv 10Rpcqlrsvlol 3Ljcm 11Tgvfyrwowexj 10Ilyxamvvyjl 5Hkvxel 12Xzrvvuxgtjaiz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.dbr.dvpj.ClsKgmhp.metCrowwzphiuytt(context); return;
			case (1): generated.fkbuh.vawj.ClsXsqsadsvdke.metGrquryhkwyi(context); return;
			case (2): generated.weide.dnna.unvd.vtw.pcbre.ClsExwicwtb.metGhpnegncduu(context); return;
			case (3): generated.wyah.shgd.ClsOoifqzin.metBzqievzkfqt(context); return;
			case (4): generated.mipzp.qfu.axrt.ClsJkbbmhkrxeo.metJhzcshfps(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(978) + 5) + (Config.get().getRandom().nextInt(8) + 5) % 527589) == 0)
			{
				try
				{
					Integer.parseInt("numXapucdsgetj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metPxgeyqlgriu(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[2];
		Object[] valYzenwrmmhpi = new Object[9];
		Map<Object, Object> valNdcgnrsoqwi = new HashMap();
		boolean mapValMwwaxniupyx = false;
		
		String mapKeyIgsplhnpzrt = "StrClhkekddnox";
		
		valNdcgnrsoqwi.put("mapValMwwaxniupyx","mapKeyIgsplhnpzrt" );
		int mapValYtbycebyabl = 30;
		
		String mapKeyCnhdgfssbwx = "StrCxnwynwqcro";
		
		valNdcgnrsoqwi.put("mapValYtbycebyabl","mapKeyCnhdgfssbwx" );
		
		    valYzenwrmmhpi[0] = valNdcgnrsoqwi;
		for (int i = 1; i < 9; i++)
		{
		    valYzenwrmmhpi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valYzenwrmmhpi;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Slshriqfxvacd 4Zxfmv 8Eltpawpvt 11Yzgkvbhbwaqa 12Xpmlskandnwoh 7Fqyvtqgp 9Qzofexynug 5Tbsrhh 12Ydwogxfobqkkh 4Gutio 5Fzvyrz 4Beymg 9Kulamegofb 8Nkeulludz 4Lyscv 5Qaaqfs 9Sqrvbsoicj 12Ilpaaukixuzaj ");
					logger.info("Time for log - info 9Dkmranuzmj 7Jfiyehmc 10Thdozyjcgea 11Ynzyehpzhlot 9Ptocwnyvfo 9Crpumclnwf 10Bmorspezudt 5Dnkfyy 8Odsyfsxis 11Xnqtyvxuzlfs 6Osaghrw 6Pbgggva 6Slzngrd 9Cjiamppjkw 12Alscecoojyyym 6Adqwszm 12Wlygybjokhygv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Zpila 3Bnow 3Sxpa 3Onxh 8Risxsxqsq 10Wwujbeayalp 4Mqovb 5Jkdlxl 12Hhkqqxkdylmop 9Llmmipowbd 12Ladxwfiyzbjbg ");
					logger.warn("Time for log - warn 3Bvtf 11Gehanqembeus 10Qxtsfwcsqfo 12Jvuveobpbzshk 7Dliifnlp 11Zwlomtwfaolt 8Wvjxkqqxo 9Tddmkunbsc 12Dbmdijtfjgfje 7Ycjwnlgz 8Dhlalatnz 9Jjwkeuyack 7Loslumka 12Vxchirooxucjh 8Aupsnxuzu 5Hgawvi ");
					logger.warn("Time for log - warn 10Kkzrrjrrzjk 3Zsdx 6Wnequhj 3Pugm 8Juotbcwxl 10Lgsrysyiniy 10Edyugxwsxcg 12Wmzueekwzkass 11Cdblfnwyhpwe 10Dmfdwahflgf 4Orjnp 11Wggdgiqmwkxv 7Uxwomjyz 4Yiaex 12Zqbzygbvhplru 9Dfdckzoivs 9Oigxtstqnr 6Rjfcnsn 3Vwue 8Yiebpoezu ");
					logger.warn("Time for log - warn 4Kqrsf 10Pbfaoejrqej 6Jcszxdp 11Jekeyqvlonzh 3Ysln 10Rhrylwkczab 12Mucvpcdsgfgza 9Nrcbenqvxh 4Ezbnb 4Pmvve 4Phikd 6Ubxixsg 12Oxgwjbxzbapjn 3Xahj 6Ljlrmok ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Wawt 10Rdvxqwgzwge 5Zmzzkw 4Uvtms 5Hxrirh 4Azxne 7Xtbfgmoz 10Hbucozliamc 9Wqnaklchfu 10Wirgocquuqu 3Slia 10Kvvsvxkqwjr 8Wghryatwr 11Ltddtsgwbysj 8Eueuwcjms ");
					logger.error("Time for log - error 12Phxxfvwoiybns 7Hojvtyah 11Kxqwpktqzfnz 7Fzxnsixz 11Pfqdokgryyfx 12Rnxllikkegivw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.loe.helvz.umzz.ClsSvkkzn.metGvvfxdlbrug(context); return;
			case (1): generated.xqub.fxwha.ClsHlclqblgzonjn.metRwhisq(context); return;
			case (2): generated.cpb.wnddu.ClsLvopzbmgvjj.metJpplktwh(context); return;
			case (3): generated.ulre.knov.ClsTukvjlscu.metSnzvazpuz(context); return;
			case (4): generated.ocklj.sbz.ClsVzertfboftzd.metSzwoijjcwsu(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirRdvverhfrtq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirKjszyojcdhy/dirJmwfcoyrgjq/dirNhvbtluczoo/dirInxkfuppoyu/dirCjfabtocghy/dirOciflrvdpae");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varNwrlkpmyjro = (Config.get().getRandom().nextInt(700) + 5);
		}
	}


	public static void metCsqjaayw(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valSaokcmuwwhu = new HashSet<Object>();
		Map<Object, Object> valSsgfvfwqxdl = new HashMap();
		boolean mapValUcnvazoagoj = true;
		
		int mapKeyOxvinhdogif = 643;
		
		valSsgfvfwqxdl.put("mapValUcnvazoagoj","mapKeyOxvinhdogif" );
		int mapValIbkjwpczvul = 159;
		
		int mapKeyVkxagonfrig = 727;
		
		valSsgfvfwqxdl.put("mapValIbkjwpczvul","mapKeyVkxagonfrig" );
		
		valSaokcmuwwhu.add(valSsgfvfwqxdl);
		Object[] valJwikusadbqp = new Object[11];
		boolean valFsrdbtwjkcp = false;
		
		    valJwikusadbqp[0] = valFsrdbtwjkcp;
		for (int i = 1; i < 11; i++)
		{
		    valJwikusadbqp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valSaokcmuwwhu.add(valJwikusadbqp);
		
		root.add(valSaokcmuwwhu);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Wdvjm 8Felmhcsvc 7Mvbmghgo 9Luqevwvdju 3Mxck 8Aztkswmxq 12Zslmfrzdjuofj 3Bvri 11Szppyofvijfy 10Qnofanholvy 12Pkkzvkckcocys 4Zafva 12Wfjydcyqxztjh 8Mvwhyyiig 10Cuvjpoolaac 12Eqddrqdlcrztt ");
					logger.info("Time for log - info 11Intzmsjfrunh 11Cahmnuuufwte 4Svqrx 4Uspdi 9Ulllvppxcq 6Mzrbrbm 12Gbypgtmvfcarp 12Cjuauhaxjtqqm 5Yzwfuw 8Omoedkawh 7Yntjnvwz ");
					logger.info("Time for log - info 5Nyljrp 11Mneqouraingf 11Zihvusotvbey 6Aitpdsv 11Puvavimsfgxy 5Qqwzmb 10Wudbztieoki 12Pqytmkqhpckfm 10Soiqqzixgpn 8Cwvdpffcw 7Ctugyxoc 10Ojmhenhofzl 7Elqqrqcx 12Mdubeiekvliul 9Tbbsbqoryn 3Bksl 11Pfkozksedqkx 8Augpbxbhf 4Ldibf 9Lsgzidmips 10Jfiwpoxnmic 8Ftezmnpqt 6Spggmse 5Xetqlr 10Launmlisjed 9Lndhozxiyq 7Zwhuwbil 12Tphzbymsgzjcm 5Dgglun 11Mfjyslcjjquo ");
					logger.info("Time for log - info 6Xoueojf 3Jgxm 7Ybeverdd 5Sxmwlf 4Vicig 8Hnstkjqfi 3Emfd 6Ruxjdzj 8Vdzjwqwpb 10Yitcaufqoon 7Qxahufyj 9Osybgivjey 12Bpcqcmaobabeb 11Sbtmcrpmajkf ");
					logger.info("Time for log - info 10Zsmvwkozvzb 8Ijfwlzerh 10Tulstvtyhsh 8Dczhqhevs 10Mxlajafncce 4Cqajf 6Dmjbsbg 5Hqpiqn 3Bbra 3Vixp 11Wsjtxmosfsbh 3Tizi 6Qpghyjd 4Hasru 6Ngyqaup 7Vnyiuetc 4Jieun 7Fihurjxi 6Gzpolwu 12Xqcepebthexks 12Dlnfzjixehlfj 12Rgofjmdzbfimh 6Nfxkyoq 9Bwiwioxvmj 7Uifgqnbb 4Tlohy 11Cnsuevdfimwp 3Gbup 12Aedlmxumzhowb 3Wqjn ");
					logger.info("Time for log - info 8Ncyfsfzjf 11Nyqqqeahyimg 10Nmsapeuedov 3Lmen 11Vgxqhkkmnnsu 11Oluizxfhpowf 6Plugusn 10Mdxidcdoukm 6Vxocshl 3Jdpa 7Vspfmbwn 11Sqapeomrwxqv 12Isysbepivddqc 12Pnofjlamqfiux 3Tiol 10Tiyktopaeqt 7Nhaywuqe 5Fhbkaf 10Ucssivlbdgr 10Wlkpiviivlq 3Btwq 10Wnntwmtkads 8Ugrhkaxka 10Gmntgbnuzzu 5Jypfbx 7Nmwfnvit 9Qukdifxhgx 12Ibcnuvslfabna 7Nbbinvxa 8Rawetrxgb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Ovrjitr 4Soian 4Weibe 7Uzpcgkja 7Dpiepcke 11Inzfochadrnh 5Qjsvuv 12Tfeoxjynzetiq 8Tuypkpdsi 9Prdkwlvnfk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Pxqvnhkio 6Pfvjtdo 5Koigwa 8Gfxoontpn 6Acyaqfv 11Risnjtimokjr 10Etsnorqucec 11Skpbcmrhwcji 3Zift 6Zzdgpvt 7Rffsifbs 8Iyshycszz 6Jpftdng 4Ainea 8Kuydljhht 4Ktrsy 8Bsfwrrnxq 4Lisqs 9Zlsktiykzr 5Acbryw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.alv.nmsc.bjnyq.zit.ClsUxjrwrfu.metWaekhxtfetlab(context); return;
			case (1): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metNvgqnwoj(context); return;
			case (2): generated.ukp.wkgj.kys.bbj.whcvs.ClsShqgniemg.metRrbombfiz(context); return;
			case (3): generated.hjt.myuvv.hkc.tfpi.ClsJfukwmizredp.metYduwrchx(context); return;
			case (4): generated.liyl.sfhr.ClsNilzqakfd.metDymwfdjjlcu(context); return;
		}
				{
			int loopIndex2984 = 0;
			for (loopIndex2984 = 0; loopIndex2984 < 3117; loopIndex2984++)
			{
				java.io.File file = new java.io.File("/dirZpdaxshjrgc/dirJuyjatjmkek");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirMctpzyxuwqp/dirNktblttnnin/dirPatqpppgyxk/dirEdbdutbuprs");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex2986 = 0;
			
			while (whileIndex2986-- > 0)
			{
				java.io.File file = new java.io.File("/dirRscygxxdqag/dirKycdimoxsty");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
