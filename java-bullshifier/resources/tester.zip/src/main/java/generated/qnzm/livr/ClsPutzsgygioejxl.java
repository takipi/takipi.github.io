package generated.qnzm.livr;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsPutzsgygioejxl
{
	 public static final int classId = 500;
	 static final Logger logger = LoggerFactory.getLogger(ClsPutzsgygioejxl.class);

	public static void metMebbiihjouloja(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valPvnouzrsssk = new LinkedList<Object>();
		List<Object> valXacndpilink = new LinkedList<Object>();
		int valEdgmbovpiby = 89;
		
		valXacndpilink.add(valEdgmbovpiby);
		
		valPvnouzrsssk.add(valXacndpilink);
		
		root.add(valPvnouzrsssk);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Utkhyuwvxlwhk 4Pazxe 7Pwexitub 4Drhox 8Rdabskovg 6Voxxlzr 11Jnpflljgamcs 9Pkuuskyogb 7Okpysroa 12Tificsqbsxnym 10Kxekdfgspbw 4Rdwdv 10Hpuybvcnprh 12Xywpugbxellpa 10Zumtpxxrdvy 6Tolfnfo 3Xgjs ");
					logger.info("Time for log - info 6Gigtkcn 4Rvska 7Eyqjmkaa 3Ncaz 12Jtmnnjswclcfp 11Ooiwcxwrjwii 7Fildriav 11Qxedsimvmify 7Cfjbkmzw 8Povtoeatl 5Tknthy 7Zkfthiyf 9Ydavisdadh 4Cimtn 12Hfzabwsncpgxo 11Ddpuvhyskyoo 7Ntfmgdhd 11Uagpnhcfzzoj 12Ctdvxayaohabd 9Vhpagkxvhp 10Zzbhpapkvns ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Bmmu 8Voljnjnbb 4Bfrok 12Pozomobldqilu 11Bbezdytfwimp 5Racpai 4Kztfb 10Mayendhgbjl 3Slcq 11Yvpjtoghxucu 7Kqmahmsl 4Enohw 6Ipzzjrj 8Nhquhpqrr 5Hlpckb 11Okcjffiupcgf 11Bjotqpnnuxlp 7Nhxbzrem ");
					logger.error("Time for log - error 8Sfkcknfqo 9Zkmuuzldxb 6Ybduysh 11Najnzvcppkwx 8Urvtjidow 3Yerf 11Vtifvbeogdxp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cbscy.vax.ifmv.uvjll.ClsXprhoql.metUsqqbascqyi(context); return;
			case (1): generated.hbd.gdsbg.cmv.qvo.ClsZtgxvnjsll.metQvkbrrhkdtwqhx(context); return;
			case (2): generated.qnzm.livr.ClsPutzsgygioejxl.metEdvcgkuyiw(context); return;
			case (3): generated.mipzp.qfu.axrt.ClsJkbbmhkrxeo.metJhzcshfps(context); return;
			case (4): generated.uqvko.bvdt.pbjo.abize.rep.ClsVzpniirg.metEfcladeulohz(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(804) + 1) * (6292) % 978461) == 0)
			{
				java.io.File file = new java.io.File("/dirYrktjohcbgd/dirDggknaaqsrd/dirNjoskqflfat/dirXjekoiljlfp/dirKnrwyxmavea");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(843) + 9) % 649852) == 0)
			{
				try
				{
					Integer.parseInt("numNvayvwrlndr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varKkcuzbzxgda = (5373);
		}
	}


	public static void metJtxtxkipo(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[7];
		Set<Object> valNpobmjkvkzx = new HashSet<Object>();
		Object[] valErwkposqqyz = new Object[6];
		long valMptpgavgswd = -232051351951899989L;
		
		    valErwkposqqyz[0] = valMptpgavgswd;
		for (int i = 1; i < 6; i++)
		{
		    valErwkposqqyz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valNpobmjkvkzx.add(valErwkposqqyz);
		List<Object> valVvgfndnhtfz = new LinkedList<Object>();
		long valUtmnxoeuqav = 7484461961231773072L;
		
		valVvgfndnhtfz.add(valUtmnxoeuqav);
		int valEzbziyrutgt = 677;
		
		valVvgfndnhtfz.add(valEzbziyrutgt);
		
		valNpobmjkvkzx.add(valVvgfndnhtfz);
		
		    root[0] = valNpobmjkvkzx;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Fpblidl 10Jcjqdxhovre ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Uvxfs 11Lqlladneeurf 6Cwhzdub 6Zvyciec 8Wcguccian 7Pqgzzoju 11Gughbjizkfki 5Kcereg 11Mmumqecskbvn 12Ertqoudnbmtif 11Xhzzgsablhkz 9Gskzkpassi 7Sddyvaap 10Xaywhdkfitb 5Ufyvey 4Eglpc 4Cdrsv 6Bycnofe 12Dajpusevxmzih 9Lszozwiqbt 6Cuhsarb 4Htrsw 11Ubwklqchtlmd 12Cpmgnlhqzsvvc 4Xiuaj 9Ebmuyfrxnm 8Phltipjai 5Nirhne ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.exa.yssf.ClsHuxmu.metLxxkvqloasqtd(context); return;
			case (1): generated.lkx.jvoz.ClsUgthzii.metEemhoq(context); return;
			case (2): generated.mccr.hhayo.cgyp.gjrvj.ClsTjitk.metJjldlhrudpysva(context); return;
			case (3): generated.rorl.wuo.lqgdf.ClsUltodfmiuq.metZqbkch(context); return;
			case (4): generated.vtvwz.yobg.lldg.auey.xwd.ClsDdnvjde.metHxwjgboi(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirFrdjiletwhq/dirYredrgsxceg/dirOapjbcfzjml/dirCziiifxnztr/dirYctznipktjj/dirJzqkdauqpvm/dirJvwparycugx/dirGnbgogztxjt");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirKgxefzgiytc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metRdflajddlt(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valYxlkbmbqgvj = new HashSet<Object>();
		Object[] valSooinoleudn = new Object[11];
		int valRiehpseoswb = 124;
		
		    valSooinoleudn[0] = valRiehpseoswb;
		for (int i = 1; i < 11; i++)
		{
		    valSooinoleudn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYxlkbmbqgvj.add(valSooinoleudn);
		
		root.add(valYxlkbmbqgvj);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Ypjtybjkxuetz 7Lzrgvvgq 3Jthj 7Zrkpfhrf 12Epbbeufzulgsl 7Dautznfx 7Uscfurrl 3Gezu 5Qdviwa 4Gledu 4Ypvqz 3Vari 5Pejgyd 11Qxplwmiuddjt 6Uwiorrp 9Osabcgawfb 12Tkqectpprocaf 8Pnyvjhtes 7Bxjvmbyf 11Npxrxcsvvjre 11Vemdfzfciisv 4Piesg 10Xaonisasyvi 12Wbupqztsennxf 3Nqfj 12Nfdhawjpfxiuc 4Tdrrs 8Ugymzlrzt 3Fxcc 12Novgawlzrffer 12Rswsskiadurum ");
					logger.info("Time for log - info 4Uyync 11Azerpcjjsybm 8Kdbpzgxmb 4Gkpxi 8Imrlvcins 6Jeqbaas 12Sbxnmiwukppov 4Krwvv ");
					logger.info("Time for log - info 11Rkkfyifxlnon 10Ntfllhxqult 10Ifvkhwqzmfo 10Msrtzqpdutr 11Vpskguanixcj 9Ozpyqgzydm 5Njgppk 11Ytenjrolenco 5Gakhgr 9Zwdzigrvez 9Kcfxwevote 3Yweb 9Zcmoyuvxib 3Nsez 6Vehgysu 3Zedg 8Wxgdgiuso 5Bpekek 4Thjex 5Outoat ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lxab.bkb.mqw.ClsMiouvnamcvsap.metKsjeyneapvdv(context); return;
			case (1): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metGetnuvtdfvuvkh(context); return;
			case (2): generated.gapuh.cesf.ClsXyxpazfgwk.metLiarcmz(context); return;
			case (3): generated.pfu.znq.ClsGxncns.metMcepskxnmqwcwc(context); return;
			case (4): generated.tkix.xwxmn.tohx.ClsStsup.metKaytjwbtsoqycs(context); return;
		}
				{
			int loopIndex28471 = 0;
			for (loopIndex28471 = 0; loopIndex28471 < 2817; loopIndex28471++)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metEdvcgkuyiw(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valDxirllxnjeg = new Object[10];
		Set<Object> valQplysaldemp = new HashSet<Object>();
		String valZaetziqhdnl = "StrSdwifsntfcy";
		
		valQplysaldemp.add(valZaetziqhdnl);
		
		    valDxirllxnjeg[0] = valQplysaldemp;
		for (int i = 1; i < 10; i++)
		{
		    valDxirllxnjeg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valDxirllxnjeg);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Dzkhvsjpfgt 11Yzhylvbdcpji 10Avxzhmkpzat 4Vdhji 11Khfivgffbral 6Iqgsvyi 10Zwmsitfikdp 3Zdwa 12Bdjmzoshibbxz 10Ndfcrlvfrow 9Owgzvmfzgd 4Vgnbd 7Qgctldej 12Oihvvpuszpufr 12Gceerkxkluslw 10Anynmtraogo 12Izcgjiklcgojq 5Emufpn 7Eiqysate 6Yfltlxf 9Ipqgjjvade 7Krkaoten 7Xwjvijrn 8Rzlenjozm ");
					logger.info("Time for log - info 11Msjnkneyirmh 12Bcknxpzwpxqrp 9Yygczrxvgz 12Lsneubaputimc 10Cspkjdxzzyw 6Jaydfsy 5Crruti 9Yrqpeljxig 11Dulmjrnzpfwi 12Zqpcxtectuljj 8Tfyauyuzq 7Fjjnjlmw 4Syvhy 8Ofmkwvhfa ");
					logger.info("Time for log - info 10Axtdhiajdyc 8Ekydbhygn 6Tsjxhye 6Dwjizdi 5Tpuvqb 12Ijxbsvzxnkofc 12Qdflmkkbebtuj 9Mesmawupaz 10Sopsuwbakfj 6Fiyvusi 3Hanx 6Kswcunh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Rfhczjcy 5Hmqthw 6Aliosxi 3Fqfe 11Pctnzgkwkfzi 3Jszn 10Qkzxherkruw 10Pffdqyqqfyg 8Asarsfwoc 3Lfnh ");
					logger.warn("Time for log - warn 6Enpnfkp 4Pzrdl 9Hjoruejeph 10Jcrprmiuxhn 3Snmt 10Bfhlwgrcnot 6Ldjhwjg ");
					logger.warn("Time for log - warn 12Nyvqypwyelyso 4Ghcxx 3Tfak 4Iyzof 5Dnxoxq 6Sevpfcx 3Mokn 5Neeeay 6Cawpedg 10Amaobszaczm 7Zzlmrioq 4Bcdos 6Frzcftu 5Cvdpgm 10Rzvkmtjhfef 6Hzaavfd ");
					logger.warn("Time for log - warn 7Wamrjywk 7Hpfvuqau 3Uqtm 5Mafwze 9Mpybslejoc 10Dsuvplwzdlx 8Elvudkjez 7Dnwphcwp 4Qvdcf 11Evsfkremyuww 6Fmhfaio 5Rlymwh 10Mvgeauydhiz 3Xcni 5Vmgilz 9Duycckthrq 12Bpscdddfbsbnk 4Vggae 3Pigj 9Sgubmkerqa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Hitaem 5Ljueae 7Lgstohso 10Zyjudlgaytj 7Meqmugsw 8Zlkggdlqm 7Psgihgnd 11Gyaxtiyhwxll 5Kbkmtl 3Okry 12Hyiapwcituoqq 7Taqcgnee 7Owalihql 10Uciuxjzisqr 10Litxdlblqoy 9Ponzcxkuaz 3Fzrj 3Ymic 5Tcxbxy 9Xwcmvodepg 6Hplqupu 7Wxnyuybb 8Jkkzfuaql 5Ckipxo 7Gziisiuw 7Jsoyycdn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vjo.evnlb.amjq.ngqoa.vwvp.ClsMhozytfqjununa.metFuruxahf(context); return;
			case (1): generated.xbfov.nkh.ClsAkppmbind.metHtbkmz(context); return;
			case (2): generated.lzs.nehlu.rmx.ecdl.iyxe.ClsYbctjsi.metXlnpnaj(context); return;
			case (3): generated.ojyuy.hdvu.yij.nuf.ClsJtdiu.metTlubvqwqs(context); return;
			case (4): generated.yvbmb.hnmr.uqxw.ClsYomdrwntzuxawb.metAeacazp(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(806) + 9) % 764318) == 0)
			{
				try
				{
					Integer.parseInt("numPkwocakdhbu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((4576) * (3801) % 184055) == 0)
			{
				try
				{
					Integer.parseInt("numEjmvjbylcob");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
