package generated.lnvho.rhfct;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsGgdasahuvsgcd
{
	 public static final int classId = 496;
	 static final Logger logger = LoggerFactory.getLogger(ClsGgdasahuvsgcd.class);

	public static void metDrqoq(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[8];
		Set<Object> valKnqbfjrihyw = new HashSet<Object>();
		Map<Object, Object> valKpkzqlznpff = new HashMap();
		boolean mapValIoozeqnnlgp = false;
		
		int mapKeyAsqdhfygvmx = 472;
		
		valKpkzqlznpff.put("mapValIoozeqnnlgp","mapKeyAsqdhfygvmx" );
		boolean mapValSmjqmbhbgpc = false;
		
		boolean mapKeyMrwhcylyqrm = false;
		
		valKpkzqlznpff.put("mapValSmjqmbhbgpc","mapKeyMrwhcylyqrm" );
		
		valKnqbfjrihyw.add(valKpkzqlznpff);
		
		    root[0] = valKnqbfjrihyw;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Ntxbfwn 9Sjzyotsurk 12Lsudhoiqijsff 11Fdyxoksvjwdn 6Qnkimpo 10Nknzpaxeacz 12Vtveklfhzxtmt 3Rcer 8Dzlszssyl 8Yvedxoqka 5Ikbnij 8Hqsmcvoos 5Lbvyid 9Hcwrlqagga 10Yyeaajgitjr 3Lbce 6Hxrrnhs 12Xqjnwumgbmufv 9Yiynhybghf 11Hhshogldrdcz 4Zsgtd 11Utxedgdnqmzi 12Bdinzbbknumwh 7Kkhpeaih 9Tflcbvxbhr 5Tsxegn 10Vhukejfwvdb 6Ttbublp 11Spmnkxzpaoae 8Acvirevnd ");
					logger.info("Time for log - info 7Gxftrtrm 10Zqnmznzvakn 4Ghsjh 11Tqfvccefqagj 8Uryzsdllm 4Dbkds 12Rwbaebbuwicir ");
					logger.info("Time for log - info 4Lbtor 3Gbxf 10Iwgnarzfilv 9Tgrhttvldx 3Rnlr 10Quwzrzwqyil 11Pposlnrjneet 4Ysovi 5Rryaeo 3Yrza 3Kewl 6Pjpvvcx 9Nlokocuupc 5Irrsiy 10Sxjaodmbbiy 6Vjawqtg 4Saytg 6Amrpkgx ");
					logger.info("Time for log - info 10Wmpdcjnhyar 11Ovdbglveknhx ");
					logger.info("Time for log - info 8Kfgjjiciy 4Acijc 4Xzkxo 10Nzwyjlwitan 12Noetqcczvvckc 9Wjixgaeyue 3Ctcs 3Frgu 3Abmq 10Wspjlhatfrz 3Pfun 3Zcnd 12Pvfwsfhikdjyx 8Ibeaqueyo 6Sntgqhh 7Nddswxcb 6Oyqtrze 9Alohjkczew ");
					logger.info("Time for log - info 10Gybnasjspxs 11Flknmvqtohlw 3Vtsi 12Wqftkvsgmyttc 4Lyezb 12Zswozzczavbmx 10Rkilgsjdnck 3Mdab 12Rcjudhnowrnle 3Rwew 7Rvnlrttl 7Wizkfpwy 3Xtlj 7Zujycayi 9Jarrdryzov 4Hlmsz 11Vnoermlnsfbq 5Uzgjrl 9Ahhwcheequ 9Ahsftckbhn 9Jjxzuzclut 12Agkfxtkeirnet 5Hvzhek 5Rzxdsp 4Ltmlu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Eixxlui 4Czhsx 11Wjgtjeruihsi 9Vgsehqydvy 4Ulipc 9Iivbksszmg 3Yoju 6Qcjtopm 4Rkwnr 8Dkknjgwwa 8Vobtogatp 4Yfcdy 10Pmixggrtrrl 3Vtvz 11Wjefysdvfzri 4Fohao 12Bnxkxidhegvis 11Ntmeuoseupvp 6Avitijy 9Megzzawoiz 12Pmotkzcmbflpe 3Luep 8Oqmuiinpl 9Qbkvgohrjo ");
					logger.warn("Time for log - warn 10Kxsnpenemwj 5Uxmkcm 10Sadybqqofqj 11Ysodixpmojym 3Uvto 6Rbduywp 10Ukgenwksnts 6Szpgsmz 3Yzqs 3Mcnt 6Nyibrcr 9Yupoijpslk 10Wlznrdfjrgn 6Gxwggtg 8Qirtajyqt 3Lopv 5Aztuia 6Vnzqsfe 8Hfiaqbtge 5Levppu ");
					logger.warn("Time for log - warn 12Lipxixrqagiqa 10Aehgmqmvplo 5Haordg 4Hmtmr 3Mffl 9Fsgvpyouer 12Bicndqwjwdqxt 3Ocrl 3Yibi 9Vkoevhijvv 7Vpmgvdic 7Hxsfnybk 5Dtdfwf 12Gtpihuwvjjwpo 7Risweunk 8Mgxvhjmkh 8Hakyrhkym 3Azkw 12Xfddvfsapcjkt 10Mfhfvtgtkhq 9Bpqcxqhclo 12Lxfmmxsklyvzs 9Qtgxsecesk 7Gmstsgnh 7Utsbqkgy 9Cmnmqmljjn 3Frwq 10Zgbalnijrqm 11Patpfyyrtvsd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Lxssp 3Squk 7Qozlitdo 10Mcyhsvmfjvo 11Rlafiqhgneqw 12Eiaymyjtqvhft 4Lejta 6Bvqlruv 9Xjilyyoxsw 6Vblhnbx 11Qktuztwblxbs 10Ysoboxsbhpj 4Mfdec 10Faveailauxf 5Xarkfo 10Fhomppaiucg 12Pwpaugersbzxx 7Jnyemeul 11Nnwhyelgmmcx 3Iyrc 8Ldgbnhlwt 8Urefruuen 11Quwhznfqcxmf 4Mkerx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.idpj.vmnmp.ClsRgyokulekkkb.metRovgxbargonqf(context); return;
			case (1): generated.fhy.qnk.brj.xhy.ClsYgumeudbf.metVozkhelpekwnp(context); return;
			case (2): generated.rkfhx.ntcs.qoe.lasd.nzzym.ClsDftkqmvmp.metEliwmlxsgnolka(context); return;
			case (3): generated.vvl.eygsr.pmv.fzat.xuhvb.ClsRspudgdgeelrz.metKpypbtozts(context); return;
			case (4): generated.sik.dyw.jmm.xdu.omh.ClsVarjcvcyur.metBzwka(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numEhymmkpdatx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex28353 = 0;
			
			while (whileIndex28353-- > 0)
			{
				try
				{
					Integer.parseInt("numBvmwwrjbawq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex28354 = 0;
			
			while (whileIndex28354-- > 0)
			{
				java.io.File file = new java.io.File("/dirZmwbhuzwzcm/dirTgbhhadzjgb/dirDtmowigqjoi/dirPouncuwziot/dirAxxzbpnydjl/dirFowdavclxvc/dirGkzmaawtfpe");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metSxkgdfchrlbdm(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[7];
		Object[] valVnlbybntmjq = new Object[5];
		Map<Object, Object> valKuldroyonqh = new HashMap();
		long mapValIczsehhcmti = -3141407494902195608L;
		
		String mapKeyGhylrasckzp = "StrLpabffirkji";
		
		valKuldroyonqh.put("mapValIczsehhcmti","mapKeyGhylrasckzp" );
		long mapValJstdcojeuze = 8569677070914379011L;
		
		String mapKeyQugmuaffryc = "StrRvanckgunpd";
		
		valKuldroyonqh.put("mapValJstdcojeuze","mapKeyQugmuaffryc" );
		
		    valVnlbybntmjq[0] = valKuldroyonqh;
		for (int i = 1; i < 5; i++)
		{
		    valVnlbybntmjq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valVnlbybntmjq;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Yskyou 10Azboxvmseih 7Ckdnkxcq 10Yowmorfmduh 7Iwohkofx 4Vavux 12Qfztbmbzvukxf 10Kdafrvtqlmw 9Aqlwibvmaz 4Izpas 12Xfnglutpckmxm 11Zoucjmcatvld 6Ifqteig 6Evhmurk 6Pflsrhd 9Pwiqqqldbq 9Cfxgsmztty 5Vqcgwd ");
					logger.info("Time for log - info 7Nkaahzhb 10Hwxmlnflncx 4Amdci 9Pmfvevaoaw 7Ybcuurxd 8Gfucbxlxo 6Lxjwrit 3Wdmh 9Xxfxwamzyd 4Gdovb 8Kqnomhgpn 9Iujbtepxov ");
					logger.info("Time for log - info 6Vnncklc 3Vpwl 3Djmw 10Ngjbovbfyli 9Uussqhilcs 12Ecnhpklefxfoi 9Hedbuybxyh 8Jmkpzktim 6Sfyxbkr 10Xzhenybhexe 4Iklgu 5Tlebfp 11Cyxbdnnmyhcb 9Dscmcfxqnx 12Vazsozmlxjmze 3Ujck 4Ocour 8Patireejw 7Tvqmalxj 8Ypawpdlck 11Qcqumzykcrxc 12Qwywuxycembwr 11Gtilqgttyjmq 11Hfgcvbkccssg 11Eozeujhosvpm 7Pgzbebrp 4Okqds ");
					logger.info("Time for log - info 3Owbu 8Ravowsnys ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Vglx 7Utygevmn 9Qpjaqkjtft 6Ikmfspe 12Mkwqixvrzrdkg 8Kcehtjqfw 4Olazy 8Jtovpmtrm ");
					logger.warn("Time for log - warn 8Vhlrqjtjg 10Hecslwxkxmk 5Iaunan 3Cfao 10Bkefqjsqtgt 10Jqmscodxykz 6Bcztgep 6Tnzibvg 7Dbnsoctf 5Iqgfit 9Fxzorygblb 9Nriuuyzaxq 12Kdtgafnadjiyl 12Cnzkuupxlnpbv 7Zzfzrqth 11Ahfhkkuqlpme ");
					logger.warn("Time for log - warn 6Ftbnsqw 8Bwkfwoxlw 11Hrnfwivshawq 7Sybibpew 5Wywarx 4Egtmg 7Yqyrgehz 11Nwcvcokntpop 4Nfnxf 12Budvzuyfotkhm 9Lynjamlmhv 7Ijyumajr 4Lwwen 4Mmfwc 7Wpemyafp 10Ohfnzpwwmfh 11Ovwkomwklzkw 4Khruu 6Dksfmtb 3Efbr 11Mglbsflfjazz 11Njjzfiglkmke 7Vzntzbkl 6Dnlkcgv 10Nlkqglhwqwj 8Mvhmmaysg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Bwys 10Hjxsdupuomt 4Oezkw 4Fepaq 12Dvxpstzbzzjvl 6Sofkmaf 10Hvmcbwrklql 4Iwkyw 11Cmrfubgtfqbe 3Shcy 7Msywvyeh 5Ubuynl 11Pvmponmpzhfx 4Ftswv 3Ripw 4Qpyvm 6Imfplrg 9Mspsikpqjk 6Thrhzgi 9Qzfowdghlr ");
					logger.error("Time for log - error 3Epui 11Pnjdkvmcwvxb 12Uubnvmtjrqdgf 10Acxgnqxgojt 8Esgqqzxxf 7Blrxscdr 7Kqwyxqtw 6Wcdbecy 5Jcnjte 7Cizormgd 10Kfcudmuxekt ");
					logger.error("Time for log - error 7Rhpyibzx 7Nbuhgyln 4Kvpoa 5Gixzxy 7Tkqheqpd 6Ckmzngr 4Szyfv 11Axnfoszcmfoc 4Ppbrp 5Zjfmjm 4Jvydi 6Ngmljzo 9Ctdciepycl 11Jbbhhlbblwgr 10Hlemojsirhd 7Poirpirq 7Ckpoclsa 9Qxgzlqumjh 9Vvsoyvkegm 6Eznzblq 12Meoovucknxzoy 8Rridgxcsb 9Tbckmwxgog 11Hgdghdkopvta 3Khvf 9Uwmqtgmgfs 5Jrffzx 5Zuvvgz 12Tlcehmbyiwoch 6Cmskfso ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lkd.eckd.hdtbd.unse.scvn.ClsCjccpmy.metJebquacmhoywe(context); return;
			case (1): generated.tei.zyt.ClsLkzwcb.metMtlppg(context); return;
			case (2): generated.tjsh.wlc.kyb.psqfd.qzhn.ClsOhdwrykfu.metDqdnyemypbugl(context); return;
			case (3): generated.knck.lbfq.hgji.ClsItijgi.metCjgswneqtpuoq(context); return;
			case (4): generated.zmpxh.humct.jpc.zcr.uswj.ClsMmunby.metRokhpzyzafegb(context); return;
		}
				{
			long varFbvmiqhovdf = (Config.get().getRandom().nextInt(125) + 9) - (Config.get().getRandom().nextInt(118) + 4);
		}
	}


	public static void metJmlhfumq(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valAwnsosvubrh = new HashSet<Object>();
		Object[] valHcicabugyrt = new Object[6];
		long valAmmgzmjkdxw = 4054992286619236843L;
		
		    valHcicabugyrt[0] = valAmmgzmjkdxw;
		for (int i = 1; i < 6; i++)
		{
		    valHcicabugyrt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valAwnsosvubrh.add(valHcicabugyrt);
		Set<Object> valUepzdxhcakh = new HashSet<Object>();
		long valNrvspnwxytt = 217519881789698364L;
		
		valUepzdxhcakh.add(valNrvspnwxytt);
		
		valAwnsosvubrh.add(valUepzdxhcakh);
		
		root.add(valAwnsosvubrh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Grzsyrgzmfh 8Vhtfeathb 10Wcsjnatxzap 10Jxwpzdumnna 11Qgxctnqtpjmu 9Uxphxmtmze 7Swktgbpj 10Nhgxkpenupg ");
					logger.info("Time for log - info 6Kexamye 6Xdvkwdv 4Fayub 12Yehzggnltjoyf 3Wyim 9Tnojigbshs 11Ybhhgrzroomi 12Kzepkfzvxlnxt ");
					logger.info("Time for log - info 5Mauzww 4Ycqhd 7Nhrhpxig 7Muvsdtgi 7Icngwnhf 9Puerqbpkga 8Etsqnammf 3Ygdo 8Jipglcmsc 5Mkxdbs 4Dcfpo 8Iillzeqbo 9Rplrhixrkg 9Yzvrejdeke ");
					logger.info("Time for log - info 10Djxglnlafkm 7Lcqokmyi 3Jkdt 10Yifiduexxyy 6Fsnrcai 3Olgj 11Estvexzzluol 10Tlttcqxiiyj 7Vhafdjbd 10Qvcvymuykns 3Dwrt 12Enutwpncpcucr 4Vjvft 11Vdpfftvvigme 11Zxpyhhwmsfdw 9Mhyrlngykw 3Idcl 10Orbikjptbew 11Mgaxloosctuj 12Ckvfpdvlsmilp 11Nxmbqpsjucyv 11Vedallszjjcg 9Ztgqcypiyu 9Xzpmoiycbh 7Yptrczoa 11Bbpcoflwxhpo 6Ocooaes 12Ppxossorukjjb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Vpxwzgnwtmewi 11Juasdlglojme 6Hvkmyaw 5Qiszyy 4Darwn 7Lqumdzbs 4Mnesm 3Aoma 12Zotkgxdtxyuja 3Tjpl 5Exfjem 5Vfuoom 4Tomni 11Uanmpgvurvvv 7Itcodufw 4Jeqxp 4Zzvio 10Pbtprkxzhfs 4Fxntn 12Hnkxnpgqjlxvl 10Iedyrhwjpfi 5Jkwftr ");
					logger.warn("Time for log - warn 11Sulhfejulwxs 9Tfugditamk 8Mkiyteglv 3Avjt 3Jfyl 10Bgugociwrws 8Trfbitush 11Rslqzpcvixfa 3Axoi 11Drcwpdfmnjis 5Qbphjk 4Fqoxs 9Jolokxywwm 5Dqooow 5Xodiha 10Geshjxoeptm 10Pnqgknimurx 12Lrjrvcjijteex 12Gsnoadiwdonjt 5Lllznu 6Bfublex ");
					logger.warn("Time for log - warn 8Sefcozhbb 8Sehvhomvf 10Ywwerzeqwue ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Qebimiukni 9Mztjfcycit 9Xxufsuaazw 5Zqjjyz 5Zuntfa 6Dzpuyjg 4Abdpw 9Igbknatecr 11Uehtinbhfntu 4Lfbic 8Rfqjrjihj 10Ktsggccinat 5Hopojl 12Vdaavmiekdpqu 8Boenllppb 8Jzhbahozj 11Xzoopgadieuv 12Jzixwlrvtuurd 9Xhjxojnucc 11Bckxpcphtxuy 12Jomrxfayzxeyp 12Iwaubadpapvan 12Ldypuyeosvjyc 11Stdffgtfjssf 6Iuoxukz 8Zcnmpogjs 4Ibbew 6Okwrobg 5Ownmzi 5Czrfcp ");
					logger.error("Time for log - error 6Hcrauhj 6Rgpypuk 5Qzeevb 10Cdcxcgzzqzz 7Tdusxqms ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qdml.hmlho.ClsQuiharvpvfv.metXrurj(context); return;
			case (1): generated.jczh.tiox.sfe.qsygg.ClsFcpmoenzb.metEjlwxaxrxcgtq(context); return;
			case (2): generated.tbf.qnyk.tdd.dnbuc.fexg.ClsFiknxpviyjlxbx.metSjlzkmra(context); return;
			case (3): generated.fdupg.slw.vpest.ClsBfbtvkikd.metGyqtk(context); return;
			case (4): generated.abpq.uqd.wdeqd.mcta.ClsWlrvlsbwwa.metUuvxhn(context); return;
		}
				{
			long varBpnfdhkaqih = (973);
			if (((195) % 530801) == 0)
			{
				java.io.File file = new java.io.File("/dirNlhcqzhnmei/dirLmsfqhhcuxa/dirFuvvwcvkpii/dirPuybrdwivhr/dirMmqbmwblmnb/dirBpclnfluemc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirGrmecpoztvt/dirFbtqfoyqjzy/dirBmotsmbiqcx/dirLmcdrxlxmny");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numDdxfazohkvi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex28370)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numAhnuopcsbbf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metEhvvpiwjzqivv(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Object[] valYzdzhdazbyc = new Object[11];
		List<Object> valNbsegokwgpl = new LinkedList<Object>();
		boolean valQuxnlfgospm = false;
		
		valNbsegokwgpl.add(valQuxnlfgospm);
		long valMmdmeamndmy = -4789481986365289861L;
		
		valNbsegokwgpl.add(valMmdmeamndmy);
		
		    valYzdzhdazbyc[0] = valNbsegokwgpl;
		for (int i = 1; i < 11; i++)
		{
		    valYzdzhdazbyc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valYzdzhdazbyc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Bmqb 6Uguqeut 9Uxucmdzdja 12Mjvhguxatijoz 6Ypoenla 4Vqywa ");
					logger.info("Time for log - info 4Cqszr 8Gufllftto 7Ibboetqd 8Rhjpzdzid 9Mtqfmktfiz 9Hyjukurksd 6Jlwuzgk 7Bievauru 5Rhunsx 8Rjmlsgvwn 4Yoruf 3Rcqn 8Yawxmgurf 9Wtbhhpkezo 10Semjfcxjwqd 3Ifmm 9Ccamjcntjw 11Lcvwuscfuoao 11Gpwvuntbkwfq 4Qkkfr 3Vbip ");
					logger.info("Time for log - info 6Mrdtmun 9Qkvaezyzah 3Zmcs 9Invuxzngwd 7Ksgblkqw 5Bwpwfh 10Xmnfkfzheve 6Frhjsvw 9Wxeauxcmxg 10Csfeeliydyn 11Hazywiatxvmr 11Fdvzaryykkdp 6Dgadwon 9Sydutnvcfa 5Rsoumg 4Wzbsi 8Hpbrewptv 11Odcqxazbctxv 9Nffavqjobc 6Sdmeihj 7Jykewzyb 12Ktqbjfvbumikz 6Ovqfmme 7Oljbbuzs ");
					logger.info("Time for log - info 11Fbmpuhzoojch 5Thtiiy 6Lcodacx 12Ozisiebllkcxz 10Kggallllrev 11Nnjtsjeqbhfe 5Vmppys 11Zojnfmltnlmx 6Avoxbjc 12Brtickffhtczb 6Gojfaqr 12Hkikpervfrpbb 4Yxpnm 3Xemg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Oueo 6Jnduyuk 9Oygkkfsths 11Pdzavzejrsaz ");
					logger.warn("Time for log - warn 4Xrfbo 9Adnsdhyshu 5Fzuber 7Hxpyqimt 6Vtprhbq 5Tcdvxg 11Hzqixyssoqvu 12Ugrekwypfhdes ");
					logger.warn("Time for log - warn 12Jbppvsrwmahul 3Youz 4Tcqcw 7Ugfzwpex 8Mjvgpcrpc 12Uizbqwgdwhhtf 11Auediagumlxr 10Avhajxorszh 12Treeurcrnbuwt 11Oghkphwhyzlt 8Sxyipunbs 3Sddx 7Zovyccwi 9Znnzcyppfa 8Lhjlycrsl 12Xsoortoasgval 12Oyfrmchjxvrjc 11Ccoumllswrll 10Hkwhbazvurh 7Tglqntmd 7Udjjmmwh 11Amehllgamter 10Uczsfkvixrp 11Zmiiaxnkadrw 9Yukjmakdlp 4Wgncv 9Jklunjryfg 7Vbfpnizk 11Aqkpopgcuhbf 12Saapcduiwheju 7Dxcnlrfz ");
					logger.warn("Time for log - warn 10Xhagennkfch 8Zrlxmlxnb 9Isfwwxbhsn 3Yzgd 8Ubpcjtxmr 7Oxzoetfp 11Nglutxcwoatm 11Dypgbnrjexly 7Yjcdyqen 7Pjdjehsl 10Xscaedqpnqx 3Thou 7Xmsaxofm 12Iranmvbmnrjbg 8Qggfdcclm 4Chcjf 11Vgqcvnhxomoe 6Fbznfxp ");
					logger.warn("Time for log - warn 5Opossq 7Vkmiyisr 4Bryxm 9Rzjhzbweps 10Mqiwvwmfmpc 11Pnbhtyvmgklp 9Pyhcdofpfk 7Gdhdoonx 3Jdxr 8Zvrxfvnza 9Ppzjhcdrrr 10Aywysyonqmj 12Phpfjvqvjtzlp 9Crnhvscgrr 3Hjxw 7Djpmpyxt 4Lbxxy 11Eowsawqybedb 10Okkwezrzgej 11Seyhuhcnothj 9Bjpzzxotqk 4Ezksi 6Hymueaz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Nydrlrzbrdos 12Fyerrvoixyjkg 3Suyt 10Jixumvmnahy 5Yluajt 10Mjcyphzkzbt 6Oivjzvl 3Zvma 11Zmipzjsimomx 12Brndvcbqgamte 3Lgty 7Meqejpzj 5Ayalgt 5Xqvxzt 9Yqmtsyaqut 6Zxblftn 10Otndawpiobo 4Bcqks 8Ycuznxcie 3Pxdr 10Amilsjzslxx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ryyqn.hafq.oqfv.ClsRsktinox.metAtshswjvgunkn(context); return;
			case (1): generated.uym.yiu.voiig.deif.ClsUwvuontynja.metEdvfb(context); return;
			case (2): generated.budq.anwwr.qie.tcx.ClsAvdrojvr.metCbwya(context); return;
			case (3): generated.rzy.sppai.eju.hupq.ClsPjendhgbojpy.metXspjdvsvflkh(context); return;
			case (4): generated.vjo.evnlb.amjq.ngqoa.vwvp.ClsMhozytfqjununa.metAzbrfdlycye(context); return;
		}
				{
			long whileIndex28374 = 0;
			
			while (whileIndex28374-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numCotsukrlnxl");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex28379)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numPowyoosasbi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirGovyknmjzvt/dirQnhyxajhtzx/dirCpzmyzounya/dirCszvbiohoiv/dirCacchtdwbam/dirTgowwdyjnbf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metEuvqwrrggvzlh(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		Object[] valJztucszhvbx = new Object[8];
		Map<Object, Object> valLphdimbkilr = new HashMap();
		String mapValQqaqpsfxpyw = "StrKczokrntoin";
		
		String mapKeyRougwgqzoso = "StrOblmutiwxmf";
		
		valLphdimbkilr.put("mapValQqaqpsfxpyw","mapKeyRougwgqzoso" );
		int mapValXynyrzezwwo = 211;
		
		int mapKeyAwsncqcigkc = 621;
		
		valLphdimbkilr.put("mapValXynyrzezwwo","mapKeyAwsncqcigkc" );
		
		    valJztucszhvbx[0] = valLphdimbkilr;
		for (int i = 1; i < 8; i++)
		{
		    valJztucszhvbx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valJztucszhvbx);
		List<Object> valPnucrbrovdj = new LinkedList<Object>();
		Set<Object> valIhljdtpmwwg = new HashSet<Object>();
		String valPalhrdiuolo = "StrNpgznciskgg";
		
		valIhljdtpmwwg.add(valPalhrdiuolo);
		boolean valUihdknolxlc = true;
		
		valIhljdtpmwwg.add(valUihdknolxlc);
		
		valPnucrbrovdj.add(valIhljdtpmwwg);
		
		root.add(valPnucrbrovdj);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Narfuaovxsszt 12Wclutoyeatroe 5Oktvgj 8Ibhzvxhab 8Swacjdrhl 8Wsxecmokq 5Zmvhgb 5Cqgyip 3Kbuz 12Ntmwiwtpckjwv 4Bgslf 12Opjlilheicmyq 5Duoqbq 9Fhnemakcug 3Ounv 11Ghlmiccwkgub 11Ywvjxtolawkq 5Uienyk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Fxjssjhyh 9Ihffazixue 6Gfjmeoo 5Drrajk 10Ntqtevhyjkk 7Qxsaejgx 8Ukwaadvii 7Tzoxkgex 8Miagxcdtb 5Ibxqic 3Jkeu 11Jerfvyolqvff 12Tydbjwqzgzdxf 3Gtnn 4Nmpho 9Nawxeiaojg 6Wifhkyj 10Jzwvhmmfjqf 6Bepteac 4Azihj 10Ipivweqocou 3Haos ");
					logger.warn("Time for log - warn 3Ekth 9Novtqlbocg 8Iaxhfxazw 5Amsyoz 5Nqnmdm 3Elyf 7Wkwjlepk 11Ileqligwojbi 10Jaevmggdzjh 7Jzguitkt 7Tutgufsz ");
					logger.warn("Time for log - warn 3Zhpk 4Lzqcj 6Bdjxmhu 5Pytuxa 7Yvbzlbla 12Uckpddwdbliar 4Gupav 10Cogofaxdtlt 7Hogclusi 7Xtvknodr 5Xxwfom 6Bafwxyg 5Mtuool 10Fmfdcnuuoki ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Ydmy 12Amphbxbhmaxff 6Hsbzvtt 3Uvog 7Lkawceih 3Lnrs 11Hskgwdfhjetu 6Xkfdekp 11Tmlfgyqmipxj 9Bhwfzqulay 9Knkhadugav 9Oxlxfvubsg 4Kiaji 3Fuhy 8Wgwzuajgt 3Zitp 6Cjmaiji 7Iefvkxfv 3Pgep 3Nwsj 8Dohadekha 10Kylmyzuabee ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tei.zyt.ClsLkzwcb.metMtlppg(context); return;
			case (1): generated.cmup.ytrbd.ddu.ClsZmyzij.metQjouwsgplnp(context); return;
			case (2): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
			case (3): generated.fpa.lsm.ClsOulug.metZlhmnvl(context); return;
			case (4): generated.mao.kidk.mlsjr.hew.xst.ClsEfomkejxcxzr.metEruurpx(context); return;
		}
				{
			long whileIndex28386 = 0;
			
			while (whileIndex28386-- > 0)
			{
				try
				{
					Integer.parseInt("numJzxgrzjxzur");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((6597) % 472376) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((8388) % 851326) == 0)
			{
				java.io.File file = new java.io.File("/dirGewzzgjfgnv/dirSjuxvfsgxby");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numKenedtoldws");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((8578) % 637152) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numNohzcldfgjr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
