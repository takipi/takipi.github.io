package generated.tjmm.euxn.jmtp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsNhugjkj
{
	 public static final int classId = 413;
	 static final Logger logger = LoggerFactory.getLogger(ClsNhugjkj.class);

	public static void metQafbogfqlngiyk(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValIosjbggmccg = new Object[8];
		Map<Object, Object> valBcdwivhaymj = new HashMap();
		boolean mapValOolpppzncut = true;
		
		boolean mapKeyDibtwvciolc = true;
		
		valBcdwivhaymj.put("mapValOolpppzncut","mapKeyDibtwvciolc" );
		int mapValFkmcpyjhjru = 425;
		
		long mapKeyPsshjcxaaxe = 7856675763029226691L;
		
		valBcdwivhaymj.put("mapValFkmcpyjhjru","mapKeyPsshjcxaaxe" );
		
		    mapValIosjbggmccg[0] = valBcdwivhaymj;
		for (int i = 1; i < 8; i++)
		{
		    mapValIosjbggmccg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyRvscmxltikh = new HashSet<Object>();
		Map<Object, Object> valIkizqngziev = new HashMap();
		boolean mapValBycbfwzudpw = true;
		
		long mapKeyAqjsprqkgwj = 8453697578458084073L;
		
		valIkizqngziev.put("mapValBycbfwzudpw","mapKeyAqjsprqkgwj" );
		
		mapKeyRvscmxltikh.add(valIkizqngziev);
		
		root.put("mapValIosjbggmccg","mapKeyRvscmxltikh" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Rfglamjetzzp 5Tjtcev 4Ozqvl 3Pggi 6Rxcjdso 12Tfehunezzrwsc 6Bzzjnyq 9Ajbqqwhvrh 5Vfxoyc 12Tihqykdjpnbmv 4Ybtiy 10Otljwwoodjr 8Xkcbcosqv 7Dvnaspyu 8Yimbuiiga 10Eutuqurczku 7Mwpxpofo 6Hrvhllk 4Wtpdo 3Ficd 3Taut 3Royc 9Pgfdsavcrf 9Jlwwbyvgja ");
					logger.info("Time for log - info 7Yslmsokh 6Dvrzfaj 12Xaigqygiczqmo 6Vxrrwpz 6Lgluerq 3Gpyq 5Nbhppw 10Wufneeznrwl 3Lomx 5Aelfei 6Oomunef 11Ucudzmzqdvrj 3Gjys 3Sxcm 5Pnlsxk 3Aclq 12Cyuzrnuqkubry 6Ukhndta 7Opcjlacw 12Jqdeuithqpkwe 9Exctklcjdp 6Cgiwxaz 8Nkxdzdmtk 4Ulygl 8Uxiqqxfmd 12Crmftturgyeyi 11Ehedeajnoirv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Gwnziazdu 11Euptsygcwzhz 3Ffuo 9Pcnkhvyrfd 11Mggvdxtwumvs 6Uzawpwt 3Apuf 11Ywnfhbnswnvb 3Pvfa 7Esmnsrox 5Mrkknb 11Tcsktejxbtye 11Hhloqcqmnszd 11Ikjmnhyrjftf 3Okdm 4Ioozb 6Fqzsrph 10Usxvxgnnkej 11Ytwkchztcndd 12Ssuxgtrokejtt 5Pzijdc ");
					logger.error("Time for log - error 3Qabt 8Wvjkxqcau 11Sskcqbiwyeih 8Yhrbeyqua 9Kvffaurlqr 11Wufipsdwitct 6Gkcnttg 10Eyvkprnnibl 5Gqauyv 10Ifyrnwnjmtu 6Uqqaxwt 3Itwj 9Svovjftbyd 3Lhfm 7Jucwymtg 3Ygoh 11Spjjlxkmenjl 9Waxnfrjkrj 5Yxcerq 6Wiktcds 9Dsoiulbfmc 3Gasb 9Zqrxxanuvb 11Wufxlndpdqms 12Wjjnjhxjbpcbr 3Izyd 3Kfxj 12Sjvudbvzvraeq ");
					logger.error("Time for log - error 8Zksguvvyp 7Powvaohb 3Azzz 4Wmedt 5Rriolp 11Zijftjhmbrde 12Ilqdxiuvvoive 3Lzlg 6Uloiamy 12Hqeavolinjvko ");
					logger.error("Time for log - error 6Cnxdbis 12Ldgpjdfzgpxdm 4Rtejd 6Djzuspi 7Tbzkbbja 3Pugu 7Ruofdxym 11Bbqxztnbmdop 4Mebwz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
			case (1): generated.xcud.xbp.eztj.gexk.ClsTupoxajhjshtec.metEsfpmpnsdd(context); return;
			case (2): generated.obqk.bihpl.ehwd.ClsWcpejgvq.metUrpeeajbj(context); return;
			case (3): generated.qzl.yonxw.xanna.lsvx.pese.ClsHtvngej.metDfrsop(context); return;
			case (4): generated.kkpa.egwla.xylej.ryfr.zebdf.ClsUznbtznd.metNknepqlg(context); return;
		}
				{
			int loopIndex26953 = 0;
			for (loopIndex26953 = 0; loopIndex26953 < 1454; loopIndex26953++)
			{
				java.io.File file = new java.io.File("/dirPxjxvonttom/dirWzwxxauobxs/dirHmjchyksbvp/dirVgjndnsmdjo");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((7188) - (9064) % 845051) == 0)
			{
				try
				{
					Integer.parseInt("numOqlsgzknzxq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirSopedlcilam/dirOavnnukgjsy/dirWyyfwjxejra/dirKtuogrphijm/dirWsnsdsfpvdm/dirDzvzewohjur/dirKjqxinlkntd");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varWxtnuhovlew = (Config.get().getRandom().nextInt(921) + 2);
		}
	}

}
