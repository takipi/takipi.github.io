package generated.nmwme.qnfne.zsgam.zytf.yqrto;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDkqpghfzzf
{
	 public static final int classId = 497;
	 static final Logger logger = LoggerFactory.getLogger(ClsDkqpghfzzf.class);

	public static void metFtplshpnymzm(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valWtmczyxbdgn = new HashSet<Object>();
		Object[] valWefgvodtllk = new Object[11];
		String valQejcpqknuzq = "StrIgxekchafqn";
		
		    valWefgvodtllk[0] = valQejcpqknuzq;
		for (int i = 1; i < 11; i++)
		{
		    valWefgvodtllk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valWtmczyxbdgn.add(valWefgvodtllk);
		
		root.add(valWtmczyxbdgn);
		Map<Object, Object> valQctkttgynpn = new HashMap();
		Object[] mapValYathmljpfpb = new Object[4];
		long valLfvjcwrpugo = 6174624715692292271L;
		
		    mapValYathmljpfpb[0] = valLfvjcwrpugo;
		for (int i = 1; i < 4; i++)
		{
		    mapValYathmljpfpb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyXwmzmeukxrd = new HashSet<Object>();
		long valVniveifetbp = 847082490345382539L;
		
		mapKeyXwmzmeukxrd.add(valVniveifetbp);
		
		valQctkttgynpn.put("mapValYathmljpfpb","mapKeyXwmzmeukxrd" );
		
		root.add(valQctkttgynpn);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Zvhswxmrnd 12Rsoezrkaaoddt 7Oruvqrav 12Semvdvrelvmzs 12Bezkzgqduziwh 10Kucjkrggise 6Wxbzfkk 7Panpsnmx 5Nuenkb 7Kyglygaz 9Jhjltfdrna 7Busznuuo 10Iyedirqiedc 9Xbixzbrctu 3Oadz 5Fpjpkv 10Cfyfvmgiqpa 6Nvqsiji 5Rinhbt 5Rinywd 9Tfhqhwhcgb 6Vgtpail 3Jctt 8Ztlnfvozh 6Vkbpxij 3Gsxt 12Lveizhmilvzcq 4Orsis 10Kzqhgbwtukv ");
					logger.info("Time for log - info 9Vgarbrknbe 9Jgaifzeqxq 6Fusjlgx 11Svlxrkpkwrlz 12Shoiliuqxcggk 12Pwrggvvqyieyu 12Jpcfovzawcapf 6Xvkwejv 3Orkn 5Zsyqgs 11Rlakysctkdep 7Lomfbpke 10Ndiysrkibcl 6Xojoosh 5Jwvdrx 12Paauotcadbsaf 8Dvpcefnpc 8Vwhkywtnm 7Qwyyjkad 3Cvoy 11Nmhksjhtrfsd ");
					logger.info("Time for log - info 8Lfdxfgqvr 5Ssmegc 8Hqtuhfnoi 4Cqtjd 5Mlxbnu 4Oxdsk 10Gbngxktkucr 4Mftdh 4Wclsp 11Xxsptauzzcny 5Ktuuyr 7Khfpdvmr 3Odyn 5Xsskpu 12Sslafwjpsfucl 4Qjgmt 9Obfdbegccg 11Munzjsidaxef 10Drxwbjwderw 4Yawwd 8Jainaiuhf 11Epkbbwkxdcue 7Aqukooqr 12Yzotudqrdlvnw 7Zhwiemqs 12Oqlunepcikxig 9Ycvsufcdnt ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Japrshcgccttj 6Bjjikae 7Hdpnqicz 8Lrkxumlet 12Kuecnznqymyek 6Ymxmhdq 4Kdgqj 5Nxeual 9Srqoodyzoh 12Qsmsejoxdocby 6Jrkehcz 10Vptvcsqjxxr 4Qpzym 5Rllpzv 8Zlypwvfoy 6Ydtinxe 6Yyeanaj 3Rdsb 4Zazeq 3Fqvc 8Zttntxsvi 5Qtsdsh 3Omid 4Pwayk 4Goyyr 7Chpdjnqr 9Rwmlnyujqm 3Ofdj 7Zhcmuhyd ");
					logger.warn("Time for log - warn 6Slerpkb 7Nvonengy 6Aigczlq 11Igkvdjzisihq 3Gwft 5Xywbov 8Mnxrwfhzd 3Uiby 12Lxodihgrfpfpy 6Rnhtqqy 5Wktbbs 8Rymgqyheb 12Cbdngcykufexr 12Tujvbotthwwys 6Jriinuf 4Vqqoy 5Myordu 9Reyiafflom 5Gfkysy ");
					logger.warn("Time for log - warn 3Xfpv 11Ghjmzicgvcwi 12Iktqzbunqvnwt 3Wzeq 3Mzde 6Zstzalx 4Qzkck 8Xuzjsimdf 9Mtzxojfsuj 5Bttsxx 7Btdjnrrd 11Nagcnrpvfgdy 3Xjbr 4Lfhaz 8Aygntfbkg 12Xtfejbnquouro 7Akwejogy 5Hzqkkm 3Ujaa 5Bfmqnw 7Akptaiwe 5Xjfdcw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Tsrye 12Zsxvbtorbjame 10Dychbmmazyr 5Cdpsay 9Uovnumkkgh 11Uvgcpjoydjsn 3Jpfg 9Qmsgjabtkb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jrx.knq.qgl.klpmp.wqhuy.ClsPrfpvgkjefvagy.metFzjcvfpdxrxcop(context); return;
			case (1): generated.zeo.tykl.bkniu.uhs.uwxh.ClsUegpnzqhmar.metNitnfqpe(context); return;
			case (2): generated.gmgh.ssix.lawd.ClsKyyfcksbykyfba.metCgbvmwx(context); return;
			case (3): generated.drdz.aky.gfc.cjlsi.ndn.ClsMzlwuddsrmx.metPkkootprwfykih(context); return;
			case (4): generated.mbf.jauhv.phe.sowu.arz.ClsAtgovrsbvzxguw.metNzrbcudifbng(context); return;
		}
				{
			if (((235) - (7328) % 640332) == 0)
			{
				try
				{
					Integer.parseInt("numXznrwbbqstt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirYxvpsykmtyp/dirHybbmrjhvhw/dirTyqupewiybv/dirQxtqeuvvnhj/dirOqleyvbwxtx/dirEtzokiscoya/dirImscdmufnjv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metLrvrrwj(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValLrqwprjparn = new Object[8];
		List<Object> valQkzylahnkqw = new LinkedList<Object>();
		long valGjrlkdlpbhg = 6661391926961187213L;
		
		valQkzylahnkqw.add(valGjrlkdlpbhg);
		long valOluypfmlcum = -4297556838225541369L;
		
		valQkzylahnkqw.add(valOluypfmlcum);
		
		    mapValLrqwprjparn[0] = valQkzylahnkqw;
		for (int i = 1; i < 8; i++)
		{
		    mapValLrqwprjparn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyJodirxizwtk = new HashSet<Object>();
		Set<Object> valItaioqulitz = new HashSet<Object>();
		String valVpchbclzryg = "StrVnfjfetmlhw";
		
		valItaioqulitz.add(valVpchbclzryg);
		String valNwrsijckank = "StrOgpoypzgenp";
		
		valItaioqulitz.add(valNwrsijckank);
		
		mapKeyJodirxizwtk.add(valItaioqulitz);
		
		root.put("mapValLrqwprjparn","mapKeyJodirxizwtk" );
		Object[] mapValWgatorsieii = new Object[6];
		List<Object> valPegbudzwilu = new LinkedList<Object>();
		int valXdzednyuedo = 792;
		
		valPegbudzwilu.add(valXdzednyuedo);
		long valMvydyaazole = -2360464079189591951L;
		
		valPegbudzwilu.add(valMvydyaazole);
		
		    mapValWgatorsieii[0] = valPegbudzwilu;
		for (int i = 1; i < 6; i++)
		{
		    mapValWgatorsieii[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyRbkwhfrpgcm = new HashSet<Object>();
		Set<Object> valDjmyigitxqp = new HashSet<Object>();
		boolean valTeonbkgjhkc = true;
		
		valDjmyigitxqp.add(valTeonbkgjhkc);
		
		mapKeyRbkwhfrpgcm.add(valDjmyigitxqp);
		
		root.put("mapValWgatorsieii","mapKeyRbkwhfrpgcm" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Zpcmgxxq 9Ojqjmgeenu 6Momofth 3Mgoy 8Tvgdwkryp 3Cgin 6Tkajdxy 9Xhnhyfoeyz 5Yqivrt 10Ahetiuwzpjc 8Vjkrmwcxi 7Hffhlrju 12Hnldjlgwygtvw 10Orubhosaksr 12Qqcqdthaozwkq 8Utfmfjrdh 12Esdejxpfpsxrd 5Mubtfv 6Keapaov ");
					logger.info("Time for log - info 9Mlphqtbbgm 12Mrbuleauayghe 9Hdhrfmxrjc 8Yomqdmlac 7Mepijiti 7Hvwwxfje 10Umjawrtfrjf 10Jmdnqnvjgos 7Vkjkxxve 9Gchelfenit 6Jqzbgaf 12Viomhtypzjziz 6Ctvoquy 6Htlvqqm 11Vfcrwhfnsolx 6Pcngxac 6Tzoxhom 10Qbrhxiobgeg 7Lnezxzlo 7Jmogrnlv ");
					logger.info("Time for log - info 10Bmoglqzgwzy 11Tzkkynnoefga 5Ndzipy 11Dyultovxfnzq 10Hofckrkxfqp 11Ohbersbkwhox 8Kxuxgfwxf 9Dtvnqplexf ");
					logger.info("Time for log - info 6Ldsihnx 5Zeaycj 4Zrbcr 6Vqdyvyl 3Xhns 7Otvpppou 7Nvssnqhh 5Tjhncf 4Kkffj 3Teml 10Sgabxczoxnk 5Paeisw 6Bqlsfjd 5Yyjxak 12Yfhetnjvolfob 11Omfglljiuves 10Kvqumezslur 5Njxoat 12Viwrgzhkiulbr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Brglspsaixt 8Iyhdjmews 10Jpidyimuzrx 8Tnkrcyptz 11Ntcwwloaarjm 7Zmlervcc 3Hzrt 4Eyggx 9Ulyoxmhkgu ");
					logger.warn("Time for log - warn 6Ndxybjo 3Zxyv 4Kwyeb 10Eexqqnrwvhb 5Heomkq 3Enzf 5Urbstl 10Bzplbigkjjk 8Kjrbeqdqe 11Saccxkrlnkli 11Gtvkrybjzmxk 10Anjzxrzmqov 10Lgfeuthggxc 12Zqchhjausuaxn 8Jjyebuqke 10Rvzdhamfqtl 4Jtqts 5Pjymnn 9Jbwizpaamy 8Hvfptahwz 4Qcpdi 5Mmyjzk 7Nsfbtnxw 4Ykkta 7Srjwczcm 6Wviqzdk ");
					logger.warn("Time for log - warn 9Gtnvfdlbyu 5Enmsxy 11Amdurkuedcqx 3Ynst 10Pdnrivxqwxt 7Yynglvem 10Fzzrnobiqhe 3Vqbm 9Szmvjqusco 7Tzlkxylu 9Dxgsmvhdnf 4Fjkhw 5Hkpmih 5Mtbghn 3Faoz 8Ecdqurwur 8Kbzhnlyni 5Gemdnk 9Quacamynpn 6Ptbadwg 8Rdctsbkyj 7Uebckwxw ");
					logger.warn("Time for log - warn 7Tseyhvhm 12Jfjuasldeswwo ");
					logger.warn("Time for log - warn 3Plcv 6Wwnaarq 9Mcuvlmxami 12Okpcfzwlhklaw 12Praxmvrtctdeg 6Okgxpru 9Dbsdrtrcfm 7Yayjkisf 6Zkpbyte 10Tlpnkwcnfcq 9Xjlscnupby 9Ezxvjzqbhg 3Wjnp 8Hpppniecz 6Mqvhxga 11Yueslopvdvcs 9Yyqboululk 11Wsmnnqredkxn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Ooworihjz 11Fwrpopfwdvnt 6Wmlkeru 8Sbydgafmk 9Xdmzidmrrs 11Kcoyerrtvryk 5Jyuico 10Uyzysmazfsr 8Vpfghgxys 10Ekjaxuwluhv 10Rqkidnvhmwq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qzl.yonxw.xanna.lsvx.pese.ClsHtvngej.metFwbebfwdtycuk(context); return;
			case (1): generated.zfo.wctt.rjxf.wjfcy.ClsKuhcjj.metRopywvqfbispip(context); return;
			case (2): generated.meo.tvmj.xqqix.qdpb.crypd.ClsCqiefbhpitkzjs.metPmgbkkg(context); return;
			case (3): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metUooas(context); return;
			case (4): generated.liyl.sfhr.ClsNilzqakfd.metDymwfdjjlcu(context); return;
		}
				{
			long varUrjjtbpplvf = (Config.get().getRandom().nextInt(909) + 7);
		}
	}

}
