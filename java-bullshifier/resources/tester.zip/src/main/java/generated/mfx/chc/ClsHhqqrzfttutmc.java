package generated.mfx.chc;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsHhqqrzfttutmc
{
	 public static final int classId = 248;
	 static final Logger logger = LoggerFactory.getLogger(ClsHhqqrzfttutmc.class);

	public static void metIncutinrfri(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valPbzqzjjjblv = new LinkedList<Object>();
		Object[] valCckjblgrnhk = new Object[7];
		String valBaiaqotmplw = "StrGvrmnswyazj";
		
		    valCckjblgrnhk[0] = valBaiaqotmplw;
		for (int i = 1; i < 7; i++)
		{
		    valCckjblgrnhk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valPbzqzjjjblv.add(valCckjblgrnhk);
		Set<Object> valFhvhrgkmqbb = new HashSet<Object>();
		int valVjvkcwxevgq = 413;
		
		valFhvhrgkmqbb.add(valVjvkcwxevgq);
		
		valPbzqzjjjblv.add(valFhvhrgkmqbb);
		
		root.add(valPbzqzjjjblv);
		Map<Object, Object> valTbpaoldaudc = new HashMap();
		Map<Object, Object> mapValTvvzgpqoqfm = new HashMap();
		String mapValFxsansgkemy = "StrMnufizdejxv";
		
		boolean mapKeyVlntbspayfa = true;
		
		mapValTvvzgpqoqfm.put("mapValFxsansgkemy","mapKeyVlntbspayfa" );
		
		List<Object> mapKeyAjwvqpdzxrk = new LinkedList<Object>();
		boolean valBlppjcdobie = false;
		
		mapKeyAjwvqpdzxrk.add(valBlppjcdobie);
		boolean valDuiwgerxapz = true;
		
		mapKeyAjwvqpdzxrk.add(valDuiwgerxapz);
		
		valTbpaoldaudc.put("mapValTvvzgpqoqfm","mapKeyAjwvqpdzxrk" );
		Map<Object, Object> mapValBnqtgswzmmw = new HashMap();
		boolean mapValNgnnpfoergs = true;
		
		boolean mapKeyUmbawneobsz = true;
		
		mapValBnqtgswzmmw.put("mapValNgnnpfoergs","mapKeyUmbawneobsz" );
		int mapValJhizavcsnez = 4;
		
		int mapKeyQdgjgmotdrd = 499;
		
		mapValBnqtgswzmmw.put("mapValJhizavcsnez","mapKeyQdgjgmotdrd" );
		
		Object[] mapKeyPsgtzsrpjoo = new Object[7];
		boolean valUjlmhjahakd = false;
		
		    mapKeyPsgtzsrpjoo[0] = valUjlmhjahakd;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyPsgtzsrpjoo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valTbpaoldaudc.put("mapValBnqtgswzmmw","mapKeyPsgtzsrpjoo" );
		
		root.add(valTbpaoldaudc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Dtoganoczmym 8Uzuztndhx 9Ilputqawix 6Yazuers 11Futvdgtfkmtk 10Twzjaejwrwq 5Zinyio 6Nsbwpbu 9Trhvktfmye 4Iuykx 3Ydpj 6Ewkiyns 4Jhxqr 9Iqrbrdtltb 5Frfout 3Wmlq 9Bfliinnzml 12Lcjazdgtjzoer 4Vpnfz ");
					logger.info("Time for log - info 7Pvacvroj 3Dlyq 10Xolbhwdiapq 4Ezsyo 11Xnuaeucaykcj 9Csilphctna 11Awelqustvgkx 5Khronb 9Nwutnvizeq 4Dwdhl 7Yibsrjvj 11Jobkmiiuhjmq 3Ifuu 4Ynynu 10Riupuaahuby 4Oatqs 11Tnehujfgygsm 4Xkcde 7Ltpjkoci ");
					logger.info("Time for log - info 5Jmmbrl 7Fumohdwk 3Kfzq 10Vrupljnzens 9Fyyrmgketg 9Yemocbeeql 10Odmgecwwfrm 11Ubzgxlnpdxsq 6Bwdlsog 9Rvkgzumqxt 10Qwmemtexath 3Jtzy 11Xkzhncsyclgv 11Piqrcnxectpv 10Hgiaurcbgzv 10Xdmousqurzp 7Bcgneeer 12Zeagwgkoxvavt 7Aueikxok 4Adybx 7Byigwjfg ");
					logger.info("Time for log - info 4Vzrpw 10Zungsdpajoe 6Ztgetib 10Yqcnalpdkup 9Wqromgdgkd 7Hxqxcvhz 7Rresgesq 9Sqnvpilvlf 10Xlpmenznpct 10Crgvdmkqpsy 8Pvsjsknup 7Rscnuiuv 12Yjlrkoyyhmaiy 7Mzgtydyg 12Dxorlmvunrfly 3Gkow 9Repfkprols 10Iczsoqgrdhv 4Byttb 9Gdltflrpec 4Phvex 4Xaqwd 5Gyobkb 7Wtpsyurs 4Wczuo 5Jdprqq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Qjgpwnulmpw 5Bhkcfl 9Bssjmlzqxx 3Kytw 11Maxbrvdnjkut 8Ynwculbzx 4Frapm 11Dvgjglovpexj 5Invzjt 9Gxnrwqizen 8Rsxyujwqy 7Ofavldfi 8Hqtwscygn 10Raiieznftxg 4Snzyk 5Aafvfu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Npee 9Xnzsfbinis 11Vdbtgkhfykvv 5Jbakqq 9Ahfhkxkwni 9Skpkppbktc 10Swvnowdjpmq 8Tccdbjgeu 8Ngezsxchh 3Oroo 6Wvupmff 10Roaqgrcxicy 8Sqvecbflf 6Wbvfysa 11Fwjgnvtwqjar 4Takaj 11Hrhyemowuqqy 11Vxvaaydsdoaw 5Dyftrw 8Iygrwxyby 11Bjptuxlqwakt 3Whpg 7Sywxadxp 4Poesg 4Wpsnn 4Nczdg 6Dwztrxm 9Huwpiiwfot 9Hyocnuglrk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zmpxh.humct.jpc.zcr.uswj.ClsMmunby.metRokhpzyzafegb(context); return;
			case (1): generated.fyv.gdrcs.ClsDobveqqn.metEznzvmkjfe(context); return;
			case (2): generated.xxnyf.gha.ClsWohtztrryuonp.metBusawtcharn(context); return;
			case (3): generated.bnlmp.cvjtk.ocoo.ClsDyyxrbbjxtkmxe.metXclyxjwxnjpi(context); return;
			case (4): generated.ooziu.gzrop.rbg.ClsFthgefv.metEguhqfdvtpntfq(context); return;
		}
				{
			int loopIndex24390 = 0;
			for (loopIndex24390 = 0; loopIndex24390 < 49; loopIndex24390++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
