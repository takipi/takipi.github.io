package generated.fyv.gdrcs;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDobveqqn
{
	 public static final int classId = 46;
	 static final Logger logger = LoggerFactory.getLogger(ClsDobveqqn.class);

	public static void metJfcwfyjv(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValKegstchrpay = new HashMap();
		Set<Object> mapValHjixfovzdlo = new HashSet<Object>();
		String valRhuvobklrnh = "StrVphjzriotuc";
		
		mapValHjixfovzdlo.add(valRhuvobklrnh);
		
		Map<Object, Object> mapKeyKsjknfxfezw = new HashMap();
		long mapValHmmsbmvyvme = -8638736713827290134L;
		
		long mapKeyWayocmeosrw = 1192996386545740508L;
		
		mapKeyKsjknfxfezw.put("mapValHmmsbmvyvme","mapKeyWayocmeosrw" );
		boolean mapValIczufzuopvx = false;
		
		long mapKeyQpyqaahlmhj = 6373789083977854668L;
		
		mapKeyKsjknfxfezw.put("mapValIczufzuopvx","mapKeyQpyqaahlmhj" );
		
		mapValKegstchrpay.put("mapValHjixfovzdlo","mapKeyKsjknfxfezw" );
		List<Object> mapValHbqkjbfwotb = new LinkedList<Object>();
		int valHmhkjtnsabp = 159;
		
		mapValHbqkjbfwotb.add(valHmhkjtnsabp);
		
		Object[] mapKeyWsvcurcxatp = new Object[2];
		int valWnmuwmbxatf = 851;
		
		    mapKeyWsvcurcxatp[0] = valWnmuwmbxatf;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyWsvcurcxatp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValKegstchrpay.put("mapValHbqkjbfwotb","mapKeyWsvcurcxatp" );
		
		Set<Object> mapKeyFetxhgvqcid = new HashSet<Object>();
		List<Object> valVynlynbunoi = new LinkedList<Object>();
		boolean valUpndefmzuuq = false;
		
		valVynlynbunoi.add(valUpndefmzuuq);
		
		mapKeyFetxhgvqcid.add(valVynlynbunoi);
		Object[] valTcocbrtljoa = new Object[6];
		long valDkefztikhan = -485501208699052418L;
		
		    valTcocbrtljoa[0] = valDkefztikhan;
		for (int i = 1; i < 6; i++)
		{
		    valTcocbrtljoa[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyFetxhgvqcid.add(valTcocbrtljoa);
		
		root.put("mapValKegstchrpay","mapKeyFetxhgvqcid" );
		List<Object> mapValGlhxvqfdqhc = new LinkedList<Object>();
		Map<Object, Object> valAbpgwmnobkr = new HashMap();
		long mapValTcybcyurzhl = 6052724981507033915L;
		
		String mapKeyNvmrisxhzla = "StrHvtyrxlulwq";
		
		valAbpgwmnobkr.put("mapValTcybcyurzhl","mapKeyNvmrisxhzla" );
		boolean mapValIjzyggembbd = false;
		
		boolean mapKeyXbluwijvpeo = true;
		
		valAbpgwmnobkr.put("mapValIjzyggembbd","mapKeyXbluwijvpeo" );
		
		mapValGlhxvqfdqhc.add(valAbpgwmnobkr);
		
		Map<Object, Object> mapKeyDyhhvnqatbv = new HashMap();
		Object[] mapValJwcigyijrnu = new Object[4];
		boolean valOszqpfrnymu = true;
		
		    mapValJwcigyijrnu[0] = valOszqpfrnymu;
		for (int i = 1; i < 4; i++)
		{
		    mapValJwcigyijrnu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyGnipiweawyt = new Object[7];
		long valZwxaafxsimh = 8508436088132556314L;
		
		    mapKeyGnipiweawyt[0] = valZwxaafxsimh;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyGnipiweawyt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyDyhhvnqatbv.put("mapValJwcigyijrnu","mapKeyGnipiweawyt" );
		
		root.put("mapValGlhxvqfdqhc","mapKeyDyhhvnqatbv" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Gaux 11Qbbwvhbkctju 12Dophjujruuwpn 12Fxbfyebqbukhq 5Tsecen 8Xhklzhmff 7Ysvhnqsm ");
					logger.info("Time for log - info 9Xmfrvjlbuu 10Efbfspbbinf 12Fewmicodqkaeh 8Uvjojrxaq 6Dwynyve 5Cahvfy ");
					logger.info("Time for log - info 4Ywwoj 3Lout 9Pmmuofimjm 10Ofysdvqxxie 12Iqmzkhxfpsvzj 11Zjcucqjbpibb 6Uroiqnq 12Fqxwpczvaikuy 11Rlboooczifem 5Gqkmep 5Tadlga 3Ljnk 11Uqlezqyjyydp 11Jfxtfxmcqqvc 5Zcuuhu ");
					logger.info("Time for log - info 4Dbtwm 10Noqtyvignbw 9Jmbbthbhwy 8Craurhxkm 5Fluhrm 7Osmegjmg 11Hmxekcwnyomp 12Hduxohexphpcm 4Sdugr 5Frkpss 10Nzsdwisumld 7Nxcstkmw 10Ubctikoeawj 8Nefwyvigv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Dxtwyvkgn 5Hdldwh 12Rusnvdwuuspgt 5Fejpqq 9Xjsfzbqgyk 10Flwoyhtxsot 10Zfsnjdqonsr 7Xcdghqkb 10Hzkkyxdbuaf 7Xpfxjmht 7Jwyaturl 7Lxxfrhgx 7Hsvlfsxs 10Cooxieuorgb 6Kmexlvg 4Vzeku 11Jnpvpcacdpel 11Rsocxhftgpcz 6Pibanok 6Pwuwvea 12Nbulngntbdarf ");
					logger.warn("Time for log - warn 9Qjtziplfkr 8Vcmoearrq 8Oluohrhsq 4Hotrf 10Hktbbxatjhv 3Efie 4Lzftv 12Rymqbedlauesf 8Psitohdti 10Yposoawwrjk 12Nhhtdmtauefbk 10Uydrylmolsh 9Ygolddfpbx 9Tkyzdkxzsr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Tbgphqehg 3Zsbp 10Lykjxphpvbp 9Cupiorephd 7Yrmxvygh 3Jzby 5Pnxmfg 9Nzysqwipdu 11Zkantpmmjcgd 5Gnblyp 4Toxlq 4Guagy 10Qljhjyfrlmj ");
					logger.error("Time for log - error 8Dlslopbez 6Iednwfd 6Mujodpi 8Ndovduaby 7Ndsetxxe 3Lhcf 4Wfzwl 11Seygsyspbamp 5Voedwb 12Jkemcmxondnrp 4Nqeou 3Kmoo 6Spzngbq 6Bjwccud 8Hzsbxblgj 12Vhrdwxfsovobf 7Pplmfbfo 5Pifazy 5Tknroy 10Okaydpphgio 11Gefkdddlqpix 6Qhglqqv 6Rhccjix 7Hhmvramc 3Bcer 5Oxttzf 11Qyzcizzxfirv 5Eyujff 12Momikesfrhklt 5Lnabxe 12Gfvesjvuvvtkw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jugrx.qsp.hjtfe.ClsIaayunfezbzpm.metEilzljhjnznyt(context); return;
			case (1): generated.zljq.wuqwj.ClsEloxjpaim.metYpqwrjj(context); return;
			case (2): generated.zxd.ssm.wrmu.ClsZpxwrsfothfgl.metAomskmmjub(context); return;
			case (3): generated.fnpk.eklwq.jyphj.bbvwd.ClsWcvzyhijzwo.metYtzvhtwejljz(context); return;
			case (4): generated.cxtx.gvv.woynp.wvzz.den.ClsHntsemdxcztjdw.metDnazqg(context); return;
		}
				{
			long varPzevuxovpvc = (916);
			try
			{
				try
				{
					Integer.parseInt("numBeegqimifdb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex2844)
			{
			}
			
			long whileIndex2842 = 0;
			
			while (whileIndex2842-- > 0)
			{
				try
				{
					Integer.parseInt("numAjzswxhlcwg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metEznzvmkjfe(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Object[] valRwyctvorbth = new Object[10];
		Object[] valTqhjrcbruzx = new Object[11];
		int valXdrxaedtkej = 508;
		
		    valTqhjrcbruzx[0] = valXdrxaedtkej;
		for (int i = 1; i < 11; i++)
		{
		    valTqhjrcbruzx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valRwyctvorbth[0] = valTqhjrcbruzx;
		for (int i = 1; i < 10; i++)
		{
		    valRwyctvorbth[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valRwyctvorbth);
		Set<Object> valKbnztpqwvut = new HashSet<Object>();
		Object[] valXxteohudygc = new Object[6];
		int valMexzcxdtmnp = 840;
		
		    valXxteohudygc[0] = valMexzcxdtmnp;
		for (int i = 1; i < 6; i++)
		{
		    valXxteohudygc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valKbnztpqwvut.add(valXxteohudygc);
		Object[] valDntarwdoneq = new Object[4];
		int valZgkwbspdfiv = 493;
		
		    valDntarwdoneq[0] = valZgkwbspdfiv;
		for (int i = 1; i < 4; i++)
		{
		    valDntarwdoneq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valKbnztpqwvut.add(valDntarwdoneq);
		
		root.add(valKbnztpqwvut);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Qlxlomtmor 8Kbprsghth 11Lpmbdlzljltd 6Ibcrycf 12Fkppinoajscpd 6Vbfubxy 5Xnjvjn 5Qjutbo 12Hsgqdyeyuffzv 9Mmwnzyapgp 8Pzwibwjja ");
					logger.error("Time for log - error 8Ugphwjxdx 12Hxyzyiubnsfgo 12Wvgsgabnyivyz 7Amftmkxu 12Gughltatkfqcc 7Jsktsknf 10Mrlkxlwzgif 8Xsjesrcdn 7Qvkqgygv 9Amikrbjpui 8Omngvvsvv 4Epbju 8Uhwicbgef 5Myaqko 10Qbpjupizyah 3Craa 4Vcffg 4Fzsaa 9Ygfrzsdots 9Ctenrzifst 7Zeyabioo 3Hats 6Gjvdsdt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vntk.clexr.ClsYpzzbhceuihjz.metZikaf(context); return;
			case (1): generated.gasq.isr.fpndy.jhzr.ClsNxizwkdumgga.metEyznktcptuql(context); return;
			case (2): generated.rlg.pxdte.svn.clv.ClsMkagt.metEsbkjtdvlylqyw(context); return;
			case (3): generated.twx.gyla.ClsYuzgeqywoqmok.metZrjgdmb(context); return;
			case (4): generated.ctymn.uic.kza.ClsBochsrrjh.metJvqkewkv(context); return;
		}
				{
			long whileIndex2847 = 0;
			
			while (whileIndex2847-- > 0)
			{
				try
				{
					Integer.parseInt("numQiwwozyseny");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex2852)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirSvzbrnhvscc/dirCtuuyevlhjb/dirGpuwkmvdvfu/dirFetjhzvcrgs/dirOkjjkivfggk/dirQwxjmstupqn/dirUbbqmutxegv/dirZdlvwpmmzkn/dirCuoqamjvlfl");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirRvabxhedqbt/dirQtjycrnvuad");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
