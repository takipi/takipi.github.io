package generated.qpe.ifudp.xgatn.jzg.qau;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJymdeqopgpbo
{
	 public static final int classId = 123;
	 static final Logger logger = LoggerFactory.getLogger(ClsJymdeqopgpbo.class);

	public static void metZmvopmy(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valWpvxezvyfeo = new LinkedList<Object>();
		List<Object> valKcleowqhvmt = new LinkedList<Object>();
		int valZditrrenfgc = 175;
		
		valKcleowqhvmt.add(valZditrrenfgc);
		boolean valWaxonahwkve = false;
		
		valKcleowqhvmt.add(valWaxonahwkve);
		
		valWpvxezvyfeo.add(valKcleowqhvmt);
		
		root.add(valWpvxezvyfeo);
		Set<Object> valJhvmjrqgcjk = new HashSet<Object>();
		List<Object> valMgvircideqr = new LinkedList<Object>();
		boolean valIjpuudmjczn = false;
		
		valMgvircideqr.add(valIjpuudmjczn);
		
		valJhvmjrqgcjk.add(valMgvircideqr);
		
		root.add(valJhvmjrqgcjk);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Qtkjole 5Tfbmmc 7Jdzpmtkk 9Yzfbiudugt 3Zuwm 4Wiqlz ");
					logger.info("Time for log - info 10Sdfobmigvwp 7Vzkbaaxi 3Liws 4Czapt 4Ywdkm 11Qfxfrjkflaak 11Ojgvxbnigbum 11Fnqqdpmpjwkf 9Wchmfjlpzi 10Ludcedgsbwn 12Sqgsqkmsphvcc 8Veefjgbqr 4Tstjr 7Rbddfxxs 5Lzsiyk 9Muzitfbmol 11Jrsgstdhofnn 6Eqptrvd 7Jfeynwln 8Cnvqfosou 10Tnwgjdsldcz 5Bjigsd 5Cdnzqc 12Dyxjwhtjzunws 10Kwirflxdcem 12Jxmbqxwxavdxk 11Npmcuyefdqwy 6Tgecpon 8Wrizztsiz 3Kpae 3Ipsu ");
					logger.info("Time for log - info 11Zcjshtnnqynq 10Nyhdocujido 8Yoidasjvf 10Pouyrebwbgw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdhb.psopx.ivn.rkn.apqvp.ClsKaatjkanbespks.metLvjabphis(context); return;
			case (1): generated.ebl.tdhe.hblqj.plazc.otajb.ClsEihhumwr.metZzqrbtidxpltas(context); return;
			case (2): generated.idk.jvavb.vjuwp.iuzf.fawz.ClsRtwkffyfhbvpjl.metHdimsltzwuwz(context); return;
			case (3): generated.kfvy.ymxa.end.hazk.nwqfn.ClsXakhsfoyrlse.metJcgkp(context); return;
			case (4): generated.wwtht.wyffd.ClsDnoox.metFwosjn(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirMgxmvulkvfy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex22225)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirWngisfncbso/dirUbajzwjrhol");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metKphqyqlpqj(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValZrcgvurseqr = new HashMap();
		Set<Object> mapValEgzmypmouob = new HashSet<Object>();
		boolean valNqfadgflnon = false;
		
		mapValEgzmypmouob.add(valNqfadgflnon);
		String valIpzkutxxpye = "StrAdisroduxnw";
		
		mapValEgzmypmouob.add(valIpzkutxxpye);
		
		List<Object> mapKeyMpfgdqhyxhx = new LinkedList<Object>();
		String valNqcnydjhyqy = "StrRcpbnmlnarg";
		
		mapKeyMpfgdqhyxhx.add(valNqcnydjhyqy);
		boolean valVolyimhzqgw = true;
		
		mapKeyMpfgdqhyxhx.add(valVolyimhzqgw);
		
		mapValZrcgvurseqr.put("mapValEgzmypmouob","mapKeyMpfgdqhyxhx" );
		
		Set<Object> mapKeyYtujovjqldj = new HashSet<Object>();
		Set<Object> valUiypofzlidb = new HashSet<Object>();
		String valFidolfyqgfq = "StrCvweeumdzpd";
		
		valUiypofzlidb.add(valFidolfyqgfq);
		int valTmezfcnnazp = 50;
		
		valUiypofzlidb.add(valTmezfcnnazp);
		
		mapKeyYtujovjqldj.add(valUiypofzlidb);
		Object[] valCrcinqoeuca = new Object[9];
		boolean valKmwdokxvswm = true;
		
		    valCrcinqoeuca[0] = valKmwdokxvswm;
		for (int i = 1; i < 9; i++)
		{
		    valCrcinqoeuca[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyYtujovjqldj.add(valCrcinqoeuca);
		
		root.put("mapValZrcgvurseqr","mapKeyYtujovjqldj" );
		Set<Object> mapValHvykbogzqej = new HashSet<Object>();
		Map<Object, Object> valYhwzsifpocy = new HashMap();
		boolean mapValMstusaesagq = true;
		
		String mapKeyUbuvivalpxc = "StrIhepmxdlvyh";
		
		valYhwzsifpocy.put("mapValMstusaesagq","mapKeyUbuvivalpxc" );
		long mapValGtlhutxhqvq = 5848570964057687736L;
		
		boolean mapKeyQysmebxcnbt = true;
		
		valYhwzsifpocy.put("mapValGtlhutxhqvq","mapKeyQysmebxcnbt" );
		
		mapValHvykbogzqej.add(valYhwzsifpocy);
		Map<Object, Object> valJfuouxsrmho = new HashMap();
		String mapValQutbonvjqzf = "StrEdrnckbnrco";
		
		String mapKeyQisunxcnaoa = "StrOzzwllfqxze";
		
		valJfuouxsrmho.put("mapValQutbonvjqzf","mapKeyQisunxcnaoa" );
		boolean mapValGhrooyupatu = false;
		
		int mapKeyXtxsrxyawno = 701;
		
		valJfuouxsrmho.put("mapValGhrooyupatu","mapKeyXtxsrxyawno" );
		
		mapValHvykbogzqej.add(valJfuouxsrmho);
		
		List<Object> mapKeyKhwymcojset = new LinkedList<Object>();
		List<Object> valPeppbmvakbt = new LinkedList<Object>();
		int valIiyewslxfbw = 663;
		
		valPeppbmvakbt.add(valIiyewslxfbw);
		String valFjjmneyxomy = "StrGxomrbgilry";
		
		valPeppbmvakbt.add(valFjjmneyxomy);
		
		mapKeyKhwymcojset.add(valPeppbmvakbt);
		
		root.put("mapValHvykbogzqej","mapKeyKhwymcojset" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Omuavudldciy 3Rhae 9Rxrmrviydn 9Jibymrxyfb 8Vrfiponax 3Atak 9Ccqzhbzvye 6Poyzdbv ");
					logger.info("Time for log - info 4Ekgoe 8Kdeiwasaw 8Jpdgfwqwf 12Rzfjkewysyrgu 9Gwsbuzdahw 11Arazbfbwwtiu 11Aarrzgulurgk 11Gsvkbjymxpbp 12Cwjoxcorchysk 7Rzuvcopo 6Sjewuoi 5Zxbnek 6Zpgzfjw 5Vsvkmy 4Vbqaa 10Qkqdbxyxxvp 4Qxzaf 3Ufjg 9Xetqjzkqlm 3Dfli 10Aabhfajnmzy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Gbnukwtai 8Lryhaqtkv 11Hppvzcpjnokr 4Oghtz 11Soqxovmxzalr 5Mcqvyf 7Gyvrxfud 4Txstv 8Bguqfcsim 7Flmofxbr 5Xvrkcs 4Fzndy 6Afurkgr 11Gjtklvihkvdi 12Jymluxjlnrdez 7Ycabaxxf 6Ryvheva 6Jraxtvi 12Ytddlygbfyzrj ");
					logger.error("Time for log - error 3Fxhm 5Ncytgg 9Bhkejjyfmi 6Wmmxuie 8Agwqtvohw 5Mfoxke 3Delu 5Rtldeo 10Gyjdsphvlfb 10Kjxkoaeviss 3Fusm 5Mulmmp 6Phntcul 8Jgwdzsttb 12Lihdbfqjlxfzl 3Hgyn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bhfun.zpnwj.czfe.augg.ClsEdcxpvndelttu.metUlhmbyyc(context); return;
			case (1): generated.wvkuf.rvtq.kcgfs.vezg.ClsKfeffw.metYhvpbcd(context); return;
			case (2): generated.wtc.bgb.gahv.mul.rts.ClsUeuxdzs.metGmiqxl(context); return;
			case (3): generated.weide.dnna.unvd.vtw.pcbre.ClsExwicwtb.metBepkcxgkgvlun(context); return;
			case (4): generated.afllp.gwt.xvrk.rxvp.rryr.ClsQsqze.metJjhfwnwz(context); return;
		}
				{
		}
	}


	public static void metNcpaipo(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[6];
		Object[] valZusmombzhvc = new Object[2];
		List<Object> valXlpmszgcbvp = new LinkedList<Object>();
		long valInpskhnbwos = 707635138943719963L;
		
		valXlpmszgcbvp.add(valInpskhnbwos);
		long valMmnehqmtnds = 2646169126538081302L;
		
		valXlpmszgcbvp.add(valMmnehqmtnds);
		
		    valZusmombzhvc[0] = valXlpmszgcbvp;
		for (int i = 1; i < 2; i++)
		{
		    valZusmombzhvc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valZusmombzhvc;
		for (int i = 1; i < 6; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Xyivh 12Ewreodowwxiwt 7Iejalsuq 9Yuoukqsjcx 11Rddzakanmekz 8Ahxwrguwh 10Okjbszozgje 7Fmihtesg 4Wggqj 11Roghkhiaxfth 8Bendruqym 7Zjwncptm 8Vinlmlnig ");
					logger.warn("Time for log - warn 10Nnzcxiwtgrs 9Zndmlrctpg 4Dkubs 3Liff 5Uwibwv 5Esqrra 3Tbgu 6Smojcgx 9Ewqawyucqo ");
					logger.warn("Time for log - warn 12Wlhwcpijajrdd 7Ggresijm ");
					logger.warn("Time for log - warn 5Vxljtx 6Exlsdde 8Ljvsymxvb 4Caxgm 12Yjbuomivkddvl 12Eywrinogjrfry 7Ndpknjds 6Grjuclo 10Rsbhiwwlnli 3Wsqk 12Plkjjiaxpyiyg 7Aaarvvui 8Xghwhhzth 12Aucnapnofszch 8Gkurztfnq 10Nvkpxwrkgfa 8Qyodkgutd 5Uymkyq 10Iszpaacqitv 9Vabveisoyw 6Axrzosb 9Xzjufqsmnw 10Bnehpwlrvpa 5Mtkpzp 6Cfovhhj 9Vuhofxvbcm ");
					logger.warn("Time for log - warn 6Nthisvg 9Znzyosvwxs 6Kqowisg 3Mwqr 7Uazxqyye 11Qfkfduelfvaf 3Auer 12Krhfodicpwlzc 5Vndamf 6Eghmynm 8Uvfjnzafa 8Llacnxqrf 4Ogxiw 3Sxto 8Jvmvoepqp 4Orreb 3Cmzm 6Rjqpeni 7Uybfbsoy 6Rbxnkkm 7Fouzthui 8Srtpgxgzh 4Ladzo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Frldgwtplv 8Alnksclot 7Phptquji 3Grnx 6Brsrkqt 8Dbgzssbcp 12Rjevvvcbsqglz 7Qeaitnhz 10Hykobdbukoz 7Xbbtcnmm 7Imynlxsw 8Mzuyiwkql 3Esqp 3Bzpx 9Oyzgwphpsz 11Wtfsymviqppv 4Asset 5Eccsev 4Wnayh 11Wzddygoiupwe 12Ijlruikbunpol ");
					logger.error("Time for log - error 9Jhdxnrbcai 5Hyjldc 6Isanyfx 3Hhkk 10Kkzmvsnsdow 5Thgmnh 9Corfszgyxu 12Rodlvmfptyxmo 12Vpnqtpmxmwrar 4Yjpbi 3Tspm 11Nywcgbbylwkq 3Yquy 12Roipwdjksifkd 10Cumvimbsuaa 5Sggjcb 4Smowl 12Jgaylacnfywsg 11Wjxwxdxtsxzi 4Ybqga 12Aptcysqzjtoww 4Jjxax 10Pdoxfocfbqm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bywcf.xycgt.wqguo.ClsDsjomnr.metDdfotoep(context); return;
			case (1): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metJvnsuyubxdox(context); return;
			case (2): generated.zhzbs.ylhl.ytr.cges.stvq.ClsYeenuinrut.metRuxodvwf(context); return;
			case (3): generated.duzy.rxrsw.ClsQbnde.metFgxdseboz(context); return;
			case (4): generated.ewz.kir.rqdl.wup.ClsTcnbjngxap.metXatmnfjmhsznde(context); return;
		}
				{
			int loopIndex22235 = 0;
			for (loopIndex22235 = 0; loopIndex22235 < 5812; loopIndex22235++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metRgioipeguamkhy(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[9];
		List<Object> valHdmgijitriv = new LinkedList<Object>();
		Object[] valCxztrdloxse = new Object[7];
		long valLsktfgcarkd = 3090041227752167804L;
		
		    valCxztrdloxse[0] = valLsktfgcarkd;
		for (int i = 1; i < 7; i++)
		{
		    valCxztrdloxse[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valHdmgijitriv.add(valCxztrdloxse);
		
		    root[0] = valHdmgijitriv;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Uucr 4Raugz 8Dwazvhvuf 4Pemjk 8Mvyzypeuz 4Vfgqw 4Rbcwd 3Lllf 12Gvdyzccapsdlq ");
					logger.info("Time for log - info 8Plpmlwdmh 8Lqvwdgeah 3Iesn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Mclbfmfx 6Wcsiljv 4Pmsan 4Mbcrc 9Mfjjdqdgdv ");
					logger.warn("Time for log - warn 6Apgqzba 9Axeoxhrmtx 9Fdpbapzses 5Zpnmvh 10Irtlqeeoizp 3Tqno 9Npbompfedp 12Fxklvftuhtzrk 7Xiyvfzhb 6Bzowozu 4Jksok 6Fhympez ");
					logger.warn("Time for log - warn 3Rale 11Owgkhtijlhxt 4Ktyoa 12Delgorxkvuajw 6Gasajjj 10Tvbepwchdyt 12Qrkedbzzgdxek 8Gmfyhpztq 9Prdndhprmk 3Xgkt 7Bbzyytyj 6Iupebrv 3Olfx 7Xqgtrqkg 11Evlqijyqdxfe 9Pcsduavztg 8Xtkxrubqu 11Wyxevfxtgbdh 5Hldjvp 7Jufrcdlu 7Tparnfwe 12Cxbyfvvchtker 9Uthoszvdgq 10Vipdchxefsu 3Kwac 11Lroczqjaspor 12Bkkeiunqnffdl 8Jcuiuqmmk 7Fcnxhklm ");
					logger.warn("Time for log - warn 4Yewwf 8Xxgbvffmp 6Xrftqbv 9Ejgnpajbrs 8Fxcifinwx 3Utkj 4Qwxwe 11Othfvemyyein 3Fdln 3Jivt 5Junsyv 10Rzuizixabnk 4Tesyg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Sypfbfpii 3Huyb 4Jlklh 5Qsklrf 6Gykaqmc 4Nvyhn ");
					logger.error("Time for log - error 4Kjncl 9Pboutjopdp 3Ybjw 12Qidpyxebkfznm 6Fqynofs 3Smom 5Lvlzoh 9Kdrialhhsw 7Ukcrdgik 4Xwdpt 12Gkhohrbmtdynf 12Jfjbxyyvjoidy 7Ooflvnze ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hioa.tbao.juo.tlh.zgppg.ClsZtwfn.metIybrdbhypesv(context); return;
			case (1): generated.hiv.mgg.zog.vzpz.ClsYqryx.metCoemu(context); return;
			case (2): generated.uym.yiu.voiig.deif.ClsUwvuontynja.metIvjieifumyhc(context); return;
			case (3): generated.wvctc.whp.ftjy.ClsPwdcftvpjt.metRruqnnklvvnmp(context); return;
			case (4): generated.sttvf.uvyp.navra.vntc.wlw.ClsLyfkosygvnxgsh.metWuyudxzkmbkah(context); return;
		}
				{
			if (((9542) + (4295) % 87072) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((7081) + (2747) % 784198) == 0)
			{
				java.io.File file = new java.io.File("/dirWlzzehypuro/dirWqylqeatsdf/dirFmjgmjwplbv/dirLojlqjsydhp/dirCgtllfkzakb");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numKcsgdhyllhk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
