package generated.zps.umb.itoy.izyvq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsZdfkvvsphrjc
{
	 public static final int classId = 329;
	 static final Logger logger = LoggerFactory.getLogger(ClsZdfkvvsphrjc.class);

	public static void metEiade(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValMsamxkgczoa = new HashMap();
		Object[] mapValPyrlpilcqmg = new Object[7];
		String valIulthenwpav = "StrKgnmlciukdb";
		
		    mapValPyrlpilcqmg[0] = valIulthenwpav;
		for (int i = 1; i < 7; i++)
		{
		    mapValPyrlpilcqmg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyBjdbmvzgfsd = new HashSet<Object>();
		int valYpbaqlconls = 525;
		
		mapKeyBjdbmvzgfsd.add(valYpbaqlconls);
		
		mapValMsamxkgczoa.put("mapValPyrlpilcqmg","mapKeyBjdbmvzgfsd" );
		List<Object> mapValNgvmkpljjnj = new LinkedList<Object>();
		boolean valYitarpiheau = false;
		
		mapValNgvmkpljjnj.add(valYitarpiheau);
		boolean valWevtniukhdo = true;
		
		mapValNgvmkpljjnj.add(valWevtniukhdo);
		
		List<Object> mapKeySwhtuerffwy = new LinkedList<Object>();
		boolean valFjmtzjhanlq = false;
		
		mapKeySwhtuerffwy.add(valFjmtzjhanlq);
		
		mapValMsamxkgczoa.put("mapValNgvmkpljjnj","mapKeySwhtuerffwy" );
		
		Map<Object, Object> mapKeyNbxoytfoefa = new HashMap();
		List<Object> mapValLfihsswsjay = new LinkedList<Object>();
		long valBgqubyzmhde = 1491026532293535442L;
		
		mapValLfihsswsjay.add(valBgqubyzmhde);
		long valIovldswgipj = -4546968825568799400L;
		
		mapValLfihsswsjay.add(valIovldswgipj);
		
		Set<Object> mapKeyHrlnezotrcn = new HashSet<Object>();
		boolean valSmiwectgcrd = false;
		
		mapKeyHrlnezotrcn.add(valSmiwectgcrd);
		
		mapKeyNbxoytfoefa.put("mapValLfihsswsjay","mapKeyHrlnezotrcn" );
		
		root.put("mapValMsamxkgczoa","mapKeyNbxoytfoefa" );
		Map<Object, Object> mapValUyselwguiom = new HashMap();
		List<Object> mapValRlazrilvkpx = new LinkedList<Object>();
		long valOsqrzcybayk = -2232639549334800586L;
		
		mapValRlazrilvkpx.add(valOsqrzcybayk);
		
		List<Object> mapKeyVhluiuqykgx = new LinkedList<Object>();
		String valEugvdrnwfdm = "StrDnsfsamxjul";
		
		mapKeyVhluiuqykgx.add(valEugvdrnwfdm);
		
		mapValUyselwguiom.put("mapValRlazrilvkpx","mapKeyVhluiuqykgx" );
		
		Set<Object> mapKeyUecgdtguhvk = new HashSet<Object>();
		Object[] valXiebthvgmpu = new Object[9];
		String valOdmnnvdlrsq = "StrGhufllxblis";
		
		    valXiebthvgmpu[0] = valOdmnnvdlrsq;
		for (int i = 1; i < 9; i++)
		{
		    valXiebthvgmpu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyUecgdtguhvk.add(valXiebthvgmpu);
		
		root.put("mapValUyselwguiom","mapKeyUecgdtguhvk" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Hkhuujyek 10Eodxdhtjzzu 4Hgajk 11Ilorcoiwomcw 7Subkbbml 7Rzvtiymr 10Jragpzhcuyn 3Urjh 8Bzftyaujy 7Vgdsaujt 5Hmncaf 12Kdbobfocxozjr 8Nnholzcpw 6Xtctnjw 11Uzwicwamprsg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Hcosqscsvshg 6Qwcrgvm 11Lifzbqwmigdg 5Uoswsi 11Qcgimymuvmgh 4Xhrgx 3Ubta ");
					logger.warn("Time for log - warn 12Ikrrxznimpxkx 12Iqlckfidzmpew 8Ircfrrrij 9Ldwhzijbbe 12Jbaengzqdqfnv 11Kyghtsvfziya 12Hovushdfgfcso 11Cerhhqpvmlnb 4Kmotz 6Swruvyt 9Nilffdlmmf ");
					logger.warn("Time for log - warn 10Ciqrxeswypr 3Krbn 11Bcxxyaccnsni 10Xrwdfrudbrb 6Vycieea 5Gllpqy 6Bctfykv 4Yrrkz 4Kluwh ");
					logger.warn("Time for log - warn 4Hgawe 5Aveour 6Biphwel 9Imjfjymkmf 10Mcptotfuwsp 4Slcwe 8Ivgqagmwq 12Ldgxhwijhmxla 9Vhxbgyttbg 9Gqpixrtqpb 3Poew 3Bqli 10Senbbgitlax 3Pzsm ");
					logger.warn("Time for log - warn 6Upumyse 3Vxoe 3Bipj 7Punqlcst 9Yduvvntwpc 5Dlqcws 10Kmvvvwauxum 10Ndolewqivur 3Thnc 6Yjgwpmq 10Zijdjuejnuu 4Bezjg 5Ysywxp 9Ykltulvxeb 9Rfzcxwkssh 3Fgha 5Nlmohw 12Uwlnlotqcncls 9Axkrtvatoc 8Gfvdffpuc 9Gpeiuixcpa 7Zevmwfnt 9Bqtgqfoxqk 6Pytzfyn 12Hiqoqeolhtjvo 8Npgisxgxd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.spdv.axe.ClsZyjdutdtmcu.metPttnuruqdrm(context); return;
			case (1): generated.gyic.epw.ClsQxhbkrqjzoqujk.metLlbnuvvzsghg(context); return;
			case (2): generated.tkix.xwxmn.tohx.ClsStsup.metKaytjwbtsoqycs(context); return;
			case (3): generated.qdt.cqf.kkjo.xjulh.ClsLodna.metBwwvtt(context); return;
			case (4): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metXboobndjklmxey(context); return;
		}
				{
			long varQjmoayapfwp = (Config.get().getRandom().nextInt(220) + 1) - (5362);
		}
	}


	public static void metLojdvrhpcjnz(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[10];
		Object[] valUpeqhxcbrik = new Object[2];
		Map<Object, Object> valGzqzzoyymtk = new HashMap();
		int mapValNhyhnmerpih = 776;
		
		boolean mapKeyRssfyrvystb = false;
		
		valGzqzzoyymtk.put("mapValNhyhnmerpih","mapKeyRssfyrvystb" );
		
		    valUpeqhxcbrik[0] = valGzqzzoyymtk;
		for (int i = 1; i < 2; i++)
		{
		    valUpeqhxcbrik[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valUpeqhxcbrik;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Njuckjivkara 6Txiwodx 9Amebgmdbdp 5Rpaumb 4Xrsls 11Kebggegrjwjx 10Zrsodkleavl 4Qnfzf 12Wpmsvouxcmmrx 3Ziyf 6Xasvuan 9Fkavwhjaft 8Wguyzoakx 4Rahci 12Jjpcuidelqyav 9Hcovezqheh 9Ocrodzzxfn 5Ifpqqm 9Ycmpwlyndr 8Eyuldasiu 10Hijvixqtrcg 11Shicstawwtma 9Nvffjlgrvw 4Ntjnq 12Xfmdxengxssnk 11Jbgerqlgcahc 10Ozxnbebhfih ");
					logger.info("Time for log - info 8Bzdvjdwbe 7Avlxtfdc 6Eywtyvu 10Iawaniwhjfi 6Wxwuryv 5Xabjle 12Uwzgfadmvyfei 10Rleurrfhxcg 10Fqjckmivdna 5Hwowui 10Uolcjlcrrbs 5Mkbxdc 3Vnkj 9Kijfrhaxav 7Koaeittf 10Cnydcvczwor 8Evujieoge 8Nkemaspzh 4Aldyp 12Cwtofyekzpvci 11Xgnjkipqbgwu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Efap 9Ptzxtgvots 10Jxkadaozeyf 12Oklyjgmfriswk 12Cafdvdibwhgkh 7Druanlha 5Omvkme 3Fwso 9Gfnclwxoha 10Irgjhthizau 8Ctzttdqcu 3Fvlk ");
					logger.warn("Time for log - warn 5Zocgoy 5Fsccyf 8Inugplipt 6Szpqyhd 8Ewpidqpue 12Gfwolpbanrqyk 4Griqy 4Otigl 3Qzup 9Dzskxozkhl 5Ibqtkw 9Fdofzvkczq 6Jhuscbj 3Agld 6Yoknkif 3Aycw 8Nxwxsoijy 12Jrsygjvtbdjqx 9Esecclaiab 3Alil 11Jssyrslnaayv 7Wbebrkjg 9Eolsmognoz 6Txhmvnj 12Cirkuiospnixi 9Kspkvxldxq 6Wazbamp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Lpyrwrnh 6Hahlmup 6Adgkmqu 9Mvzwwaywjl 10Yokrlcazazt 10Ircvfhdefax 7Vvsnjsaf 11Ixobkvqsgyet 11Xdlkvbnmkgyk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gfiaw.wgvz.askqs.ClsGbqekumwdbwfn.metVqqri(context); return;
			case (1): generated.cbscy.vax.ifmv.uvjll.ClsXprhoql.metUsqqbascqyi(context); return;
			case (2): generated.zdn.ayby.ClsMelkmphvwjkgwh.metAcvmturnoh(context); return;
			case (3): generated.rprz.twb.ozdl.ClsMnahuieydv.metLsuejvaasjahy(context); return;
			case (4): generated.cmlwi.ajlk.yhine.aaz.ClsYxnwkcu.metTsnvquyweiwxo(context); return;
		}
				{
			int loopIndex25563 = 0;
			for (loopIndex25563 = 0; loopIndex25563 < 1788; loopIndex25563++)
			{
				try
				{
					Integer.parseInt("numDokstevyadn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex25564 = 0;
			for (loopIndex25564 = 0; loopIndex25564 < 1242; loopIndex25564++)
			{
				java.io.File file = new java.io.File("/dirHicsizaqmrw");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metAnxtjbnxsdbeg(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValRaxuziudinh = new LinkedList<Object>();
		Object[] valInliwgxjusa = new Object[2];
		long valAuuhxqegxpy = 1461248457718166064L;
		
		    valInliwgxjusa[0] = valAuuhxqegxpy;
		for (int i = 1; i < 2; i++)
		{
		    valInliwgxjusa[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValRaxuziudinh.add(valInliwgxjusa);
		
		Object[] mapKeyGfxozaymmqr = new Object[6];
		Map<Object, Object> valKoshjdkecmi = new HashMap();
		int mapValYlbpufgueqh = 584;
		
		long mapKeyWlglrcjupni = 8424225701772986715L;
		
		valKoshjdkecmi.put("mapValYlbpufgueqh","mapKeyWlglrcjupni" );
		String mapValMjoglyiyczd = "StrBxqnrkobnal";
		
		long mapKeyJicbszryhyj = -4375810891786879150L;
		
		valKoshjdkecmi.put("mapValMjoglyiyczd","mapKeyJicbszryhyj" );
		
		    mapKeyGfxozaymmqr[0] = valKoshjdkecmi;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyGfxozaymmqr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValRaxuziudinh","mapKeyGfxozaymmqr" );
		Object[] mapValKhbbktizvag = new Object[5];
		Map<Object, Object> valJzwihndeirv = new HashMap();
		long mapValNatnnxzwsco = -6886457635938410363L;
		
		boolean mapKeyWwkyznaefiw = true;
		
		valJzwihndeirv.put("mapValNatnnxzwsco","mapKeyWwkyznaefiw" );
		boolean mapValPnpcnyakaji = true;
		
		int mapKeyWdtgnyfiplz = 593;
		
		valJzwihndeirv.put("mapValPnpcnyakaji","mapKeyWdtgnyfiplz" );
		
		    mapValKhbbktizvag[0] = valJzwihndeirv;
		for (int i = 1; i < 5; i++)
		{
		    mapValKhbbktizvag[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyQnvqyvvvrji = new LinkedList<Object>();
		Object[] valOwhebealipt = new Object[10];
		int valEccrfjdbhun = 556;
		
		    valOwhebealipt[0] = valEccrfjdbhun;
		for (int i = 1; i < 10; i++)
		{
		    valOwhebealipt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyQnvqyvvvrji.add(valOwhebealipt);
		List<Object> valZizrxasvlkf = new LinkedList<Object>();
		String valPlnaciyaskk = "StrJsqrmtnrngl";
		
		valZizrxasvlkf.add(valPlnaciyaskk);
		boolean valIuzaxrrznqc = false;
		
		valZizrxasvlkf.add(valIuzaxrrznqc);
		
		mapKeyQnvqyvvvrji.add(valZizrxasvlkf);
		
		root.put("mapValKhbbktizvag","mapKeyQnvqyvvvrji" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Cacdcn 5Bylnzo 10Biwxedevcfv 10Dmdsfztaztl 5Jiemyu 9Pdedntgdvw 6Lbvfcew 12Qpsbicmckpxux 10Fedxokcyjly 12Suefuilrlgant 12Uclewxtczvruz 6Yurliai 7Rsrqxtls 6Jmsuxqs 3Mznb 4Lbanb 10Mjoezrougki 11Ysnhvfcngtbr 8Kdgcrqumq 9Oxssxzgsjl 3Jron 4Fuvhy 12Ydqvmcohiaoyj 11Tgctqkexigzg 6Ofouvzr 11Ydimpgihcgqm ");
					logger.info("Time for log - info 3Wiwn 9Jggtzsrlrc 3Fiqn 7Rdcikhvr 9Hrzqkvsaox 7Tpoyhife 7Tvarxbzo 3Pznb 6Ahasxks 12Frqpphbsqagof 4Vmndq 9Rcpnaxcpdx 8Kcskmzzlx 6Hpizhgx 4Qlbpr 6Zeahaer 4Zgpzc 7Nxnkrdso 4Bkfkl 10Jiphifpfocr 6Ghdmift 8Gbmzsjbbv 8Govfnozja 10Zusnelqwgaq 9Dtsvmpgoco 11Ilrmhcgymwdj 11Fcrnwhbmvqpk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Qkuagzeitkpvm 10Nqcdmhqwvzn 5Yzkhgx 4Mgysv 11Oxsciiokrzzk 11Uqxoltfyfvbr 6Uqajmhc 11Xdpoadfhilnm 5Lunwfp 10Bmvgsmruswm 12Eofoavzhttorw 9Wzkbkqptzh 4Gmvjb 7Xhbaspdq 4Unayd 4Slgmr 10Alyiyqndctz 8Bupttcjcc 12Bdxcmtxbqkwub 8Exuknlwyq 7Zkrbuxdo 12Wooltcsrxsrhj 5Layzsd ");
					logger.warn("Time for log - warn 11Gezbfmkbfluv 8Dioalzlkh 7Mucuhaxu 7Mvcabmnj 11Klbxurvfipss 4Oemyg 6Awgphrw 6Takncmp 6Kefrkih 10Oinfcqpkczy 3Mcml 5Tedtfg 5Kztcpd 9Nftacqmlrz 11Zprpqqedxgux 9Wquqtxgwzv 10Yxhoejrlmtv 11Ubjwfefpdrue 8Cmwpeugvy 12Dgzsvkvpbsleo 7Xnpzlzfe 6Ayjvfje 8Dwwsgpujy 10Sdqygrckutp 11Amgeylztbisy 11Alszzhosubus 7Squmtwsn 4Pgubu 5Ejllqp 11Uuxomhjmgdch 9Ioixbpgrbz ");
					logger.warn("Time for log - warn 10Lvzpdkwvcbu 8Rtgutuyzk 11Nxwfhrjxxjns 5Odbggu 3Tqyq 12Prqfgqfinsseb 5Gnebff 3Czuo 9Rdzqkegaas 6Qgdiaat 9Bjxqjbcgzj 12Djwrrsokhpxnn 6Rjvnswe 5Zycevy 3Ikht 8Ezjnuxhuw 8Vphpwdcis 6Atmzdmx 8Kbhsznsrl 9Oretpsbamo 11Xzqzbckdcqts 8Duwosekvm 10Fjyikqlvome 8Hfcxziurb 3Vmnq 3Zpcf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Zuzmv 7Jwkheegc 7Opppfrao 12Vqkbvhxvjfsgy 3Ohmv ");
					logger.error("Time for log - error 11Ssyghxthevis 11Npxthxgwiyus 10Aeckgivatjq 12Casrivhfdamzo 11Usixjveglgpm 11Wemzohxkavpt 6Rsgdqtm 11Lavisgwznshq 5Vsfivm 5Giiqtd 12Lmslpjmztjawv 5Hqsgzn 10Yourkogjnvc 10Zllhmnhujcg 4Vaqfm 8Ujpocvakj 8Tyxceplzu 12Hkzyoxntvajhw 9Wxmipjfwvs 3Tatg 6Jvtdixh 4Oajjg ");
					logger.error("Time for log - error 4Dqsyu 10Ifcptaxluyc 5Lsxkyw 4Xttcz 12Dvydrpnoaarqk 3Ycrp 3Mptx 10Yhrfggcddnr 8Czazopkin 3Ulxi 12Dajobfsjtkeze 12Xjtzdixyiumly 8Dpvbetjap ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metEwxuvzwhpbpte(context); return;
			case (1): generated.ifyrm.rwj.ajr.gkqyg.ClsSfeshwgdectgpm.metUdqxpeng(context); return;
			case (2): generated.loe.helvz.umzz.ClsSvkkzn.metHczavlj(context); return;
			case (3): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metGigic(context); return;
			case (4): generated.xluq.wys.lexvj.ClsEsonclfnnvbg.metKsdklzxlnfg(context); return;
		}
				{
			if (((3145) + (Config.get().getRandom().nextInt(710) + 1) % 278077) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex25569 = 0;
			
			while (whileIndex25569-- > 0)
			{
				java.io.File file = new java.io.File("/dirFdqevlngohs/dirIpoesvhispb/dirYbqqtgkwdas/dirYpmceafnqlu/dirCkzolcmmrqd/dirCufrdnygbos/dirFnonlnjhhfs");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((8105) % 577053) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((1398) % 971173) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metYvhtzzazeiso(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Object[] valBuytjzjdvua = new Object[3];
		Set<Object> valBcsbxirfftb = new HashSet<Object>();
		int valJlnexlrxffi = 970;
		
		valBcsbxirfftb.add(valJlnexlrxffi);
		
		    valBuytjzjdvua[0] = valBcsbxirfftb;
		for (int i = 1; i < 3; i++)
		{
		    valBuytjzjdvua[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valBuytjzjdvua);
		Map<Object, Object> valDfgtxhdwvom = new HashMap();
		Set<Object> mapValEbpdfkpwntf = new HashSet<Object>();
		long valUonxhwyinwa = -8699639889622625442L;
		
		mapValEbpdfkpwntf.add(valUonxhwyinwa);
		int valIfogfhbwwsk = 966;
		
		mapValEbpdfkpwntf.add(valIfogfhbwwsk);
		
		Object[] mapKeySircszvtqvo = new Object[10];
		boolean valRoolurqsgdj = false;
		
		    mapKeySircszvtqvo[0] = valRoolurqsgdj;
		for (int i = 1; i < 10; i++)
		{
		    mapKeySircszvtqvo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDfgtxhdwvom.put("mapValEbpdfkpwntf","mapKeySircszvtqvo" );
		
		root.add(valDfgtxhdwvom);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Sfroziaejtqen 6Irutsve 9Vcizvgsgli 7Iwlgdsmx 7Hemxxjln 8Oljvmgmew 10Luzsrpkdlml 6Irtqywd 12Txxoliwnahmqj 12Fyhlwpvwtlgmv 5Klepzu 3Okxu 8Giukbrymx 8Qwjugstuo 10Cuuyceiqsew 10Ajkrxwkbubu 4Rvnuu 7Zeqovcks 11Fbpnjdpgtdmp 4Gbpjb 5Ymjxll ");
					logger.info("Time for log - info 12Qohyjzqgeitgv 6Zlhakwt ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Hvlbeqnrto 8Bpcrgjzas 4Wtpil 4Ukwjz 4Owwco 5Lpbabx 11Oxhciaooycuz 8Fwozzqtqh ");
					logger.warn("Time for log - warn 6Bfymsrc 6Fijujut 12Qcitlhffifhdc 12Tkdeqncfksmtu 11Itfyqaygkghw 3Ftki 11Oerxqjahvegi ");
					logger.warn("Time for log - warn 5Jonrzg 7Tgxnjixs 3Ufoz 8Xydpghbvr 5Gerexp 12Jmpkvxzholqvc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Ykzjzdhvs 7Bsajpjcq 11Lgbihycyowqa 9Iwmnscetps 9Eaembivpco 6Xtkhyck 11Xzitzzihgczk 10Xqitbzyqljg 9Vympuzwpvn 6Pyzsrrn 3Qdde 8Pjyanggak 8Vedvfafsc 4Advkt 4Cfmwm 12Cljvanqbkqyoj 12Hoimhxlxfuism 10Gwthbkclabv 8Stobnfnav 8Cxqluftbl 5Iljpld 9Fzwmgfuloz 6Ztgsnma ");
					logger.error("Time for log - error 12Dphdutuwvrxdo 12Kqpkzbbpipzlc 12Wgkpjwymwktpt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bcbrr.mrpx.ClsJcswauwrr.metIydcpeyrd(context); return;
			case (1): generated.kyd.fxg.ClsVvcevjvyz.metAvlkamwowqupb(context); return;
			case (2): generated.wunj.xtrc.rfx.aikz.yopv.ClsTejixmzc.metAhxfdsezzruvtx(context); return;
			case (3): generated.tcf.quma.ClsZzrrflp.metZjejbmakhczdx(context); return;
			case (4): generated.qer.bwl.ClsCbeyhqqy.metFgzkaoqzw(context); return;
		}
				{
			long whileIndex25577 = 0;
			
			while (whileIndex25577-- > 0)
			{
				try
				{
					Integer.parseInt("numHxsculmpfhz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex25578 = 0;
			for (loopIndex25578 = 0; loopIndex25578 < 6506; loopIndex25578++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
