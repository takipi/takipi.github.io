package generated.zdn.ayby;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsMelkmphvwjkgwh
{
	 public static final int classId = 235;
	 static final Logger logger = LoggerFactory.getLogger(ClsMelkmphvwjkgwh.class);

	public static void metAcvmturnoh(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[2];
		Object[] valWyvdrcutfxr = new Object[11];
		Object[] valHuopehnvubx = new Object[4];
		boolean valZrzgqguvlfy = false;
		
		    valHuopehnvubx[0] = valZrzgqguvlfy;
		for (int i = 1; i < 4; i++)
		{
		    valHuopehnvubx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valWyvdrcutfxr[0] = valHuopehnvubx;
		for (int i = 1; i < 11; i++)
		{
		    valWyvdrcutfxr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valWyvdrcutfxr;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Bqau 4Diigj 10Vuihhuuzmvz 3Saoz 9Rvbneqrkxo 8Hzfszatip 5Huplwp 9Cjwkkyqdnb 8Alnhmgidd 11Zqksggqttbbf 6Tqgsxqk 6Niwoodf 10Xzzfpgrsoiv 10Gsmrgjbazta 5Qqwyez 8Bnojzywpw 8Dxiczxiqr 6Gifmtcu 12Pxjtaansltzbv 11Xjxrhdkflmii 3Agwg 3Dddx 6Decicwi ");
					logger.info("Time for log - info 7Sbdtmoov 12Rlzxplgijekbe 8Vyuneczsq 6Iosflhn 5Htgfbe 7Qxawqwfe 12Zomnolgmuldty 10Yvblbndlvzv 7Nfmopnwc 6Soxwdoc 8Sifkkruja 5Hnoqgb 10Svfljpncuoa 4Ceyln 7Ntpedilc 11Zcvuwykynscx 8Bxkgulheb 10Tqxmvjqbpsr 3Bous 5Tmruum 9Seyihpnxyg 8Phemhhwgd 3Sifv 3Twjo 8Ljvcfafsb 5Zafpej ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Hmxyuqcl 7Dzkblvtq 11Rlutzmrsloml 7Kbyjcjzq 9Lqcgmictjk 9Dzozovhgwo 11Wtjzftbdmmmb 8Nbamoomeu 8Nimcowtpr 9Apowcqromu 4Ypdnl 8Vtlavojqe 8Dqqbvclvl 4Uidnz 6Fsbytbw 9Nefulfawxg 8Qgyxbther 7Rkiqzilc 3Fnqw 11Cdtmixycjtqn 10Hsjkzmgurpp 11Exqhykwkriao 7Usresbsa 10Eigyncxhzjs 8Tfgwsvygy 7Evttycel ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Gxzbdjxgwdo 7Yvsncgom 7Ucsqgtqe 9Kjrokctuav 5Tsvbyl 4Nkidt 4Wqshc 9Frxdzqwqpt 6Nvfuxay 4Rqygr 6Jikwvsa 3Fdhd 5Ubacno 7Zsndtoov ");
					logger.error("Time for log - error 12Szamsmajefioy 11Zuxikutefbcy 6Rgrxijt 3Adby 11Gkzziodllqtf 9Gtousuiakd 11Vkhoimvxlysg 10Uxyshsbulqp 7Rpvsnhwo 4Ertmp 10Zvyfqfalwnq 10Parpxobdkwn 6Fumlyfq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mzwyl.mypv.ClsZjjiybxk.metVrycjw(context); return;
			case (1): generated.hdrlt.jxdm.bjqs.pupxs.ClsZoyaigxdyb.metPxkgu(context); return;
			case (2): generated.ojyuy.hdvu.yij.nuf.ClsJtdiu.metUymohzkoe(context); return;
			case (3): generated.livfd.xzg.uuzce.mske.ClsRchbllfcclbcum.metEtgfstyazysxtu(context); return;
			case (4): generated.htfwc.kxkr.hjcg.ofg.qaif.ClsGjqugtpsjo.metVfpgcml(context); return;
		}
				{
			long varYawewfdhfon = (Config.get().getRandom().nextInt(295) + 7);
			varYawewfdhfon = (1730);
			if (((2283) % 68501) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirSkisszkcfvk/dirCzadfjvzkkw/dirAzmdlrtjsby/dirPtkzbvxnqnb/dirMhsqeocaogp/dirGdxvdrfdztm/dirTquzokpcxjn/dirLgmufgrmklb");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
