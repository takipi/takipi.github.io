package generated.baxd.moelu.dfhna.pgrdw.pgae;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsTifyecuw
{
	 public static final int classId = 489;
	 static final Logger logger = LoggerFactory.getLogger(ClsTifyecuw.class);

	public static void metBnfwficdpxvbr(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valXhhkqdeuhvc = new HashSet<Object>();
		Set<Object> valNihruueqkst = new HashSet<Object>();
		long valSglhzprmshv = 4336751267601872396L;
		
		valNihruueqkst.add(valSglhzprmshv);
		
		valXhhkqdeuhvc.add(valNihruueqkst);
		
		root.add(valXhhkqdeuhvc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Rzpznewlagqvs 8Csdvthasz 11Irhqylzvldlu 3Emzm 7Bhhnlvtk 7Ktnuayqc 3Ghfa 8Hwajbbuqf 4Gmxdk 8Ocxlzbwld 12Rhjyfjtqnoepd 12Ddsdaszdlrsrl 10Dpafkkezbmi 8Jjttspgpq 10Lxbajpzgtnh 4Xntvm 10Yywejtmsfgt 11Afyhkkqfqkrb 12Jnznrrkksqdmd 9Gnwskxbquq 4Zptsh 12Ddgzohnukrwsq 12Ggnfnvbgotkpq 4Bxbqs 7Sfdmomhm 3Kgla 10Gctkzuyloar 11Qaxoecdrkban 9Upthrgfdiz 12Rmbmtwyyrgqne 5Jutmog ");
					logger.info("Time for log - info 3Tpua 12Jnxufefzpejsq 4Jlenm 12Eqzydqtitzqkh 3Dfpo 9Nquqqaoxjj 3Kduo 4Frned 6Yefjwbe 10Dcqngmefyks 4Izscl 7Vluchbxv 9Jncutdhtgu 10Gaucxbjfmoa 6Reljlba 11Eqqbqhytzlgx 3Kbdi 7Sqrcqpxh 3Utds ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Qexvpsrtax 10Taubtyupknp 9Obvbaeuztp 7Trkzftdw 4Zgghi 11Sechpibwzvor 10Kxhqlmitwqt 8Ycugdvsyf 4Lgbfc 5Bsgkvn 4Udgzn 12Iucujijwimgji 3Lucp 10Jpphbehhkaj 10Szbtdfygzsv 9Nlxnhnktxx 10Dfkdsqiyefq 11Idmyldhqgjte 9Noimxqtbfk 6Cugijrf 12Gjveryvxhswfp 12Afurkjjjicvov 9Misvhkkitr 5Mxkslh 11Aznpgvsuvvlb 8Fgqzbqydr 10Asmsycjapdq 6Yyufltu 11Vlvigiprqsew ");
					logger.warn("Time for log - warn 4Jyxfr 6Kdvmbty 10Rfdgbqqymno 5Tdpbyp 3Hbkh 6Lbqqwzi 12Mnroqznnicpzh 11Igmnfhhbgyhg 3Eyka 8Asplpxwki 11Snsagcgccsaw 4Zoevz 7Imbdmhdq 4Xyhdh 12Xeaieusojwlqa 5Placfo 5Kruepp 6Sqmnxvp 9Xlcvnrpyve 11Anrcrbfzyahf 10Toupolrybkp 10Tbnlimzyklg 10Nbdjpcitvvc 8Fsxphnpsf 5Nepzsq 11Wyqtmurudysl 4Mdsdg 5Cdgciy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Rjohcl 7Xrumcqlr 12Strtqmdcgcnnw 8Tbdfkjcpf 6Uqetdhv 12Hhpuiyqqgqzug 7Mioknltp 7Ejfmflad 8Iflohwmgt 8Tfvpocsri 12Qlqmcspzqyncf 4Nsrsj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pfu.znq.ClsGxncns.metXbdeur(context); return;
			case (1): generated.gmrwo.oumy.sahgj.zbppw.vqlx.ClsDexipe.metMyagpq(context); return;
			case (2): generated.wxgmf.hjxrw.ClsYvfyyrknqfec.metRjzexmwk(context); return;
			case (3): generated.wvctc.whp.ftjy.ClsPwdcftvpjt.metMihtagu(context); return;
			case (4): generated.gfhvs.nuhuq.qbk.rwbku.erqpl.ClsOuzdnnqrt.metAacwokcmgyz(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirSlcvyapwzxg/dirEjgwvfhsdvr/dirWdtjgriugoc/dirGskoqtkbxdc/dirUtuynkltkye");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex28248)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex28246 = 0;
			for (loopIndex28246 = 0; loopIndex28246 < 8831; loopIndex28246++)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metKuqddwkfbtsqxa(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Object[] valHraqoicolvt = new Object[9];
		Object[] valZgsvlkgjvng = new Object[4];
		int valNnjqldreyxk = 473;
		
		    valZgsvlkgjvng[0] = valNnjqldreyxk;
		for (int i = 1; i < 4; i++)
		{
		    valZgsvlkgjvng[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valHraqoicolvt[0] = valZgsvlkgjvng;
		for (int i = 1; i < 9; i++)
		{
		    valHraqoicolvt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valHraqoicolvt);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Gidlk 8Nxjexhmaa ");
					logger.warn("Time for log - warn 12Hwizhkmczncmi 3Ckfp 8Tzzmcjrps 8Qzcfimdkb 6Rvwamlw 3Txbe 9Mqykhusodd 10Ovcddlldldi 10Qjllcdqgssm 10Zpasqiblauw 8Moqhbflwo 9Crvmtcgevv 10Mrqeitctnff 9Upbopmaslr 12Llcbsjqmxnoic 7Bwjqynay 9Geeysxpgfj 6Aqpqkhg 7Mldvlunv 9Fyuborgzjz 9Yweyaktwws 6Bwyzxsq 6Ztyoukp 8Sqowufgrk 12Regqgatzwqrkg 4Zysaj 3Xynq 8Qursysran 7Wbmlxwor 10Zbmibtcgaid 12Vtavrubdjgrsb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Cvknt 11Hiffxiqlectk 12Vetkbzjitbeul 7Qxbcjaqo 9Vhsrqplmzc 10Uygoglrczmw 8Ayfeybiqr 11Pxyoyripwqbg 4Brgeu 6Nswagpa 3Jprr 7Zxawolpz 8Ebsyokpgs 5Apnmlz 10Vvkkdgtuerb 4Urlfb 10Qvmmtewhyoo 8Fwzayfrri 9Vkgvqjoixm 4Fohrh 5Cwonim 11Brrwniejltjw 5Kbifkk 9Xejoqnofiv 5Pmgwhy 4Hdrjd 9Cdvwmecgam ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.iiben.ptjec.naa.begt.ClsJlkmiazt.metAgwabdd(context); return;
			case (1): generated.fflc.jdncn.ClsHubvnnx.metSnkfjhjtib(context); return;
			case (2): generated.ucgs.cys.qrt.ClsGwmfnzjfaj.metFonacuizikxef(context); return;
			case (3): generated.lkd.eckd.hdtbd.unse.scvn.ClsCjccpmy.metYcdmbyork(context); return;
			case (4): generated.pxy.vesv.fuz.ClsEaskwlgtcshts.metCnqxpzkxiqea(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numBdcooubvavp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
