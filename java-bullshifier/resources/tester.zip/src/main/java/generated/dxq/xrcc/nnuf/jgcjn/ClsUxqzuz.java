package generated.dxq.xrcc.nnuf.jgcjn;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsUxqzuz
{
	 public static final int classId = 468;
	 static final Logger logger = LoggerFactory.getLogger(ClsUxqzuz.class);

	public static void metHzpuk(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[2];
		Map<Object, Object> valFheungkrkxg = new HashMap();
		Map<Object, Object> mapValDpihnylyuiy = new HashMap();
		long mapValFetqbowmcik = -973680087872007822L;
		
		long mapKeyTpygwrhonxv = 5133993875447177198L;
		
		mapValDpihnylyuiy.put("mapValFetqbowmcik","mapKeyTpygwrhonxv" );
		
		Map<Object, Object> mapKeyGwncywwuwwd = new HashMap();
		int mapValQkdqgchibsg = 387;
		
		boolean mapKeyWksjgwfauqc = false;
		
		mapKeyGwncywwuwwd.put("mapValQkdqgchibsg","mapKeyWksjgwfauqc" );
		
		valFheungkrkxg.put("mapValDpihnylyuiy","mapKeyGwncywwuwwd" );
		Set<Object> mapValTkzhjubmhef = new HashSet<Object>();
		boolean valXeqmahtygro = true;
		
		mapValTkzhjubmhef.add(valXeqmahtygro);
		
		Set<Object> mapKeyMajoanfljsz = new HashSet<Object>();
		long valDphzzwksqpg = -6721010148790725665L;
		
		mapKeyMajoanfljsz.add(valDphzzwksqpg);
		int valDfiyfrhgjey = 519;
		
		mapKeyMajoanfljsz.add(valDfiyfrhgjey);
		
		valFheungkrkxg.put("mapValTkzhjubmhef","mapKeyMajoanfljsz" );
		
		    root[0] = valFheungkrkxg;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Jbbfvjydlr 6Yryycus 3Svyj 7Elhfdxnn 6Gdxsmax 7Opysdbmp 6Gpdjiet 7Rmaziwda 11Iqxbcwrubumr 5Lklmud 3Bzww ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.axdim.stv.ClsSaegiqo.metKmdsuvjx(context); return;
			case (1): generated.jrx.knq.qgl.klpmp.wqhuy.ClsPrfpvgkjefvagy.metPasaujrwb(context); return;
			case (2): generated.tuih.veohx.ClsLezjqptgnoj.metYlqzr(context); return;
			case (3): generated.vcamv.yhh.ynaoh.fpbp.ClsCmgmcvgh.metUzxdq(context); return;
			case (4): generated.hnmnf.dxh.laih.zpf.ClsDfldwucgkze.metVnovmwgbhe(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(582) + 2) % 330761) == 0)
			{
				java.io.File file = new java.io.File("/dirYsdfmjzaevh/dirNivaixkiwjm/dirVlnwfeoqlzt/dirRwuijwocbwc/dirIgzztqkiukx/dirDvxmlhneyqb/dirBddigkylmpn/dirJwjomhvfaar");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(813) + 4) % 837526) == 0)
			{
				try
				{
					Integer.parseInt("numIgorfjqdlvc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metMerkfgxadscigo(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[7];
		List<Object> valUsyubakpjej = new LinkedList<Object>();
		Map<Object, Object> valMktdkzllzrl = new HashMap();
		boolean mapValXontiwkxter = false;
		
		int mapKeyZoburdszwem = 785;
		
		valMktdkzllzrl.put("mapValXontiwkxter","mapKeyZoburdszwem" );
		
		valUsyubakpjej.add(valMktdkzllzrl);
		Object[] valBhuddyxbtwe = new Object[6];
		String valPypzcfztmln = "StrAtbkejlwruo";
		
		    valBhuddyxbtwe[0] = valPypzcfztmln;
		for (int i = 1; i < 6; i++)
		{
		    valBhuddyxbtwe[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valUsyubakpjej.add(valBhuddyxbtwe);
		
		    root[0] = valUsyubakpjej;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Khligpwgu 5Erlhkw 3Pnug 9Vrarornvvb 4Hygak 7Mhksxjfz 6Htguczh 8Ywafkvzfj 9Wlsywvmktr 10Llrmdzqkqgc 5Kwxhmq 9Ogczhauani 8Gwbgkkkku 3Xupj 5Xjmhdn 5Fmcesd 10Owvfxyyzuht 11Dimupntckegm 11Hyguieesnxev ");
					logger.info("Time for log - info 3Infe 10Wsenuwruecd 11Xnnpsrkhiuqh 7Imxfswgf 3Vtet 3Hhvp ");
					logger.info("Time for log - info 10Lwmfwltsphi 11Oiygymkskxds ");
					logger.info("Time for log - info 5Sgigib 10Stxawzauxkz 6Inluyxm 10Obxnaqsrzqw 11Xjlgllfhtggq 5Jfgjca 5Vqrvli 7Gekkzjsp 9Xqxtsseoux 8Jkvrimmvx 7Dootfail 10Lsrfghiemme 11Fgwjezrppmnz 10Tgyigesmqvg ");
					logger.info("Time for log - info 6Cbglbok 10Tudvzubkfof 11Pqposssvmhsi 12Ehlmajbxfevjk 10Wlsyunjgqye 5Knbpox 6Brjcerq 10Grbxxcylqkl 10Yvvbqdhomcs 4Bcshf 9Pdhyjpffbh 8Kzdjbfcfu 8Uqebmrvol 5Shhcii 11Epwbenbnugok ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Pmpdkvmgi 10Kplrqbxiuyh 12Jjvfmcukhlqck 3Bnte 5Azoayt 3Wrkl 8Fjfgqarzw 10Ibxjawbfzka 4Widuq 11Nfpvaataeycv 7Yhtoxdnp 9Rjtomfxzvy 4Dqeva 8Ukmkmyiih 7Torhcwkg 4Pcfkp 6Tzqydkv 3Exjt 11Dwfkxzufstag 4Iebpp 3Peuh 4Qgzdc 4Qzulm 7Ehwnypmz 5Wxpvvs 3Kzsf 7Uqjqnhuj 11Dabpftsifafy 8Tdgkjeoef ");
					logger.warn("Time for log - warn 9Dghrxwzdcw 3Fmld ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Neyvoyjro 6Jykiyno 11Czxxilauzbvs 11Ihewqxzxhfpk 10Nqvmlrftpws 12Yngourzyzflao 4Valjk 10Blswhfzbgwt 8Okjbloryh 4Jywbe 11Dzuhxojuablx 8Rvicduklj 12Pnmzyshqgzkec 9Wshodnvhju 10Qwlfetvwjys 11Qswsvmqkfdmo 5Xjdflb 7Znzobjam 3Ibqt 4Puabv 9Zmrkwrlnig 12Iayepdtbtcwjy 5Outsxv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mpex.dpd.nziyl.ClsMvkjogpaegzqh.metCcluioiaauedgi(context); return;
			case (1): generated.kfjp.bzn.mda.sfyxf.ClsAguszlzt.metWsvlopnliexx(context); return;
			case (2): generated.fhy.qnk.brj.xhy.ClsYgumeudbf.metEcwaz(context); return;
			case (3): generated.tzk.wxrm.bwm.qkv.ClsTeonxo.metQpntvyruck(context); return;
			case (4): generated.uxbqo.pcskv.udre.ClsKillneqmm.metIokufnwdnpfcxt(context); return;
		}
				{
			if (((5555) - (9333) % 295052) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirWovutzmfhkr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex27889 = 0;
			
			while (whileIndex27889-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metMdwubkjj(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valUtwtygwkplt = new HashSet<Object>();
		Map<Object, Object> valZidbzoympcg = new HashMap();
		int mapValVeofoiqavja = 619;
		
		int mapKeyNyxiyfaevcd = 627;
		
		valZidbzoympcg.put("mapValVeofoiqavja","mapKeyNyxiyfaevcd" );
		long mapValDiqmsqlxpku = 4515399107597016369L;
		
		int mapKeyKigmtmhugfb = 247;
		
		valZidbzoympcg.put("mapValDiqmsqlxpku","mapKeyKigmtmhugfb" );
		
		valUtwtygwkplt.add(valZidbzoympcg);
		
		root.add(valUtwtygwkplt);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Ftdqpl 3Qmyx 12Khqdjjpbkjagc 5Uczfsf 6Jgbuqwm 3Kryf 11Waickbecuqfp 10Dhhlekrktqo 10Cmambztqsma 8Zkrhypxxa 9Aobgforlne 6Ssbgaoc 6Qcxtbom 12Pitiiuasgrwma 9Goraguppsd 12Lrxxoxgfyosbm 3Hxwv 12Pdljqqgniuuad 6Tepokpq 3Krcq 11Iimaouzxxuzg 12Yuzxvbipmkszw 8Ugfarpacb 8Lanyiskni 12Zhkflvviderqr 3Umax 10Xvxootuqcbh 11Tfqfqiexwbky ");
					logger.warn("Time for log - warn 3Vwnw 5Zzxlsi 9Fjimeszjnd 3Hynr 9Gkzdmajvlt 10Mblgsnnzczz 6Wxysgtm 8Ivswwwkxs 5Iqhknd 8Igfslpdki 7Kkwnxzpa 3Ujew 5Nkrgwy 8Fscjoeirh 3Dpnx 6Wxsaqwt 9Ovovztqheo 10Llncdragxyc 7Iccmcxzw 7Tsaetxtm 9Aceckjcxbj 4Oimyn 3Bnnc 11Iywhkpdrhzrx 12Rgrzaszopulys 6Gwdvjxb 10Ypjujnyphzf ");
					logger.warn("Time for log - warn 6Jzxklld 7Bptvkrcl 5Lajeqp 4Iarhs 10Xkpcdkauagw 8Njkgtcign 4Xyfvh 4Tjlqe 10Vrlnbqifhlq 4Idwhx 7Kklgjbpc 9Kjuzstspty 7Cmhoczbk 9Znxhskqmwv 5Mwukfl 10Rjjdlxvkynt 9Sekwbvmzrw 3Yfjb 10Tqlxgovlobo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Qcscilcbpdpz 9Rjtngmxufu 8Rulaugqpb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vspck.scvf.gxvmo.ClsBudbedmvgnjpa.metRtbqqjsh(context); return;
			case (1): generated.lzs.nehlu.rmx.ecdl.iyxe.ClsYbctjsi.metFzkbezkzlrqdq(context); return;
			case (2): generated.lxrj.lts.csk.iew.ClsCagmzsja.metOondcg(context); return;
			case (3): generated.rnt.ihen.ClsUnbfdq.metAtneflmvgcprd(context); return;
			case (4): generated.rzy.sppai.eju.hupq.ClsPjendhgbojpy.metXspjdvsvflkh(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex27896 = 0;
			
			while (whileIndex27896-- > 0)
			{
				try
				{
					Integer.parseInt("numGyhvpbsepmp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirKnypytguhrj/dirUkjrtezdnfx/dirKrdrssyehjy/dirVqsojaolnft/dirBkwovlgikgl");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numGshdsvuurfq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metSikxfogw(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valVlrwdhzengd = new HashSet<Object>();
		List<Object> valOuekwtxutjm = new LinkedList<Object>();
		long valNkzqhxvjqhx = -8738369481914250944L;
		
		valOuekwtxutjm.add(valNkzqhxvjqhx);
		long valDuvmtvntgod = 1310290576793053204L;
		
		valOuekwtxutjm.add(valDuvmtvntgod);
		
		valVlrwdhzengd.add(valOuekwtxutjm);
		Set<Object> valYlmojtzsllo = new HashSet<Object>();
		int valThzpvugcado = 101;
		
		valYlmojtzsllo.add(valThzpvugcado);
		String valQmpvsdimyyc = "StrXenfehkgkaz";
		
		valYlmojtzsllo.add(valQmpvsdimyyc);
		
		valVlrwdhzengd.add(valYlmojtzsllo);
		
		root.add(valVlrwdhzengd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Esmwqdcbsbfpy 9Dplnnjyvsl 4Fmmmw 12Toeojbjrhnmnc 8Eacroeidi 5Uttdho 7Olhindpi 12Uqpivuvpfthgq 9Kiqkmskvwp 5Vrpwru ");
					logger.info("Time for log - info 4Kylck 7Bbljxokl 3Megu 6Wunlhix ");
					logger.info("Time for log - info 9Oamisefoft 11Vkfkygdbrfxf 4Dnosm 12Pxpxyizrgnxrm 3Gsxv 9Nxzexwulve 12Xgnnsvwnkfajm 4Ehjou 10Deyxzxgbiuu 5Tcrmia 5Tmxkjc 5Eqcjxb 10Ttlxgdwdiva 5Yuzqxd 9Vgcikvkztk 12Yhmixastjrtpl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Fvksxebnyo 10Vskaykpvuqb 6Hjrshoz 12Bfpdzstjjrmio 7Yurvltqd 5Cssikc ");
					logger.warn("Time for log - warn 3Fzus 3Amns 9Otwhrqrgah 10Hwisvymodha 10Zulmxzqlsse 3Eehx 10Vhwidpgundu 6Ltbkspf 6Dsbanss 4Wtrjr 10Bindnyitequ 6Yciovkp 6Wragqst 10Vfctsbqobrh 4Myhvd 3Iris 10Mbmlshlayin 11Olqpidkytfvi 9Vabpmyaawi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Wetjqp 12Jhuifvdvxquvj 4Bggyr 9Snpihuedig 7Ufotjlcc 11Gyylhhyhjlmm 10Gzucfanfibm ");
					logger.error("Time for log - error 8Wziwzwpln 4Mjzhm 12Ooqgaopsvjcrs 4Yauer 3Ayyh 3Isor 12Iryplrnlnmvqm 7Qgwgwfjs 6Taprxtz 9Lvnqpzmigi 3Axiw 11Qyvyzyyzhrnn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.plye.kjczy.bmku.wrxrk.zek.ClsNtetu.metQbexvwsymsm(context); return;
			case (1): generated.liyl.sfhr.ClsNilzqakfd.metIodijouzvnszdm(context); return;
			case (2): generated.uzhb.dwl.ClsEamgh.metGdedianbrzaib(context); return;
			case (3): generated.ahr.cnut.ztcbc.ClsUicrpogixv.metIynrmqpfnjegr(context); return;
			case (4): generated.avme.rnc.ClsUgqeozcqx.metIsegbgah(context); return;
		}
				{
			if (((7502) * (Config.get().getRandom().nextInt(711) + 3) % 487016) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
