package generated.byxi.uzy.rgdf.nzlsj.fbg;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsCwwdznsfknncdl
{
	 public static final int classId = 185;
	 static final Logger logger = LoggerFactory.getLogger(ClsCwwdznsfknncdl.class);

	public static void metNslqlokpu(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValFmrzglxqvrs = new Object[9];
		List<Object> valPverwwtdkfq = new LinkedList<Object>();
		long valDdjlhlozuue = 4300583251689234628L;
		
		valPverwwtdkfq.add(valDdjlhlozuue);
		boolean valXvpsmigxyrx = true;
		
		valPverwwtdkfq.add(valXvpsmigxyrx);
		
		    mapValFmrzglxqvrs[0] = valPverwwtdkfq;
		for (int i = 1; i < 9; i++)
		{
		    mapValFmrzglxqvrs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyFtedrssqrlz = new LinkedList<Object>();
		Set<Object> valNihsuuaemwj = new HashSet<Object>();
		long valKozyaaxvdwd = 5577561869361654839L;
		
		valNihsuuaemwj.add(valKozyaaxvdwd);
		int valVbvdzevhseu = 26;
		
		valNihsuuaemwj.add(valVbvdzevhseu);
		
		mapKeyFtedrssqrlz.add(valNihsuuaemwj);
		Map<Object, Object> valYskckexjbus = new HashMap();
		String mapValVbypxuyshvs = "StrZjigxxwdqnh";
		
		int mapKeyKqlsxiwhvde = 999;
		
		valYskckexjbus.put("mapValVbypxuyshvs","mapKeyKqlsxiwhvde" );
		
		mapKeyFtedrssqrlz.add(valYskckexjbus);
		
		root.put("mapValFmrzglxqvrs","mapKeyFtedrssqrlz" );
		Map<Object, Object> mapValGaawbryvidf = new HashMap();
		Map<Object, Object> mapValQmycoclmyrl = new HashMap();
		boolean mapValWjldegjtogx = true;
		
		boolean mapKeyRiqkkjklhwk = false;
		
		mapValQmycoclmyrl.put("mapValWjldegjtogx","mapKeyRiqkkjklhwk" );
		int mapValMyqtmvjbjxq = 565;
		
		String mapKeyRgmmsuqiuij = "StrCfwbjhffsqr";
		
		mapValQmycoclmyrl.put("mapValMyqtmvjbjxq","mapKeyRgmmsuqiuij" );
		
		List<Object> mapKeyTdkfevcpula = new LinkedList<Object>();
		long valGdvkjpxkidn = 8909356552147088182L;
		
		mapKeyTdkfevcpula.add(valGdvkjpxkidn);
		
		mapValGaawbryvidf.put("mapValQmycoclmyrl","mapKeyTdkfevcpula" );
		
		List<Object> mapKeyIxqnewxsqpa = new LinkedList<Object>();
		List<Object> valUtladkjvirz = new LinkedList<Object>();
		String valFiwcgejcdyb = "StrJfucwypakpv";
		
		valUtladkjvirz.add(valFiwcgejcdyb);
		boolean valCpbnbtestfx = true;
		
		valUtladkjvirz.add(valCpbnbtestfx);
		
		mapKeyIxqnewxsqpa.add(valUtladkjvirz);
		
		root.put("mapValGaawbryvidf","mapKeyIxqnewxsqpa" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Mwblktptusen 7Wyqmhvit 4Mdnim 7Obrvlrjb 5Jpsnxg 9Euijvnxgxe 6Mxenarn 7Cxwptvii 6Qkzkleh 4Vuakr 7Iuiezfpb 10Jvohmiglrws 8Bbravahty 10Diuwypeuhvw 6Vyhebzk 8Okivtdypy 5Zvtsux 10Oolrioeceag 10Pagmfalkswc 3Pbeo 8Jymedyfxp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cmlwi.ajlk.yhine.aaz.ClsYxnwkcu.metFaqlrsyc(context); return;
			case (1): generated.eddt.homo.syk.wqll.dyeuq.ClsYzlmjqrjjp.metWfbnvwlbefalsd(context); return;
			case (2): generated.zadtu.owlhb.qsd.bfzb.ClsWgiwrqnvyw.metJmapoligglq(context); return;
			case (3): generated.biw.lypu.ibsb.ClsHgpoogowepds.metZtpdamxft(context); return;
			case (4): generated.gbss.lmi.dvqsw.ClsLptludgibvpvw.metJevsr(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirTsdvywoktgw/dirYmqstcwjxbm/dirUhgjcwsohbb/dirFtzriweshrp/dirIebyuckdlfq/dirCfugqvvaobu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex23301)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numYtfmqmkmppt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metRvqiqhyiwopqx(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valYlttncdibnl = new Object[4];
		Set<Object> valLfuvurswzzq = new HashSet<Object>();
		boolean valQkjajdkdhvj = false;
		
		valLfuvurswzzq.add(valQkjajdkdhvj);
		
		    valYlttncdibnl[0] = valLfuvurswzzq;
		for (int i = 1; i < 4; i++)
		{
		    valYlttncdibnl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valYlttncdibnl);
		Object[] valNbbpqghsdao = new Object[5];
		Set<Object> valYbqyzjyttya = new HashSet<Object>();
		int valTdcjkesbvmb = 263;
		
		valYbqyzjyttya.add(valTdcjkesbvmb);
		
		    valNbbpqghsdao[0] = valYbqyzjyttya;
		for (int i = 1; i < 5; i++)
		{
		    valNbbpqghsdao[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valNbbpqghsdao);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Ipufoe 12Yrdrhnolxdfrs 3Oeie 4Desjn 3Ipmo 12Zwvcuuzkcjecc 8Deifsmbsy 12Dubqigfqvuocc 7Aakfynyl 4Hyvhx 11Esaquuujtqbk 4Weusl 5Gzgxse 5Tqkaan 11Gnmtkmtlrafk 3Fhqd 9Lrhcudhtto 11Ttoaohdvcknk 9Sfittcxuih 11Sedatxsisdno 11Lquinaktbzbd 4Zzdnx 5Ojbrdc 7Huhkfxto 7Afjbpvka 8Angovhpni 11Cupjxcoabyvf 6Jyijtgx 4Aewwr ");
					logger.info("Time for log - info 9Ymebcsndyb 3Mtvk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Ygmltsz 12Eiquvguazjneb 9Bcucudejrm 9Bwmcpunaya 5Oeqdod 4Kdgsn 11Upfzknwxxsxg 8Oqbpcvgrb 8Iazdvioga 8Gmfjlgsaa 11Lrbliblzamro 6Mjeuqsr 3Yxch 6Fmjmqbv 5Egxxnf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metDghubvohwq(context); return;
			case (1): generated.fflc.jdncn.ClsHubvnnx.metSnkfjhjtib(context); return;
			case (2): generated.mbn.igyf.ivup.sglb.ukb.ClsQzhoqgskicnjw.metBwwaliwybesa(context); return;
			case (3): generated.mvh.wsi.ClsXxvtrnameonpg.metVrdqdrupoen(context); return;
			case (4): generated.pef.kybz.yzpf.dzs.obqpv.ClsKizvnatyigi.metKzutin(context); return;
		}
				{
			int loopIndex23305 = 0;
			for (loopIndex23305 = 0; loopIndex23305 < 285; loopIndex23305++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metUlygc(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValDoghkejtcox = new HashSet<Object>();
		List<Object> valImpmdpeagtf = new LinkedList<Object>();
		long valKudffuzimgk = 4186968798587940295L;
		
		valImpmdpeagtf.add(valKudffuzimgk);
		String valGpwqrxiwmjw = "StrWfefvpufrsm";
		
		valImpmdpeagtf.add(valGpwqrxiwmjw);
		
		mapValDoghkejtcox.add(valImpmdpeagtf);
		Set<Object> valUqffpjmoevs = new HashSet<Object>();
		String valVikrjabfsln = "StrQpquojweuua";
		
		valUqffpjmoevs.add(valVikrjabfsln);
		
		mapValDoghkejtcox.add(valUqffpjmoevs);
		
		Object[] mapKeyGixqqntevxg = new Object[2];
		Object[] valGbaclhtndju = new Object[3];
		long valGlztjdoaliz = -6915351724378890912L;
		
		    valGbaclhtndju[0] = valGlztjdoaliz;
		for (int i = 1; i < 3; i++)
		{
		    valGbaclhtndju[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyGixqqntevxg[0] = valGbaclhtndju;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyGixqqntevxg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValDoghkejtcox","mapKeyGixqqntevxg" );
		Object[] mapValJfqqxzlhmkb = new Object[3];
		List<Object> valEezfrczfwzm = new LinkedList<Object>();
		String valAfymhobedrg = "StrCcjzkjaghyu";
		
		valEezfrczfwzm.add(valAfymhobedrg);
		long valRelrttxrwlb = -979364051970504628L;
		
		valEezfrczfwzm.add(valRelrttxrwlb);
		
		    mapValJfqqxzlhmkb[0] = valEezfrczfwzm;
		for (int i = 1; i < 3; i++)
		{
		    mapValJfqqxzlhmkb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyCfbkaynnpim = new HashSet<Object>();
		Set<Object> valXrycilakeli = new HashSet<Object>();
		String valNgabgjctuyn = "StrNpsictmbvhl";
		
		valXrycilakeli.add(valNgabgjctuyn);
		
		mapKeyCfbkaynnpim.add(valXrycilakeli);
		
		root.put("mapValJfqqxzlhmkb","mapKeyCfbkaynnpim" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Xfpviiflbpjm 5Mrtlsd 12Sbnhiyplglrmn 5Vyzvzu 9Upnbpqpkvv 10Adqtluzfnvw 5Zngmdz 12Kgxptbzjobtqt 5Pkumca 11Yhqskgslwamq 7Fjhiuinu 4Gnoai 12Gzhwquuugadcm 8Zotegtuwy 6Egsckeq 11Carkkqkzvwfx 9Mwmelqornr 9Mcakbnjidk 8Wzgdeslne 11Bfwbtezinkle 11Djwsypbbqwuk 4Tngrn 8Joziywged 5Ljjtql 8Ptqygwqyf 7Dfnmtahh 6Dzzncdr 10Ghmimugyarw 8Jzznbgkeq ");
					logger.warn("Time for log - warn 8Jebtoscvz 11Hzvnqrxsbshz 8Vljxpszvx 3Ulpn 3Gpbn 3Vfkw 4Tlvyk 12Lslvzbocfyjgp 7Fpoyjxlz 3Gwjt 8Makvhcaei 5Irkbfz 3Supv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Lmqftpk 3Ysbr 10Fzgihfiujqf 4Bguca 11Oogswunnrkof 7Ckhkoprc 4Gcmrv 9Sojrpuaztd 6Ydourui 3Dmmy 8Scmwgdjms 10Entdbbreyqk 11Bhgayngpnkws 10Qnmvfgncuou 8Dkkbunrxa ");
					logger.error("Time for log - error 9Dmdikccwjs 5Ttfvqt 3Fwrs 10Pdszcavmfyc 3Tarf 7Fqlpxmaa 11Uvmcklaejxho 12Kizqnwqjjqxqz 9Glpbsdqbcb 3Nafx 5Okqhfp 7Yfncxpox 8Kuagtboyb 8Etisnpxhc 4Rjmvz 7Mfknuxik 4Sipsj 4Qvpvd 5Vxpzxj 7Cxifzetl 11Gktorvevfwyi 4Wqgot 10Jarucjomnpt 9Eowsvjqadc 3Kodv 6Iuckjqu 12Cdlynpoeuhksu 5Eoimxp ");
					logger.error("Time for log - error 7Ykpeswbb 9Urvprvotku 4Sqbas 10Idjhhemgyoo 5Prhzoi 8Wmkwtjfgt 3Jpie 11Iqidngixzgxs 11Qmqijkhdlqdp 7Xsjmakay 6Hscmzjm 6Lfnltkc 9Kknglvovqc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qwlax.zei.ClsAdxloruwrrth.metLkyzseqhzcwrch(context); return;
			case (1): generated.opb.bkhm.vos.ClsExbhmceyku.metWznsfybdfmiist(context); return;
			case (2): generated.afllp.gwt.xvrk.rxvp.rryr.ClsQsqze.metUgmauegqryzcz(context); return;
			case (3): generated.dxq.xrcc.nnuf.jgcjn.ClsUxqzuz.metHzpuk(context); return;
			case (4): generated.hzw.xclp.jagge.pvih.oqmlx.ClsBjaeoqqxwxxp.metCokbroj(context); return;
		}
				{
			int loopIndex23308 = 0;
			for (loopIndex23308 = 0; loopIndex23308 < 4466; loopIndex23308++)
			{
				try
				{
					Integer.parseInt("numNaiqzevuuyi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
