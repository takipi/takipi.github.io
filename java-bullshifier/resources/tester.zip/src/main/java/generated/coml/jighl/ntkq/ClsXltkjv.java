package generated.coml.jighl.ntkq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsXltkjv
{
	 public static final int classId = 227;
	 static final Logger logger = LoggerFactory.getLogger(ClsXltkjv.class);

	public static void metZrfmeqabzvf(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valVtbmisutuks = new Object[9];
		Set<Object> valBihxcoicypm = new HashSet<Object>();
		boolean valXcqraodpiep = true;
		
		valBihxcoicypm.add(valXcqraodpiep);
		boolean valFdidujykadu = true;
		
		valBihxcoicypm.add(valFdidujykadu);
		
		    valVtbmisutuks[0] = valBihxcoicypm;
		for (int i = 1; i < 9; i++)
		{
		    valVtbmisutuks[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valVtbmisutuks);
		List<Object> valYqvmcqulpuu = new LinkedList<Object>();
		List<Object> valUffmmztwonb = new LinkedList<Object>();
		boolean valBnufhvhdjcb = false;
		
		valUffmmztwonb.add(valBnufhvhdjcb);
		int valWdxucbidile = 505;
		
		valUffmmztwonb.add(valWdxucbidile);
		
		valYqvmcqulpuu.add(valUffmmztwonb);
		List<Object> valVwobhmnaucz = new LinkedList<Object>();
		boolean valMnbvmwvarca = false;
		
		valVwobhmnaucz.add(valMnbvmwvarca);
		
		valYqvmcqulpuu.add(valVwobhmnaucz);
		
		root.add(valYqvmcqulpuu);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Tkthh 11Rmomcvetolzm 4Sdtdp 10Qghehguzhna 10Dsxjfuzutgs 11Qgslpacpufjt 6Wujjexj 3Bdmd 5Awviud 6Ehiszow 10Dibitnjmdwt 8Reyvofsyd 8Isqyzmevb 10Mlxdxsbvgcq 3Jrzh 8Apcekmpif 6Zmiocmi 3Ybee 3Fzql 6Xyzdaek ");
					logger.info("Time for log - info 3Eoxm 7Ubcheulc 5Crlqek 5Ywsked 3Splg 7Lazqqrjc 5Tgsyne 4Lghgv 11Njnbygrnvzrd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Fvdhymehagfz 4Jlgpp 6Uexjczr 3Sday 6Krjaouz 9Bbowdkqytp 12Sbmsswvmdirtt 12Bkoxjfpupdcdu 6Cxmivhq 6Xvsvqru 4Jirtx 3Gpiz 5Qlvrfd 11Yvbyvbqsqsjr 12Taqrixxaambaj 12Dgkzpztimnsyo 8Kwkewdwvx 7Zfidpjro 6Ffpnjfc ");
					logger.warn("Time for log - warn 6Uonehjd 4Nbekh 10Hkuzaaumkwj 12Aahewlpdpccfn 5Zfdise ");
					logger.warn("Time for log - warn 12Tvctijukhmekl 4Ktgus 4Llfmb 9Nwbbcbmczn 7Qkqilbhx 7Zkrikuuc 4Nbthd 5Cwzcxj 3Trdo 5Abtpvd 6Jkmxkel 4Jvvls 12Jelojgkvktdzr 5Ujkheq 7Cixsydun 6Mexonzc 7Ytvszwwn 6Fwrgmqf 8Szjpulppo 8Filigtwtm 11Ixaaljxvbhrv 4Yoedi 11Wwwoemfpyaqc 4Girkv 7Cnzdcjtm ");
					logger.warn("Time for log - warn 10Gjfgpyhovvq 6Bfycrco 5Vbrxsh 6Nrftklu 12Qjpeoijymhopw 9Iibnbrznru 8Citawhubk 10Dypvfdqiwko 7Voyujpqy 11Cgquvxaikkdi 5Sjndev 12Jlaranfayrddy 12Uhtiddvqaaktf 12Pzkpuhajuvsva 8Reizvuqlq 12Dghiadwgplhit 10Frsseokskhj 9Axgztlusue 9Cklqfhiwre 4Opaan 3Ajdm 11Aaoffmmcxtdm 12Saqhybrgzdbvn 3Xgka ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Jsnppnjiiq 6Jrlouwm 7Jidgittd 10Fgquvjzgbqq 6Zrkigly 3Jktn 8Wqqyxfkcv 10Eopwqhfdvbp 3Yupa 12Lotxljerkauna 4Sdbyw 10Nousddqujzm 11Etnlcyzrerct 7Kzpgppsr 3Ziji 5Sonvnj 5Zytxvq 8Xevjsskkw 8Uemnpzdwf 7Pokqpxkb 9Wafnpojemk 10Tnthlhdflqc 11Pxzchynfpngl 7Morirzdw 12Oluvhqysshqej 6Dbsrdac 4Pvnrq 6Imkswdz ");
					logger.error("Time for log - error 7Vahkoosr 9Cnkqxyqked 8Obzcbfzyt 5Bmxpjq 4Dikhs 5Vrbnya 8Zaqerzfgq 4Ypehy 4Cfgvs 7Yrvdhndc 11Mzmoguplbkiq 5Dnjdte 5Lmluoz 5Rpjcjb 12Ncfuastcsnnih 4Gspru 5Lnejua 10Hkqlsqniwoy 10Mnizqofelpy 3Hkvd 5Cawngh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kqywo.pil.grw.dvt.ClsJduhsebfba.metPsnsdnegsev(context); return;
			case (1): generated.nrwq.xlmuw.ClsJifahbhi.metXwcdbms(context); return;
			case (2): generated.siinn.hrk.mef.ClsDcfbqxc.metTnfgkqflqf(context); return;
			case (3): generated.wcc.zfysf.ClsYrxejsiwymmrbw.metUmckiclb(context); return;
			case (4): generated.tzk.wxrm.bwm.qkv.ClsTeonxo.metXcoghnr(context); return;
		}
				{
			if (((9573) + (6543) % 271753) == 0)
			{
				try
				{
					Integer.parseInt("numNfvwapmmoku");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((5334) * (4692) % 609044) == 0)
			{
				try
				{
					Integer.parseInt("numVxitjqwmhgl");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metPzsdf(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valNzkowtyxuka = new HashSet<Object>();
		Map<Object, Object> valSbjknuguynb = new HashMap();
		String mapValLqdnbssuvmt = "StrLmliesryohc";
		
		int mapKeyLmugokpymoc = 192;
		
		valSbjknuguynb.put("mapValLqdnbssuvmt","mapKeyLmugokpymoc" );
		long mapValUwvjwvoklvx = 9030908986820009603L;
		
		int mapKeyHiktkfwqulz = 868;
		
		valSbjknuguynb.put("mapValUwvjwvoklvx","mapKeyHiktkfwqulz" );
		
		valNzkowtyxuka.add(valSbjknuguynb);
		Object[] valCxaujafjbxq = new Object[9];
		String valYsughamjrsa = "StrXdusachxkbi";
		
		    valCxaujafjbxq[0] = valYsughamjrsa;
		for (int i = 1; i < 9; i++)
		{
		    valCxaujafjbxq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valNzkowtyxuka.add(valCxaujafjbxq);
		
		root.add(valNzkowtyxuka);
		List<Object> valEjmwuurpzwo = new LinkedList<Object>();
		Set<Object> valHvcojzvonrs = new HashSet<Object>();
		boolean valCgtthujzsga = false;
		
		valHvcojzvonrs.add(valCgtthujzsga);
		int valDcuslajrdym = 855;
		
		valHvcojzvonrs.add(valDcuslajrdym);
		
		valEjmwuurpzwo.add(valHvcojzvonrs);
		
		root.add(valEjmwuurpzwo);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Cvlpk 6Wtxnfmc 3Xxoa 12Oaphoauauigfu 9Opbmywcvna 12Tyxasrlxtdcau 8Mduyewhyf 8Dcrdkadih 5Vaniok 11Mfynymbimwhm 5Lprfgw 8Ilojbzqgp 10Aluzucxcamm 3Qcve 7Qartrrnk 12Bledlsaxjielc 4Scvlw 5Bpmvtg ");
					logger.info("Time for log - info 12Bltomenxzxcus 11Velwkwfrzbkn 5Zzhsuy 7Sookabzl 12Vgmfkqnlrcxra 8Envzgqqvp 5Yxkcce 12Xyycunhknamgt 5Heyfov 7Obfpjhcz 9Ahxuupryro 11Encnlkcpxsal 7Ovzljqsb 4Ukjzq 3Hkay 6Oxrksxc 4Kaadj 5Muhuhe 6Kelnfca 6Nbsxbdy 4Fmoob 9Qdiadzapam ");
					logger.info("Time for log - info 3Exov 8Drzwahfxt 6Dqqmlws 3Iygt 5Wreudq 6Rpepyeq 7Dyrhqprg 6Nwsxuqq 9Foqfutevsr 8Gasajjeaz 12Nrirdcubvyaje 11Djyrmeifrunw 7Jxaymasw 3Kive 10Cycahnocjkd 9Emblxlyqee 4Erfha 7Chblwgnr 11Snnhafpyalbu 4Owyop 8Pdqjzodgi 5Extfle 12Msmxytddknisb 11Qgkufmeyefki 7Lzanyyre 4Pbeke ");
					logger.info("Time for log - info 7Bbevxmcb 4Oszom 4Drejw 8Fbkfmtdyb 5Tetejr 8Iirqfjjhz 4Tzain 4Xtqsf 3Wsyk 5Ovsixt 12Inrisbcyldvuz 7Jrwolelt ");
					logger.info("Time for log - info 7Yzsfozpf 12Rqhdzuacnltlp 11Iccfkzzuowcr 6Dpkamka 4Hwdca 6Cctgypa 7Ggrcfyei 8Tabavwyyj 5Pglfqf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Negsyikzs 8Yuxylqrpc 9Cwrjwpafio 10Uakfdapzbjh 8Pwxgjuniu 12Ginhhmvvvtiik 12Jizizbozphzdn 4Cgmse 8Hgtjpyvvz 12Crjbttlmfwegf 5Aeffct 3Pcdo 9Htjcpqbtmg 7Kktcfsuv 9Adjqnjluhr 5Ccofkx 12Zodkilkqugtnh 10Kcaxuxcadxs 11Anazugdyqcyv 6Vdczkcz 6Nxycyyw ");
					logger.warn("Time for log - warn 3Keii 12Eexdjiuwjlswe 9Fmpnnxnfko 3Ctrz 6Oqlljcv 12Rxaglyxutvrvg 4Rmlkt 7Kejuczfg ");
					logger.warn("Time for log - warn 10Xbxyuwbllja 8Htfvaeilb 12Ybnhyfhisjxps 8Ybiuhpbpc 3Tlez 5Irwani 8Xkegmzwyi 5Ysgufw 3Ghfh 9Oyccsnqglw 8Aftipyjsk 11Faeuwtkfqpnb 3Vafg 4Rcpbr 9Billyukeyb 6Iqrxelo 5Qrvutn 9Oprnwsmqft 6Onpbzgn 7Syaqzwno 11Ikgmjnvsgqcn 11Owiavwfvuvik 8Tidcbuzio 7Dyqwlwlx 12Tzwzqyqwvxthm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Xtpruupsnllw 4Aoddo 7Rglyardh 6Vpxdkec 12Wpjejvoosetlr 12Wuknifxmnqsmm 10Ddvsnmgxmtb 9Vaxbcvivzw 3Tcnw 3Bbpi 8Whsmcnwsl 8Vzmlunuqj 8Xazjeubmv 3Yfvb 7Fiuzmjop 9Nkvlyaitxh 5Rjxazy 4Exyww 10Ahtutybnkgv 3Fjcn 12Uchaxjafsyzne 8Eddjrzgxn 5Dynsxc 3Mpuo 10Rlyrbyhhjjy 5Bznugl 3Tmqs 8Qgqxtjnry 10Pdsrrqtknel ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.byxi.uzy.rgdf.nzlsj.fbg.ClsCwwdznsfknncdl.metUlygc(context); return;
			case (1): generated.eedk.kvsj.tzabg.tqpy.ClsBuuqqzvjfxdiao.metOjmuclkrr(context); return;
			case (2): generated.tcf.quma.ClsZzrrflp.metZjejbmakhczdx(context); return;
			case (3): generated.jrx.knq.qgl.klpmp.wqhuy.ClsPrfpvgkjefvagy.metVtubz(context); return;
			case (4): generated.twx.gyla.ClsYuzgeqywoqmok.metZrjgdmb(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numJigladonupy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numMsecuszmtlj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varSrfmvbwjzdv = (Config.get().getRandom().nextInt(952) + 7) - (Config.get().getRandom().nextInt(645) + 1);
			varSrfmvbwjzdv = (varSrfmvbwjzdv);
		}
	}

}
