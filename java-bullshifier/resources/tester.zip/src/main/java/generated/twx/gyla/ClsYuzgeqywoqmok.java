package generated.twx.gyla;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsYuzgeqywoqmok
{
	 public static final int classId = 482;
	 static final Logger logger = LoggerFactory.getLogger(ClsYuzgeqywoqmok.class);

	public static void metZrjgdmb(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valDwspqtfhogx = new HashSet<Object>();
		Object[] valMzppxussykm = new Object[2];
		int valWzplmbobsyg = 62;
		
		    valMzppxussykm[0] = valWzplmbobsyg;
		for (int i = 1; i < 2; i++)
		{
		    valMzppxussykm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDwspqtfhogx.add(valMzppxussykm);
		
		root.add(valDwspqtfhogx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Chennvurxrx 10Ygqwkcluite 11Msqkujmpswxt 3Pkmp 11Hmowvitvsxrx 4Mzwwk 3Yjrq 9Enbljgcgng 8Totnvswvf 9Wusxydxwhj 10Haawuxwkzzb 3Vgtq 11Ralcezjzgtab 4Kzwol 12Jwggbsctsoiim 9Ulibfolziz 3Amgw 11Sugdxzwhwenf 7Wteoeney 6Grarywi 6Iqwjsph 4Agrst 9Wprwysrhbe 5Hzwteh 5Pvpepp 7Gubukjdh 4Hgupl 8Mkovmxqwz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Kjxvwsczg 12Isfcwwlcdvstu 6Cfxpgnj 5Kxnumf 5Egqogm 3Vqqs 4Peplw 10Kzywbiggbtq 12Spnfvzzywosin 8Ibjdrjfnp 6Fhokfxa 5Jncvby 11Pliiuptekyka ");
					logger.warn("Time for log - warn 3Zanx 7Epdaopne 4Yrgoi 10Dckjmpagqlw 11Ozcxwleznltv 3Zcws 7Pgpgdmrq 9Ubhgbzsdmm 3Iusm 7Yqrllxvt 4Edpxh 11Dtfqotyzodon 12Lgbwaciwencrd 12Ryiqicngkpwpp 11Lsdsoovaaygj 6Dclmyki 5Viesij 11Dsoufwqjelxp 3Fwgu 10Tudesryahdl ");
					logger.warn("Time for log - warn 7Zpoikjqi 5Upxjjf 5Jjtlxr 8Butyrrmuh 3Jlff 4Uucfk 8Utfndtzmx 8Ntlvffhtp 4Yaaaz 3Khth ");
					logger.warn("Time for log - warn 7Dyxclayy 7Bffcsido 8Xbxqvwpxj 4Zpoet 3Pnsu 11Xphkcjszeazt 3Fyhj 11Blsqrgrgwdyq 5Dbolcp 7Ktiozdtw 9Lydyxwlofs 4Lbyws 8Zktfaaiog 5Vlddoj 12Kpzeogxuujsnj 3Wgdw 8Okfegttvo 4Bgrll 11Qgczsooeizkw 12Vdefscylpliph 3Tmio 7Jsvmtmrd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Lxwftztp 3Cozu 5Ipatil 6Xeoaesk 12Vcyubuduioosd 10Wjjzcqnkkxm 6Oprnhir 7Mdrlgiwk 9Cunzgpvgdm 9Zdtivlznya ");
					logger.error("Time for log - error 6Mrfksww 10Jldotirjoaj 11Kdfsehbrhngi 5Jvbexa 3Umpd 7Taeexzlw 6Vzqhlml 5Ncxdtf 8Qiyufvnff 11Nububhmxigtj 10Xurnwxypljb 10Ouuvqafyxrj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ufqu.ddqdj.nsc.ClsAchghkwny.metKntxpyoov(context); return;
			case (1): generated.fpa.lsm.ClsOulug.metXlljtomhuljxyd(context); return;
			case (2): generated.iotb.mlgn.hcur.ClsAdwtsoupvuwy.metTfsczzma(context); return;
			case (3): generated.wrwx.jsm.hgij.abg.imgx.ClsRhzgz.metZwioh(context); return;
			case (4): generated.kqywo.pil.grw.dvt.ClsJduhsebfba.metPsnsdnegsev(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numOmqeejghizz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex28137)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numJxmzffqajbp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
