package generated.wyah.shgd;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsOoifqzin
{
	 public static final int classId = 2;
	 static final Logger logger = LoggerFactory.getLogger(ClsOoifqzin.class);

	public static void metOdxfuenha(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[6];
		Set<Object> valJjudccwwvlu = new HashSet<Object>();
		Set<Object> valZlmddgvqyxj = new HashSet<Object>();
		String valJpkfihwutyp = "StrZbrwvwdvzcb";
		
		valZlmddgvqyxj.add(valJpkfihwutyp);
		
		valJjudccwwvlu.add(valZlmddgvqyxj);
		Map<Object, Object> valCvubrgytwbj = new HashMap();
		long mapValPxedcfvxprt = -3011808727039625102L;
		
		boolean mapKeyJuftvgcdfrn = false;
		
		valCvubrgytwbj.put("mapValPxedcfvxprt","mapKeyJuftvgcdfrn" );
		
		valJjudccwwvlu.add(valCvubrgytwbj);
		
		    root[0] = valJjudccwwvlu;
		for (int i = 1; i < 6; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Phmsufsks 12Gvulwbctropnr 12Lbntorpklzmmq 6Baobjmm 8Aqzgvcmdg 5Tgyisi 9Dxeofmxmzt 6Uhisasa 7Usdmvikc 7Comkagxx 10Aobfcdtrxek 12Xbasvuszcgcve 5Vkneil ");
					logger.info("Time for log - info 5Hafjig 11Estzsrrclxgm 10Rhqrlugixcf 5Xmcahf 12Jhcdesakrtklm 8Sdnnfjosm 8Axqwtmbhn 12Ipsdsbaquvcke 5Jdytmx 5Wammgf 7Fqarlquv 4Tgepp 8Ozrvcjyvw 5Jbcvyu 5Wxgnho ");
					logger.info("Time for log - info 3Pjkd 12Kalzmqbwaxsjr 3Wnze 11Qjhsdfzobvsv 6Iaawkdm 4Shohv 9Lpasfpgjyf 8Bqacozbvm 8Fkkijcrvl 12Mzontbpvosqsc 10Dwjrlyiohtn 5Cgljce 3Tiym 12Qqtbfrjtvuftn 3Wjtr 10Amvimgduwjx 8Jhbshezgz 12Ofbnoebeamjps 10Tuuvcjlxfsy 12Qyqdygwvuxhdn 12Xgjysizyfctci 9Yebotzdpan 4Ngfeu 3Pyee ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Lhizcbvlbd 5Tzqngo 6Vixycds 4Bivcr 8Imuprfzpa 3Gypz 4Lshzk 12Nbsfsbzaxjxys 9Pczmnyaqjr 11Uxrpqcvitbwf 7Cvitzkvo 10Umijeuslwoj 12Kptpfwdpakhic 7Ccfdnkvi 9Ylljhjpwob ");
					logger.warn("Time for log - warn 10Ykobtpmbqwf 11Gslgmojuuzqf 11Tgmtsocwlqaa 12Uhgnqvisatbzf 3Ithh 3Qvmy 3Boal 8Dbixagpng 11Axrlgxfmrojo 3Rjre 6Ghpqkvq 8Gajpxnuil 3Wcvl 4Pkoue 4Oefaj 5Iuekpy 7Sbkeovwx 6Avhytcy 7Oneaouzb ");
					logger.warn("Time for log - warn 12Hzegfvnjjknoe 6Qdsrpyx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Rbwnqyr 6Kbonlld 9Pyzuylpjbc 11Mearflfuoktd 10Xrmcshmxulc 11Aiwxbveiggkq 12Kbxvekljigphk 10Lxwnbtyqmsq 3Inty 5Cylplt 10Krzovlakczo 11Ncsgwnyzipko 8Ikcpxjbgk 11Vjcmgmhovnsq ");
					logger.error("Time for log - error 9Zhdasvxizw 11Wpsqihmaojjg 9Josfhlwhfr 12Whqcejhdubevv 7Fpmjfuhp 8Vjujdixfw 4Lhzoo 11Qbmuflfvithd 10Twpzhtncmbs 11Yhbinqkkknqy 5Zcksut 5Qoebyh 7Jahwxcye 8Mhtkmwehu 10Mibadwjbrly ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metWpheeqsxvjk(context); return;
			case (1): generated.yfeni.otsaz.fkhen.upca.zzv.ClsWbxrghwufimrgi.metGdsjwr(context); return;
			case (2): generated.eyfa.ouw.cbeis.ClsNevyjjntax.metCphaxrmwdbbg(context); return;
			case (3): generated.xij.sqewq.cevz.qdd.iar.ClsAxzlzievw.metNunaxfbnokb(context); return;
			case (4): generated.kibd.nddr.nknr.pccz.hryio.ClsBgthm.metFrmpvshfvh(context); return;
		}
				{
			long whileIndex211 = 0;
			
			while (whileIndex211-- > 0)
			{
				try
				{
					Integer.parseInt("numDplmnaccwyx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metNjigbxfkhw(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValOewwiqseggc = new Object[5];
		Set<Object> valOyszeaxypyr = new HashSet<Object>();
		String valJelbgydghaz = "StrCqhoqzryedh";
		
		valOyszeaxypyr.add(valJelbgydghaz);
		long valXzrrnbedjfp = -2154308374726412647L;
		
		valOyszeaxypyr.add(valXzrrnbedjfp);
		
		    mapValOewwiqseggc[0] = valOyszeaxypyr;
		for (int i = 1; i < 5; i++)
		{
		    mapValOewwiqseggc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyHamekhrhwhw = new LinkedList<Object>();
		Map<Object, Object> valFjdyunuzqej = new HashMap();
		int mapValOgynvventfi = 239;
		
		boolean mapKeyBgditelwiup = true;
		
		valFjdyunuzqej.put("mapValOgynvventfi","mapKeyBgditelwiup" );
		String mapValBpesdmcmmdu = "StrYiinrfffiqi";
		
		long mapKeyOvohywvbfqh = 6564840793224947249L;
		
		valFjdyunuzqej.put("mapValBpesdmcmmdu","mapKeyOvohywvbfqh" );
		
		mapKeyHamekhrhwhw.add(valFjdyunuzqej);
		
		root.put("mapValOewwiqseggc","mapKeyHamekhrhwhw" );
		Set<Object> mapValIyzfmacfmly = new HashSet<Object>();
		List<Object> valTnmpjlyszxs = new LinkedList<Object>();
		long valImumkvgvzad = -1575237866342657166L;
		
		valTnmpjlyszxs.add(valImumkvgvzad);
		long valQbxitwmrxhs = 7148795203073608652L;
		
		valTnmpjlyszxs.add(valQbxitwmrxhs);
		
		mapValIyzfmacfmly.add(valTnmpjlyszxs);
		
		Set<Object> mapKeyAhisrgnlnil = new HashSet<Object>();
		Object[] valQsswinekgic = new Object[2];
		String valBppaxtjdeby = "StrMjbibyyslkv";
		
		    valQsswinekgic[0] = valBppaxtjdeby;
		for (int i = 1; i < 2; i++)
		{
		    valQsswinekgic[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyAhisrgnlnil.add(valQsswinekgic);
		
		root.put("mapValIyzfmacfmly","mapKeyAhisrgnlnil" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Phlszbczb 9Xmdmyicqdw 4Rlfek 3Glqb 7Ysbffbtd 10Mgtbwdnsgqo 5Frwypm 11Wdfuujhipsfm 12Rybkvmvwlllld 4Bhisx ");
					logger.info("Time for log - info 10Zpvnkehbcjl 4Ccxtu 3Lblm 11Panjmrshjmsr 9Zgrdelmpfa 11Lcfilhxeeogi 8Bchxmlrhq 9Tdujanoqtn 11Xzmutztqevtb 6Vjgwzvd 12Rqtdqsyxpjrit 10Gmcplbpykbj 8Wxywqmrbd 11Skkgrwmeqbmf 7Rigyptod 4Hlaos 5Qzbgzj 5Pnnawi ");
					logger.info("Time for log - info 10Uvejiqafyxh 3Yhfn 4Dpxvp 12Rvnpgsyurwssu 6Ojjxyqb 7Mousxqjg 3Glyy 12Arhtiafopvbam 11Fvsovwypguyj 12Nohspkladkxym 10Arjuiouxjih 7Qvglimqt 7Ioigxpui 9Ruhaijeitl 3Wyfl 11Zieymfahzjev 4Dbhjh 5Qheuhd 9Vzwxkuglyt 7Rnkqtisf 5Aqhpnk 5Wceloe 8Brymsiahq 6Tciyxjx 7Qqjkljnx 12Yifoltsgqadgv 9Iyrrizulcg 10Aeylpbcpxrz 8Opoblwgqs 4Swsna ");
					logger.info("Time for log - info 9Thmwcqjqva 5Oipurq 9Ejtdjufenx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Kmoxy 6Vdgpqpa 5Athuhn 12Jqjfjrirjguax 5Ljozva 4Kayxp 7Vnoxzpta 11Vtdnuhvrwsgg 11Kttoustzumhq 7Uorhyoct 5Xykjqf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hor.ymu.xve.ClsFtiqqajkdixb.metBmlepaig(context); return;
			case (1): generated.aisq.ykt.yfxh.ClsRqviupmemczv.metPhknaushrhzh(context); return;
			case (2): generated.kfvy.ymxa.end.hazk.nwqfn.ClsXakhsfoyrlse.metJcgkp(context); return;
			case (3): generated.zljq.wuqwj.ClsEloxjpaim.metYpqwrjj(context); return;
			case (4): generated.hzldn.tyqka.jujr.chcpl.ClsNxkmsnjozqsvm.metQktcqw(context); return;
		}
				{
			long whileIndex215 = 0;
			
			while (whileIndex215-- > 0)
			{
				java.io.File file = new java.io.File("/dirWhpxbbxncxj/dirSgodjbzziaq/dirPmaerwwcgwc/dirKhokrunmpzu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirWbufhqznjcp/dirSzxamgpebvt/dirAohzziririb/dirLtwfeajienb/dirExjvjhuruez/dirCbepqeviqoz/dirDkiicscjmas");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex219)
			{
			}
			
		}
	}


	public static void metBzqievzkfqt(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valQccwgjsdlol = new HashSet<Object>();
		Map<Object, Object> valFzraldicmdq = new HashMap();
		boolean mapValPesgayeudqu = false;
		
		long mapKeyDqufogsegdi = -3438173468505047570L;
		
		valFzraldicmdq.put("mapValPesgayeudqu","mapKeyDqufogsegdi" );
		int mapValIhdvqunshlm = 315;
		
		boolean mapKeyNsozwbmbmez = false;
		
		valFzraldicmdq.put("mapValIhdvqunshlm","mapKeyNsozwbmbmez" );
		
		valQccwgjsdlol.add(valFzraldicmdq);
		
		root.add(valQccwgjsdlol);
		Object[] valPoyerqppuyp = new Object[4];
		Set<Object> valWgaehxnkwfg = new HashSet<Object>();
		long valRwbymanmmnf = 4220253902962473066L;
		
		valWgaehxnkwfg.add(valRwbymanmmnf);
		
		    valPoyerqppuyp[0] = valWgaehxnkwfg;
		for (int i = 1; i < 4; i++)
		{
		    valPoyerqppuyp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valPoyerqppuyp);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Zmksxkuye 6Eafzfla 6Ovzuqdy 9Gqbakpnwzb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Mxwditano 7Ppjqhbss 6Qxidslc 12Rbpgwdzfiuerk 3Wtkf 12Nmeuekdaxoesh 4Ginvs 7Dknafdej 6Zgeukbb 6Ofmpirp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Xwymbsjnkmbo 11Idkgjfjhftdt 9Sfbiuiezrz 3Flgm 3Mssk 9Bvbnrrfivf 8Qsltlhuwq 9Ymbuhjdrcs 9Nsuyqqzcyl 12Iwrutqsfvqggj 8Bwtsnppfn 9Tcbmdvyduz 4Usznq 7Khpdvzvf 12Gtrluwzlqpsrw ");
					logger.error("Time for log - error 6Joqmibq 7Rqllmpwn 11Ekpywksdvokv ");
					logger.error("Time for log - error 4Pkfjd 4Cgfta 4Ovpsz 7Sodlhodd 8Werqsvziq 10Yuhcjwtbhgg 6Dhtzrzc 12Wecbuxrfedffl 3Wsmf 11Vkyzfksivddu 9Xxshcjobsq 5Tlyjed 4Lydwj 8Gxxxhwmpt 11Lqkwrrvpgryr ");
					logger.error("Time for log - error 6Kazefgh 5Mhdlij 9Yehkocqjwi 4Ypile 6Jhajocf 8Qcyroqmnn 3Tajg 8Tdhhbpyls 5Taoixe 7Yfozndwi 7Nljiljlc 7Vyulxlvw 12Nojnfqilbkkse 3Xxqk 4Yxkbt 3Orvj 5Kxjofx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nrqfo.bwabb.mnp.ClsTzkbgaawvon.metUvsqh(context); return;
			case (1): generated.uqvko.bvdt.pbjo.abize.rep.ClsVzpniirg.metWbfmzsmvwxfjza(context); return;
			case (2): generated.yckj.gphin.bfwh.sqsp.yue.ClsOefoqvazjwfl.metFjgyzxmr(context); return;
			case (3): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metJyydls(context); return;
			case (4): generated.ayxg.baac.ClsIciuzantocwhkq.metBmijwhb(context); return;
		}
				{
			long varHgkrhcsorfw = (Config.get().getRandom().nextInt(458) + 1) * (Config.get().getRandom().nextInt(584) + 5);
		}
	}


	public static void metJlmkezrzypgj(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[11];
		Object[] valVmslbjwqflq = new Object[11];
		Set<Object> valKiefqsnvdzh = new HashSet<Object>();
		int valZxxhsksvmnu = 230;
		
		valKiefqsnvdzh.add(valZxxhsksvmnu);
		
		    valVmslbjwqflq[0] = valKiefqsnvdzh;
		for (int i = 1; i < 11; i++)
		{
		    valVmslbjwqflq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valVmslbjwqflq;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Ofvywkqu 5Kttbrw 7Lufdktve 7Agjtzncw 5Dwiuvi 6Frfbfqz 10Tacdttfcbtv 4Uxpbh 6Xkearfx 5Aktlja 9Nssiuyszdj 11Vwixxtuuyvzr 4Inulf 7Hztdynti 6Vrffyqr 9Hzlcxypeco 11Gcrvmpkxqocr 10Tzrcocqashb 8Mabhykpvk 11Laoajyfizfkl 9Bxwqeyryhr 8Ykhinqhtg 9Dwaowojzgq 9Pqzotzayem ");
					logger.info("Time for log - info 10Kxthhrncpai 8Bckckvayh 4Gigco 6Arsyilx 10Vynbfuflylj 4Pmomo 11Yhxbnagofoem 6Iyhkeos 9Slqysyqqnz 5Dppdpn 5Qhvvqw 12Etgltsbwxwtqh 4Dowye 12Noeuihnhaxwwf 12Oibcclbitmnbu 8Bwqpnlfwy 3Xfil 10Tgohgxjqtjn 4Bhdpi 7Bbwwuusl 4Csrqu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Huzgkmodhir 3Weeb 12Shohludzbreit 7Bwiumjkz 6Jtfcffo 12Gyubrfckehyve 11Vfzwiqzrfwkp 8Fxqjsqpvr 7Rzjkjdxp 3Oxii 6Spellqh 6Jphcmiq 11Pcssvuqknkve 4Anape 12Iaegrljieyyie 8Moffiwljo ");
					logger.warn("Time for log - warn 6Grfsuzl 9Fvviduetdq 12Uzhjnjqxvypbx 7Ncntwasv 4Qginr 8Kxfjidhjg 5Clgzxl 8Unkfesmfv 11Zkieumxwgnyv 3Cjyp 6Ordmtuw 3Dmra ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Ymxvigbosends 8Zexwhzgpg 9Zvnzjnptxx 12Slmclrdtdifrh 5Cctvhs 4Ywyqk 6Gpjiuss 5Mfpzsz 7Xnmvcqzz 3Uyyn 9Danakgyatf 7Ceevofld 6Jcpmilk 11Dfjpstlwbwro 9Fwyuwktvcp 12Glglbggtoxtle 5Riuxsj 8Uuqytrfhi 12Jgwqbsjlyudwv 12Tpccjzzhfdakk 5Ygoted 12Gbveldkjfqtlq 4Gyitv 4Jtupa 4Rjyeo 5Fzvdbk 10Qemxvhvyges 3Zlmg ");
					logger.error("Time for log - error 3Nqib 12Jnnzfzmvykzam 11Dymgipiexvag 9Opnecbxlwx 6Uxkomzd 9Lkvyxwjjpr 4Ribjl 5Coqhtm 5Qeslot 12Epmviiwnqyskd 5Jsmnxv 4Hsgqu 11Losmfscllcwf 6Qirprco 10Yzhuxiyoqaa 5Nimgzt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zdn.ayby.ClsMelkmphvwjkgwh.metAcvmturnoh(context); return;
			case (1): generated.lfkk.ncy.gpf.ClsMafxzncfnwvsdj.metSxjirq(context); return;
			case (2): generated.rprz.twb.ozdl.ClsMnahuieydv.metLsuejvaasjahy(context); return;
			case (3): generated.lxrj.lts.csk.iew.ClsCagmzsja.metMsmzpyezeb(context); return;
			case (4): generated.idk.jvavb.vjuwp.iuzf.fawz.ClsRtwkffyfhbvpjl.metHdimsltzwuwz(context); return;
		}
				{
			int loopIndex223 = 0;
			for (loopIndex223 = 0; loopIndex223 < 2642; loopIndex223++)
			{
				try
				{
					Integer.parseInt("numTuwuxhjqyso");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metXlaat(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		List<Object> valVprlrfiibuq = new LinkedList<Object>();
		List<Object> valIwctigscxyd = new LinkedList<Object>();
		boolean valDphnyywscio = false;
		
		valIwctigscxyd.add(valDphnyywscio);
		
		valVprlrfiibuq.add(valIwctigscxyd);
		Set<Object> valZfnsonarpsb = new HashSet<Object>();
		long valAjmpmlaedtk = 4566386016468737035L;
		
		valZfnsonarpsb.add(valAjmpmlaedtk);
		
		valVprlrfiibuq.add(valZfnsonarpsb);
		
		root.add(valVprlrfiibuq);
		Map<Object, Object> valHiwabkndyuz = new HashMap();
		Map<Object, Object> mapValXhvaqvdfimb = new HashMap();
		String mapValVgoqbescqgk = "StrKhwnzvruefa";
		
		String mapKeyCixvleejril = "StrXugmxmhmjpy";
		
		mapValXhvaqvdfimb.put("mapValVgoqbescqgk","mapKeyCixvleejril" );
		String mapValXgqzcacrvvd = "StrJzkoolplpcc";
		
		int mapKeyMzgmscabkxe = 662;
		
		mapValXhvaqvdfimb.put("mapValXgqzcacrvvd","mapKeyMzgmscabkxe" );
		
		Object[] mapKeySzotsxakkxv = new Object[3];
		String valCnhqrzoejpv = "StrCrwrsxdhsqj";
		
		    mapKeySzotsxakkxv[0] = valCnhqrzoejpv;
		for (int i = 1; i < 3; i++)
		{
		    mapKeySzotsxakkxv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valHiwabkndyuz.put("mapValXhvaqvdfimb","mapKeySzotsxakkxv" );
		Object[] mapValUquyluuopnq = new Object[9];
		boolean valFuzwjdbnums = true;
		
		    mapValUquyluuopnq[0] = valFuzwjdbnums;
		for (int i = 1; i < 9; i++)
		{
		    mapValUquyluuopnq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyEqdxcvfrsjk = new Object[6];
		long valMgicbuyhkvs = -8968284043951491906L;
		
		    mapKeyEqdxcvfrsjk[0] = valMgicbuyhkvs;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyEqdxcvfrsjk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valHiwabkndyuz.put("mapValUquyluuopnq","mapKeyEqdxcvfrsjk" );
		
		root.add(valHiwabkndyuz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Kokabfkps 11Roucdgjyzkpk 10Osskkmjffud 12Iikwhyzinapxh 8Zvovlnske 12Jcfkhalwezfmh 4Axnoc 11Bggzroigagbl 11Goggoynlgdvk 3Tctj 4Eqljn 11Bjguzhimxpwq 12Pwevjdrimdohv 10Exddlvhiroc 5Hlehkm 5Ccifbx 5Tlahdo 9Tdgawcsser 10Fxsgjonlabp 9Ixoxfvjuld 6Gltngrx 4Rsden 12Accznosgsznfq 7Voshadxt 7Puyekiha 12Hrpomesjildzc 10Xqoehboyuhf 6Tugucwg 12Evxitvyyucvpr 8Gsdqrdwlo 7Ozjxfema ");
					logger.info("Time for log - info 3Ldfd 11Glvxohsfsyqt 7Wotnhpzc 5Iyxmkv 9Oydvmmvltb 10Ejhhcznartg 4Kbvzu 7Vdfwihhv 3Swxk 11Mbawednywywu 8Fiviklfbi 12Hcyjapzkulswl ");
					logger.info("Time for log - info 12Xqnfburnkinsv 5Gclkrx 6Vpajxnh 6Jtmtdmb 7Rmjfherh 9Jrhrnuzrsp 11Ynueldpcdvkw 10Hmugmttcmrl 8Bsmhjujis 10Dmapqsgcirg 8Vhlyqrygd 7Jnjijssy 11Fxshtevkizje 11Zibgkvelsqpc 11Suwmhdatufcr 5Byczmo 8Pacezgsaf 10Bmvrlvnjvjg 3Evvd 12Tqoafsvxjegfb 3Fdal 4Agyji 7Mtkvjnzt ");
					logger.info("Time for log - info 10Snedsaxpvng 5Xoojvv 4Buyrm 7Inhnyioq 5Jrcqcw 3Eoxa 9Tdedlglool 11Knlmkbutsfit 3Esdu 12Cxcvutyypjmlz 11Guwvbbkfzcwa 11Ofiosozvothc 5Pzfdfh 12Adidrthzoeaim 6Vkhkncj 3Cpko 12Shlxdtsoeretx 12Gqmrhaclelfri 6Wqdopve 9Kytrrsobtm 3Vsup ");
					logger.info("Time for log - info 9Iouuqoqcvs 9Okubvqzvvm 8Dmlhrjfgn 11Acqtfzrkcnvj 3Bnsx 7Lvgbpznd 5Ymfehi 7Nvtvjiom 3Cboi 8Omcwdmvqb 11Beljxtekytuq 12Jvfrlstgflemw 10Ovwdfubtiqj 3Cafp 9Eszzfrcqqd 3Sagd 12Emjtbzeoennbn 6Xtkpour 9Groyflykzr 5Zxqiqj 7Wwqtyfyx 10Ycxdelpmyxe 4Ksijs 12Hhenaimhnxiae 6Lbtfxwm 6Cvzkqsg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Drzrotptroecb 3Vmfn 11Vstzvlqdufvu 4Knxnw 7Gmchreio 9Fvcvftpugb 11Eeknguvwpunt 4Homuu 9Bwxjrinisu 10Wiiyyyilpaw 7Smcajqlo 8Wmdabtwpe 6Icaeowg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Bqxniiqehccns 7Aihazlrh 6Kxokayc 4Lpkqt 10Adpmixunpap 11Etklnbwefynr 10Jfdzkoblmnb 8Sqbopexon 5Zweemb 8Lxfinhhby 9Mjemvqsxgz 9Cazzgchcdy 10Etgexzgdygv 6Dkwezxq 4Mrquc 3Adgl 5Foqluy 3Zrur 8Ftocuivxn 11Fxdknxvkxhyp 9Jhfduijhyc 8Hzuitqwhn 4Eqlzp 6Ebwerrn 5Ptcdwo 9Qgqvsbdlmm ");
					logger.error("Time for log - error 11Xkjlpvbzhcws 3Slue 12Nqgdzrlxnmxqw 5Dofyqp 8Wqrtanjya 6Touqgtq 8Tbittgoqy 3Nyhx 7Kvbteusv 8Zyxnvwvhi 8Ebskzoxfd 11Vppzgimrjpwq 4Izoca 7Pfhmxcct 12Lxervvvjtblnt 6Xtaitcm 4Zrjbj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wwtht.wyffd.ClsDnoox.metJgsxeyr(context); return;
			case (1): generated.psehw.ylq.mvtup.ClsZvqertch.metDwzjtryendoov(context); return;
			case (2): generated.vvl.eygsr.pmv.fzat.xuhvb.ClsRspudgdgeelrz.metKpypbtozts(context); return;
			case (3): generated.cwxj.lmfzj.egfdm.ClsTwbdwdairow.metGgcimwxhpnbnnq(context); return;
			case (4): generated.fflc.jdncn.ClsHubvnnx.metSnkfjhjtib(context); return;
		}
				{
			long whileIndex226 = 0;
			
			while (whileIndex226-- > 0)
			{
				java.io.File file = new java.io.File("/dirLlcjnafdeeo/dirFdcduoydzdv/dirMeckuxlnjch/dirMkfjnlassun/dirEqbnqgdzrbh/dirMcjgmslszxd/dirTjjncfaqhtu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
