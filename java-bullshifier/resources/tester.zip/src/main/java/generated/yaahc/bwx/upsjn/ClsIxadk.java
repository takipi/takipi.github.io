package generated.yaahc.bwx.upsjn;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsIxadk
{
	 public static final int classId = 129;
	 static final Logger logger = LoggerFactory.getLogger(ClsIxadk.class);

	public static void metFpqlzmjobw(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valJhepuemnxhv = new HashSet<Object>();
		List<Object> valKwzpoigfuri = new LinkedList<Object>();
		int valFwbpsuunemp = 301;
		
		valKwzpoigfuri.add(valFwbpsuunemp);
		
		valJhepuemnxhv.add(valKwzpoigfuri);
		
		root.add(valJhepuemnxhv);
		List<Object> valUoqzxgpnhrq = new LinkedList<Object>();
		Map<Object, Object> valNswzxgehpcj = new HashMap();
		long mapValQhtmltxydje = 7469436995496835593L;
		
		int mapKeyDxgmkohjeuc = 959;
		
		valNswzxgehpcj.put("mapValQhtmltxydje","mapKeyDxgmkohjeuc" );
		boolean mapValZewyriolhne = true;
		
		int mapKeyZxdpbqirfzz = 796;
		
		valNswzxgehpcj.put("mapValZewyriolhne","mapKeyZxdpbqirfzz" );
		
		valUoqzxgpnhrq.add(valNswzxgehpcj);
		Object[] valXoqjzwwqplb = new Object[11];
		boolean valEhdzgfsfmrg = false;
		
		    valXoqjzwwqplb[0] = valEhdzgfsfmrg;
		for (int i = 1; i < 11; i++)
		{
		    valXoqjzwwqplb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valUoqzxgpnhrq.add(valXoqjzwwqplb);
		
		root.add(valUoqzxgpnhrq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Sezgu 6Lsmhnvk 6Mlhcaww 9Dzxobfgupv 5Slwqht ");
					logger.info("Time for log - info 11Ecydywthjdel 3Urna 9Spkvlywful 11Vdxjupqxhayl ");
					logger.info("Time for log - info 7Dmahmqyf 11Hjeevrxpuhkg 12Cqajqdljmidal 12Jvxwoaplykoap 6Busvkjm 4Sbjmg 5Vxhtkp 4Uvefv 7Zijkylmd 9Chnawmlqlo 11Yqkzsbpjfuse 12Ollujavenwcxg 8Oeqoxuswf 7Tnfflflh 8Kenqwnbcg 3Ziiu 6Cbkqgdu 3Bfwl 8Hzavogykh 8Wlbjburro 12Qbhwqiodctpfk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Slgh 12Zfcbkdmwjojzt 9Ditgshvtwr 8Igjufybdf 10Bdltjoxnffk 8Ftstyykzb 6Tlokhnc 11Vrzgwfitqmqr 9Nkdwxoneyh 12Hspqcvlrsnnko 8Miabdsytg 6Vgofhip 9Qtxznmfsif 4Rpgfw 3Dagi 8Yaichribg 7Xtgqgyse 8Ljqzctlui 7Opdjxlek 5Tvmgtg 12Eluacuacrpwkw 9Gfejmpytey 12Pvkepdfggcjkc 6Chvdexw 9Srmbuxfndt 10Ascezkkdzwq 8Jzjpccdld 7Vvktgssl 10Koyssgzeaty 11Tmewzsfyyxll 12Tqfbnljxlrpcu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Wwaqofrozg 12Bxsehoyxfrgkb ");
					logger.error("Time for log - error 4Shutj 7Kjwlbwrw 6Gqgdfsf 10Drfiilahajj 5Vncafl 7Roiefqok 8Cylnrdxgt 9Ibixyxooaf 11Vigfyjoljclm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hiv.mgg.zog.vzpz.ClsYqryx.metXcirnzx(context); return;
			case (1): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
			case (2): generated.ncau.ibhi.ttuvu.ClsHlbobsu.metTahxaryiutr(context); return;
			case (3): generated.wier.vwsz.frtoe.zpo.ClsRwhkekxcsmjus.metDnxwcgye(context); return;
			case (4): generated.kklo.eog.twpb.eja.vmrt.ClsCtkkdlrnk.metMzowgzzffz(context); return;
		}
				{
			int loopIndex22346 = 0;
			for (loopIndex22346 = 0; loopIndex22346 < 2264; loopIndex22346++)
			{
				java.io.File file = new java.io.File("/dirKpxfdayeoaw/dirWglzrykbmlq/dirPfbhbsfdkdm/dirTavowoyxnxi/dirYhggidngopa/dirBpasphcsosu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varCmaozlspmps = (927) * (5099);
			int loopIndex22348 = 0;
			for (loopIndex22348 = 0; loopIndex22348 < 8525; loopIndex22348++)
			{
				java.io.File file = new java.io.File("/dirVscwimazicb");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metNgwdnrzldyl(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValSaqdaswyqxa = new Object[7];
		Object[] valDitcqkorrfv = new Object[11];
		int valXewwkytxtfg = 367;
		
		    valDitcqkorrfv[0] = valXewwkytxtfg;
		for (int i = 1; i < 11; i++)
		{
		    valDitcqkorrfv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValSaqdaswyqxa[0] = valDitcqkorrfv;
		for (int i = 1; i < 7; i++)
		{
		    mapValSaqdaswyqxa[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyIvohzfahdnb = new Object[11];
		Map<Object, Object> valVqpskxkhlac = new HashMap();
		boolean mapValDdbouuuuuzq = true;
		
		String mapKeyAbwrbgdunmc = "StrOmhikfkaqdq";
		
		valVqpskxkhlac.put("mapValDdbouuuuuzq","mapKeyAbwrbgdunmc" );
		boolean mapValNkbpkmmyqdq = false;
		
		boolean mapKeyJrqgjilpzeg = true;
		
		valVqpskxkhlac.put("mapValNkbpkmmyqdq","mapKeyJrqgjilpzeg" );
		
		    mapKeyIvohzfahdnb[0] = valVqpskxkhlac;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyIvohzfahdnb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValSaqdaswyqxa","mapKeyIvohzfahdnb" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Jrxymhlzz 4Ppquc 10Hcawhejfhty 12Ibphhuglbumqj 4Esvgj 4Jvkfs 12Shfmtepowtggq 8Vywqnmivk 5Pdoxoy 7Qzmfhxzh 5Riiaaw 7Ayhibcbv 12Dnneyzxiraxgr 8Splbelcey 10Cblaktkqbsd 11Fxzgnykxhecy 9Napqifufdp 6Mbjokjv 7Aarzzbmu 6Axjcfvl 9Iblbpxrdfy 7Rtmihunq 10Kibgvpemdfb ");
					logger.info("Time for log - info 12Ncdphlttxgyxg 11Qcfgrszqlpus 6Nckmbji 12Bvwfsrevduela 4Zthiy 4Gotew 8Bfmlblkuj 8Prndmobim 12Atiaeiwewxrvk 7Tedxaoan 10Csmhenukmgh 7Bkmgolhf 7Kkewphls 12Eelupcwuyxllc 9Jnbwsvnnhq 4Ycatm ");
					logger.info("Time for log - info 11Bvxvebqhueml 12Fslpxitiqmfyi 12Jxjrvrqbbxbzr 6Qkegpro 12Azipvaiogojnw 11Mqxntomruyal 9Ptkdxvxfbk 5Tgfhtn 8Sbpvwaohh 4Fjqcg 10Wqnaikqlblq 8Dfqihabjm 8Esmswivym 8Ddxbalvjc 12Qayibcpeoiucr 11Pwvqwvxcovpv 3Domr 5Efthrx 10Pnkdxynvnmm 3Czch 9Prbssaovct 8Yjorzjmzl 5Cvprui 7Fhmrbxxy ");
					logger.info("Time for log - info 11Rvysewnzxxrc 5Sqfryh 11Rhnuqpzdvefq 6Gcfzdah 10Gsxyrtrpowr 3Ecor 4Uvzlf 3Wzwk 11Fndvasvnegsh 7Rewxsqpp 3Kgrz 5Wlkkox 12Vqbysnmapnkfv 12Djsflgdeirujx 5Fwspda 6Ktgcdop 12Gpatwjqznyfvr ");
					logger.info("Time for log - info 4Vchzl 8Dvlqcvbrw 12Miccvnjnzgrzj 5Vuzslm 10Pdywwhrnbpg 11Ujdkgxgrrwff 10Nsnjmyhjrsx 7Uxvmgatv 9Nenjyaxmmi 9Kzjolejrxw 9Uhfwenixbg 6Zblutpk 4Eychs 6Pjcejak 4Qzeme 9Zengvyxrde 9Pjzogpolbw 3Ynhx 7Yfllxyho 12Ywqzvhekfbpyu 5Glfxer 7Sqcbdxlx 4Kvkqb 8Lehrmkyhk 7Cxrcirgt 11Pliawjvtdjgu ");
					logger.info("Time for log - info 12Wifuobqjumqkw 8Xvlsdzwgn 4Wrfuw 3Opxq 9Bwebjcznhs 6Kqyawsc 8Npokzryfh 10Ljhfjgcqvbk 4Cjlry 3Rmua 3Gywb 3Htlq 6Kyyrvcf 3Zvls 12Ctoxlnrrtckkd 12Nihysprsodifv 3Wtbf 7Wguatxzx 6Qmrauqm 10Rnjvtuinyjz 8Jrczqqrxk 11Rnetvembfeoe 3Jllh 4Lmtmx ");
					logger.info("Time for log - info 7Rjyqgyin 4Gkdyt 10Dbduzyuyhiw 5Xzeony 5Zehwgz 6Umswqjb 12Xzbhomyuxwure 3Kmba ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Peef 5Stonpt 10Ppslngifvcs 5Rgztsm 10Tfrzbuboufk 11Fctgoixsvtuo 7Ekujbrav 11Bkondsyapxzh 6Htfojog 4Upoyp 5Gvtwbx 5Twunhg 11Nuonoennorlz 4Hypmu 3Agxh 11Eauqeyegrnhv 12Pxadgyntrgfsr 5Crmcsv 5Gmjibe 3Tuwu 6Tpwvxpb 3Yspf 5Oocgyq 5Rxorte 11Fqkzwwmogrjm 10Kgujyunsjzu 12Nijksbzpepixb 4Mzvwk 12Qscvxnsavnuzj 12Xkvokuaqvswaz ");
					logger.warn("Time for log - warn 9Tfozwnvlth 3Qgzp 5Qwddro 7Pahnmegh 8Jhfcbhouy 12Nbxdrjnvqiyhv 7Gpjrkyoo 3Mops 6Hljmgwq 3Yhig 10Unuyweihnex 7Pcjtdqpr 9Cswzotvpud 5Rrovzm 6Txttisx 7Cvqfalql 3Idss 5Dxchyt 7Jvyaakuc 3Lxxx 10Eaalkqeuqlw 9Josysljkpr 8Fzwxyxuix 3Uxax 3Ynwt 8Vzamejrhd 5Iybyrd 10Ynxzvdjrhzl 10Kgxapryxzjx ");
					logger.warn("Time for log - warn 12Achfsznjblyhh 4Jghdw 5Qvific 5Zbcnxg 6Zljylom 7Fopwkuti 8Yvvuiqenn 7Uujuwdwu 12Kneoqjjgjzmhq 10Layhxkhaojq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Gzivhbg 6Kxbqtdm 12Nsrvhibagfnui 9Jyjdzhqbvc 4Fvcdq 8Rymhhrdto 4Ikogy 5Gpiajx 12Qhhswiilxwxxi 10Zpuwwvcbxvh 6Zeyenqz 11Mmabecelgtpr 6Rtaakhl 10Ltgjivjwsqo 9Pliptwkpld 4Gakyd ");
					logger.error("Time for log - error 11Zxfjcscfoyyz 4Qxhfb 3Ktpw 6Lcruhby 3Mpof 6Qhycgel 6Dkvorkk 10Zcdpmbgdlcf 4Ddbfb 7Zidvughc 10Ctvitqdamfo 7Wdhcrnfw 10Bzzncmwnctg ");
					logger.error("Time for log - error 10Ezqfearrewh 8Bccbzwysa ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metSkbraqotkaceil(context); return;
			case (1): generated.epi.quvm.dwt.ClsQoovjnirkdxzq.metTujwas(context); return;
			case (2): generated.otrak.sob.wdjq.subj.sgplp.ClsIiictfycdas.metTnuzyugemny(context); return;
			case (3): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metNvgqnwoj(context); return;
			case (4): generated.zljq.wuqwj.ClsEloxjpaim.metYpqwrjj(context); return;
		}
				{
			int loopIndex22352 = 0;
			for (loopIndex22352 = 0; loopIndex22352 < 6145; loopIndex22352++)
			{
				try
				{
					Integer.parseInt("numIvliifgriys");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metPvfldng(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValFnnzjhwsgsb = new Object[4];
		List<Object> valEkposdredtl = new LinkedList<Object>();
		long valQyzyzwjksaa = -7829883126349945227L;
		
		valEkposdredtl.add(valQyzyzwjksaa);
		
		    mapValFnnzjhwsgsb[0] = valEkposdredtl;
		for (int i = 1; i < 4; i++)
		{
		    mapValFnnzjhwsgsb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyTeywxtzojwr = new HashSet<Object>();
		Map<Object, Object> valIklsejeecjg = new HashMap();
		long mapValGygxqrkeggu = 7697700204459135341L;
		
		String mapKeyUuzekmgdybo = "StrWtuygrkpouf";
		
		valIklsejeecjg.put("mapValGygxqrkeggu","mapKeyUuzekmgdybo" );
		boolean mapValJfbzekqpnxk = false;
		
		int mapKeyFxhuhjprzjq = 580;
		
		valIklsejeecjg.put("mapValJfbzekqpnxk","mapKeyFxhuhjprzjq" );
		
		mapKeyTeywxtzojwr.add(valIklsejeecjg);
		Object[] valKbnmbrnhnoy = new Object[10];
		int valXjzpexlmxbb = 676;
		
		    valKbnmbrnhnoy[0] = valXjzpexlmxbb;
		for (int i = 1; i < 10; i++)
		{
		    valKbnmbrnhnoy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyTeywxtzojwr.add(valKbnmbrnhnoy);
		
		root.put("mapValFnnzjhwsgsb","mapKeyTeywxtzojwr" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Rzfaycrq 6Gbcmmdn 10Jmjijyfyrqx 12Jwfkhbvzeratw 12Butokapnubgas 11Gneftxygggfv 8Pbglfhoiu 7Hwmydcyz 11Lohxnbsqdgzs 6Mcxhstx 6Tulavsi 10Ohjaumyurco 3Fyme 4Edncy 6Jcltfow 4Lxctz 5Lyzcsv 10Eqhkasrjyyx 8Ufsnypkzg 6Xoudpde 11Vrtnlwjjwbdp 9Wnlhgsdmmp 8Jpseishpj 5Bsycnr 6Webkzco 8Rwkjoarot 5Fsfueg 4Teljj 4Ivgsy ");
					logger.info("Time for log - info 3Tmqi 8Rwurqeynn 4Yhhrr 9Swsegslumq 9Qnlrxsiyvd 7Fdjzkqkz 3Qwua 12Ieecljviqocph 11Tzqqayoheror 7Fwxsixgb 7Dmbwdzwy 3Xisf 10Rnmpkfougma 7Tlmgpbxv 10Ydofbysqjkx 6Owelvky 9Ztahxbkgdk 6Wzgbtev 8Azyyfubyu ");
					logger.info("Time for log - info 6Uqsvhqd 7Rjcjhnqt 11Uuwnzobxlkac 4Sdczh 6Stlisho 11Szxpggdqpugm 5Ucneao 7Zyhwsgjq 6Wxcwmtt 5Mjaovw 10Blhtqvuabns 7Oibruowv 4Vntsc 6Ofgcura 3Ezpw 11Ierxbmaqzbuz 5Fdzzbd 10Ismvajkxowj 7Zzaimvcg 6Ndroxrw 12Mkltzrgmimxjl 4Uwmfw 4Msgpa 3Mhuv 10Utqkmgbezpt 11Tmmvxvtshouv 12Cinhpbuvevyyb 9Lisrbxgtlr 5Kuvogn 10Jyyqppqsjjx ");
					logger.info("Time for log - info 3Fhvv 3Vxga 3Qvod 6Ojtbbxw 10Obvpgvhoaic 9Myaepespge 7Urfbabcf 9Ateafxzwmr 11Vjixaqdwgane 12Ejsebdbfpfrxo 9Hqnftknkwi 12Lgrewqjbukfpm 11Jftbiuzqoqct ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Nssa 10Gsdoyziipek 5Cedies 7Omfjbpzm 7Hhasdxep 12Aixlrsplijxzp 11Wqmrukwwisvd 3Mjqs 9Pgrpyoyabd 8Gfduuvrtr 6Hambthe 5Bcwvkg 3Qopj 9Nkdhjffbcd 11Jcbacqzmmgbr 3Mfad 8Hwajchjvv 6Ymyzrou 12Lpusnfflqvmws 5Adbubx 8Ckulrprxj 9Newcnsfzwm 11Tzgvmwpotyir 12Uvuvexhzbaltt 8Nhavlgzjz 5Whhidz 3Xwod 5Jqqnlj 6Xgvzzwj 11Tfddvtjsuioh 4Uwkkb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Fguqbagqerotv 5Wvifdy 3Onzp 7Vvdcnxru 7Zjhrwakn 8Jbgoertug 5Keqatq 5Dmbfqj 11Izciiksukeac 4Wsjiv 10Mhpqmgxdzqi 10Hqwzkzcfldl 10Yuwtagjfiic 7Supqogyx 10Zjjthcuqkpb 3Apqv 4Fsojm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yfeni.otsaz.fkhen.upca.zzv.ClsWbxrghwufimrgi.metTejfjnxzfgv(context); return;
			case (1): generated.lbx.ujwf.wayq.ClsEtipntwjjs.metYkgppbepgd(context); return;
			case (2): generated.zsia.unbq.ozcif.caj.yiysy.ClsRbxlkiybibs.metDwuywtpaislqn(context); return;
			case (3): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metJvnsuyubxdox(context); return;
			case (4): generated.ctymn.uic.kza.ClsBochsrrjh.metAxovamacllktsg(context); return;
		}
				{
			int loopIndex22355 = 0;
			for (loopIndex22355 = 0; loopIndex22355 < 8659; loopIndex22355++)
			{
				try
				{
					Integer.parseInt("numIdpxfunbxjy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((loopIndex22355) + (Config.get().getRandom().nextInt(537) + 8) % 744704) == 0)
			{
				java.io.File file = new java.io.File("/dirPsnumsdqirn/dirNpvfffieigg/dirCtigszwjkvt");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((2977) % 580482) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirKeuskjkdist/dirQnjilaojiss");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metYrjkkwdkjqjlsx(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valDogpqaiddcp = new Object[5];
		Map<Object, Object> valPcowedvgbpy = new HashMap();
		int mapValBscwsrlnpjr = 531;
		
		String mapKeyMcxivjavoyb = "StrNibawcmywoq";
		
		valPcowedvgbpy.put("mapValBscwsrlnpjr","mapKeyMcxivjavoyb" );
		String mapValCbedickavnv = "StrMssevctbwvp";
		
		long mapKeyIorljdukunt = -3859107930376451943L;
		
		valPcowedvgbpy.put("mapValCbedickavnv","mapKeyIorljdukunt" );
		
		    valDogpqaiddcp[0] = valPcowedvgbpy;
		for (int i = 1; i < 5; i++)
		{
		    valDogpqaiddcp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valDogpqaiddcp);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Ywcuamj 10Onymslcvhud 10Ajuwcvrzxjb 3Czvn 3Etvt 3Hntc 6Ycftoar 7Nfkckvcv 4Dsrxw 10Iloozikahvw 7Vaiensog 4Oxthe 3Sxgw 8Anlqouqps 4Dyrkf 6Tfhcijb 9Pdxksexnpo ");
					logger.info("Time for log - info 6Wnrmhex 9Tgldwtlanz 3Ehze 7Uacgqopf 11Rdkdolnoroyk 4Tbbvx 9Zkbqeaamje 9Zzzoylaqyd 11Qhnnabbwhvhx 9Nwsphduuvn 12Ynrmsqzchskqh 5Zqlibw 6Pdysnja 5Idhxbb 8Busbqdvbb 8Etyrojejs 8Nsobrryfk 9Wzkdnbwiwq 11Tspuibkkckhs 5Kfwyjj 4Vdqzh 9Mbenrdtggl 11Acadcajqtipw 12Xaimbfbmovqyd 6Nkhqhuv 11Dgguxcbugyiy 10Sfpkwtvpnus 9Qqrpyavkye 8Bwszifiym 11Snuhwxljsind 12Dzgyioxyyipoi ");
					logger.info("Time for log - info 4Kzajr 11Bnrggfgwrqub 6Ijotsky 5Zpoaza 4Fnmra 5Jatevq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Jcqzqwqtmmj 4Wwsbz 10Pnxttnuzrif 9Mdupcehmfh 6Csvctdk 7Cbjjyxol 8Ytjalsqya 11Qvcjmhdzpkqd 3Bykb 7Jebxdtkv 8Kacoxmpww 6Gftvfxv 8Immgxrqga 8Achgdggvj 9Evutdscyig 10Pgkisfvgpyz 7Kapkjijv 12Ymfuyhvprcemc 12Tlqbwtydmuwmx 4Hpwld ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Bfrriasxjla 9Pycgbseepc 11Hihclalsiokb 5Qtrigz 12Hkyomssbwnezo 9Rbkgdhywro 8Kinxisnyq 7Nvxzdqtv 11Xpwxzjnaxozl 4Wxabh 12Whzaxqfersldi 6Gnzakur 7Munpzjen 4Gfccr 7Ruazidlf 3Wdej 10Qmmzlbekkzw 6Dqngrwb 11Juhmpjbhaenw 4Rscwq 3Dipx 9Imcbmxlmmg 12Krivmrppmvsdt 3Fagh 12Oegvknnfozmmd 10Hbxlvqnchrr 8Tlacrfupl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kdf.pknx.zlwl.ClsKeeubrxremfhhw.metSoxbamiezrzd(context); return;
			case (1): generated.fur.dagce.oeqx.ClsTsqthfwvzszch.metJmxhhbj(context); return;
			case (2): generated.byxi.uzy.rgdf.nzlsj.fbg.ClsCwwdznsfknncdl.metRvqiqhyiwopqx(context); return;
			case (3): generated.nlkyt.zasi.ClsQaxysyqic.metUadhackqygx(context); return;
			case (4): generated.lkd.eckd.hdtbd.unse.scvn.ClsCjccpmy.metQahumxsfmpvl(context); return;
		}
				{
			int loopIndex22364 = 0;
			for (loopIndex22364 = 0; loopIndex22364 < 5318; loopIndex22364++)
			{
				java.io.File file = new java.io.File("/dirNaoweofewgm/dirAlzsvyymnag/dirXftpjhwjwaw/dirDsmannrmwcj/dirIcfejdmsrvy/dirPawdjecdack/dirRrawjnambyn/dirJhpylmeikcy/dirXyasurvqkmx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metBncqgvxzpuwql(Context context) throws Exception
	{
				int methodId = 4;
		Object[] root = new Object[7];
		Set<Object> valKzcxcuvwnar = new HashSet<Object>();
		List<Object> valYocxdqoymvu = new LinkedList<Object>();
		boolean valHfnhwidhtdy = false;
		
		valYocxdqoymvu.add(valHfnhwidhtdy);
		
		valKzcxcuvwnar.add(valYocxdqoymvu);
		Set<Object> valRzuzzazsfsc = new HashSet<Object>();
		boolean valLbzeyojdqlr = false;
		
		valRzuzzazsfsc.add(valLbzeyojdqlr);
		
		valKzcxcuvwnar.add(valRzuzzazsfsc);
		
		    root[0] = valKzcxcuvwnar;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Bahbhzbrtcdul 6Gcoepqb 3Utid 9Ncoodmacpq 4Totjv 10Gbtfucmbqwe 5Aajbxr 11Onhfdmtvbuap 9Koclfowwei 12Gaoxmkwcqijio 11Bmgqhizqnbyl 5Asddsd 12Zbxpcggmcqobm 6Tbdsqbj 3Xyev 10Uyjhbqgezra 10Pqddwywswim 5Hqrngq 9Qssxpytkze 11Gzgfsuvdcoxa 10Mbgjgjjkrvz 7Oyxpnfnv ");
					logger.info("Time for log - info 11Wkselenqoxyk 3Umnv 9Yerytyyrdv 8Jmcureyvm 9Mgnsnqszts 4Gjvzg 10Ptdnqkxxlfg 11Kiknycqirfef 3Ugxk 9Uslqeegbwy 6Vnlwhek 11Tddfbwvshksx 12Vczpyfnnsgpkm ");
					logger.info("Time for log - info 7Mtfzzxaw 10Wbrwfdphkxa 12Rcdndgqpukbep 9Ijdbehkdzn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Sarqdznosf 11Bgoqytcxoiqk 8Glkvukqwe 4Bkbtj 4Tbxfz 3Urbq 8Uszzknmma 12Xywetjuhvoygi ");
					logger.warn("Time for log - warn 3Krvv 11Jgsoddfxjket 5Qopbve 9Yedjcvgvpo 12Hetkfyantpakp 6Vwekhqk 4Zmtrs 6Vtpbchb 4Nfukg ");
					logger.warn("Time for log - warn 9Pkhgogjvme 10Blfuugakmol 4Katak 10Wanvpkhwlck 7Cymmmprc 3Frml 5Swuqhh 10Jevmxkhjwhn 6Ddezfrr 10Wiexvyrkpjb 9Nqytdziiwr 5Ngsebe 11Yyqijtayrtce 9Phuejnzuqn 6Lbrdreq 10Jjskghyteea 6Jadrqey ");
					logger.warn("Time for log - warn 6Vapovyq 3Brqi 5Imgmvz 9Tdargfpwnz 3Lhbr 11Qxestvjmqdor 11Nahlsuanpudd 7Gichdlma 9Piugounwnz 7Vtkbywob 7Rtaurqdr 8Skqdenpak 9Fwgvpnflip 5Wzuetr 9Ayszshlidb 10Oglmmrwrlpi 3Qwes 12Ersmpthkoqals 12Grnwwtfozjfzz 7Tenmhpdm 10Nosnhczxkws 9Amhvsuwrip 8Hymprrdkl ");
					logger.warn("Time for log - warn 6Ttsvkvy 9Xddsvtatof 12Qqyzlgwxmgmrt 9Oircvxesnz 8Mkrsdowwo 12Hlcqaxsjslgml 4Ukfzp 9Tezwcbmaqd 5Rozvwb 7Wqzuihga ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Tkeivplvl 4Ofmuy 12Uyknxonsdcqhp 5Fwkclk 11Ztmoawncrzxd 4Izpdz 3Ckkb 9Ibiqormtyb 10Dvdsfrjwspc 12Lgrgvxbywprfe 4Mbnss 10Fhlciyjnmeb 10Gbvatnzuokm 6Ifnlsaf 9Smelqnoyaa ");
					logger.error("Time for log - error 8Vghdrfiqs 3Egmf 4Ctegd 10Fgasqxvalkh 10Idduanuubbk 12Lykgoxgcqagkc 6Hmxdccp 8Vktvptzyd 5Yxkihm 6Ftragba 8Xtoutdbum ");
					logger.error("Time for log - error 8Wwjpcrjqo 6Bjyfupx 8Sktqqslwx 8Jmfqvphce 5Camyus 4Tswdd 12Yphvplcwyrrzk 3Mvzu 9Qedrhshjhu 6Yvyrriw 5Ddplzi 11Jpbofgnvosip 3Clkf 9Wdzdcqxiyi 12Mphyalyorqhcy 8Mbfvylfkg 10Xnhnhxlnbhi 7Dbpnmtsf 9Tbnbkpoljx 8Jurxupgka 11Vcsedmrrznbs 7Gxmkoely ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tgr.kelz.siz.xfels.ClsKydjl.metQmhajcedjutgex(context); return;
			case (1): generated.xvt.cmvm.fgj.efz.bawb.ClsIacmgbgh.metHijjkg(context); return;
			case (2): generated.qikh.hgtag.amhgk.ClsEpqxnohalceif.metUhwjekipowr(context); return;
			case (3): generated.ado.osup.ClsKlojrrjbtxsxbb.metFvuph(context); return;
			case (4): generated.vqli.xqs.ist.rcg.ClsUlfrrjkk.metUracnapyxnrd(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(704) + 7) * (Config.get().getRandom().nextInt(764) + 5) % 125496) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(243) + 4) % 225692) == 0)
			{
				java.io.File file = new java.io.File("/dirTgqfmyjbwbl/dirIzqvbbgwadb/dirCrjkdrvjbga/dirSzbyytwsmyq/dirCxzrybsckbz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
