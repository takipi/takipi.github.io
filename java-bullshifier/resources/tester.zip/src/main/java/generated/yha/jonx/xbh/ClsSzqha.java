package generated.yha.jonx.xbh;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsSzqha
{
	 public static final int classId = 37;
	 static final Logger logger = LoggerFactory.getLogger(ClsSzqha.class);

	public static void metMeeynqthzudrnv(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valKnxmjdzhmnr = new Object[3];
		Map<Object, Object> valYicmdkrbifx = new HashMap();
		long mapValGkiosjqbnnn = 873912776586306415L;
		
		String mapKeyReuubsltaxh = "StrElhvolvsqib";
		
		valYicmdkrbifx.put("mapValGkiosjqbnnn","mapKeyReuubsltaxh" );
		long mapValBsbmqbogylc = -2911461834543486918L;
		
		int mapKeyUzilwhiugrd = 735;
		
		valYicmdkrbifx.put("mapValBsbmqbogylc","mapKeyUzilwhiugrd" );
		
		    valKnxmjdzhmnr[0] = valYicmdkrbifx;
		for (int i = 1; i < 3; i++)
		{
		    valKnxmjdzhmnr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valKnxmjdzhmnr);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Mswpohrzmthd 7Ccaaweie 8Mqbueafso 4Zhrto 7Odgwhrve 6Cnuipvi 10Fmbmfhtomia 7Hbthpgor 4Yrees 12Zabukzrfxazvd 6Xmjdmsz 10Ynspxzipyon 8Kwsvdllog ");
					logger.info("Time for log - info 10Hrqrihiebds 11Fjczjttevoku 9Ainoegzofm 4Arlih 4Ngfgg 8Zgbwzgcbw 6Oboggys 10Hbuvcokwjol 9Pfwmpokjsx 10Fxgnbshvvzg 12Cwekqjiruwayg 11Ossawnckyqgz 4Yxndw 3Qpdp 10Dyzlqiwkdtd 4Uqzfl 5Mydncr 9Znettithed 8Sakhswbzo 3Mohf 10Bxrbxatcggs 3Qbja 10Bgemdodgvkz 7Nmctxmwu 12Ocodvvwdfxjgw 12Dnbrjimvrylgf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Gimw 3Glnv 4Zokwc 11Sbfnjcjoyofp 11Guvrwowpzusz 10Ydqajhsdcfl 11Hnythqussmnj 11Oxplticxabts 8Djpegmnov ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Ccvyxpcbaf 9Wrqwcfgiqq 5Mzhgif 3Mnzk 7Morjgzgk 11Ibpageluzdgn 9Nelnjqapcq 9Xmhisvkhfk 7Zmoharcz 5Swhtfk 4Abmzv 8Foqwzfpbl 8Fprnoogzd 11Uoctiurysudk 4Aoqia 11Xqubvuyeimia 4Jykhp 11Uvptraxujzsy 10Ilrofzermne ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cqy.ffep.ClsWvinhicphnl.metWwbnpyd(context); return;
			case (1): generated.tjmm.euxn.jmtp.ClsNhugjkj.metQafbogfqlngiyk(context); return;
			case (2): generated.lgws.kxkr.zse.myye.ClsAnryfbudqi.metYtmxrfk(context); return;
			case (3): generated.mtq.flhse.ygibh.yfs.ClsSzzuamch.metIuxgxgafdnqnhh(context); return;
			case (4): generated.flwv.kjeus.ClsAhjobcsyb.metMaqmdna(context); return;
		}
				{
			if (((1776) * (Config.get().getRandom().nextInt(492) + 2) % 881245) == 0)
			{
				try
				{
					Integer.parseInt("numCpdbmhxxupe");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numPxapzlpbukr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex2657)
			{
			}
			
		}
	}


	public static void metBuzmdjhmnmg(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Object[] valInqpgahjtfy = new Object[3];
		Map<Object, Object> valQmzinpmwefd = new HashMap();
		String mapValAkilzknabzs = "StrOxvbsfcdqnb";
		
		long mapKeyJxhlziwouxl = -1425207047801264213L;
		
		valQmzinpmwefd.put("mapValAkilzknabzs","mapKeyJxhlziwouxl" );
		
		    valInqpgahjtfy[0] = valQmzinpmwefd;
		for (int i = 1; i < 3; i++)
		{
		    valInqpgahjtfy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valInqpgahjtfy);
		Object[] valRvfoegqyidk = new Object[7];
		Set<Object> valCwygakmxufg = new HashSet<Object>();
		String valXqlyufojuqa = "StrNtknhvlspgu";
		
		valCwygakmxufg.add(valXqlyufojuqa);
		
		    valRvfoegqyidk[0] = valCwygakmxufg;
		for (int i = 1; i < 7; i++)
		{
		    valRvfoegqyidk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valRvfoegqyidk);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Itfuzdxugjxga 7Anyhpohh 8Zcokwhmej 12Dwtcnkqtgtqyx 4Pqpwb 8Qboezpjck 5Poclkc 9Osuwzwjjmj 8Yxuoiemgq 7Mxhbufem ");
					logger.info("Time for log - info 7Wxuuonic 6Wxgxaoc 4Yqyts 6Lbymfef 5Glpyqa 4Ldywv 6Srsfuvv 8Onxwkmxwm 12Rtxvemhvdawsh 7Viupnyhz 9Xhlgykvsvq 7Dskwtabx 7Denqzfdg 12Lyoxnsahqykci 3Iala 11Ibnwzpchqdki 12Yscnlghmxrvnn 10Iaqsablspbv 6Xnxbxvn 7Etlucnls 12Tokzjokafjywq 3Mqia 4Yxzmm 8Piqfxarcv 5Usxnwu 8Ibcasfumu 10Utazoxhzbdk 4Umkoz 7Fklylasg 4Dknhi 6Wqmwimu ");
					logger.info("Time for log - info 5Vdbxln 8Ezbxzwxht 9Spgtaxafzp 5Bmkiew 3Banh 4Xswwg 3Xskz 9Bjstyvggmb 9Cqgffdonus 7Acxeycgb 11Deoevkencdvx 11Xamizravukly 5Vdvaca 10Numwhwcouvh 4Vfexr 6Pzdvdup 3Fbeo 12Klpjdvcqizclc 4Tfhzj 9Pddhxndfvt ");
					logger.info("Time for log - info 7Gaijaunb 4Yguby 4Uxsmc 3Prvk 3Krql 10Fvupinffxhn 11Qdslbacixnxc 3Dexg 9Bjadgxfylh 5Snslqk 4Gsgbh 9Paxignmypn 4Ggbub 7Vstqtodv 8Wmohdonpk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Qzfpvmzxez 8Muqruyvuf 6Waijylg 3Xwkt 10Jipbwfllwsi 3Rmky 3Epiq 10Zjsvacmzlrw 12Fetikkefgbkve 8Zkjegrvkz 4Xtpci 11Zqcczmnopblm 9Eiembzqqiz 3Fgcs 9Mltextnoir 3Otqt 7Ztjhozqe 6Hjgykss 9Gvdyrlwduq 10Rnshvpxomro ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Koaixhv 12Cpwdhaufgsfrc 5Ftllzi 7Updfezcs 9Kxtezgegft 6Odhlcvj 9Pobixrvlpi 3Eynz 6Thmhwxu ");
					logger.error("Time for log - error 5Vigbjr 8Szfqnandb 6Heuupaa 10Gxfzaznmhww 11Swyhqhobtcni 9Vlyldtowhd 4Cvkdn 11Mgqorysomxib 6Roqhrkq 3Quzr 11Ujgkidnaspeu 4Cvjqi 8Xzpamlssh 10Lruqgsfuqpo 10Lkfclcklimt 7Bcnpfniy 7Togqrsuc 3Oefh 5Ujuics 9Hsyxeksvib 9Kavisopimj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.seews.usvhz.ClsBpkgpi.metSagewrwqtbzsvw(context); return;
			case (1): generated.flwv.kjeus.ClsAhjobcsyb.metPpltlaigoqfyf(context); return;
			case (2): generated.vyk.nsacl.bsfy.saukt.ClsKpfdsyokiohmf.metYmoozuxldwzan(context); return;
			case (3): generated.tkix.xwxmn.tohx.ClsStsup.metKaytjwbtsoqycs(context); return;
			case (4): generated.duzy.rxrsw.ClsQbnde.metTalkpkmyhvbz(context); return;
		}
				{
			long whileIndex2659 = 0;
			
			while (whileIndex2659-- > 0)
			{
				try
				{
					Integer.parseInt("numBtbosmlpmxe");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metCglfhqtimvr(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		List<Object> valSolbgzkoddg = new LinkedList<Object>();
		Map<Object, Object> valQxugwdyrqum = new HashMap();
		long mapValMfhdvzctxou = 6011428338960899723L;
		
		int mapKeyBjkowhtqima = 283;
		
		valQxugwdyrqum.put("mapValMfhdvzctxou","mapKeyBjkowhtqima" );
		String mapValEsjjqijfbdv = "StrXyqcldlnzar";
		
		long mapKeyGboqtrunkgc = 4692808119378276396L;
		
		valQxugwdyrqum.put("mapValEsjjqijfbdv","mapKeyGboqtrunkgc" );
		
		valSolbgzkoddg.add(valQxugwdyrqum);
		
		root.add(valSolbgzkoddg);
		List<Object> valMjjedqyusyw = new LinkedList<Object>();
		Object[] valPipfpsclqcp = new Object[6];
		long valReqgldoafno = 4828938154333381939L;
		
		    valPipfpsclqcp[0] = valReqgldoafno;
		for (int i = 1; i < 6; i++)
		{
		    valPipfpsclqcp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valMjjedqyusyw.add(valPipfpsclqcp);
		
		root.add(valMjjedqyusyw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Eiiybwkcqhvi 10Qlzjrzzquzp 12Lpqxhomcfscel 7Djdvleme 10Oplezpsavir 12Pnoegjzstsndz 8Ttnqdpuek 4Eznnv 6Ytvofrn 12Arbzuumqpfivq 7Hovidamm 5Knmtvi 4Bxprl 11Btpaeprvrhdb 5Frmafw 4Hfxjw 12Amkmtezktdbcj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Jpwaevgldlc 9Xrupnoozvs 7Oabjqkve 9Gxvqufopyr 4Koutt 11Fvodgghvfbvp 7Dksekujb 12Hummwseflcksg 10Nhummbumyqm ");
					logger.warn("Time for log - warn 3Bvrc 12Girheppxmzjvt 3Ukyn 12Ruzlumxljgyyb 5Undnwi 6Bhgmvtb 9Ehgrauwubj 6Easgzwo 3Mldu 11Pctaydbggdus 9Obamnyffbw 9Gbugummpit 9Xmcxyhlnzm 6Ncudcgg 10Nvxqvyyerpm 6Prxwadb 11Tkiasoebinye 12Vsefxkbnoqfln 11Hlsnmxnnariy 3Adhu 11Ugujlkivgieq 8Rswnqopyq 6Xolkqzh 4Ggbzp 9Ezfkobiksj 11Jmyzlodyqygw 8Wafemerej 5Tflxao 12Vylejbvzeljwm 3Bkzg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.munb.ijbed.gztfl.ClsHbtirm.metYfquprhhflyrzu(context); return;
			case (1): generated.dyzfj.ltbnu.ClsCnnhwt.metAwrkzvmc(context); return;
			case (2): generated.qdt.cqf.kkjo.xjulh.ClsLodna.metTabsne(context); return;
			case (3): generated.ldtgt.vdfx.cdz.lkx.ClsLvvwnymti.metSmshnclxqxhvn(context); return;
			case (4): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metWzqrqrjxhdrs(context); return;
		}
				{
			int loopIndex2662 = 0;
			for (loopIndex2662 = 0; loopIndex2662 < 8545; loopIndex2662++)
			{
				java.io.File file = new java.io.File("/dirBebpvmsjjrv/dirRdjcklircwc/dirLrkfgtxajpy/dirQifyeoylypk/dirWwqqvgbzekc/dirTznuwtqgwdi/dirXvberleihnz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metXghecpfgsh(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valQtbttqtylgy = new HashMap();
		Map<Object, Object> mapValBydonphoqxn = new HashMap();
		long mapValSierhvjxcie = 7601869712371786275L;
		
		long mapKeyGwxbijfarho = -8527911092954764549L;
		
		mapValBydonphoqxn.put("mapValSierhvjxcie","mapKeyGwxbijfarho" );
		
		Object[] mapKeyByeigvfersc = new Object[6];
		int valGvwvvzvonvr = 80;
		
		    mapKeyByeigvfersc[0] = valGvwvvzvonvr;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyByeigvfersc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valQtbttqtylgy.put("mapValBydonphoqxn","mapKeyByeigvfersc" );
		List<Object> mapValZgxeajlgfpa = new LinkedList<Object>();
		boolean valSjqqxywkzsj = false;
		
		mapValZgxeajlgfpa.add(valSjqqxywkzsj);
		
		Object[] mapKeyToidlrrjmaf = new Object[6];
		long valYysrygjslic = 1833986269012704783L;
		
		    mapKeyToidlrrjmaf[0] = valYysrygjslic;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyToidlrrjmaf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valQtbttqtylgy.put("mapValZgxeajlgfpa","mapKeyToidlrrjmaf" );
		
		root.add(valQtbttqtylgy);
		Set<Object> valEejsaiyisdf = new HashSet<Object>();
		Object[] valWfelcagqzes = new Object[9];
		long valPtcphkszjhr = 6439042175401525863L;
		
		    valWfelcagqzes[0] = valPtcphkszjhr;
		for (int i = 1; i < 9; i++)
		{
		    valWfelcagqzes[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valEejsaiyisdf.add(valWfelcagqzes);
		
		root.add(valEejsaiyisdf);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Brdqnyllhqpmv 5Vodxei 8Zmmqpmssi 3Dywx 11Retyxuqhumhl 7Ytignynj 3Dqxm 10Pjhbfuilsex 8Lfcahnpiu 4Ynzxz 8Yypmngvcp 12Cvttsqrgznhfj 5Uqjeqe 12Poacgsvqetiqp 6Xxpijhi 10Jxlqdxnuffu 4Ljwrw 4Hzlum 4Nxfto 6Nizydle 7Nkjmcplr 11Eptttrltrxsc ");
					logger.info("Time for log - info 6Losznlu 12Lxmdwmhjrfawf 12Wnceovbahxgwr 12Nkjsiprfgpfvq 8Vrptmnntf 7Rxhtthcl 7Dwyrzdrm 9Alppiekvky 7Keyndvfo 8Cefchzviv 3Kskd 8Fnvpujwos 6Futxder 3Xwrw 7Mkbxujlx 9Cvbhmawcfh 11Ehzbepdthaqv ");
					logger.info("Time for log - info 5Rzjvvp 6Cfdrbts 3Gkgw 4Nstnl 4Lfiiq 8Ivdabuugi 4Vlzyt 11Kglazxsvxycp 4Dykzm 9Xlduahmloe 3Znfk 7Slndxueo 5Msveim 3Ndrp 12Byibovtpywrnr 7Ogrprnpz 5Cdblwq 7Lhzpusda 8Akouiqagh 10Nfayaqwhqsh 6Bmnwoaj 8Vaikxitlh 5Eiqkld 9Hjazjziisk 12Napuegvpvswwa 3Xbht 4Sadyw ");
					logger.info("Time for log - info 4Sizpo 6Uavqfbj 7Cecdvysi 12Qrurtehghjkcr 4Pjslz 9Ghgmznhvlu 8Yynswrhau 10Kutmlxetaem ");
					logger.info("Time for log - info 10Urpjmiqkfig 12Yzkdurdzhqipd 11Tmwrgwjxlcib 10Juqtvkpybwq 10Ozyxeeuppgf 11Rsxzzzyuxtgu 8Mqwwhrgij 4Vicuo 3Waao ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Hlictxcaat 6Igrsiiu 3Xbgx 6Ndefykm 11Jquiffpsmmmp 8Adobgvnhb 5Scqeoa 11Ruinibfeyuku 7Rcbljmdq 7Baztgpti 11Rbzdithfyemo 3Dbbn 3Ldik 5Yniwbz 3Rqii 9Qapyqgliit 3Tjsw 5Btgxqs 10Ktbeuibirpt 10Bqfxlcondxk 4Gznne 6Pcjxisk 7Astonrcb 5Owonzz 8Fvlhbudoe 12Ucuxehbanelin 5Fwjxee 4Pbjkv 10Acncosygavc 7Leamiwst ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Bijzjjup 3Wwrl 3Xdzp 12Olxbfvjddrjhi 10Uczyzxnqhug 7Jolkvcea 11Weghjlpognxb 8Ocxptfuch 10Lulengclatr 6Scbgxeo 3Jisw 7Ojvfciur 10Smvryoicqgg 8Zudzphgbv 3Jyxx 9Igamghhubi 11Lfeonrtqssov 12Lkbukxjbhzxao 3Dgmm 11Gdnizaaxjqqh 9Jngkrzanht 9Yhjhmojqan 5Nrizlp 10Wkmjkdshvwy 12Uhovlkbpulpcr 9Busnzmlzkr 6Okctcvb 12Xltppybvcmcrf 12Tvjgkelzrhxlc 8Uyjskfuim 11Bufghvbzfqxc ");
					logger.error("Time for log - error 6Wqymppz 8Pcflctjwl 9Rynktmzulv 9Jlqxlmtnjo 7Tnxzcwqh 9Zyobuktuqp 4Dhhil 11Qihppagysyed 9Upvyuronzm 3Wfia 6Qmxmdbq 11Oopiykpyiehn 11Ryhslndnoosq 9Pckccmrbzw 6Pqonjnr ");
					logger.error("Time for log - error 3Yjdx 7Xvgtjwns 7Kdtutgwb 3Ztnt 12Fyjdfommrdkdm 8Zvxmopyag 9Ypkzqrgkpb 12Efxgfqfjxybth 7Meemkmix 5Dgbdnz 8Hclehtynh 3Igir 6Qvjsaai 8Fsodbhrum ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gmk.vzs.crbap.ClsEkyhsmjeh.metRgiazeewshcl(context); return;
			case (1): generated.zfv.ypwo.wuncq.ClsFveqnpanl.metApyyqiuohqp(context); return;
			case (2): generated.cbscy.vax.ifmv.uvjll.ClsXprhoql.metUsqqbascqyi(context); return;
			case (3): generated.wyah.shgd.ClsOoifqzin.metNjigbxfkhw(context); return;
			case (4): generated.cxtx.gvv.woynp.wvzz.den.ClsHntsemdxcztjdw.metBnoufysdri(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(745) + 1) % 722336) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((8776) % 442012) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varMluvlyjduxi = (5569);
			int loopIndex2667 = 0;
			for (loopIndex2667 = 0; loopIndex2667 < 804; loopIndex2667++)
			{
				java.io.File file = new java.io.File("/dirWjvnablzfzj/dirVwsqvwahwwd/dirPgfuktaptii/dirCcnkustffqd/dirWlobjuaeeaq/dirEepzpobpyzn/dirFsuvlmdwlpg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metQpzoirlypnzw(Context context) throws Exception
	{
				int methodId = 4;
		Object[] root = new Object[8];
		Set<Object> valUjaeatbedxj = new HashSet<Object>();
		Set<Object> valVwkchhtlrag = new HashSet<Object>();
		long valSpfwgdhhzek = -6038702483357275247L;
		
		valVwkchhtlrag.add(valSpfwgdhhzek);
		long valSmnshsmzxjh = 3061139048475418558L;
		
		valVwkchhtlrag.add(valSmnshsmzxjh);
		
		valUjaeatbedxj.add(valVwkchhtlrag);
		
		    root[0] = valUjaeatbedxj;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Hhetgswbuip 7Sokkaabd 11Kizxcqilphfo 9Tglmbgmycn 4Imyxu 11Qxdpcgddypmg 10Ffewqnffcyn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Bcgcmjnh 11Nnzkddxussvr 4Msuvw 11Smusxajtvadf 5Ujaeah 7Ngnhxatl 7Xptibllh 6Pvckcwx 11Cvfihtrnnxns 12Bqfwseehyabww 10Ogewpekrysx 11Pyjpfhonfaso 6Tfhbslc 12Qvluvxwgltlzs 8Zeczcmyqg 12Gbjhjxodoktoa 10Hjybpzpeghx 8Vmuiifvbw 4Verlz 5Putvca 7Hgqmmsmr ");
					logger.warn("Time for log - warn 5Rnjjnx 7Taodfxvh 4Wlnfy 7Hcpsqyuh 9Exxggkxslb 11Uegstbvlmphp 12Ihtkvhgdjggap 6Ahgizda 4Qwzgf ");
					logger.warn("Time for log - warn 7Ehileqip 10Zxedfifnyup 4Pyehu 10Fihnfwxhade 3Daof 6Dnvdeef 8Mwmsxxmsf 10Ttsdclownkj 11Sqmmueazohqs 11Blhhccncfqxk 5Hzxtyl 12Vqpfitmthgdko 5Nrrxjb 7Iyoqgagq 3Zlsa 12Hejafkxjyiigo 6Xtcjjun 4Gtmsz 5Blqbrp 5Tsinoo 8Edfjzfmss 4Grfmx 11Sauvyblgqwrw ");
					logger.warn("Time for log - warn 9Ovgjxcweyr 11Qnwzzuynhgzh 7Yvcuajhi 11Fslxbhsatgyz 8Ojcrhdayj 10Gqzsntmgqoq 10Ptrfbdziyso 11Hgoaxjowwktq 5Mokzfq 12Bqubwnsxrmvwh 5Qdjkuq 6Gljnszh 8Jzahpwhnt 11Rydqsdplqavf 4Yktsq 6Zzdoelt 7Pzfqmzts 6Lcbzwqf 9Xlankiijvs 4Ylnvs 11Dbrfboipmpix 9Pnkpfkwmok 6Hqvlayu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nlkyt.zasi.ClsQaxysyqic.metUadhackqygx(context); return;
			case (1): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metWpheeqsxvjk(context); return;
			case (2): generated.guq.may.fgxvf.ClsClatvr.metQznli(context); return;
			case (3): generated.maoc.ohm.nwzbx.efqn.ClsOzonhytosc.metIeedbzcj(context); return;
			case (4): generated.kdu.bhxiw.zym.ClsZlzcdqn.metVaigemiki(context); return;
		}
				{
			long whileIndex2673 = 0;
			
			while (whileIndex2673-- > 0)
			{
				try
				{
					Integer.parseInt("numVcaawklwoie");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex2674 = 0;
			for (loopIndex2674 = 0; loopIndex2674 < 7287; loopIndex2674++)
			{
				try
				{
					Integer.parseInt("numGkrdzrjcsbn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
