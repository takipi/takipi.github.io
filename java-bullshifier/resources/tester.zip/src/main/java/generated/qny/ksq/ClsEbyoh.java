package generated.qny.ksq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsEbyoh
{
	 public static final int classId = 369;
	 static final Logger logger = LoggerFactory.getLogger(ClsEbyoh.class);

	public static void metHkmkfawxahv(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valOuczctdbxnb = new LinkedList<Object>();
		List<Object> valQclefuvfzuj = new LinkedList<Object>();
		boolean valQapznjmtatq = false;
		
		valQclefuvfzuj.add(valQapznjmtatq);
		int valTdstelnsrzt = 276;
		
		valQclefuvfzuj.add(valTdstelnsrzt);
		
		valOuczctdbxnb.add(valQclefuvfzuj);
		
		root.add(valOuczctdbxnb);
		Map<Object, Object> valLmwzpfvkqwe = new HashMap();
		Map<Object, Object> mapValZmsydqsxoje = new HashMap();
		long mapValUmuktisrcjq = 4231966458440286471L;
		
		int mapKeyKhcoggnilgi = 166;
		
		mapValZmsydqsxoje.put("mapValUmuktisrcjq","mapKeyKhcoggnilgi" );
		
		Map<Object, Object> mapKeyOgnbjnffpzb = new HashMap();
		boolean mapValGrszxzkwwyf = false;
		
		long mapKeyRfbdhogmssk = -1463290730193538419L;
		
		mapKeyOgnbjnffpzb.put("mapValGrszxzkwwyf","mapKeyRfbdhogmssk" );
		
		valLmwzpfvkqwe.put("mapValZmsydqsxoje","mapKeyOgnbjnffpzb" );
		Set<Object> mapValKdzzyrynrno = new HashSet<Object>();
		long valSstluzhzyvu = 5489229402178419984L;
		
		mapValKdzzyrynrno.add(valSstluzhzyvu);
		
		List<Object> mapKeyJfmurvibigy = new LinkedList<Object>();
		int valHfxgxeenuoi = 778;
		
		mapKeyJfmurvibigy.add(valHfxgxeenuoi);
		
		valLmwzpfvkqwe.put("mapValKdzzyrynrno","mapKeyJfmurvibigy" );
		
		root.add(valLmwzpfvkqwe);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Tlotnlk 11Phklbpxcibhr 12Iawdntxwbwbqz 9Nbgcotmszg 4Imqdw 5Zatqob 7Ddcfwelx 6Vczsbyl 6Viphndi 12Uqrpkffqrqxnd 12Qiixqrrjlmqvc ");
					logger.info("Time for log - info 10Cslyyzhgurz 6Kfjemyc 6Rkdmixw 8Mrakgdowa 4Qndal 4Atamo 12Ypdarotwsguna 12Gmmenrtsxsuow 3Umeo 6Ebzqnqa 7Ifgxsinp 12Htgnkcrkvpcuq 3Ncba ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Bwxi 4Fsset 7Grykyvpi 3Iufn 6Kuzhlru 6Txqnlri 5Xmmwsu 10Fmdctjlraib 10Hkvrwistxyi 12Jczxxqwrbkzdm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Fkjkggrav 5Gdwtok 5Rcqklm 7Npwojdzp 3Ykdx 3Axiu 9Qqwreomqtk 12Vfzxhtytsnlue ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.eedk.kvsj.tzabg.tqpy.ClsBuuqqzvjfxdiao.metOjmuclkrr(context); return;
			case (1): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
			case (2): generated.bolg.tnlb.nmug.ClsHstaiufsowx.metPapexcx(context); return;
			case (3): generated.rub.wtuur.cpewn.fdq.jektc.ClsLiscwkily.metAyhva(context); return;
			case (4): generated.ooziu.gzrop.rbg.ClsFthgefv.metAjgfkw(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirUjbdczrotjs/dirGhqwzmoqtjo/dirFqzxsljintv/dirBawdtufovzc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex26204)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex26202 = 0;
			
			while (whileIndex26202-- > 0)
			{
				try
				{
					Integer.parseInt("numKvayzzoyjyr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metGwxnyvgevqb(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValEqfcklzimwv = new HashSet<Object>();
		Set<Object> valSrnjcaiklvh = new HashSet<Object>();
		String valTrsdnrhsmsp = "StrVduoywtuuwz";
		
		valSrnjcaiklvh.add(valTrsdnrhsmsp);
		long valRfgscgjzldu = 4871447845352474112L;
		
		valSrnjcaiklvh.add(valRfgscgjzldu);
		
		mapValEqfcklzimwv.add(valSrnjcaiklvh);
		Map<Object, Object> valVudfcmsrvwc = new HashMap();
		boolean mapValRvtaunjjzgc = false;
		
		String mapKeyUjsswfqwpao = "StrHchzyuzunrl";
		
		valVudfcmsrvwc.put("mapValRvtaunjjzgc","mapKeyUjsswfqwpao" );
		int mapValPginskaacyr = 485;
		
		int mapKeyWubswpbruel = 86;
		
		valVudfcmsrvwc.put("mapValPginskaacyr","mapKeyWubswpbruel" );
		
		mapValEqfcklzimwv.add(valVudfcmsrvwc);
		
		List<Object> mapKeyEjvoxtlitgm = new LinkedList<Object>();
		Map<Object, Object> valOjbrqbnepwi = new HashMap();
		long mapValCypmaolzrpu = -8823369013340877407L;
		
		int mapKeyDuetmymveqm = 118;
		
		valOjbrqbnepwi.put("mapValCypmaolzrpu","mapKeyDuetmymveqm" );
		long mapValAperbowfdxo = 8604802336068036442L;
		
		long mapKeySpyguiykznr = -6006452227432891337L;
		
		valOjbrqbnepwi.put("mapValAperbowfdxo","mapKeySpyguiykznr" );
		
		mapKeyEjvoxtlitgm.add(valOjbrqbnepwi);
		
		root.put("mapValEqfcklzimwv","mapKeyEjvoxtlitgm" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Ngkyzahwnmde 6Atbbfux ");
					logger.info("Time for log - info 4Ulyyp 8Wsqqjiedi 8Sdvbgwbzb 4Nleuc 4Qumcs ");
					logger.info("Time for log - info 3Nupa 11Swjxcvfmgvua 7Zuujftzu 7Zdmavscg 8Mmsksqqxe 5Ymgbyb 3Jjvm 8Uohgjloqn 6Trlqlgz 5Kwdllr 7Gamilwib 7Lldmbmoo 8Mqpdriece 5Sllddq 11Phjzqawrnjyd 4Danfe 8Wqykydblo 5Tqbkio 6Peyyppk ");
					logger.info("Time for log - info 3Txvk 7Cqvpyndx 4Ujvyu 12Waoenmimzbaoy 11Faettgxcnhfd 4Vbruj 9Zwcbtvlasz 11Taaembrabibf 5Motqry 8Eoreduhhm 6Fwcgbep 6Mazhucd 5Xibalj 12Mderoredpkkcq 4Zxgdm 12Hzqdeynwlcdqo 9Kfpuxwbcew 6Vshtlsq 4Tijmi 11Bwufrzizsmye 3Mynn 9Fdgmfcgtlf 4Mhjni 3Gbmz 8Eskvhbqjl 4Ikooo 3Poqh 9Luucmwlpcz 3Xxjs ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Qvfgqz 5Ersauf 12Uwmqljgqdnyoe 8Adsaitloh 12Oqpmknmxvwemm 5Svhsvl ");
					logger.warn("Time for log - warn 7Uszahzqh 6Qhrjfxb 9Fquogclwzr 11Cxmkrihnhftr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Tumnvbaowgi 5Pqeohw 3Pblx 7Jsiexxiy 6Stadhwk 3Xnyj 6Tfqcksg 10Zixjjxmrqkg 4Xihtb 8Sgkqeqibp 9Wvhwnucpig 6Cgziykr 5Buzkvh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zeo.tykl.bkniu.uhs.uwxh.ClsUegpnzqhmar.metVjrdqy(context); return;
			case (1): generated.npa.tuyd.ClsLxzuwxfsi.metVaqynjo(context); return;
			case (2): generated.awuu.yuf.ClsCvioceqcbkiz.metCmrtwohtptwpox(context); return;
			case (3): generated.enb.ktdil.ClsEqcfzlhpy.metEbqhhysso(context); return;
			case (4): generated.bolg.tnlb.nmug.ClsHstaiufsowx.metPapexcx(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numNkoctjdafpo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numCnzrfcivspg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex26210 = 0;
			for (loopIndex26210 = 0; loopIndex26210 < 1206; loopIndex26210++)
			{
				try
				{
					Integer.parseInt("numClzwlanswof");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex26211 = 0;
			for (loopIndex26211 = 0; loopIndex26211 < 1805; loopIndex26211++)
			{
				java.io.File file = new java.io.File("/dirRjcswfptljd/dirApidxekzedh/dirSjikcaelrxc/dirKxrelyakrrs/dirWqvshtxzyev/dirVlcbfzkslud/dirErruaacvqkw");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
