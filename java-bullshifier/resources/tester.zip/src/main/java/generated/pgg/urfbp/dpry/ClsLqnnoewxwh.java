package generated.pgg.urfbp.dpry;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsLqnnoewxwh
{
	 public static final int classId = 337;
	 static final Logger logger = LoggerFactory.getLogger(ClsLqnnoewxwh.class);

	public static void metZjhjrjbeazu(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valYkcsuiofiyt = new HashMap();
		Set<Object> mapValKpczigammus = new HashSet<Object>();
		boolean valBzodsjngbne = true;
		
		mapValKpczigammus.add(valBzodsjngbne);
		boolean valEvdjssvhpot = true;
		
		mapValKpczigammus.add(valEvdjssvhpot);
		
		List<Object> mapKeyBccglfbnobn = new LinkedList<Object>();
		boolean valPckbummusqu = false;
		
		mapKeyBccglfbnobn.add(valPckbummusqu);
		int valYxlynsogjmh = 201;
		
		mapKeyBccglfbnobn.add(valYxlynsogjmh);
		
		valYkcsuiofiyt.put("mapValKpczigammus","mapKeyBccglfbnobn" );
		
		root.add(valYkcsuiofiyt);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Fyrrqsuoxzafe 8Ewkfztwcr 11Cwkgzcscoiyb 6Ddfinls 3Skon 8Cjaydcbhk 8Wxtovfrgz ");
					logger.info("Time for log - info 11Knuxhevjwdkh 9Zoxiasoubb 10Jidnzoynosf 7Ejzqwizh 8Tatdfhbow 7Qbnizpif 10Hnjpmcfzjbd 8Wffbhbfpz 10Vsedfbtfeqb 3Oxwv 3Fwky 3Gnxa 10Ycwrkltkesk 11Jqzptapktsup 4Kbzaw 12Htqwmdnonzwjk 5Knynbn 9Aqtvbwciit 9Merewqsjpl 12Zhcfcmsvpcakf 6Zxaevof 12Izveznafvsvev 7Jiqicbvg 9Vqpdzmejvc 9Nomxhlcixp 12Rmjivyyfszwax ");
					logger.info("Time for log - info 4Ahuhx 3Yvkq 10Ltsmqhgtwml 11Uiixeqjurobd 3Wzxy 6Hodlnno 10Ovrtcbshyvs 3Lwaf 5Fsdobb 12Ihbxjirukwdqm 10Vnexikuwsdo 5Kjfqys 4Zibak 8Lebchtabf 12Fpshwnsrfalvy 10Pajizaqrhzh 8Vxpoqcrzp 3Risb 9Vtnymkmffb 6Yjwmigk 7Igbpiwcp 8Vfscnghav 5Bhujry 3Hzgh 7Bvqxgqnq ");
					logger.info("Time for log - info 4Auofw 4Egtig 8Xtopdvchh 10Hhsfttrctpj 3Gric 6Utatepz 11Gqgjtnaijlnp 8Qhwbnzkcg 7Hbvzpggu 4Omaqc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Zajufvv 9Vydcfefunz 8Lsoacchcz 12Scrvzmymkwtah 8Sqwniuxhc 10Zlgkfdstfol 3Sttd 3Cgha 5Unabnm 5Iuiiyw 12Ofozhsjoiccez 12Noyfpgfbgrgdw 4Jhocm 10Htgfmuowpsi ");
					logger.warn("Time for log - warn 9Bnyqqlgomk 12Hfmkdtfocipef 11Yslddfmcqwcp 3Fldq 3Mriy 4Tljge 7Eobkqvmz 10Vmjqocpjnzc 7Fjpmirth 8Lwumrrloy 4Vghnv 8Ieoiuechv 12Vglyuzxtwxzya 5Hvntgx 7Ifjuhjvd 5Trgdcj ");
					logger.warn("Time for log - warn 7Ipwxnqoh 9Wjxfaraqjz 6Qixaffl 4Foctc 12Qrbkqodjfgjcf 8Lvgcpipgj 8Nykapqpve 8Xkmolayun 7Eardzznf 9Zkodcjqqlx 4Lcneg 8Kgheavfyo 3Dmrq 3Bwbq 6Hlfuqbq 10Spybirorczd 12Zgzljnmkhkfti 11Knsrnjzjmrhr 3Wrtr 5Kwaoab 8Mmkpedioy 7Qxrmgbea 6Bosnfij 6Ujtmvqf 4Tytmr 8Vofjyozvc ");
					logger.warn("Time for log - warn 11Hisbjzkoibrk 5Lpjeju 7Tuwgkzql 11Icvecazhpedk 11Mweyaivortmv 4Gwasz 7Cqptktyq 4Uyisi 4Xexyv 3Qwox 5Qbjfdk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Urvjdibhfoe 8Lfwfyrnbh 3Tige 3Shgg 8Jeazvklzw 3Xrpl 3Dktr 3Mork 3Bkqs 4Suull 10Xfsjqraqubi 6Hakbyfn 10Vkxtnufkomq 5Ljtiuc 10Zqeyvrtiedu 11Qsvaywvokknt 12Nljivkfttvdmf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nxf.wvris.vmp.ClsGllyounxce.metEovax(context); return;
			case (1): generated.mrz.embg.gydr.vls.fvllv.ClsYrxhq.metPmjofrckzavphr(context); return;
			case (2): generated.qdt.cqf.kkjo.xjulh.ClsLodna.metBwwvtt(context); return;
			case (3): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metZfqpeqqdiyyj(context); return;
			case (4): generated.hkyc.tzi.ClsYwknearnl.metPahqec(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(853) + 9) + (Config.get().getRandom().nextInt(851) + 4) % 493010) == 0)
			{
				try
				{
					Integer.parseInt("numKdylhkxuiqa");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(644) + 8) % 439393) == 0)
			{
				java.io.File file = new java.io.File("/dirJfjjqxpprmv/dirSfakfyhwnpj/dirBoqinkzjmzg/dirLrrcqtqavej/dirRowyvvfcxzy/dirRdzprrzwezu/dirUdnwpilfqen/dirJarzmzznehs");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metEewtjghwbbijby(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValQfkylikvlri = new HashMap();
		Object[] mapValQhtipfdiwxh = new Object[9];
		long valJfdcfwnrcna = 8458130434940308150L;
		
		    mapValQhtipfdiwxh[0] = valJfdcfwnrcna;
		for (int i = 1; i < 9; i++)
		{
		    mapValQhtipfdiwxh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyIvaazixgnpi = new Object[4];
		boolean valQxpgzpviakd = false;
		
		    mapKeyIvaazixgnpi[0] = valQxpgzpviakd;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyIvaazixgnpi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValQfkylikvlri.put("mapValQhtipfdiwxh","mapKeyIvaazixgnpi" );
		
		List<Object> mapKeyZwxvjusgngr = new LinkedList<Object>();
		Map<Object, Object> valAnqhkzuocql = new HashMap();
		long mapValTlvbwraonen = 8075523041590749069L;
		
		int mapKeyBjipooyfiip = 127;
		
		valAnqhkzuocql.put("mapValTlvbwraonen","mapKeyBjipooyfiip" );
		
		mapKeyZwxvjusgngr.add(valAnqhkzuocql);
		Set<Object> valIfetsmzweph = new HashSet<Object>();
		boolean valSzbpxuzscxf = false;
		
		valIfetsmzweph.add(valSzbpxuzscxf);
		int valWmymsohoicf = 183;
		
		valIfetsmzweph.add(valWmymsohoicf);
		
		mapKeyZwxvjusgngr.add(valIfetsmzweph);
		
		root.put("mapValQfkylikvlri","mapKeyZwxvjusgngr" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Engn 9Pzzjrpiyac 12Doejujlpsbskh 3Cgft 12Bofeyunddzgal 8Doprjujkl 12Kktwfqdqupvvu 9Syulznjmnp 6Hqyvvag 11Qungjwniuhte 9Oqzgtzboea 7Tqlqqnxy 4Yazao 10Wcjogetnxyy 12Rtedfsdwahjty 10Rkaksmjplkq 8Gutcqhjno 11Inhcbjqnovrm 5Zzfogx 3Urcu 8Nvrnvezdt 3Tcxp 4Ebspd 7Cnbregih ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Nqsh 11Pnntbvvznwqn 10Fxkseroqnrr 7Hmenxufc 5Ewbcgx 11Kigjarvucatd 3Fjam 11Pgcwsrszxltr 9Hoqoqlygal 10Hqmtvjcvqpm 5Tgjfwm 3Ajqe 7Oletwtxk 5Ltjais 10Jlkckqkvosu 8Kgvhbdzvc 10Chfwrtxdsad 3Pkse 11Qnnwcyklgqpt 5Znvjys 7Jadxhhjf 3Zyqy 3Oebe 5Mefiee 4Qlzfl 8Rueuefcmo ");
					logger.warn("Time for log - warn 9Cqyimrwdyb 12Utfynuwdnlpzs 11Abyedxtwpfyd 5Tjjyfe 8Cdtdvbpgn 12Vhupiazlsmzne 6Vokumes 11Reiaaerhoaci 8Oructplrn 6Qvbhktv 7Exmxptmp 7Oswvqzma 11Jnnftcpxvdwi ");
					logger.warn("Time for log - warn 10Bpkhvjxgkep 10Dtlkabjsfkk 11Irfytnfvtygp 7Oihwdqrw 11Lclindxqdmfv 11Fohcjmpusite 7Vtagdsna 6Oqljhfr 10Derlbccpcko 11Zvbspbxmtxdx 4Vhtku 5Wkjzkt 5Ivfpgw 6Yhavqbj 7Pryzoowo 4Fdjcb 11Buwfhycelxmk 5Opgufl 12Xatqptrnaeily 3Ozdk 12Gfykkpbusnzah ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Bngoskshs 8Pcortcnpx 6Kexbnuw 10Bzrcnvgugtb 7Hlzjfdli 5Zfubes 8Gcmoyjkgh ");
					logger.error("Time for log - error 9Qfakcitzoo 5Surumj 12Dknmtgnqqrndl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gar.mdz.moh.znab.ymyxm.ClsZduvwawzb.metEhneheywvhck(context); return;
			case (1): generated.qdt.cqf.kkjo.xjulh.ClsLodna.metBwwvtt(context); return;
			case (2): generated.wyah.shgd.ClsOoifqzin.metBzqievzkfqt(context); return;
			case (3): generated.lkx.jvoz.ClsUgthzii.metEemhoq(context); return;
			case (4): generated.mao.kidk.mlsjr.hew.xst.ClsEfomkejxcxzr.metEruurpx(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex25663)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirZnjgowdiblz/dirMzgdgysezqx/dirFlqfzivcvsz/dirLnmtwjuwwcs/dirSpxaupziquw/dirGxtdrlognle/dirSzhxowuxjtg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metUlggo(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valInkalqtllwd = new HashMap();
		List<Object> mapValXeczmsixkwp = new LinkedList<Object>();
		boolean valOpysyfpurjx = false;
		
		mapValXeczmsixkwp.add(valOpysyfpurjx);
		
		Set<Object> mapKeyIdgwdnnoulv = new HashSet<Object>();
		long valLmmrkhhsxjb = 3314066891089019192L;
		
		mapKeyIdgwdnnoulv.add(valLmmrkhhsxjb);
		String valTxygvpcnyhj = "StrJeacaedkdpj";
		
		mapKeyIdgwdnnoulv.add(valTxygvpcnyhj);
		
		valInkalqtllwd.put("mapValXeczmsixkwp","mapKeyIdgwdnnoulv" );
		
		root.add(valInkalqtllwd);
		List<Object> valYqjuauceong = new LinkedList<Object>();
		Object[] valVhwxxhhjdpm = new Object[6];
		long valWhlmpmjoobw = 2533935595223520255L;
		
		    valVhwxxhhjdpm[0] = valWhlmpmjoobw;
		for (int i = 1; i < 6; i++)
		{
		    valVhwxxhhjdpm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYqjuauceong.add(valVhwxxhhjdpm);
		
		root.add(valYqjuauceong);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Ssyfnjwynfwbp 6Ovoumkm 11Ujjpjocsivsk 10Tdarmdvlnij 7Hotaoemu 12Kycbvapyreaxp 8Youcscckk 4Qurny 6Ytalawu 10Njghcdikuoc 7Cuxxszai 12Xpnyozcqtnpfo 5Vtxyye 12Lygoijlkwlook 7Tmfexkbr 4Zscbc 11Dixcvhqkblfn 12Ncktplhbredrl 8Qtdlvxbjf 4Chfli 7Ffvjlxuk 8Ofjyjvvsc 12Cgbrxkxescdbp 7Hefqvuup 12Kohczowulouko 4Quxlo 3Jdza 4Tmtlb 11Kuwysyrgujvb 6Lavyotw ");
					logger.info("Time for log - info 6Mbdavod 10Comtweoldym 4Nhivl 7Wagrvjps 8Bewdkkbud 9Wpisiuqpki 3Ecwz 11Vkrcngmsdpzc 5Vjsxxf 7Uitciujj 12Dbxdtynupfwql 12Egzygheadazlz 3Nrzh 12Wpplebxybutlq 9Reihxfbpqu 6Vhmirfl ");
					logger.info("Time for log - info 3Ubhg 9Myozqggusv ");
					logger.info("Time for log - info 11Iyzoaohhnfam 3Ufsx 10Kzuoeozwmlo 8Vgxcvizdb 9Pptnkqrydw 10Tbwisqdqvcn 11Ihcgwrpqdffd 8Raztrhaib 10Zsfptgxxxkr 9Omsqujmhyn 7Bkjfntrg 11Fqeoydhsqlxm 5Dztpdt 8Lvflqxonf 3Lhqk 12Iwnayavbhfuxa 12Lntamxtenbxne 4Zquee 6Wipdqft 6Fwanxay 12Zxwgrvwwzfgwa 9Bazhcdnwxh 10Byhgqqiytbi 7Yqpflbev 10Fwkntsgyxyg 12Hlsdwzaaloryn 10Ssleaidmvge 9Ydqlyuwhph 11Hptzlghggfvl 10Ydovwqeetwi ");
					logger.info("Time for log - info 8Oditooljo 10Fodzcgzkkuk 3Arry 12Fhbxjkkeilztc 6Ajipxvu 5Rxbkmi 8Imvivxgah 5Rgxzyg 10Elssfqmbbhg 7Fpbcaudm 3Jvaj 12Dhqhrjfssuuqb 10Ahaamabwgkp 3Pfjd 6Nryxakq 8Fgzoyzgwn 3Madv 7Khjpdhkn 11Fwqndznglarq 4Oqgfu 9Zzkazyuxfr 4Wilvn 6Bupxewq 8Pbyyiwuuo 6Vdpgaxr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Nwpiqsuzqa 7Ufnmkgml 8Mchlygbou 9Rfopcinbdy 5Kzrgeq 5Sitokl 9Ndbqruqqfk 6Wzxvffm 8Nuouaxgno 8Mbexfpplv 10Futcjofacqv 5Vuncwc 11Sxhwiwixphpy 9Redhgzvlqr 4Tpobs 6Hegyuqd 12Zbjryljuoqxxo 6Tkwqqlr 10Huvojvhpmjw 3Izoz 8Xifrpagoc 11Zjqrklrpigwd 5Rgfwtt 10Rubozolqouc 10Glrhvygcwuv 6Uhtiqrz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tyg.mzcly.ClsYmwmvdb.metNppiiobv(context); return;
			case (1): generated.dvks.jsbpi.ClsXlatniflz.metIhawpoyjsfgfom(context); return;
			case (2): generated.hzw.xclp.jagge.pvih.oqmlx.ClsBjaeoqqxwxxp.metPmkwxr(context); return;
			case (3): generated.vna.rvrp.nspt.ClsOdrnbbdzkkwwtm.metNfrkflcsgv(context); return;
			case (4): generated.cmlwi.ajlk.yhine.aaz.ClsYxnwkcu.metFaguljivuo(context); return;
		}
				{
			if (((6865) % 193545) == 0)
			{
				java.io.File file = new java.io.File("/dirNhafhaisgcc/dirKqpokpfkufu/dirJuwbgkdtmiw");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(385) + 5) % 870732) == 0)
			{
				try
				{
					Integer.parseInt("numYznzngnwpbx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metHqhcu(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValYvxazeyzxgh = new HashSet<Object>();
		Object[] valTcctdlphpkm = new Object[11];
		String valXqalytrlnzt = "StrLwxuyvedkyn";
		
		    valTcctdlphpkm[0] = valXqalytrlnzt;
		for (int i = 1; i < 11; i++)
		{
		    valTcctdlphpkm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValYvxazeyzxgh.add(valTcctdlphpkm);
		Map<Object, Object> valLermbgjsuyb = new HashMap();
		int mapValVxlvwitmysv = 151;
		
		long mapKeyKerakxwifhm = 3347690224204228824L;
		
		valLermbgjsuyb.put("mapValVxlvwitmysv","mapKeyKerakxwifhm" );
		
		mapValYvxazeyzxgh.add(valLermbgjsuyb);
		
		List<Object> mapKeyJewakvtncam = new LinkedList<Object>();
		Set<Object> valWtqnxompwxo = new HashSet<Object>();
		boolean valUhloconkykz = false;
		
		valWtqnxompwxo.add(valUhloconkykz);
		
		mapKeyJewakvtncam.add(valWtqnxompwxo);
		List<Object> valLnvffkwzqlk = new LinkedList<Object>();
		long valHjgnxwovymz = -2206278909435232167L;
		
		valLnvffkwzqlk.add(valHjgnxwovymz);
		
		mapKeyJewakvtncam.add(valLnvffkwzqlk);
		
		root.put("mapValYvxazeyzxgh","mapKeyJewakvtncam" );
		Map<Object, Object> mapValUymhqxnrmcv = new HashMap();
		Object[] mapValZsjshnjcslm = new Object[8];
		boolean valHgvhbmebuwk = true;
		
		    mapValZsjshnjcslm[0] = valHgvhbmebuwk;
		for (int i = 1; i < 8; i++)
		{
		    mapValZsjshnjcslm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyBuwenvufvcb = new HashSet<Object>();
		String valRebuhaegmun = "StrDbpcidsykil";
		
		mapKeyBuwenvufvcb.add(valRebuhaegmun);
		int valPsamslopefv = 276;
		
		mapKeyBuwenvufvcb.add(valPsamslopefv);
		
		mapValUymhqxnrmcv.put("mapValZsjshnjcslm","mapKeyBuwenvufvcb" );
		
		List<Object> mapKeySpqggctsieg = new LinkedList<Object>();
		List<Object> valIvrtcjqpdbt = new LinkedList<Object>();
		boolean valTauklwggnwe = false;
		
		valIvrtcjqpdbt.add(valTauklwggnwe);
		
		mapKeySpqggctsieg.add(valIvrtcjqpdbt);
		
		root.put("mapValUymhqxnrmcv","mapKeySpqggctsieg" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Buwidgs 6Hjavkyb 3Pzip 6Irxfwzu 3Rlcs 12Lbclodytxmaee 4Msvwn 3Zrtn 7Vfyyahod 11Sodmldxjsxwb 12Vkgaadmvpulkp ");
					logger.warn("Time for log - warn 5Qvisez 5Natwzc 4Inlkp 6Ntidegc 8Ruebczofi 10Jghcwyptzzi 5Oodbzb 10Tnzenasbcuu 5Slaayk 7Ojthrkta 7Xfvhbrwc 4Iriuo 3Vqgh 3Fquv 10Hdtsjyqglfu 6Qfsjsdl 10Aseddtkefvg 12Jhdfhvrnhrbzu 11Vtdtjivdbddc 5Ggecwb 9Ylftnzrvpq 6Fbzpvcu 8Fthoiujfk 4Tloqj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Atzhbffjy 9Ocwimkewnm 10Dpeoycklrts 5Riciqb 9Pwtgdvxibj 10Xnlwvkgrazc 7Aplquokc 6Wqzefcf 6Zzhplpe 7Xfcollty 7Rynuqosu 7Tzvcdgel 11Dchesizcmhzb 11Hqcrvtahvnxe 9Ppjrhefjuc 7Vsofllgu 5Ielnlh 12Vbgngckufyalu 12Emmueqvtftsui 9Xyjqjklrbd 5Oqujkk 11Iapfffdbtjjt 7Hfpaalue 8Uvbsmsglk 9Ebjnkckext 12Xtukurmrlajnf 12Ubuosyjpkfyka 6Uwmlbnl 6Zatrpoj 3Qyeq ");
					logger.error("Time for log - error 3Jirn 9Amaaxqsbkl 8Dpypdmpet 4Dlfyp 10Esvuefiiwyv 6Vcyxsaz 9Cwennfepqc 12Qyqizapnrzhih 6Deqwnbb 10Luebhjpuojk 9Vzdvewcghq 4Ztuyt 3Qwag 7Bcskihio 8Ueddfsgxc 5Wznueh 11Cpanfepybxiz 5Uqawir 9Maikkgfpnh 5Lbjsob 6Jcftdwg 3Jrvf 8Nkagcwbbq 10Dpvwquraquh 12Gtdmaowkyagjn 5Fsbxjc 9Pmoomlntwh 4Opbbp ");
					logger.error("Time for log - error 8Zlnpkmmwq 12Dbbflgpsssrjn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
			case (1): generated.yewpq.dap.itdt.ClsOhnihvc.metVezpyfhkrdq(context); return;
			case (2): generated.zuqq.dis.ClsZotjz.metPhpym(context); return;
			case (3): generated.uhn.nhlo.xwe.qendy.ClsUedsvxy.metDrmqzdoluerxn(context); return;
			case (4): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(765) + 0) % 953345) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((Config.get().getRandom().nextInt(460) + 4) * (5940) % 994265) == 0)
			{
				java.io.File file = new java.io.File("/dirZvizbndbacy/dirYscfvxfavaa/dirObjtqwfcpie/dirUtgysbvkeyw/dirEcyxuhhbdvj/dirSzkzbnujfbl/dirXgzuviekkdm/dirYpbtisnokvy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((6248) % 151726) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
