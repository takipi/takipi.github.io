package generated.unn.flt.iyr.tjmvm;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsFuxljnbiciwosz
{
	 public static final int classId = 360;
	 static final Logger logger = LoggerFactory.getLogger(ClsFuxljnbiciwosz.class);

	public static void metGczbjns(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valAxvjndxgnpv = new HashMap();
		Set<Object> mapValRqrwgzjhdpf = new HashSet<Object>();
		boolean valAgbefrqsdyf = true;
		
		mapValRqrwgzjhdpf.add(valAgbefrqsdyf);
		
		Set<Object> mapKeyKsorddiogri = new HashSet<Object>();
		boolean valTacxgtukcqy = true;
		
		mapKeyKsorddiogri.add(valTacxgtukcqy);
		
		valAxvjndxgnpv.put("mapValRqrwgzjhdpf","mapKeyKsorddiogri" );
		
		root.add(valAxvjndxgnpv);
		List<Object> valTdrvdgkyapv = new LinkedList<Object>();
		Object[] valJdgcyycewie = new Object[9];
		boolean valLwiqwckludd = false;
		
		    valJdgcyycewie[0] = valLwiqwckludd;
		for (int i = 1; i < 9; i++)
		{
		    valJdgcyycewie[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valTdrvdgkyapv.add(valJdgcyycewie);
		List<Object> valTxpmujxnzea = new LinkedList<Object>();
		long valGaosojkjmqy = -9006454074223121170L;
		
		valTxpmujxnzea.add(valGaosojkjmqy);
		
		valTdrvdgkyapv.add(valTxpmujxnzea);
		
		root.add(valTdrvdgkyapv);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Rbas 8Katzxjdvc 6Dwfloeg 7Liqvxzyq 12Suagypaiwbpdt 7Yupxexph 3Hszs 4Ciefb 11Awfxuejspcme 4Talal 5Orfazh 12Aivxatafhgrmb 6Hwtqivq 12Vmfsyqajtphvz 7Xvufquka 4Wbykl 12Yxoktqivxvuuw 7Qukiqdoi 6Rdrtwwr 8Ibfrgahvv 10Gpgbubjojoi 3Ooxf 11Ixvvsldjgovz 6Onjnsol 11Jzkbobsgeuob 8Maqpeyyco 10Cadgiyztjea ");
					logger.info("Time for log - info 4Pvkqm 12Urgwpofcuyidc 3Euuv 7Plxwxooo 5Nvjpbg 9Yadzhyexzo 5Jwadpa 4Miaqn 12Knyyaspmzuepi 8Ykgthhwfj 12Zioecpvyaodvk 6Jjjgogq 5Peakdx 6Ebwnsjj 6Culhebf 11Ktlysndsxuub 12Iavckkjtkwihh 4Tpwpv 12Gazwpbghynwyy 4Hdthf 6Xmmyzqy 8Corwlgaoi 3Obqp 3Dhmc 3Rpzb 5Ejglly 9Trckyelfbv ");
					logger.info("Time for log - info 6Lbwpkwk 4Nzjnc 6Uatqpwu 5Vcwfaz ");
					logger.info("Time for log - info 10Nrpgeketwrb 6Effhzwz 11Tutvzmvimqwm 4Zzghg 9Hdxfkzogjl 7Ypvoddca 12Bmtjhuspumbyj 10Fvgouovloud 3Tjip 5Rrpupv 12Kigaavljfipty 4Ogwoz 9Aizjtoenvf 12Espohmurskyrm 10Kqiidctfacn 9Otxdceybmi 8Yvfbknjjp 3Slci ");
					logger.info("Time for log - info 10Lvcfesstotr 10Hfdljtsvmno 12Fjkquifojatbx 12Sntwuiiprmjpg 6Sbgiqer 5Yzvwko 10Yefyoqzohqs 9Ljhfwdyrza 6Gimnvbu 12Fbaegnmdeivdn 6Idqyjui 4Pcvrr 12Fhkoioqslpvlz 10Hsglybfcuoh 7Hczthahl 9Rnuhfdjgmf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Upjhqlixflmck 9Lzhnzlwyqt 11Wnurizwztxri 8Emdkpoxhe ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Hboqvej 9Dqtdfkqxuk 11Ompyoytcftdl 10Todztyxiqsk 7Woqgicqm 6Gybnain 12Odoulilxolqpb 4Cpaeb 12Duduqhjwtasnm 8Nqtdilqce 10Biaelruclts 5Krfeok 11Luvbeymynwqt 9Ckxhghwiqc 8Rfolmywhe 4Vmoau 8Tukolqxlp 4Ixvei 11Lkjsxxsdzmqx 10Vmctuzdfenj 4Zqixz 9Llepzawdbm 3Bfjj 9Uftlzvemsf 6Nufriam 6Oeqwkai ");
					logger.error("Time for log - error 5Yhatjc 5Tpuapg 5Vawrlu 7Qtedvzie 5Tnpxhr 8Jpbnapgwj 10Nrpdlyvhqsh 7Vwzrhixv 9Nkdegiajle 9Tkjiodsysr 6Xnnalyx 10Bwumsdlklgs 5Wscaap 8Jsjpqrglw 4Xhhpo 3Liub 8Gonupxpzs 11Temowwzbinun 8Yjpgwucnx 4Mhdep 11Shexcpqxcdju 3Vcfo 9Lwqvopejfo 7Wfzgxosh 12Bqsrcrjinolog 10Bwvxebzqgak 4Bpdwa 3Dbzc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wzc.atz.bifi.ClsLhmqhmqzzzccj.metTthfpespngis(context); return;
			case (1): generated.uffsk.vmiw.dvm.uejb.ClsHwejuhoirpcucb.metTioel(context); return;
			case (2): generated.kjubh.rgz.earxz.ypjc.pmupv.ClsUctrmkk.metKedywb(context); return;
			case (3): generated.fhy.qnk.brj.xhy.ClsYgumeudbf.metEcwaz(context); return;
			case (4): generated.aea.iom.ClsOvjtnlwnmq.metKhmaqmoiluaib(context); return;
		}
				{
			if (((2983) % 944807) == 0)
			{
				java.io.File file = new java.io.File("/dirNujnwrbztgg/dirSltzwairkpt/dirHnerlwyuqzs/dirDechugqpsyi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numXuhcxexvhlq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex26068 = 0;
			
			while (whileIndex26068-- > 0)
			{
				try
				{
					Integer.parseInt("numWywxjoakpzm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metUewdyxri(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[2];
		Map<Object, Object> valMalwqgbnfeg = new HashMap();
		Map<Object, Object> mapValSazdwymewfv = new HashMap();
		int mapValCezzhqltugs = 693;
		
		String mapKeyTmtenxkzipr = "StrYifzdditsiz";
		
		mapValSazdwymewfv.put("mapValCezzhqltugs","mapKeyTmtenxkzipr" );
		boolean mapValJbevsksriac = true;
		
		String mapKeyFaankbgzabo = "StrWycienhfszg";
		
		mapValSazdwymewfv.put("mapValJbevsksriac","mapKeyFaankbgzabo" );
		
		Object[] mapKeyQuajtqcjozr = new Object[8];
		long valDeqrjdtqujh = 2858543990961228545L;
		
		    mapKeyQuajtqcjozr[0] = valDeqrjdtqujh;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyQuajtqcjozr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valMalwqgbnfeg.put("mapValSazdwymewfv","mapKeyQuajtqcjozr" );
		Set<Object> mapValPgqfcqswnjw = new HashSet<Object>();
		boolean valWhzlqfoyqdn = false;
		
		mapValPgqfcqswnjw.add(valWhzlqfoyqdn);
		
		List<Object> mapKeyWwvxcjsnvju = new LinkedList<Object>();
		boolean valBsizgztydww = false;
		
		mapKeyWwvxcjsnvju.add(valBsizgztydww);
		
		valMalwqgbnfeg.put("mapValPgqfcqswnjw","mapKeyWwvxcjsnvju" );
		
		    root[0] = valMalwqgbnfeg;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Otfwaav 8Xmigibxon 5Qmzasj 5Zvnfyc 4Wyyns 6Cbxcgxv 3Tent ");
					logger.info("Time for log - info 6Mcvcilg 7Gknkncsy 4Ksrth 5Jonagb 5Ilrlzn 3Yded 12Daqqfsebzetxk 8Fdaljhgdc 12Wrubklvjfppnq 8Zkmdlywnd 10Cblmzggdolf 3Ltvv 11Wjhgaazhrocz 9Gjyvzlcvqf 3Gfan 6Pbhwlhv 6Zqsoawv 5Okqttc 3Fhbd 8Gmygfnhyt 12Dcuaerhfnkgtw 11Qjnngsjdgcgg 6Ljzimzg 12Lttemrdaewtdk 4Nckse 5Rukkib 7Mdzxkfcd 7Rejclabf 9Fcopmjlule 12Pxrnigxtihejv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Chfjiilg 12Sqfexqllrddac 10Xekydkmrnnb 6Lwfttfh 10Rsdmqwfyuam 6Gdooxut 11Beadptdbaayk 6Ldppfjg 4Mxmjh 3Hkig 10Rnzveclpaqr 10Dyqdlowrnhm 12Leglhfxvqdtgp 7Jrnnrucx 5Hkiwrv 11Vlijepitgvge 6Lcqvklq 9Pddvpkzdse 9Umigyuieig 4Dhvuo 12Jyozzcdoajrrx 7Qfxsdnek 6Pevoouw 4Nablt 6Sgagbnu 3Qlss 9Lrfenelbgx 3Kzwd 11Quvumztbjpkt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Ohyx 10Ifslpdrdehr 8Vfewcaqga ");
					logger.error("Time for log - error 3Xrvx 3Mmyv 9Xrpxwpzeti 8Mpxgeweoe 6Ybylbgo 7Ynfusaac 5Nekcfx 5Enbglu 7Qcqvwoak 6Cjmdqzt 4Tmuvt 5Rmoqxp 8Bhtqkbsrr 3Kqkh 3Hqah 10Sbkolwdobrw 3Csyj 4Gcvaf 9Divnheulvj 4Jrver ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hnmnf.dxh.laih.zpf.ClsDfldwucgkze.metWcabetshupsmkr(context); return;
			case (1): generated.wyah.shgd.ClsOoifqzin.metJlmkezrzypgj(context); return;
			case (2): generated.pmny.tmdlo.mfapc.ruez.fnhku.ClsHncyoaufamsb.metZiouerfahj(context); return;
			case (3): generated.pema.ddj.ssuh.ClsIlinaijnkxxo.metXiwjmfzcnkodct(context); return;
			case (4): generated.knck.lbfq.hgji.ClsItijgi.metCjgswneqtpuoq(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(203) + 6) % 225133) == 0)
			{
				java.io.File file = new java.io.File("/dirCejycopfonh/dirQekdyiogqum/dirKuogywnxeit/dirBsskgaxzrxg/dirGudrzulxxvr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numAcgfzhtvpvt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numHlpuqpafruw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex26081)
			{
			}
			
			if (((912) - (1624) % 115930) == 0)
			{
				try
				{
					Integer.parseInt("numMffetndnxtb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metRgojbrkwjkezrx(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valGzquxbqooxh = new HashMap();
		Object[] mapValCqgnkzvomgm = new Object[11];
		int valIussgbifccp = 32;
		
		    mapValCqgnkzvomgm[0] = valIussgbifccp;
		for (int i = 1; i < 11; i++)
		{
		    mapValCqgnkzvomgm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyRzodjgslfbj = new LinkedList<Object>();
		int valSmtrlowdbuu = 916;
		
		mapKeyRzodjgslfbj.add(valSmtrlowdbuu);
		String valVneghatizsb = "StrNurghzvguln";
		
		mapKeyRzodjgslfbj.add(valVneghatizsb);
		
		valGzquxbqooxh.put("mapValCqgnkzvomgm","mapKeyRzodjgslfbj" );
		
		root.add(valGzquxbqooxh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Ivotlg 7Erbgjscj 12Oeencarfwkrzn 12Hhrtwuoxwvhgb 7Cyokegmr 10Guvvgmerbzd 5Amrtyw 10Dzpujxzpglz 10Paevkpkmfnr 10Dfqtggmvobx 10Hpaplaipaos 9Dzsntlcmxv 12Usbppxzmcweke 4Jajhm 5Hdzmsp 12Gejytubjmqzgi 8Tubqbdwty 5Ethmjj 4Kseyl 10Dfvfhogtxxs 11Ssqxbiccpxog 7Mjdrapiz 6Rozsdyp ");
					logger.info("Time for log - info 6Safgfrh 7Vmyerwrd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Rmdpjnmmy 9Emtjnsxxye 11Hpmkjaienjll 5Fsqtlo 3Pjxh 9Wturpmnosb 9Aweltizvno 3Zkoc 3Kfsh 7Qscokefr 8Snnbfikdu 4Yrmsl 6Pmwbpap 12Rvwtqjxpwjydz 7Dmvtvjsi 7Vhwftiiu 8Fcrknfnpe 11Zdikswhnuipy 5Fhepbz 3Ymoq 11Syyptraevopd 3Jzcl 11Amghrbkahlcf 6Ryntyui 6Prtrgio 11Kvltcsuhxplk 12Jjcfpnbbqkyaw 4Rrbkc 7Onfpgfbf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Jjzgdihqsgtpq 5Gucubs 5Usbbph 7Vtpikcfo 3Rdtf 5Cwgpvw ");
					logger.error("Time for log - error 7Qtblihbf 12Atayqdkoaecnm 8Uhqyrerjd 8Jqbwdikev 5Ktdzhw 5Iwjuhy 9Ualaffgglq 11Tijfzwfemenn 8Vndhnouwn 6Skutvdk 10Vlypilzddol 11Ccoljoojjnjg 7Nwfeqwpx 10Mrojpywqohm 10Zawlxkpxuro 5Nrxsoo 4Snfxp 5Zyuotq 5Uyhcnz 5Ngwlsj 3Eqry 7Cnimjjzv 11Aucfhhyzztrm 4Hdbpa ");
					logger.error("Time for log - error 11Bvxfojgmsaru 8Irotqdflq 7Cqjxrjdo 8Dsdairmta 5Mdaqle 3Sjia 9Jgjddjufwa 7Oejsppdv 12Eayajgyyprhgk 8Mzawowjnh 7Ytddcyjy 8Slsluwdnz 12Bffdhihpwcpkl 11Stpmkijlagax 5Svcqhw 5Ayhbdj 9Bgaktytohn 5Lvqmtg 5Nslvbn 3Qley 8Xygozwxol 9Lmjyaisnzk 10Wojdjmgiqef 4Eqqdx 9Zypwztiavm 9Mzpdqamcay ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metZlaxbquc(context); return;
			case (1): generated.lxrj.lts.csk.iew.ClsCagmzsja.metMsmzpyezeb(context); return;
			case (2): generated.agl.duqt.yfyli.jnv.jpizl.ClsQbgwqgmsxm.metEmnhch(context); return;
			case (3): generated.wmjc.yywge.qivf.ClsNtnaiojgyo.metNewjeyyudocce(context); return;
			case (4): generated.fdupg.slw.vpest.ClsBfbtvkikd.metJjksunzjbd(context); return;
		}
				{
			long varEkinoqulpzu = (Config.get().getRandom().nextInt(569) + 5) - (904);
		}
	}


	public static void metIhsje(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Object[] mapValGeficuwozqw = new Object[11];
		Map<Object, Object> valOaedpxosryd = new HashMap();
		int mapValRzyqyzobinz = 655;
		
		boolean mapKeyVbpdiszcqgu = false;
		
		valOaedpxosryd.put("mapValRzyqyzobinz","mapKeyVbpdiszcqgu" );
		boolean mapValZosazzhajxo = true;
		
		boolean mapKeyRkhfrzpoxsr = true;
		
		valOaedpxosryd.put("mapValZosazzhajxo","mapKeyRkhfrzpoxsr" );
		
		    mapValGeficuwozqw[0] = valOaedpxosryd;
		for (int i = 1; i < 11; i++)
		{
		    mapValGeficuwozqw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyMuuijqzddsz = new HashMap();
		Set<Object> mapValMhxlfthxgpv = new HashSet<Object>();
		long valIiyviabremm = 5220634786710812770L;
		
		mapValMhxlfthxgpv.add(valIiyviabremm);
		String valPuotxeayrzt = "StrEftzgbyymne";
		
		mapValMhxlfthxgpv.add(valPuotxeayrzt);
		
		Map<Object, Object> mapKeyHmgdsmbsfni = new HashMap();
		String mapValHwypztdvwga = "StrAnfmrigomfh";
		
		long mapKeyBvlkosjjlcv = 6151113330980067707L;
		
		mapKeyHmgdsmbsfni.put("mapValHwypztdvwga","mapKeyBvlkosjjlcv" );
		boolean mapValQqcrhiezpfw = true;
		
		int mapKeyZjuurmhtedg = 531;
		
		mapKeyHmgdsmbsfni.put("mapValQqcrhiezpfw","mapKeyZjuurmhtedg" );
		
		mapKeyMuuijqzddsz.put("mapValMhxlfthxgpv","mapKeyHmgdsmbsfni" );
		Map<Object, Object> mapValVjbdgloqwhz = new HashMap();
		boolean mapValHxosbabfpqe = false;
		
		String mapKeyGnflavmfcjw = "StrVhrybvboiml";
		
		mapValVjbdgloqwhz.put("mapValHxosbabfpqe","mapKeyGnflavmfcjw" );
		
		Object[] mapKeyEmiwiywapnn = new Object[3];
		String valXylxdbpszfr = "StrXmqcdtzzbcz";
		
		    mapKeyEmiwiywapnn[0] = valXylxdbpszfr;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyEmiwiywapnn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyMuuijqzddsz.put("mapValVjbdgloqwhz","mapKeyEmiwiywapnn" );
		
		root.put("mapValGeficuwozqw","mapKeyMuuijqzddsz" );
		List<Object> mapValFjnifiqpkxx = new LinkedList<Object>();
		Object[] valGdbqkzssmmx = new Object[8];
		boolean valLtllrwzkbns = true;
		
		    valGdbqkzssmmx[0] = valLtllrwzkbns;
		for (int i = 1; i < 8; i++)
		{
		    valGdbqkzssmmx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValFjnifiqpkxx.add(valGdbqkzssmmx);
		Object[] valHxmzcxhipeq = new Object[2];
		boolean valOkhbxjlstvf = true;
		
		    valHxmzcxhipeq[0] = valOkhbxjlstvf;
		for (int i = 1; i < 2; i++)
		{
		    valHxmzcxhipeq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValFjnifiqpkxx.add(valHxmzcxhipeq);
		
		Object[] mapKeyKyweipmpdfp = new Object[3];
		List<Object> valYjaduoaemnb = new LinkedList<Object>();
		boolean valUdxcghcpnoy = false;
		
		valYjaduoaemnb.add(valUdxcghcpnoy);
		
		    mapKeyKyweipmpdfp[0] = valYjaduoaemnb;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyKyweipmpdfp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValFjnifiqpkxx","mapKeyKyweipmpdfp" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Zwfytqxbjguhz 12Xjxbruyevlfrk 4Wewyh 11Gtgxzdbfchwt 12Qvlfpcdxqlgsi 11Iuzqmwyrvalj 10Uhpqwundbnh 3Erha 5Ixcglr 10Aitjhgawfau 4Clnhl 10Ozyyhrathtt 5Odnouf 3Teqw 4Ibqpt 10Whsglcvftfq 6Solkxxu 5Tgzvbm 3Dgsj 12Kjwtlnbiwmvrd 7Donfbgtt 9Jfdpymlerh 5Ocmnao 3Ffzk 12Qvfemmwkvvajv 4Lbnjz 6Akrboje 4Zwste ");
					logger.info("Time for log - info 12Netmyditjcawe 8Nitkgytga 3Rthc 3Snje 11Tkeassiqboqn 10Gihbsgxjehr 9Ccljaexkql 7Tcqhxsuj 10Sevqhzpyolt 7Yagqwnhq 7Fgzpeigp 8Oqjijpmmb 7Dkiyrnws 9Ziunzmlqbm 10Zzsnmkbzzid 9Qqhrvtnwvm 5Karmio 10Jsyqoiipwwh 6Sudajxm 5Gzrnrs 10Bibulousywb 5Vemkhb 4Uunjl ");
					logger.info("Time for log - info 3Tjcm 9Lzxgmhcesd 11Dnghidijmjyv 4Etogh 4Kflkp 11Cywzylwrogbq 6Nqqsvfo 4Ylytk 3Jkpx 5Ckirio 5Kumhax 5Sefzvq 6Raxwehb 4Qadjc 12Odyysvzhftlnf 8Tldkgsojg 12Namrmrjzxbmay 12Ajwmqyvrzcegh 5Cwtzhr 5Rqnsrv 7Hyvgwvgp 10Rqegigdsfjo 4Ugoih 7Qgkedbpu 12Graxxncijxdwd 7Qkztvtmr 7Dideacsg 10Gtzepddqjnh 4Qbsoq 9Ibkkyxvvxn 12Vwxocdtnlzjex ");
					logger.info("Time for log - info 10Jzrdxbqjhmg 3Ewhr 9Vfhswxsmkr 8Bgmlndkuc 7Exptsdru 5Agisgd 7Saaalymi 12Idlrdrwqjvsgx 9Tghndzgnfk 3Dlkk 10Bdznmvvwcsd 3Axyh 10Jvihvfeldwk 5Kqjpfm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Lstuclorwxcem 4Kgtqx 4Gbkbh 12Zfmnpwzkvymlm 7Vbtrzdil 7Prnnhlar 11Zfqigtshixjw 4Izpqi 5Drpfug 9Ffnjwackba 8Uyjzbpqrj ");
					logger.warn("Time for log - warn 11Ysykecbaqgxd 7Gpipnwih 8Uggcxnash 10Fyplhrvcxlj 3Yzjp 12Hoktjyxgdwgxj 5Fmdhkn 3Ezxl 3Qdvt 8Ezomfxxgb 11Llfxpzfskcbw 11Ikabknnczgnx 4Ytrxz 5Fpltzn 9Ykqsxdvyqg 10Vzohtbupqzi ");
					logger.warn("Time for log - warn 5Zsslgf 6Rkoxdbc 4Hqorl 10Fdpwvofwhwc 4Vvfxc 11Gxbzzoxfysdi 10Sisqdumtfrz 4Orbtx 9Tqlydijrbc 11Eozocsarggvz 4Otvqv 4Fxygy 5Wwwkrv 3Dzkj 11Lcrqzsctjagr 4Qsmfu 10Ebgjsedzjkt 10Grjuxhqhzvz 8Fmwlrqrra 6Mtmwxgu 8Czshyejwz 7Oqpbowfa 9Qdsfqeecil 4Gsyra ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Nknkneebsfdyb 3Xrrd 7Muxjwcif 11Mlekjsrzsbll 5Iynmsn 8Qpsjhipze 9Qheywszvfi 5Htovqv 6Jgwqqht 12Subexjzljkfoy 9Ldezqblqqs 6Egwtigs 4Slsib 5Xnwwvy 12Zaqudvfuxmshq 9Kwihsawbfr 6Bdboyxa 8Ygbycdydk 10Hxxqtjshxtq 4Ehjfh 4Fkyqz 7Cstiakpd 9Hyemrvogat 11Jqujrhllrbhi 7Kxfwcnsv 4Fzhyo 8Ntxfqjotc 4Rsvan 11Wqibjdmswwlm 3Ggyp 8Fnuqjdbed ");
					logger.error("Time for log - error 10Nuxqffbguha 3Hcjc 10Asblmdfnxja 7Jydzpyrz ");
					logger.error("Time for log - error 7Vhvvlgkm 8Mugpvphjh 9Apkfbesden 10Wpiiewkvfcb 3Pifc 3Gjzv 8Qxjxyvbtp 6Rmywcst 9Fnzfzvztwv 12Dbviozhhdjhmr 8Hxvnxasmi 9Ytqwzkzqvn 9Kuzzqsmjjr 6Ixxyckd 9Zcrbktjmys 4Svajd 11Pnhpiqxukvuy 9Ylqvpisdym 9Jitfjpnduw 6Deifkee 5Vefbbr 11Feonarmixgiv 9Gpoqscucmn 5Pldzxb 9Ejabloknsk 9Juunvppfgw ");
					logger.error("Time for log - error 3Qafa 7Bhthxpft 8Myypynojl 11Rvmpvqvqavef 10Nroqtdfolji 12Dhphlgqwszmtu 6Vujslgf 11Urshhlmnlpye ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tbf.qnyk.tdd.dnbuc.fexg.ClsFiknxpviyjlxbx.metFjlbdq(context); return;
			case (1): generated.htfwc.kxkr.hjcg.ofg.qaif.ClsGjqugtpsjo.metIuperibrlehft(context); return;
			case (2): generated.uooez.nez.ipsx.tenui.ClsCrgtl.metEgxtoauldfq(context); return;
			case (3): generated.bcbrr.mrpx.ClsJcswauwrr.metIydcpeyrd(context); return;
			case (4): generated.ythhn.vxvz.yizb.ClsLckdkkeapmss.metUtevjjtyd(context); return;
		}
				{
			long whileIndex26087 = 0;
			
			while (whileIndex26087-- > 0)
			{
				try
				{
					Integer.parseInt("numTbpozxzjdin");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirXfoqvzprqjt/dirQqpodbrbxst/dirWgwtpvjyvar/dirHhtjwvwjchh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex26092)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex26089 = 0;
			
			while (whileIndex26089-- > 0)
			{
				java.io.File file = new java.io.File("/dirTdpnmnaugjn/dirBwhpbjlcvgd/dirMufhmdegzjc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metQrptesizpvf(Context context) throws Exception
	{
				int methodId = 4;
		Object[] root = new Object[2];
		Set<Object> valYggnzuhygml = new HashSet<Object>();
		Set<Object> valZkopfvmducf = new HashSet<Object>();
		long valGinlsqnijrd = 7513242427952963623L;
		
		valZkopfvmducf.add(valGinlsqnijrd);
		
		valYggnzuhygml.add(valZkopfvmducf);
		Object[] valAzblttfpgqz = new Object[3];
		String valPfktloftsap = "StrMlphryyrote";
		
		    valAzblttfpgqz[0] = valPfktloftsap;
		for (int i = 1; i < 3; i++)
		{
		    valAzblttfpgqz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYggnzuhygml.add(valAzblttfpgqz);
		
		    root[0] = valYggnzuhygml;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Nlbxciunyga 4Uovaa 9Oqmomwevpo 12Mcpguacdayymq ");
					logger.info("Time for log - info 9Tyasesosnf 12Woyyqfezjbcjv 7Trgtpkfc ");
					logger.info("Time for log - info 9Vzryvagmix 10Yiamphavlxa ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Cbefhbp 3Fxgj 11Jbjcbtneqmqc 9Givdcncdqd 6Ggfmson 11Tlaxwdagsibm 11Ezpvqkdsprip 7Lbrwyesd 12Bwjwwzcnybzrw 12Aarycqoalwxhc 3Dvfy 4Zmlqj 5Rglbjc 3Hupv 10Xhzrrkzsorp 10Toyfillylvc 4Djxtb 8Chrcxyipp 3Etiw 3Byuv 4Dvmgk 3Brtm 12Cicjckpmvkmrz 9Igrfsnbmtv 6Exbrnux 3Frup 3Ecto ");
					logger.warn("Time for log - warn 7Dfzwhfcm 7Qmfftjxi 6Hbidbpl 8Cixfbfoue 8Hahhfflxx 3Cxfi 8Cqwtahpoh 12Ydwckqnmoitym 9Cyaghlqgzh 10Hbeeuoydebh 7Fzctdarn 6Lxabzim 3Rxhm 7Vmagizhl 4Odkkd 10Zpcoufasghm 9Snbwsweceo 9Hipdyungju 12Gdglqfgwrkcer 7Hduolzrz 8Dluadkqrl 12Gpzwrrzygiieg 10Rifuddofhtj ");
					logger.warn("Time for log - warn 3Zwnl 4Fdzcv ");
					logger.warn("Time for log - warn 7Uwfovele 4Eevpl 10Bezlgjjzxjq 9Pyviadpori 7Rjtuztat 4Ymxaf 4Abnaf 5Yijayj 8Cjcfglbbv 10Wpkkyuvnecg 10Kapajhpnvaw 11Glpxsplhsccd 12Tdlcsecgpkkqq 10Refwvkaijnl 5Sygrrx 4Hmhnl 3Jxkx 6Ccdqlrj 10Mlarekaofjv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Zkhh 5Rfsoha 4Imsrh 9Ccjcposzzz 3Sgqr 3Yxmt 9Ciugvriiql 8Uhddoqcti 9Ssxcrizrgc 3Ened ");
					logger.error("Time for log - error 11Vzsyhnnucrlu 4Myjbh 10Agrsnxtntou 9Rbvukfatie 8Zewspjgdl 3Sizs 7Gejdkoic 8Tirseidks 9Qmyspddrzy 3Cgdm 6Ybxhbsc 11Hlaotjsisiyt 12Ooqrzoxlcnlzl 12Gsuthxheolshg 9Aqpkzclzzs 4Aavbt 3Rsbo 11Xiidlcfcnqin 4Fztsn 8Okexpobqw 3Zapy 5Eegstn 8Mutfwxllb 6Pggvbpe 12Unfdclzpkxxze 8Curpwempt ");
					logger.error("Time for log - error 8Pytoyxkdm 10Rsmjhdidlvl 5Qikjxf 5Cmqbjv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tgr.kelz.siz.xfels.ClsKydjl.metQmhajcedjutgex(context); return;
			case (1): generated.oucap.zcbrm.jbhm.yte.ClsEpzgpbjqjhr.metTekko(context); return;
			case (2): generated.wvctc.whp.ftjy.ClsPwdcftvpjt.metMihtagu(context); return;
			case (3): generated.vbmu.nqy.tvok.ClsTqtbdjb.metNhjvsnqwnbit(context); return;
			case (4): generated.yvbmb.hnmr.uqxw.ClsYomdrwntzuxawb.metAeacazp(context); return;
		}
				{
			int loopIndex26097 = 0;
			for (loopIndex26097 = 0; loopIndex26097 < 4680; loopIndex26097++)
			{
				java.io.File file = new java.io.File("/dirKxqsujfcdvm/dirAvdtlnkvwms/dirGljnkyngeil/dirEhjwiugufgy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex26098 = 0;
			
			while (whileIndex26098-- > 0)
			{
				try
				{
					Integer.parseInt("numFdjejprimbv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
