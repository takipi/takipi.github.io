package generated.pef.kybz.yzpf.dzs.obqpv;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsKizvnatyigi
{
	 public static final int classId = 303;
	 static final Logger logger = LoggerFactory.getLogger(ClsKizvnatyigi.class);

	public static void metVpeqkkprfd(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valMqggyratiot = new LinkedList<Object>();
		Object[] valVjpkokmgsvd = new Object[2];
		String valCyvuctesuey = "StrTobscngarrl";
		
		    valVjpkokmgsvd[0] = valCyvuctesuey;
		for (int i = 1; i < 2; i++)
		{
		    valVjpkokmgsvd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valMqggyratiot.add(valVjpkokmgsvd);
		List<Object> valTykbairgduf = new LinkedList<Object>();
		int valOuuqwpldbpt = 837;
		
		valTykbairgduf.add(valOuuqwpldbpt);
		
		valMqggyratiot.add(valTykbairgduf);
		
		root.add(valMqggyratiot);
		Object[] valFvikelvwqqy = new Object[4];
		Set<Object> valUtfebauevqs = new HashSet<Object>();
		long valWmeztdfeswh = 1477907301334318776L;
		
		valUtfebauevqs.add(valWmeztdfeswh);
		boolean valPebmyruqcts = true;
		
		valUtfebauevqs.add(valPebmyruqcts);
		
		    valFvikelvwqqy[0] = valUtfebauevqs;
		for (int i = 1; i < 4; i++)
		{
		    valFvikelvwqqy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valFvikelvwqqy);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Jxlog 8Tsydgqaqn 11Vvppgyekrizo 3Hmgw 12Peomrpiwozcuq 6Uoceqfw 10Kveaowqlepi 12Jcuwhgcpcchoe 7Sqwnlqka 8Owvxfwrek 7Jadlqeuk 9Idoaxoqxpl 10Wvwpwseucrb 7Jwcozxwa 3Ascw 8Ekswautsj 3Klqh 6Faflsou 4Rthxv 12Hvnpzidalimog 4Qqixi 8Tdmbnpmxs 4Vpmlu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Pkwsjqboqnfxh 12Iznoaxmmkaefu 5Tqmanj 12Nhwqkodvkghfe 9Dvrujvkcdr 5Wmcppk 5Zlulcg 11Iomqjjrhfhyu 3Jowh 10Htpajoahppa 5Vqgsco 4Syspj ");
					logger.warn("Time for log - warn 6Oisgiho 6Lxzyrew 9Zjpfecezyb 4Ahszy 8Ijjkzitrk 5Xovrpk 3Ljjy 3Kvls 11Lnavugfrthud 3Kqex 10Urujsaiyrof 11Fwlatumhqrfi 12Nlhhouygnmmaj 10Peerwzhlfbz 3Umsk ");
					logger.warn("Time for log - warn 6Ffevjei 8Bjbogkacw 7Gtehdnuk 10Jdgjiafsajn 6Rntnwcu 11Zmknhcjqcgdl 9Arfsolpclm 4Zmmiq 3Nzgh 5Kigozi 7Qeecbkkt 8Zljxhxtkg 9Aeupdhjdff 6Dxoqixn 10Kacmkmkgzly 4Bsdoy 10Zgzbynzkdhx 11Umwlisnewvvh 5Lfhneb 3Qxdw 12Ehbtcsyfoxouo 9Wsiyseroqb 10Savdetfchib 12Ebnyvhcvetdmi 8Nroohgsec 11Gzzztwnrroab 11Uohuhwfrwrqr 8Bnhsdliyo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Celmegp 5Zkyria 8Qfodpvxqz ");
					logger.error("Time for log - error 8Lvvjndiym 11Bngwyjpekbdw 4Dxsmh 7Rgjoaqmv 5Zudarm 4Wufuc 4Vbafu 8Zbvkrmcle 11Ggbhgqzeclar 7Rdgbxsds 12Mylvufxhxlrui 6Zmwdkdy 9Bnfbxquqcq 9Kbzpgkowdb 10Lddbmgvptbr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jrx.knq.qgl.klpmp.wqhuy.ClsPrfpvgkjefvagy.metUxhyesxgsaesr(context); return;
			case (1): generated.fzd.qgqjp.ClsVzqqvdhb.metMsjbhqpplani(context); return;
			case (2): generated.sik.dyw.jmm.xdu.omh.ClsVarjcvcyur.metFesaihfuowja(context); return;
			case (3): generated.rqcl.nvc.nixtb.fedm.ClsWjomfkmimge.metFpafgu(context); return;
			case (4): generated.qnzm.livr.ClsPutzsgygioejxl.metJtxtxkipo(context); return;
		}
				{
			long varMbjjpmvzvsx = (5502);
			long varMcmyuvsruvp = (33);
		}
	}


	public static void metKzutin(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[2];
		Map<Object, Object> valWvgioovtwuy = new HashMap();
		List<Object> mapValBitcqznuzgz = new LinkedList<Object>();
		String valMlubsfrvevq = "StrUsdrtvomjxy";
		
		mapValBitcqznuzgz.add(valMlubsfrvevq);
		long valDdecbsweliz = -3603354992126381437L;
		
		mapValBitcqznuzgz.add(valDdecbsweliz);
		
		List<Object> mapKeyOetnqtylhzs = new LinkedList<Object>();
		long valYvfklwljnlo = -4568274846025228057L;
		
		mapKeyOetnqtylhzs.add(valYvfklwljnlo);
		
		valWvgioovtwuy.put("mapValBitcqznuzgz","mapKeyOetnqtylhzs" );
		
		    root[0] = valWvgioovtwuy;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Utyfisb 12Dsinnoiisxrpd 8Eziyjuedn 6Jhqhtrd 4Bhvyd 3Wvkz 3Zbst 8Hxbcrucuy 6Ljmfihn 9Ngrhtdwple 4Qgbqx 8Sobghoriw 11Wfqklqamwbyz 3Kwid 3Jhwz 9Npqxnfivrl 9Thbdxcyszk 6Lfseqth ");
					logger.info("Time for log - info 3Nsca 9Qipulcnnzt 4Sxfdq 6Xpcdifg 6Cryaaxv 5Olbmke 12Ncmbyfrkawomp ");
					logger.info("Time for log - info 10Pilvwbtlmxg 12Yezacskzqgrfp 3Yenp 6Afisysk 6Wllgfog 3Jlid 12Yjueqjnagwzeb 7Tapnxvdg 10Lqzepcfobzz 5Ooxmqx 8Zcrqrpveg 7Wfqnpkkt 4Dhjle 11Rxkmcgtzhvtb 3Gbqj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Ozylouofduj 10Gfwaerszzkj 7Zialcolz 10Zlorccpughr 7Wmsyblqm 6Snmtdfx 9Sglwyqrilv 8Pwxxbsirf 11Mcwclmjlcgcq 8Umkokzcnh 10Ejdtomimqrv 5Gajfyn 8Emwctrgip 6Bafvboo 7Ivxxktnw 7Kfismsqs 10Hyztikbxapa 5Yrdtsi 11Eesxuvnhqjeu 10Qqxapuljmak 3Xpnn ");
					logger.warn("Time for log - warn 11Tbrxrmrdpywc 6Ghgpltr 6Pydsxof 9Sazkwxnwhu 6Hvedtfe 8Tvbfwqnye 3Rvbs 7Gkuaumju 7Uyblgliz 12Qerrqnqsbeiqo 6Zyhwegw 12Gytgnxhhfdvav 8Pycdauegz 9Xhmqmbwcgw 8Xnjtowhak 7Ooabdbbh 8Wrqkstqrm 6Gqvqolq 7Dcplwlnm 7Igtdtrxl 6Lctfjyt 5Jlurdl 8Eviixdieg 5Zuchhw 8Nvppfmhmx 7Zqwkyhtf 12Kfibtshpwogyc 7Pjzliduu 5Hpdoex 9Wvljrjqapf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qyalc.lus.ClsKvouelboluo.metVctwjruk(context); return;
			case (1): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metUfpufoucpqucye(context); return;
			case (2): generated.yfyks.sksk.asgi.ClsXzaehxcicrdskw.metZqjjzsjied(context); return;
			case (3): generated.yudi.kwckr.ClsDwmxwqmygi.metNppyrlnbpx(context); return;
			case (4): generated.cbscy.vax.ifmv.uvjll.ClsXprhoql.metUsqqbascqyi(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(319) + 0) + (3677) % 865302) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(615) + 2) % 693797) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((1195) % 819968) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(78) + 1) * (6435) % 806704) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
