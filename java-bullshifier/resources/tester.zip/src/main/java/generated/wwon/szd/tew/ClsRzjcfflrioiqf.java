package generated.wwon.szd.tew;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsRzjcfflrioiqf
{
	 public static final int classId = 34;
	 static final Logger logger = LoggerFactory.getLogger(ClsRzjcfflrioiqf.class);

	public static void metOqjme(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValOumqplpeyqh = new HashMap();
		Object[] mapValBhyhbsodoki = new Object[6];
		int valOlfkbimdgai = 993;
		
		    mapValBhyhbsodoki[0] = valOlfkbimdgai;
		for (int i = 1; i < 6; i++)
		{
		    mapValBhyhbsodoki[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyUteyqdalthq = new HashMap();
		long mapValIgzcxktqteu = 1700087542230614050L;
		
		boolean mapKeyIxgrdkiwzzd = false;
		
		mapKeyUteyqdalthq.put("mapValIgzcxktqteu","mapKeyIxgrdkiwzzd" );
		int mapValFnomrbdtupf = 963;
		
		boolean mapKeyPgqmiwuczqs = false;
		
		mapKeyUteyqdalthq.put("mapValFnomrbdtupf","mapKeyPgqmiwuczqs" );
		
		mapValOumqplpeyqh.put("mapValBhyhbsodoki","mapKeyUteyqdalthq" );
		
		Set<Object> mapKeyZwrotplelpy = new HashSet<Object>();
		Set<Object> valFiqjvakgyod = new HashSet<Object>();
		int valSunkqshkulz = 541;
		
		valFiqjvakgyod.add(valSunkqshkulz);
		
		mapKeyZwrotplelpy.add(valFiqjvakgyod);
		List<Object> valAvmvysiexfx = new LinkedList<Object>();
		int valLwfohitaump = 125;
		
		valAvmvysiexfx.add(valLwfohitaump);
		int valKjmzrsowjse = 692;
		
		valAvmvysiexfx.add(valKjmzrsowjse);
		
		mapKeyZwrotplelpy.add(valAvmvysiexfx);
		
		root.put("mapValOumqplpeyqh","mapKeyZwrotplelpy" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Fwtypm 3Unkr 3Ydad 6Gqnxjmr 9Gcbahzooem 3Moba 8Yskkicbna 5Fyieql 10Aeuaefzdrno 6Vttnkuz 9Drfwxhgcoq 3Ibyx 4Jcpdd 11Yilvripngbuc 10Pmovkzbomzp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Aevjgwblmjywg 3Lqzj 4Jbbwx 8Fnqkpbfmb 6Zcfkhmx 12Wzgfopmnfjgcp 12Plcjbyiiaqzvm 11Ecbzbjqgxyyx 3Hubn 6Xgeqrrh 7Wbasohbw 6Mgrghyb 12Nfyvlbwbwdskh 8Hzqjmzium 6Tyqmpma 11Rdnqbdojaxtq 3Gbdd 3Rqdt 8Mpmaphpdf 10Baamffgsfdx 8Xqsaijicn 7Pkpghlcu 12Hemxlajouazzi 12Bmjcvfsmvdcfn 3Ppii 6Qwluypb 3Nigs 7Lofhqukn 5Rjxhcv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Mufctyrkdusvg 5Blecuh 7Oyniozbh 5Cepyjx 6Ulssetm 9Clzdfauzvj 11Frnuuvrzmjne 3Dnwj 8Pljioazru 4Qayyn 10Ajyhqkwsffq 5Paydkp 10Wipzovigptz 3Kedf 3Mimp 3Lnuk 11Lgawvznwugag 5Gnnbbl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fhy.qnk.brj.xhy.ClsYgumeudbf.metCzfoghkqm(context); return;
			case (1): generated.kyd.fxg.ClsVvcevjvyz.metAvlkamwowqupb(context); return;
			case (2): generated.mccr.hhayo.cgyp.gjrvj.ClsTjitk.metTxgopsgvmsurv(context); return;
			case (3): generated.lxeoh.qnh.crznc.ifldw.owge.ClsJaitfhoyoqqri.metElosoop(context); return;
			case (4): generated.jzpii.ixwl.ClsCvgimgq.metBcgopgf(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex2600)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirMcddhhtuafa/dirNrmiyvxdfmc/dirMlyfwpqhnvt/dirJrvxacnvskv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metNhvkfyrepdbqs(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valFvcjowkeksz = new LinkedList<Object>();
		List<Object> valArmsgrxauzw = new LinkedList<Object>();
		int valBerxlksussy = 704;
		
		valArmsgrxauzw.add(valBerxlksussy);
		long valVgxjkvxojfv = -1235932033137968067L;
		
		valArmsgrxauzw.add(valVgxjkvxojfv);
		
		valFvcjowkeksz.add(valArmsgrxauzw);
		Object[] valGuadmyplwup = new Object[9];
		boolean valOcwcdworxbx = false;
		
		    valGuadmyplwup[0] = valOcwcdworxbx;
		for (int i = 1; i < 9; i++)
		{
		    valGuadmyplwup[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valFvcjowkeksz.add(valGuadmyplwup);
		
		root.add(valFvcjowkeksz);
		Set<Object> valDxupfbewtfv = new HashSet<Object>();
		Object[] valBblstjhpywj = new Object[2];
		boolean valAlezqyojpop = false;
		
		    valBblstjhpywj[0] = valAlezqyojpop;
		for (int i = 1; i < 2; i++)
		{
		    valBblstjhpywj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDxupfbewtfv.add(valBblstjhpywj);
		
		root.add(valDxupfbewtfv);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Itdonprbiv 11Jpjnfyesrwyy 9Tdlxptzuct 5Zrkesd 6Prmopon 11Edgalfuprael 3Yzxv 4Ezvlx 8Vhawxwcbf 11Ectkkgsadorf 5Xditoy 3Elhy 10Wqktxseedjf 8Kzjyqlocl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Sreuk 10Zyxnhylqqej 5Dkighn 10Xbddnnmyzpa 5Cvqiuy 11Ldryykvplwyv 6Hjkwizg 11Gzgzktcophlg 11Eacrleukhwpy 9Nrtotzkbgh 4Goarf 11Fnnavwoblsvx ");
					logger.error("Time for log - error 3Brcv 11Sqbysxrmoyqi 11Mgoaytpkgimz 5Bqhkia 11Xqnssiaozgot 9Djpbwxlhsr 11Cisedbludtjr 3Bmue 3Nbdq 10Lbquwwniouo 5Vnjjvd 5Yixtsb 6Kinwkxo 8Usynvpqsr 7Oxgyiect ");
					logger.error("Time for log - error 11Uhzodvrxbzim 5Hexvra 3Miro 9Tswtiraghn 11Vyueldeyazwk 4Ivyql 10Mnbjmxbfnfw 5Jvuojz 9Gdrheqjvkh 5Dwebpa 4Yrrlw 10Gamxkcrfrrn 8Ekcrdujiv 7Mdmgcqeo 8Ftmkeczaf 10Grcalvrrolb 3Fsfd 6Mpfelpo 12Qpeeazsfqgiui 7Aigcdpfk 7Jihaoizs ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.amxo.ekvdv.ClsShqqngjhvyrxx.metPxdjzije(context); return;
			case (1): generated.lxab.bkb.mqw.ClsMiouvnamcvsap.metKsjeyneapvdv(context); return;
			case (2): generated.ahr.cnut.ztcbc.ClsUicrpogixv.metNaysjnfmv(context); return;
			case (3): generated.avme.rnc.ClsUgqeozcqx.metIsegbgah(context); return;
			case (4): generated.hdrlt.jxdm.bjqs.pupxs.ClsZoyaigxdyb.metCofpcgjfkt(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(377) + 8) % 973555) == 0)
			{
				try
				{
					Integer.parseInt("numHnrzflwvvnl");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex2605 = 0;
			
			while (whileIndex2605-- > 0)
			{
				try
				{
					Integer.parseInt("numNvjuowhjzci");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metRchlwwntsqlvan(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[7];
		Map<Object, Object> valNuohqrbckja = new HashMap();
		List<Object> mapValJjmwpcaxyhs = new LinkedList<Object>();
		String valYagxnedtpqy = "StrOwasmalvwms";
		
		mapValJjmwpcaxyhs.add(valYagxnedtpqy);
		int valGcexoltexxx = 992;
		
		mapValJjmwpcaxyhs.add(valGcexoltexxx);
		
		Object[] mapKeyGsqugmpdbhp = new Object[5];
		long valTflgevxukqq = -1453069739832503482L;
		
		    mapKeyGsqugmpdbhp[0] = valTflgevxukqq;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyGsqugmpdbhp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valNuohqrbckja.put("mapValJjmwpcaxyhs","mapKeyGsqugmpdbhp" );
		
		    root[0] = valNuohqrbckja;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Klsrp 3Owvf 4Bcqtw 8Zkshlikkq 4Nvptq 12Ffercicdzjthc 6Yulazue 7Hecxsrbs 10Nrxioyknitt 8Gnfjhodix 3Xvjq 4Qemiw 6Jrkrqwp 12Rdaxcedrkadhy 10Xksnfwnvrkq 12Wqdurzfvmssuv 10Cgnqxlchavl 6Yjhdawg ");
					logger.info("Time for log - info 4Jnpap 4Qlwue 7Hcyahvhq 3Ffbr 11Gbajemzmsujs 6Yyaixqv 6Ikdmsdp 4Kgqnm 11Jajtzstpvxei 6Sqqenrv 5Xcsupe 10Vrljprpnira 12Gplfkogcdetml 10Ljgfbcoeurt 7Lpwbmjuq 3Srio 8Rggizyspu 9Snklsoybfp ");
					logger.info("Time for log - info 10Kpnwbuqohvz 5Hjlwwu 8Wteudbrde 12Gqdsodnevxppt 10Cyewuuvxnlj 6Tkedwdr 11Yenwxevpzmzv 5Pxapld 4Wsvik 9Jitzpmzonb 4Mmuuz 12Zvvfkcqvkqnwl 9Fslltvcxwm 4Mdqlf 7Vgsxfxya 6Uzohwjd 4Ocpse 7Mqvwukhe 8Tpjfjezdb 3Pwyk 7Kqcgqygi 9Raithgmbru 6Wsruprs 6Epfnwvg ");
					logger.info("Time for log - info 4Pwbcc 4Xkjom 4Ktxib 4Oxiaq 6Piscjvo 7Pdeeatri 7Cmxezncc 11Gjwurmaopjsx 5Giqzbr 5Lomkxk 6Twymaln 11Eejslrlnypbs 11Groxkrxmfzse 12Flkapuhfxmbxf 6Sovhatf 7Vhmypfio 4Vnluu 10Xzxxoyuznty 6Bymepom 5Ukkiys 11Crcjreknbcqt 7Wxsizdew 9Dohbnosolp 12Zndrhfhtcvocj 12Ntdvdopfuopyt 7Lrtohpcx 5Xcgcsx ");
					logger.info("Time for log - info 11Vivqubiewzzd 10Dgriztpgcag 8Jsrsemwuy 11Erdbklrqpkbm 8Dzvxuqdae 10Dkarspzhrya 12Mmaioxnatyhxe 4Jwqio ");
					logger.info("Time for log - info 8Gftatqqns 12Ufqvcrjwurkfe 3Hcsr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Zgyovbcxo 9Jjhokrknrc 12Arcqltyvtkjxo 9Kubbzdeuax 6Bscdwnn 3Pggf 5Dhkjvl 6Cmixrxm 3Gxqr 4Bvyzx 3Uusb 9Fqehqiklie 9Azbmotpdwj 5Ngjdhz 7Egmcsipb 9Ikbfkztmww 5Vgycrp 8Mwpwgstxq 5Aeevdu 11Mntacvkpjdwc 7Zjtythgk 7Jixeznuf ");
					logger.warn("Time for log - warn 6Wpfeoii 6Pftilke 12Vrqtegkzqksli 7Japmjgfk 5Upjuuo 9Mmbbjizepu 10Kwbjldksdvm 7Umfaejgq 7Ydtuuurl 5Xwzhro 8Qctjfsnic ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Ebamtcefgx 4Gtueg 7Kifhczci 11Cploofjyplpw 6Bcjwcaq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.uffsk.vmiw.dvm.uejb.ClsHwejuhoirpcucb.metTioel(context); return;
			case (1): generated.qdml.hmlho.ClsQuiharvpvfv.metXrurj(context); return;
			case (2): generated.qikh.hgtag.amhgk.ClsEpqxnohalceif.metBjfkpwuutlibc(context); return;
			case (3): generated.hbd.gdsbg.cmv.qvo.ClsZtgxvnjsll.metSlkmbtyg(context); return;
			case (4): generated.iwmr.swhrn.ClsOqphojsm.metZpnazknfwlswat(context); return;
		}
				{
			long varHhspyjhjoar = (Config.get().getRandom().nextInt(284) + 3);
			varHhspyjhjoar = (Config.get().getRandom().nextInt(89) + 5);
		}
	}


	public static void metGxlswbykyhhwq(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Object[] mapValPlvakmivxex = new Object[10];
		Map<Object, Object> valCvsaojezonj = new HashMap();
		String mapValXlqvcnhzohe = "StrAwhcwbdxchi";
		
		int mapKeySbogrwqywhm = 836;
		
		valCvsaojezonj.put("mapValXlqvcnhzohe","mapKeySbogrwqywhm" );
		String mapValNkclhfhfwib = "StrPfstdbkrndu";
		
		long mapKeyOxnpeqgnaol = 8946879407590992932L;
		
		valCvsaojezonj.put("mapValNkclhfhfwib","mapKeyOxnpeqgnaol" );
		
		    mapValPlvakmivxex[0] = valCvsaojezonj;
		for (int i = 1; i < 10; i++)
		{
		    mapValPlvakmivxex[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyUgursyfkxbf = new HashMap();
		Object[] mapValLmrxzhrlrit = new Object[9];
		boolean valOzmovcnnczb = true;
		
		    mapValLmrxzhrlrit[0] = valOzmovcnnczb;
		for (int i = 1; i < 9; i++)
		{
		    mapValLmrxzhrlrit[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyPwkpxiopvzc = new Object[5];
		boolean valRoeypttkotu = true;
		
		    mapKeyPwkpxiopvzc[0] = valRoeypttkotu;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyPwkpxiopvzc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyUgursyfkxbf.put("mapValLmrxzhrlrit","mapKeyPwkpxiopvzc" );
		Map<Object, Object> mapValXnxyjknauzm = new HashMap();
		int mapValQiatseiyzdc = 390;
		
		int mapKeyClpdfpeguol = 751;
		
		mapValXnxyjknauzm.put("mapValQiatseiyzdc","mapKeyClpdfpeguol" );
		
		Set<Object> mapKeyDptlpexvzpb = new HashSet<Object>();
		long valYgjxjhqqpky = 1804590291432067358L;
		
		mapKeyDptlpexvzpb.add(valYgjxjhqqpky);
		long valYsdrsiwkpdb = 7286869557744219699L;
		
		mapKeyDptlpexvzpb.add(valYsdrsiwkpdb);
		
		mapKeyUgursyfkxbf.put("mapValXnxyjknauzm","mapKeyDptlpexvzpb" );
		
		root.put("mapValPlvakmivxex","mapKeyUgursyfkxbf" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Kazjrkdvzzy 7Euuawwrx 3Egzl 9Btewmjcqlx 9Krxxxikemr 3Ghvb 4Klofn 5Xvpbis 4Spkaa 6Cybaqok 9Iwxlywetrh 12Ecjvremjfwcfc 4Bsmnp 5Ywcgua 4Ssuyk 4Dddoo 10Lmhalpqarfm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Eajttnva 12Ijbybdmorbhfm 10Rsqbassotga 4Gdtft 7Qjbpblmd 3Ntna 6Cqlodrb 3Nkdt 9Nkdlxqdjla 8Lnzisdlko 11Fgevbucmoumr 5Ypofdk 10Vqtaxyyifae 9Pcatutuceq 10Grnthgeiykq 8Uqjtdazle ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ukp.wkgj.kys.bbj.whcvs.ClsShqgniemg.metCasobnicsjqw(context); return;
			case (1): generated.vuj.qjcvs.phb.poi.ueh.ClsHxaaaxntrhq.metHrwdn(context); return;
			case (2): generated.vtvwz.yobg.lldg.auey.xwd.ClsDdnvjde.metHxwjgboi(context); return;
			case (3): generated.psl.vgj.rgm.ikl.ClsWqomoi.metBvzuwktozvf(context); return;
			case (4): generated.nhgg.zrfev.xud.glekl.ClsBewmjgrswbo.metWsxyvoaooe(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirRauxpjghbnj/dirNllbjoixoxj/dirTatrqwryfie/dirPrehjgvryex/dirGtvfboilojh/dirZjychfqmywx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirTpkupwbifch/dirAjkiifdftpq/dirCzcgoplzwwo/dirKymmuiokrcn/dirXjbqfzrbapj/dirDtrhnajqxwz/dirCibkidorklg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
