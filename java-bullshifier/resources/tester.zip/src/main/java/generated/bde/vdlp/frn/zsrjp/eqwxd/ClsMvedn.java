package generated.bde.vdlp.frn.zsrjp.eqwxd;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsMvedn
{
	 public static final int classId = 153;
	 static final Logger logger = LoggerFactory.getLogger(ClsMvedn.class);

	public static void metBrdejrtmmvqjyb(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valKnqzdrpeavq = new HashSet<Object>();
		Set<Object> valWedetuxcwnd = new HashSet<Object>();
		int valJrwdiltnsrx = 872;
		
		valWedetuxcwnd.add(valJrwdiltnsrx);
		String valImmqsmrwxwf = "StrZbfclelncvr";
		
		valWedetuxcwnd.add(valImmqsmrwxwf);
		
		valKnqzdrpeavq.add(valWedetuxcwnd);
		
		root.add(valKnqzdrpeavq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Gomadiovp 9Vddrdxxwbb 7Tqmsepmi 12Kuhaqwqxgcfcy 6Snifzbd 11Lfekqxvfvdyp 3Hahj 7Bfqyxjtp 9Vzgwtqwwki ");
					logger.info("Time for log - info 4Dbfng 10Ewjychjdajp 10Jsmdtndqgia 10Rhizfoffpcf 9Jfuwehwwka 9Oxyhwrzbtj 8Mbwutfbbn 10Eblhscfybqq 7Qfairryg 9Nwbbmswoml 6Ltkxlxv 7Vxmhrmzt 9Menryzsojd 11Hyqhybpteops 8Soixhttgd 8Yfpakhjrq 3Vafp 3Pjro 4Rgbma 10Qefnfbfxasj 10Ygcczhcahph 4Kdido 9Nudooemkee 7Zafeewnp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Nsfidsknxn 10Mhjtsjlovqp 8Qfmkmrbxj 6Toyigae 3Aacb 6Ysfzoxm 12Uxtssiqarblkf 4Axfed 5Yhwdbc 10Pxibgsbecte 8Tvzzcawhg 10Dabegwqxefn 3Ygzk 9Hysdqpjogo 3Deor 3Bjyk 4Jshja 11Xookxniidyzb 4Reivw 11Pjinmxzlistr 7Gdqlheem 7Evdztndz 10Ooeyyroiypz 7Uwwjeaqe 7Lfijjwsz 5Tizxcd 9Jyifdymwbk 12Npmvhfrzaxbmt ");
					logger.warn("Time for log - warn 7Zurmifrl 11Gnvnccvwkbzv 10Ckbputnfcsd 10Gvnyxzqepsx 10Yzwwsrvctyz 6Dsunfht 8Yalyvahcb 6Otrgsww 11Vfmnnyqcgeyz 5Wngrcs 5Egzwgc 5Vrupsi 12Xrvdyuxjeleap 3Brgy 8Khzfjfsov 10Xaduofzuaxl 8Rdpotxozg 9Dofrekocju 8Dqzfmmkou 11Peunbuamyksb 6Zqbupwd 6Qbkoojf 6Kgfwnxe 10Ukmwlblsaul 9Cstrbvqhld 7Xgzxdogg 3Ocpe 3Vudi 6Kwwxske 5Hqvqpc 6Rbdeeme ");
					logger.warn("Time for log - warn 10Qqseyxhbtfj 12Ktctdrnaviosl 9Yspqwbkpsh 9Xkgasvqedt 8Fkabidyce 10Kegvoqltgwe 8Ynduhtjcn 10Gonmaymikbu 12Wewumyinowhfs 5Sbjgmh 12Ydyevsdizlxbj 4Eedwu 11Fkagztskqryf 12Sbuijuwkjvral 5Bkpxtc 12Vijvafqnzszwd 5Snudks 12Zzrllaussdnow 9Dhsskiihav 9Pxaeonxaur ");
					logger.warn("Time for log - warn 6Mbvyxgt 6Yvblfhy 9Roljxkzlmx 9Incxipkavr 11Jrdgxluyttsm 8Rrvelyabj 5Jsukqx 8Cwbbxinqg 11Rqcaozfsmlhe 10Dmitvjvpjzl 3Gdgl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Feguuco 9Myoxxiqisc 6Nousamw 3Hkig 9Dpslcnangn 7Ixpvkqcl 10Mrcetdgotfy 7Qldnrcsb 9Fqelnnbgrg 12Vugwieeabyetq 6Lzvlraf 4Xdudb 5Gxsxnz 12Ybcawcfnwbtbp 5Zcdemr 7Cinphrci 6Ihjspre 7Ycoriofd 12Kxvfkyrsqnmow 10Ezjyrcvqpvt 6Wozyqdy 9Trqdytabnv 8Yrptzvnwb 7Maeakvko 10Qgdnpjzcudj 6Xsmzdrz 10Wntdqcxoqfx 6Llrtlum 11Rersvprfrbmp 7Lecflfil ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.usy.jqyb.aoxm.cmxc.tdb.ClsGdtxkhc.metOylpx(context); return;
			case (1): generated.uqvko.bvdt.pbjo.abize.rep.ClsVzpniirg.metZxjubfw(context); return;
			case (2): generated.ncau.ibhi.ttuvu.ClsHlbobsu.metTahxaryiutr(context); return;
			case (3): generated.vqli.xqs.ist.rcg.ClsUlfrrjkk.metUracnapyxnrd(context); return;
			case (4): generated.psl.vgj.rgm.ikl.ClsWqomoi.metKrbftwlk(context); return;
		}
				{
			int loopIndex22775 = 0;
			for (loopIndex22775 = 0; loopIndex22775 < 2740; loopIndex22775++)
			{
				try
				{
					Integer.parseInt("numElyrfmhjchu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((9338) + (loopIndex22775) % 871710) == 0)
			{
				java.io.File file = new java.io.File("/dirCwypevevkuh/dirKmuowbzdtft");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
