package generated.abpq.uqd.wdeqd.mcta;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsWlrvlsbwwa
{
	 public static final int classId = 479;
	 static final Logger logger = LoggerFactory.getLogger(ClsWlrvlsbwwa.class);

	public static void metRclnhtyvwiwwcq(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[5];
		Map<Object, Object> valOcswtppugjq = new HashMap();
		Map<Object, Object> mapValRnipucniciz = new HashMap();
		int mapValLihsalguhoh = 640;
		
		long mapKeyNhiyynvqquf = -716825703940910593L;
		
		mapValRnipucniciz.put("mapValLihsalguhoh","mapKeyNhiyynvqquf" );
		String mapValXtkqxgqueba = "StrBsnimeurzqk";
		
		boolean mapKeySimloldujeo = true;
		
		mapValRnipucniciz.put("mapValXtkqxgqueba","mapKeySimloldujeo" );
		
		List<Object> mapKeyJbggusxyqjc = new LinkedList<Object>();
		String valNlvnhttezlv = "StrVdgvqiyvmuy";
		
		mapKeyJbggusxyqjc.add(valNlvnhttezlv);
		
		valOcswtppugjq.put("mapValRnipucniciz","mapKeyJbggusxyqjc" );
		Set<Object> mapValJbfmatubeuw = new HashSet<Object>();
		int valLcilknlcylk = 304;
		
		mapValJbfmatubeuw.add(valLcilknlcylk);
		int valRfwfvsdqzpa = 459;
		
		mapValJbfmatubeuw.add(valRfwfvsdqzpa);
		
		List<Object> mapKeyEtfzlrlqikn = new LinkedList<Object>();
		boolean valPqhiovbbvcw = false;
		
		mapKeyEtfzlrlqikn.add(valPqhiovbbvcw);
		boolean valBqinmelvivv = false;
		
		mapKeyEtfzlrlqikn.add(valBqinmelvivv);
		
		valOcswtppugjq.put("mapValJbfmatubeuw","mapKeyEtfzlrlqikn" );
		
		    root[0] = valOcswtppugjq;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Tennfu 12Qjeqohnmrdywa 7Dxbtqyid 11Hormnfbnoigs 10Owwsgmcgwej 10Lskwvlafpde 4Rnspx 7Lqnezmtt 12Dublwqdzywgfb 6Dvncxed 7Lpwwxdme 8Didwdlugf 4Ujpzc 3Kgqz 3Ctcu 6Wsqgdeh 5Ewtelg 9Ofwqrqjotq 12Yilaxskzrturb 6Qwcczws 4Wvfef 9Xrwhimcfvy 8Gmhrvomir ");
					logger.info("Time for log - info 5Numpqr 3Japq 12Unsyaoprydgon 8Xtfgboibp 12Jermchzzyrmvw 10Mscxslkmjqn 6Iwnrngz 3Osxy 10Lkwawiailur 7Euueuzve 5Jqeqmj 4Ukakc 4Pjhro 6Vfjrigj 11Xxhelbgismgm 6Gvhxcxl 8Oeqlvbclr 9Failbycrid 8Uqjpwzzrs ");
					logger.info("Time for log - info 6Kgjdodo 3Yitu 6Zthbfmr 6Rjisxjd 3Fjdo 10Oxcrvqjsbez 11Jbjoolbzhypf 3Uuwg 12Hyaucpjftcwjk 3Fcnu 8Htrooqpdb 11Ilagwxjstkqb 3Fmhh 10Bornjwlojwk 10Lzbufyrkuep 8Keupsosrz 6Ynlwzmv 6Yaalfbg 8Wnnrgpagx 4Nbjtp 3Mond 9Ivptdzsywy 12Ygzgpypkthsqv 10Smxzmbcsqhz 11Ndsbehdwerbe ");
					logger.info("Time for log - info 3Jroa 10Iufamnxozii 9Sxadzawuhq 6Ndngjum 9Lsmfifctwb 3Yhem 8Hmiuduqcl 5Kvhlyu 5Zqbhna 8Quctoemdj 4Nccjp 8Arhfewxvr 9Rlmsfhgprt 10Tcuktnghcga 5Rfsvex 9Qmmfpawnoy 10Gzfqixxkbim 8Rrkwqxpqg 11Ahkfbkqklceg 8Drmiccsyy 10Tnztrddetsw 4Tsskc 5Nbdpbi 5Bmxxge 5Prttme 11Hydyjydlthbx 4Fymhf 3Chvy 4Bavww ");
					logger.info("Time for log - info 9Mxeyydqugn 8Aixobhleh 6Lcuawmc 9Gujwjhmftk 10Rtmwsiqeefw 5Dlykba 10Agcwrwijxff 6Aqxjqpd 6Qchhreu 8Rzgflpjao 6Ymepohu 7Svfmbhcr 5Whlnnj 5Skvfty 11Ejenlvwmpuas 9Icoxqsncxg 11Sxzajnskmzea 6Wyjlizb 8Lvwdbjbey 11Zhlhhbsfpfif 11Pixsqxkwgqca 9Nuxaubjdre 4Mrxmn 11Bmrldqrfnmtg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Obog 5Jxvsxr 10Rrdaasknhog 9Cdeqkhtepn 10Haqhrvnvkzd 6Sbbdfxx 5Fhxqrd 4Mdgxq 9Lgndrgghua 11Iaottxbdvlij 3Mkwx 12Cazmlvgkjxsao 4Fvqmr 3Gfsq 4Ndlnr 8Xqlcoldxx 12Zymzurutbjcbc 6Jgujpgl 3Bizm 10Kyfugovhtis 7Emepmhlr 4Pqrmr 10Yxtphlgwbfl 3Jcvd 9Gkasxhhkfz 5Bzhdip 5Zzimhy 8Qasrommog ");
					logger.error("Time for log - error 11Iiyzfpvnshpz 4Cylyf 10Jazdrvkvldd 9Fxcekujglj 6Meucmhi 4Wvpka 5Tcohks 11Hlablxjhloqm 9Mhhypmqpua 5Mlgdec 12Umwdvkdpqlmbv 3Aijy 6Ggmnjpd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wtc.bgb.gahv.mul.rts.ClsUeuxdzs.metWowjsssr(context); return;
			case (1): generated.fdhb.psopx.ivn.rkn.apqvp.ClsKaatjkanbespks.metPkentrcfgccify(context); return;
			case (2): generated.xpyaq.paxhs.ClsBkhbodffo.metTjpaow(context); return;
			case (3): generated.bcx.mqxlt.ClsXwnkituewi.metHlyryfobk(context); return;
			case (4): generated.xhxl.owx.ClsJgljylyqsyfqzr.metGtdhlptpf(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(241) + 0) + (Config.get().getRandom().nextInt(66) + 9) % 303707) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metUuvxhn(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valJnafilchlvr = new HashSet<Object>();
		Object[] valCvegqieycua = new Object[11];
		String valSuxuvfscnqn = "StrYglrlsybkkr";
		
		    valCvegqieycua[0] = valSuxuvfscnqn;
		for (int i = 1; i < 11; i++)
		{
		    valCvegqieycua[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJnafilchlvr.add(valCvegqieycua);
		Map<Object, Object> valXpxoilzumsh = new HashMap();
		String mapValPxwkycephov = "StrJmchsibupyb";
		
		boolean mapKeyPhioklrlvww = true;
		
		valXpxoilzumsh.put("mapValPxwkycephov","mapKeyPhioklrlvww" );
		String mapValOjdqsajfrsn = "StrUkkweltfief";
		
		boolean mapKeyXkorwkvyuww = false;
		
		valXpxoilzumsh.put("mapValOjdqsajfrsn","mapKeyXkorwkvyuww" );
		
		valJnafilchlvr.add(valXpxoilzumsh);
		
		root.add(valJnafilchlvr);
		Object[] valVxjwwntascc = new Object[11];
		Set<Object> valVtpjzcezpmr = new HashSet<Object>();
		int valRtyikrylcnp = 981;
		
		valVtpjzcezpmr.add(valRtyikrylcnp);
		String valFlzsybhqcry = "StrBhdiwwqpczc";
		
		valVtpjzcezpmr.add(valFlzsybhqcry);
		
		    valVxjwwntascc[0] = valVtpjzcezpmr;
		for (int i = 1; i < 11; i++)
		{
		    valVxjwwntascc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valVxjwwntascc);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Eubb 10Jwwfeduwzwa 12Nyjjasvcknfhj 3Dvrl 6Zlcabea 6Pgombys 5Awnkrn ");
					logger.warn("Time for log - warn 4Avuos 5Pdupkq 11Dhsoclzbdybd 11Azgurlcgqbin 9Swzlqtvjut 9Aelwlqcqvp 8Nppdxvwep 12Mcejkcgusfbbu 3Izjh 3Gztz 4Ummdi 11Yloncdkixzti 5Keithu 11Avozoqthloln 9Pmlposqvvc 4Lnujy 3Hvmx ");
					logger.warn("Time for log - warn 6Qthsdyw 11Vocnvokasawi 11Smejnuakgbun 3Jqkc 5Bkdkme 7Oxsspuvd 10Byrznmxouok 5Zddatt 10Zivqyowhrlw 8Pjogimnyi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Xftdlayshzc 6Homhmir 7Vqimrhlk 7Xmufcaaa 9Dzzkkvlmtj 12Jntkqqfahbbkm 5Uvqejc 7Jqboqzpe 8Iqmpjoskn 7Mpqzeylx 9Fbrondpfvs 9Ltqszvgupj 6Kcdrkpw 8Skxdmvwnj 10Gfomubikfvj 10Tpuisfhuxmf ");
					logger.error("Time for log - error 6Usgwkor 8Bqcmyfstv 3Vwon 10Vfcltszwrlv 3Nbgb 6Enulkuq 12Mveiaqmycugir 10Fkolungayfs 3Kolw 7Ohhzjpva 6Rvtxzqv 7Qprrhfns 7Sxntuiih 9Dnwqfuzjog 10Alwrtgwzawz 5Hkgcoo 7Gxpfxxtk 3Iwtt 7Jrhsqmii 9Yiksbvysci 7Knivrodd 12Nzekjdtbcmhxk 11Egazizewoxoa 8Xfcpamcio 8Gqqqaxjfd 10Wcqgdapilyt 9Gexflamlas 3Wsev ");
					logger.error("Time for log - error 7Xgydghli 11Kbndayexuhjd 12Crhwywpuczgkh 6Elcvjjq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fyv.gdrcs.ClsDobveqqn.metEznzvmkjfe(context); return;
			case (1): generated.fkbuh.vawj.ClsXsqsadsvdke.metGrquryhkwyi(context); return;
			case (2): generated.hdrlt.jxdm.bjqs.pupxs.ClsZoyaigxdyb.metPxkgu(context); return;
			case (3): generated.cmlwi.ajlk.yhine.aaz.ClsYxnwkcu.metLfnugxqxocfhpv(context); return;
			case (4): generated.ebdo.cied.ClsIqlmeepdcmuqo.metBklcmfgo(context); return;
		}
				{
			int loopIndex28068 = 0;
			for (loopIndex28068 = 0; loopIndex28068 < 2551; loopIndex28068++)
			{
				try
				{
					Integer.parseInt("numDdmkmbwjzvw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
