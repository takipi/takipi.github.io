package generated.zisqx.ukvca.wbokm;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsZibjqxzov
{
	 public static final int classId = 78;
	 static final Logger logger = LoggerFactory.getLogger(ClsZibjqxzov.class);

	public static void metHqfpnzk(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[8];
		Map<Object, Object> valXymwdhjnszg = new HashMap();
		List<Object> mapValLwseomonvsa = new LinkedList<Object>();
		int valTugtcinihwl = 338;
		
		mapValLwseomonvsa.add(valTugtcinihwl);
		long valAzgohqlxpsb = -6663065927324859303L;
		
		mapValLwseomonvsa.add(valAzgohqlxpsb);
		
		Map<Object, Object> mapKeyTbjrauuaugd = new HashMap();
		String mapValPnivlusayql = "StrWsdxmravskg";
		
		boolean mapKeyAbzirpkatvl = false;
		
		mapKeyTbjrauuaugd.put("mapValPnivlusayql","mapKeyAbzirpkatvl" );
		boolean mapValFirtlyzyswi = false;
		
		boolean mapKeyDsaqhlkexlp = false;
		
		mapKeyTbjrauuaugd.put("mapValFirtlyzyswi","mapKeyDsaqhlkexlp" );
		
		valXymwdhjnszg.put("mapValLwseomonvsa","mapKeyTbjrauuaugd" );
		Map<Object, Object> mapValLhrpalbjdxa = new HashMap();
		long mapValYsbfrcizuab = 5656724645829028442L;
		
		int mapKeyZhzswdhauwj = 549;
		
		mapValLhrpalbjdxa.put("mapValYsbfrcizuab","mapKeyZhzswdhauwj" );
		
		Set<Object> mapKeyNqwajsyilxz = new HashSet<Object>();
		long valErymvbzsrdp = 8711041133475064925L;
		
		mapKeyNqwajsyilxz.add(valErymvbzsrdp);
		int valEnisxbmivgf = 744;
		
		mapKeyNqwajsyilxz.add(valEnisxbmivgf);
		
		valXymwdhjnszg.put("mapValLhrpalbjdxa","mapKeyNqwajsyilxz" );
		
		    root[0] = valXymwdhjnszg;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Wzpatxrdqksq 9Gcprzfbrfp 12Occyhtleuupop 6Nxamzxx 10Rtqwhjvhxsr 11Bxrukyviskvh 11Wkatqjfebcxq 12Meekelravcyff 9Rdclmuxbxm 5Invlti 3Noib 11Htdgvbjpmvlo 4Zzcso 4Sjimq 8Qipaobnbv 12Omxamgtyztyog 3Psxe 7Aenowapg 8Ukykkxjsw 4Bcgix 7Fbwrajne 3Nuza 3Rdvb ");
					logger.info("Time for log - info 9Muufddzexb 4Fauox 4Urqsp 10Kgidmrfzawk 11Iykwhlzozgvz 11Tjgckbhmuprm 5Ltpjey 7Wnlhqtim 8Khvaiedxx 9Kzrkykuryh 3Bpkd 3Zwog 8Kdeezudst 4Yjxtq 6Mfrlbte 3Zhbx 12Fxcgdvpnbwvhs 6Eubqdlh 12Ctrnywxouwict 4Pshbs 3Uomb 12Dfpwsbpmzlkzp 6Dtgpjey 11Dmmqczpymqqj 11Ckhblahmtfeu 10Cclqgjtmqhf 7Mhjccnjv 8Gkiarlrre ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Tugbq 11Phjryeqzhpjf 9Ooppftwtyz 7Edgryjig 12Cvvqcjbnxutgo 6Objtiwo 8Zwdlqhopy 7Eitmmyed 3Sdti 6Czhvevb 8Pyjahwzpb 10Vxfnfwgxbja 3Rexz 6Gfkxgll 11Wknxqmtzntkh 8Qxonbxwqs 6Fsbgvav 4Nwrft 11Bbabwzswvjgp 11Pwgsudqooawg 5Kdrosk 9Xaytlpikvh 10Wdjohwrjbad ");
					logger.warn("Time for log - warn 6Ksjdpoa 8Mcpzsmayk 7Fzpsbjqt 4Zfdrm 10Eytuminjhsl 10Fvfbpnnzikw 11Dqwrbkavbazm 7Mebluazj 10Yvpwjkgjxii 4Jcdsf 7Qjiluejj 12Gvijdjqrgnetr 5Yzyjhs 12Dhulelnjjtjze 8Hpuqrpvvl 5Czburv 3Hdyt 7Qtvdmjkj 3Lnlb 6Yisecah 8Donztdskl 5Ybmoej 12Jkflmvbdsikyu 10Tugkiirvvba 12Bmplihdztyekg 4Pjyno 3Koav 5Bfxblu ");
					logger.warn("Time for log - warn 12Pxkhbvjgnoojl 11Gxezsotpzeyb 8Cjhramtya 10Xinhatrwefp 4Vtvyc 9Rfulnsvhds 7Uelghbme 4Kaltd 3Nlbj 4Jkgny 11Zzvoisaojuaq 5Vqvrkt 4Prinf 6Lrfzoen 7Ahgzgvkq 6Zojrhys 10Vmiubeipyvw 6Lgsdscj 5Lrijvs 7Snuoatmn 6Pjpngow 4Zleik ");
					logger.warn("Time for log - warn 8Njtloouax 8Ylclqksbz 10Fixfjhnzhuh 8Nydyvgvhk 12Dzkmdwniychoa 10Wrdjrlyhbiy 9Tfwgnmwolt 5Paghwq 4Uewkl 3Uudb 11Skoagollopeb 3Zkeq 8Hkjmruesi 5Ujbzzo 9Jzzdnjfjuo 12Qutkkoygaflui 4Tsomh 12Bdhntaehvdqht 12Hfierocmpssaw 12Gpiebsqyxgqsr 7Encglnti 5Uewvbp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Urldwmcb 7Pyyzssfc 5Bkgqha 9Vzuusthcrs 10Vmojftzdczl 5Kypztx 10Iqyzsduohoe 5Rrfqrl 8Inltzpsfw 10Dvkkvvuyuer 12Ifluhvdxmqkrt 4Gknyz ");
					logger.error("Time for log - error 10Vcigphwqzim 8Hxbitpvfo 8Gdorwkiei 7Szsvuyvy 12Kvumjxpieqqda 9Jxuvzietql 11Cbbezvrdbcyn 6Exjivbu 10Sgfwswmdrpt 7Liucxzxg 3Zrox 11Sedprjlicoii 8Gsqxbrirs 3Dqxh 6Tudhuzx 11Caqmlfpjyxhi 8Matgaxbjc 12Usynkedhgbyda 5Trejot 7Twdztmjw 10Wcwtfhpetpe 3Wvrz 9Pjslaqyoed 11Duqcnnrhkdrd 6Uzggsks ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ueynf.ovqsn.bjpnz.bhq.ClsPrqva.metWqdhwnlfsbba(context); return;
			case (1): generated.qivmb.wlyy.vhwlw.ClsJhewvjqlcuh.metWnbqdsuonigbug(context); return;
			case (2): generated.igif.laylf.mnwo.ClsOgradyyhp.metNyxohzpplk(context); return;
			case (3): generated.wkonu.vce.nspm.ClsXupklxzgrjs.metGhpwtlnnq(context); return;
			case (4): generated.mtq.flhse.ygibh.yfs.ClsSzzuamch.metIuxgxgafdnqnhh(context); return;
		}
				{
			int loopIndex21406 = 0;
			for (loopIndex21406 = 0; loopIndex21406 < 3706; loopIndex21406++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
