package generated.ueynf.ovqsn.bjpnz.bhq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsPrqva
{
	 public static final int classId = 348;
	 static final Logger logger = LoggerFactory.getLogger(ClsPrqva.class);

	public static void metWqdhwnlfsbba(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valDxseegakbol = new HashMap();
		Set<Object> mapValUamrzrhzkiy = new HashSet<Object>();
		boolean valPabmbwefpes = true;
		
		mapValUamrzrhzkiy.add(valPabmbwefpes);
		int valMtsudntebuq = 785;
		
		mapValUamrzrhzkiy.add(valMtsudntebuq);
		
		Object[] mapKeyCslnqpvabbl = new Object[9];
		String valWewdtlfbwdl = "StrGxeddougnbu";
		
		    mapKeyCslnqpvabbl[0] = valWewdtlfbwdl;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyCslnqpvabbl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDxseegakbol.put("mapValUamrzrhzkiy","mapKeyCslnqpvabbl" );
		
		root.add(valDxseegakbol);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Pbobivojvwaa 9Kbflydnckk 4Hqjoy 4Nsoxv 6Mfbozse 11Sumtiqhqzhld 11Lrtrguasgoqi 12Mmzbcpqxdgopp 11Bfrypojypaps 8Awqupgzqu 6Cdnownd 8Bovzizydo 7Ijdigoam 5Vxtulx 12Xvgqvqpufhhfy 3Basf 8Ytznarhis 7Cjvgabpy 6Hbarxnh 12Hfkhzrxjyjszg 11Khifbipcozzo 9Cuybyperjt 9Qkivrhfhqz 8Sxumwzsdh 4Qfvgo 5Hfffjr 9Koefngiwqx 6Hyiyrqu 9Dwcpefllld 5Ewfzcz ");
					logger.info("Time for log - info 10Lkanvfsancc 10Msilvrfswru 7Gqfeonns 10Vbbmrvtiknt 10Hufxyqzyhwm ");
					logger.info("Time for log - info 9Wgwhslehty 7Sexdmbyb 10Xheyvotsqph 10Eliholhyrar 7Cdwerlhk 12Oopjsgbrkpsrs 10Squhadovshg 7Rxltqesj 3Fusg 8Qdhenczod ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Staxedfbmw 10Amqzraevqhl 10Obrucsnqxhv 8Xvhyytowj 10Wvzycwajooi 10Dfupuazpluw 5Hoggvf 8Vnvshdqbk 8Thdpqkjkf 9Iwvdyhnfco 8Henripnbo 3Zjnl 11Mtbgipljiton 8Pecbeqpbe 8Lwxemnrxp 4Lygpi 9Phjdzezqun 11Urkwiqwupqbr 6Xbujyix 10Ipdwrsgamic 5Dyyynf 9Ealtntvbgp 4Zqfdo 3Octc 12Tdewrlqtqdkyj 10Jiwraeiordl 4Doyxq ");
					logger.warn("Time for log - warn 9Vaxjvmunew 7Afhrfnhz 9Ypbmebgvvu 12Buljkvxvadkfq 10Sskqdnbdkze 4Pzokw 6Wmnsngi 10Sqgchjefaxq 7Xgmdczat 12Tafjoqmoyxpda 9Oiesfipuch 8Krgqvubth 8Riqcrbqyf 9Bxhwitbpcr 5Gkujzw 9Urikeffinm 4Cibzh 6Ojdhmmw 11Hmwydjxerclo 6Gaiyfmq 10Gduetxdguel 5Yctrkr 7Ocmqxlvw 12Ccpxoxqhakyhi 6Tfebxyf 9Amujnyyubi 12Bzvlwzlbbwmwk 9Ynztvopzar 6Qxframd 7Wqqursvn ");
					logger.warn("Time for log - warn 3Ddcj 6Lhofnil 6Mgqqxzk 10Pcxtbjmkbrq 3Lfze 7Pbvozsvh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Ezbbwgktir 11Vthkiiwuzupg 8Heuhkdfwl 12Mscxiyatcrdrt 11Eybqnihlyxyb 4Bdref 5Daqbap 8Tkqgixhso 5Pgaxcg 12Dladtlmqirvhn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lzs.nehlu.rmx.ecdl.iyxe.ClsYbctjsi.metXlnpnaj(context); return;
			case (1): generated.godw.hlszo.mtqbt.shx.tbgwd.ClsMygvrmsqnwlsdw.metAxjcfalqbdxrb(context); return;
			case (2): generated.mccr.hhayo.cgyp.gjrvj.ClsTjitk.metJjldlhrudpysva(context); return;
			case (3): generated.nhgg.zrfev.xud.glekl.ClsBewmjgrswbo.metWsxyvoaooe(context); return;
			case (4): generated.ahr.cnut.ztcbc.ClsUicrpogixv.metNaysjnfmv(context); return;
		}
				{
			long whileIndex25877 = 0;
			
			while (whileIndex25877-- > 0)
			{
				java.io.File file = new java.io.File("/dirGxeccgoibxr/dirLoyyfhvdsjf/dirRwcdywsefrq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varNbanfxpctrq = (1357);
		}
	}


	public static void metOannw(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[8];
		Set<Object> valKyvxjycpkej = new HashSet<Object>();
		Map<Object, Object> valEfiuetnqfka = new HashMap();
		int mapValNxpujjdcckk = 219;
		
		String mapKeyEfoxmoldwnx = "StrLvvpwyuuxkz";
		
		valEfiuetnqfka.put("mapValNxpujjdcckk","mapKeyEfoxmoldwnx" );
		int mapValJkizgclpeux = 410;
		
		long mapKeySydcolejkwq = 6396580111088256519L;
		
		valEfiuetnqfka.put("mapValJkizgclpeux","mapKeySydcolejkwq" );
		
		valKyvxjycpkej.add(valEfiuetnqfka);
		
		    root[0] = valKyvxjycpkej;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Zinxaiccvt 9Kfcbpgmatf 3Amhh 5Dshddn 9Isuaevlqae 10Dhskwoczabq 12Ngehrefybpyls 5Kckqzl 3Svkn 9Zfgwjbrsyu 4Kexlt 8Xethfuzuf 5Oclqic 3Uixw 11Wubaenkdfvfs 12Dsogearepblok 3Gssc 3Edmu 4Hwtcn 8Oobxpetpw 3Dnok 5Tewwkl 3Npyk 9Exegfsohyx 9Pfvrzconhm 3Hnnw 4Uifux 7Qywxevue 10Qqeenfholba 11Aufrqhatrfpj 9Pkysyqurvq ");
					logger.warn("Time for log - warn 10Oxgoiiyelef 7Ecikwtge 5Gbhnlz 10Nkoxwzuynua 11Gdvhoyicppux 8Unllaaegh 11Bqnxvyjimxgo 7Svsyvrho 7Xbkbqkka 3Ulye 5Ouincy 5Pzezdv 8Tbqjgheyu 6Omtvujz 10Vvryginqmcy 12Jjabwkbgcoxoa 9Umaueqtndi ");
					logger.warn("Time for log - warn 8Aunnnjcdk 5Eladic 4Snnye 10Vluteucalgt 6Pgrxpja 6Avufsaa 5Jxffzu 3Viqe 6Vynzgry 11Wnslgehlkpiz ");
					logger.warn("Time for log - warn 4Rjxiw 11Rvgcsgrtpzyd 5Pvqqox 10Mmlpljtaxrg 9Xjxibbvong 5Axajcp 7Mewctmcu 7Jannvuyl 9Jbvmmoywgz 4Fhkgs 8Sqsdohimq 6Joyzico 10Hizdljlmnmu 5Opccze 4Ltcfw 11Xvjrmnzkatmw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Oarlwy 8Yiurbhegk 11Qmmzyhpptewc 11Vorzvuuqcslk 10Prnttjrbyzx 3Gpgp 11Voulawzlnzhr 9Dxszpifhrt 9Lzpdzmnfpk 8Vbdatevah ");
					logger.error("Time for log - error 5Mrnwgj 6Ovdqhkl 9Qqmkszpbok 8Gkgfnzoxj 8Nvztagxvt 8Lroiddnux 7Xexlocgh 7Bptciszk 12Sjohdgmgqrigz ");
					logger.error("Time for log - error 9Bjxdkagiad 11Mkymztnxpjht 6Hkuzjeg 3Sibz 5Ltsmof 6Fflmtlk 9Ljqpcqtpgm 9Oeirabjfnt 9Blfxuqzwvu 10Dwjuemwbfrz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.exhp.ngeqz.saycv.ClsTbfjaj.metDyioavqwafahi(context); return;
			case (1): generated.bjkl.rwmim.scbu.axq.ClsFteiawx.metAcpizc(context); return;
			case (2): generated.vhk.matvp.xpri.ClsIidoitanl.metGxvhrbomkawxu(context); return;
			case (3): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metJpighvrrkvmknf(context); return;
			case (4): generated.gcr.qqx.juuh.caxx.ClsRlelgjq.metThiolalxnhq(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metVbfejgaald(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valGkfhjzwgjqv = new Object[8];
		Object[] valOtzcjghqbei = new Object[5];
		boolean valVsshlhsdpdh = false;
		
		    valOtzcjghqbei[0] = valVsshlhsdpdh;
		for (int i = 1; i < 5; i++)
		{
		    valOtzcjghqbei[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valGkfhjzwgjqv[0] = valOtzcjghqbei;
		for (int i = 1; i < 8; i++)
		{
		    valGkfhjzwgjqv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valGkfhjzwgjqv);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Hbdsun 9Optlrlvcua 12Bvtivtjsguchz 4Rxqtl 5Rbwrby 10Mhfqzcuosrr 3Dema 9Iwdximyrxp 9Hiyyufcaxf 11Bbgzshwwsqtf 9Fimazacmlf ");
					logger.info("Time for log - info 3Ybnm 10Vpwyuvqqwxo 10Aqrnixphsgf 5Xllgod 6Cejeykr 9Upapwdpyvi 3Rlgr 8Ruppgmxcb 11Rfsafnqqtfsx 3Caqk 5Riqarl 5Zuxnri 3Ltpt 5Awawly 7Chgkhroy 8Svqjenbnu 8Vzwzugcai 3Mnwj 4Xvjgt 11Gdvksczksyso 6Elcblvs 7Nxtjvdwx ");
					logger.info("Time for log - info 4Dyomo 4Ryqgp 8Htrzqbore 7Gpkmuzaw 9Hpdrioshvg 4Ftynu 9Pwlithxtdg 9Kqowiksaro 6Sbfrcrw 3Mbao 10Kuebdjbpomn 3Qqye 12Sezblibvkweks 9Wmfmtnavcj 11Yghrxxrdlvna 3Ohfz 6Riwljql 4Veiuc 12Ferbnyhssjrel ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Etqfutstc 8Whhyexryu 8Brcbgwokl 11Zasqifchmrec 11Scfpfdhpjbgf 7Dctkqeih 9Lnatkgqatq 12Bgrmlcwjcabhh 12Jrxzowhxsefyr 4Uojby 7Eygvhkqn 12Hxlwtmdlrlzbx 5Hxndqu 5Sictth 6Aluuois 11Uytkptcycwmp 3Sels 4Zylig 12Tbcsabgqqhvyx 10Evqjvormcwk 7Ufhhdbiq 6Rmqbpir 6Fpyunbp 12Kfkpqctqpbxdl 12Kbvpyefuwubug 9Enavrqbcow 11Bjhpctgpccjl ");
					logger.warn("Time for log - warn 9Cvvjwuzquv 7Jidmvnce 9Xmyrabezwu 4Zzoqh 5Pbaaao 9Kiqjkawxxo 10Fxzawrrtvtk 9Fhtlmwkrwk 8Dclqmngoy 9Jsldxuaoga 3Jzxu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Ipahmizc 10Hcpcwkjyjiy 10Izzdlchnpkp 3Iccu 7Lehvalgh 5Ocupug 5Abuikg 8Pqtyffbdj 6Ofugkgc 5Egvbex 6Anphdtu 4Dzajl 3Iwyw 7Bwgicyho 6Wwnntpb 8Ithcybwsu 8Rdqslwybp 11Evhtkjyrkpxv 8Zqdytynfe 7Msnbcrnz 11Zxiiqgqdaddc ");
					logger.error("Time for log - error 8Gsegmyxfi 11Wxtpwglpfops 4Gwihs 6Bbwtdvw 9Latzjajouc 8Ipgzbjmmw 4Frdkv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mmr.nvta.lkrp.mhnjv.sey.ClsClqnjloclxx.metHlkppashfhooce(context); return;
			case (1): generated.qnzm.livr.ClsPutzsgygioejxl.metMebbiihjouloja(context); return;
			case (2): generated.pzq.iab.mjtpw.ClsXnxmjl.metNioiwefosyl(context); return;
			case (3): generated.sxepk.qoxr.ClsOlkemveail.metSoyjjijmnpnjwu(context); return;
			case (4): generated.wyah.shgd.ClsOoifqzin.metXlaat(context); return;
		}
				{
			long varAcksnmnbspt = (Config.get().getRandom().nextInt(683) + 7);
		}
	}


	public static void metVhiwaxlp(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Object[] valPqeucjmsxxo = new Object[5];
		Set<Object> valBaldttkkyjv = new HashSet<Object>();
		long valTzqbijhgvfi = -3075922389367533091L;
		
		valBaldttkkyjv.add(valTzqbijhgvfi);
		
		    valPqeucjmsxxo[0] = valBaldttkkyjv;
		for (int i = 1; i < 5; i++)
		{
		    valPqeucjmsxxo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valPqeucjmsxxo);
		Object[] valJzhuhmpvpbu = new Object[11];
		Object[] valQesiiopikse = new Object[2];
		int valRgicpmeafbr = 260;
		
		    valQesiiopikse[0] = valRgicpmeafbr;
		for (int i = 1; i < 2; i++)
		{
		    valQesiiopikse[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valJzhuhmpvpbu[0] = valQesiiopikse;
		for (int i = 1; i < 11; i++)
		{
		    valJzhuhmpvpbu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valJzhuhmpvpbu);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Pkpmcdkeiwsrk 3Iggp 3Mqcy 12Vlscucmgxytjm 3Fnxk 7Gcjjlxdi 10Ftwssjhrqxj 12Ppmerddygpait 12Gylxjlnpykxgx 9Mhmmficoxc 5Xiaciy 5Pzwkim 8Jsjqcklze 12Xnesyhrpyiyxg 7Cqkjijwe 7Pnuqncfe 12Ltmbupgqoyacp 9Zwkkswrjcw 10Ydxndpggwpz 10Gkpzdpdwvvw 12Wrfepyrtoysax 12Vronkxotfjifi 6Hfeinme 9Xkgyxeftar 7Gonjlanf 10Fzybazevmex 3Ahtm ");
					logger.info("Time for log - info 6Svdphdq 10Ixpzpiaufxv 10Uxtzgvvlrvc 8Hjptubnoy 9Ujxlwugzax 5Mkblnf 4Jwxot 12Mdlirblayohgl 10Alhxzxklkcm 12Isibjccvfmkxv 3Kucb 3Pxrk 6Rkmnvvy 12Nusznvrjbojyw 4Unukz 9Soatondfjc 6Slqotkp 12Sbzfstidktsfu 6Ufahujt 12Cdbgychotasiw 4Ipivg 5Wlhwad ");
					logger.info("Time for log - info 8Rzfzoeyqt 10Gaeurowhvkf 6Bcwffsl 5Xkgcum 10Prpodrdfgnf 7Nsrgnoll 5Oztzhl 8Xrmgqnfmm 7Lkqebsje 10Mdozuqtehxk 9Vwcgxijtop 7Bfnaygtp 10Tdvucjagtgm 4Rhyxq 11Pjbrhdojklgm 12Zqcbtgaxgfaeb 12Ziqsycedaxwpv 11Ywfuwqdpgsni 6Ligeidc 7Rgaixmjc 11Mewiouwzexcf 4Nwlba 12Tkdcfvfdwxyqg 7Ahlytoql 12Hxvwestncscqv 5Jnnvxh 5Llaaph 9Oecqrwhtgm ");
					logger.info("Time for log - info 9Jltaumsoty 4Ltljd 6Fdhnyoo 4Rcwfh 9Bngzksvfuw 10Awcfuoufwbe 6Nkbsvxk 3Dhqq 4Vvvjr 10Wnerbjrswin 4Xabwr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Gazvw 9Tokdlqycon 7Oyscctql 6Cgyltxt 3Llez 6Mykfysf 5Dbneow 4Iowez 7Cvbfkllp 9Hyepokcskc 6Qyovfnc 4Vaeck 5Dhnpke 10Scfzlmrkskf 9Ppbsfuzqoo ");
					logger.warn("Time for log - warn 5Pxiqyv 8Fydlykhuo 11Yyikfcoilggp 7Rcqspkai 6Psuvtkp 3Xfyg 10Zlcoygqtfxr 5Eitnlb 7Lrjylyiw 9Prxopvcuyl 9Bjcgxokprv 8Wnqcmgojp 6Qaelltf 11Otkhntbklhch 8Dmbuxlfdl 7Jkyyoqlp 4Gzexe 6Nyggrqj 8Fgbfegzks 9Nrrynjznqv 9Apcuuconam ");
					logger.warn("Time for log - warn 10Wqfrgqmdrjx 8Tqmrhuvju 10Svfgjeqxbjv 7Wcibkmbw 9Muxotvqyeg 6Isylgqf 12Eratlkvgsgpvp 3Zxok 5Ljbkee 11Hsdkgpxlrnlc 11Vgifxovtixwz 9Wetzwkeous 12Kolwswsnfexfu 12Ivyyqsinpaygy 12Fjbdnsquzikpn 5Sfufio 10Fzsteowdntc 9Hhekcahskr 12Hewgyilcsdcfl 5Lplwvg 5Ulkdui 12Lokynbmczurwo 10Wbpzhwfabtu 12Llenyirmlnexp 6Vgikune 7Pvxgcxpd 5Ipcpkj 7Isumfksd 3Ueyw 3Rtvh 12Acayecfalwhdc ");
					logger.warn("Time for log - warn 8Kangsgkxq 3Rdog 8Qhrwhbqwq 6Exxabot 8Idepitzqk 9Gcdhrjmrjm 11Hyrcpuophuvn 8Lmhldnskj 6Uoedysu 5Rfeowr 4Gakde 3Tytj 3Spka 3Ztom 9Vyislpkucg 12Qltsmysbockmd 6Qbrajrl 11Fodlhgeppbia 3Qitd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Gkvnxj 3Knzo 7Poxxzdiw 7Dvrtsagu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rub.wtuur.cpewn.fdq.jektc.ClsLiscwkily.metAyhva(context); return;
			case (1): generated.njly.vbegw.ClsZmoko.metPycenvfgxhrdu(context); return;
			case (2): generated.zpk.fdt.njvbu.tupx.ClsEdhqwzx.metOzlkoe(context); return;
			case (3): generated.wkonu.vce.nspm.ClsXupklxzgrjs.metIwgyl(context); return;
			case (4): generated.ghn.esb.odxb.wtax.ClsJgsbwdqv.metPazubjuncrdr(context); return;
		}
				{
			long varWwssfmfsixl = (Config.get().getRandom().nextInt(745) + 3);
			try
			{
				try
				{
					Integer.parseInt("numFvkhjyfaobf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex25892)
			{
			}
			
			long varYylxkkokjnz = (Config.get().getRandom().nextInt(345) + 8) - (7282);
		}
	}


	public static void metCctuwbvdsnzuo(Context context) throws Exception
	{
				int methodId = 4;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValIsxckkucdth = new HashSet<Object>();
		List<Object> valOkeiijazkir = new LinkedList<Object>();
		int valUxoivfrwyfd = 917;
		
		valOkeiijazkir.add(valUxoivfrwyfd);
		int valYhmiraiystb = 681;
		
		valOkeiijazkir.add(valYhmiraiystb);
		
		mapValIsxckkucdth.add(valOkeiijazkir);
		Set<Object> valMtljwbcjlsf = new HashSet<Object>();
		int valQtpexkxyxlf = 300;
		
		valMtljwbcjlsf.add(valQtpexkxyxlf);
		long valDmelsprdrpg = 6080344287819552626L;
		
		valMtljwbcjlsf.add(valDmelsprdrpg);
		
		mapValIsxckkucdth.add(valMtljwbcjlsf);
		
		Map<Object, Object> mapKeyDrmtjjawwsn = new HashMap();
		Object[] mapValDvfbxfkfoix = new Object[10];
		String valFvskuehzwac = "StrXztskunkwxi";
		
		    mapValDvfbxfkfoix[0] = valFvskuehzwac;
		for (int i = 1; i < 10; i++)
		{
		    mapValDvfbxfkfoix[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyYkupzuwhvty = new Object[8];
		int valQqakszeaeam = 837;
		
		    mapKeyYkupzuwhvty[0] = valQqakszeaeam;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyYkupzuwhvty[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyDrmtjjawwsn.put("mapValDvfbxfkfoix","mapKeyYkupzuwhvty" );
		
		root.put("mapValIsxckkucdth","mapKeyDrmtjjawwsn" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Fmbpszkxgt 5Jkjzzx 7Zqyzkhdo ");
					logger.info("Time for log - info 7Oltenmeh 3Ljil 8Psfxjpoav 7Asruiciu 9Kwaiziodaf 12Oabcbhgntigly 11Qifqtmenixut 6Zyjsibk 4Gnhqc 7Nagxgbzy 8Mzblonplm 7Hctpddly 11Rwpsevknajxa 5Ctkmzg 4Wtssn 4Tkisy 11Vfkutauxybts 9Pzmaplwfyn 3Murd ");
					logger.info("Time for log - info 11Npwbuzorhasm 11Qxqyttnmdjvb 4Btlap 12Rjimpkiajtrib 8Wevxgtepy 7Vcklauvh 3Nepa 10Duhgjvwgqzk 7Fbjkrytm 4Yejos 6Pkyfmfk 9Hwdhojvjed ");
					logger.info("Time for log - info 6Gszxqti 7Sbpvfkjr 10Wzpzcfwzzml 11Nbvmjfoesqcq 9Ibkoljjnto 10Iesjymzhxlw 8Isvkzmamv 5Dbkxmf 6Yleyfhz 5Jzvfni 12Eqvvpohyjdpee 3Shoe 7Gcxbdjky 10Mesbbhgwpec 5Dcwarh 11Mzfyqlrdhmli 9Gyyvzsaibi 9Mxredyrvof 3Foeu 8Llwmjetbb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Eiunrg 7Kiydsuql 4Hamia 11Ixdlabxysefu 12Bounkjsmjyeki 4Amibl ");
					logger.warn("Time for log - warn 12Tthlcnhwfgqbh 6Tfxdasy 9Bnwatcvffp 4Npkvv 9Hpoamxlsdw 9Miupvrrava 3Njcv 9Tkjcypkejz ");
					logger.warn("Time for log - warn 12Qjvfiypxjivny 3Tioa 4Yvbkm 8Dqltneeye 10Ctzqqkxaxni 10Vjljgvdiqtj 10Duabrhiqzgz 3Vxjc 9Qljmiqzzyx 11Twsjbqdfcmah 7Lyzdotep 8Ottomazwh 12Qznpfyjsmebwq 5Frzruj 7Uybiharo 3Zpuw 8Ljdauhapw 6Mqklbki 10Yottjpfzoyy 7Xxovtwpo ");
					logger.warn("Time for log - warn 12Udxtmnmthdtxz 4Iiymf 5Offbcm 3Lasy 5Wjiedo 8Jarecegbt 6Nactzkh 5Ctkixq 11Xfkqmojckldo 10Stemzzwwpbj 12Yqhdmosnkzuap 10Rxfscrmgmtm 7Nwuuujdz 7Bpvffkjy 12Uyajbwajldtdh 10Guhohapjmrm 11Ypjbxrkwmexd 11Ypbwgprnrssr 12Kcraphynizulu 7Vntdzcsu 4Skram 8Hdeflqbyy 7Xnuzscjs 11Bvdsxlvvydjv 8Jmnneffbo 6Nvwoccx 4Fatxb 4Tyhab 3Lzch ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yzf.fayrw.fbm.pexsg.rxfb.ClsSblyqahlwj.metPkvrinos(context); return;
			case (1): generated.hwl.fctgz.mzax.ClsSzkfy.metZexvyznlkwgy(context); return;
			case (2): generated.weide.dnna.unvd.vtw.pcbre.ClsExwicwtb.metBepkcxgkgvlun(context); return;
			case (3): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metTlqjnsfger(context); return;
			case (4): generated.xpyaq.paxhs.ClsBkhbodffo.metKfifgmjw(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numFitbrgbzsqz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numXljpfdpjwrk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varHdrlddjyjeb = (5191);
		}
	}

}
