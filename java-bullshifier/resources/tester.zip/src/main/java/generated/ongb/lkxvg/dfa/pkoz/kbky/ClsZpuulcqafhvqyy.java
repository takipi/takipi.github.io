package generated.ongb.lkxvg.dfa.pkoz.kbky;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsZpuulcqafhvqyy
{
	 public static final int classId = 436;
	 static final Logger logger = LoggerFactory.getLogger(ClsZpuulcqafhvqyy.class);

	public static void metOzbahhdicun(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValBxyymhbvbbm = new Object[3];
		Map<Object, Object> valBgyjvlxfrqe = new HashMap();
		long mapValSbfryvqqyah = 5557686244875985614L;
		
		int mapKeyAtcavhagjea = 221;
		
		valBgyjvlxfrqe.put("mapValSbfryvqqyah","mapKeyAtcavhagjea" );
		long mapValLwjxhjwvbxk = -4127890878438611372L;
		
		String mapKeyIhkzirljmkp = "StrGkxyclosuey";
		
		valBgyjvlxfrqe.put("mapValLwjxhjwvbxk","mapKeyIhkzirljmkp" );
		
		    mapValBxyymhbvbbm[0] = valBgyjvlxfrqe;
		for (int i = 1; i < 3; i++)
		{
		    mapValBxyymhbvbbm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyLuthswxveqr = new LinkedList<Object>();
		Object[] valKdzlfzkoozk = new Object[11];
		int valKprermafdrk = 591;
		
		    valKdzlfzkoozk[0] = valKprermafdrk;
		for (int i = 1; i < 11; i++)
		{
		    valKdzlfzkoozk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyLuthswxveqr.add(valKdzlfzkoozk);
		
		root.put("mapValBxyymhbvbbm","mapKeyLuthswxveqr" );
		Set<Object> mapValSqduvfrrzdy = new HashSet<Object>();
		Object[] valTrbirhkbrcp = new Object[7];
		int valUrrjibklhyi = 191;
		
		    valTrbirhkbrcp[0] = valUrrjibklhyi;
		for (int i = 1; i < 7; i++)
		{
		    valTrbirhkbrcp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValSqduvfrrzdy.add(valTrbirhkbrcp);
		Object[] valPwyavdpyymh = new Object[3];
		int valQcyhoxikglc = 937;
		
		    valPwyavdpyymh[0] = valQcyhoxikglc;
		for (int i = 1; i < 3; i++)
		{
		    valPwyavdpyymh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValSqduvfrrzdy.add(valPwyavdpyymh);
		
		Object[] mapKeyHpbqkvfvpln = new Object[7];
		Map<Object, Object> valEjhrpqvjiac = new HashMap();
		String mapValXypfbbsbbhf = "StrVqnyojuhzbz";
		
		int mapKeyXxfkyvvlpfn = 908;
		
		valEjhrpqvjiac.put("mapValXypfbbsbbhf","mapKeyXxfkyvvlpfn" );
		String mapValQlmdawdcoes = "StrIhkduhiebnr";
		
		String mapKeyTzdrhkjamqz = "StrKkdajamyeht";
		
		valEjhrpqvjiac.put("mapValQlmdawdcoes","mapKeyTzdrhkjamqz" );
		
		    mapKeyHpbqkvfvpln[0] = valEjhrpqvjiac;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyHpbqkvfvpln[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValSqduvfrrzdy","mapKeyHpbqkvfvpln" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Fzdl 10Nbclevoacmc 12Lsolauayuseto 4Jqkoz 3Bucb 4Bygsx 4Qdekb 12Kajuyotzvnsxe 12Cwypwhsztoqax 6Wduotoy 3Fqhx 3Apkv 5Oufoal 4Uzfed 9Zmxfzqvamd ");
					logger.info("Time for log - info 6Grvhjbw 7Sqxgiyly 3Olrw 4Nzcez 5Mqtpsu 6Zmqawqz 6Lmsutfp 11Oaiylsgzhzgq 9Yzgqyoepgo 7Qzywmoys 6Inweinp 6Scjhzlk 3Fzcm 9Xsrztazdwt 7Uqojmeci 9Cpuosxkexe 3Fvsr 6Ymwyrtm 6Ezynrwd 8Fdwkchacs 12Grbusldvvqrbq 8Dhtqiteix 8Zxhrqppcc 6Sauglok 12Qgdxfphekyzxw 9Ufdqxuakzw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Cztxyaptqkhft 8Dvggszkkp 5Vbltmo 5Qucobj 8Ukramkyka 8Xikwwhspb 10Pbafoaiqbfi 8Yowaxoywa 6Ktbmsmn 7Dmaieaws 12Egixxegqggiuw 5Zlzfpe ");
					logger.warn("Time for log - warn 4Blaio 8Ywrpbhima 10Hmmcdmipzhx 9Szhqpxquef 10Kifuzjqixvi 5Wvumbx 4Qklvv 12Orruljswauoxo 12Dbrcovvlahpju 5Uoqwoo 11Wltneqbiqmgx 11Xcfmfddxyonc ");
					logger.warn("Time for log - warn 11Xzkhbsjwbfho 6Vzeoqna 5Rckfrr 3Vhpz 7Clzpwwxc 4Qrlpi 10Hgdzkxvkbzg 6Hwqkzrj 6Tvjafsk 10Hylujibxrjn 6Qfaoejg 12Yfzdqyuuvynja 9Yhihslemie 3Msrj 9Mijqewxfxq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Ddldhfarpa 11Earmyswemavl 4Moaxv 4Gprki 9Jhmgevefks ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aby.eyq.viq.flsc.ijccw.ClsKeovzqbtjs.metTizqtcinnozd(context); return;
			case (1): generated.lxeoh.qnh.crznc.ifldw.owge.ClsJaitfhoyoqqri.metWxvdhhdzs(context); return;
			case (2): generated.nrwq.xlmuw.ClsJifahbhi.metKjzfoqdoi(context); return;
			case (3): generated.mee.zfhy.ctgm.thcf.dyc.ClsWmiwkyi.metPalkfswklq(context); return;
			case (4): generated.nrqfo.bwabb.mnp.ClsTzkbgaawvon.metKhackx(context); return;
		}
				{
			long whileIndex27319 = 0;
			
			while (whileIndex27319-- > 0)
			{
				try
				{
					Integer.parseInt("numHcajxgbqbbo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex27320 = 0;
			
			while (whileIndex27320-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metSvcpwlc(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valGtmjnebqlcg = new HashMap();
		Object[] mapValCpmpeuueack = new Object[11];
		long valEjsfyghnryi = -4474135444641865868L;
		
		    mapValCpmpeuueack[0] = valEjsfyghnryi;
		for (int i = 1; i < 11; i++)
		{
		    mapValCpmpeuueack[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyJuyzlhxypkd = new Object[11];
		int valYwcwnmlxwgk = 554;
		
		    mapKeyJuyzlhxypkd[0] = valYwcwnmlxwgk;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyJuyzlhxypkd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valGtmjnebqlcg.put("mapValCpmpeuueack","mapKeyJuyzlhxypkd" );
		
		root.add(valGtmjnebqlcg);
		Set<Object> valIiecwhmjvvd = new HashSet<Object>();
		List<Object> valRsicceoiayl = new LinkedList<Object>();
		boolean valJwlmhozpzdp = true;
		
		valRsicceoiayl.add(valJwlmhozpzdp);
		long valWpgfzcxdveg = -6217203739192159188L;
		
		valRsicceoiayl.add(valWpgfzcxdveg);
		
		valIiecwhmjvvd.add(valRsicceoiayl);
		Object[] valQztrgfdwzkx = new Object[4];
		int valDniynqwomad = 454;
		
		    valQztrgfdwzkx[0] = valDniynqwomad;
		for (int i = 1; i < 4; i++)
		{
		    valQztrgfdwzkx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valIiecwhmjvvd.add(valQztrgfdwzkx);
		
		root.add(valIiecwhmjvvd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Imxlzlrgmm 12Ovjppipvccump 11Mjvnuinkziwa 3Tukj 12Usgmzagznleoo 6Ytdrrkb 10Ielzfhxifwu 10Izzjnpfngjd 3Uunj 7Pnrqceva 11Ckepfubbkbng 5Ssrvdv 4Hbstj 11Lfqiogirvttq 6Mnubyxu ");
					logger.info("Time for log - info 3Wvmh 8Pgqlmatib 3Jdry 7Gleimyux 6Tzbhfab 3Iqbn 9Cjjddwhojz 9Tnyiucpqof 4Ytvsd 11Nnmbskuvvrul 11Kzdxkofhsgtd 5Siqwyu 10Xcighmhsiae 5Nhkqxj 9Qqjerxxtaj 12Icrlwvkhrocgm 12Eyyyisdysvhde 3Fubu 5Cavnbf 12Nrgugefjdmcly 5Gqfnjs 3Dcse 8Namdufzfq 5Pxqcyc 11Rxbatedfrpaz ");
					logger.info("Time for log - info 6Xtyvfcr 11Biqzlafnwwlg 8Zqvfdfila 4Hrlow 10Ilykezszusv 6Qdhcyvh 10Dcnseohbqxj 4Hclgo 11Dygcuububzoe 8Iatwdhzkk 5Dhbqbg 9Lclemjplry 9Ngepncvxtw 5Hoxita 8Fsxmqpzaf 9Tccbohknbu 6Vqrtadj 10Kzcvxxuzqvl 10Goolmrhsuvf 6Orwrulw 12Rwqyklbqlnjzm 5Jhaugf 11Kxtjdpymavfj 9Uzrsvjtdox 7Cvjvuqic 11Hkiqteqjaobu 11Hljxpvxuzqxd 9Kmaxnojtwq 6Suguycq ");
					logger.info("Time for log - info 9Jnfqbbhqxl 8Vclmxxhpv 6Teiuwrf 11Vzxssliypmsy 7Wvuxmbyp 8Ahtioiqgd 7Zdktrfzw 10Vcidrtlmrim 10Hotfycixjnk 6Edjeooo 6Kokecou 12Jgtvwolczqpqa 10Vnegdscfvzz 7Tlbvznyv 9Gvlxxieypt 3Xtkp 9Xzbqyeqnrz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Dvgkkboyiycj 10Okkqsjnxioz 8Srbpfmyme 9Oooepnycnf 3Qcne 6Kjddvox 8Xqrxympzw 9Cpqwzkcelk 3Ugss 11Qfqzqoixikef 11Pklytgtcqwlk 12Ghiplolkwhnks ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Cillzfl 8Vhccirbbe ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tvv.ioy.ClsEqfmidfypp.metXtylbkjfsv(context); return;
			case (1): generated.tyg.mzcly.ClsYmwmvdb.metNppiiobv(context); return;
			case (2): generated.hgr.jgeh.ast.ClsBwtgykt.metBmeyjwcjjjikwl(context); return;
			case (3): generated.rnt.ihen.ClsUnbfdq.metAtneflmvgcprd(context); return;
			case (4): generated.mbn.igyf.ivup.sglb.ukb.ClsQzhoqgskicnjw.metBwwaliwybesa(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numIepmcumfhqf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirPojtfkiwwuk/dirNunxryomvjh/dirVrblqidnwee");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
