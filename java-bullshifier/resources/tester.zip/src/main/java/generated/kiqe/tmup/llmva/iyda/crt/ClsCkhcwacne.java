package generated.kiqe.tmup.llmva.iyda.crt;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsCkhcwacne
{
	 public static final int classId = 350;
	 static final Logger logger = LoggerFactory.getLogger(ClsCkhcwacne.class);

	public static void metSqibhmdisq(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valNhpewctqwsq = new LinkedList<Object>();
		Object[] valKmwyieaojyj = new Object[2];
		String valNxjcezptfty = "StrRgpbjrfjonj";
		
		    valKmwyieaojyj[0] = valNxjcezptfty;
		for (int i = 1; i < 2; i++)
		{
		    valKmwyieaojyj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valNhpewctqwsq.add(valKmwyieaojyj);
		
		root.add(valNhpewctqwsq);
		Set<Object> valAdroaiohauz = new HashSet<Object>();
		Map<Object, Object> valHlzigvyvgvi = new HashMap();
		int mapValZhrueexxekc = 687;
		
		long mapKeyEqlwghrsrfp = -8533302039082296036L;
		
		valHlzigvyvgvi.put("mapValZhrueexxekc","mapKeyEqlwghrsrfp" );
		boolean mapValNbcfytmklkl = false;
		
		String mapKeyDqprzvlygkw = "StrJohkxgcvokw";
		
		valHlzigvyvgvi.put("mapValNbcfytmklkl","mapKeyDqprzvlygkw" );
		
		valAdroaiohauz.add(valHlzigvyvgvi);
		
		root.add(valAdroaiohauz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Qxduqtscqqx 8Gwwqmdojh 5Jnssuh 3Ygwb 6Bnvmwev 11Orjkxqudwfqw 11Gdbrnvumkegc 7Zuixsyxc 7Sceozpef 12Sgmhuojvekwri 9Tfgaxuxaeo 8Kqbcakbvm 9Fqulvisshi 6Wvoeigw 6Jeishyq 6Iqvtedi 6Fvprpmk 12Elqblhlprquls 4Tvhzc 7Lunkmrki 6Efwphwq 9Zbvnnqxdov 9Szgszpqfkr 4Qmqjh 11Bibokvjrfgrn 9Rxhxzruegd 6Vdkniyu 4Kemqq 4Tfedy 10Xyawbrcuytk ");
					logger.info("Time for log - info 6Ankjkka 7Dupnpoxv 6Zkjvyrv 9Oeaydezbju 8Mpriuqcsh 12Owezqsyzlccji 12Gtfaodqtdsmnu 8Lrvgytekc 9Nukivqztma 5Wfpomo 6Xpbqshu 8Haqvvxret 11Opeebqrjbueb 8Ycbkocbyb 12Gjkbodvnoeaxf 9Gyrqsitjjq 9Ghepdrbxkt 3Phpc 10Bmlwcdxccmv 9Qeryjnslff 8Tknhjacuh 3Urhy 6Dkqdpym 10Zeeljgoxrkh 10Cznhxvgnyhc 5Cltroa 12Galsaqtvjxeeo ");
					logger.info("Time for log - info 5Uwjfxw 11Bvgnbfrtespb 9Osvykhdaso 8Sczjkkbuv 5Uksxlk 12Ndkdjfcpeorit 7Dweubupl 12Cemeoomfobziq ");
					logger.info("Time for log - info 4Usvvj 8Wlarwtadb 8Crftqwvtn 6Hlmeimb 10Rptsnoymbjh 11Dxpfflveptym 3Lnyb 12Loysnivxfahze 9Rturirnfri 7Yfugcalm 11Uqiyvjgjyhis 3Lxqp 10Mtfgglqogco 3Civn 8Iytvpxglp 12Eoirutxwboddz ");
					logger.info("Time for log - info 10Eraggrhihfr 7Scbjtxfv 10Wtjsfbfwvia 3Vqun 6Kqimypk 11Nzdaqgwywoqc 9Rrnvmhhbml 6Zvaocjk 3Kfsk 12Vigmeupkhlvix 5Fignui ");
					logger.info("Time for log - info 7Nmkjcozf 3Jait 5Nnztye 12Eyhlunjslakff 12Ddjwrmwifxzpg 7Ntvwiyfw 7Znwwpqbu 8Jkgpgqywk 11Hanihgnlgzpt 6Pbcqgio 12Voklxkwgummyj 4Vtjun 7Xflfjnve 9Qafithvgcs 11Sopptxhdsrlp 12Dhgniafizdpgv 9Kwenzwvjpj 12Mkuthijspfhpd 3Tamh 10Acyaetlqhkd 6Ezehthd 7Cbcbluty 4Ezrjl 12Hmwsozjocotoo 11Vxexqlzvuwcl 10Vmpnxaeepik ");
					logger.info("Time for log - info 11Ncoferncills 6Ihoedde 8Vcowtynji 3Ubsi 12Avjoqggxkynlf 11Vviyapexburg 8Uasmibaky 8Dskbhmegr 6Bfcxsry 7Tuahzjjq 12Apxrgimcdoyik 6Cssujtf 11Hvlxhowrxuku 11Vqymxrtgoaka 12Yzolezbkdzyqh 3Qfgt 3Uxig 8Vafgmysca 6Wxvhvuz 3Caoy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Mvueija 9Orshuiagzh 9Etmsusdfka 7Ppqnbqdj ");
					logger.warn("Time for log - warn 9Dfwmlgdxgh 4Xyppx 9Fzpfmoxebl 10Ibazbbazcpn 3Uogh 8Odxcwbmww 11Gmodccjnxfwp 10Xxmjddlhrad 4Akygm 5Pfwyyn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Acomslwkywlkg 5Gyoxax 12Yczkagivojxdl 12Eaqobsfqwcrzk 4Dssil 9Zsmfpmiwfr 4Sllub 12Idcvxgcuhlrjc 5Huvodv 11Zyhbpiskiobx 5Xabjnj 10Pfwtqrvpaos ");
					logger.error("Time for log - error 5Qithqn 7Nysabbfr 9Kxugqbodor 7Akuiojfd 11Aimksklwddra 10Enhtgbsfvcl 11Ttahxrqnjfea 9Hpqimwdmnl 12Uvvtymxcpqpmr 4Gwmiy 12Hpisapdjytgec 8Gfaxssiqq 4Gepkw 6Fvsbrit 11Dbstswforcgx 8Qiehjnsqy 6Ejjqptf 3Csqv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ulj.ogxe.vbwy.ClsQmshqdjff.metNngxyjxf(context); return;
			case (1): generated.wcc.zfysf.ClsYrxejsiwymmrbw.metKnfdaxts(context); return;
			case (2): generated.iotb.mlgn.hcur.ClsAdwtsoupvuwy.metMpwarwswa(context); return;
			case (3): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
			case (4): generated.aby.eyq.viq.flsc.ijccw.ClsKeovzqbtjs.metTizqtcinnozd(context); return;
		}
				{
		}
	}


	public static void metOebzatkpa(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valJzkepujrkaf = new HashSet<Object>();
		Object[] valApwqdragdgm = new Object[6];
		long valAgruypukope = -2966755043179922761L;
		
		    valApwqdragdgm[0] = valAgruypukope;
		for (int i = 1; i < 6; i++)
		{
		    valApwqdragdgm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJzkepujrkaf.add(valApwqdragdgm);
		Object[] valUtyopwobklq = new Object[9];
		long valRtmkdcjisxh = 689022134491048625L;
		
		    valUtyopwobklq[0] = valRtmkdcjisxh;
		for (int i = 1; i < 9; i++)
		{
		    valUtyopwobklq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJzkepujrkaf.add(valUtyopwobklq);
		
		root.add(valJzkepujrkaf);
		List<Object> valNhjzzchtotw = new LinkedList<Object>();
		List<Object> valYymbgziesls = new LinkedList<Object>();
		long valPfigbbshqqe = 6211436845432167312L;
		
		valYymbgziesls.add(valPfigbbshqqe);
		boolean valRndryjvbazk = false;
		
		valYymbgziesls.add(valRndryjvbazk);
		
		valNhjzzchtotw.add(valYymbgziesls);
		
		root.add(valNhjzzchtotw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Gjenohvqzxe 7Lrlurdph 11Tszzodebxekq 7Kwtkcuhj 4Znuel 9Vyelyetygp 9Kdfjomcikh 5Xbixqz 10Uewvkejwcda 7Zzcxxsdo 9Pdzbetqxlr 6Mqxhgkx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Raztyjv 8Llvrldxzw 12Mnysppizadmag 5Tfbshf 12Qhbrhmgmeiuib 3Chiq 12Ygqabdnmowird 7Lhmhcmhd 6Zetgiic 9Hrhsbebrmq 11Sdboumdiuqjs 4Muzfc 6Colyinp 8Ssshftdvz 5Mwtsqn 8Aenjfrpjt 8Uwqpxsite 10Oyioochrzgt 11Sxmpqfaefnfs 3Awap 3Iyti 9Hylvgbyrfn 5Rbniuf 4Jxtvh 5Fjokrj 10Rvqqrgzsgzl 10Hrhgneikjfo 6Uwirwnx 6Ifsiana 5Xeagsp 12Navyosgdkdowe ");
					logger.warn("Time for log - warn 9Fchcgwmdhy 9Ameanludfc 9Whzbgtohqd 8Dthrhzdvt 5Lzvcqp 12Jvlfijuovfgyg 6Mthhfys 8Oqshajvml 7Ezrymqhv 11Mhdcvvwlsdae 9Mwrifkumvz 9Ufyaopnqpv 4Bucdc 3Avqd 4Cbaqb 11Ejijdpaxqyst 5Xgzjhj ");
					logger.warn("Time for log - warn 3Tzzo 5Cmudrz 12Gzluselxkrqig 12Mrqykojokhqxg 8Ogmcrdske 9Qtcwhnpklk 8Giegvpczv 6Ccqamyv 9Fluyimxqxz 5Jwassb 3Cuxi 10Tnycpttntog 5Siwvxn 5Iofbno 6Koqqlap 12Pvztqsgblebaf 10Fhxnsrbpfin 7Iqqvppql 6Uugbyvb 9Efphibjqcw 7Xpxpgznr 12Vroglwdtilzii 11Tndrbutlqjga 3Ljdq 12Wcleushsguimq 7Xfldevcq 9Jcvvtujeal 11Knfklpovergb 7Xzhoqndm 7Ddnwstwx ");
					logger.warn("Time for log - warn 6Qsrowez 9Yibetpicco 10Coheflmrump 7Echhyxkx 8Otvjvogvs 8Nlhzxtxkg 4Rybmu 4Rzmju 9Xvzazhyrbb 8Hdpzwfkyh 4Jdois 4Xnujl 7Qdvjnrto 9Tekgclgqpo 8Qhflszomr 12Zrisehvtyyewp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Zkylraifpn 7Elyvllhc 5Ejbpcb 7Qtuuenoy 3Oaef 5Bbaggn 6Owhdjox 3Zxvv 6Brsbxpt 4Ohehy 5Nhlcid 8Hdmdhcilk 4Wrbkk 6Toebywg 11Flewxxvssjkz 7Quluyrtz 10Wsbxoqukhsj 5Zwceph 9Bxpnocrfyz 5Yiuohv 12Qlhrwgmxdlkou 3Dmrb 8Ctlrgjmhq 8Gngccrdui ");
					logger.error("Time for log - error 3Pydr 3Ftuv 9Bjrkblznrq 9Vdrvlitsar 9Nwlteodhcl 8Clhhoyvvl 6Fzyxqjp 4Cwcwj 8Ieigzlfwb 4Ekxot 4Yzlkv 6Ofmznwj 7Asyvxilx 12Pubqpwbkhzydu 4Pejuq 4Halgh ");
					logger.error("Time for log - error 5Pyavga 10Ryxtftwrktd 4Vfzvw 5Iyzvvd 4Rdhup 3Zjtd 12Gkrjifagzoxkm 11Dqkodlqgutbf 11Ffmzmyoddvin 12Hkchcbuvczlma 11Sgjbfhrnxbeh 5Fukogm 11Dtsxkvbotclz 11Kmiuzbaeipwc ");
					logger.error("Time for log - error 4Osoya 8Ccdromlet 8Iuptrzwlh 6Asqufgi 11Szftdsogrhhi 10Lljvholckdv 4Vnnwx 6Ohzqvlv 4Nluft 6Pouupwo 4Zzpkx 4Aopum 3Jlug 4Sedcg 9Rogbbbqcea 3Qcdx 11Danvirtevvlx 5Yykrss 5Naopdj 5Acrjpn 6Jihyiys 7Enfaduwy 4Soons 5Ggrrzd 10Pulztzmwlug 8Cuonvwcpz 5Bcrzhf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gyic.epw.ClsQxhbkrqjzoqujk.metCxlwimqqzxfd(context); return;
			case (1): generated.gpnn.qul.pdexl.hxjph.zmndq.ClsIcvyndtrplxfkf.metNldde(context); return;
			case (2): generated.bkbep.bjvph.skry.qijli.gfl.ClsFlycqobnxjszt.metXjavkvvpbkkxo(context); return;
			case (3): generated.gapuh.cesf.ClsXyxpazfgwk.metLiarcmz(context); return;
			case (4): generated.bkbep.bjvph.skry.qijli.gfl.ClsFlycqobnxjszt.metLjgrsni(context); return;
		}
				{
			if (((9635) * (Config.get().getRandom().nextInt(343) + 4) % 836632) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirBjjyfperods/dirTzcarewjxsv/dirNxsragoojui/dirAdwijjrliqs/dirDkuadmxvjgn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numVmjesrddflh");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metEqiixejyhymhk(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValCtbtpyrcbxb = new Object[5];
		Set<Object> valBcekptjjsjk = new HashSet<Object>();
		long valGtpaebymcec = 3347453592705952091L;
		
		valBcekptjjsjk.add(valGtpaebymcec);
		int valZkrzcvjzyra = 138;
		
		valBcekptjjsjk.add(valZkrzcvjzyra);
		
		    mapValCtbtpyrcbxb[0] = valBcekptjjsjk;
		for (int i = 1; i < 5; i++)
		{
		    mapValCtbtpyrcbxb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyXntrpknwvsw = new HashSet<Object>();
		Map<Object, Object> valXdmuljivknl = new HashMap();
		boolean mapValLhsdmawgiup = true;
		
		boolean mapKeyPmdaxzgigpx = true;
		
		valXdmuljivknl.put("mapValLhsdmawgiup","mapKeyPmdaxzgigpx" );
		
		mapKeyXntrpknwvsw.add(valXdmuljivknl);
		Map<Object, Object> valNxfhfvnonpl = new HashMap();
		long mapValGlzhfwnlxsw = -4343407738228371458L;
		
		String mapKeyUwlsfgjwyuc = "StrXcxsafixjwi";
		
		valNxfhfvnonpl.put("mapValGlzhfwnlxsw","mapKeyUwlsfgjwyuc" );
		long mapValWlyrvxrfmgb = -3694993988867413510L;
		
		boolean mapKeyEinpehvrglq = true;
		
		valNxfhfvnonpl.put("mapValWlyrvxrfmgb","mapKeyEinpehvrglq" );
		
		mapKeyXntrpknwvsw.add(valNxfhfvnonpl);
		
		root.put("mapValCtbtpyrcbxb","mapKeyXntrpknwvsw" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Eumw 10Aqxdolkapwq 9Vciedrizsf 5Tfojay 12Bonxjvqyaafrt 10Xjezkquunqp 3Ghoz 5Ldwoms 8Hodwfewle 11Xrljmdxwnbmc ");
					logger.info("Time for log - info 11Vhpulbwcqeva 11Vdnlsquktvhh 4Ztigy 10Sojompyulmj 11Czhcadqqwlre 7Zuhdqwxu 8Sfkyuliql 12Gxytzdlxnjeue 5Dephww 6Ncyyftf 6Phcipxl 9Yfewkgfrol 11Asfiqnkmgakq 5Orjmof 12Mrdzdymeiwjlo 6Qeueywh 10Mtkjpffvprg 11Tukwnmkvqxgw 3Nqjw 12Sthvzkprrelsu 9Zohvizamaw 11Zmyfohbqcwpj 3Koyj 11Tvmacozqwgvk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Itdyn 8Tqueckllh 8Mdpauutjk 4Ycvno 9Hxdvmniuie 7Xrytnnhw 4Couaf 11Agakwxmayjrc 6Thlrpnf 10Ppgaflqislt 7Orhkbfmz 9Ipmjrxngir 5Jlygqh 5Vcnzig ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Drtlnit 4Licld 3Vkbs 4Mxkkj 3Vmjc 12Ktpmikevyvukt 5Iewpgx 5Vtkwsk 6Bzkkbur 8Jcldcxjjz 4Kcktb 3Japb 8Ucgocctzc 11Yocvuftctfal 11Qjiojlytgblx 9Iepidmxyee 10Sztuftdqmpn 8Cgolohbyf 8Zdbxtaael 9Bgymxixqpq 4Vnxwx 4Ysgwi ");
					logger.error("Time for log - error 9Cjhbtqkcgf 8Nwgxhhfjw 3Dref 8Cbjiratus 5Ydgawi 12Ntqnorbqqipfb 11Lirarjdwqtzx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ctymn.uic.kza.ClsBochsrrjh.metGygnvmjatcdvgy(context); return;
			case (1): generated.gyic.epw.ClsQxhbkrqjzoqujk.metLlbnuvvzsghg(context); return;
			case (2): generated.lzs.nehlu.rmx.ecdl.iyxe.ClsYbctjsi.metYscrg(context); return;
			case (3): generated.xluq.wys.lexvj.ClsEsonclfnnvbg.metKsdklzxlnfg(context); return;
			case (4): generated.cymhf.zmxu.aqlat.ClsTwlvztmhvdbz.metGeiteeydip(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(459) + 5) - (Config.get().getRandom().nextInt(591) + 5) % 130524) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((4459) - (Config.get().getRandom().nextInt(762) + 9) % 663388) == 0)
			{
				try
				{
					Integer.parseInt("numEoxujvbniuf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
