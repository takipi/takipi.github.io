package generated.yyztd.kdvzo.xtlfe.sqo;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsTrzriiwcgvlv
{
	 public static final int classId = 96;
	 static final Logger logger = LoggerFactory.getLogger(ClsTrzriiwcgvlv.class);

	public static void metJvnsuyubxdox(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Object[] valRtjagvbczzz = new Object[4];
		Set<Object> valLnpxvhqqioo = new HashSet<Object>();
		boolean valVfxnymfbdpm = true;
		
		valLnpxvhqqioo.add(valVfxnymfbdpm);
		boolean valFnwagtiyyvh = false;
		
		valLnpxvhqqioo.add(valFnwagtiyyvh);
		
		    valRtjagvbczzz[0] = valLnpxvhqqioo;
		for (int i = 1; i < 4; i++)
		{
		    valRtjagvbczzz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valRtjagvbczzz);
		Map<Object, Object> valQtbpjiozpto = new HashMap();
		Map<Object, Object> mapValRzwadncowfq = new HashMap();
		boolean mapValYoobrtrofbd = false;
		
		int mapKeyLconivxvjiw = 467;
		
		mapValRzwadncowfq.put("mapValYoobrtrofbd","mapKeyLconivxvjiw" );
		
		Map<Object, Object> mapKeyInlkwxujgbv = new HashMap();
		String mapValIinvigaznir = "StrZrudyumwtgg";
		
		int mapKeyVciaouyvaai = 574;
		
		mapKeyInlkwxujgbv.put("mapValIinvigaznir","mapKeyVciaouyvaai" );
		
		valQtbpjiozpto.put("mapValRzwadncowfq","mapKeyInlkwxujgbv" );
		Object[] mapValMyzcrawwbwl = new Object[8];
		long valRvqaulfetjd = -2685385405738177414L;
		
		    mapValMyzcrawwbwl[0] = valRvqaulfetjd;
		for (int i = 1; i < 8; i++)
		{
		    mapValMyzcrawwbwl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyYuybxkcchmu = new HashMap();
		long mapValXtsvczylkmf = -7588932755901926425L;
		
		long mapKeyPykxxoxloxv = 9058775041421624314L;
		
		mapKeyYuybxkcchmu.put("mapValXtsvczylkmf","mapKeyPykxxoxloxv" );
		
		valQtbpjiozpto.put("mapValMyzcrawwbwl","mapKeyYuybxkcchmu" );
		
		root.add(valQtbpjiozpto);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Ubdcskkzsr 10Uibkpkgziwu 8Boxbfliti 9Lzmtgojxxu 5Xflfzn 6Cqpesxq 10Ocqiteqskms 7Emvhundu 11Dnbwbxhccfbz 11Vydhukddzgwk 9Klvvzxgchl 8Efaeanptb 9Umhnyfftkz 7Odfhuwbb 12Gsqenbdburdse 9Dscmmhumwm 6Yuwoevj 12Sqehmckboxotk ");
					logger.info("Time for log - info 4Btugw 7Qcucmrfq 4Xjikn 6Xtstzyz 3Rsvc 10Pkvmxdkzlwb 11Iqoogwqwiokw 7Enirloae 11Kykxjxhxsloj 12Jyeprgkxptwml 4Gigdq 4Oivxg 11Ntjfonudzogo 12Segtvwxxssreq 3Sqwa 11Wquksfxipaup 6Frjjjou 4Okgsv 10Ezveoivnwno 7Qsdtkpbf 3Jdhk 7Emsoeyqx 7Knvvnlup 7Oucwbeyq ");
					logger.info("Time for log - info 9Vocixpwgst 5Zsquoo 11Fkrfbqwsrjok 3Tszy 12Yywntgcwbxpts 9Reyueafezx 3Kclm 4Fxnoi 9Hoepronupe 12Bdagdbxxfbrep 6Pweygro 10Uyomtegzvan 7Lnxfxkjf ");
					logger.info("Time for log - info 8Japcuwzwn 7Khfwrukt 8Nrjudsaxk 9Hpaccnovgv 10Uxshlwqetfx 8Goryyzhst 4Qtuiv 7Qwnddjbe 3Qxhy 10Tissupqpbes 10Dfipcfppmji 12Tuunksosjxqso 8Fnoxiuwps 8Asaauwcse ");
					logger.info("Time for log - info 10Zmyfbcfwlal 12Thdyxvxzqioai 10Xejybeaiisw 10Fgkbuylbnhy 11Fmkuujnrwprl 10Ontvykvbvnh 4Zacvs 6Vhwpcqf 4Glhbd 9Cyyygtebdi 10Xanssnorkym 10Cuspxqcalnx 8Bdiitxxwo 12Kzmuelchuvdee 10Pnjkgontahh 6Ypagxjg 11Dkmvwaowrohv 6Pdornrd 9Vvljhjexqz 9Qjqmmicvdu 6Amldmxc 8Hyqpcqlyv 5Uwjhrh 10Lzbknwahwtk 12Htaaywghvxxmc 5Yojfth ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Pplwvcwfhf 7Ekyyinfp 7Anclgnft ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Etlgqdmuleeb 8Lrtydcqhn 10Hmrnrmgiiyv 7Mefyhhyc 10Sdoimutxrfm 7Whuyklru 5Nhzsit 9Sozihtspuj 3Pllg 10Vsohuribxrs 9Umvgfkxvrc 12Ldsozniarhwlt 9Aevnscrqlf 10Sosgdgpgzbp 3Lxju 9Flxegmyuwt 10Acffjmkevix 7Epoujqsc 8Scavidgsh 3Lqdj 9Tdtwbxcfba 9Whoaycdqhc 4Xbmpt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.seews.usvhz.ClsBpkgpi.metSagewrwqtbzsvw(context); return;
			case (1): generated.naf.suq.ClsSzodbxxywsfz.metKihakbig(context); return;
			case (2): generated.eddt.homo.syk.wqll.dyeuq.ClsYzlmjqrjjp.metWfbnvwlbefalsd(context); return;
			case (3): generated.hvqh.qdnb.tawyn.ClsAaddylg.metCsnugb(context); return;
			case (4): generated.gxto.nwin.jagvj.ClsIsbtgkhpotpu.metArlow(context); return;
		}
				{
			int loopIndex21752 = 0;
			for (loopIndex21752 = 0; loopIndex21752 < 8874; loopIndex21752++)
			{
				try
				{
					Integer.parseInt("numCvbmblraxrr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metXboobndjklmxey(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValFajieygfkye = new HashMap();
		Set<Object> mapValNyuyhpgpzwp = new HashSet<Object>();
		boolean valXlqrosshppc = false;
		
		mapValNyuyhpgpzwp.add(valXlqrosshppc);
		
		Map<Object, Object> mapKeyYbijmjhxddg = new HashMap();
		boolean mapValDfkohblvodc = true;
		
		int mapKeySdkmyxlbrcp = 906;
		
		mapKeyYbijmjhxddg.put("mapValDfkohblvodc","mapKeySdkmyxlbrcp" );
		
		mapValFajieygfkye.put("mapValNyuyhpgpzwp","mapKeyYbijmjhxddg" );
		Set<Object> mapValLdlctpcwxkb = new HashSet<Object>();
		long valEmexxuvramg = 1800955167993814895L;
		
		mapValLdlctpcwxkb.add(valEmexxuvramg);
		int valRikyrummnoy = 963;
		
		mapValLdlctpcwxkb.add(valRikyrummnoy);
		
		Set<Object> mapKeySyipbojsnck = new HashSet<Object>();
		long valGahxktmpxwo = 8182331187670727955L;
		
		mapKeySyipbojsnck.add(valGahxktmpxwo);
		boolean valQqdbczzxlql = false;
		
		mapKeySyipbojsnck.add(valQqdbczzxlql);
		
		mapValFajieygfkye.put("mapValLdlctpcwxkb","mapKeySyipbojsnck" );
		
		Map<Object, Object> mapKeyXtgmyhkeutl = new HashMap();
		Object[] mapValPfyeppuxshc = new Object[5];
		int valKbkyzzdfsmz = 985;
		
		    mapValPfyeppuxshc[0] = valKbkyzzdfsmz;
		for (int i = 1; i < 5; i++)
		{
		    mapValPfyeppuxshc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyEprghdyqark = new HashMap();
		boolean mapValUehfhndched = false;
		
		String mapKeyEazutdeisbj = "StrDwucftvplbu";
		
		mapKeyEprghdyqark.put("mapValUehfhndched","mapKeyEazutdeisbj" );
		
		mapKeyXtgmyhkeutl.put("mapValPfyeppuxshc","mapKeyEprghdyqark" );
		
		root.put("mapValFajieygfkye","mapKeyXtgmyhkeutl" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Juvysgry 11Qyylltgklkgw 9Hnnyxnaopn 9Mnybscikms 11Vbfqdgjyfwwz 4Xmcuh 11Nbqcshgscwxz 4Riuwp 11Jbzywenjdqbv 4Syydc 6Axkawul 4Peeqi 6Qnjfjgf 8Ithynpdhz 11Jdhxftlblyns 3Tbuf 8Xopuqbpga 9Ghzkikrdnr 5Alaisl 3Wwzi 6Xbbjoml 11Mtnproxksmag 4Eidak 6Wahdntk 5Urorzw 11Yasouhpheyxf ");
					logger.info("Time for log - info 11Xlsbecnzwelo 11Gxnffuyedoyy 11Nrqquxkjrxmt 10Bybrexgnlsl 3Gjyx 8Zwrfzctzh 8Tnfayfjeu 5Wsfubt 9Pljkrohsod 9Lkygccqtje 6Stcziso 11Uybzllquzrzv 8Rfpbxoiht 11Ynwgwcjadrpt 3Kmel 7Dygbcqad 12Wgwrnicmlisyh 9Iqosrexwns 7Uskdkpsx 8Yqihcsvso 4Kquqo 11Hrogqjoqjvhq 8Wuglwdvcu 11Amgdqgnmanxx 6Ahuzcsy 3Ufjy 4Kwqrn 3Gkqy ");
					logger.info("Time for log - info 12Ekoosencjamdm 8Blktjkywz 12Rbjbvdpvjpkls 6Uqcwtuy 11Tqdpzojjnsfm 12Vbupsieizdaus 12Ejcgzjhrhqjpe 11Zwiowulcajcw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Bbqiysxbgslzw 3Nrzs 6Dwktdom 9Mxjkmlderw 5Mackcz 6Fjxrwua 6Kapxhdj 7Byandvoo 4Oscwa 10Uqabvwdnywa 5Cpahxl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Uazh 6Baqyfkf 12Gxofwpsrzwnip 4Gynot 4Diinp 10Uewhlmybroz 5Glbtta 4Wogeh 6Edolgiw 11Zgbefgdapoqj 7Lfaljdzr 7Iyivmyyn 12Zmihuhzrdtzii 11Csmitlhqbrya 6Ptpkyqm 3Aagz 3Rxlm ");
					logger.error("Time for log - error 6Lgpsunu 11Zhlrrdzwoqwf 11Arzizwegzxee 6Hmgbpil 3Xhcc 11Qwxvcnswecwb 5Imwssb 11Gnfzhhfjjxcu 3Myyv 6Rzjnjtl 4Iyclb ");
					logger.error("Time for log - error 11Wymwmcbdkfrq 6Wevberp ");
					logger.error("Time for log - error 12Svbhiecihqgvk 7Xjlwjbxf 5Nwgdjc 10Cxjzcesrydu 7Skyeeywy 12Yaxpwwhruplwh 11Xfchbgrbmvcd 6Kqnzfws 12Ecwoqkpbjpefv 8Uqfuwmruh 3Jtkd 7Jlntfcvf 11Ocsxvryunkos 4Erewr 9Qbalwnnljs 10Ijxdntpvxuw 7Wlvoqmzp 5Kjhoxh 6Uozstev 7Ucsxqjqn 11Fuvcyxwsxdxw 10Gdjbxyvoete 7Uythmyzk 3Fkhw 10Pgzrslqnswd 10Kvdbbvtsuvt 7Atixqwlp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cin.hewe.akg.wyf.seuvv.ClsFgxjhcrdocnyas.metKhzutma(context); return;
			case (1): generated.ocmm.ezbtm.vxyei.kuseg.ClsUqzgoaq.metGzyab(context); return;
			case (2): generated.yewpq.dap.itdt.ClsOhnihvc.metYxfsbhns(context); return;
			case (3): generated.hcl.ivd.nxcam.ClsQkvrtnftml.metTyfahozhlcema(context); return;
			case (4): generated.plye.kjczy.bmku.wrxrk.zek.ClsNtetu.metUzgbsjjt(context); return;
		}
				{
			long whileIndex21755 = 0;
			
			while (whileIndex21755-- > 0)
			{
				try
				{
					Integer.parseInt("numMsyzhfsaogr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metXtcge(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValNldgwundczh = new Object[10];
		Map<Object, Object> valUewxutgrdak = new HashMap();
		boolean mapValSwdsqwsjfiu = true;
		
		String mapKeyWguzipeqtbi = "StrBrsjstvtyum";
		
		valUewxutgrdak.put("mapValSwdsqwsjfiu","mapKeyWguzipeqtbi" );
		
		    mapValNldgwundczh[0] = valUewxutgrdak;
		for (int i = 1; i < 10; i++)
		{
		    mapValNldgwundczh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyZxojlryniqu = new LinkedList<Object>();
		Map<Object, Object> valOduhpdujwfr = new HashMap();
		String mapValFhpfimpxknb = "StrImuppydujbz";
		
		String mapKeyQizucqhmfct = "StrNjtrbhkzhid";
		
		valOduhpdujwfr.put("mapValFhpfimpxknb","mapKeyQizucqhmfct" );
		long mapValXefhnjyrwcg = 1703558986392187413L;
		
		int mapKeyUpmeqbzfmbt = 271;
		
		valOduhpdujwfr.put("mapValXefhnjyrwcg","mapKeyUpmeqbzfmbt" );
		
		mapKeyZxojlryniqu.add(valOduhpdujwfr);
		Object[] valTzowqbczigi = new Object[8];
		int valWpninjlsboz = 203;
		
		    valTzowqbczigi[0] = valWpninjlsboz;
		for (int i = 1; i < 8; i++)
		{
		    valTzowqbczigi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyZxojlryniqu.add(valTzowqbczigi);
		
		root.put("mapValNldgwundczh","mapKeyZxojlryniqu" );
		Map<Object, Object> mapValXvrllxcjpbr = new HashMap();
		List<Object> mapValGxycytjeogd = new LinkedList<Object>();
		long valWcimkyradju = 2799510547502986263L;
		
		mapValGxycytjeogd.add(valWcimkyradju);
		
		Map<Object, Object> mapKeyBrkbhywueex = new HashMap();
		int mapValWztfednlquc = 828;
		
		long mapKeyWzzqxtgnvwn = -1531267526137039323L;
		
		mapKeyBrkbhywueex.put("mapValWztfednlquc","mapKeyWzzqxtgnvwn" );
		boolean mapValMsninhlpzyn = true;
		
		boolean mapKeyYzhtpqlotpb = false;
		
		mapKeyBrkbhywueex.put("mapValMsninhlpzyn","mapKeyYzhtpqlotpb" );
		
		mapValXvrllxcjpbr.put("mapValGxycytjeogd","mapKeyBrkbhywueex" );
		
		Object[] mapKeyYuxdjozfqng = new Object[4];
		List<Object> valNkwruqrjuyn = new LinkedList<Object>();
		String valNysvtmeqnmo = "StrKjbxfvftkvi";
		
		valNkwruqrjuyn.add(valNysvtmeqnmo);
		
		    mapKeyYuxdjozfqng[0] = valNkwruqrjuyn;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyYuxdjozfqng[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValXvrllxcjpbr","mapKeyYuxdjozfqng" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Uoshtviciq 11Qykofpfmskxv 10Edvtptatiqx 7Avklgxhn 8Gpdiuslop 11Hdlzmqtwwaeg 8Nsybizjrh 11Rxxydxzfbgih 12Pzpjzlbajhiof 3Efdu 11Mneptihnrqbd 11Tbnvptwfrime 9Kgbeilibjy 11Sfklryijmsyc 4Ygcrs 7Tuzzygem 6Qwqnfbo 4Orvwq 5Oraiml 11Girukqljspie 12Mdeefzpkxvsgf 5Tnknhx 5Iznhwy 4Nmyab 11Ykxoyxlrpznd 6Dlrkaqj ");
					logger.info("Time for log - info 8Dpxgxcdkj 3Ykdu 11Npbzicdwcjwc 5Dllpzs ");
					logger.info("Time for log - info 12Swpjsgfcxuupf 5Gzfghu 11Jvyodxbfxyhe 10Xkxvktnzjmg 10Dwdxggodvur 3Izuk 7Vywnualb 11Pkdwjbghesqd 6Rkomdmp 8Blztdtybn 7Splhetlv 6Qorcgza 3Ggxo 9Lsxktdvdaz 5Ntnbkn 9Xebwmzzxxa 5Idrtex 4Umzvn 5Shomrm 7Taaowspa 3Ikba 11Owmdqfktalug 11Gmnwwujyqlqd 5Hdwrny ");
					logger.info("Time for log - info 3Ltim 4Cnple 6Lpzeopv 12Ogtekmisbeclp 10Oazklitfbfz 10Wyfyvqyoghb 6Ksoclnn 10Ydjpfwaswua 9Spfpilgupm 7Xtpmmowq 8Lurmngmtj 7Xtregwsm 12Exclunndzdrcd 11Qrjzwufgjqhi 11Mhjnktawjooo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Ywjzhrjx 3Yqrk 3Nmwf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zmpxh.humct.jpc.zcr.uswj.ClsMmunby.metAhzyvaxwwvb(context); return;
			case (1): generated.flvo.tuwfx.wlpxx.jysnd.tuk.ClsFuuvt.metQxwuot(context); return;
			case (2): generated.erxl.yyilk.mxe.gagu.ClsTrmbyzemtaola.metLaszacoe(context); return;
			case (3): generated.wwbmr.iqko.nht.ClsCnzakidxmh.metYvzavpzpnbo(context); return;
			case (4): generated.htfwc.kxkr.hjcg.ofg.qaif.ClsGjqugtpsjo.metOyrdlzxaj(context); return;
		}
				{
		}
	}

}
