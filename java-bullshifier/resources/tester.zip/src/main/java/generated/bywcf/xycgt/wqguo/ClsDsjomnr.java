package generated.bywcf.xycgt.wqguo;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDsjomnr
{
	 public static final int classId = 358;
	 static final Logger logger = LoggerFactory.getLogger(ClsDsjomnr.class);

	public static void metDdfotoep(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[10];
		Set<Object> valLgfvgylaaja = new HashSet<Object>();
		Map<Object, Object> valAvljzeopmml = new HashMap();
		long mapValGdobcpahqmx = 8798166904864520825L;
		
		boolean mapKeyEivhunajezu = false;
		
		valAvljzeopmml.put("mapValGdobcpahqmx","mapKeyEivhunajezu" );
		
		valLgfvgylaaja.add(valAvljzeopmml);
		Object[] valGkqrmvdbxzz = new Object[10];
		boolean valCujqqerbacp = true;
		
		    valGkqrmvdbxzz[0] = valCujqqerbacp;
		for (int i = 1; i < 10; i++)
		{
		    valGkqrmvdbxzz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valLgfvgylaaja.add(valGkqrmvdbxzz);
		
		    root[0] = valLgfvgylaaja;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Bumxggy 11Onwarwjzgrcg 6Czdysbm 12Czlcruchwreni 8Qkrgiguvs 11Tkogicwodpqw 11Jebjltqmayah 3Cylg 10Atwzougfxrq 5Eyydnp 11Uttovaqneuyg 8Iszpwimze ");
					logger.info("Time for log - info 3Mdvl 11Ehkfwerrqnbj 6Diwputy 11Ylhfigjryxwm 8Ycyejquhy 6Thszgqy 8Rorxadmfn 6Bybezap 3Ayjx ");
					logger.info("Time for log - info 9Ftktqcntrm 3Edhc 7Qerihefr 6Kywpjew ");
					logger.info("Time for log - info 6Zfgcmbg 4Tztso 11Uogjabduesfc 7Rddopfrc 7Pfmlytwy 6Bxocwwm 4Xjzkv 6Ujngxin 8Rtnwamqxc ");
					logger.info("Time for log - info 8Witwyjvdj 5Cffcjp 11Itousxwfzxzt ");
					logger.info("Time for log - info 5Ymjtae 12Gyumowuohzvoc 6Ejukmhh 7Vntpvfrw 6Uiojytn 10Egtgnqgihmp 5Lkeusu 3Rddk 3Ovob ");
					logger.info("Time for log - info 9Tzmjwilpcq 5Ddzxhm 5Coetfu 6Jvhquei 3Ypvu 6Ewmcspy 4Xegvv 5Szmerz 3Sdjh 6Qcamkof 5Jeklfk 3Hdxz 6Gsdnuju 5Waezyr 8Lcbltckvr 7Ttwrezhk 5Bvrlbk 9Icsyevlhba 6Jujrrvc 8Apzrcxpit 12Ubgqewiovimfl 9Apzhwlucjp 5Mcmgwl 11Dhqbbgdwhhje 8Ugthpzdbu 5Epkfip 4Yunvz 9Emkkmaenmz 8Mxelrohvk 7Vsotsbtu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Bryzdmyj 7Gqkgrspl 8Zpimhfhbd 6Lfhaiqs 11Uafatreiszsr 9Nvgfdxivhf 11Rifreltvyawb 9Mighzjewvv 6Dxhplge 10Welxkpzqthn 4Jaqjo 4Ztwjb 5Pmihwm 6Ultqucb 9Pmkedgyzdk 4Bbask 12Hoerikoobkxht 8Tcthtmoax 9Ihkzawauut 8Becxflgcc 6Xqvewxb ");
					logger.warn("Time for log - warn 11Cqupkatdlsws 9Iuaminztie 10Lmqorznfxvj 9Legqazfxtt 8Etxopytxt 6Vwafuvm 12Wqgnkuntlxezu 9Ibsxugdwal 5Wsgynp 3Nden 5Dgrgjt 11Fthywdalijgw 8Fvdxjfiki 11Sjjtcfjnnxkp 6Szxzlus 8Sayycbuxu ");
					logger.warn("Time for log - warn 7Dbqdgbxm 12Aomgxxjuwiyjt 10Kfccynwqkey 3Msci 5Ldatki 10Qkeoefwrjak 8Giykatmwy 9Jamppbkpev 10Roodkobwgeu 8Kdlxcxkvx 12Mboxwkhjprigb 4Xwbna 10Xcrmlzriczs 9Xwlwylpamz 7Trqzkyto 12Uvsiifkfcgrmy 4Gklea 5Hydvmg 12Jfqhmeewxqkhc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Rkixrkim 9Gnylpzxjbn 9Dnwsazqkhp 10Xkwtairimul 12Lmfsswwokvlfg 10Ervfzcrpjap 3Yyqc 3Bjtm 3Ogcb 5Rakttp 6Fayrqwb 4Aacgt 8Vfitwvcwe 3Hrny 6Fjwuzmu 11Sffagvsarerw 3Xbvm 12Uitepjxhuukxw 8Wfhagdkip 3Pwad 9Cqykosxwza 11Jhwjozaghery 4Rolfz 5Ixkmgh 5Yyqkdj 6Cvqffhk 8Qnsftskvn 3Gijz 11Qxjbtbtynrzj 5Qxfipy 12Ztcqmaikkmuiz ");
					logger.error("Time for log - error 4Gmnll 7Yoryloob 4Nwjnu 9Lawgtepjof 3Jaxl 10Faontktbdyx 4Yltxe 6Hjdrriz 9Prbzxzxizz 10Zgtipshrlyf 10Mvdlclenlou 11Wghzfweenccm 8Syymkyjsp 4Vgbtm 7Lwuqeibl 8Jsukgdwkx 11Qkhxznlttums 4Hovro 3Isog ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kdf.pknx.zlwl.ClsKeeubrxremfhhw.metOxjieq(context); return;
			case (1): generated.zuqq.dis.ClsZotjz.metPhpym(context); return;
			case (2): generated.fzi.whyx.ClsLwqmexgqswx.metOkmaagzzibm(context); return;
			case (3): generated.gcr.qqx.juuh.caxx.ClsRlelgjq.metIstdlmn(context); return;
			case (4): generated.ebdo.cied.ClsIqlmeepdcmuqo.metBfionas(context); return;
		}
				{
			long varWhbmjcjibvs = (5067) + (Config.get().getRandom().nextInt(92) + 6);
			if (((Config.get().getRandom().nextInt(764) + 2) * (2311) % 358633) == 0)
			{
				java.io.File file = new java.io.File("/dirBumvoceymjy/dirSvwladrapfj/dirMmreurpdfwx/dirJtzrvzjjhuf/dirOkkumhttcvu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((4065) + (Config.get().getRandom().nextInt(44) + 5) % 586659) == 0)
			{
				java.io.File file = new java.io.File("/dirMhsxctyrjku/dirUdlkwglobbi/dirGyjnhgtcyny/dirQwapzapfjzr/dirJpecsevlxfz/dirYugepphiprp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numRmmsgwhwdel");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex26049)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numIkwhekgvujw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metHbpetwyyyphnb(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[3];
		Map<Object, Object> valLctabotzqag = new HashMap();
		Set<Object> mapValUzwjevwvqte = new HashSet<Object>();
		int valPhzlhqnqxme = 941;
		
		mapValUzwjevwvqte.add(valPhzlhqnqxme);
		String valEqdhxplbwbj = "StrQvghbxscejx";
		
		mapValUzwjevwvqte.add(valEqdhxplbwbj);
		
		Map<Object, Object> mapKeySlzunqwuvrt = new HashMap();
		int mapValYrjawdwmyes = 525;
		
		boolean mapKeyWgnmvceseba = false;
		
		mapKeySlzunqwuvrt.put("mapValYrjawdwmyes","mapKeyWgnmvceseba" );
		
		valLctabotzqag.put("mapValUzwjevwvqte","mapKeySlzunqwuvrt" );
		
		    root[0] = valLctabotzqag;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Jdlgoxxebv 9Fymuqqdcjd 11Qjvllsujbtee 11Iklrgfcfnpwj 4Bakpj 8Doqirrvgm 8Sxusgkimu 8Znmdgrotl 7Bkorfvmv 12Wgquzamrqjbqg 11Kdjxnkumolpv ");
					logger.info("Time for log - info 11Pndobbrwtign 9Tlvnghwsgr 11Hhguaylerpmk ");
					logger.info("Time for log - info 11Ueqtexslbark 6Zkuwpcy 5Vnnilj 3Aqtr 12Witteskbwvyma 11Xeundnzqtcsb 9Saouzmfcsm 8Gevzbvtzv 4Pshty 4Drnae 11Lalkbbyfrcou 8Lqxkmrefp 5Tzxifm 6Etxmgqu 11Ecmjnwxewerm 10Bhuyjuplhui 8Zcmnvyacg 6Nilhxpy 12Lkbetblmdlmbr ");
					logger.info("Time for log - info 4Cfhft 10Wdjpznpqkim 5Rxgodx 5Uvsonn 7Imxmerio 5Srpxlc 12Lzxbfmypvobht 5Bsovxf 4Qgwvc 11Brmouokihtua 5Pnaltc 4Vbfzk 3Hmhc 11Igsajufufknr 6Kfvxqox 12Iboogdzqfesiy 9Zphsivduoy 6Xwysqzc 8Rbdtielei 7Zzvoqqqq 3Dupp 8Yjoaxfpaw 10Ulfghcbnsgx ");
					logger.info("Time for log - info 11Hewmazyaoyyk 10Ksjeqetxawr 3Ulgf 6Wbqdnac 9Cibayivkvo 7Yqeaunbl 4Iabll 8Ywaikwvpj 9Prpnyxeyfp 3Zmql 6Jssylqi 7Byscptom 7Ohnpoccs 12Hjwwvtpldpfyd 8Gtsqpshxk 12Jxlhplnhtkfpo 4Oibai 4Tryoy 10Ncgnletglma 5Cuhphm 8Timvfzjnp 7Tbxhkmwu 5Mulbbh 11Knxsbowgptcz 12Erfynitgemohe 11Ecthuwdqobop 10Lkrtecumsga 7Fxxhzzyh 8Fuvofsyem ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Oqwm 6Zbhvhjg 8Uvrgfiifa 6Rkrpvyr 5Jgiays 11Ttuhvrautarw 7Nhnfymnc 9Zhrcrvxzgu 5Cuizhw 12Iqbyhbusjgkec 4Cfprt 12Brxzybgvdzziy 5Ptiuym ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Adebdppu 8Gonkoerrb 11Aasveefejyzm 10Wexgmnqfxdm 3Qrpm 7Mvzoedlx 8Rbkuxyomw 12Yekelmxjevkwb 5Zmxccu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hzw.xclp.jagge.pvih.oqmlx.ClsBjaeoqqxwxxp.metLyljj(context); return;
			case (1): generated.juea.qhm.ClsOhhvy.metBukqjym(context); return;
			case (2): generated.ocmm.ezbtm.vxyei.kuseg.ClsUqzgoaq.metSglyom(context); return;
			case (3): generated.hor.ymu.xve.ClsFtiqqajkdixb.metBmlepaig(context); return;
			case (4): generated.ukp.wkgj.kys.bbj.whcvs.ClsShqgniemg.metRrbombfiz(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numQzkvdhzfvhz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metNwhqqalj(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[10];
		Set<Object> valVbgnysulqcq = new HashSet<Object>();
		Object[] valVqcnsdcwuon = new Object[11];
		long valTfhscchnsfm = -2053207706608552417L;
		
		    valVqcnsdcwuon[0] = valTfhscchnsfm;
		for (int i = 1; i < 11; i++)
		{
		    valVqcnsdcwuon[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valVbgnysulqcq.add(valVqcnsdcwuon);
		
		    root[0] = valVbgnysulqcq;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Pmwzvpcycuisg 10Zwpiwqiavwr 5Xmpybc 9Hhmqgncbvf 5Jykuvv 12Dlqnwztuztvfi ");
					logger.info("Time for log - info 8Gltsmkqgd 3Idzk 10Aqyqlpirtxh 11Txynapkxagvt 6Gkmzdkn 8Seajupqdk 8Efvfijsvz ");
					logger.info("Time for log - info 6Gxekpvs 3Aqxv 4Bzacb 10Wdtjqgjfkdw 12Tdlvkvqdqistt 11Mwcsdrzpihbx 5Plcfwv 9Noctqikrty 4Tktjo 5Rixerh 4Xgohr 9Rugqfglxgn 7Rwlzkfce 8Jaldtoxvc 3Fxfi 7Qkamysoj 11Odglhipujrgp 11Oyzzebycxvfo 11Ahovkejqktsp 6Rdhbctc 8Acgqflaly 10Vavwteemehk 7Bdrvifax 6Wtoeoeq 11Ghjlfkmvpncb 4Ynwtr 5Idhsde 11Jhhjnoynhbjg 3Rojq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Hynoqcrj 11Bfmgqkxhlxwi 9Jwtwlilftj 3Aogl 3Wimy 5Ykkybd 8Eiwnhipxh 11Jfnyzvonevkx 7Dtjrgztw 9Xzsywvfrvl 12Qngdqdhmsdvka 4Nevoj 8Aufzafhde 9Equhgonkgx 7Ukideteu 5Fobcuc 12Mcvalexorkqpu 10Uyftxanlzmc 9Qpqynwrjih 11Lvqnowkdnwfq 9Fdlkwqlzpk 8Egzovmvqx 9Xcngewabti 6Iidxjxp 3Tosv 8Dpghyefhv 3Zqzo 8Aeqtkdwcz 9Fxqybzlstw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Tjqgqqki 7Tyjwswae 5Dxkivi 3Aydh 5Qqyqvz 12Fhujvfdrystyh 10Vcxpqowemij 3Pvtc 10Hjcoklvvebp 11Jkurfumziphq 7Vlardjam 4Lgitl 5Nyosob 7Zpjdrluv 8Plwmnhtoh 8Titofmzvm 6Oxkzath 4Aitpd 4Ovxic 3Owtd 7Iqqbfnjg 3Raih 9Psvxxtimun 8Fasjiyyxb 5Hcencv 9Rtlhipvdan 7Pksdpdvo ");
					logger.error("Time for log - error 8Cyghtyoax 3Ssfj 8Ylzizkthe 9Knhvixkfzz 3Fwwr 4Pdjzd 7Genlqwhf 6Fhocosp 3Mnml 11Hedfactnualv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lfkk.ncy.gpf.ClsMafxzncfnwvsdj.metSxjirq(context); return;
			case (1): generated.dxq.xrcc.nnuf.jgcjn.ClsUxqzuz.metMerkfgxadscigo(context); return;
			case (2): generated.phtjf.bzplf.izqn.pznr.nxe.ClsUtlzborau.metGtnmttouutf(context); return;
			case (3): generated.gbss.lmi.dvqsw.ClsLptludgibvpvw.metZydcmbkku(context); return;
			case (4): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
		}
				{
			long whileIndex26058 = 0;
			
			while (whileIndex26058-- > 0)
			{
				java.io.File file = new java.io.File("/dirZzstcrduibh/dirEzfmdtqkfue");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex26062)
			{
			}
			
		}
	}

}
