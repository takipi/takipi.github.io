package generated.kmtdc.slqlz.nmqcy.naaq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsKsliquh
{
	 public static final int classId = 377;
	 static final Logger logger = LoggerFactory.getLogger(ClsKsliquh.class);

	public static void metYprzkjhmint(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValXynkcnhctjl = new HashSet<Object>();
		Set<Object> valSaipuwqxayy = new HashSet<Object>();
		long valZlyuhxolbdm = 7135658884884972915L;
		
		valSaipuwqxayy.add(valZlyuhxolbdm);
		long valOddspifcqzd = -2360486703259909956L;
		
		valSaipuwqxayy.add(valOddspifcqzd);
		
		mapValXynkcnhctjl.add(valSaipuwqxayy);
		Object[] valYaznakzjuhg = new Object[10];
		boolean valPkduzlgijfj = false;
		
		    valYaznakzjuhg[0] = valPkduzlgijfj;
		for (int i = 1; i < 10; i++)
		{
		    valYaznakzjuhg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValXynkcnhctjl.add(valYaznakzjuhg);
		
		Map<Object, Object> mapKeyFgfutsopihd = new HashMap();
		Set<Object> mapValNpgrtejtjuo = new HashSet<Object>();
		long valCyylhjalasm = -6628851223872627047L;
		
		mapValNpgrtejtjuo.add(valCyylhjalasm);
		long valMdedasnrykp = 5055587737480136669L;
		
		mapValNpgrtejtjuo.add(valMdedasnrykp);
		
		Set<Object> mapKeyPlbaebaaztl = new HashSet<Object>();
		int valPqnqootnufr = 880;
		
		mapKeyPlbaebaaztl.add(valPqnqootnufr);
		long valDscezfgvkis = -3310518645308928383L;
		
		mapKeyPlbaebaaztl.add(valDscezfgvkis);
		
		mapKeyFgfutsopihd.put("mapValNpgrtejtjuo","mapKeyPlbaebaaztl" );
		
		root.put("mapValXynkcnhctjl","mapKeyFgfutsopihd" );
		Object[] mapValDqeebnlmnvv = new Object[10];
		Map<Object, Object> valSprntauitdi = new HashMap();
		long mapValTjiacbsweqm = -654106880916042943L;
		
		boolean mapKeyBoyqmrjncam = true;
		
		valSprntauitdi.put("mapValTjiacbsweqm","mapKeyBoyqmrjncam" );
		
		    mapValDqeebnlmnvv[0] = valSprntauitdi;
		for (int i = 1; i < 10; i++)
		{
		    mapValDqeebnlmnvv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyRcwmmeiyhei = new Object[4];
		List<Object> valGqhadqjuhst = new LinkedList<Object>();
		boolean valVincjylqplg = false;
		
		valGqhadqjuhst.add(valVincjylqplg);
		boolean valWgrzhhqhmjs = false;
		
		valGqhadqjuhst.add(valWgrzhhqhmjs);
		
		    mapKeyRcwmmeiyhei[0] = valGqhadqjuhst;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyRcwmmeiyhei[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValDqeebnlmnvv","mapKeyRcwmmeiyhei" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Uojex 10Wzowzowotyr 5Njbbjx 7Ihaycpjm 12Yttiwikrtodve 3Ylcy 5Ezflpv 10Gslgrpglymf 12Gfbrrmjyamqwo 5Woxaxi 9Mudrxecdjp 8Ukeffulim 9Yteplefbno 5Ufvjxc 4Dcjaj 3Xglf 5Lzkxiy 3Lphm 11Brfsebviceom 11Hvuzvzpovndj 5Nyylkb 4Exizw 4Rrbki 8Rcvgrgumc 9Cqczoaydns 7Ruvzvsnh 12Osspnszwxbdrs 5Swwgnx 8Aklsnbwde 7Jfqzselm ");
					logger.info("Time for log - info 5Erursy 8Wbkcsmhut 12Ouuelvkppsdpm 8Zqizqokhh 9Mnfesxvghc 7Zsokxojj 7Lahzujra 3Lkbn 10Rwsqbpjdmpp 10Zczptqgyjid 7Ywppxjbj 7Hgvazqnw 7Zdklpwps 9Vnpnrxabuv 4Xfogs 12Sbqvvstanvesn 7Jsrnpwaq 10Jrlpwbfdwbb 9Ademthwgnf 4Gybbz 8Mmmcjdjes 10Sfmmayuromj 12Ddezdlnuvjyiq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Nbalt 11Qyvglbktevmd 8Umhxbhiwk 6Rfcihyl 7Eencevhm 5Cfgudn 7Lffdctzh 5Xweixn 6Zwudonb 7Bvjyhabs 4Bsval 3Vexn 10Shkorjnkwch 10Nwdiekibfwm 5Klmuol 4Zlhfd ");
					logger.warn("Time for log - warn 6Jzcwvqt 8Cddyenrrd 6Ewtvbox 10Rqpnssubcre 10Gnbhlewkkhk 10Mhafcldniob 5Jgtcqr 10Natbaodsbxk 8Lchlrvblk 8Nwfpskjcx 4Ymumy 9Xeebkvxjbt 7Dwceefgu 12Ilgmomzdycatm 5Csimft 7Zmsnzfiu 8Qsfgtggtm 5Zvupqv 12Yuyscykulkwzx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Krtiqbcsklfnk 8Gteskeuom 7Erwpymnh 5Omkbiy 11Shlxbfiinltr 9Lxjddxwqkh 12Yuigxfhkhfqod 5Uhwrxo 9Ioveqqodav 3Qbyw 10Sowilwckyam 4Ozmtg 5Kcqikq 11Kshtyynldvxq 6Zzkpsde 12Vmpseakxikrct 6Pomjekm 7Ckuyuyoy 5Xsxpas 10Pfzayimcedz 9Fcmergnrmr 6Gzoyyjr 4Fvlyo 6Vjyydvl ");
					logger.error("Time for log - error 8Vgjiqtruy 10Kzvyewrivtl 7Jjerwzsi 12Cesfxoyncqcdc 7Glwndboy 7Jasjydhm 5Oavkzf 5Habbjb 8Smdrkhlni 7Ubvlsmzt 5Dhsdkd 3Fsbf 3Zzct 8Cmnlceece 7Uudfubba 10Afzcdukitbp 12Bdczyxaaskexg 9Pvfuqjokot 9Qdlfajfyrn ");
					logger.error("Time for log - error 7Tegbzrgi 4Rvkdp 11Sgpwlsyglqdq 4Kxonz 12Waffyoidbrfhx 4Wwjyb 10Hbzydwpwnkn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.dyv.vxo.ClsWrwpfswr.metCedzccdg(context); return;
			case (1): generated.mrz.embg.gydr.vls.fvllv.ClsYrxhq.metSuifsjipzddr(context); return;
			case (2): generated.xqnb.haff.rrb.lurge.ygwj.ClsNrgsacrzyefzg.metXouqbpti(context); return;
			case (3): generated.alv.nmsc.bjnyq.zit.ClsUxjrwrfu.metNwxqnbhnue(context); return;
			case (4): generated.fzi.whyx.ClsLwqmexgqswx.metFhjktel(context); return;
		}
				{
			int loopIndex26391 = 0;
			for (loopIndex26391 = 0; loopIndex26391 < 7173; loopIndex26391++)
			{
				java.io.File file = new java.io.File("/dirVobmawpqvtx/dirMoouyxsloqd/dirAwkmfagipmc/dirZldnxiffssv/dirGhzlxmarems");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metNmcayldfqz(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Object[] valDwjyxonhwug = new Object[9];
		Object[] valVimpqipnnaf = new Object[5];
		long valEvwliekxufs = -5078072663275987223L;
		
		    valVimpqipnnaf[0] = valEvwliekxufs;
		for (int i = 1; i < 5; i++)
		{
		    valVimpqipnnaf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valDwjyxonhwug[0] = valVimpqipnnaf;
		for (int i = 1; i < 9; i++)
		{
		    valDwjyxonhwug[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valDwjyxonhwug);
		Object[] valXgzzcwhhtpi = new Object[10];
		Map<Object, Object> valAenregpoueh = new HashMap();
		boolean mapValOjepickqmfe = true;
		
		boolean mapKeyFstpzaodplp = true;
		
		valAenregpoueh.put("mapValOjepickqmfe","mapKeyFstpzaodplp" );
		
		    valXgzzcwhhtpi[0] = valAenregpoueh;
		for (int i = 1; i < 10; i++)
		{
		    valXgzzcwhhtpi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valXgzzcwhhtpi);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Vpizyncpkxzk 8Teozhhilr 10Szvweutxlep ");
					logger.info("Time for log - info 5Lyzjlc 6Nlwcoyv 6Msofmuq 4Vwqyd 9Ixdcyxmagm 9Fhdiejcppf 12Wejudunzlzqyr 12Odpurckpzaeds 4Duskp 6Vemxrtf 11Heubplshhtiu 11Dprxzljcwwgs 9Gujsfjeypn 10Rhugoikffif 9Grbzeoyshd 8Qvshapwkg 7Yswkhhik 4Faidw 9Xanvvzxfcp 4Lgxnj 11Allwlyskvkmq 10Bzfpdpxnkru ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Dickztnvlj 4Etxio ");
					logger.warn("Time for log - warn 3Folx 6Fsvxcik 3Uvhk 7Heuoxfsa 3Tbas 11Xagawlpsvptm 6Ejdbkoj 5Gpypjk 11Meatjrwkchlj 9Jcaablorzv 4Bhvqb 8Utcvfjegx 11Inftydxmplii 12Uekaylyskwxxd 11Eoyemdakanwt 9Jazzqjhbvh 10Vihgprcuaon 5Lwyzqz 7Xqmufmmg 12Yvranbtfmhzdu 11Wzkgwawozztp 7Yjltrsfj 4Ykxui 11Kbriaaicfkga 4Iueuq 9Bcemxkaspo 4Qvhqp 9Qepnmtrhfj 8Qwcoqoyjs ");
					logger.warn("Time for log - warn 8Tyyprqlak 4Pcifv 12Uaopnijtirjig 9Acsuinsbnu 3Cymg 6Jujyvsm 7Xuxkgbxq 11Tufshgtwvbep 8Zieerbdtr 12Mfqwwsovqloct 11Ikuofzgwojuz 7Gnzrrdkq 5Dqmfis 7Kxcpsqhv 7Nmdlrgtv 6Rhaupvh 4Egoqo 4Oiyqd 10Qvsoqbeyccl 7Aqqtecrd 4Jutwi 5Fnbxxi 4Wrceb 4Dutrw 8Pzuibccyq 5Etjlzr 3Cfit 8Gtlxdgfkr 12Gxtnwcpkqduhw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Ubcnb 6Mykwqun 11Ldxaqzunakwk 4Udcac 11Dkzsdqwssunl 9Vtrzbdrdvq 3Hlkb 11Qzhmlkuehzoe 7Llcntywq 5Thmmfz 8Gtkimdpzt 4Wwfys 9Rzroqkyvha 12Krbcdpajmdgil 10Lyifbjsichw 9Bdwvtmzfjj 4Irjxn 6Sombtot 3Rieu 10Fqsbvdxyuiq 9Mmlreajgcp 9Mbxdgrqrog 5Oymwqp 10Uahvwpkawwc 12Rjpwpglanlwlh 8Jnirfpfhm 11Irjsfcfrpitu ");
					logger.error("Time for log - error 10Tmyydsjquux 11Qiioejbqwndc 5Kprmob 4Jcufx 4Hfrnw 7Ptjcwsdq 12Ssmjfenfmsqpn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lnvho.rhfct.ClsGgdasahuvsgcd.metJmlhfumq(context); return;
			case (1): generated.iyxve.emn.dzc.ClsAggygwujkgt.metWmlfsxai(context); return;
			case (2): generated.iwmr.swhrn.ClsOqphojsm.metZpnazknfwlswat(context); return;
			case (3): generated.hehz.xzg.akn.rdsvf.ClsKsukcv.metYviizisnunbnph(context); return;
			case (4): generated.hqq.wtuo.vap.ClsNidilkbt.metWxcpfhso(context); return;
		}
				{
		}
	}


	public static void metSpfctwamvtapks(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Object[] valQyadhyygaay = new Object[3];
		Map<Object, Object> valTqdfavkjrcp = new HashMap();
		String mapValBtzzucbkevl = "StrYxleddmusyt";
		
		String mapKeyVcgxenojcxz = "StrOwircuwukdo";
		
		valTqdfavkjrcp.put("mapValBtzzucbkevl","mapKeyVcgxenojcxz" );
		boolean mapValJdknluruqol = true;
		
		boolean mapKeyYfxkivkxdtu = true;
		
		valTqdfavkjrcp.put("mapValJdknluruqol","mapKeyYfxkivkxdtu" );
		
		    valQyadhyygaay[0] = valTqdfavkjrcp;
		for (int i = 1; i < 3; i++)
		{
		    valQyadhyygaay[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valQyadhyygaay);
		List<Object> valWgwjmevxlvb = new LinkedList<Object>();
		Map<Object, Object> valIsbawllwywk = new HashMap();
		long mapValPzibrpekdmc = 4425316488073924884L;
		
		String mapKeyTuppjyaiaaw = "StrDtkqgslenkp";
		
		valIsbawllwywk.put("mapValPzibrpekdmc","mapKeyTuppjyaiaaw" );
		String mapValRaopzuffxzb = "StrLnilveuqywo";
		
		boolean mapKeyIzyrevdfkrt = true;
		
		valIsbawllwywk.put("mapValRaopzuffxzb","mapKeyIzyrevdfkrt" );
		
		valWgwjmevxlvb.add(valIsbawllwywk);
		List<Object> valGqhurzhcgbn = new LinkedList<Object>();
		long valMnvcxfhudkx = 4654149767261575967L;
		
		valGqhurzhcgbn.add(valMnvcxfhudkx);
		long valXyrrcdahlem = 8747795113843774776L;
		
		valGqhurzhcgbn.add(valXyrrcdahlem);
		
		valWgwjmevxlvb.add(valGqhurzhcgbn);
		
		root.add(valWgwjmevxlvb);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Uqvqlfjbpe 5Kxauiu 10Yrvvpqycnwc 5Dhzjwx 12Tpfckiiqwrdda 5Hgkxtq 8Tybqlvpiq 9Jdsllyjhpv 10Myudhsylyuk 9Cilvvkfgsy 10Hzbsxdgvnsd 5Bbsazs 8Ddicrznun 12Mhidfuutaowpm 9Ukshdculrq 5Fnsoop 6Cedgrsd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Wxyycxqpvfyhb 11Amqqwjltselg 6Idhkjvj 8Dheeadbbl 7Fcolurdm 7Kcxqgfkh 3Oopk 3Zkoh 3Nkzd 12Cboxhlhzrltjv 5Ymlzeb 11Xvxshfvrkpnv 7Koiswjka 3Qcsl 5Vpusww 11Olxnwccvzlwf ");
					logger.warn("Time for log - warn 4Ziliq 12Tyravumjdgxti 10Gdrjpznpcus 9Cyxzrlgere 11Kbbjfhzzhpba 3Tvzd 6Jcbeqdq 11Ceizlseyctbq 11Vrhjvmfchlfs 12Pokejwfpjjvwd 6Fblyguc 11Fhxfmxunydiv 8Bgigvjsnd 10Blxalbpuvxq 10Mgrvpoeazzl 9Hsauotkyrx 8Edbgfrigp 9Loyyzntjij 9Bcslzbercq 3Zyat 8Jwmlqfilt 10Cpqutfjbdni 6Clczwqo 5Flvhcj ");
					logger.warn("Time for log - warn 9Pfjzlaranw 7Tmxvpenz 4Xmrir 6Ercishb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Vpdm 11Iraubpnttzto 8Rgvnwbplm 9Vijlzjgffa 6Sqvrhtu 5Mkgyis 4Zqhxl 3Bqar 11Bcvmjvypxegt 8Zsrhjuwgc 12Cspzcuzmpownr 11Gutxdtnbegiy 8Thmetkwsa 8Qryyibvai ");
					logger.error("Time for log - error 10Hoiodaeukmp 5Spqvva 9Zgoyehelte 11Adtkfreknrvl 12Kwmtykhjglisx 7Igeyktnv 6Qruzogy 5Bouuug 3Anbs 11Aftsrnldgkhf 6Lkefmte 8Ehwfvbjjb 7Djxbayqb 9Ywqoqduxsj 12Wudclftwwoyqn 5Zbrpnd 6Dnwjsol ");
					logger.error("Time for log - error 5Depiap 6Ehwmtjz 6Hjuzszx 9Lemcnngvyv 4Vdwxn 9Bmojureljk 12Hydvyjqvuzihg 8Oifqvhceq 4Lzlla 12Cxiqxgndvvhyq 12Mnksthpugladl 9Upulammtjy 4Nduzt 8Rsrqlsfni 9Eswakshnth 4Hsqys 7Fewonyjr 8Xenbybdpn 4Dghmp 7Ghywioaz 7Udrgbjqq 9Euctwwvowv 10Pzqnhsywdrc 10Vpnzapzrgyi 9Vpbyqhcuwh 5Hytqpd 12Uqjxracplovyb 8Bsmnijcjj 5Sdgaar 6Ckzitwm 8Ctusqpahl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nhgg.zrfev.xud.glekl.ClsBewmjgrswbo.metWsxyvoaooe(context); return;
			case (1): generated.yckj.gphin.bfwh.sqsp.yue.ClsOefoqvazjwfl.metFjgyzxmr(context); return;
			case (2): generated.rjuw.mmbua.ClsRawvqxmhewbl.metOsciin(context); return;
			case (3): generated.rub.wtuur.cpewn.fdq.jektc.ClsLiscwkily.metFxfyfwekmvvpv(context); return;
			case (4): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metKlgcwsafmqppr(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
