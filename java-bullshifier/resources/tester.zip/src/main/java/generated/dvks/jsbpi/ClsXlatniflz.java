package generated.dvks.jsbpi;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsXlatniflz
{
	 public static final int classId = 135;
	 static final Logger logger = LoggerFactory.getLogger(ClsXlatniflz.class);

	public static void metIhawpoyjsfgfom(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valXmkazpficnm = new LinkedList<Object>();
		Map<Object, Object> valBwgupwcojkq = new HashMap();
		String mapValVinnyonixkp = "StrWnvrhqxzmmc";
		
		int mapKeyLlfozxntnvv = 84;
		
		valBwgupwcojkq.put("mapValVinnyonixkp","mapKeyLlfozxntnvv" );
		int mapValAafwqfojqik = 857;
		
		String mapKeyJgjzifnqogx = "StrAfzhddrgkcz";
		
		valBwgupwcojkq.put("mapValAafwqfojqik","mapKeyJgjzifnqogx" );
		
		valXmkazpficnm.add(valBwgupwcojkq);
		
		root.add(valXmkazpficnm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Ekzlnzzmg 11Uvswlsbrsjda 9Cbuhztwvxs 11Detujxschmfg 4Svgma 10Kdavhhckqcr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Hmmyf 9Yxafxznjcr 9Vxnykwmtsw ");
					logger.warn("Time for log - warn 8Oxtxnvcxw 4Ffjny 3Vdlv 10Yvsyxziosmm ");
					logger.warn("Time for log - warn 8Nalrranfn 4Kwwkk 6Pnurkda 9Xejgrguenx 11Btmmyroxqigt 4Sfjkq 3Bvua ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Fgcwv 6Lxppiow 6Urpxdek 12Uspozetphbpqa 12Cqowclxrorepe 7Pjrimpkn 3Qxin 8Vmvnskjzn 4Yyfmr ");
					logger.error("Time for log - error 9Pngdgcvgwx 11Ptmrscoxkkjt 7Vjtdkrmi 12Hbckrpyobgdcm 9Wptbqpdnko 11Qqkdwkpugjvt 4Nkmwq 6Swzaicu 6Aoqwmga ");
					logger.error("Time for log - error 7Tbfupnls 4Qvkez 6Ojqldfl 12Ueixikdcjgvdh 11Beluaibvqesp 7Rryxumck 8Sntbwhzzz 6Ksrkjah 11Krhoqappmpon 7Hpzitegl 10Mrcspwgdwye 8Zfmoipqdq 4Otjxv 7Adubpzhl 3Sjzi 12Uzzsxlkvabrlz 10Usibsssrwqy 8Lnekerjzf 3Vxbk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metEwxuvzwhpbpte(context); return;
			case (1): generated.hdrlt.jxdm.bjqs.pupxs.ClsZoyaigxdyb.metPxkgu(context); return;
			case (2): generated.gbss.lmi.dvqsw.ClsLptludgibvpvw.metJevsr(context); return;
			case (3): generated.loe.helvz.umzz.ClsSvkkzn.metHczavlj(context); return;
			case (4): generated.cxoq.hzjj.hhxu.ClsXfvidhbawjojdu.metGjokxistgrq(context); return;
		}
				{
			long whileIndex22458 = 0;
			
			while (whileIndex22458-- > 0)
			{
				java.io.File file = new java.io.File("/dirZnxojufowxh/dirAsmehykinjn/dirNfdbogbsazt/dirUdvytwkqmwu/dirOgvvzlzjacb/dirDiavjrzqond/dirXxabnzgxtii/dirBishmlobigk/dirDhlmkxsdrpv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex22459 = 0;
			
			while (whileIndex22459-- > 0)
			{
				java.io.File file = new java.io.File("/dirSmgasdljhen");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
