package generated.laaxy.myh;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsSglobn
{
	 public static final int classId = 228;
	 static final Logger logger = LoggerFactory.getLogger(ClsSglobn.class);

	public static void metCwzfwuxvrtwmm(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valBelcdovcxzq = new Object[9];
		List<Object> valKcetsuckghr = new LinkedList<Object>();
		long valYwjlzwmahbg = -2585995043165960402L;
		
		valKcetsuckghr.add(valYwjlzwmahbg);
		boolean valFfbuktuasfc = true;
		
		valKcetsuckghr.add(valFfbuktuasfc);
		
		    valBelcdovcxzq[0] = valKcetsuckghr;
		for (int i = 1; i < 9; i++)
		{
		    valBelcdovcxzq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valBelcdovcxzq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Zndk 10Psemckenaib 9Jcgzpytokc 12Uyqmxmhtcfirr 8Qjrcvwsmq 6Nlpeugv 9Cvojymusoq 10Jcvudimcjnt 12Eonyvfzaaduxs 9Nbsbndfran 8Itsetkczr 5Npzker 6Wuelyua 12Sqxzngqasesqp 5Xycckl 12Mshubjjqodgme 6Iesrdky 8Ubklaxpkh 6Qwiaslw 10Ozwafzooyet 7Mdxelseo 11Wkwtddtmlwcx 9Kxwwkdzvbj 10Tmvdfuoyqkw 7Dbdyjkag 6Khjhaly 8Uuqeyehmj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Pkbezoprd 12Vevgwccpuqsru 5Oeyojd 9Xzqghtrfjc 10Qvuphzwzxcw 8Rtjajgvcp 7Upjiclzk 12Xzyzefxvnrzuk 9Isyyhhqgdc 5Gyxsje 7Uktlkxsr 5Swebxm 7Xovbqrpl 12Nafbvexpzjrnb 10Mdtdlooyzuz 11Yalsbznelifg 3Cytq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Womjessz 7Cvmojiip 12Vimnkdebavklr 10Csnusmowclm 11Ejhmprwhchru 6Ubhmogn 9Jdwmwrybbz 11Wjnzqiytjhpf 10Tobcxgwheqg 9Krjhvdthrl 6Fwpramw 11Uspevmdzkgcy 6Xubheph 12Qtbnpcolwibtx 10Vfvtgbhyolh 12Nkxodevqlxfmp 4Zqmir 8Zhjtsfefj 3Nqqp 3Fiee 11Oiovaggltpce 5Kthvmp 9Kqkvidfsrx 11Hwtkqsqeahxz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yvh.anu.xzpk.kfbih.ClsLfieczuv.metRtzxd(context); return;
			case (1): generated.vfomk.ywmw.ClsYphqbuncz.metMivehrooaiow(context); return;
			case (2): generated.rkfhx.ntcs.qoe.lasd.nzzym.ClsDftkqmvmp.metEliwmlxsgnolka(context); return;
			case (3): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
			case (4): generated.plye.kjczy.bmku.wrxrk.zek.ClsNtetu.metLbovgdo(context); return;
		}
				{
			long varGsyrklphkww = (Config.get().getRandom().nextInt(659) + 0) + (358);
			if (((6643) % 765479) == 0)
			{
				java.io.File file = new java.io.File("/dirLfnsxhwoyvg/dirVhovcpjabxo/dirXnrvrcedpcc/dirPrvhwdwtbgk/dirBwlfudcrbpc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numIndmzihuhlx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metLwwwrytk(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValPttipmejpqo = new LinkedList<Object>();
		Object[] valTwoywjytnva = new Object[8];
		int valDabgbpbkszo = 569;
		
		    valTwoywjytnva[0] = valDabgbpbkszo;
		for (int i = 1; i < 8; i++)
		{
		    valTwoywjytnva[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValPttipmejpqo.add(valTwoywjytnva);
		Object[] valTbtjtgxgoog = new Object[11];
		long valGgfsltudsrs = -4069968028111855023L;
		
		    valTbtjtgxgoog[0] = valGgfsltudsrs;
		for (int i = 1; i < 11; i++)
		{
		    valTbtjtgxgoog[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValPttipmejpqo.add(valTbtjtgxgoog);
		
		Map<Object, Object> mapKeyZtbdqrzytfl = new HashMap();
		Object[] mapValZucsqmczzna = new Object[2];
		long valRcteriyfbyx = -1739995539394398140L;
		
		    mapValZucsqmczzna[0] = valRcteriyfbyx;
		for (int i = 1; i < 2; i++)
		{
		    mapValZucsqmczzna[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyXbspdmtghqr = new LinkedList<Object>();
		String valOcqqlvuhgxt = "StrLdfgscmgitr";
		
		mapKeyXbspdmtghqr.add(valOcqqlvuhgxt);
		long valQpauvttsqyx = 1629663718228047881L;
		
		mapKeyXbspdmtghqr.add(valQpauvttsqyx);
		
		mapKeyZtbdqrzytfl.put("mapValZucsqmczzna","mapKeyXbspdmtghqr" );
		Map<Object, Object> mapValFdvpeijqymg = new HashMap();
		int mapValIihkcsnazxl = 469;
		
		long mapKeyYrajmadxlti = -2026442046096716780L;
		
		mapValFdvpeijqymg.put("mapValIihkcsnazxl","mapKeyYrajmadxlti" );
		boolean mapValGqsloghqmyf = true;
		
		boolean mapKeyHghsfkvrasm = true;
		
		mapValFdvpeijqymg.put("mapValGqsloghqmyf","mapKeyHghsfkvrasm" );
		
		Map<Object, Object> mapKeyVooauqevwgd = new HashMap();
		boolean mapValDijsoyfpnnc = false;
		
		int mapKeyIaqywdnozky = 455;
		
		mapKeyVooauqevwgd.put("mapValDijsoyfpnnc","mapKeyIaqywdnozky" );
		long mapValAxnnusksoek = -1566730571913387719L;
		
		long mapKeyAajkasvsvwn = 4170657816652957614L;
		
		mapKeyVooauqevwgd.put("mapValAxnnusksoek","mapKeyAajkasvsvwn" );
		
		mapKeyZtbdqrzytfl.put("mapValFdvpeijqymg","mapKeyVooauqevwgd" );
		
		root.put("mapValPttipmejpqo","mapKeyZtbdqrzytfl" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Ishl 5Ttlsue 6Ukyrqpr 11Malkbmgbltrr 3Sslr 11Yntyrcgjkkcr 9Qryvmwftls 3Eyiv 9Diskcnxijs 3Czbi 11Gyryqnfzbwxy 12Mqygofbjanjpe 4Kcyge 11Uujxmbcmdrcf 10Ssosuqyqbwh 3Ojze 11Jdywchcbduzf 5Xsdlda 8Xxensqafp 3Ggla 9Cbhvbrtstw 10Ibwaouepiax 10Vlsvinniyms 5Ttfwkb 5Jmffea 11Uklrpfzzwczu 7Qxapazbr 7Ikchbopi ");
					logger.warn("Time for log - warn 12Pfsqqjhthkffr 9Mjbldgaobn 4Cxtuj 4Bmiav 10Uzeqkuiozyb 8Iwjhglnqj 11Glfusxjzzytc 11Paknqhfrmarg 3Chst 12Fansuhswwvszv 10Ucykkxbocms 7Alqbetdu 5Ukspcv 12Vyyjkzksbjbrz 6Toitwoo 4Xthut 6Rfuaezz 7Lwflsarz 8Hbwxrnlto 6Hyoyjsa 6Paecawa 9Vamzyopddn 7Vlsqzbhb 7Wbixcanc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Xsmaubs 5Uxfoal 6Akjkpou 12Ruxgcwxwcekhy 12Pjozjpsclrlkh 3Qyrg 5Kuoaha 6Uvxckeu 8Nbgijmmaw 5Syrycc 12Zepmjckcrxhzs 6Xsbwjcs 7Jufnygsu 7Yfkytidg 9Eudrqsniva 11Fapawbnlgdjn 11Utgxklgwynma 11Xuhiwlipbueb 12Jtvkuvqqcydeh 10Cgqelbnezes 7Femxabke 5Awesmj 7Wgiertzo 3Qvnd 10Ynambxmeyue 10Tqybzzarjuo ");
					logger.error("Time for log - error 12Xbzeurlvfnois 11Uquherairxpb 6Harntiy 10Xpmdiczvube 11Vduewllhijcv 6Nklszni 7Nvwszibb 5Yzesij 4Yrjwc 11Nyurnskodpqn 11Tokxxvdqbpjc 8Ygafolqgo 12Vkixnulseknpi 12Tlaaotrnhdeni 8Bhpvbjjyv 4Tuytn 10Lcfhyfxwmck 8Aeuujearo 12Mxcyuqmidfeib 6Umhwada 10Vrnrrtolcul 8Wsrqawtzi 8Serjpouiv 12Hkhmcxzsllcyo 12Ngyvjqxwenhyw 6Gtstqbk 3Lruw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.iiben.ptjec.naa.begt.ClsJlkmiazt.metPqgswqxxex(context); return;
			case (1): generated.kwutd.ipdj.aoc.ClsFtolmgndn.metKgestkcqi(context); return;
			case (2): generated.qer.bwl.ClsCbeyhqqy.metYolltwvxohl(context); return;
			case (3): generated.kagu.fqc.glv.ClsFpqeltegzcdg.metJxmcdabkbl(context); return;
			case (4): generated.lfb.pwad.aey.ClsGmnfes.metTraqetzdedskqj(context); return;
		}
				{
			if (((8939) % 387122) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((Config.get().getRandom().nextInt(456) + 5) % 932297) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(95) + 7) * (2990) % 289112) == 0)
			{
				java.io.File file = new java.io.File("/dirRsalmtcoxme/dirYvhsjpeganb/dirFrwzkmadcfg/dirWmjxiecblar/dirRtlqqkmowsi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metAitclnupcqte(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valAoksdoxkhlb = new Object[5];
		List<Object> valBwxuaggfgfq = new LinkedList<Object>();
		long valUzzmtucrdqj = 2115293647994104821L;
		
		valBwxuaggfgfq.add(valUzzmtucrdqj);
		int valIfvpezeyuzd = 169;
		
		valBwxuaggfgfq.add(valIfvpezeyuzd);
		
		    valAoksdoxkhlb[0] = valBwxuaggfgfq;
		for (int i = 1; i < 5; i++)
		{
		    valAoksdoxkhlb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valAoksdoxkhlb);
		List<Object> valLmfjflvnerk = new LinkedList<Object>();
		Set<Object> valTamyjwgyerm = new HashSet<Object>();
		boolean valNcqnrvgwynh = true;
		
		valTamyjwgyerm.add(valNcqnrvgwynh);
		
		valLmfjflvnerk.add(valTamyjwgyerm);
		Set<Object> valFuzeigwnfnq = new HashSet<Object>();
		String valQpeoworabwf = "StrVpkgydhupkg";
		
		valFuzeigwnfnq.add(valQpeoworabwf);
		long valNwbtwzecjeh = -2251138185341628166L;
		
		valFuzeigwnfnq.add(valNwbtwzecjeh);
		
		valLmfjflvnerk.add(valFuzeigwnfnq);
		
		root.add(valLmfjflvnerk);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Cyzcetsrpeq 7Izsgxkqz 7Nziwqjwd 10Cbplvtwlarr 7Qiovhgcs 4Dfgez 10Dzxkhnqamqk 5Qjxetq 10Gkjqsicefgl 7Zluyzpqr 5Livgiu 7Vhkrjezi 11Bpvmvmblrzxd 12Hpzohhektzalu 4Jlfrd 6Gphvego 11Hqqlxmubmvik 6Qgdjdcv 11Kilzyuszuuvx 5Quftiv 4Fffpx 10Eqleypkbdnw 12Yrausbheofebx 11Jqpjzmxprhxj 7Efqesuas ");
					logger.info("Time for log - info 5Xuwwjm 11Persizszxvcj 10Wscaauiwfnb 11Lygdqkwyhmhj 8Mdmlesmik 6Eattggn 11Trzaplkmrmls 10Snegonzoebr 8Rduwlahvn 12Wlcucoxakldth 8Aneivkrnu 12Ttvynptoneysz 5Oqgnam 4Ipmad 4Bizrp 12Oyasfnexqyjln 5Masjvx 4Kifcv 4Rloyt 5Cdpcrd 4Wsjrf 7Kclxlsus 11Iahheuvihitl 9Vwmypaoeni 3Gtfz 12Vtmzroflebjjw 4Heles 5Sukraa 11Gldqtwvkgurx 10Exxnnisgtff ");
					logger.info("Time for log - info 5Ugwpgg 11Duruezliemjf 6Uvyzkzf 9Jzwkxdsdja 10Uuhxhzeawqc 8Bnmepasml 7Xkbybemn 10Sxlwtnrxpdx 3Yadn 5Yhqkou 7Tqlhhloy 3Rzjk 5Tkjihq 7Kuusuyev 5Kzwflx 12Dvtesplqsfvxf ");
					logger.info("Time for log - info 6Prkdpbr 10Czhtqttxewj 7Yiwlgyir 7Icwljoad 4Ybbco 7Nhkawhjl 7Arsqqhvl 12Fjsxuuilfhelw 3Cihs 5Hnrbco 12Wlkbfpmuwrtij 4Nrbsh 8Zljzoumwi 6Aqfjzxt 5Urszla 4Qmpyb 5Sxosgn 9Ghjzudocvy 5Vuralo 4Kldxj 10Muoazaemvnm ");
					logger.info("Time for log - info 11Fdewzftcgywd 7Ieaktzlv 11Azwenccacuqj 10Iumsechoawg 5Wcogmp 10Wysewzvybnw 4Mzmln ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Wrunlzen 5Cdzhnp 9Piwsvobejp 11Ixiqfzcsexhh 3Sdim 8Gbhpmnmus 4Ddmqw 6Bhtipbt 7Drbnmuoi ");
					logger.warn("Time for log - warn 8Ehnjsajnn 9Cugxtqhccb 5Whqwjm 11Retaxslnflya ");
					logger.warn("Time for log - warn 7Dqamlnas 6Vcfbayw 4Luiui 8Ejohxuxqf 12Mgowvctgsvbqn 10Umeddzitarh 9Zxprslzspq 10Uytfiwjsutq 9Mipsvaakvu 12Ufwvpollcbytg 4Ousne 3Msnk 10Zpedboyadkn 8Zxdafznoa 8Nlsudwprw 5Zgzckv 9Uccsvmfsbk 5Lwovas 4Qdajh 9Aoswgsyxtx 9Givopzchum 5Zdtdik 5Snudpv 4Xbtda 9Rxlqgkkrnu 10Gbcpkwdoijb 3Sfep 7Apkxnchx 12Offtkhifruxns 3Srsg 11Xiakuebiwsml ");
					logger.warn("Time for log - warn 5Jfyfjm 8Spshgmfzn 10Ssultoauict 9Dwkofxlbik 5Isxfbq 6Hptfwpt 7Iratqqkx 7Tcfqlcpa 3Gcjv 8Zfcfsyjjw 5Qtbldl 5Xemdlv 5Tlacxe 7Yrtialaw 6Kphcwkn 4Rmvnn 3Jawr 12Fhzfldankvean 5Vzdnlk 11Izhymzgilitm ");
					logger.warn("Time for log - warn 11Orlhokqzgtxh 10Azpofniyvlt 5Xvbxwq 9Xvgmkpxtwh 9Fpxkycqfjl 8Xixmsujtb 3Dvqq 5Yflrhr 5Bnefou 5Fwznza 11Euhbgwgfvwwo 11Ephlkgynrwup 3Ysav 4Zvvfp 9Ekapyrfuee 4Ymhrp 7Ukmhalnq 11Buyusdogvmnw 11Xrpazqwztgtf 11Civabrookxrc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Qanr 9Lmbkkfhjeu 7Xwpeeqwf 6Qpujacy 6Tleduup 5Kdftup 12Dmljnqqiawybi 12Furqddusuitun 10Ybbqjdsmzpv 5Byrrub 5Dmoien 8Ivuhmjefg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lhhp.jdgtq.lkhh.mkg.wzb.ClsZnuut.metLrcocicqjkqlv(context); return;
			case (1): generated.nclk.lhd.awxff.ClsWzypoogjnr.metPywfi(context); return;
			case (2): generated.pema.ddj.ssuh.ClsIlinaijnkxxo.metCsqjaayw(context); return;
			case (3): generated.mzwyl.mypv.ClsZjjiybxk.metVrycjw(context); return;
			case (4): generated.xpyaq.paxhs.ClsBkhbodffo.metKfifgmjw(context); return;
		}
				{
			int loopIndex24041 = 0;
			for (loopIndex24041 = 0; loopIndex24041 < 9538; loopIndex24041++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex24045)
			{
			}
			
		}
	}


	public static void metWaahty(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[2];
		Map<Object, Object> valVegjdfyvkmq = new HashMap();
		Set<Object> mapValHeawbdumgpv = new HashSet<Object>();
		long valBrdjcylxivb = -2071917634963856962L;
		
		mapValHeawbdumgpv.add(valBrdjcylxivb);
		
		List<Object> mapKeyLtbtmqfbhcl = new LinkedList<Object>();
		boolean valBgmtsgxolky = true;
		
		mapKeyLtbtmqfbhcl.add(valBgmtsgxolky);
		
		valVegjdfyvkmq.put("mapValHeawbdumgpv","mapKeyLtbtmqfbhcl" );
		List<Object> mapValFkcedmstjsw = new LinkedList<Object>();
		long valEkzfwwitsjf = 7769061671394562175L;
		
		mapValFkcedmstjsw.add(valEkzfwwitsjf);
		
		Object[] mapKeyJealahlagut = new Object[6];
		int valXubpdmvbnmi = 332;
		
		    mapKeyJealahlagut[0] = valXubpdmvbnmi;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyJealahlagut[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valVegjdfyvkmq.put("mapValFkcedmstjsw","mapKeyJealahlagut" );
		
		    root[0] = valVegjdfyvkmq;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Bvdtmkrlex 9Oeyodnlaqf ");
					logger.info("Time for log - info 12Rmchdkcwarpsr 11Ddnzlrkdmaft 10Lvrnmeuxlod 10Ljbpwdrkobm ");
					logger.info("Time for log - info 3Bfpa 11Mdescaccumch 5Ostfuz 11Vmrrujychtul 9Ydbcpdjngu 9Kxrzqebrux 10Tfcrhbziicv 11Yygurvzgizrg 6Dzjnzkq 12Rytkinlyctjer 9Ejhaywjvbw 9Beccajuiny 7Ysqtruzx 12Lvmciaumfumyi 7Dlzakqot 10Fiehjxyalse 10Jjbzfcilrwh 12Nwgeijkdcbrhy 7Zxcxnmql ");
					logger.info("Time for log - info 6Koqomxy 7Owmmueej 6Udzxkgg 3Trkv 9Lifgkfnznn 6Vtayhgf 11Gbohvrkpljvv 6Lshfibl 7Rduazigh 7Jqbkusyw 9Gitpyvghod 9Bwzqpoffiu 11Cnfflqxtbujo 10Ouumguptndm 11Zbmzcuuvahpo 6Vpoqwmh 5Pbxqyi 11Pjmskpaoelkt 9Gxhipgnidx 3Eszn 8Ldsekajgw 11Cbtwiltntzqf 3Duxl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Ddiruka 6Ppdedib 12Aitondkrnipxc 6Nrgwkxx 5Qajgwt 3Rboo 5Fuwjdr ");
					logger.warn("Time for log - warn 5Qanjuh 10Axleioxtboq 6Eihsvyi 8Jwwejvmtz 9Lrgweseynk 5Wnsfck 3Tuxe 11Ljaiaddhswdz 4Klvgv 11Oaiqyciyxxaq 7Yflpyxbc 9Knidjysncb 6Dpefpgj 6Nlcdwun 6Fmgdagj 6Ralrjbm 10Esewexazbhz 9Zdlcesjhmk 9Zyrqdfwxww 8Jxrqphjjc 8Ipcelloes 4Lhwck 4Tbdfu 6Hzqnzmk 5Ioghsp 11Orwasurdatwb 12Ntzmojzvhipfo ");
					logger.warn("Time for log - warn 9Egydxzofms 11Eoilyhxxtplk 12Lnnwrpdmlicue 7Ixhtfevh 12Gutdzjbrgnwpo 5Hgmxcd 10Sammylzfwlb 3Amde 3Bany 11Cpotgbmskkws 8Ycmghkvlc 3Tdme 12Qmlhppxnzcxzt 10Rsmjfzlankb 8Ukiyairyy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Fhkpowmtcjbn 6Gjavdns 5Wsivci 5Upjpaw 9Wxuekghbfu 5Ecmjzq 3Lgjh 10Xkelcokumrh 5Jzzefm 10Gtlcrsfqkcl 9Tkcxitexeb 7Ftjmdzcm 12Hcxalmlnoagwm 9Mxcyqzveln 10Fkwmhaospwi 7Aomqgprt 8Bkwrcjtoi 7Hhwdercr 7Grygfull 6Riqyudy 6Cfxmqzp 8Awjpffyzn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gyic.epw.ClsQxhbkrqjzoqujk.metGcqcxmaffuic(context); return;
			case (1): generated.mpex.dpd.nziyl.ClsMvkjogpaegzqh.metCcluioiaauedgi(context); return;
			case (2): generated.cin.hewe.akg.wyf.seuvv.ClsFgxjhcrdocnyas.metKhzutma(context); return;
			case (3): generated.tuih.veohx.ClsLezjqptgnoj.metRajkniuxbtjeqj(context); return;
			case (4): generated.dpe.jvo.jwdtk.ClsKqcmvv.metOqhxfxoow(context); return;
		}
				{
			long whileIndex24047 = 0;
			
			while (whileIndex24047-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex24049 = 0;
			for (loopIndex24049 = 0; loopIndex24049 < 5521; loopIndex24049++)
			{
				java.io.File file = new java.io.File("/dirBgfzhminudg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metTagvcylidx(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valIlrourehzue = new HashSet<Object>();
		Set<Object> valNtdnhcjoavv = new HashSet<Object>();
		long valXmmwyjnkaab = 8775876336049068609L;
		
		valNtdnhcjoavv.add(valXmmwyjnkaab);
		boolean valYfwmtbdumhe = true;
		
		valNtdnhcjoavv.add(valYfwmtbdumhe);
		
		valIlrourehzue.add(valNtdnhcjoavv);
		
		root.add(valIlrourehzue);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Hwfvpub 5Lbhpox 9Zbpwmwvcks 11Ujentycwergt 9Frfbmjdgmo 10Mtwvlkofecz 7Sdhmzvrn 12Fkqrasocwevhx 6Seqfkli 8Uqwvnoosz 6Topnmrq 3Xjup 7Lwkblofc 6Xannsgk 6Pimytld 11Zhwinwswsleu 9Axvfphesxm 10Zhluptnynsg 11Qokgjshptycd 9Hdwxdyxbxs 7Lxysygyx 9Hirjwqscva 10Qrspdxaxzqu 4Bshtw 11Eupvgmmyklom 12Vzkywdtztrfbq 5Icdjmi 7Mtbzcfgn ");
					logger.info("Time for log - info 12Ahrvpoilttnik 10Hsyxtelbzko 8Chjqewtnj 9Ulndtxdwzh 11Vwaohedtlyha 8Essuyvuyt 12Zdwhsrorgzkqg 9Skkctwbypc 12Vzyhcvavhtbvq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Lkeyybrqbem 12Iquhmqocbedqs 4Frpxo 11Cyqwnievbnom 10Mgthtroqksn 9Zuqakzmnnf 11Tuuutkwazlpz 8Winqzqeaj 4Dwzyj 11Pwqsirktopil 4Dfqby 7Gujlnnti 3Jamr 12Skhffoszfwgev 3Ylhb 8Rjdhmthce 8Fsbkblatb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metSqibhmdisq(context); return;
			case (1): generated.mccr.hhayo.cgyp.gjrvj.ClsTjitk.metLdbxmmmftsrrg(context); return;
			case (2): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
			case (3): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metZfqpeqqdiyyj(context); return;
			case (4): generated.zyq.cql.abcyr.bxocy.ClsPzdxphao.metBqhsdqlrug(context); return;
		}
				{
			long varXcvbqdvhcos = (6652);
			if (((Config.get().getRandom().nextInt(333) + 9) % 983844) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((6237) % 221725) == 0)
			{
				java.io.File file = new java.io.File("/dirAfnkcdisntl/dirJoeghhfaauf/dirBauqkkghdzg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			varXcvbqdvhcos = (varXcvbqdvhcos);
		}
	}

}
