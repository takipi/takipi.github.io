package generated.cpb.wnddu;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsLvopzbmgvjj
{
	 public static final int classId = 493;
	 static final Logger logger = LoggerFactory.getLogger(ClsLvopzbmgvjj.class);

	public static void metJpplktwh(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValAvugdoevrva = new HashMap();
		List<Object> mapValZgpkxsjghcx = new LinkedList<Object>();
		long valYlnlsngooxw = -7654264307413682884L;
		
		mapValZgpkxsjghcx.add(valYlnlsngooxw);
		
		Set<Object> mapKeyNmuhkrxohqy = new HashSet<Object>();
		int valXvpvmtctplh = 836;
		
		mapKeyNmuhkrxohqy.add(valXvpvmtctplh);
		boolean valAzqhdvpwnfr = false;
		
		mapKeyNmuhkrxohqy.add(valAzqhdvpwnfr);
		
		mapValAvugdoevrva.put("mapValZgpkxsjghcx","mapKeyNmuhkrxohqy" );
		
		Set<Object> mapKeyFykhsxrztah = new HashSet<Object>();
		Map<Object, Object> valCijdpgiqbmy = new HashMap();
		boolean mapValKohnspkofvb = false;
		
		boolean mapKeyOmspjxvgjiu = false;
		
		valCijdpgiqbmy.put("mapValKohnspkofvb","mapKeyOmspjxvgjiu" );
		
		mapKeyFykhsxrztah.add(valCijdpgiqbmy);
		Object[] valUkrfktjqsui = new Object[2];
		boolean valWwlnmzxcsvw = false;
		
		    valUkrfktjqsui[0] = valWwlnmzxcsvw;
		for (int i = 1; i < 2; i++)
		{
		    valUkrfktjqsui[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyFykhsxrztah.add(valUkrfktjqsui);
		
		root.put("mapValAvugdoevrva","mapKeyFykhsxrztah" );
		Map<Object, Object> mapValUjhsupgxlcm = new HashMap();
		Map<Object, Object> mapValRjthqhpstcx = new HashMap();
		boolean mapValGnearonauls = true;
		
		long mapKeyBnzhumthdzr = -2338258715356324836L;
		
		mapValRjthqhpstcx.put("mapValGnearonauls","mapKeyBnzhumthdzr" );
		boolean mapValCcdtqvkckiv = false;
		
		long mapKeyKimggeawifn = -1613646184159275210L;
		
		mapValRjthqhpstcx.put("mapValCcdtqvkckiv","mapKeyKimggeawifn" );
		
		Object[] mapKeyTozhvkeyspb = new Object[6];
		long valVbrdqtjhnnt = -3845533940366051670L;
		
		    mapKeyTozhvkeyspb[0] = valVbrdqtjhnnt;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyTozhvkeyspb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValUjhsupgxlcm.put("mapValRjthqhpstcx","mapKeyTozhvkeyspb" );
		
		Object[] mapKeyKbaimeunjqp = new Object[7];
		Set<Object> valSncctwkwswx = new HashSet<Object>();
		boolean valWiexxmsmsxc = false;
		
		valSncctwkwswx.add(valWiexxmsmsxc);
		
		    mapKeyKbaimeunjqp[0] = valSncctwkwswx;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyKbaimeunjqp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValUjhsupgxlcm","mapKeyKbaimeunjqp" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Zjxs 11Dpabjqjvdcui 11Bslxdpkoalod 5Umgnrm 7Rappjrrx 7Jlhjnjmf 11Fynwsypzwmkj 7Hycchper 5Qejqlh 12Obndldjznimlg 12Ucdzhvrjwycnk 7Xcoxkcnb 12Vkcspchzfmrux 12Zdmgyginvucep 11Kvczlafgfoyp 12Vzispgalirwzx 10Zolticugwcz 4Zrhrq 7Wodfqwrb 3Kmtv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Vciuyfovudjb 5Fztjxi 4Zvrch 5Badmjf 12Nxusqwoydvjox 10Qgryrcxqqru 12Klkgaisxrqirq 7Vnginyfr 6Duyxnwy 8Lyeeisyes 3Qreu 5Tdvoqq 7Yhkhkkjd 9Anxefuwxhg 5Oeegdl 12Bxwykfudbpjwz ");
					logger.warn("Time for log - warn 12Cihfixnidimcq 5Evkgqo 4Oscpz 5Nqlksi 12Xglrodcvtzgdj 5Bxbvdg 3Lick 3Ejjz 9Lscnqyjcbn 9Ikvdxuzdwv 3Cwyg 5Xicydl 7Kuskaclg 3Grku 10Yadalkjuwgx 11Nkyxjedcuzzp 5Mypvfa 9Wjlzynmdlb 3Nguk 10Ebosyslguhx 6Sxmhskq 9Zikgwgmwjh 9Ccuqugdqjq ");
					logger.warn("Time for log - warn 11Lyeeehpjbezc 6Bcdznxq 11Aiwxivzziqqb 11Zwtmfhwguwor 8Avaffdvio ");
					logger.warn("Time for log - warn 6Vzstvvb 4Sgppt 8Ljkbpcdlk 3Utfp 11Zvwxmfwaofug 12Eckgywlcfybte 7Npvpvmhv 6Tawhxpu 4Tdfoj 10Kolagwkfepj 5Rduqau 6Esykytn 12Undnwnytftmzy 3Rjvr 4Xuewe 8Cthivftyd 8Cqkwyuuvu 8Zjojkcdzr 5Minmpe 3Tvfd 3Fgsa 4Oefng 4Mzwjl 6Dytmdzj 12Dqjgjvgzqldts ");
					logger.warn("Time for log - warn 11Nglntjtukzip 6Xtdodyr 6Cjypjgg 10Wromrzutnig 4Ovyvk 5Dbzkmi 3Smgo 5Jwzzkw 5Pycynp 12Zjlyvgtwogcgc 10Niucyzhrcsk 5Ogbgts 9Mmmdukvoow 9Tuitzfzgmz 7Ebzdshbf 9Vecqrnpbpa 11Xjtdzlrsshdm 3Bsgc 12Vqxozgvajkcvv 7Odqnasfr 9Umfokgryex 3Jxcx 10Anrudfzxncx 10Owkntsikncu 9Nvaninllub ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nrqfo.bwabb.mnp.ClsTzkbgaawvon.metKhackx(context); return;
			case (1): generated.zuj.yzx.nga.pvup.ClsJyskqhfglgbk.metUwrvr(context); return;
			case (2): generated.hor.ymu.xve.ClsFtiqqajkdixb.metBmlepaig(context); return;
			case (3): generated.lraiq.fcmvy.qwp.rkzex.eokht.ClsJupuz.metVmcuy(context); return;
			case (4): generated.zljq.wuqwj.ClsEloxjpaim.metYpqwrjj(context); return;
		}
				{
			int loopIndex28313 = 0;
			for (loopIndex28313 = 0; loopIndex28313 < 520; loopIndex28313++)
			{
				try
				{
					Integer.parseInt("numDomibgyhnhf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
