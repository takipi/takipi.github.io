package generated.oucap.zcbrm.jbhm.yte;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsEpzgpbjqjhr
{
	 public static final int classId = 332;
	 static final Logger logger = LoggerFactory.getLogger(ClsEpzgpbjqjhr.class);

	public static void metNxbcwnp(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valVwtyxzamrac = new HashMap();
		Map<Object, Object> mapValCmqtfhnkvma = new HashMap();
		String mapValNliaimwffri = "StrThuzdrkvihd";
		
		int mapKeyNhllyfkmogv = 289;
		
		mapValCmqtfhnkvma.put("mapValNliaimwffri","mapKeyNhllyfkmogv" );
		
		Set<Object> mapKeyDrnxlzkmbdx = new HashSet<Object>();
		String valRnjigysmbsl = "StrSysvuweuqxa";
		
		mapKeyDrnxlzkmbdx.add(valRnjigysmbsl);
		
		valVwtyxzamrac.put("mapValCmqtfhnkvma","mapKeyDrnxlzkmbdx" );
		
		root.add(valVwtyxzamrac);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Gmwj 9Obzquxgldv 5Tcxfmm 3Pvfb 9Xpkavsueah 3Hurs 9Yzxwciqkow 11Mkhjetzfxdlc 4Jlwka 11Qivshzvlbyza 3Kgut 9Msgvqbgyuj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Pwomiendfal 3Nfsz 4Lpcpd 7Hvutsrlm 7Zckbfrim 8Hianumnfd 8Hylisrclg 12Emprmzjntsexf ");
					logger.warn("Time for log - warn 4Xwwdx 8Zuxdhftbf 9Xqxazrcusp 11Urzaxrtumaho 8Zomdufuhc 7Ocdvifct 8Aipqqrnrg 3Fodh 5Rukvgy 12Armngpqycwafn 7Ziuqwaxx 10Hpeozyskoii 10Sfeegkekvlg 8Txlkvxtyq 4Gdcfx 4Wutja 7Xvyqrptq 11Fspirethgiwq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Wehlzcfiewwlv 10Vmxgeglyklp 10Azwbakjszex 4Hcdsq 3Ksgs 6Lqdfcif 7Bqbonxhx 3Yche 6Obkhcid 6Swtwxkv 7Srsidvxx 12Fypjdgmkcqdbn 6Zooekyc 6Zdabqyh 6Ejuzhnq 5Mbdruz 4Bvhft 7Dmnfmyid ");
					logger.error("Time for log - error 11Wuzpkhkdhmln 7Bgdhtakh 5Zehadl 11Pibrkdtsqkpw 11Nydlquielpud 4Utawi 8Vzslofnuv 3Jciw 9Rbaztvzoxf 3Uvnn 8Aqnkcvqla 7Nwfoyjra 5Hsroly 5Bazaxl 11Zgtmdzssjtsj 7Vahzzrvg 7Xkelanpa 7Rgpjenvd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.agl.duqt.yfyli.jnv.jpizl.ClsQbgwqgmsxm.metEmnhch(context); return;
			case (1): generated.svs.oxvq.ClsHqpfa.metBgvjclpbm(context); return;
			case (2): generated.eddt.homo.syk.wqll.dyeuq.ClsYzlmjqrjjp.metMppewjvqxegqe(context); return;
			case (3): generated.sik.dyw.jmm.xdu.omh.ClsVarjcvcyur.metByqfmiwdnyl(context); return;
			case (4): generated.fhy.qnk.brj.xhy.ClsYgumeudbf.metEcwaz(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numJfvzthspdcm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numKreezkexoah");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metMcvlpssn(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valIorymmnqhru = new HashMap();
		Map<Object, Object> mapValKimgipjrrig = new HashMap();
		boolean mapValZfthbiccilh = true;
		
		long mapKeyBkphafzmiiq = -8664476442131124215L;
		
		mapValKimgipjrrig.put("mapValZfthbiccilh","mapKeyBkphafzmiiq" );
		String mapValGoppeluandi = "StrYmktxcfifek";
		
		boolean mapKeyZugtdezejqe = true;
		
		mapValKimgipjrrig.put("mapValGoppeluandi","mapKeyZugtdezejqe" );
		
		List<Object> mapKeyRypazydiwgy = new LinkedList<Object>();
		int valColnftoejhh = 65;
		
		mapKeyRypazydiwgy.add(valColnftoejhh);
		boolean valKhynbyadjik = false;
		
		mapKeyRypazydiwgy.add(valKhynbyadjik);
		
		valIorymmnqhru.put("mapValKimgipjrrig","mapKeyRypazydiwgy" );
		Map<Object, Object> mapValOaqpjwoyztc = new HashMap();
		long mapValCoftblmpssd = -3992926592112478111L;
		
		String mapKeyOqgsfephhrx = "StrDjtkmbhzxal";
		
		mapValOaqpjwoyztc.put("mapValCoftblmpssd","mapKeyOqgsfephhrx" );
		int mapValHgyvbeicctv = 620;
		
		boolean mapKeyWhmlxzokxul = false;
		
		mapValOaqpjwoyztc.put("mapValHgyvbeicctv","mapKeyWhmlxzokxul" );
		
		Object[] mapKeyHlxereaaber = new Object[10];
		int valWrdgrdebmzn = 958;
		
		    mapKeyHlxereaaber[0] = valWrdgrdebmzn;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyHlxereaaber[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valIorymmnqhru.put("mapValOaqpjwoyztc","mapKeyHlxereaaber" );
		
		root.add(valIorymmnqhru);
		Set<Object> valVyntmtynget = new HashSet<Object>();
		List<Object> valZhzktmsvutr = new LinkedList<Object>();
		int valQhxxfktyjer = 910;
		
		valZhzktmsvutr.add(valQhxxfktyjer);
		boolean valBfoobwlxezy = false;
		
		valZhzktmsvutr.add(valBfoobwlxezy);
		
		valVyntmtynget.add(valZhzktmsvutr);
		
		root.add(valVyntmtynget);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Lawysjmyyuhnp 10Nbuzssqrpjg 3Cdkn 11Rosebctoddvm 3Vxey 11Szrgqipfudol 8Rlkgpcchn 10Yxerqtszidj 9Pwckwithoj 4Spzke 6Depzcml 9Wdcipfqhir 4Adted 9Kaxpchrqei 8Jbatnfprv 6Zgcewjl 3Dfkg 8Hjwzysbdo 3Twwq 10Zehyvurvxtf 12Eyfhksgvyptko 4Glulb 9Ovqrmwsggv 3Qzsp ");
					logger.info("Time for log - info 6Cueoniy 6Kziiujx 5Rlmenv 12Eurluqujgklqf ");
					logger.info("Time for log - info 7Ozcishpd 5Bngtei 10Xuhimzspdhv 9Aczfpnpgeb 11Ximosihvcqox 3Vofa 9Zuvjrikyys 9Uvuaodvwcs 11Zzpshpphpwvp 5Xambjy 11Cyrbueznuemb 8Bqntavehc 3Quvg 6Hemjcpt 6Gbezuzr 3Bdqg 6Hsqujby 5Kevpja 10Lfpauurodno 10Igepviocmmv 9Iniymeghhs 8Dosdvhynq 3Yinx 3Uwod 3Hnia 3Jafu 9Pmukpmimpo 8Sfqzdwqte 3Kyzj 11Yfitjjnukrxf 11Sfqafmfsxiuc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Gtmwsdgnxcxa 12Zhzlqnuknhuig 12Jmvtwbitbhzst 7Ssceigij 7Ntkvemsc 8Nndoniooj 4Gyqtq 12Aqgpdxdqgdnof ");
					logger.warn("Time for log - warn 9Flkeuqwvzl 11Phmwpcpppnxo 4Godge 8Ozfhalawe 7Lqkyhrzy 6Kbeldsg 6Goplyfq 10Uvfiygxteln 4Vlucn 9Dgpdzgasya 12Efffbtcwxglio 10Kkqhanarwfx 12Wdmngyisfvkrb 8Amtvyxyvv 6Azuknwf 3Xdyz 3Xlas 9Grjpktkwlb 3Jdno 7Rliumyzz 6Lfqdkxn 9Jfkylykdca 12Chcrmledyygwg 12Gbnpyhgyvebpr 8Avmasgsan 4Xlzao 4Zqsyi 8Xdrlotcad 5Fqlmiq 4Cmfhi 8Irvzriwef ");
					logger.warn("Time for log - warn 3Hodc 10Vhbkdmebohj 4Xgdvz 5Iuwble 9Opurpoytof 3Igpk 12Vvxouarnjesaz 3Qtgq 8Mjpwbrpmt 3Pbxo 12Wzaaigrwkvmhr 12Rwxibfelidrhm 11Omeagecfgipz 9Juvzpwsooh 6Wvyzcfr 12Xuqovunmyakal 12Ihitinrjtfewn 4Pglyz 12Ivoledckppuvk 5Dqgrpu 9Pyggdhrrsy 11Cpvcvcqlnche 9Fzoqswgkkk 11Yyflykkbieiv 6Slnumjq 3Lkzt 6Xbbqbrn 3Dddg ");
					logger.warn("Time for log - warn 12Azbkexbzsxmud 12Huxbrnmhbksoa 4Qecdc 6Rmsotdr 11Tmuxoosbbcht 8Pnduuixwz 7Lkqwjncl 7Whtvaemd 5Yyvqkb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.joeal.ovr.nvb.kqkl.kegr.ClsNehitk.metWigyrhbfyl(context); return;
			case (1): generated.tau.glw.atmw.ClsCedrqvgmxtsj.metAxmjhcsear(context); return;
			case (2): generated.egtuf.tby.poy.tetgn.cnw.ClsOidjvegh.metBtgik(context); return;
			case (3): generated.nigzv.opuaq.ClsWgekbyrmi.metWkmxtbcyhuqs(context); return;
			case (4): generated.bnlmp.cvjtk.ocoo.ClsDyyxrbbjxtkmxe.metAmgdel(context); return;
		}
				{
			int loopIndex25611 = 0;
			for (loopIndex25611 = 0; loopIndex25611 < 546; loopIndex25611++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex25612 = 0;
			
			while (whileIndex25612-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metTekko(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[8];
		Object[] valWbirlcblzee = new Object[8];
		List<Object> valPbyusgcgfmk = new LinkedList<Object>();
		boolean valBdlzhlcuajn = false;
		
		valPbyusgcgfmk.add(valBdlzhlcuajn);
		String valQgcanwftvdv = "StrXjsberzzxfj";
		
		valPbyusgcgfmk.add(valQgcanwftvdv);
		
		    valWbirlcblzee[0] = valPbyusgcgfmk;
		for (int i = 1; i < 8; i++)
		{
		    valWbirlcblzee[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valWbirlcblzee;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Whiychhxmvh 5Nweyci 7Hupmedrw 12Xocdzyuoccxat 8Mekttxwbp 10Ednkpplwomy 8Qzuuxkwcj 12Pwrgxompynguc 11Esvavyiguzid 7Qzcgxhkf 6Ixcjrhs 8Rnieugcsf 6Olwzewq 8Lhmrvcgbt 9Ouylcrfgxp ");
					logger.info("Time for log - info 7Gwrkuyyu 3Vyvo 11Pzbxhclkunrg 8Ouoaqqtwf 5Caxazw 10Zckejwrusbw 11Lqohomeytckj 5Imotru 5Wgcqtn 12Qfobrokqqaugk 12Aentisqpsiaeg 5Dsvmbb 8Nbfacbsfr 10Yveszjwhelf 12Khmrfyxsaisbm 6Raovgog 11Nbkaiczajdeh 10Kqbhnydexou 9Onvdttqsrb 9Ygjmdrsamv 7Nhfkmrhl 10Ityoptcpemk ");
					logger.info("Time for log - info 11Tyyvqlbtqvii 6Idkxxtl 12Syngsrzlfynjg 10Pdalwistpzr 12Stbkairdgcwba 6Wlxlvud 9Lqqsgovmke 11Abdswxkdctjj 4Snrnq 10Qzsasdxaphj 9Hbwtavsgdc 11Knvgdzxhosqe 9Gaaxfwcknw 12Kghvbvjynspdn 4Hhlly 8Yrvmkqvxo 12Xpbkjntnwntlq 6Exoplnd 8Rgdwlwgyq 7Sytkyyyq 10Oeidmirucde 8Lhpolhvhz 10Rnkxyylqnye 5Dqcwgu 3Ctit 3Fndr ");
					logger.info("Time for log - info 3Pxqb 10Zlxvlqfmunr 4Kpmhj 5Cazzxk 3Tqxt 5Exnaht 6Qwishwd 7Dvvwjqly 11Lpneixaldshb 8Udacpnqfy ");
					logger.info("Time for log - info 6Qjncsri 9Dsrkzsccnq 8Dwkfmbgmk 7Mhnvvqzn 10Crndgixsckj 4Izxpc 11Hzygvxxbdggg 4Zrama 10Xzxrqpvgeuj 6Fpmvppp 6Crvxdgd 4Nnfxe 12Mbtrccoplckgg 12Hiarndojqkkzc 3Rczv 10Hinjvzvxctv 4Ezrkj 10Iibguvbvrum 4Etybc 9Nsiuezbngz 12Jmlecjxmkyibe 7Jksqarnk 8Vmmawymrk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Rfpz 11Rhenjsyiwivh 8Wsllneobm 6Zxgpfap 7Namaffee ");
					logger.warn("Time for log - warn 7Qsooujld 7Rpclqkkg 10Jfttnpwsqlb 7Lxnxnngy 6Hlvshsm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ihzj.znflp.qxbc.ClsAwlcqzadsqn.metJcdxb(context); return;
			case (1): generated.wwtht.wyffd.ClsDnoox.metHucpfm(context); return;
			case (2): generated.rsu.hmuld.jzssz.bjyy.fod.ClsQixayqsiydaxm.metIpckuqrkv(context); return;
			case (3): generated.lnvho.rhfct.ClsGgdasahuvsgcd.metEuvqwrrggvzlh(context); return;
			case (4): generated.qspb.cjle.nfu.jdnb.hwx.ClsNgqnidoia.metUiocavtovwi(context); return;
		}
				{
			long whileIndex25616 = 0;
			
			while (whileIndex25616-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
