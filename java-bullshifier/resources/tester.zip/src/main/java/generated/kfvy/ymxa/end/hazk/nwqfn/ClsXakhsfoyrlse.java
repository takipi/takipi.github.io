package generated.kfvy.ymxa.end.hazk.nwqfn;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsXakhsfoyrlse
{
	 public static final int classId = 257;
	 static final Logger logger = LoggerFactory.getLogger(ClsXakhsfoyrlse.class);

	public static void metSihzklw(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valFjdyxoklbnp = new Object[3];
		Set<Object> valGjozozkwaat = new HashSet<Object>();
		String valHszkmerptrx = "StrOjskpsfnzur";
		
		valGjozozkwaat.add(valHszkmerptrx);
		
		    valFjdyxoklbnp[0] = valGjozozkwaat;
		for (int i = 1; i < 3; i++)
		{
		    valFjdyxoklbnp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valFjdyxoklbnp);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Jrzlpht 6Svmolvk 7Hpsxxypb 11Qzjzkvamkvtz 5Gkwmqg 7Aigzovbs 7Wocawxow 8Rglstscot 9Ibabcptbdk 11Nhybajnmzbhk 11Ekarmtsumpjb 10Oidclfxplzf 8Yoczgwdeb 9Bcmukspfwz 8Ayplqbcsq 11Thepxfjnsklq 12Sqdminpzvgkwx 9Qpopvatmxy 10Ateqdpkvaxx 9Bvebgpksrn 6Actwvxe 11Ejlwjgshejqb 6Eajogrw 3Dbdv 3Sycb 6Zgywvho 8Copotlkje ");
					logger.info("Time for log - info 5Cusvbb 9Kczjbcdosy 9Vsctffdsva 4Behzz 11Tlrlwcdjiayb 7Dmvyegwj 12Rlzvfculxvksf 3Cfpz 12Gpltmsqfbozzd 11Yvhnllosddfi 3Tpwb 11Iilfdcgurycb 4Poxgv ");
					logger.info("Time for log - info 4Ixuur 5Irfhnw 9Acdshnsiyt 11Zdripttmptud 11Bizabrliyhrt 10Ptsymtatgxk 4Fiqiu 6Xywjrvj 5Xdebld 4Wsntz 3Ajkb 7Kohedvwo 7Jgntzmwz 4Snjmf 6Cxwgtsn 4Tphto 7Jovdjlky 12Tuahmygzcshav 6Fhpbeyk 11Cboxywyvnkqf 7Mcveszxh 7Uwlrfrgw 12Cztvybtsrewuc 12Nwvrrapcbikld 3Evub 9Yexspvcxtc 4Hzxon 11Vjtixbyaedgr 7Xdgrrucs 3Stvm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Fdtivfuitwil 7Iuvwyctq 6Mhcnirg 9Aoeeqrowxz 3Uvzc 9Udaanqjvsf 9Whwqwwvrae 6Bfaaczb 3Fzif 3Aaxs 10Cnbarqswykl 11Qeawnlbhperp 12Zaqbxcgukixjv 12Gwclwgszpzpgi 9Yznobbrkia 4Pgkbv 6Jqeyynr 9Vueamvlaal 6Vucjgyf 10Zxbshdthcxr 5Yulyvu 12Ghslqjymjkblc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Udaaigqxlcc 12Mnwajnkxryoqb 8Yjclpyriv 9Mmyixhmkzp 4Ypliq 9Msitgeaygg 9Ncfdvizvhn 7Runfuvuh 7Jnssqyqp 4Bjaeg 11Akklybapsebi 12Blwwamsbtwuzj 5Euxdgs 12Locwtschpmuei 9Fuopktgmcq 11Xxqfqjhrcyho ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.iwmr.swhrn.ClsOqphojsm.metAtffyacmyd(context); return;
			case (1): generated.qrzc.frg.utv.itv.ClsGoyvsxo.metZvafe(context); return;
			case (2): generated.bolg.tnlb.nmug.ClsHstaiufsowx.metPapexcx(context); return;
			case (3): generated.dyv.vxo.ClsWrwpfswr.metWnivtvbltsfqlg(context); return;
			case (4): generated.uyus.ruq.fow.dvnw.ClsCysblmgtiyuxcr.metExmmbm(context); return;
		}
				{
			int loopIndex24472 = 0;
			for (loopIndex24472 = 0; loopIndex24472 < 3511; loopIndex24472++)
			{
				try
				{
					Integer.parseInt("numFytleatzobm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metJcgkp(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valMwonuutxjxh = new HashSet<Object>();
		Set<Object> valThzvxjmegal = new HashSet<Object>();
		long valEnniqjafhyk = -554189344877575790L;
		
		valThzvxjmegal.add(valEnniqjafhyk);
		
		valMwonuutxjxh.add(valThzvxjmegal);
		Set<Object> valQcrqitzcyvs = new HashSet<Object>();
		boolean valRhomhksmorr = false;
		
		valQcrqitzcyvs.add(valRhomhksmorr);
		
		valMwonuutxjxh.add(valQcrqitzcyvs);
		
		root.add(valMwonuutxjxh);
		Map<Object, Object> valObhdqpfjgwa = new HashMap();
		Object[] mapValTsylcvhwtch = new Object[9];
		int valLadbotuypqb = 910;
		
		    mapValTsylcvhwtch[0] = valLadbotuypqb;
		for (int i = 1; i < 9; i++)
		{
		    mapValTsylcvhwtch[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyFfwdjiiqiyn = new HashMap();
		int mapValPyckeabthtl = 548;
		
		int mapKeyXjnpfosgopl = 366;
		
		mapKeyFfwdjiiqiyn.put("mapValPyckeabthtl","mapKeyXjnpfosgopl" );
		boolean mapValQwriabadodo = false;
		
		int mapKeyChtjhhvsnqh = 905;
		
		mapKeyFfwdjiiqiyn.put("mapValQwriabadodo","mapKeyChtjhhvsnqh" );
		
		valObhdqpfjgwa.put("mapValTsylcvhwtch","mapKeyFfwdjiiqiyn" );
		
		root.add(valObhdqpfjgwa);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Ovpmpxxrn 11Oulifanzgxnp 9Smmwnbtnlq 11Ngqnsigdsiab 7Tkklggqj 9Jscxtbxilj 3Xkbm 5Rmryqc 12Teyutckymtimw 10Kxulzzwgsrb 11Gluisharcayf 10Pcyewowisrc 9Fkdxpfknqi 8Wgcowvnan 9Uhjdqetudx 7Wdbtajdc 3Ztko 7Iqaakxpb 9Xuyjklldhx 4Jrumf 10Cuxzxyqkqtp 8Qqpvkcswx 9Scydseienz 11Tcjxssycsgrq 12Bjyrkemiktogf ");
					logger.info("Time for log - info 4Bdvco 8Qqghdwagz 4Mqaso 6Bjzhdeg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Ayklnuwrbgr 5Tkwxhw 8Zochmpyqx 11Xxngkdkaklpt 4Kkqig 3Qhpy 7Kvjrjpmo 6Xtgwbvh 6Iqyrqxm ");
					logger.error("Time for log - error 6Mrgrobt 7Pjqdomct 7Pfrqzkiz 7Ewwvosqk 6Njvbxyg 9Bemnbdsmbh 11Zplqcqmdehzi 7Jrcqkqhj 11Rwyludlqnrpt 5Ulsscd 6Yppvdxi 10Ixxvnbzhyog 10Osiqlfcxmzc 8Xewyrfssf 11Oeczcfgwsvgf 5Atqdcq 7Qdnrichq 7Plxiifef 7Youhdusv 6Tpgerji 8Hcshkoerf 4Ztvlv 8Ssgznspom 8Aqhmbxnfs 7Sltkknkq 7Zgqhhpia 5Ayjlrp 8Ywwfnjoqu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nrrh.nxnu.xat.kha.ClsLoiagobs.metTrfqw(context); return;
			case (1): generated.qrzc.frg.utv.itv.ClsGoyvsxo.metBbvjqnzqzrvdmf(context); return;
			case (2): generated.qpe.ifudp.xgatn.jzg.qau.ClsJymdeqopgpbo.metZmvopmy(context); return;
			case (3): generated.hor.ymu.xve.ClsFtiqqajkdixb.metBmlepaig(context); return;
			case (4): generated.vere.yue.xag.ClsLhubirlwqfrd.metHsbpvmcqtwkaz(context); return;
		}
				{
			long whileIndex24475 = 0;
			
			while (whileIndex24475-- > 0)
			{
				java.io.File file = new java.io.File("/dirYkioxppjhkw/dirSozxbxwcmpa");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
