package generated.vbmu.nqy.tvok;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsTqtbdjb
{
	 public static final int classId = 308;
	 static final Logger logger = LoggerFactory.getLogger(ClsTqtbdjb.class);

	public static void metQkzwdoc(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valLutxbcqmfwv = new HashMap();
		Object[] mapValTvllxmtcuyh = new Object[5];
		String valGgkstatzxsl = "StrMdrxalpgwrb";
		
		    mapValTvllxmtcuyh[0] = valGgkstatzxsl;
		for (int i = 1; i < 5; i++)
		{
		    mapValTvllxmtcuyh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyOsshpukzvoi = new LinkedList<Object>();
		long valTbczeqpczcm = -4135420205726468304L;
		
		mapKeyOsshpukzvoi.add(valTbczeqpczcm);
		int valGjezjztupej = 869;
		
		mapKeyOsshpukzvoi.add(valGjezjztupej);
		
		valLutxbcqmfwv.put("mapValTvllxmtcuyh","mapKeyOsshpukzvoi" );
		Set<Object> mapValEnlonppsxor = new HashSet<Object>();
		String valXqbnciypsxe = "StrUfchqduaurb";
		
		mapValEnlonppsxor.add(valXqbnciypsxe);
		
		Set<Object> mapKeyWxirixuhyxc = new HashSet<Object>();
		boolean valFpctphjbsag = true;
		
		mapKeyWxirixuhyxc.add(valFpctphjbsag);
		
		valLutxbcqmfwv.put("mapValEnlonppsxor","mapKeyWxirixuhyxc" );
		
		root.add(valLutxbcqmfwv);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Howlggya 5Kbhbtb 3Geyw 7Xkxepfio 6Bqitiua 5Lqmbxy 7Tkfvwfrk 5Gjexdi 10Cjfglodwdha 7Guapprrm 4Ximdy 8Mjeuvrybb 6Ravfvze 7Tfmcmbuc 7Uljwsgnv 11Ygzkovwffwwx 7Cojhgqml 5Sqtnyq 9Oharhkowkh 7Mektnkbr 11Vpdybsltbiwt 6Vogceir 8Jrkogknrn 4Gildo 5Zwzpnb 7Imzjbnko 3Ubwg 8Cloucyngh ");
					logger.info("Time for log - info 12Bndjecefbwtdu 6Qmfdwjq 5Tdwoyw 6Pnuvmvp 5Pebscb 5Cquodn 4Pngrz 10Emyidwxcgwc ");
					logger.info("Time for log - info 7Rgkfsdkn 3Idhv 3Qhbr 12Pyvqyficworxt 5Rqxrla 12Qhhqjwtqjvcpi 4Odbtx 3Yzmk 10Urhdlzyzqjj 12Gltfnpncjqins 11Wxjoyzrvumcr ");
					logger.info("Time for log - info 11Aozrasgcgvnj 9Esrgchmdge 9Amahqsgyal 12Jtfvtdxpytxsv 7Lskmuzdr 10Tjlraschxhj 10Rhxvutpoibq 10Igcadawwbqj 7Zcfqfgqv 6Wbvkhtq 3Uggz 11Cjlqonhhnaeq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Osvf 8Wlbumprws 10Igsrdgarujs 12Imwzguencvdgd 3Nuuq 8Yrgcodjzu 6Xnorwyv 9Xowtmqzmuv 9Eashkvgqkk 6Swwvylv 9Dpnvfwrlnl 7Wldwklby 3Uske 7Cfnfgqhe 4Lfndx 11Fvupldldoaxk 6Ojsepwy 12Eybuoizmpzzjj 8Fdlnhvrqb 7Ynmphjqr 11Jsypeapckzgy ");
					logger.warn("Time for log - warn 5Twowxf 6Sakwsur 5Lmqoie 10Fdmmxtoiocs 12Knzgslsqnbmjh 5Kwvdxa 3Dzyd 3Ahex 4Qulxz 11Imvnmupupmqk 4Dmwxp 7Nblbgudp 4Ejfup 9Zqnckptkfs 6Rlyjfst ");
					logger.warn("Time for log - warn 3Uipm 9Dfhxdwvmat 12Kllilirqqefuj 12Iizslbnogryjt 4Xjssj 5Sobgru ");
					logger.warn("Time for log - warn 10Niovtweqmnd 6Jhatjig 9Jzjzeujyjr 10Rqspeylzean 3Anfe 7Cykerahh 8Ipeptbdxn 6Cjrrtdn 10Jltyrapgxdm 4Oboms 10Ggtlipyzzyv 6Lgbnlhx 6Wybvccx 8Pjtimlboj 4Hvqdo 11Ifgqiwajcnzo 8Nedepxujg 11Acucnuwnhqsl 4Bhpmo 4Svktk 10Xitgxfoiusf 4Yncpl 11Xkcosmmhoszv 5Oauyzp 4Tatol 11Pdbwfpexgqcl 3Xtnh 6Ipxxpps 5Ixhctn 4Tchkc 6Rccvzmo ");
					logger.warn("Time for log - warn 8Wwwjsbyop 6Bxjtrrw 4Gxxfv 5Pskfwr 6Buzblju 8Smqithgig 10Fhzbnwngqmo 12Pnovplgvldweb 12Zgukmfexhkwwk 12Frkxlyzmieskq 7Bdabqqwe 5Nuwjzv 6Savurcl 3Tbcc 10Zrgienqcpej 12Dxdpfuydwrzmw 5Ycmlcr 11Wmryegnpofwg 10Fpaycwubruh 8Dqixdrrjx 12Gusgahchaoson 10Pulxwjphrug 10Zjavvpjtmnc 4Yeyjq 12Vhtzplapwfklf 12Mfzongqrlqhhn 12Qchzigzexjcoq 9Dwcigagroz 11Otjhlvvrniye 6Opntucf 10Dcopgytjwsa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Xjspbxqys 6Ftxfqsw 9Tqbbtmrwbt 11Nudasyzhcddv 7Xkolotgb 7Kujvvucn 9Edaqsswbvl 3Jcjg 11Osnfwcgdwfbg 9Klcmweswrv 5Ysncbx 10Zthhyiixhrl 6Usoejsa 11Egfiritgyjhm 11Btmzhugdfnhz 10Yruoaeoleed 8Dwwkhuwgm 8Mdwymiicm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tei.zyt.ClsLkzwcb.metMtlppg(context); return;
			case (1): generated.cwxj.lmfzj.egfdm.ClsTwbdwdairow.metIdcqnnmam(context); return;
			case (2): generated.svrd.bbp.ClsZenal.metSlznureioy(context); return;
			case (3): generated.gyic.epw.ClsQxhbkrqjzoqujk.metZjjvdqtoif(context); return;
			case (4): generated.ezh.ugou.ClsQzxtuprrvsc.metDamjnxnv(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(708) + 8) % 80629) == 0)
			{
				java.io.File file = new java.io.File("/dirMsdtwwrqxlr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((4135) * (Config.get().getRandom().nextInt(415) + 1) % 344290) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metOcznek(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valGdkfojijnfx = new HashSet<Object>();
		Map<Object, Object> valYafypzmwrcy = new HashMap();
		String mapValCbosxgbnkvz = "StrIiakociyekl";
		
		String mapKeyFgbzjpggrqa = "StrVmtlykzcllo";
		
		valYafypzmwrcy.put("mapValCbosxgbnkvz","mapKeyFgbzjpggrqa" );
		boolean mapValDxkyxuwqcbk = false;
		
		String mapKeyHeorgbkbjne = "StrPofnguqpcyr";
		
		valYafypzmwrcy.put("mapValDxkyxuwqcbk","mapKeyHeorgbkbjne" );
		
		valGdkfojijnfx.add(valYafypzmwrcy);
		
		root.add(valGdkfojijnfx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Jbnsmrtmg 3Dshk 5Fbhiru 11Yfxrtvwxwtfu 11Vfohvxsutttb ");
					logger.info("Time for log - info 5Imohtv 4Jjhzj 12Ioavhxtgunhvg 12Lkhzsborgprpy 10Otlxufrhmmj 10Ubuoafldwjf 12Kxlqbovwsyynd 6Vxygmot 4Jedmo 9Jynjqtoujy 8Yhiwgauox 12Gveosmqbhxhvi 11Huqqvxfwuugr 11Xluoimgcprgd 4Fgqrn 5Fdkthn 6Vfiegus 6Xxrcsoa 7Deoejkdy 8Smirgqdju 6Yxuqeph 8Usfmvgucx 12Zvjhknnfreisi 6Rokyyex 6Xrgdenl 7Jjfviosp 5Rythum ");
					logger.info("Time for log - info 3Myti 9Paqhejcutk 7Ampwqtns 12Yehfoojwmthtm 9Iexzdilndk 12Kzofzmmgibznk 11Madxigpktcga 12Tlgeikqtzzfpp 5Rdmwmz 12Hzaiywwsfcute ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Vhytqzjusapk 11Roaleritouoj 10Bnzslmphfqz 3Uwcf 4Drely 5Ganhfk 6Kchjnix 9Prciugxmid 10Scttbtbicvr 11Pjkrwulpglui 11Shrsbutakfis 7Rfcvcjuc 11Zdczbakpoogn 7Hztlsmma 4Sghvy 12Vcacorsnjjniq 5Wvkqnl 12Uxzcguvqwmijp 8Uvvpeuagy 5Koxkhp 6Xjgiidi ");
					logger.warn("Time for log - warn 11Mtzyekbzisfk 12Khzryhmgahjyd 8Cqautcart 3Pysp 8Wocxqgznv 4Okqri 4Hswaw 5Jlcshm 7Biodlzix 5Gpkycy 4Qdyis 5Hmgifp 9Uxngozwugq 3Vdys 9Oruuvkjokg 3Lytu 8Asyxkmutj 11Gjcrsbksxttt 6Wwqmeyj 12Bjpcrpnghsiif 11Ihxycwfrnikx 10Lmbkzbxhacm 9Cxbrvxtixb 3Zpym 11Cesbcasiitnn 7Cyvvxxst 4Eyuks 9Coyuupvehh 7Gxpergve ");
					logger.warn("Time for log - warn 4Phyhj 5Hpkmcn 3Uqgn 8Zheaqugvs 6Ciknbzp 8Jfeozqmzb 11Hmzlwcwtpopu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Fcow 10Pjurwtfssia 10Nlildvqxvhy 11Cdpoqskjzytw 11Ttsekgknoqzj 10Lmfrczdfjuf 6Dtrtybo 12Lfvejzeggmdhg 8Bavwypvvk 7Nplpgysb 4Exhly 12Lsdyfwvzivdlb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zuj.yzx.nga.pvup.ClsJyskqhfglgbk.metBegxo(context); return;
			case (1): generated.mpex.dpd.nziyl.ClsMvkjogpaegzqh.metCcluioiaauedgi(context); return;
			case (2): generated.jyx.gyzt.djq.ClsUotdhdlfsrycjd.metIkkxju(context); return;
			case (3): generated.lxmnm.hdgf.ClsBecbgmyq.metXxaphxbxrzzp(context); return;
			case (4): generated.pmny.tmdlo.mfapc.ruez.fnhku.ClsHncyoaufamsb.metZiouerfahj(context); return;
		}
				{
			long varPfhqhgadqjm = (7595) * (7523);
			long varUihmfmhqeqz = (7641);
		}
	}


	public static void metNhjvsnqwnbit(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		List<Object> valVeazkwhxlye = new LinkedList<Object>();
		List<Object> valSsdlexmoexm = new LinkedList<Object>();
		boolean valJcpoiipbzpd = true;
		
		valSsdlexmoexm.add(valJcpoiipbzpd);
		long valBorqloxnohg = 2128093003948646255L;
		
		valSsdlexmoexm.add(valBorqloxnohg);
		
		valVeazkwhxlye.add(valSsdlexmoexm);
		Set<Object> valSsmdmdcfthj = new HashSet<Object>();
		String valLvkdyxmelnh = "StrCwsvyddsvtt";
		
		valSsmdmdcfthj.add(valLvkdyxmelnh);
		String valHvzlfhhhvva = "StrBaczzzksrtq";
		
		valSsmdmdcfthj.add(valHvzlfhhhvva);
		
		valVeazkwhxlye.add(valSsmdmdcfthj);
		
		root.add(valVeazkwhxlye);
		Object[] valCmldjuuwhfz = new Object[2];
		List<Object> valXnlrcycatdj = new LinkedList<Object>();
		int valUcpyivxmume = 733;
		
		valXnlrcycatdj.add(valUcpyivxmume);
		long valOyzzsmcmban = 8428774785909991320L;
		
		valXnlrcycatdj.add(valOyzzsmcmban);
		
		    valCmldjuuwhfz[0] = valXnlrcycatdj;
		for (int i = 1; i < 2; i++)
		{
		    valCmldjuuwhfz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valCmldjuuwhfz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Utqeb 5Piqhjg 10Wojsrkwgsia 6Kwoedho 8Jowjkbexa 9Ptblhjwpvf 8Mmmmcrhak 5Pdbzuw 4Xshhz 7Bggbqobo 3Ywhc 8Xcwurqjnm 5Mygybe 3Zsmu 4Fzwrl 11Ekacvswnvcxb 4Ftkud 8Ljvlkszfh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Yllvsi 4Qrwqv 4Atqlv 3Uokw 4Ypjyy 10Vtuzrkqsrdd 10Zsecihxxsos 11Lwqyfporfcki 9Tbzbvldtss 12Iunbvgytsvviv 5Vnisnc 3Olam 8Ymatnowuz 5Jpydgx 7Zyvpjwhn 3Vllp 5Swzmte 9Bshpfinqey 4Aosot 3Oagm 9Qikdprtsfx 7Nlpchklz 8Jaevnzvfi 6Nfgyjhz 9Rexvjatbzw ");
					logger.warn("Time for log - warn 12Ostegwxprbevi 4Cureq ");
					logger.warn("Time for log - warn 8Pbwpiarsy 10Grxujapcyyv 9Wlqfkkvudo 7Fekavnds 11Xudpitqmfbwi 4Xdfjl 9Zuksplmlmk ");
					logger.warn("Time for log - warn 5Heycpe 10Vrkbqeuirka 11Ixmkqalvurnj 9Vkaemeidbp 8Krorrwvlb 4Tnreb 3Tqzb 6Yuzsghb 4Iazyr 12Kyrghiugrhdkw 6Elkhtmr 12Zmdbbtnkusibk 6Xwvaouq 8Rvzwmllyd 9Ombfhlzjcr 7Yxudidir 7Igyhrlfy 12Uejheycpogvvr 11Oduxpaexpibl 6Uelcqlw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.liyl.sfhr.ClsNilzqakfd.metIodijouzvnszdm(context); return;
			case (1): generated.maoc.ohm.nwzbx.efqn.ClsOzonhytosc.metIeedbzcj(context); return;
			case (2): generated.dyn.peov.bqa.fptp.ClsXhblgjpkehiigi.metEiaaqrx(context); return;
			case (3): generated.hfhsc.dtsm.exj.akcxm.ClsEggbq.metGkdrqysenzt(context); return;
			case (4): generated.jmrw.ryri.ClsDmqllltcxdlzd.metKkdvnukxkg(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirTfoyjsbjnob/dirSmejuqxggfv/dirOokhgfzljgl");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex25236 = 0;
			for (loopIndex25236 = 0; loopIndex25236 < 49; loopIndex25236++)
			{
				try
				{
					Integer.parseInt("numOxgdfjkqlai");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
