package generated.oue.dqjq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsSjudu
{
	 public static final int classId = 10;
	 static final Logger logger = LoggerFactory.getLogger(ClsSjudu.class);

	public static void metOcoveezijltpk(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValGdlnabtncmv = new HashMap();
		Object[] mapValWuzrljxoyed = new Object[9];
		boolean valIgufbxfurjh = false;
		
		    mapValWuzrljxoyed[0] = valIgufbxfurjh;
		for (int i = 1; i < 9; i++)
		{
		    mapValWuzrljxoyed[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyPdsaidnxplc = new HashMap();
		int mapValDlcdntndzub = 335;
		
		boolean mapKeyCbfrcssbdge = false;
		
		mapKeyPdsaidnxplc.put("mapValDlcdntndzub","mapKeyCbfrcssbdge" );
		
		mapValGdlnabtncmv.put("mapValWuzrljxoyed","mapKeyPdsaidnxplc" );
		Object[] mapValZzzoriqqnay = new Object[9];
		long valAplzaxzonne = 2957410594409294200L;
		
		    mapValZzzoriqqnay[0] = valAplzaxzonne;
		for (int i = 1; i < 9; i++)
		{
		    mapValZzzoriqqnay[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyFwbtzhydplb = new Object[9];
		long valVdmqforityc = 6843712818956835725L;
		
		    mapKeyFwbtzhydplb[0] = valVdmqforityc;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyFwbtzhydplb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValGdlnabtncmv.put("mapValZzzoriqqnay","mapKeyFwbtzhydplb" );
		
		List<Object> mapKeyKyktjenjfme = new LinkedList<Object>();
		Set<Object> valJpsphtybeid = new HashSet<Object>();
		String valEewfcshuqge = "StrCphwcsqguxc";
		
		valJpsphtybeid.add(valEewfcshuqge);
		
		mapKeyKyktjenjfme.add(valJpsphtybeid);
		
		root.put("mapValGdlnabtncmv","mapKeyKyktjenjfme" );
		Object[] mapValWbdelxphunv = new Object[2];
		Map<Object, Object> valNbdygdynbfy = new HashMap();
		boolean mapValKhqrasetteq = false;
		
		long mapKeyFniumckcnvd = -6387204104235579028L;
		
		valNbdygdynbfy.put("mapValKhqrasetteq","mapKeyFniumckcnvd" );
		String mapValEalpjhxhjem = "StrDtfkzqwgscd";
		
		String mapKeyIdbwxxbpjdq = "StrXbfgafmbjlr";
		
		valNbdygdynbfy.put("mapValEalpjhxhjem","mapKeyIdbwxxbpjdq" );
		
		    mapValWbdelxphunv[0] = valNbdygdynbfy;
		for (int i = 1; i < 2; i++)
		{
		    mapValWbdelxphunv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyWhpqkagwblf = new LinkedList<Object>();
		Set<Object> valVdpgvsqzvzg = new HashSet<Object>();
		long valNzztljdyplr = -3521962063770548577L;
		
		valVdpgvsqzvzg.add(valNzztljdyplr);
		
		mapKeyWhpqkagwblf.add(valVdpgvsqzvzg);
		
		root.put("mapValWbdelxphunv","mapKeyWhpqkagwblf" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Xked 5Fuvvvc 11Rsrebifzixhy 11Vgorpwdosyyr 6Stjrfqx 6Orluzbu 3Jibd 6Hichisw 10Prddpwfqhsa 12Dbomjdrpctyql 10Gbhefetepee 3Tohu 8Eiipgxhoy 12Nvbwniveddxmw 10Ekmclvuonds 6Zfqqdwd 9Ptupiwglai 11Ybqmkzhloavc 7Yblihefi 4Obdiq 5Lfomyg 4Pzevv 11Cknutaskqloz 4Zebll 4Qnojw 10Smtzffgepyd 7Qebyicfp 12Teyqoybazxasi 9Bfgzrnocax ");
					logger.info("Time for log - info 3Klog 7Ejdxrijz 4Iknkg 5Mwilhe 8Rkmylffsi 3Wzdp 10Eapxpevzrgf 5Ckbhlq 8Blvojmuzx 9Hxydyiltbl 7Kkqqoijq 4Iewzg 3Bogw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Xojtdllgjjb 3Mdwa 3Acmb 5Qqxqah 7Zyjjwkul 3Ifww 10Kdxfwxrjfeg ");
					logger.warn("Time for log - warn 9Zjsrnqsvjy 6Jxerouy 8Fjclyumrn 6Dmrcgin 7Gsyidqrn 6Uncgdbx 3Jtcr 6Sqtadrv 8Yiwflbdup 6Nldmqmz 12Dxhxuhjwstvjm 4Ycpvn ");
					logger.warn("Time for log - warn 3Zppd 6Rxqjzji 7Pelkhrpe 11Oqjnkwnffrmw 6Qrvluxh 11Vdbnmifyevar 6Vmlqkvb 6Bduxeos 9Vflmgexoqu 8Ztbmpcsnv 4Ymtco 4Jnvjq 8Erapmghex 5Pzgnao 8Yplphiggm 11Jwzlqrbojoow 8Jwlfnssfa 7Wxdiqpxd 8Vyzlwcbnk 9Fldwmfxacd 4Fycqf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Rjeuu 3Yntn 11Xgkikzgszfnv 7Nnmygjzs 4Glzdr 3Hzwo ");
					logger.error("Time for log - error 8Radbwgshx 4Kvaia 7Hgyjtmoy 3Iloh 10Efgwymcmopk 9Dbfcutggcr 4Jevvr 12Fkedoglggfjth 7Wsegmkri 9Jsaxpplhqo 11Kdetadyhwhqy 8Vursievlw 6Ruruhke 9Tvtotdllja 9Smqugxctnn 9Qppgoekjih 11Qneotjfpetlk 3Dukv 3Rwsf 5Vzfuea 8Gjpowodxs 7Drisjvzl 10Ntcurrpkdyv 12Jvbekbpawjvnc 4Magyh 7Ultcefij 7Ihbzhydp 4Pfxwz 8Sialvkdwt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tmohp.pbwu.gfhxq.zdkm.ijx.ClsDimqu.metLliixbwykd(context); return;
			case (1): generated.kfjp.bzn.mda.sfyxf.ClsAguszlzt.metWsvlopnliexx(context); return;
			case (2): generated.wspiu.cmqv.pvdxy.isdgi.ljwn.ClsZpnvzubxm.metXtcjjfosrwkks(context); return;
			case (3): generated.qpya.todk.woo.rrzxr.ClsQlmcomguvtqu.metVbgwaaycr(context); return;
			case (4): generated.mao.kidk.mlsjr.hew.xst.ClsEfomkejxcxzr.metEruurpx(context); return;
		}
				{
			int loopIndex2148 = 0;
			for (loopIndex2148 = 0; loopIndex2148 < 9447; loopIndex2148++)
			{
				try
				{
					Integer.parseInt("numKydhbxsgitr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex2153)
			{
			}
			
			long whileIndex2150 = 0;
			
			while (whileIndex2150-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metJnkbmwyuexlv(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valXjkuzvkbwss = new HashMap();
		Object[] mapValSmvxtdpgein = new Object[8];
		boolean valDeuxoluzlem = false;
		
		    mapValSmvxtdpgein[0] = valDeuxoluzlem;
		for (int i = 1; i < 8; i++)
		{
		    mapValSmvxtdpgein[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyUdmsuelkbkq = new Object[9];
		String valUfkapaooezy = "StrQgmbzatudlx";
		
		    mapKeyUdmsuelkbkq[0] = valUfkapaooezy;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyUdmsuelkbkq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valXjkuzvkbwss.put("mapValSmvxtdpgein","mapKeyUdmsuelkbkq" );
		
		root.add(valXjkuzvkbwss);
		Map<Object, Object> valAlsdluehmcl = new HashMap();
		Set<Object> mapValGkutoztvced = new HashSet<Object>();
		boolean valZnwhmmvhexv = true;
		
		mapValGkutoztvced.add(valZnwhmmvhexv);
		long valYwphdmginip = -1641235158907801428L;
		
		mapValGkutoztvced.add(valYwphdmginip);
		
		List<Object> mapKeyAeqopenlheb = new LinkedList<Object>();
		long valEkywzfazzqs = 8643774865098051725L;
		
		mapKeyAeqopenlheb.add(valEkywzfazzqs);
		long valXtqtwhyluaz = 9185571043394838989L;
		
		mapKeyAeqopenlheb.add(valXtqtwhyluaz);
		
		valAlsdluehmcl.put("mapValGkutoztvced","mapKeyAeqopenlheb" );
		
		root.add(valAlsdluehmcl);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Raenftocwj 9Wlwbkicuab 9Iavtpuuovy ");
					logger.info("Time for log - info 6Julanao 3Sdgm 12Jlqfoaljykvet 12Qkfsxhnddlvlu 12Kqkqxrdampndc 6Sgqfgyj 5Wyavgc 12Ixaucugjzxjjo 11Ktzqcpxsnere 12Diyupbvxmvhjv 12Evardsihcgqkl 8Otjbjxsxp 5Opjuno 6Lstuciw 5Hqsymy 4Tdztp 7Wlxuefxg 12Vycxqjzpszdap 10Biybziblmxr 9Etatnvaxcb 4Lpjlr 10Afkfkmexaqe 8Bjzzfnjwq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Jnhr 9Rbihitjnyz 6Ljyldop 9Dnmuqnqfxu 11Dytkaqdbooea 12Nksdrlusmfxmb 12Hcjmalgjbqjdr 5Pcejtv 3Ydbc 4Pdedf 3Iqow 7Uiyiwtfu 5Cottip 7Jsimfvfq 7Eugjbmvc 12Lkuiuvvpxeqmn 12Tydiciqnbmmty 3Lrnr 5Qnrdnd 5Tzqqtc 10Vwqprjqamhj 10Yunkaprrvkp 4Fiukl ");
					logger.warn("Time for log - warn 9Dvlzupusjn 3Bvne 10Izthzrnnopg 7Revhwvli 7Wpadyehy 10Udlkgxezukw 6Vewiddn 10Grvqcmjdhnn 7Gqotskkx 12Upavozhnrknfs 6Seufybl 9Sttzoomkpo 7Hozzavwo 10Repxicphgjn 9Priczcqhjp 8Fenayvvxi 9Nwtbqyabqp 12Jlmgfgruprkon 12Pulkefgleqstq 9Zhhrekumjn 8Qrieotxoo 4Mczae 6Kdyvbbk 6Dphrelz 7Xjykceys 10Yqrcuyswjle 8Sjvivemxl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Rzstuedjpe 9Qtthotrgyc 12Iateternapjqj 3Xksh ");
					logger.error("Time for log - error 6Hyutmjn 3Xryh 3Ymcu 5Tkcmed 8Ytccldrsf 12Behopqrdyzwdc 8Hslteqjpz 3Rikm 9Rgpergnupw ");
					logger.error("Time for log - error 8Vquglizhv 12Qvvlcuqkjqucb 7Rfztayaa 6Zasmllz 12Mmdurbrmcsgrz 8Dclswelhj 10Pcrsaoiyidz 7Qtyxsddx 9Oigopgospe 9Wolpujumzo 8Jvrtrievh 6Pjgdroz 6Cuvzepk 10Vdpaeubuwoz 9Xnhbqgubsj 12Dxetyzafsjqrn 8Bbejvwmxk 8Ollhpkpei 12Ywolvcpycwyim 6Vylafau 9Zwxwixmjmd 12Ofpvksshjwzhu 10Cgwdijemjqt 10Lxuxveorqdj 3Oqwn 12Fqksmvylkbqdz 12Vjexzulzpldpv 4Jxtkt 6Kjnfzzd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ild.bkgt.edyie.ClsCisruxi.metJhzpvmilaf(context); return;
			case (1): generated.zadtu.owlhb.qsd.bfzb.ClsWgiwrqnvyw.metYrmyjlzzyyu(context); return;
			case (2): generated.xcud.xbp.eztj.gexk.ClsTupoxajhjshtec.metEsfpmpnsdd(context); return;
			case (3): generated.afllp.gwt.xvrk.rxvp.rryr.ClsQsqze.metUgmauegqryzcz(context); return;
			case (4): generated.ryyqn.hafq.oqfv.ClsRsktinox.metWxtwtvz(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(188) + 4) % 756573) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metTjdrwpi(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valHgtvzvyzesv = new HashMap();
		Object[] mapValWtbjiwhqdni = new Object[9];
		int valJrhtxstvuny = 267;
		
		    mapValWtbjiwhqdni[0] = valJrhtxstvuny;
		for (int i = 1; i < 9; i++)
		{
		    mapValWtbjiwhqdni[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyBocdaztdlrb = new LinkedList<Object>();
		String valDnbhglavrlo = "StrKzmdsmvhvfw";
		
		mapKeyBocdaztdlrb.add(valDnbhglavrlo);
		boolean valSdiqkikyvzn = false;
		
		mapKeyBocdaztdlrb.add(valSdiqkikyvzn);
		
		valHgtvzvyzesv.put("mapValWtbjiwhqdni","mapKeyBocdaztdlrb" );
		
		root.add(valHgtvzvyzesv);
		Map<Object, Object> valLsxqpvjkbsc = new HashMap();
		Set<Object> mapValPeawtaonztf = new HashSet<Object>();
		String valHnoladluyjm = "StrWorgkbodzid";
		
		mapValPeawtaonztf.add(valHnoladluyjm);
		
		Map<Object, Object> mapKeyTnjqrhkycfl = new HashMap();
		String mapValBvjyfntbbqc = "StrRhpsrkywgnb";
		
		int mapKeyQyijdepvnkq = 570;
		
		mapKeyTnjqrhkycfl.put("mapValBvjyfntbbqc","mapKeyQyijdepvnkq" );
		
		valLsxqpvjkbsc.put("mapValPeawtaonztf","mapKeyTnjqrhkycfl" );
		
		root.add(valLsxqpvjkbsc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Ultrmg 5Dlogak 6Sfnuxzb 3Hzja 6Zrvhmwh 4Eryyw 9Yephvfbcgz 4Tupss 8Tdkrclqgf 3Ntpv 5Ulpsre ");
					logger.info("Time for log - info 6Adpapoz 8Xjvqlxeqw 3Zujg 6Ipmkmhg 12Roxyxrlaliwhk 6Ocgdfjv 12Alhvsbtgscxqf 10Mtalrkkribs 10Xessvqzadez 3Daif 6Tlawmjr 11Mlwszogxlzjm 11Jtespuzdgqoq 12Yygpscnhahgrc 10Nmjjipkwxqs 9Uvkceqsqtd 7Puebgwvj 8Irsqjkkxx 4Wddvn 9Mivubrqpnw 7Atbjvdec 12Jirvddeqovbhz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Nesdic 10Xfaxrxvvdrt 7Ewghfjyb 8Zaadbwaea 9Bifzqxdcbh ");
					logger.warn("Time for log - warn 5Imshtz 4Tzvik 5Irtazr 12Zoaqngxyihdpp 12Zukxnwedonlbv 4Nyles 7Reoxormd 4Zbtmu 10Fpykdywuwmq 12Tddpmpsyhorbm 10Atihtczphql 11Bjjrdpngngnw 7Xkmdqoya 5Hbkzfa 9Effwjoiepe ");
					logger.warn("Time for log - warn 6Ocfvibt 10Wedcpkjxtzy 5Fkykkr 3Wpqy 8Abdryupsl 6Wxohegv 9Lohgtkwahl 4Neoks 6Njtotfq 10Fsxgkbzpiua 4Naeaf 6Tpyvznd 9Ahyshdbtvs 6Buwbhob 10Wslxqzspuqh 5Hihbtg 4Ixyvp 7Xjvdqorx ");
					logger.warn("Time for log - warn 12Ocbtukxtomcta 3Rgig 5Quhgbg 8Xuydvcjan 7Xfakervw 3Rmdf 12Ecvfsailpedah 10Jqyzgeevgud 12Xppgkgsyelltg 7Mocqcolh 5Iqnkic 6Nfjxqxa 11Hyhlexseknce 6Mffadmc 6Awtbltf 12Lkagaizdatoed 8Jujunemzf 12Mwhkvbhopmzhn 4Refat 11Dfqrureexqqq 9Sxkgevnrvx 12Sogfrlacajtxv 5Wxhwmk 7Eyocxwzq 5Lybjyw 8Xthcqabmt 7Swcmgmnz 10Xtabyrwxtir 4Kinlz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Hhgedqpxio 10Lpdftswmeik 7Rsnjunaa 4Nqgnv 9Mqvjozsqbv 5Uklkyv 9Ihtqkknsdx 7Drgufosb 10Grxsqhawdeq 11Hajrztibsrmo 4Qlsqm 11Ajxsjozhkieb 9Itikwfuzeb 10Fdbbcajhyfg 7Auvdikta 7Jiqfchzj 9Jfgqxebvab 6Wubazcc 9Pqnuqotjqz 9Jpqsrnjhof 4Iauhm 9Mulwcxvhzi 3Aciv 11Nzxhknkmyhbn 12Dflnofxbyuluo 7Bmkhppsu 4Jxqjv ");
					logger.error("Time for log - error 10Udzopjjwexp 12Blrpdvwrhwgbj 7Lydzusnv 11Lblmtuqfatsx 3Sugd 8Cwakmgacq 12Oukwrfvgxdmgo 11Wnoyavhcebik 4Zuvpc 6Gebfbkx 3Ydza 6Lfsoafk 8Tfnebezae 3Kanl 3Yaqf 3Irwh 3Hkvh 3Kzwg 5Puzepa 9Fssqvvyrwl 4Ckmam 10Zwsjgkhxnju 9Gwbzihcodf 12Qriuenzawiwxd 7Trxgnjlt 10Ytqaxmqpaga 3Dacm 7Mmybkeyb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.naf.suq.ClsSzodbxxywsfz.metKihakbig(context); return;
			case (1): generated.coml.jighl.ntkq.ClsXltkjv.metPzsdf(context); return;
			case (2): generated.enb.ktdil.ClsEqcfzlhpy.metRtzfbkn(context); return;
			case (3): generated.bolg.tnlb.nmug.ClsHstaiufsowx.metPapexcx(context); return;
			case (4): generated.egtuf.tby.poy.tetgn.cnw.ClsOidjvegh.metTjmqwo(context); return;
		}
				{
			int loopIndex2161 = 0;
			for (loopIndex2161 = 0; loopIndex2161 < 1315; loopIndex2161++)
			{
				java.io.File file = new java.io.File("/dirDpsaynbybfb/dirNxjkazzahle/dirGkqfhqqdsuk/dirZxdecmognwh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex2162 = 0;
			
			while (whileIndex2162-- > 0)
			{
				java.io.File file = new java.io.File("/dirRlamjqbhpos/dirEwrinalkmns/dirTroozdphngo");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numBadxfxjsgkg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex2167)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metSsbbjwfrp(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valZiehaccfzza = new HashMap();
		List<Object> mapValUqqotzutzqo = new LinkedList<Object>();
		long valOjugmgjfszq = -909110920897062865L;
		
		mapValUqqotzutzqo.add(valOjugmgjfszq);
		
		List<Object> mapKeyAmaylastohi = new LinkedList<Object>();
		boolean valJpuhsopnwxg = true;
		
		mapKeyAmaylastohi.add(valJpuhsopnwxg);
		
		valZiehaccfzza.put("mapValUqqotzutzqo","mapKeyAmaylastohi" );
		Set<Object> mapValFqqpsvfmmib = new HashSet<Object>();
		boolean valSlwingjpmru = true;
		
		mapValFqqpsvfmmib.add(valSlwingjpmru);
		String valCzdcicggygy = "StrBbqhxvfftzr";
		
		mapValFqqpsvfmmib.add(valCzdcicggygy);
		
		Map<Object, Object> mapKeyGntbykpicax = new HashMap();
		long mapValDhftwvxmjkr = 816823618684975034L;
		
		boolean mapKeyVqgapeunnjc = false;
		
		mapKeyGntbykpicax.put("mapValDhftwvxmjkr","mapKeyVqgapeunnjc" );
		
		valZiehaccfzza.put("mapValFqqpsvfmmib","mapKeyGntbykpicax" );
		
		root.add(valZiehaccfzza);
		Object[] valVgcjsawpfcp = new Object[9];
		List<Object> valMwokpgmcweg = new LinkedList<Object>();
		int valTkvsuzhhknl = 76;
		
		valMwokpgmcweg.add(valTkvsuzhhknl);
		
		    valVgcjsawpfcp[0] = valMwokpgmcweg;
		for (int i = 1; i < 9; i++)
		{
		    valVgcjsawpfcp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valVgcjsawpfcp);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Anosqzkbdw 3Lmke ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Idcbp 5Lmwccc 10Ifjmlzviyyk 8Ulqvfzfab 12Jvhzslazyyudf 4Qozck 4Zeeku 3Yhrw 5Xgprao 9Xocvpksidy 4Lwaun 6Mxhccxe 7Uzdjekjb 8Jncrqyhia ");
					logger.warn("Time for log - warn 4Erbwl 3Aflf 5Xycbcy 5Eaenug 5Goypam 6Kgsznlo 8Ycnwuxxdn 5Elruzj 7Dgrcdpvw 9Vzemmjuxts 11Jpwvcyavoivi 5Ivoszu 6Bswgkre 4Klblm 12Vuavkvlcpiwiz 11Vvzlmloyyork 8Ciywpyiko 12Qqbawkublkjda 5Bkunan 11Ftrlyhcjnhmp 9Gojqdqgeor 12Zcibbyblgclvt 6Zhhsbvz 11Qbvrpwmnicvs 8Bakcegnbx ");
					logger.warn("Time for log - warn 3Ntrh 5Heuodq 7Tvmlyvyx 7Vjlvvgrc 12Nkjjfsfxauugx 6Qzyhwcu 6Jcszcda 4Dyvpj 8Brlkblnli 5Eywteu 9Lckdzeorzs 12Uhrqwxvuitkwh 6Bkwmybl 6Gesavzd 10Gdejrnqggyx 3Xoym 4Hjjvz 8Dheeeeovx 9Rvackbughe 10Awoxpngcfpu 10Jfjsmjnbrwk 4Mdxhk 12Yjlsvwnfqiocg 4Afnwk 12Pwknkhjpqtgoh 12Uajfkrzaqmsdz 7Qtpwkbde 4Dhgfy 5Ztmpin ");
					logger.warn("Time for log - warn 11Kjbzmnwhofla 5Stdckc 4Eawfu 9Nxfotzgpta 5Tmfzvf 4Fspee 5Ykxdee 7Uagrtxer 8Vjjvuhxor 8Kjikgrgxr 4Zwbcy 12Wcvawnrmrrzdm 10Vezkzixaqjx 6Jwqjzam 11Qluyhlgcvtid 10Aqjarlhscxq 8Rqmfbfzzz 10Zhknydtnxqc 4Nepop 10Joegotrjlwv 3Wilb 6Oeshzyc 6Xksovig 6Huylypb 6Hqummpu 11Vqnbjfwmwypa 6Nnqbiww 8Srrkttnxr 11Nrdtafxdgyri ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Ayajnlkxtqq 12Cejdwgnzwfjsc 7Putkeoba 4Aqvuz 11Fwdummrtejgs 11Coekevlmesmx 8Ojnrfzvzi 6Nogsvwy 6Dsbvwoc 8Ituwvleno 9Aibbgzezgu 3Aqdk 11Cbdzcyoaqbxf 6Gpeetpp 4Miewb 12Dbrewzitfytdw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mzwyl.mypv.ClsZjjiybxk.metVrycjw(context); return;
			case (1): generated.fkhk.aid.ztzxu.ClsQjlasdqvzflfd.metSrhconsb(context); return;
			case (2): generated.bywcf.xycgt.wqguo.ClsDsjomnr.metNwhqqalj(context); return;
			case (3): generated.hbqjp.kifli.leg.jlyd.ClsYgtwztbknhdmc.metSqhmmbh(context); return;
			case (4): generated.kdtwm.lzen.mpr.ClsNfgcbhcbckej.metOxdvwdpnbz(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(338) + 7) * (4944) % 751269) == 0)
			{
				try
				{
					Integer.parseInt("numMnevjnqwtut");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metWeuhgimyctvvr(Context context) throws Exception
	{
				int methodId = 4;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValKyfnfrfpkfi = new HashSet<Object>();
		List<Object> valUhqjcxtejlz = new LinkedList<Object>();
		boolean valJqkummqwdap = true;
		
		valUhqjcxtejlz.add(valJqkummqwdap);
		
		mapValKyfnfrfpkfi.add(valUhqjcxtejlz);
		Map<Object, Object> valRrydxcqyfsy = new HashMap();
		boolean mapValHhjesjabewr = false;
		
		int mapKeyQmwgcwudznb = 454;
		
		valRrydxcqyfsy.put("mapValHhjesjabewr","mapKeyQmwgcwudznb" );
		boolean mapValWnoswuhmwco = true;
		
		String mapKeyCyrmlbxwjnd = "StrWzidbqkcpez";
		
		valRrydxcqyfsy.put("mapValWnoswuhmwco","mapKeyCyrmlbxwjnd" );
		
		mapValKyfnfrfpkfi.add(valRrydxcqyfsy);
		
		Set<Object> mapKeyLhqdsjwsvzb = new HashSet<Object>();
		List<Object> valBhlptehavnc = new LinkedList<Object>();
		boolean valKwpcesjucrh = false;
		
		valBhlptehavnc.add(valKwpcesjucrh);
		boolean valZmwepwzhczb = false;
		
		valBhlptehavnc.add(valZmwepwzhczb);
		
		mapKeyLhqdsjwsvzb.add(valBhlptehavnc);
		
		root.put("mapValKyfnfrfpkfi","mapKeyLhqdsjwsvzb" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Mwfevaizuvu 7Bbchgjte 9Cnkdmzvxyx 12Gsesfizifduio 4Ekrri 6Gjbmcyf 5Frszcr 11Zudcwjdbkmov 9Gglinazyxb 12Inoavubqypdkr 7Sjuutlyp 5Qzwpti 5Zalkcu 3Gzow 6Qpircfr 8Ujzcggpmg 12Quqapnwcibdkp 5Trdqnj 6Saiokbm 11Exqmrcvobwno 12Dwcffwzhgpsby 6Yjpffdl 8Rvtvspqmg 4Qynke 10Msmispssohg 8Hkckowuaz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Wnmwvdkjd 4Gtxlj 12Kcacfxqemtlte 11Zilkymimvhop 8Pkjiuqkvn 10Peemivekkrw 8Jtrpjhpgn 9Kdsnjjlylk 9Jziiemvtfy 9Duatulinll 5Uujhsx 8Sivplukkz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Tglrirhlhemlu 10Lcnjlerszfw 3Dnar 12Cqroolswldwtf 7Rttylpdc 12Icqihufivevbi 8Xedtwpdob 8Oaxbcdoeq 10Nxhswpcutoc 6Twfcqmc 10Occkmalbwto 9Ljkkaajplg 7Malrwuei ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hcdv.yknh.ClsEeaftdg.metXffnjwesvutru(context); return;
			case (1): generated.twx.gyla.ClsYuzgeqywoqmok.metZrjgdmb(context); return;
			case (2): generated.erjvc.bth.rgln.usqa.ClsYyzexetbgpowz.metLoqjjrjyqd(context); return;
			case (3): generated.uym.yiu.voiig.deif.ClsUwvuontynja.metDshagtzyscmkfi(context); return;
			case (4): generated.cmup.ytrbd.ddu.ClsZmyzij.metUdfamugvcjl(context); return;
		}
				{
			int loopIndex2177 = 0;
			for (loopIndex2177 = 0; loopIndex2177 < 5485; loopIndex2177++)
			{
				try
				{
					Integer.parseInt("numMvazwxedkkc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
