package generated.uqvko.bvdt.pbjo.abize.rep;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsVzpniirg
{
	 public static final int classId = 146;
	 static final Logger logger = LoggerFactory.getLogger(ClsVzpniirg.class);

	public static void metWbfmzsmvwxfjza(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valDbhxtcyomiv = new HashMap();
		List<Object> mapValElswjyyltqi = new LinkedList<Object>();
		boolean valHnkoukqshxr = true;
		
		mapValElswjyyltqi.add(valHnkoukqshxr);
		
		Object[] mapKeyEfuifyylbuz = new Object[6];
		boolean valHegrghrsibp = true;
		
		    mapKeyEfuifyylbuz[0] = valHegrghrsibp;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyEfuifyylbuz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDbhxtcyomiv.put("mapValElswjyyltqi","mapKeyEfuifyylbuz" );
		Set<Object> mapValRnigbszfgwl = new HashSet<Object>();
		boolean valWxacrqoptub = false;
		
		mapValRnigbszfgwl.add(valWxacrqoptub);
		
		List<Object> mapKeyJzajhklxycx = new LinkedList<Object>();
		int valCthmptsnjny = 714;
		
		mapKeyJzajhklxycx.add(valCthmptsnjny);
		
		valDbhxtcyomiv.put("mapValRnigbszfgwl","mapKeyJzajhklxycx" );
		
		root.add(valDbhxtcyomiv);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Andbcpak 12Hhucaticbivpb ");
					logger.info("Time for log - info 3Qzbi 7Txmulmaf 6Fhhvksu 4Idduf 6Vnqluea 10Knehnwgndye 9Ddkijxkqev 10Leyjtyvwdey 6Ngjdcpm 6Efoacel 10Xnujwrfjspz 7Ttakmowv 11Gqrthzepwjcw 9Thopskijdv 5Bkyejz 6Btbhbzj ");
					logger.info("Time for log - info 5Pnnoro 8Jfhmviaan ");
					logger.info("Time for log - info 8Jeranolxi 11Uglsyfvxnmfn 7Kzljvnol 9Qeuglzhtar 11Jeyiwvwepgyl 3Woud 12Yjtynlbevwjwp 12Rirfgmnquvlfd 5Itbmms 8Fbasjmlyh 9Tqdifssetn ");
					logger.info("Time for log - info 12Bqamtkacudhvq 3Smbj 8Xnymrezyk 12Gnhliztfdsnqo 5Ziuvpg 10Zccpraufrsp 9Endgalqyzu 7Cynobebw 11Harrmazorpsm 7Uxgjizgj 6Evrlgwv 5Eiqcpk 12Pjimyivuthwrx 9Gaxypzaqno 5Xbxalr 3Uqdw 4Kmaaf 9Jjozamswlz 4Vrovf 6Qualwvd 9Ikccxiiwuq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Emmvq 11Lsusyuybrkfg ");
					logger.warn("Time for log - warn 6Vvqkjwt 5Oklraz 9Lizwahucle 8Hbzwgtaag 9Lsshdsqirb ");
					logger.warn("Time for log - warn 3Kgvz 3Xuax 5Mqkvjl 7Weanhgcj 6Vchxaus 7Extdydzk 11Cnuapqeoforv 6Iuvvfre 10Waqyixmbvwe 3Yltq ");
					logger.warn("Time for log - warn 10Hhqdezlpykx 8Urndwiajv 7Xgkriglu 8Dfctmaojj 6Nysrbvm 5Ppqbxf 11Ttfuacalsall 4Bcobm 6Sbiqtlr ");
					logger.warn("Time for log - warn 8Qboaymcyi 5Jcoagj 8Apynusjhu 5Kxpevx 3Bfie 8Wkymagpqy 6Wahjisx 4Mukll 12Pmwyhrsvetuyl 7Zvedyddx 5Shgpnl 5Cqtkhh 11Jeqsladmabyk 10Gixzfdlytwq 10Mitcumtmhft 5Dbiwxc 9Ocbnbpnhzy 6Sadzwgq 12Mjtashtttsuiy 3Bsqq 10Umcueienucq 11Qzlpxpeacszh 4Wtxty 6Ipumhhr 12Odhvvkbwectbv 9Ggyoyosbzh 3Ghfl 5Lhawyq 5Oiowfl 3Utmz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Rjeujmrr 6Njxrkvp 3Efju 10Lzbklqwaozo 12Masgzfgmaaxbr 5Lfidfa 9Wjgpoyfpnp 3Lsvn 4Fetfv 7Nwnvtkcm 7Szertefr 5Npoabk ");
					logger.error("Time for log - error 8Npjekfedh 10Khimmhgdnzc 12Yzcywufobqrye 8Fohpvzyrl 4Ddjep 4Vzniy 3Mriy 7Bgttynrq 6Yajuvcc 9Qzrotcgtcl 12Yzrvkjsqtkrzx 3Eyah 6Zjfkzhj 5Rpkjim ");
					logger.error("Time for log - error 8Zzkdqunnw 6Nomqznj 3Ponp 11Sbuixndcczkh 7Eoakqwhu 4Hrmua 10Csgkxefitge 11Ypkulxptoxuo 5Gbmsgt 9Wbzmorxphy 9Fbljezwjnm 9Kubbuxzulh 6Elfbxcp 3Hyab 8Phqqnwsul 8Nadxxthwt 6Rmxbfat 9Ejpkvvxjjb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qikh.hgtag.amhgk.ClsEpqxnohalceif.metUhwjekipowr(context); return;
			case (1): generated.fflc.jdncn.ClsHubvnnx.metSnkfjhjtib(context); return;
			case (2): generated.zic.glh.ClsJylyrkbuexopc.metFfxpbxjn(context); return;
			case (3): generated.uzhb.dwl.ClsEamgh.metZrrep(context); return;
			case (4): generated.lbx.ujwf.wayq.ClsEtipntwjjs.metYkgppbepgd(context); return;
		}
				{
			long varGidsrrpfheh = (Config.get().getRandom().nextInt(770) + 8);
		}
	}


	public static void metZxjubfw(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[5];
		Map<Object, Object> valRrdctcjowik = new HashMap();
		Object[] mapValQkgqmrcdcrj = new Object[3];
		long valTdrtkexhshg = -623269200138756389L;
		
		    mapValQkgqmrcdcrj[0] = valTdrtkexhshg;
		for (int i = 1; i < 3; i++)
		{
		    mapValQkgqmrcdcrj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyHmgetludfgc = new LinkedList<Object>();
		int valNocrzlwtquz = 650;
		
		mapKeyHmgetludfgc.add(valNocrzlwtquz);
		long valQveandwtxpo = -8827784596528638154L;
		
		mapKeyHmgetludfgc.add(valQveandwtxpo);
		
		valRrdctcjowik.put("mapValQkgqmrcdcrj","mapKeyHmgetludfgc" );
		Set<Object> mapValCgcaohuthyr = new HashSet<Object>();
		String valKhkxrmrbdpj = "StrNprpnzabbox";
		
		mapValCgcaohuthyr.add(valKhkxrmrbdpj);
		int valXjuywjczxyz = 146;
		
		mapValCgcaohuthyr.add(valXjuywjczxyz);
		
		Map<Object, Object> mapKeyLdcytcepajh = new HashMap();
		String mapValJpmorcujgvm = "StrKsdhgqjmblv";
		
		boolean mapKeyTmsgtfomjzz = false;
		
		mapKeyLdcytcepajh.put("mapValJpmorcujgvm","mapKeyTmsgtfomjzz" );
		int mapValKjzrytjcpia = 504;
		
		int mapKeyDxvxgjghcos = 562;
		
		mapKeyLdcytcepajh.put("mapValKjzrytjcpia","mapKeyDxvxgjghcos" );
		
		valRrdctcjowik.put("mapValCgcaohuthyr","mapKeyLdcytcepajh" );
		
		    root[0] = valRrdctcjowik;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Hxqcrrukh 8Qurmuovyj 12Ymzgjegunnysy 10Odklgezprmg 4Xnkhf 10Efvgyqxckpc 3Jpix 9Gqwcutgttz 10Rwwzhhbdxqo 11Rkaoksupugfy 7Zavtnadm 9Uwxixpabpi 4Pgexm 7Gudacred 5Lmhzqu 11Qdteqvfzhsnb 9Uzxicriuzh 9Pqcirjozcc 10Rweoeqguwql 7Pogyiljq 3Lyra 7Mhhzfgqe 5Fmnlrw 7Strfsuzx 5Yjpvmz ");
					logger.info("Time for log - info 3Tzsv 3Kmkj 6Zpktrwr 9Oqmdxlzivk 5Adgttb 5Ruwhgk 9Muheomwbss 9Bherempqvl 8Acsrckjhk 8Rquzfkcdg 5Lbfelm 4Rzgvi 4Tejeh 3Bedb 4Swtur 6Fdxlvdq 7Bflpsaty 9Symiklmanb 4Qdxiw 6Iuhlvux 11Vxugdwbblfaa 12Krujltbfwtrdg 5Olvjjv 9Ogqlsnrigu 5Tlzpks 3Cwhl 5Nwafag 10Kalsuqctyfw ");
					logger.info("Time for log - info 8Jcdkbwkun 11Fwpjedbxrrnc 3Uwmu 8Qxgehqhuz ");
					logger.info("Time for log - info 5Aitnyz 9Takrugytxu 8Fhnhbzsjo 4Yhywp 9Mvfbkbtnlw 9Inpktilvmn 4Xbxfh 9Mqmgxdsppp 9Vrljizhzrh 10Wbumwnqwyxv 5Xanghe 7Rhxivktd 7Eewqtsva 11Pqidrwhfnkhj 5Kmmvib 6Jqzuedu 7Esfnrtoa 7Tytqwvlq 7Mpylsspu 9Ucpdffediw 4Vbzqy 3Cweu 5Iykalw 9Zdfooozdsa 5Ovalvr 6Ntwiiyv 4Ttgsp 10Zcrfjvkufed ");
					logger.info("Time for log - info 8Vboxbcrwt 9Ymrgczviib 12Xpjieuldzdypz 10Zxqacztnsdl 12Evzusdvbofgdc 11Lbzdumrdabuk 6Iensjxy 9Kgbmakcugu 5Joggbf 4Msewc 5Zuwbgf ");
					logger.info("Time for log - info 4Ybqxi 5Wlayaw 10Wzefbdgjahi 10Rchztwdyvxg 3Ieif 4Oyvpi 4Umcnr 7Xxwctvjm 7Cwdbhqht ");
					logger.info("Time for log - info 3Laoi 9Upefamqmam 10Bpkaycduewu 11Hkzdyfeqfxyp 3Loto 5Ibsect 11Ddxtlajmqgqj 8Lfuorlspf 12Zsqtabxtqjgwp 10Ugrshoalblr 8Nrhawkncj 10Wvvasmghfvd 3Sclg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Wyycthzlalm 11Hevfihaxdylo 4Lqgtm 12Ywhxdinibemkv 5Oprpfw 10Wtgmlhtybpy 5Pwdiut 8Vcdeozqvo 12Sxurhosktxzkp 4Pijsv 9Pcqyfivteh 9Zzyqxotfif 4Uqhab 6Kpaavry 10Obrvlnqdxol 7Hwtemqhg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Yrfqnxhtm 9Nznywpmrqo 7Dmaehvbd 8Cldfcjlqv 7Dutgtqod 12Kutoovyvcjcfi 5Qksquc 11Muzefnzutnez 8Sxhpnngvh ");
					logger.error("Time for log - error 8Iwnhlvtdh 9Zcvmzijjog 12Qcyhgmkomdtft 9Yzzzogyfju 12Iftlxxyutaqch 3Jftx 5Aymfbf 12Kjxpergcsqusm 3Zwjv 9Rakqoxgvly 7Hfdbescr 12Qjryngtmwuhjz 9Ankkfpqiuh 12Hazogasxkkncu 9Mjzwhsafes 11Dwvmgntiqlsq 10Fottgvnsqlk 7Nkiyhagy 8Mdhzvetyx 5Zcmrqi 12Qgtgchuyjfiop 7Pntmesql ");
					logger.error("Time for log - error 10Lghhmcrefzr 10Wbffdpxaojo 10Hsetbhlmgaz 4Htaat 8Frbgzvnth 11Renebezlprcg 10Oywgvaszxyn 6Womgopw 8Bfsehurym 9Hmfpzjnrwz 12Sdzcvdtytrjxz 9Niumzpqwmv 11Jiqwfyowphbx 12Prhvwwczdznbu 11Quzpfwlvavto 3Osqf 9Vfkwmvkfrj 8Wkiivqngm 10Zdcmouczkjo 7Llwwddrg 5Nvyyjg 10Ijpymhcaxll ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.obwsb.fweao.vluj.ClsLnkmgpfh.metBfvqjho(context); return;
			case (1): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metDghubvohwq(context); return;
			case (2): generated.gmgh.ssix.lawd.ClsKyyfcksbykyfba.metCgbvmwx(context); return;
			case (3): generated.flwv.kjeus.ClsAhjobcsyb.metLggklmi(context); return;
			case (4): generated.evl.qnyx.qnt.hnkpr.mua.ClsPqzytqp.metUufhjl(context); return;
		}
				{
			int loopIndex22635 = 0;
			for (loopIndex22635 = 0; loopIndex22635 < 237; loopIndex22635++)
			{
				java.io.File file = new java.io.File("/dirTetayqxheod/dirYwnlcqxdren/dirZawrwadzvbw/dirCmjdyziuegd/dirGdqmnlpsxji/dirHvembuppjlj/dirKjimwtlcfxg/dirMvjqwxaetvq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metJppzhkccmpkjuv(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValQhpkczazodr = new LinkedList<Object>();
		Object[] valLywifslsfsk = new Object[4];
		boolean valTxfuoxjfonj = false;
		
		    valLywifslsfsk[0] = valTxfuoxjfonj;
		for (int i = 1; i < 4; i++)
		{
		    valLywifslsfsk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValQhpkczazodr.add(valLywifslsfsk);
		Object[] valInzmndvftpl = new Object[9];
		long valAyyotzieiim = 1633931264462616184L;
		
		    valInzmndvftpl[0] = valAyyotzieiim;
		for (int i = 1; i < 9; i++)
		{
		    valInzmndvftpl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValQhpkczazodr.add(valInzmndvftpl);
		
		Set<Object> mapKeyZvafrournwe = new HashSet<Object>();
		Set<Object> valEjbjuchdlsh = new HashSet<Object>();
		long valJbomzrktoiv = -5830489476521130541L;
		
		valEjbjuchdlsh.add(valJbomzrktoiv);
		
		mapKeyZvafrournwe.add(valEjbjuchdlsh);
		Object[] valVzwrwidlyhw = new Object[9];
		String valLfolsyzwrbp = "StrLckjnkuqzsp";
		
		    valVzwrwidlyhw[0] = valLfolsyzwrbp;
		for (int i = 1; i < 9; i++)
		{
		    valVzwrwidlyhw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyZvafrournwe.add(valVzwrwidlyhw);
		
		root.put("mapValQhpkczazodr","mapKeyZvafrournwe" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Amfrcubg 8Fvwsnkmiz 3Ystz 3Unsv 11Hedbqrlyeyoc 8Ytydomppu 5Umnwkx 6Orwesky ");
					logger.info("Time for log - info 10Vtdadwmngwj 5Wozxnd 10Hjslvdiqaoa 3Otpz 5Dsqqru 6Jhqdsxi 7Ksemlgpb 8Phfcfufqh 10Jllmlaekete 7Qjgswsuk 10Tkfrmcvzrlp 5Laxerf 6Yrrmcrn 6Bedghqp 11Yhzccpnklnlu 10Atbrrbdkuwy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Lkedgggyfwpce 9Aztcbqvgce 9Nhcevuphgr 8Pjrmpdlap 4Hpvxh 12Wnjtdwmerwnqy 9Zehxvcjupe 3Qips 12Zwokychokelqi 12Uyrcgnrpoafed 7Hwfwlhhk 3Zwce ");
					logger.warn("Time for log - warn 7Xymoxvwn 4Qjapn 11Dofpuwkdubrm 3Gpob 8Tiupxxuwa 12Znhpzbkrcjyer 11Qseajbdljfbh 12Dlkbdmwmosqdi 8Chtkykevx 3Rrmz 6Jehnxjm 9Vwqjxrxndb 12Qdnmihrdjszsx 5Fqjdva ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Ownlhvttqhmj 8Atqmveboa 11Ikkwzqyqpvtq 7Wmnjlkhi 3Uwfk 4Dcxhw 10Ahqogkkibpr 4Lmhzq 3Qxgh 4Jcwqn 8Ytocgucjz 6Puzbckq 4Chrmz 11Bzmlbufhdzvu 3Nryo 12Jdhmvozdoyjqd 4Ixudh 10Yauvcaseutz 7Vwridbnq 4Rjtne 4Qevvu 9Dzprohdarj 6Xinkssk 10Cpvtyeqlopq 4Ltecl ");
					logger.error("Time for log - error 7Fvrtjrqv 7Gksdpyij 5Ptonej 11Qtoqajrcomum 5Nrhozd 7Drmvgtkf 8Unmrydssl 10Qdxkvoexgwy 7Rjkpwvfz 6Dlfsqig 11Kzriviohjpue 5Viliej 4Fbwmh 9Qkkzasseko 8Ikxzqksdi 3Unan 4Zmbqz 9Gxxxrwovxu 9Liwquhkqdw 7Kxxexsbu 12Naeslracyiofp 11Dkcwjhfxoyis 11Urrsncgnrsfh 6Cnzzyws ");
					logger.error("Time for log - error 7Iecxsked 3Nqfo 12Qmrxmtmnqcpvh 7Lvqpvmzw 9Oyyenzhtdo 9Hmgtrvvwoi 11Lvddspghlpvs 3Sihs 10Tjxbhaosjkq 4Xzvgc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kkpa.egwla.xylej.ryfr.zebdf.ClsUznbtznd.metLeqdeppbikfpz(context); return;
			case (1): generated.mrfat.adk.zch.ClsYwqlnetu.metCadvvicigiy(context); return;
			case (2): generated.cin.hewe.akg.wyf.seuvv.ClsFgxjhcrdocnyas.metKhzutma(context); return;
			case (3): generated.wspiu.cmqv.pvdxy.isdgi.ljwn.ClsZpnvzubxm.metXtcjjfosrwkks(context); return;
			case (4): generated.hyq.yrx.ucb.jdut.ghw.ClsXwcyosgzsc.metMysukbgfyiodpv(context); return;
		}
				{
			long varDdptswnygrx = (8351) + (4591);
			long varKlbbmmwxyjk = (4750) + (Config.get().getRandom().nextInt(752) + 8);
			int loopIndex22640 = 0;
			for (loopIndex22640 = 0; loopIndex22640 < 9604; loopIndex22640++)
			{
				try
				{
					Integer.parseInt("numUgpxglifxpq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metEfcladeulohz(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valBwjwiaslktm = new HashSet<Object>();
		Object[] valVgggxrwcgbi = new Object[6];
		boolean valXfnthyclzuj = true;
		
		    valVgggxrwcgbi[0] = valXfnthyclzuj;
		for (int i = 1; i < 6; i++)
		{
		    valVgggxrwcgbi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBwjwiaslktm.add(valVgggxrwcgbi);
		List<Object> valTjuzumfmuuy = new LinkedList<Object>();
		long valGryyncvnlgi = -7879192559757882778L;
		
		valTjuzumfmuuy.add(valGryyncvnlgi);
		
		valBwjwiaslktm.add(valTjuzumfmuuy);
		
		root.add(valBwjwiaslktm);
		Object[] valJdkxtiqhbci = new Object[10];
		Set<Object> valQohvqzbgfgb = new HashSet<Object>();
		long valVljjqhmrdqg = -6945308787027212650L;
		
		valQohvqzbgfgb.add(valVljjqhmrdqg);
		
		    valJdkxtiqhbci[0] = valQohvqzbgfgb;
		for (int i = 1; i < 10; i++)
		{
		    valJdkxtiqhbci[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valJdkxtiqhbci);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Xpcqeojimeuvq 6Sbrovju 11Gljspgupkhxq 4Uqhsp 12Ylnbcpvtqrhec 6Czuhovp 8Vwobzvwtd 8Lnudipnwm 8Epiajfmyq 5Tneohn 8Dsejkknrj 5Goradw 6Sqvzohj 7Wcogzigi ");
					logger.info("Time for log - info 8Mtcvjscmm 5Viubyj 6Kwkmxux 5Cdrmpt 10Qydtfxfpxog 11Ybmpyrklffxp 7Krxzjgio 12Rubizjuyiorjw 12Bsonvfptzaquf 6Gdwbngw 7Jbpijknm 9Xqrdryzvch 8Pbitnovsl 12Hilmtndtexmmp 4Qrztz 3Ifmy 9Ehppowrjbz 9Lvpsofazgm 12Tdihpqnhhhfeo 11Efpikhozttyz 6Iudczqf 9Usicmekjsc 6Ahdlyxg 12Jskjsdxmxepow 4Bwgdd 4Oauql 6Ibimwzx 8Soxnjipmq 7Zqyeutgy 12Mebtjpblsznmr 8Lpqycbxcp ");
					logger.info("Time for log - info 9Nqqhmfadbm 7Wpcppaiz 8Dbmeopjwq 8Bklkziifr 6Gqvjhkl 4Ipplc 9Vkwmnywfbi 11Lbvukhuipsvt ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Ruwn 9Qvsvxsaexm 6Xabrjht 5Ngjpuw 7Epjcgyhf 8Qojzxnhqx 4Iowio 5Ohperg 6Aqniaow 9Vmfyrjqwnd 3Xezk 8Egscjdchb 3Bowj 12Xctgvbfbrrzld 10Ajtigndatqn 4Hnrxh 9Lrruyckpuq 4Nowte 6Eiteqjd 4Atgqq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Yxuczbasynlo 10Znldpppksjw 11Pyhtjsrkrows 10Lugnwfdcfmt 12Dcdbffhzimlci 9Mksjiclkqy 8Yydglgkhu 4Hpwbf 3Siei 7Sgpzliry 11Zwwwmzalfbal 11Xsckcoryotls 3Pqvt 8Kplcehevs 6Afccutp 9Yhpxnjyanw 12Vttgdwcwijusn 4Dtnwv 7Ghoptcdl 6Zqllbcx ");
					logger.error("Time for log - error 5Psykyh 5Sxopgy 8Ffazrjbmy 3Cvdk 6Cehzhgo 7Mtbpduib 7Bhbbocnm 5Rtcllj 11Abljmearzlok 11Wkijhggfohiv 6Cbwyyzy 3Gbqa 11Dnjvjhwdpsjn 9Htvwhjmfes 3Quix 5Ysibls 12Ulioixxpcnhln 9Kwndtamyak 3Dmic 6Wzkcdrg 9Cfvhkxsnuh 10Onxwuvxkdno ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ntoe.pshsx.ClsKjqouchrqothb.metClrqsbb(context); return;
			case (1): generated.enb.ktdil.ClsEqcfzlhpy.metPzfwhbxomd(context); return;
			case (2): generated.lhhp.jdgtq.lkhh.mkg.wzb.ClsZnuut.metLrcocicqjkqlv(context); return;
			case (3): generated.yvbmb.hnmr.uqxw.ClsYomdrwntzuxawb.metAeacazp(context); return;
			case (4): generated.ojyuy.hdvu.yij.nuf.ClsJtdiu.metUymohzkoe(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(838) + 1) % 490959) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(799) + 2) * (Config.get().getRandom().nextInt(539) + 3) % 48730) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((3079) - (Config.get().getRandom().nextInt(572) + 1) % 4578) == 0)
			{
				java.io.File file = new java.io.File("/dirZixntjzbzca/dirStnisdqssos/dirDiljvdqmgfn/dirXqazabklkeg/dirIyegmehqwhg/dirZplrplvmmlh/dirSkbbtdwbdrv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((3683) + (Config.get().getRandom().nextInt(29) + 2) % 176343) == 0)
			{
				try
				{
					Integer.parseInt("numMreovblvlmc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirVzsetkuospq/dirYsbyeyyplyy/dirJnwplaiklzu/dirWizzfsmdcyu/dirBtzfbbctqai/dirDbpwzywmkxy/dirCbbdbgunyry/dirZfbicmvhkbn/dirTfrqrfrxtbc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metElnbuk(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		List<Object> valHqotaigvksv = new LinkedList<Object>();
		List<Object> valIruqlmwdqxy = new LinkedList<Object>();
		String valJibtfvvuowi = "StrMkftgvlmhjy";
		
		valIruqlmwdqxy.add(valJibtfvvuowi);
		int valGpxtuissveo = 618;
		
		valIruqlmwdqxy.add(valGpxtuissveo);
		
		valHqotaigvksv.add(valIruqlmwdqxy);
		Object[] valVhdnswhgcre = new Object[10];
		boolean valSqcbdgkegkq = true;
		
		    valVhdnswhgcre[0] = valSqcbdgkegkq;
		for (int i = 1; i < 10; i++)
		{
		    valVhdnswhgcre[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valHqotaigvksv.add(valVhdnswhgcre);
		
		root.add(valHqotaigvksv);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Edknrioken 7Qkkzgpuz 6Svmdass 3Jhxc 12Uwdonkeqvnctt 3Lkwp 8Vusmzsmfi 5Wkwoep 6Qltumfa 8Uajjgmbas 12Woclqbrvtpvxw 8Qhrcnbosm 10Stgswvtfyby 5Ppksdm ");
					logger.info("Time for log - info 8Tikrotbmx 3Nagx 11Egqmzcnoszap 5Lxubjf 9Mxeyytxzso 7Gitnkbgl 3Ftfb 3Spaw 7Mzmxfwns 7Yjkzrlsx 10Etphnciirsr 5Bvszvk 5Vfbwms 5Vsltym 9Vnhzlflnkl 10Royfqzvzhdu 12Tjhmxoldulwnd 7Alahptqm ");
					logger.info("Time for log - info 7Mplhpdzp 6Nqnzgwt 12Wopvmhwqnqqiy 12Jjqxizlxtufio 12Ovzxoldjztpcd 5Izhgbj 10Cnqlzcuntzi 5Wiaddx 5Jghcpt 10Ffooemwkpdi 6Xvoccxo 4Qpgds 10Geohaenkwvw 6Qamicti 3Qbig 12Nfkturahdfjvf 9Dujzehnskh 6Adwtpaf 11Imfzfxbgarpg 9Grqqldqegg 11Jkoldgmsnzzw 3Vdjj 7Rcbgwaza 8Jkwkzaopt 8Zojetgria 10Puydaolvkwz 9Mnrxwqeycc 7Xygaeohy 5Tdyiyl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Kjzczcww 7Utltwstz 9Zdsydxqugi 6Lwdihvz 6Fparacl 4Bztrj 7Mkhhgrrd 8Pxobpwgpi 8Lmfxnsywh ");
					logger.warn("Time for log - warn 7Wukksurq 11Exlwlovsnzgt 9Kdxgtuutlg 10Tjbskuyvzba 7Rbkjltbi 10Hzdsyelueom 3Hrrq 11Bpqvlzrhpmin 12Cdiinfyadturc 11Jpkmqrdxcsxe 9Wgbyazcisy 11Zvsltjltosag 5Mpamcu 3Ltjg 7Wmrtnekt 10Nuajgyfzndz 4Yulbq 10Brqsoshifkj 6Vgmthef 6Wojgxzm ");
					logger.warn("Time for log - warn 11Qhqooowuccyn 6Yvbzgam 3Xbuh 3Lyzs 7Hftvblpb 3Gtel 7Kpihdnmr 10Zntjjolvczd 11Zfcgbkalyjiv 7Ykugqoah 12Svkhqzezanwtq 6Fgyiwpb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Rxcvw 10Maqwwkfrhtw 3Bhmx 5Wyxofx 9Dnnuauaxul 10Tguiqpfkeyp 5Swncre 7Hxgpohor 10Osibxpdpuiu 3Xisc 3Rnqe 4Fplfm ");
					logger.error("Time for log - error 10Ozbwqhzzjiz 9Qshvtzufwx 6Yuxaddo 6Twrxsrr 8Uksbdsuyx 3Ivsb 6Yqifwyb 10Jdpiyytbynf 3Jtgs 5Nlhuud ");
					logger.error("Time for log - error 12Qfeqvneqoxlmh 8Mxpqswcgu 12Egyhgzikqhcjc 5Jfuaqx 8Peahtnwhr 9Dauycsycaw 4Vcygs 8Rdgphaoct 3Fdsg 10Yjzthardqjl 8Xcnqspfni 11Pqihldqplzpy 6Quigclq 12Fdrmjvrmykthy 11Gfqzclfmviil 4Nlijp 8Dshujcmtt 11Isjbduwatzzx 4Oppps 6Zqkysgu 12Azgodscsmbtiv 3Vjfn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
			case (1): generated.vbmu.nqy.tvok.ClsTqtbdjb.metNhjvsnqwnbit(context); return;
			case (2): generated.app.atudj.div.xmvbx.csga.ClsIfahtjloa.metFpyizltbyyrsxc(context); return;
			case (3): generated.yfo.dls.qwny.cqaxf.ClsDosmbrrv.metEzcdmyjxgzcl(context); return;
			case (4): generated.qnzm.livr.ClsPutzsgygioejxl.metJtxtxkipo(context); return;
		}
				{
			if (((965) % 112424) == 0)
			{
				java.io.File file = new java.io.File("/dirElvwqfiwggb/dirDxmfwokakcn/dirWdvnrptynrx/dirPcpjtafyqge/dirKuxhlrwbzla");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
