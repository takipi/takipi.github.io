package generated.lle.fzxn.utis;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsYhanmsbp
{
	 public static final int classId = 390;
	 static final Logger logger = LoggerFactory.getLogger(ClsYhanmsbp.class);

	public static void metGdkojhgtko(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valFyewpzmpthx = new Object[3];
		Set<Object> valZvtpdgohfqq = new HashSet<Object>();
		long valTuuldelxsna = -6098226285999076041L;
		
		valZvtpdgohfqq.add(valTuuldelxsna);
		boolean valNxtoatmzlsc = false;
		
		valZvtpdgohfqq.add(valNxtoatmzlsc);
		
		    valFyewpzmpthx[0] = valZvtpdgohfqq;
		for (int i = 1; i < 3; i++)
		{
		    valFyewpzmpthx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valFyewpzmpthx);
		Set<Object> valVonfseoqgvb = new HashSet<Object>();
		Map<Object, Object> valHfwxhnoathi = new HashMap();
		boolean mapValXmpypimlony = false;
		
		String mapKeyVaxqzbgycad = "StrUgccfodebpo";
		
		valHfwxhnoathi.put("mapValXmpypimlony","mapKeyVaxqzbgycad" );
		
		valVonfseoqgvb.add(valHfwxhnoathi);
		Object[] valMeonpbuizor = new Object[3];
		String valIbzyhfbhruu = "StrLwxsdrfyiii";
		
		    valMeonpbuizor[0] = valIbzyhfbhruu;
		for (int i = 1; i < 3; i++)
		{
		    valMeonpbuizor[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valVonfseoqgvb.add(valMeonpbuizor);
		
		root.add(valVonfseoqgvb);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Uqqbyvgbql 6Vwocajc 4Kevta ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Xibetxxmeg 3Hqlr 3Pmob 12Ofbhirfavjrjz 6Hovunot 6Rylskty 12Hihgutljticou 5Ggvbyh 10Hmbxexytaos 5Veckhj 10Laxrhpzvurd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Dpjmw 8Tqxbnatpq 11Crlxauposdav 8Hgbjurccr 5Nsquyy 6Ifzhhcy 4Hqdbh 12Ogiecwslsswbo 8Prswuoybm 4Skidd 3Waqz 8Gjfqzmlhw 10Heprrhfvpuv 5Bcrpso 6Hebkasj 11Hzridsbvnmso ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gww.spuw.jrq.nmv.xowli.ClsKosigq.metKvjjegqp(context); return;
			case (1): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metLcfufswjvofrzb(context); return;
			case (2): generated.yvh.anu.xzpk.kfbih.ClsLfieczuv.metRtzxd(context); return;
			case (3): generated.kibd.nddr.nknr.pccz.hryio.ClsBgthm.metFrmpvshfvh(context); return;
			case (4): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metJyydls(context); return;
		}
				{
			long varKqjgdzxjwkh = (4315) + (5497);
		}
	}


	public static void metZkoiifaijv(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValMsvhaqtirif = new HashMap();
		Set<Object> mapValEicublsyvoq = new HashSet<Object>();
		int valCrxxmpuuwed = 815;
		
		mapValEicublsyvoq.add(valCrxxmpuuwed);
		
		List<Object> mapKeyBwrtlahibms = new LinkedList<Object>();
		boolean valDidxelnkuix = false;
		
		mapKeyBwrtlahibms.add(valDidxelnkuix);
		
		mapValMsvhaqtirif.put("mapValEicublsyvoq","mapKeyBwrtlahibms" );
		Map<Object, Object> mapValUrfdmrahift = new HashMap();
		boolean mapValDrpclgehdjn = true;
		
		int mapKeyKdtijsdlghy = 546;
		
		mapValUrfdmrahift.put("mapValDrpclgehdjn","mapKeyKdtijsdlghy" );
		
		Map<Object, Object> mapKeyWviedfmgfwv = new HashMap();
		String mapValUyghherglmy = "StrKrlnzyxrsiv";
		
		String mapKeySjnsiatudqz = "StrBxlqswwaobk";
		
		mapKeyWviedfmgfwv.put("mapValUyghherglmy","mapKeySjnsiatudqz" );
		long mapValVustznpmdde = -3823822269008294280L;
		
		boolean mapKeyCqeljdziehm = false;
		
		mapKeyWviedfmgfwv.put("mapValVustznpmdde","mapKeyCqeljdziehm" );
		
		mapValMsvhaqtirif.put("mapValUrfdmrahift","mapKeyWviedfmgfwv" );
		
		Object[] mapKeyBmmrrrueetj = new Object[6];
		Map<Object, Object> valGpovrkuskpq = new HashMap();
		long mapValFlefmzvtkgo = -2221749556678650527L;
		
		int mapKeyRbmpkzxxzxx = 886;
		
		valGpovrkuskpq.put("mapValFlefmzvtkgo","mapKeyRbmpkzxxzxx" );
		int mapValGicmzyzyqvx = 885;
		
		boolean mapKeyErfwprqvrzd = true;
		
		valGpovrkuskpq.put("mapValGicmzyzyqvx","mapKeyErfwprqvrzd" );
		
		    mapKeyBmmrrrueetj[0] = valGpovrkuskpq;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyBmmrrrueetj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValMsvhaqtirif","mapKeyBmmrrrueetj" );
		List<Object> mapValHpbcxshnrli = new LinkedList<Object>();
		Map<Object, Object> valJvrtcweokpg = new HashMap();
		String mapValScekheyusae = "StrEzplraoohju";
		
		boolean mapKeyMedayjmehca = false;
		
		valJvrtcweokpg.put("mapValScekheyusae","mapKeyMedayjmehca" );
		
		mapValHpbcxshnrli.add(valJvrtcweokpg);
		List<Object> valFwhabnmepje = new LinkedList<Object>();
		boolean valDqwbmosdpvt = true;
		
		valFwhabnmepje.add(valDqwbmosdpvt);
		
		mapValHpbcxshnrli.add(valFwhabnmepje);
		
		List<Object> mapKeyTovfwievfzt = new LinkedList<Object>();
		List<Object> valLpzdptvkpkk = new LinkedList<Object>();
		long valYxgozicball = 3395062658972765003L;
		
		valLpzdptvkpkk.add(valYxgozicball);
		boolean valFzpukrpkdsb = true;
		
		valLpzdptvkpkk.add(valFzpukrpkdsb);
		
		mapKeyTovfwievfzt.add(valLpzdptvkpkk);
		Object[] valAfyyvgbfjnm = new Object[9];
		boolean valPslslmbbrzx = false;
		
		    valAfyyvgbfjnm[0] = valPslslmbbrzx;
		for (int i = 1; i < 9; i++)
		{
		    valAfyyvgbfjnm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyTovfwievfzt.add(valAfyyvgbfjnm);
		
		root.put("mapValHpbcxshnrli","mapKeyTovfwievfzt" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Ixvstl 4Pyliy 9Zvodrarpbq 12Fjnvivxkdrtap 5Dnpvhy 5Qbizoe 3Wkgy 12Exwswdharbufw 6Jaxyfbv 6Gbuovho 10Gkhectjodsh 11Peszlzwptffw 7Kwomqdke 3Fjdv 6Rrhyrdb 3Cius 4Ywagz 5Ldeftv 11Hnjoywamlspj 3Atlw 7Ghynqxvo 8Fjaebhshz 10Pmzojztjoub 9Fwuyyfbypv 6Pglztgq 11Hghbdlqxuphr 3Yidh 10Neqzynjmauw 8Dtutokbxn 9Slctzpqkta ");
					logger.info("Time for log - info 4Tryxu 8Uhiawmlvv 6Ehukwfc 11Awzqzwtwtxeu 10Qpxxgkhqqzu 10Ykmtaxlhbzv 10Cnenxomtjsw 3Fnuk 4Lqsnb 5Mhxppy 7Xbxrtacs 8Ecxfbqxwl 9Qdcqwtpvrm 11Carrjabavibj 5Tmlryr 11Jjzqmkecvhwk 9Vcowtjnpnk ");
					logger.info("Time for log - info 4Cfvat 10Gqdedjdcjea 5Arnrau 9Phxhdsziir 6Tsdoirg 9Sciprxufut 10Jissozqvsou 5Rtcqmz 9Izpedrijnx 11Gkxysokfdpmh 3Kxzf 3Imxy 3Xcib 4Bxvnw 9Epqolyhntv 4Fnhxf 11Bpzrxecxsmuj 4Pvzdp ");
					logger.info("Time for log - info 7Jlwctwtt 8Qpojcfpsz ");
					logger.info("Time for log - info 6Ptmycxe 12Xkzomuutkslxr 12Tlqonsfgujqal 5Bqlzrt 5Zyfrmn 3Bpgp 9Aqyybwtooy 8Fqxpfjvkz 12Ldhczheqguadt 10Akuxlvekgmy 8Cotvorjgp 11Jfvqnexbelbv 4Ssgdl 12Fnrgjcduamveb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Xewgg 7Esjdnkzc 3Kqwe 9Wmvgmldwfs 6Tsmcsri 9Boqogyufnj 4Vqybd 8Zkqdsfirj 5Jruubh 3Cqmn 4Hmoxe 7Dvuinoxy 9Eoevqomrsl 7Bowdrqcv 10Qbhcuqzgjuv 8Tvfkupxpe 12Wfswebnziyryo 3Ohru 7Stuccywl ");
					logger.warn("Time for log - warn 3Zwes 12Yaigusxfctfae 3Jeim 10Rapfldudjqg 3Vlrk 7Nsoqsoje 12Aqlvcdqduhday 6Llyoiig 6Ikelnvk 10Kudfdqaxwzm 10Cfzrkccehuq 9Wxfqovqfwt 8Nepdcvaoa 10Xqjebdvndto 6Hgbkwpx 5Dbdhck 3Rjbi 4Jdnry ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Ayzbmftzo 11Mhippdctotqe 9Svmeyovxvu 7Dijwjebc ");
					logger.error("Time for log - error 7Ksjxqiqx 7Lseptgxv 6Clntujj 10Oeszqdzevra 11Xgnzpdomosbv 3Suio 3Ufgw 7Nqbgaozx 11Evxhzlnxqgfu 12Uodtjiqkljifg 8Uswdanwbg 10Ktaixxdnvte 11Upqzjhpmrapd 10Xezhfwoxdxh 10Nmumidgxvrp 5Jbganc 11Zsqaopehrwzk 3Pqug 8Hynwyxnyw 12Wkzqmzrkqrxrd 5Ybkhmk 3Njbu 12Nrjttzbtzshqq 11Lxkqhagocnxd 5Njuofl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kkru.kkr.eff.wedv.ClsTciibuckxmwxc.metYwdzegshne(context); return;
			case (1): generated.ghyrj.islj.cfyq.ivyv.ClsPvvifymh.metMqkfvb(context); return;
			case (2): generated.cpb.wnddu.ClsLvopzbmgvjj.metJpplktwh(context); return;
			case (3): generated.erxl.yyilk.mxe.gagu.ClsTrmbyzemtaola.metTqiji(context); return;
			case (4): generated.tkix.xwxmn.tohx.ClsStsup.metKaytjwbtsoqycs(context); return;
		}
				{
			long whileIndex26635 = 0;
			
			while (whileIndex26635-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metHmamlew(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		List<Object> valEdzmbgiaele = new LinkedList<Object>();
		Set<Object> valEvpqcayiodx = new HashSet<Object>();
		boolean valRtlqmkhirrb = true;
		
		valEvpqcayiodx.add(valRtlqmkhirrb);
		long valFrethrwklcr = 920930485735454300L;
		
		valEvpqcayiodx.add(valFrethrwklcr);
		
		valEdzmbgiaele.add(valEvpqcayiodx);
		
		root.add(valEdzmbgiaele);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Pknpouoxqvgan 11Apwmvutafbta 3Huvf 8Hgawvnufb 3Ojpu 3Thko 6Texvtal 5Qmrsff 11Mcjqyjaqykjz 4Ksozs 4Klizp 9Tjmjhgsngg ");
					logger.info("Time for log - info 6Bgfkuhv 10Bexjyayuxcu 11Buepnfixxose 7Wzooaprx 11Kdanltrjqacn 4Ckebi 9Zcwnizbqee 11Pfwzcslmpdej 8Puiekzmgp 6Ycnncnr ");
					logger.info("Time for log - info 4Hjbbl 6Trhdmkb 4Cxhza 4Nvnjx 10Aoqoatmdqhu 11Vhacyidwayab 9Euwwzbotmv 12Umpfaapocltdb 8Riuqqknyr 4Rtedc ");
					logger.info("Time for log - info 12Eeaewfghwtirk 4Aflfk 9Bemkmdniog 12Ubugjpkygtdob 5Jpxgyd 5Rhvaqd 9Zhugjrsldt 6Jfdnsfd 11Qptmbgsaxoja 9Ljhgmwsfuq 4Banxh 12Khmtenpxcehzx 10Xbltvvqcpwu 3Egwz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Frjpd 11Byeokyvujhbz ");
					logger.warn("Time for log - warn 8Lzrgjefjp 3Rfna 3Rvzf 6Oeujqzs 9Jusecduihg 3Lyti 9Bvothmqmxr 7Sxfklzio 3Wifc 10Zwzsrojraab 11Mcmrzgoarecb 4Uscqf 3Kaas 9Cxsrqngkhf 12Anvaareomdzta 4Mwfbc 8Inathxvsi 6Iniintc 8Likcblcdk 3Lyvt 11Vzqhwdkpydpn 12Vwofyzdvtnqku 3Stby 8Hrvhjkpwl 12Vlfbkmpiimibq 7Uzvcbohm 9Wflaorliiv 10Oiwhtqzqlqb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.exa.yssf.ClsHuxmu.metIeneankndf(context); return;
			case (1): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metSqibhmdisq(context); return;
			case (2): generated.dbr.dvpj.ClsKgmhp.metVaplmoyavlsjm(context); return;
			case (3): generated.bwwh.pcsa.hpav.bbh.ClsXicvnzwjqnoh.metXmvss(context); return;
			case (4): generated.rxif.wckg.ncsqv.pmlox.ClsRkhayrnqgfzod.metVuvkwlczu(context); return;
		}
				{
			long varHuvhmrfyymt = (Config.get().getRandom().nextInt(158) + 7);
		}
	}


	public static void metYezvvp(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		List<Object> valOcjelfvexbm = new LinkedList<Object>();
		Map<Object, Object> valZabwlhcbidy = new HashMap();
		String mapValHmzlfzjbdok = "StrIqjrfedydur";
		
		int mapKeyHuortizqlkj = 179;
		
		valZabwlhcbidy.put("mapValHmzlfzjbdok","mapKeyHuortizqlkj" );
		
		valOcjelfvexbm.add(valZabwlhcbidy);
		
		root.add(valOcjelfvexbm);
		Object[] valOwdzmxwxilp = new Object[5];
		List<Object> valDkmocgcrkai = new LinkedList<Object>();
		long valJxpkoouilpd = -8047325678363113424L;
		
		valDkmocgcrkai.add(valJxpkoouilpd);
		String valKyvyvzkgdur = "StrKbhzesobqqa";
		
		valDkmocgcrkai.add(valKyvyvzkgdur);
		
		    valOwdzmxwxilp[0] = valDkmocgcrkai;
		for (int i = 1; i < 5; i++)
		{
		    valOwdzmxwxilp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valOwdzmxwxilp);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Hepus 10Ravocyzurgx 11Unewphoynvli 9Lpdngmmvso 7Sjvtotaq 12Ahvluqppfbzwr 4Inzjt ");
					logger.info("Time for log - info 11Fqeddoyqpadh 6Tuqthbn 9Tqczxjgler 6Abpvkvr 12Ufchsbimjdmzl 6Nugppor 9Yykthqomlb 7Vrshqdox 10Pckphjyftdc 4Okzsv 9Qqgsvoflgk 8Fbaubserw 4Owqoh 3Dhzr ");
					logger.info("Time for log - info 12Jgraqpmprjfgi 11Szgltboyvnpu 10Mprliimszrq 9Howqxsifxb 4Lswcd 7Uddwtuoq 9Ohmlfcfxqt 3Acpe 10Pnjahffewod 3Pqpo 7Hbkjxugb 5Zijoit 6Buibkuw 5Shbihu 4Ayqxf 4Rtazk 7Cgudbqnw 12Xophlorqludgk 9Xglittrhsk 10Scgvzamjsda 3Idov 12Qvmncajirwmfn 12Tmkofirpiytsi 11Bfugbrdtomcq 7Faluercu 4Dwlze 6Rehgfon 7Bgfnzthi 6Gkehwrf 5Hqkkkf 5Zjxztn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Ixnc 11Rpxfyqwoalwd 4Wvqhe 8Jxchtoqze 4Ccwwr 4Rmnlf 7Lexqyiwr 7Rnahiaqu 4Asepp 4Doujj 12Urailzefmddne 10Uqawfblqqsd 6Zcbvypj 11Ngwnccelqjug 9Hqpwrpljuj 10Edqkgobaziw 4Qjkmi 10Vxtldlbzijf 5Mdupyk 7Rtbnkurs 4Yhwoi 7Xxjglkdr 12Jnimjipazicus 11Jhuiifsxyafm 6Shwpdki 8Kdnyjniyh 4Uppfa 11Smzfbzqcjwrr 9Opobtoujrp 8Pnrpvxhek ");
					logger.warn("Time for log - warn 6Wjhdowf 11Chjkzlotaicm 11Oxaiaviqsxlc 7Vacdtyyk 4Wndka 9Viasmbcgbr 10Jglvpkbiedl 8Gmuherxyh 6Fqsfceu 3Cibz 10Qzyrafltkql 9Xhsselpvyz 12Zkjnigbqysrdk 12Azabkefntwlmc 4Scmjx 5Ruublh 8Tlordgsym 9Ywctlpsogw 7Ndplixkm 9Skhqwwjqjm 3Iems 9Dnuinvnpjp 6Ctccekr 11Kpkshlvlcxrm 8Sofcxsdnz 10Gbwctopatlc 10Ospyjskvilt 5Zpzayq 12Riwtoitegcrjr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.erjvc.bth.rgln.usqa.ClsYyzexetbgpowz.metLoqjjrjyqd(context); return;
			case (1): generated.wunj.xtrc.rfx.aikz.yopv.ClsTejixmzc.metAhxfdsezzruvtx(context); return;
			case (2): generated.pgg.urfbp.dpry.ClsLqnnoewxwh.metUlggo(context); return;
			case (3): generated.elv.qjwox.npj.oxv.jth.ClsNewmedi.metDaykkwtjgtz(context); return;
			case (4): generated.rnv.dtvl.uhnk.ClsTzqkdsb.metQcrkkxqtuodw(context); return;
		}
				{
			int loopIndex26640 = 0;
			for (loopIndex26640 = 0; loopIndex26640 < 3997; loopIndex26640++)
			{
				try
				{
					Integer.parseInt("numXxhqbonrdxq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metWjzcwu(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valZqqaeicnwwu = new HashSet<Object>();
		Map<Object, Object> valQrurihalrhm = new HashMap();
		boolean mapValHrijcjdzaej = false;
		
		boolean mapKeyCjhbsnekana = true;
		
		valQrurihalrhm.put("mapValHrijcjdzaej","mapKeyCjhbsnekana" );
		
		valZqqaeicnwwu.add(valQrurihalrhm);
		
		root.add(valZqqaeicnwwu);
		List<Object> valQzdetkpbkwk = new LinkedList<Object>();
		Set<Object> valOjtlczlypvk = new HashSet<Object>();
		long valOmiofxbytuw = -7762710915428253270L;
		
		valOjtlczlypvk.add(valOmiofxbytuw);
		String valOigubxjbboe = "StrXsxzarwivyr";
		
		valOjtlczlypvk.add(valOigubxjbboe);
		
		valQzdetkpbkwk.add(valOjtlczlypvk);
		
		root.add(valQzdetkpbkwk);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Qyxjprf 4Qqgpa 4Qobfn 4Jjxzw 6Dsgzfdm 8Jrxzpwncx 3Ggkw 11Vnqhosexqfpw 11Rcnoqonuvikf 7Nrhtipeg 4Talrv 4Suhzf 8Ivkyzamxx 9Codmtuflth 7Gwwwvjkq 12Dfinaqdxxunek 7Lzwikcbi 8Fkapspdni 4Lufro 10Akgvmbngret 9Qaiohnotha 11Sgvmsjgikzch 10Zmoiqmhcutd 10Kilxzihcneo 11Mhkfyjrtrzux ");
					logger.info("Time for log - info 12Rsedzqvabicgu 6Sauzipa 4Bzuwv 11Ewtgizytehjs 4Xtgct 7Qqifjvhv 6Zlwidxx 7Lsvdosyc 5Hwnmok 5Oegcju 4Uezzb 7Kjuwogdw 9Awfwywngtq 6Caioyil 11Fuljrbrxlsfx 8Rzwvdpozl 9Zzcfamysvc ");
					logger.info("Time for log - info 3Yaic 4Crbud 9Nfpsftxxdv 8Mrwjyeiog ");
					logger.info("Time for log - info 11Ijsiqwqoihyl 10Semlgrogdpl 11Sgtnmxuehtys 12Mgonrhdkhkxmy 11Jwdodrecqtlk 8Majkuglaz 4Wqpkx 5Cetoed 12Ipjupwzedlncj 7Otlmfgnx 6Ffwwowb 5Sqpmaw 6Fodrlug 10Wysdfmynjgg 9Wsndfuwutn ");
					logger.info("Time for log - info 7Caqvioln 8Ssogzykkq 5Deioej 3Oukw 7Bixoiqtx 4Oazxt 4Kmvhm 11Olunllybxwnw 7Wmryiasc 5Zouahw 3Haif 8Wlzkcsmlt 7Lsvchzgt 6Zniyqxy 3Opqx 4Iartd 10Slpurlxpaeh 5Ofnpvt 6Mjzgitu 5Wotqwl 5Ijrnvl 3Uunl 5Wwzjsr 3Sglo 9Zybwbnzmgx 12Oszdfzflwkcbe ");
					logger.info("Time for log - info 7Zlzfgewg 7Esnrfkal 9Emgimhbeem 5Lwrbbj 10Gzmqgepxgxa 9Mofywkmhqp 8Gsyvodsac 11Sisbueytrkoy 9Scyuorpptl 11Eivzvcuyjukl 8Bdoyinriy 9Nympvbbycr 6Ivbyokf 8Cqbwtdsyj 10Kqyryudztcy 4Dvfmd 6Irxgqay 11Jovbzdukpnfu 6Vhgogqw 9Mgoolpzaqt 9Ouivadwbwr 10Fnochmxnmnz 9Hnejiprtgr 6Xyysjui 6Wwvtbar 4Xhqox 12Rqmnslwlfpwbj 3Lvov 8Mllabtigu ");
					logger.info("Time for log - info 8Ffzlyjmyr 4Wpmxa 8Xvddfghis 3Dqpq 6Xvykguz 5Dxocin 7Letyskci 5Mjbwgw 8Gkyzpvybo 4Qnbjr 8Nsvhqkcuv 11Sgscoindpkqw 8Nrannmosf 4Ciubg 6Auzrfui 12Jxggbvcboddcr 10Ewmcnjyxcrn 11Luxuyfcetuvu 9Smeusheyzf 6Fqtozaz 9Hylskvtjck 8Viurjqsys 4Annoa ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Cewkexcvtxhx 11Vwokwucsskno 4Nohiv 3Bnxx 4Imrot 5Hrobtn 5Kjlwky 10Plqfzuhkzdo 6Rwqxqwe 9Qtqxcbuipb 3Wkst 11Qhvafdbhxgyp 4Riznc 4Mooif 8Ilxxjunxx 12Pnuujkkdsrqed 12Tkmzjzgitvcxe 7Hveslnzr 11Jqjeuggbddzt 3Qhqx 5Nmrlbd 3Axss 11Bskxvxdfmgbe 11Pootgyyhpfcz 11Lzkvkxckipdu 12Gxobokxgandqn ");
					logger.warn("Time for log - warn 5Xanlbn 5Ixuwge 12Mmzaydsqzhcbo 9Asvhsfttei 7Ksmfulsx 4Egavx 3Ueqd 3Zhsu 8Oqhstujin 6Fedovah ");
					logger.warn("Time for log - warn 7Baczrwmk 5Psbmlg 3Obte 4Pvjcs 12Xmonmggblylcp 9Alsrdhmprb 6Abfhiiq 12Buzjzqebgzmfi 12Yufvdkwnflrqk 5Vswfth 5Jylddr 5Vsosda 5Yctgzc 6Mptcock 4Xcfef 12Xmlrhomqulbdl 12Ybwmtbhlcijka 7Dtbqiitn 5Pbrbiw 3Ctcm 7Pzkxjdfb 6Uczmedd 10Yqujnjhwego 12Dmmkhaeyruxrx 11Uyzaigipexfa 11Pcyvmhxmmukp 10Tdvnpkbolvh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Jdlz 5Cmqnig 9Mqtwaebtob 6Vjfrwjh 10Mjduxcpikpp 6Wxvqljo 4Qqyha 7Ycbxgtdo 7Pwmxrgkb 11Ugnkzhjisebg 4Bbasw 11Twdbhgxdplpa 12Uogpmznwaaros ");
					logger.error("Time for log - error 9Pzurcugcrj 8Qgimhukwu 9Xtrkgeguir 11Qzbckmbofzai 9Tiliqwqiym 4Kyyxh 7Vytcqgfj 10Nispnaqkulb 9Jcqslymlew 11Sfjkxhezyqkt 7Frywkscd 3Znpl 3Eafb 4Svrla ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.axdim.stv.ClsSaegiqo.metVwtuv(context); return;
			case (1): generated.jrx.knq.qgl.klpmp.wqhuy.ClsPrfpvgkjefvagy.metFzjcvfpdxrxcop(context); return;
			case (2): generated.naf.suq.ClsSzodbxxywsfz.metFhdpmoxdz(context); return;
			case (3): generated.ecksk.wvb.ClsNtqfbmlui.metJftpyt(context); return;
			case (4): generated.ebdo.cied.ClsIqlmeepdcmuqo.metKtzhn(context); return;
		}
				{
			long varApjiiuxxoln = (Config.get().getRandom().nextInt(160) + 0);
		}
	}

}
