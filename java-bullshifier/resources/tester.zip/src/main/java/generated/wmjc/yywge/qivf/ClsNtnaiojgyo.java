package generated.wmjc.yywge.qivf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsNtnaiojgyo
{
	 public static final int classId = 165;
	 static final Logger logger = LoggerFactory.getLogger(ClsNtnaiojgyo.class);

	public static void metNewjeyyudocce(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Object[] valTemtnfyhnuj = new Object[6];
		Object[] valMhazxsgzvtv = new Object[3];
		boolean valCykoagwlatx = false;
		
		    valMhazxsgzvtv[0] = valCykoagwlatx;
		for (int i = 1; i < 3; i++)
		{
		    valMhazxsgzvtv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valTemtnfyhnuj[0] = valMhazxsgzvtv;
		for (int i = 1; i < 6; i++)
		{
		    valTemtnfyhnuj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valTemtnfyhnuj);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Jrfelajdsoo 5Klbnwg 5Pmddoa 3Hfla 10Rqxgqclbffc 9Bbgqdxinjk 11Wmsmfvjkriqd 11Csgvodjjglud 11Mpvkinfzuqdx 9Sxftmmmjzw 11Jidehzuefymp 3Hsra 4Btdcm 7Ehohsucp 5Cloolv 12Jrqtpdiwkybsv 3Rvzc ");
					logger.warn("Time for log - warn 9Txdkemzyll 8Cwoekagkc 5Fzbioy 12Alakqehyzxjmf 5Yejqpk 8Oonlzlwhn 11Cmypiippioek 5Pmddpv 8Qmkelcfwp 10Rvmbtidhmph 12Xmefksxuswnyv 11Fyuizmmjhefb 11Aiexniilzngg 7Lnctgdkb 5Zixevd 12Igugeyjbnwdxb 8Eempbzhyy 11Gsbnetolpovg 9Urmkucpqft 6Czpwepm 11Tjoyvpiafwjd 9Mrrujxaddf 6Qzkdkpv 11Pemrdsfeczlb 10Ctyzoxggfwi 11Bvgbnbfjqzeg 11Njrpwxakbcqv 4Fmjqu 10Fmpliuobqcn 8Bunwlnzlu 10Asbivlphyeg ");
					logger.warn("Time for log - warn 10Oemnftqjwin 8Zzlophptz 6Wjytxlu 4Xcjxb 12Xvkutcjxykoaj 10Qjizxpqyrqp 5Vgzfqn 8Spkomqbpk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cfolx.abg.ClsZqloaugvusc.metIpjezogguhroh(context); return;
			case (1): generated.ldtgt.vdfx.cdz.lkx.ClsLvvwnymti.metFkrjypkkw(context); return;
			case (2): generated.zhzbs.ylhl.ytr.cges.stvq.ClsYeenuinrut.metRuxodvwf(context); return;
			case (3): generated.cmlwi.ajlk.yhine.aaz.ClsYxnwkcu.metTsnvquyweiwxo(context); return;
			case (4): generated.yaahc.bwx.upsjn.ClsIxadk.metFpqlzmjobw(context); return;
		}
				{
			long whileIndex22976 = 0;
			
			while (whileIndex22976-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varFsmsftzfcyh = (2043);
			if (((8170) % 33980) == 0)
			{
				try
				{
					Integer.parseInt("numUcednbrkizx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numJblrsqqzakp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metQvixcwqsm(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[10];
		List<Object> valDpijhbqjsea = new LinkedList<Object>();
		Set<Object> valOeaurwlxxfh = new HashSet<Object>();
		String valKqjdndkczdk = "StrIpebumotpwc";
		
		valOeaurwlxxfh.add(valKqjdndkczdk);
		
		valDpijhbqjsea.add(valOeaurwlxxfh);
		Object[] valFcuezdremjs = new Object[5];
		int valKxxuhmwubsv = 14;
		
		    valFcuezdremjs[0] = valKxxuhmwubsv;
		for (int i = 1; i < 5; i++)
		{
		    valFcuezdremjs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDpijhbqjsea.add(valFcuezdremjs);
		
		    root[0] = valDpijhbqjsea;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Qrpauizrcyotm 3Obkw 10Xveldsbrsgl 7Jpzbzdez ");
					logger.info("Time for log - info 11Icrpseicqihd 10Irthhbtkbxg 6Zsrmsat 7Rdvbejim 10Icnsqjbihhx 10Cfjmtkfileg 4Tvpws 10Nkgmarqkdzc 11Xbafhgcvgjnn 5Angfbi 9Znvdndrflm 6Urlvjee 12Dwdchnpuuagpp 8Xmhayupph 7Yittwgzj 11Cyjoartcwnij 6Zxacykt 3Obij 8Nbukcolkd 4Bsrac 7Bwnlwtvh 6Zktrpfw 6Jjyqzaz 4Kbykc 6Ldcxpso 8Oadjiubvw 10Nkwkxkfigwn 5Jqqxaj 3Hmfw 9Yjvczsewgi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Uemuhpclzjhdh 6Ydbywud 5Oxlizl 7Qgrshmaj 8Gtcuykznw 12Stmowukdwqyzj 4Gcgkk 8Nljgtigrz 6Ncsqohf 8Hfyqvijjq 12Rwzlklfxtgbsn 8Jcujedexz 8Ynmjkarim 7Sqqjxxxp 8Itortsjex ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zps.umb.itoy.izyvq.ClsZdfkvvsphrjc.metAnxtjbnxsdbeg(context); return;
			case (1): generated.xij.sqewq.cevz.qdd.iar.ClsAxzlzievw.metNunaxfbnokb(context); return;
			case (2): generated.xxnyf.gha.ClsWohtztrryuonp.metBusawtcharn(context); return;
			case (3): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metBninyradw(context); return;
			case (4): generated.bftm.jkb.lcr.ctpvk.ClsYfbhukzct.metFpamceutssnko(context); return;
		}
				{
			long varIqtmjgtlubh = (3380) + (2242);
			long varGciczizktkd = (Config.get().getRandom().nextInt(176) + 9) - (1472);
		}
	}

}
