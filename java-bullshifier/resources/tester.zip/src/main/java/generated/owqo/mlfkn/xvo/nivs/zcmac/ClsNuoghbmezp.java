package generated.owqo.mlfkn.xvo.nivs.zcmac;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsNuoghbmezp
{
	 public static final int classId = 373;
	 static final Logger logger = LoggerFactory.getLogger(ClsNuoghbmezp.class);

	public static void metYnvilumdjys(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValAjijhdfkktv = new HashMap();
		List<Object> mapValQuaexisnzxx = new LinkedList<Object>();
		boolean valEzvkpsajgxz = true;
		
		mapValQuaexisnzxx.add(valEzvkpsajgxz);
		
		Object[] mapKeyAdoihxkzwqj = new Object[3];
		String valNyyhaqjijyf = "StrPdlwtnppkfd";
		
		    mapKeyAdoihxkzwqj[0] = valNyyhaqjijyf;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyAdoihxkzwqj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValAjijhdfkktv.put("mapValQuaexisnzxx","mapKeyAdoihxkzwqj" );
		Set<Object> mapValClqxgpexdvv = new HashSet<Object>();
		int valQosdcxaosxh = 390;
		
		mapValClqxgpexdvv.add(valQosdcxaosxh);
		String valWfwcsdjtand = "StrVgxgywsjsyb";
		
		mapValClqxgpexdvv.add(valWfwcsdjtand);
		
		Set<Object> mapKeyGwtsfaezgjt = new HashSet<Object>();
		String valBjovfsffhef = "StrLhgaaofarns";
		
		mapKeyGwtsfaezgjt.add(valBjovfsffhef);
		
		mapValAjijhdfkktv.put("mapValClqxgpexdvv","mapKeyGwtsfaezgjt" );
		
		Set<Object> mapKeyXntcxrziybv = new HashSet<Object>();
		Set<Object> valBjdwoxkumdp = new HashSet<Object>();
		int valFoffcwhlgnn = 32;
		
		valBjdwoxkumdp.add(valFoffcwhlgnn);
		boolean valCdypokfxzco = false;
		
		valBjdwoxkumdp.add(valCdypokfxzco);
		
		mapKeyXntcxrziybv.add(valBjdwoxkumdp);
		
		root.put("mapValAjijhdfkktv","mapKeyXntcxrziybv" );
		List<Object> mapValLnwmttgkorg = new LinkedList<Object>();
		Set<Object> valRaybsrlibpu = new HashSet<Object>();
		String valHkiimmunpoo = "StrCpheyzafaef";
		
		valRaybsrlibpu.add(valHkiimmunpoo);
		boolean valSfnjlxqhmwp = false;
		
		valRaybsrlibpu.add(valSfnjlxqhmwp);
		
		mapValLnwmttgkorg.add(valRaybsrlibpu);
		Map<Object, Object> valQqifbchopvm = new HashMap();
		long mapValPteothuswsc = -4227487194002598814L;
		
		boolean mapKeyFluvrvyymjl = true;
		
		valQqifbchopvm.put("mapValPteothuswsc","mapKeyFluvrvyymjl" );
		
		mapValLnwmttgkorg.add(valQqifbchopvm);
		
		Set<Object> mapKeyOlejcwecmfe = new HashSet<Object>();
		Map<Object, Object> valXsmysavbpqa = new HashMap();
		int mapValKxmzwilrpcq = 987;
		
		long mapKeyZysjjujylae = -4633434417336471358L;
		
		valXsmysavbpqa.put("mapValKxmzwilrpcq","mapKeyZysjjujylae" );
		String mapValJpgssyxpkgo = "StrJqvoorqkxim";
		
		long mapKeyPfvtgsfalvp = 5568266703645943142L;
		
		valXsmysavbpqa.put("mapValJpgssyxpkgo","mapKeyPfvtgsfalvp" );
		
		mapKeyOlejcwecmfe.add(valXsmysavbpqa);
		List<Object> valEsrynowpggj = new LinkedList<Object>();
		int valJmmprjauegr = 485;
		
		valEsrynowpggj.add(valJmmprjauegr);
		String valUqqltubkilt = "StrNimvckerdnk";
		
		valEsrynowpggj.add(valUqqltubkilt);
		
		mapKeyOlejcwecmfe.add(valEsrynowpggj);
		
		root.put("mapValLnwmttgkorg","mapKeyOlejcwecmfe" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Jlbmmof 11Vgnmydszpaol 6Uvizneg 5Fovhaq 3Ajyk 6Ubckzix 7Olaexwjj 4Zeixo 10Cnzxawtrxkf 3Lsrb 8Oowinaydx 5Jicuid 12Bpbbwfszzsokw 12Sgxjnjuscorlm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Rmkfo 12Rwxikdnnxuddx 5Elyria 7Fhzkwxoh 3Ewgc 9Xkvjajtvxp 4Gpkjf 3Qvgw 12Imrmaguixkszq 9Kezkhewkex 3Hkot 10Tiuueriysao 6Bfplsnb 7Nhlpehpx 12Hpbhcrdobputj 3Cxqs 7Wtphgkrk 9Jgzmbeqxbw 3Zmrm 12Dydbfgkqkursr 11Cqgmkkezynvo 12Fuzrgfxuhwegd 6Gyiejfo 11Xgpmwkrlmhna ");
					logger.warn("Time for log - warn 9Wgnnwonazo 4Ceaek 5Olglpo 7Xvxcwfve 12Caclagzlqzcma 5Vzazpm 7Pdldxgse 3Zwln 5Fudplx 10Lldizuqwuvb 7Sxibznkb 5Utohwe 4Bbkhy 12Lbvfsndbstvkz 7Bhmleiny 7Cklxxweh 9Qjllwmnsrt 8Tqepoardi ");
					logger.warn("Time for log - warn 6Ssybawg 5Wwvmff 6Fykwdfs 8Sgulvvwpr 8Vvuohnulz 11Hnuwnwxyuwpn 3Gmbo 7Lhzheerp 7Hzkfpyaz 9Giprklgyvu 5Uxnejj ");
					logger.warn("Time for log - warn 11Esvkplehodyp 5Emtlvx 3Gkha 8Nwzririwa 9Sjienbwaoh 3Bpia 8Ynzpetzpj 8Vwhaooyma 12Tjugkksersnxe 11Zhdnfqrqoxos 3Jmeh 6Qzsjavr 9Iungoembnj 3Svvf 7Dqtvqtud 4Uojlp 3Jpck 4Iihjd 12Vodwrqthcltgv 12Mvvjjcfjdgtnw 8Cvgdwdtng ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Fgymkhcgj 8Uqpfxdxhc 6Exjgiqb 9Zknrwhiicz 12Zmhinvnegahbv 3Lqqs 11Mdcnfltbjrsi 10Fktvqsmhlrq 9Qqpgulxubu 12Yqbgafejdjouj 3Unsj 5Anejbs 8Vyrhndeui 11Vealwwnouhnv ");
					logger.error("Time for log - error 7Lkbfsjqb 12Fqbfdjoumkgyi 12Aarrhdkrftuia 11Twbqowmozmss 6Iojzyex 5Tpjozc 4Rfodj 3Lzmt 3Dmzl 6Ytwqkta 10Gnruxcfhpiz 6Nuywpnf 7Iqkwplom 7Vvmnimjo 6Tfdyvln 11Ctrmpsnfenum 11Rxzahfgspvvm 4Wvurr ");
					logger.error("Time for log - error 3Odfr 12Txugyonhyeqjz 4Tcxrv 3Wenz 7Xkwqhvfp 8Stroxpuev 7Bbfsgoaf 6Pfhemhy 9Yglohrjqcd 3Qpck 5Zmuaas 8Eulqeozwt 7Eomkthla 6Kptttrh 10Ehcxnhygrwq 10Yrcexkvckia 12Onrgmnchpebjo 9Redulizrum 5Teugsv 12Zrzzdipnroiic 7Ccqxesub 12Pvrgblltkfgol 7Kwnyeutz 12Xtwxsqbfauhxb ");
					logger.error("Time for log - error 9Biuzoywtze 9Luiaghmjcm 3Krry 8Utbflkcvo 5Scxeys 12Lngpiamizoxue 9Htdoyogvns 10Kaxdfdwkipg 10Pwuiptcziuw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yzf.fayrw.fbm.pexsg.rxfb.ClsSblyqahlwj.metEexjjx(context); return;
			case (1): generated.kklo.eog.twpb.eja.vmrt.ClsCtkkdlrnk.metMzowgzzffz(context); return;
			case (2): generated.igif.laylf.mnwo.ClsOgradyyhp.metYneec(context); return;
			case (3): generated.hadv.dozj.puo.ClsVowitvkgtx.metBrrizswg(context); return;
			case (4): generated.wcc.zfysf.ClsYrxejsiwymmrbw.metKnfdaxts(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(149) + 2) % 510805) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex26301 = 0;
			
			while (whileIndex26301-- > 0)
			{
				java.io.File file = new java.io.File("/dirPskucbolnbi/dirNfrncxmdwnm/dirOrfqzeumxpa/dirFzsxwntlqda/dirUoaassbkdgu/dirHrigjdlsynh/dirUcndqohtyuo");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex26302 = 0;
			for (loopIndex26302 = 0; loopIndex26302 < 2330; loopIndex26302++)
			{
				try
				{
					Integer.parseInt("numGcagztrmljy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metTvscwchxhkloer(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValNmbrsrtrioy = new Object[3];
		Object[] valOihwtcktybc = new Object[8];
		boolean valNjjvrwcbtzc = false;
		
		    valOihwtcktybc[0] = valNjjvrwcbtzc;
		for (int i = 1; i < 8; i++)
		{
		    valOihwtcktybc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValNmbrsrtrioy[0] = valOihwtcktybc;
		for (int i = 1; i < 3; i++)
		{
		    mapValNmbrsrtrioy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyEhxzhgoefqz = new LinkedList<Object>();
		List<Object> valYakzuvenocn = new LinkedList<Object>();
		long valFdyxusojypr = 3387248928852347312L;
		
		valYakzuvenocn.add(valFdyxusojypr);
		
		mapKeyEhxzhgoefqz.add(valYakzuvenocn);
		List<Object> valApvtemkuilc = new LinkedList<Object>();
		String valGawdivrehlf = "StrQaetgrgqavn";
		
		valApvtemkuilc.add(valGawdivrehlf);
		String valPhgxytbvpiq = "StrNubpycdcqtg";
		
		valApvtemkuilc.add(valPhgxytbvpiq);
		
		mapKeyEhxzhgoefqz.add(valApvtemkuilc);
		
		root.put("mapValNmbrsrtrioy","mapKeyEhxzhgoefqz" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Jcykhgxdgaedf 7Tyjyxakm 6Xddcpnz 12Csdlmtizoiirg 7Jibxxsez 3Jecw 3Wulk 9Nophugjasa 11Rlxiaqnqqkus ");
					logger.info("Time for log - info 6Dyrteyb 5Cmnrze ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Unotjxrolpbtk 9Ktbmletotk 4Xidfz 5Cjhtwj 5Vvoqhu 7Wxqiglyc 7Pfnqjsej 9Ynbglwwwut 8Trakzffpr 8Xerhjspqx 6Piqlxey 11Aoqmzxgxkprq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.uyus.ruq.fow.dvnw.ClsCysblmgtiyuxcr.metExmmbm(context); return;
			case (1): generated.rnivz.zhh.uhei.req.ClsPtwayhomjjn.metIvavionsx(context); return;
			case (2): generated.lgwo.spy.sqb.ClsVtibt.metZawpt(context); return;
			case (3): generated.lsv.svu.ClsVsswgqo.metRpymmmock(context); return;
			case (4): generated.bhfun.zpnwj.czfe.augg.ClsEdcxpvndelttu.metUlhmbyyc(context); return;
		}
				{
			long varBmelchozfde = (Config.get().getRandom().nextInt(429) + 5) + (446);
		}
	}


	public static void metLndbwkmjawsc(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[9];
		Set<Object> valPeskgqgtjzg = new HashSet<Object>();
		Set<Object> valMswfypaocgf = new HashSet<Object>();
		boolean valWrlsccaqmtf = false;
		
		valMswfypaocgf.add(valWrlsccaqmtf);
		
		valPeskgqgtjzg.add(valMswfypaocgf);
		Set<Object> valDiwscvumhha = new HashSet<Object>();
		String valSvjzxstuajo = "StrIdvfcevqnly";
		
		valDiwscvumhha.add(valSvjzxstuajo);
		
		valPeskgqgtjzg.add(valDiwscvumhha);
		
		    root[0] = valPeskgqgtjzg;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Stnapby 8Ivqourdyh 11Eiglvfksrmql 6Iubrmap 4Ksrem ");
					logger.info("Time for log - info 11Vvzehmaxjhgr 8Kltxrgkol 6Hcjqfyt 7Gvcefgyj 4Ajtzx 9Mbelvyoicv 9Ytztnshltg 4Zmsot 9Apdbhdyldb 11Kkjdsncsqgqb 8Fscrtbstr 5Vnolac 4Flpoo 10Ofbwtiyhqow 12Nxxkttiethikt 5Qglisa 11Ugwekuctvacj ");
					logger.info("Time for log - info 9Hgwoesgcrv 8Frorcxwdv 11Cdztpeldthgr 10Dtjoylubymf ");
					logger.info("Time for log - info 5Vnwxno 9Uoaozrttxc 4Goegt 3Phdi 10Nhtvudyjini 10Obacavfgzdh 6Eqffbsx 9Hdsepddskv 7Twiupfgv 7Awfnsdwk 12Jeshgsqiousgl 11Mhrcklijljwt 5Rvgmcv 8Zpqjhkqrs 7Uybqncrq 3Ylhe 3Gmua 11Yuctfktjxhvd 11Xpbyyiogwjmr 8Dhparggki ");
					logger.info("Time for log - info 3Scel 3Nqeu 4Oaihn 11Wmqyxbncbszf 3Tprf 9Vvaxvgrerz 3Yxau 8Hfocjlwuf 3Kpfn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Omjclcvyyrzib 6Lvkwftf 9Thcwrrflav 8Bfxplozgv 7Rpqcqdqm 12Dibtxmuatablc 7Xadkjyyo 9Jrgbkxlyil 5Wnpbuq 6Glfqjog 6Gyfmnul 5Degyss 8Balsqeiir 4Btvsw 12Smqgckvsdesuw 11Grhmtpllibvz 7Izgzyplx 7Ehpesvfo 3Fbbg 11Vgzcjezfmauw 10Cyzyentzqdm 7Oibvhxyf ");
					logger.warn("Time for log - warn 11Pumzlfilcjmc 4Cncnl 4Cpqce 5Msibnm 12Raqnahajsdrxv 11Ocladixgzimt 6Eopclwt 3Sfqy 12Nphpzitrbiaok 11Hnhvveisuoeh 8Fihaipfan 7Rlryysbr 12Uxbdrhlnixwxb 9Kstocwumff 11Dsjtezbczcdb 8Awpyvkdqt 8Wtmbjajxo 11Gliuxedvkuqi 8Bsxhsbsgy 6Jforwjb 5Jcxyoo 5Lbahbv 6Uvruadr 10Tkyhkgponek 6Yneyvbc 7Vmhitqyx ");
					logger.warn("Time for log - warn 5Thkpcx 9Friuztmlof 3Lfdb 4Okjom 12Ortigpolpkhrd 12Qvuftwnhbfzzt 11Llymlbyfkjge 8Agtasntca 5Voaqle 12Lqvmwigaknpjp 7Ilclkvux 11Wgsfsffjvlss 7Onbjybla 10Jgwkmvavvlo 11Yqfdklemrnct 9Allqfsbkup 12Eeglvovofqoyv 10Kiiqjlldqaf 12Xhfdihqtpkqtf 11Sbwbqccrjweq 12Bklzrefkeknef 3Sgav 12Lluzugvykccla 12Lhrdpttgomnpb 3Ohll 4Kxriy 12Roqaebzcfghrr ");
					logger.warn("Time for log - warn 8Urjscnxvw 3Mxri ");
					logger.warn("Time for log - warn 7Xujrargh 9Tnovinkgvm 11Xvrupqktwvdp 12Cjdbfcbotwvkn 7Tfisbohz 11Jgmwostvnaxe 9Otywqpytol 8Rvqtsvpbj 7Zkyzehvd 10Qptfglyvrog 12Hriumlyuaqwon 8Cxoqfnpwo 9Xjnfixsgsg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Akffardeywa 9Wsaxncxtce 10Uemngzxwojc 8Zyuizsuas 5Rdotoe 4Hbfgv 8Ylshrwfrf 5Mwedpa 12Abmafwhoyrmjn 10Tmwtdhfzflu 6Gxswytb 5Zuiiav 3Ieuw 9Kiaftupxbc 7Bochldju 12Jhxvdxouruzot 7Ahmcqmqp 11Ocqotpiuowvm 11Mqzfzvnrarek 3Hpps 9Grwpohemad 7Tcpvxyob 12Wmoinjeasftgn 7Xlrryevq 7Pjtovyrq 12Kfcddkzwsogmj 10Utvshnumzpc ");
					logger.error("Time for log - error 9Cfyqxcknjs 8Wztuzpkvi 7Ohfudtka 9Tjjkzxdfbb 4Puoea 8Bypvwqtzv 7Dukzvued 7Mwrvqtuj 5Bxffzp 11Mhzggqfclvmg 10Qhqfdiotyvq 7Wugnakre 10Tijguichmqn 3Pqus 4Jsbbg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wte.xgtr.bgy.yncq.pkef.ClsWcqetwudvh.metOqckimb(context); return;
			case (1): generated.mrz.embg.gydr.vls.fvllv.ClsYrxhq.metOlxzxxtvhnzlxg(context); return;
			case (2): generated.rlg.pxdte.svn.clv.ClsMkagt.metEsbkjtdvlylqyw(context); return;
			case (3): generated.yzf.fayrw.fbm.pexsg.rxfb.ClsSblyqahlwj.metEexjjx(context); return;
			case (4): generated.weide.dnna.unvd.vtw.pcbre.ClsExwicwtb.metHqnibperro(context); return;
		}
				{
			long varTbkqmxiivkj = (5146) + (Config.get().getRandom().nextInt(56) + 4);
			int loopIndex26310 = 0;
			for (loopIndex26310 = 0; loopIndex26310 < 3508; loopIndex26310++)
			{
				java.io.File file = new java.io.File("/dirYbxiziujxkt/dirQwzevlbdcua/dirPvlrfiypkxq/dirYiukrpecuzs/dirNkxaefofpfq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex26311 = 0;
			for (loopIndex26311 = 0; loopIndex26311 < 8563; loopIndex26311++)
			{
				try
				{
					Integer.parseInt("numIqnueknfuii");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metDtgdmwp(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValAnvdttsvpot = new HashMap();
		List<Object> mapValRyykjzncnvi = new LinkedList<Object>();
		String valTihvlqfkfep = "StrThwgrtgkyhz";
		
		mapValRyykjzncnvi.add(valTihvlqfkfep);
		boolean valGuiubdpglvt = false;
		
		mapValRyykjzncnvi.add(valGuiubdpglvt);
		
		List<Object> mapKeyDorccgczgzd = new LinkedList<Object>();
		long valOpvgjigcdbs = -8528273378795140188L;
		
		mapKeyDorccgczgzd.add(valOpvgjigcdbs);
		
		mapValAnvdttsvpot.put("mapValRyykjzncnvi","mapKeyDorccgczgzd" );
		
		List<Object> mapKeyCkjbiamelxm = new LinkedList<Object>();
		Map<Object, Object> valQrcwkiubrov = new HashMap();
		int mapValApvxkdwmsmn = 424;
		
		boolean mapKeyRikuazgjnoo = false;
		
		valQrcwkiubrov.put("mapValApvxkdwmsmn","mapKeyRikuazgjnoo" );
		String mapValVygidaoupgn = "StrXycxsjjbhuw";
		
		int mapKeyMnqdvkezyay = 477;
		
		valQrcwkiubrov.put("mapValVygidaoupgn","mapKeyMnqdvkezyay" );
		
		mapKeyCkjbiamelxm.add(valQrcwkiubrov);
		Map<Object, Object> valGchaeryrslu = new HashMap();
		long mapValJhqouroeexc = 5282498544189657955L;
		
		long mapKeyPlidatdlbzq = -3756581921277807235L;
		
		valGchaeryrslu.put("mapValJhqouroeexc","mapKeyPlidatdlbzq" );
		int mapValNpwdnofuvvb = 753;
		
		boolean mapKeyXcneyooacwa = true;
		
		valGchaeryrslu.put("mapValNpwdnofuvvb","mapKeyXcneyooacwa" );
		
		mapKeyCkjbiamelxm.add(valGchaeryrslu);
		
		root.put("mapValAnvdttsvpot","mapKeyCkjbiamelxm" );
		Set<Object> mapValOwioffppmfo = new HashSet<Object>();
		Set<Object> valXrjvaqbrylp = new HashSet<Object>();
		int valHlikwuypbpi = 938;
		
		valXrjvaqbrylp.add(valHlikwuypbpi);
		String valWrurpzhjwdu = "StrOcnkldhclsq";
		
		valXrjvaqbrylp.add(valWrurpzhjwdu);
		
		mapValOwioffppmfo.add(valXrjvaqbrylp);
		Set<Object> valQkxcuyzftqn = new HashSet<Object>();
		boolean valGbvsoraefde = false;
		
		valQkxcuyzftqn.add(valGbvsoraefde);
		
		mapValOwioffppmfo.add(valQkxcuyzftqn);
		
		Object[] mapKeyWsbneewjuls = new Object[9];
		Set<Object> valZscufdoxhbt = new HashSet<Object>();
		long valWdkdgjnlyqg = 7479188733011956844L;
		
		valZscufdoxhbt.add(valWdkdgjnlyqg);
		long valJnjhzskpmhw = 233805841785045417L;
		
		valZscufdoxhbt.add(valJnjhzskpmhw);
		
		    mapKeyWsbneewjuls[0] = valZscufdoxhbt;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyWsbneewjuls[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValOwioffppmfo","mapKeyWsbneewjuls" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Kfroqkbnvsfry 8Sokekopks 3Ffwo 7Gksmneko 8Eapaytujc 8Wcwvatmsn 12Griozhpeqyzjj 11Gqjnncxajxpi 6Gkerypc 9Yutcwzzjuj 5Zagmch 9Ysaoskvbag 7Mwkivqdi 6Bmfsywe 10Vpnozepnuxv 4Ncqcg ");
					logger.info("Time for log - info 11Ltzuaudsryfu 6Vyyesop 10Ejsnpdfocez 4Dxejf 10Dxiyxljzxzc 8Jsrvgcapr 12Adlirajumuxkk 10Wuyyimhqnwd 6Iizlhxb 11Hrjvoynvxsxr 6Vsddakx 3Yyun 7Rrafvmue 9Xwsoqiprre 6Zbmpgzl 4Olewl 12Bzpfqegyhupxu 12Ztwjxqgicykuz 5Lhlsvu ");
					logger.info("Time for log - info 4Dsgaf 5Rqydpt 6Kdiquze 7Npanwtwh 6Ttidalp 8Vtopenlqp 3Xpbo 4Tghiz 12Tpjgajwjvlxts 12Wrnkxerlggxkj 11Orlyxluuhovc ");
					logger.info("Time for log - info 9Xxbeiwisys 3Ehor 10Oycdomujdfd 4Jsjur 11Iewiihpwiwgt 6Tiycyug 8Ohymguuza 5Diayej 3Qzrv 6Iyfokvl ");
					logger.info("Time for log - info 10Nbujkyexbdp 8Uwvnvttvh 5Clpycj 3Oyvf 3Fmrq 10Qboajhmevgd 5Cdjuoc 6Ucodqsx 11Xpwbfqrhcbtt 10Pefreiibvoc 7Zcewpvkz 11Tvrqrvyxdmju 12Iusxmkzznluku 11Ecwdgqymgpsw 5Zflvlf 4Hzchp 3Ular 7Gkymvtgf 8Reegbyfdx 3Tttu 10Wwgiiobkyrg 12Gkckklmxjubje 10Mswvnpizrwv 7Iuuwidaj 7Wdnmdzsg 4Hycow 11Twrvamolfbsl 10Pcxvmlxxqiw 7Jgrgojqa 7Pffytcbm ");
					logger.info("Time for log - info 5Dmaoyu 5Nopqeg 11Duxewnsqvhut 6Qdytvbu 4Vzeeo 3Uodh 9Zcfqievdxy 8Jgehjegyc 6Gzjclxf 9Eiinsysuuk 4Irukf 4Lrzmh 11Sxrunogemoqt 11Jieozyjmbfee 3Zals 5Byaxsu 4Wqaax 5Ixgiks 8Vsimyaulx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Nnqqmqouio 12Uqbvskgdqgqyu 9Nstmxrftfn 11Abyhzhcbugdn 3Vivd 6Ozuldsj 5Cwshsl 12Calwmcwjbkoua 12Qnxavjcyxjhyf 3Xcig 3Hzbt 12Sqnjmwipkhlmq 11Hqfjdeqpnffk ");
					logger.warn("Time for log - warn 9Nfwtaoqfew 8Usrwdvpgp 7Qdanujvh 4Noqfu 3Pxfj 3Bvmf 8Dwziqsbzp 6Didtsuw 12Vkcirgzufpvxg 10Uzmoouctigg 11Ofrgotwvypzv 10Cnfbilqlaaw 8Pgjhtwpjk 6Qvcchqm 7Lvqdvtvi 5Mckowe 4Jqqml 5Jserrb 6Hotqdbd 4Txbzc 10Snzeiexfunb 8Zulxxjahh 8Unepolrjl 10Voxgjkgaecs ");
					logger.warn("Time for log - warn 11Okyujuaylmal 7Qjspnbdi 12Rbhnxztajcmfc 4Ysany 11Cikwobifsfvj 4Xyulv 11Hlrjfjvqrwct 8Jujehhguw 4Brgst 9Nbcwllapjt 5Wuuzqz 5Bxzkto 6Sgxhheo 6Qbdsjfx 11Xykrxadodtpa 10Vailksjyzgr 5Gyhidn 3Izif 5Aewctj 10Najxhsvltoi 10Ekcldghbhke 6Jckxjvr 10Yksbtjoeotz 6Nnghhwc 5Zvlnmv 6Nxzahpn 4Uxjpd ");
					logger.warn("Time for log - warn 11Vszlhaagnxio 3Eftq 5Zpluzs 7Izcmpohb 10Bqntdlfdqnx 12Onpaftacreyfl 4Vgsjg 4Uhksl 11Scsxlxmxhxav 7Irbyysmf 3Mzsy 3Kvvg 8Bmwokqgne 3Btyj 4Vxirl 9Ztamymgljp 3Gvtl 9Wzedhxghvy 4Inccg 12Ngevxukakmurl 12Mrdmfuyespthl 12Rrgwuxxybxrpd 10Ccpdzzsdyce 11Cxinljvoqzwv 10Hharhtnedmi 12Ppitspbztfrxy 8Rnewtznjj 4Pptky 11Euzfdyyglhpw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Kehtvssf 6Dmfnqmu 5Rnyyru 9Fbdkmvtwbe 3Bdee 8Dpohlucsp ");
					logger.error("Time for log - error 3Iorm 7Raofnjxp 9Nqmcopbakc 12Socntpbllrhth 11Ealvkbrddufm 12Cxeeuehfanqqd 9Crgmzgxcoi 8Muyjnjcbj 7Tfqscfiu 9Mpvgoitlut 9Jqaelompmw 8Wefgyduof ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vuj.qjcvs.phb.poi.ueh.ClsHxaaaxntrhq.metHrwdn(context); return;
			case (1): generated.tei.zyt.ClsLkzwcb.metYgqywxliqwprfr(context); return;
			case (2): generated.tcpo.xhov.ClsRfokukcdi.metFyxdxe(context); return;
			case (3): generated.lraiq.fcmvy.qwp.rkzex.eokht.ClsJupuz.metTywqcdpv(context); return;
			case (4): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metDghubvohwq(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex26319)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numNwizqzuhuyi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirVctzrgrkrqm/dirClhphahsoxr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex26323)
			{
			}
			
			int loopIndex26317 = 0;
			for (loopIndex26317 = 0; loopIndex26317 < 4926; loopIndex26317++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metAcpodlmg(Context context) throws Exception
	{
				int methodId = 4;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValPvlprggphhu = new LinkedList<Object>();
		Object[] valIgukvoubtvb = new Object[5];
		long valXfhjjjemqzf = -5433895055716998831L;
		
		    valIgukvoubtvb[0] = valXfhjjjemqzf;
		for (int i = 1; i < 5; i++)
		{
		    valIgukvoubtvb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValPvlprggphhu.add(valIgukvoubtvb);
		
		Object[] mapKeyJpdsmcpytsd = new Object[4];
		Set<Object> valItvnqifhbaz = new HashSet<Object>();
		boolean valVcoshpiaivf = true;
		
		valItvnqifhbaz.add(valVcoshpiaivf);
		long valSjwwfmuthxh = -9197213042819351524L;
		
		valItvnqifhbaz.add(valSjwwfmuthxh);
		
		    mapKeyJpdsmcpytsd[0] = valItvnqifhbaz;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyJpdsmcpytsd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValPvlprggphhu","mapKeyJpdsmcpytsd" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Wntjls 3Uttd 7Rvglcgem 7Otitfctf 9Ybddagmglb 12Ajdmvceamcpgv 10Fletfghgjsi 9Fqlzogeyki 10Czzbvtprwjw 12Viqzyjvkplvvc 8Kclphxjoa 6Qignhyf 5Sqrram 12Zposfltfbkejs 5Utexyr 9Kyuswlxdhn 7Frxmknzs 12Ohghaehiyjkdt 5Dtowim 7Qmleufdw 8Jrhumvfsb 9Kkbhqyrdkp 7Grbehmrd 12Dgevbchhvxskl 7Eqzepyvo 9Sxousepopc 6Ynjwosp 11Vcetthwriuzz ");
					logger.info("Time for log - info 4Abxyq 5Mnffgl 8Jfkelmwlu 12Mejogldhvzlls 3Jcid 7Sccdktvx 7Xexquegi 4Orcbf 3Nrnb 3Nxqe 5Mygwwh 6Lgqrjqf 4Zgube 4Zpbrt 6Ixmprme 7Haghwsno 6Evyaelr 6Awwvjog 5Mpnpxm 3Bpgc 8Sotkmlcgw 5Nwplol 11Ecupgowjonzo 5Cqucnl 10Yiyoemsaxtv 11Kjfrcjbqxvvo 9Xnjnfcqgso 8Qzwunqetr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Kzdqlnjnpu 12Mnwacnkloayiq 12Rzpewdtzpcvtq 7Ldvlntqc 8Tpcccikpn ");
					logger.warn("Time for log - warn 12Svkocvxohxaxp 7Zlxigccu 10Wmfnefftzda 6Ofaflsu 8Dpcxaejfp 12Rscjqgqxbnvrw 11Wklqmuqoohtb 11Tbykjavagtwx 8Ytrjeqvvn 3Dxcw 6Vjbxqrv 11Quiskbpoaphl 5Izxzra 9Eygjyvsqhv 12Jhzqwosmlcqnj 10Vsjasmzikwr 3Vdml 5Znynrq 11Yqjhhnrrlibc 10Qstjiotlybs 12Xelytcxlzgtxy 10Oopawpvcdic 10Tgepouiglgv 3Kpdv 7Lprnlfiw 12Bsfflrytaffkn 9Uhnxrgnayz 10Zvvcictqefd 8Hgvhcovoq 11Hwrtipqyfilr ");
					logger.warn("Time for log - warn 8Eopnhhohk 4Dgdny 3Raex 11Zlkocmlmznqa 5Wpytnw 9Dayztohfih 6Ivlzwmx 12Jzqgwhpqcbbew 8Kfxmijwlf 11Adbgmtzucfrg 9Gkrugnqdby 6Wvrrcpc 5Rdfgso 8Scjudescw 7Fgggxhre 7Mfahvpxi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Aiwteurjls 10Kihnownavvw 3Jepj 4Pvnhb 3Rmik 5Plfyql 12Lidgmybukfiqs 9Pmqzgjegae 9Rpfrnmaohn 3Ufnu 8Ilghhikef 10Hpkhbptjedy 10Jawzuyqwfrg 10Vbtrmlzaoht 7Lmnzklww 11Skrcuumadbxb 4Vmonz 11Sdlatbmmbajh 12Mzjojtrsghdut 12Kbbsupohhzmrq 4Rnjtd 10Xcbkfwccxee 9Nfhrjblfcm ");
					logger.error("Time for log - error 10Ixrblodzelk 12Tnwtrnbyntwzy 4Neeib 11Lzoehmtmuuff 11Wiknrqordtya 11Ffctrvelekhy 8Zkfrjopac 8Ljsgzrmvp 8Cvvkackse 9Issgjjqeqc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jsgq.prz.gbdn.gmbz.fsq.ClsVccwchvmrutt.metJtnvvvb(context); return;
			case (1): generated.jbipj.zrsb.daypv.qszx.ewk.ClsVnncvmwdx.metEgxuxcqraj(context); return;
			case (2): generated.gyic.epw.ClsQxhbkrqjzoqujk.metVprfejv(context); return;
			case (3): generated.zyq.cql.abcyr.bxocy.ClsPzdxphao.metTogar(context); return;
			case (4): generated.cbscy.vax.ifmv.uvjll.ClsXprhoql.metUsqqbascqyi(context); return;
		}
				{
			long varXcwifthcama = (Config.get().getRandom().nextInt(275) + 0) + (1018);
			try
			{
				java.io.File file = new java.io.File("/dirPfpmektffst/dirEmoupjaedmq/dirFpvhicnvpfd/dirQbpkohaxbik/dirHjnukynbngm/dirVocfprpevpz/dirYoopytcdzpr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex26329)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirHwbfrypmdht/dirTprlglginqr/dirHopnsygrwje/dirOhqzmxzmsdw/dirRkwqzvmqwnp/dirThurjecszdf/dirTnicusfqgsl");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
