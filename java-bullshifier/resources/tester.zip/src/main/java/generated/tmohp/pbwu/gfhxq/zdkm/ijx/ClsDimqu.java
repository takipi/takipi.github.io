package generated.tmohp.pbwu.gfhxq.zdkm.ijx;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDimqu
{
	 public static final int classId = 60;
	 static final Logger logger = LoggerFactory.getLogger(ClsDimqu.class);

	public static void metXkytsyqb(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valKuqwvpxkuzd = new HashSet<Object>();
		Object[] valEvfvxxbthzp = new Object[8];
		boolean valSlmsdhjutoi = false;
		
		    valEvfvxxbthzp[0] = valSlmsdhjutoi;
		for (int i = 1; i < 8; i++)
		{
		    valEvfvxxbthzp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valKuqwvpxkuzd.add(valEvfvxxbthzp);
		Set<Object> valWlxfvgptjbc = new HashSet<Object>();
		long valLktolpgofbd = 3324907855712753994L;
		
		valWlxfvgptjbc.add(valLktolpgofbd);
		
		valKuqwvpxkuzd.add(valWlxfvgptjbc);
		
		root.add(valKuqwvpxkuzd);
		Set<Object> valVetfpufmsvg = new HashSet<Object>();
		List<Object> valWfycmizzdin = new LinkedList<Object>();
		int valPeecrfeucjb = 848;
		
		valWfycmizzdin.add(valPeecrfeucjb);
		
		valVetfpufmsvg.add(valWfycmizzdin);
		List<Object> valKpuspwblkmx = new LinkedList<Object>();
		boolean valKnkqrnhrnsm = true;
		
		valKpuspwblkmx.add(valKnkqrnhrnsm);
		
		valVetfpufmsvg.add(valKpuspwblkmx);
		
		root.add(valVetfpufmsvg);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Vlbdphtgap 8Gkbixleif 3Bdix 9Mowxmunkhc 5Wakqhk 4Ylfmc 3Gmms 8Wzscxtnec 7Sxtyzlxy 12Gqnythrwgwzdf 10Qexpmosviny 5Prtbqt 10Eppridpksxb 10Czeysbfpwtt 9Ftbzrfhifu 11Ojmfyeimalrw 6Wulpxgl 6Vwmncvp 7Xswcflxl 3Gzax 10Qmpdbbkvlam 12Rdpdspqtcszjf 4Oglxb 10Dvlmynmmhra 9Ougtlbflph 11Dgsaqhppszqb 9Clyijtqycb ");
					logger.info("Time for log - info 3Rapk 8Xqrxvdukx 11Wkftixredxmt 3Kotg 4Bsebu 4Dpfxb 7Hmyunyvl 5Ffrcmr 11Shevvqhdptyc 11Fauzanxorynx 6Pznlmvf 10Qukyalvjjor 10Mxxlbjotuoa 6Ydjcajc 5Rjiemh 7Yywohmkf 8Fdgulhgde 7Wbzgsfia 8Qkjmtlilv 6Xtjniun 7Enbrhvpu 8Pavhaltjp ");
					logger.info("Time for log - info 10Pvgwbfhpwxo 8Tyycerglj 5Anizzu 7Ptfafpok 7Bdcqmgmw 6Dtzefnh 10Oydddeczesp 6Zolphuj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Xsjhcagsusz 7Wcskxaht 3Dvaq 8Ftslqckoy 4Clwgc 11Npduoslyfsgs 4Cxoed 3Rkpy 9Rrexqjhuft 9Duvewnrnqa 6Lneymrc 4Urcim 5Gnbdpz 10Ernkpbmmzph 3Vrte 9Tcxzitbhbi 9Cpbuvbxopc 5Zkvepd 6Zopjbpd 9Bgbclbqtua 8Xzkyqmlin 8Islkiodnq 11Mndgwmtxttll 9Nzfwfkcbwp 9Qroilebqlr 12Tgiejqwibldtq 7Sklukpxg 4Mkgoe 12Regdvskkcvwsx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ocg.pnhd.assci.ClsEkxxqpavkqxkay.metCmxzsyw(context); return;
			case (1): generated.rub.wtuur.cpewn.fdq.jektc.ClsLiscwkily.metFxfyfwekmvvpv(context); return;
			case (2): generated.naf.suq.ClsSzodbxxywsfz.metFhdpmoxdz(context); return;
			case (3): generated.kdf.pknx.zlwl.ClsKeeubrxremfhhw.metSoxbamiezrzd(context); return;
			case (4): generated.exa.yssf.ClsHuxmu.metYpznuybxbixhh(context); return;
		}
				{
		}
	}


	public static void metDaefjy(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[5];
		Map<Object, Object> valPearyutfilk = new HashMap();
		Object[] mapValJzumstdauxj = new Object[3];
		boolean valNynlvemylwt = false;
		
		    mapValJzumstdauxj[0] = valNynlvemylwt;
		for (int i = 1; i < 3; i++)
		{
		    mapValJzumstdauxj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyPnpfunpiekd = new LinkedList<Object>();
		boolean valWeauoytqilx = false;
		
		mapKeyPnpfunpiekd.add(valWeauoytqilx);
		
		valPearyutfilk.put("mapValJzumstdauxj","mapKeyPnpfunpiekd" );
		List<Object> mapValLwnfnesvftg = new LinkedList<Object>();
		long valEbwqerzzmtx = -2758722946458752837L;
		
		mapValLwnfnesvftg.add(valEbwqerzzmtx);
		int valZibylyyxzto = 305;
		
		mapValLwnfnesvftg.add(valZibylyyxzto);
		
		Map<Object, Object> mapKeyOpxcxgdnxeo = new HashMap();
		long mapValLyrdlhxvhcm = -3119236387810450469L;
		
		long mapKeyNionxwwuher = -7151932238855670025L;
		
		mapKeyOpxcxgdnxeo.put("mapValLyrdlhxvhcm","mapKeyNionxwwuher" );
		long mapValVfxaxhxjgvs = 1731406413957647501L;
		
		long mapKeyXybnmstilzl = -3991443487613393040L;
		
		mapKeyOpxcxgdnxeo.put("mapValVfxaxhxjgvs","mapKeyXybnmstilzl" );
		
		valPearyutfilk.put("mapValLwnfnesvftg","mapKeyOpxcxgdnxeo" );
		
		    root[0] = valPearyutfilk;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Qzmrdnqhepexo 9Psohfpnmdz 11Pgowazzgclce 8Vafnlfrtm 11Kkvkoherzbaw 8Rpihomdab 6Arkxqxt 6Axyijbi 8Mpwjkfxtt 6Scriigj 9Idrrzycpfs ");
					logger.warn("Time for log - warn 9Rqxifjzawp 9Utnwerhnlr 10Bdmiuhztupx 12Bjzbkbxwschpw 4Skdez 12Ccpvdrvfsizjp 5Knawvr 8Drsbczjql 4Cjdhl 3Tcqi 7Orecqwno 7Wzzntqtd 11Cqjqkbvucbkr 4Vybfc 6Fqknxey 9Adyjvgwnqt 3Wgvv 12Wueufogheapuc 3Xiyw 8Pyevrhhzw 8Zcatjmsff 4Wqzwc 7Zqbsgxzh 9Phinvdotyf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Fbyxzyfljvzth 7Vyhxsbrh 3Qhuh 12Esnekwjtjisaj 6Zdwnqic 7Vffatbsw 9Qzcdqgnqeq 10Gmcjsvynolc 4Hpqsn 11Rjrpsyyujxkl 6Wwwclgc 7Siatytqa ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.eob.tzj.qiec.ClsEnjcnowop.metRglvwndsjd(context); return;
			case (1): generated.npa.tuyd.ClsLxzuwxfsi.metNpvomn(context); return;
			case (2): generated.iotb.mlgn.hcur.ClsAdwtsoupvuwy.metMpwarwswa(context); return;
			case (3): generated.pgfis.zew.ikgq.ClsEgsupkocifpi.metYobadnrmqm(context); return;
			case (4): generated.hbqjp.kifli.leg.jlyd.ClsYgtwztbknhdmc.metSqhmmbh(context); return;
		}
				{
			long whileIndex21107 = 0;
			
			while (whileIndex21107-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex21112)
			{
			}
			
			long whileIndex21109 = 0;
			
			while (whileIndex21109-- > 0)
			{
				try
				{
					Integer.parseInt("numZbvkihtgvtv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metSwhvdjgcvud(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValNhxlibykoqh = new LinkedList<Object>();
		Set<Object> valBnjzcxgqufz = new HashSet<Object>();
		long valQxugppshjmz = -3194669801930423319L;
		
		valBnjzcxgqufz.add(valQxugppshjmz);
		boolean valKwiioohylyx = false;
		
		valBnjzcxgqufz.add(valKwiioohylyx);
		
		mapValNhxlibykoqh.add(valBnjzcxgqufz);
		
		Map<Object, Object> mapKeyIqusmrqaagb = new HashMap();
		Set<Object> mapValZodupiesmti = new HashSet<Object>();
		int valCzitdtiaqud = 920;
		
		mapValZodupiesmti.add(valCzitdtiaqud);
		
		Set<Object> mapKeyEdizwgjiosm = new HashSet<Object>();
		boolean valPvyepdtfqkw = true;
		
		mapKeyEdizwgjiosm.add(valPvyepdtfqkw);
		int valBwtifvwtfuu = 744;
		
		mapKeyEdizwgjiosm.add(valBwtifvwtfuu);
		
		mapKeyIqusmrqaagb.put("mapValZodupiesmti","mapKeyEdizwgjiosm" );
		
		root.put("mapValNhxlibykoqh","mapKeyIqusmrqaagb" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Mrrwp 4Jmcbl 8Xsgelhewu 11Fggwtuiybpsl 10Vztiolyxcwc 7Bjkemlai 6Nfmcdfi 3Jkym 6Docngmr 3Azyo 8Iblvovgjh 9Dsflpknpbw 6Haurxqu 9Qjdjyejbun 4Hfbpi 12Jfdgbmskgeycd 9Lkwtpxrznb 4Qdzws 9Nkebkixxsx ");
					logger.info("Time for log - info 8Txsaxcbog 4Gebyu ");
					logger.info("Time for log - info 4Diovc 10Kqjqhkneudk 10Byevrwtqram 7Phonhcal 6Rirkwzc 11Upsjblcrgaaf 12Lrqcevyoangkm 5Hfxmwq 5Wrpvhq 8Tvaecjtrh 3Qiyx 5Jfzozy 7Hnpcwzxr 5Gaorze 3Gqzh 6Yxrfkzf 9Zxndyaqwpm 11Zfofuckyrzst 4Tjrzk 12Pgpbweupjslnk 12Qhfkrwuqlmwvq 4Pbsvr 11Lvnimyyfipvm 12Xfidtlkwbrqin ");
					logger.info("Time for log - info 4Yctxg 9Edtczxvjnv 11Wkaqmmiluuai 6Chgzhuk 8Tsiudlktw 9Adimazfbwt 7Aomnobjy 12Potcrhzdxdfqm 5Hwvvcz 9Rxyssaeglq 10Yyyeeltpptk 11Qwelhcbzavll 8Xzezehywr 10Yifttshoidz 12Inueilvjtkeiv 8Vhpyzfexg 6Kjzygkz 6Ugbygjq 6Wwokyjk 4Jeaot 5Txvmyg 6Nsypdvz 12Zjjmedkjzmykr 4Gpffk 8Okffnsfjd 6Nnsbtah ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Bzjufqdy 4Rpdfk 8Sbnqpbcgn 10Jirsvhpifwj 3Xids 10Yvgdrccqust 8Mubcekqfs 7Tohccyfh 6Gqulmrd 8Pgdpuqoip 4Efmnv 4Bkdjh 10Zsnyfdxxeuf 8Xljggfjif 5Mwfyhn 9Xzqwlsukyc 6Npaqgfd 7Swllktyl 10Nljbpswceuu 12Gyjntbnhlaeop 12Roaqvwrrbfysh 3Soda 9Zjxljzofpq 3Uiws 3Wlja 7Omqabhgc ");
					logger.error("Time for log - error 7Hqihygmi 11Uyrwhbotnefl 10Sjaaqahtach 12Jwmzglbavkiuz 12Juasgecbossos 7Khxsvvgu 3Jlef 9Awhemrooij 7Lnvdsxkj 9Syduwmvbyy 5Lcnfyl 9Vjvzrmdvco 12Kvjmdlwmssigw 9Gworxmiogi 9Omgrhyxbka 10Mifkllmnhuy 6Orqvlzs 7Mhtuokbt 8Wlvhnxeqy 5Hxmdom 5Nmhpty 5Ikiyrz 5Pizevr ");
					logger.error("Time for log - error 9Mubdlkfzgu 7Hjefoixj 3Olbf 11Lngzyosyecbi 5Xyvvzj 7Ddhxumgq 3Kcuv 7Ktpyjitl 9Qxhkdlxodk 6Utkrujs 11Uuvqfiunsbpc 5Lzhlut 12Otaxugwxtwumm 11Gdjjefnxxruy 8Ejqlzdnsa 12Kezvwtprqvxec 9Wjfuevxqtj 6Evdzrrv 6Gzvflti 6Itgqarm 6Hypiivx 3Eukm 4Yzqjd 6Agmwxtx 6Pqfdsnk 5Ohglfn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qnmn.narfk.rdhdk.ClsPtwatcpapj.metGdaktormyy(context); return;
			case (1): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metLlvwdlebp(context); return;
			case (2): generated.ocg.pnhd.assci.ClsEkxxqpavkqxkay.metChyppmprgvzqeo(context); return;
			case (3): generated.ocmm.ezbtm.vxyei.kuseg.ClsUqzgoaq.metGzyab(context); return;
			case (4): generated.hqq.wtuo.vap.ClsNidilkbt.metWxcpfhso(context); return;
		}
				{
			int loopIndex21115 = 0;
			for (loopIndex21115 = 0; loopIndex21115 < 2282; loopIndex21115++)
			{
				try
				{
					Integer.parseInt("numRlnxdtgqcql");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metLliixbwykd(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValIltzwwyness = new LinkedList<Object>();
		Map<Object, Object> valNjavmxvxqyh = new HashMap();
		int mapValOmzcgxkmmnb = 643;
		
		int mapKeyNtygnkgeqvk = 541;
		
		valNjavmxvxqyh.put("mapValOmzcgxkmmnb","mapKeyNtygnkgeqvk" );
		
		mapValIltzwwyness.add(valNjavmxvxqyh);
		
		List<Object> mapKeyVamvydhhrhe = new LinkedList<Object>();
		Object[] valMnrlgajljxu = new Object[5];
		boolean valCkjylgummcw = false;
		
		    valMnrlgajljxu[0] = valCkjylgummcw;
		for (int i = 1; i < 5; i++)
		{
		    valMnrlgajljxu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyVamvydhhrhe.add(valMnrlgajljxu);
		Object[] valEvebhuwyazj = new Object[11];
		int valAxdxzawfiro = 401;
		
		    valEvebhuwyazj[0] = valAxdxzawfiro;
		for (int i = 1; i < 11; i++)
		{
		    valEvebhuwyazj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyVamvydhhrhe.add(valEvebhuwyazj);
		
		root.put("mapValIltzwwyness","mapKeyVamvydhhrhe" );
		Set<Object> mapValXkvwfgtdybs = new HashSet<Object>();
		Map<Object, Object> valJfaibxknuxg = new HashMap();
		int mapValQktwtetkvuo = 149;
		
		int mapKeyHflluiwpapk = 605;
		
		valJfaibxknuxg.put("mapValQktwtetkvuo","mapKeyHflluiwpapk" );
		long mapValSpujcpxploq = -63386783070147258L;
		
		long mapKeyVsvgldluunw = 7718102246458607073L;
		
		valJfaibxknuxg.put("mapValSpujcpxploq","mapKeyVsvgldluunw" );
		
		mapValXkvwfgtdybs.add(valJfaibxknuxg);
		List<Object> valZtdinjqcsdc = new LinkedList<Object>();
		boolean valNrbtzogdyup = true;
		
		valZtdinjqcsdc.add(valNrbtzogdyup);
		long valVyaayjyqext = -7241836744575385324L;
		
		valZtdinjqcsdc.add(valVyaayjyqext);
		
		mapValXkvwfgtdybs.add(valZtdinjqcsdc);
		
		Set<Object> mapKeyHyshcqdnpwt = new HashSet<Object>();
		Object[] valXrmiyvoacjj = new Object[9];
		String valXvulnunanlv = "StrYuruzucupje";
		
		    valXrmiyvoacjj[0] = valXvulnunanlv;
		for (int i = 1; i < 9; i++)
		{
		    valXrmiyvoacjj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyHyshcqdnpwt.add(valXrmiyvoacjj);
		
		root.put("mapValXkvwfgtdybs","mapKeyHyshcqdnpwt" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Ffdqkqzfhji 10Nlsqrgyketj 9Unldovzzpm 12Dmmbcldmuyfbr 3Wres 8Dnqxcmuzf 11Xsensrrjwjvh 5Kssaxi 4Aqrry 10Jiupxjbjpfc 9Ssdcdpaani 3Frww 4Kevea 6Whayeft ");
					logger.info("Time for log - info 6Adpqrcx 6Rhnzfbg 8Kaxgcstgw 7Usqauqpf 11Eownyclmqvnf 5Zmlyuo 12Otzbxftpogsbc 7Olmiumsf 6Vckxovv 11Vvvpzyrcnmvj 7Oecvjsxl 12Auzzhfxlmekll 10Kksiueqeioj 5Nrmuid 6Qlgkjbf 8Evqollexy 7Ywlpaijm 12Aekgqljuocety 10Abdmwutgtnc 9Lmfpgtlsba 7Rvllglxk 7Cxcjgqot 12Btytlcbwshklq 9Ikttolfhxh ");
					logger.info("Time for log - info 7Qpdmvxin 12Yettqugpuqjbr 4Wjnni 5Cybvwd 9Ttioddzxmt 10Cdlzvqmjoib 5Kqmkys 11Irlzgogibuoi 7Uquodrcf 12Mkrgpflxhztub 9Jfxnymrhry ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.iotb.mlgn.hcur.ClsAdwtsoupvuwy.metTfsczzma(context); return;
			case (1): generated.flwv.kjeus.ClsAhjobcsyb.metLggklmi(context); return;
			case (2): generated.mbn.igyf.ivup.sglb.ukb.ClsQzhoqgskicnjw.metBwwaliwybesa(context); return;
			case (3): generated.cpb.wnddu.ClsLvopzbmgvjj.metJpplktwh(context); return;
			case (4): generated.javqv.ttek.ClsJqite.metDgxswlnyjk(context); return;
		}
				{
			long varHyxffeonsxd = (Config.get().getRandom().nextInt(128) + 5) + (Config.get().getRandom().nextInt(677) + 9);
			long whileIndex21119 = 0;
			
			while (whileIndex21119-- > 0)
			{
				try
				{
					Integer.parseInt("numUzeganfxpde");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
