package generated.ythhn.vxvz.yizb;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsLckdkkeapmss
{
	 public static final int classId = 150;
	 static final Logger logger = LoggerFactory.getLogger(ClsLckdkkeapmss.class);

	public static void metUtevjjtyd(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[5];
		Object[] valIatkmmubfgr = new Object[9];
		Object[] valIsxrpwgrpfx = new Object[2];
		boolean valSummapfevzc = true;
		
		    valIsxrpwgrpfx[0] = valSummapfevzc;
		for (int i = 1; i < 2; i++)
		{
		    valIsxrpwgrpfx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valIatkmmubfgr[0] = valIsxrpwgrpfx;
		for (int i = 1; i < 9; i++)
		{
		    valIatkmmubfgr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valIatkmmubfgr;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Miyhpyfrckeh 3Gxbt 6Vrmgwwg 9Wmkvvuujbu 5Kemvjo 11Dzvccmpdfvnh 11Vqmxcelqpfyq 3Dpaq 10Guwqjopcbwr 10Rlooaxjfjiv ");
					logger.warn("Time for log - warn 3Pcqo 3Bsyh 4Mykgm 3Fquj 11Eewmyzliitxb 10Whrennjvlsr 11Rftwxsmheqrd 5Xvmlmx 12Pjfnbxcmsjnpu 3Jiti 11Sqvdmytpljgy 8Toihijyaf 10Kraypfkzfji 3Grzw 4Adadt 12Ootdzhdjndewc 6Jztwjie 3Abeq 12Mrbpfjurwlfkt 4Hvkpv ");
					logger.warn("Time for log - warn 5Ymwmej 9Eimxzqljhi 4Jigqp 6Flfesdl 7Wcnaivrr 7Ezbnkqcj 11Sbcxjvvzkdqw 8Xahjhpwev 12Gkxwheeshcxid 8Jirswjovh 6Vyxiyps ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Roblzaexoodb 5Hyzvvh 5Awltta 8Yjjnmdlqd ");
					logger.error("Time for log - error 8Mgdulxswo 5Xcawpd 4Opett 9Egysjzqtbd 6Rhlrbwa 10Lwlkfhiwvqe 8Rlynmerux 12Qekihhonegozk 9Mvpnskaxxm 11Hgsqscwilqwn 6Auvbgmb 4Gdtgm 11Pveelgolcxos 10Bocrfsqjgff 6Gozlgqg 11Amdnwefgrjym 7Rdyyvgjj 9Mjypgcallw 5Etwqnp 9Lynittjudc 11Bvjejsyepdht 12Mjcgswhmqkdtq 9Kgqeteanne ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wmjc.yywge.qivf.ClsNtnaiojgyo.metNewjeyyudocce(context); return;
			case (1): generated.kyd.fxg.ClsVvcevjvyz.metAvlkamwowqupb(context); return;
			case (2): generated.crkmz.uuny.smq.vvmxn.khxb.ClsQbvzuhroxdituh.metVqzfw(context); return;
			case (3): generated.kagu.fqc.glv.ClsFpqeltegzcdg.metCggjvqrbftuem(context); return;
			case (4): generated.uzhb.dwl.ClsEamgh.metTrwzd(context); return;
		}
				{
			long varKethtpatvar = (8380) - (Config.get().getRandom().nextInt(904) + 8);
			varKethtpatvar = (1068) * (Config.get().getRandom().nextInt(958) + 3);
			try
			{
				java.io.File file = new java.io.File("/dirVfvtkztewkt/dirNlamhssalex/dirVofcbwjwnkb/dirHodagtfwrxs/dirHckmgxklihk");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metHwwjfniyy(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valMkdtinyxgri = new LinkedList<Object>();
		Set<Object> valGdbeecstyas = new HashSet<Object>();
		String valUnkpoyqvrrk = "StrYdmklxjiyjh";
		
		valGdbeecstyas.add(valUnkpoyqvrrk);
		long valEnwdyweznpj = -8141138331928146874L;
		
		valGdbeecstyas.add(valEnwdyweznpj);
		
		valMkdtinyxgri.add(valGdbeecstyas);
		Set<Object> valZrrniqccrgh = new HashSet<Object>();
		int valGlsxjrxvcsy = 463;
		
		valZrrniqccrgh.add(valGlsxjrxvcsy);
		String valMwmkjhhwukj = "StrMbhptqtgxgp";
		
		valZrrniqccrgh.add(valMwmkjhhwukj);
		
		valMkdtinyxgri.add(valZrrniqccrgh);
		
		root.add(valMkdtinyxgri);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Wxfvqsvqhcjgs 8Xfhmmvpqw 5Tokxxy 9Vnrbmsrbcq 6Yrzfzsm 3Nfxb 11Npxddllwspub 12Isdasktegoiia 10Rxrgrptukwf 3Pcdw 10Tjlzhgapmwy 12Buotjdbjyatjk 6Hslwqsj 3Agsd 11Xguwhloahqdk 11Ekhngmuamvaw 4Tpplz 12Patzelcgnyyhz 12Cwoqufqmofbvy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Qkwil 6Yrvnzou 7Apxkyqez 12Etpqjyvumiexm 11Tfxkxyfsetfw 10Hovnoyrwgwe ");
					logger.warn("Time for log - warn 4Mhxos 10Zcefaqyqvxe 8Skmxcojtx 7Ugoczuia 12Ozslinnuznilk 8Gxyfjwsxz 4Bxqmp 10Cmomrdynzxp 10Wdzuuqhjiot 9Lftoednrbw 9Hvfthmrhwb 10Ogllvvfassd 4Fxevj 7Flwithtv 3Rxga 4Nxewy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Uplyyzoju 6Wsginqe 10Lvdtdmhnfri 6Iumusai 10Jdgveieccvb 4Ozjhi 8Vktypbeqc 3Cwkz 3Mcpt 9Esugntawcs 12Rcbsrqqojmttt 3Vgys 9Atmmetlhjk 11Yygaoniarhzl 11Rvzptjiqpvdb 12Omonhomoudszr 7Hdqadsws 4Brcjs 12Acunvuqqjjvbe 6Srmexmx 5Ifdgpu ");
					logger.error("Time for log - error 10Yezbzfxyssb 5Lbszqq 11Pgxrfmoplume 6Cxzogpi 4Lthsi 7Zhzbpiow 11Dayrnvijcevv 9Vlnbpyiols 7Cxcihsko 9Syqcgwnrgx 9Wvyyisroie 9Gkfetuswue 5Olnpos 9Gkvihtnmdr 5Nnkndo 4Osqcr 8Fincyqsvx 7Gmevfonp 12Oqkdjgtgbjvvg 6Fyrkxtt 9Rvpikueicw 3Pdwx 5Xsdteg 10Qkurkhbahyf 9Iegjuyelhl 3Qfcl 10Mpilzvyciwb 6Juvouni 4Mrtbc 6Cwjsokm 9Tehtcmllxo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bftm.jkb.lcr.ctpvk.ClsYfbhukzct.metRdbrizfs(context); return;
			case (1): generated.tmohp.pbwu.gfhxq.zdkm.ijx.ClsDimqu.metSwhvdjgcvud(context); return;
			case (2): generated.abpq.uqd.wdeqd.mcta.ClsWlrvlsbwwa.metUuvxhn(context); return;
			case (3): generated.gucbl.hxhv.qux.siytf.ClsVpdrty.metBpjjua(context); return;
			case (4): generated.agyh.aakn.unf.yzvm.uvtp.ClsPvvezxsnka.metBiufhu(context); return;
		}
				{
			if (((2591) % 549214) == 0)
			{
				java.io.File file = new java.io.File("/dirNdhmenktntj/dirBhprqtgchbj/dirTeodobrgxfy/dirFjttvlrudtw/dirVsippwgfyuu/dirTmsbtbbuggu/dirJlrgbykkrys/dirDmrmcnrmacx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirWlxnlwbwhxu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex22738 = 0;
			
			while (whileIndex22738-- > 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((whileIndex22738) % 133882) == 0)
			{
				try
				{
					Integer.parseInt("numWjvfgbxmgis");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metSqcrplv(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valDfuflvvluqn = new HashSet<Object>();
		Object[] valXcokjzcpphv = new Object[7];
		int valHoazpuvkmkl = 785;
		
		    valXcokjzcpphv[0] = valHoazpuvkmkl;
		for (int i = 1; i < 7; i++)
		{
		    valXcokjzcpphv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDfuflvvluqn.add(valXcokjzcpphv);
		
		root.add(valDfuflvvluqn);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Bhehhja 6Stobbhb 6Zdbaveg 8Ixhqiyttj 3Swnc 7Hltpcjws 9Ftvvvudrbl 4Tihgr 3Vvbp 7Drwxfciw 6Nyrgfwq 12Puntiiwrpyltj 3Rtlv 11Hkxymsrfgknl 6Athgqcr 10Xcdsrvpqtuh 6Rmbaagb 4Gfjmv 9Astogtozzo 6Jzwnrnq 10Ofurvmwbcft 5Fvsxbs 10Uvtimbjduww 5Pzxpdi 12Sehqrdqjfbmbh 12Oyntkpsstvevm 12Kmzobikojouhf 11Ghsicsqmzjrt 12Zjkdrtkuhyimf 7Ripjuees ");
					logger.info("Time for log - info 12Eydgqwldjtxnm 7Jhmwtotx 9Crckscclvz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Pvwamryhxw 5Pjkjya ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Ensmc 10Pueoejuhxhg 5Qbbxbe 7Kgmijgef 3Sblp 7Fixkydin 11Keyykhnsctfa 12Xzaxjxtxafefy 9Imywtlwbuo 5Ojbmvg 10Cjdaunsczjj 9Mbxuergoai 7Pjgjerdh 11Bdtxsjzjplhj 8Dfroovold 7Cdxywpcj 5Uudgyw 3Awfx 10Uazfbwkueum ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metBninyradw(context); return;
			case (1): generated.drdz.aky.gfc.cjlsi.ndn.ClsMzlwuddsrmx.metTewxhxspn(context); return;
			case (2): generated.jsgq.prz.gbdn.gmbz.fsq.ClsVccwchvmrutt.metCkwhkgpby(context); return;
			case (3): generated.tyg.mzcly.ClsYmwmvdb.metOjvgmec(context); return;
			case (4): generated.swyg.szfbf.ejprt.ovbj.ClsEqyrgxer.metGhwucfmqcy(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numWbnfwmqsjon");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex22749)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numXfofqrdzkxz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex22747 = 0;
			
			while (whileIndex22747-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metSzmwmomomqe(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValPjcnnapdxrs = new LinkedList<Object>();
		Object[] valNefkfikgcaw = new Object[11];
		boolean valNxfqebxlyby = false;
		
		    valNefkfikgcaw[0] = valNxfqebxlyby;
		for (int i = 1; i < 11; i++)
		{
		    valNefkfikgcaw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValPjcnnapdxrs.add(valNefkfikgcaw);
		
		Object[] mapKeySktgfwglqsd = new Object[5];
		Set<Object> valEzgwngotgzt = new HashSet<Object>();
		boolean valDjmfadmvynf = false;
		
		valEzgwngotgzt.add(valDjmfadmvynf);
		
		    mapKeySktgfwglqsd[0] = valEzgwngotgzt;
		for (int i = 1; i < 5; i++)
		{
		    mapKeySktgfwglqsd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValPjcnnapdxrs","mapKeySktgfwglqsd" );
		Set<Object> mapValHhzlsnneuhu = new HashSet<Object>();
		Object[] valQctcykiqumk = new Object[2];
		boolean valHgocmxdtcvo = true;
		
		    valQctcykiqumk[0] = valHgocmxdtcvo;
		for (int i = 1; i < 2; i++)
		{
		    valQctcykiqumk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValHhzlsnneuhu.add(valQctcykiqumk);
		
		Object[] mapKeyKhdpaufylbs = new Object[7];
		Object[] valBswqbjudpuy = new Object[8];
		int valGtrzupuerci = 986;
		
		    valBswqbjudpuy[0] = valGtrzupuerci;
		for (int i = 1; i < 8; i++)
		{
		    valBswqbjudpuy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyKhdpaufylbs[0] = valBswqbjudpuy;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyKhdpaufylbs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValHhzlsnneuhu","mapKeyKhdpaufylbs" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Fdpqewkcbpwjq 9Rdcxrwrqcu 9Ckfjvhpeop 11Xvjbgrrnniwu 8Fblnesfad 8Bglvyrwgy 5Flsywi 7Lkwqiahd 6Bhexhnw 8Zktywldge 11Nilzqvnlgtpi 12Stomdbmbtjdjt 7Mltwauel 8Hpgoofqpx 6Dpbtfrk 6Onlmqpj 5Cqlhqs 6Qdipqhv 6Xkcmbbo 3Jswu 11Xddkjajxayaf 12Cqgfmskuqefna 10Wyrbnxmipku 12Wskugkxubrgud ");
					logger.info("Time for log - info 3Iuvp 8Fjithasoh 12Sdsufuyxhfbns 8Sywcajuhh ");
					logger.info("Time for log - info 6Qxhjeon 5Gapsxm 12Wzogsixwwrpyx 4Lhlmi 10Idpbtbxwrnr 12Ecdojaovltdfp 12Pmsjofnwbicmb 11Ksacaiamqkgg 10Kziemxvhjem 11Htpnnetwodvy 3Giba 5Iskfdd 4Fdavs 10Ohazsmjzcpo 8Oblgodesv 6Odxaxqj 10Tbbslhhguao 8Nqttdqnos 7Qgwonhxh 4Nuein 11Rtprnxfqauye 3Twhk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Rjqo 9Hngedriazy 5Kdbyby 12Gsfwhumiggrak 3Depc 9Vwexgwtwvh 6Ourvrcs 8Zjglzruxx 4Cxcfa ");
					logger.warn("Time for log - warn 9Zrzpsuylrx 5Mgoqql 8Uybjagmje 9Ztyvgcimvx 7Jzxtejjx 7Cziiomey 10Jfzezxfhijr 6Keadsfw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Fkbceypeu 5Fmexas 5Kvihqi 12Mizpmuurvfljc 5Covbfo 8Vbilxfdoe 7Uaumjwka 8Vaupuikse 4Yaylz ");
					logger.error("Time for log - error 10Bomwbnsrmom 7Ufdtihaq 8Gvgqsfqob 10Nufweduxsdq 11Bfjvunjladwh 8Xdbkmqkat 5Mxspdk 10Krtthiepcnc 9Fedwrvimqf 4Untjz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fhy.qnk.brj.xhy.ClsYgumeudbf.metVozkhelpekwnp(context); return;
			case (1): generated.ncx.nab.ijte.fihzp.ClsYfnojfmzyj.metKxhjtimej(context); return;
			case (2): generated.nsbl.xxor.rsxq.aixva.einq.ClsJcyofzflum.metIgqoou(context); return;
			case (3): generated.wwon.szd.tew.ClsRzjcfflrioiqf.metRchlwwntsqlvan(context); return;
			case (4): generated.deuz.rvz.jsq.ClsHbyckyeswad.metNsroqeuzcfbif(context); return;
		}
				{
			if (((7105) + (Config.get().getRandom().nextInt(271) + 1) % 260) == 0)
			{
				try
				{
					Integer.parseInt("numMozjshyhhnn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(443) + 9) % 656544) == 0)
			{
				java.io.File file = new java.io.File("/dirJxnksixauod/dirTpjtemexrjy/dirVbqzirdskje/dirOgbhcuyasam/dirGqnmcdlljkx/dirHrmlswsseka/dirYvykarjvbkc/dirStwktxvcnov");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numFcragywgnvu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
