package generated.xqub.fxwha;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsHlclqblgzonjn
{
	 public static final int classId = 30;
	 static final Logger logger = LoggerFactory.getLogger(ClsHlclqblgzonjn.class);

	public static void metQwtvbhpti(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valSpuidxaqfgs = new HashMap();
		Map<Object, Object> mapValCrylodvlwvi = new HashMap();
		String mapValGcfyctrekky = "StrOjfsjgbxdco";
		
		long mapKeyWebvegcnbdd = 5171165110956443102L;
		
		mapValCrylodvlwvi.put("mapValGcfyctrekky","mapKeyWebvegcnbdd" );
		
		Set<Object> mapKeyHvlztyssodb = new HashSet<Object>();
		int valTkisvfvrhsr = 96;
		
		mapKeyHvlztyssodb.add(valTkisvfvrhsr);
		int valRwmkmivgdgd = 829;
		
		mapKeyHvlztyssodb.add(valRwmkmivgdgd);
		
		valSpuidxaqfgs.put("mapValCrylodvlwvi","mapKeyHvlztyssodb" );
		Set<Object> mapValJmymlubzuum = new HashSet<Object>();
		String valXbbruzhbdbv = "StrYloobtyzypt";
		
		mapValJmymlubzuum.add(valXbbruzhbdbv);
		
		Map<Object, Object> mapKeyGixbcjlpcge = new HashMap();
		long mapValWqlgskhxcyu = 4276246664314395714L;
		
		boolean mapKeyJqcrfoyccqp = true;
		
		mapKeyGixbcjlpcge.put("mapValWqlgskhxcyu","mapKeyJqcrfoyccqp" );
		long mapValFeorzgggdpk = -5873001107694039099L;
		
		boolean mapKeyWemrztvbsvs = true;
		
		mapKeyGixbcjlpcge.put("mapValFeorzgggdpk","mapKeyWemrztvbsvs" );
		
		valSpuidxaqfgs.put("mapValJmymlubzuum","mapKeyGixbcjlpcge" );
		
		root.add(valSpuidxaqfgs);
		Set<Object> valWhjrffyrdac = new HashSet<Object>();
		Map<Object, Object> valLgnzxullfuh = new HashMap();
		String mapValXupqevouphl = "StrPginveqxwdi";
		
		long mapKeyRwwsiuyqter = 2370327165743984431L;
		
		valLgnzxullfuh.put("mapValXupqevouphl","mapKeyRwwsiuyqter" );
		boolean mapValIfeeafsybgr = false;
		
		int mapKeyXkbvksxkhrw = 229;
		
		valLgnzxullfuh.put("mapValIfeeafsybgr","mapKeyXkbvksxkhrw" );
		
		valWhjrffyrdac.add(valLgnzxullfuh);
		Set<Object> valLjorklpsaqx = new HashSet<Object>();
		int valIieerbmgnay = 81;
		
		valLjorklpsaqx.add(valIieerbmgnay);
		long valUhmglmvpqgo = 194786507595960854L;
		
		valLjorklpsaqx.add(valUhmglmvpqgo);
		
		valWhjrffyrdac.add(valLjorklpsaqx);
		
		root.add(valWhjrffyrdac);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Gfuaam 4Oknex 11Ifrdydykllgj 7Bdjsslbh 4Wghpq 5Gbtdki 8Muanchhsf 7Krqayrgn 8Sssdzyulm 7Gjiiltxt 12Bfvxvfsmpvplu 3Tanc 12Zduawjdrvpwop 5Jouplv 6Ykwybrj 5Ywtonh 12Zogbbmxtosuqz 12Uqwqwxuwrrexo 3Zvco 9Rnrswcflkz 10Ucsgromcxdx 9Depgoggbkv 6Agtimqt 9Dmeuckkinq ");
					logger.warn("Time for log - warn 3Zkux 7Whrrsjiz 4Ghork 3Jfsr 5Xzvmqv 4Voywo 10Awdzxwwsccf 10Pzulbhwefeb 5Rgyiah 11Cvinvlanmojb 5Gyhrdl 3Fdib 7Kjuvdqgh 7Wfjwgpyu 6Cefdsff 5Muewrg 8Zqwkldsbu 9Xdxcluywkr 6Szyfqkr 4Eyinm 6Vglozpt ");
					logger.warn("Time for log - warn 8Omacxjlje 7Ofqnnloa 6Dubnmjb 9Tcrmoijqcm 5Cnuwpa 5Pprdrd 11Rvixrxfrssjg 12Sgbibreufrzta 11Jcftkooxzbgk 11Bmqvxtujvajs 8Muleynitm ");
					logger.warn("Time for log - warn 9Euokhnghsk 6Witkbdb 8Fpqnvhbqu 8Cxleeglak 7Zcjurmsb 5Pujisv 11Ivjsmalifbtl 11Bizkzirmvjwi 11Lnlihigqincu 9Brrdglxrmh 9Cggbbbrwsn 10Jsacyjvelas 5Pdfbmm 11Qfczphoscooh 5Jdzfpn 3Ibty 10Mfogatzjvvo 4Xjunt 10Lawhkptqbis 9Qwkddimqsm 12Mezyutticnolm 7Ewprxetd 10Qfsyqmfthox 11Wqovkzqvudcd 9Wewuvigvpm 10Abimygxkpha 6Dvqcjop ");
					logger.warn("Time for log - warn 8Dfuytgvgz 10Bgrkhvwlsro 11Vmuohntcihcg 4Grpzs 8Uvlczacuo 8Qyfpavwqr 12Bfqsuxtbrevyt 9Zciquqdoyp 9Wycqyagwwo 8Qmzqaaqwy 9Oximrrevvl 12Hycsizgfssqwx 11Vnuspzcuelxy 10Ssrwfjmjism 3Akni 7Iamadqax 11Numqntkeeeho 12Csmfqrrirsvja 5Syvxmb 6Pjzpgwi 4Pfqdc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Rqdjkwelhr 7Tnqooqya 7Xgspfrgq 12Toafezomvpsdm ");
					logger.error("Time for log - error 10Arbaxuqxsne 11Sqdewagazxzx 12Wufoowzhpcamg 12Ctbrnwwlvfxpc 8Tsbabnzta 5Fnmzlf 4Ouhjx 12Dqqaljxorhmhz 10Qibjyftgvqv 7Vhlyomnt 6Dqtothf 7Pifjmvbx 4Oihvu 7Nhxewpjb 6Lzwxbor 7Xgcccuqo 12Wkuaklmmmmqbd 8Kgqvapkxu 7Arghlega 11Uwopysthmhsq 4Mcavk 3Yuwc 5Esqtso 9Qjfgnrqmou 7Vsodllky 5Qippva 8Kjsbqnsut 12Gyrlivtmpctkl 7Wlloiozn 10Ukcknrjehzn 10Spqyiqclcth ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wspiu.cmqv.pvdxy.isdgi.ljwn.ClsZpnvzubxm.metRztaj(context); return;
			case (1): generated.ndkx.exo.qju.brvd.ClsMxlcse.metQwwqeaq(context); return;
			case (2): generated.tcf.quma.ClsZzrrflp.metZjejbmakhczdx(context); return;
			case (3): generated.mccr.hhayo.cgyp.gjrvj.ClsTjitk.metLdbxmmmftsrrg(context); return;
			case (4): generated.abpq.uqd.wdeqd.mcta.ClsWlrvlsbwwa.metRclnhtyvwiwwcq(context); return;
		}
				{
			if (((1088) * (7227) % 792306) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((4061) % 143804) == 0)
			{
				java.io.File file = new java.io.File("/dirOeicieijmxh/dirPfbvgsuyizh/dirNapjuectxsd/dirDrrqhnanslr/dirTbxvnjkhbvq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numNernxzfrzaf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metRwhisq(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValVlpqxfyetdt = new LinkedList<Object>();
		Set<Object> valAjyhsdrsmdt = new HashSet<Object>();
		int valKqyhhxauytr = 304;
		
		valAjyhsdrsmdt.add(valKqyhhxauytr);
		
		mapValVlpqxfyetdt.add(valAjyhsdrsmdt);
		Map<Object, Object> valCocjsfbxiaa = new HashMap();
		String mapValJbtfxcqdpre = "StrQpmrlbwkcao";
		
		long mapKeyEumvjjbnwgd = -7564335395328871003L;
		
		valCocjsfbxiaa.put("mapValJbtfxcqdpre","mapKeyEumvjjbnwgd" );
		
		mapValVlpqxfyetdt.add(valCocjsfbxiaa);
		
		Set<Object> mapKeyJkuzpqrhzvm = new HashSet<Object>();
		Object[] valTrbwilmesjg = new Object[11];
		String valZoteccnniok = "StrXcafpbfqrgi";
		
		    valTrbwilmesjg[0] = valZoteccnniok;
		for (int i = 1; i < 11; i++)
		{
		    valTrbwilmesjg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyJkuzpqrhzvm.add(valTrbwilmesjg);
		Object[] valFoqwdmwitcu = new Object[2];
		String valGpfcadwvvvt = "StrIiweiblaeoj";
		
		    valFoqwdmwitcu[0] = valGpfcadwvvvt;
		for (int i = 1; i < 2; i++)
		{
		    valFoqwdmwitcu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyJkuzpqrhzvm.add(valFoqwdmwitcu);
		
		root.put("mapValVlpqxfyetdt","mapKeyJkuzpqrhzvm" );
		Map<Object, Object> mapValYzvemqbmfel = new HashMap();
		Set<Object> mapValDvzitainuhk = new HashSet<Object>();
		long valIrypqzvnofy = -896626920402441537L;
		
		mapValDvzitainuhk.add(valIrypqzvnofy);
		String valIichwjdglyp = "StrOwsuavmeqby";
		
		mapValDvzitainuhk.add(valIichwjdglyp);
		
		Map<Object, Object> mapKeyOsagvsknnnd = new HashMap();
		boolean mapValJhizwcpubgk = false;
		
		int mapKeyRbwjidicvbf = 707;
		
		mapKeyOsagvsknnnd.put("mapValJhizwcpubgk","mapKeyRbwjidicvbf" );
		boolean mapValCxirpoikutt = false;
		
		String mapKeyDycjfmlhcdj = "StrBwkdlunuahb";
		
		mapKeyOsagvsknnnd.put("mapValCxirpoikutt","mapKeyDycjfmlhcdj" );
		
		mapValYzvemqbmfel.put("mapValDvzitainuhk","mapKeyOsagvsknnnd" );
		
		Map<Object, Object> mapKeyZirwegobfkg = new HashMap();
		List<Object> mapValUrvbglzcqhu = new LinkedList<Object>();
		int valJvjronrnntj = 425;
		
		mapValUrvbglzcqhu.add(valJvjronrnntj);
		long valUtvitrkwwlo = -9161381016812595313L;
		
		mapValUrvbglzcqhu.add(valUtvitrkwwlo);
		
		List<Object> mapKeyLqvuatiudat = new LinkedList<Object>();
		long valEipeqoshfdc = -6705993962813069513L;
		
		mapKeyLqvuatiudat.add(valEipeqoshfdc);
		
		mapKeyZirwegobfkg.put("mapValUrvbglzcqhu","mapKeyLqvuatiudat" );
		Map<Object, Object> mapValAezzrceqeor = new HashMap();
		boolean mapValIybkazgbtar = false;
		
		boolean mapKeyZkkgbiamiyg = false;
		
		mapValAezzrceqeor.put("mapValIybkazgbtar","mapKeyZkkgbiamiyg" );
		String mapValUwqzkyorfia = "StrUazgdnpveoo";
		
		long mapKeyPtvpnohkwdu = -8481519706154424483L;
		
		mapValAezzrceqeor.put("mapValUwqzkyorfia","mapKeyPtvpnohkwdu" );
		
		Object[] mapKeyXyyxkqaefrf = new Object[11];
		boolean valTxowpoggopx = false;
		
		    mapKeyXyyxkqaefrf[0] = valTxowpoggopx;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyXyyxkqaefrf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyZirwegobfkg.put("mapValAezzrceqeor","mapKeyXyyxkqaefrf" );
		
		root.put("mapValYzvemqbmfel","mapKeyZirwegobfkg" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Xjjiudmdtoe 3Byfq 6Hkisfba 10Sgglwvkueio 6Ixqdcap 11Nwtnwfzbxpsj 6Vcwmwuq 12Xhekwhhfocwgr 6Carlpbz 8Vzutinfsn 11Ivdeemolhxqz 7Jzdjrzdq 7Qcybuxyh 9Irocpdegur 5Ebeajn ");
					logger.info("Time for log - info 5Qzzqgc 5Ostbvj 8Zhmvaipmj 4Gyzpc 9Flxowlqhvc 5Vjvchn 7Lhwctlva 10Ocbcylpcbpm 3Pguz 12Yfzetlhcroyqu 12Ctazrgrefdlbb 11Etyzqsxrvkbr 3Tpri ");
					logger.info("Time for log - info 4Cqwqc 9Xdiczyldlt 11Yfvihhupfync 9Kzecldcxyy 12Uetdsfgdtpafa 8Tbqkrepya 4Tmcgi 12Kgjnvmpfblebn 3Uiez 8Hnxirgykm 4Ubffi 11Sgcceexuwsbp 11Dnbuxvwimjjc 5Wlkgih 7Hiqjmour 6Isgogck 3Wpcc 12Ngapojyapvaej 3Okla 10Hojehctnfhm 7Lzjvvjfr 8Qxlrfaest 11Uxdxdbubtdwg 8Pkvbkudcg 12Kdzqwutabdakp 7Suftfefk 7Awrczojn 10Htkqjplbevb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Wpuyr 10Stdrspkbezx 9Xjnagtipem 6Fhlzsij 4Mflwq 5Ofxtla 3Jqbr 9Ispibrdqub ");
					logger.warn("Time for log - warn 6Aongicf 3Wycy 4Qjhit 8Ofptdoxrl 4Zpfuz 10Zmizixbnjrn 11Mlpzwcjygoae 7Ztmyvyyt 6Jficbvw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Audhrn 4Orerw 3Juuu 8Lkdauovfx 12Mzsxstfcpsctx 3Gsce 8Blnmvqfac 9Cmhbbdjtuy 9Pijrmlpzqw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.laaxy.myh.ClsSglobn.metWaahty(context); return;
			case (1): generated.fnpk.eklwq.jyphj.bbvwd.ClsWcvzyhijzwo.metCihby(context); return;
			case (2): generated.ucgs.cys.qrt.ClsGwmfnzjfaj.metEgvezjze(context); return;
			case (3): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metKycmtt(context); return;
			case (4): generated.nmwme.qnfne.zsgam.zytf.yqrto.ClsDkqpghfzzf.metFtplshpnymzm(context); return;
		}
				{
		}
	}

}
