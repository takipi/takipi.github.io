package generated.zmpxh.humct.jpc.zcr.uswj;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsMmunby
{
	 public static final int classId = 180;
	 static final Logger logger = LoggerFactory.getLogger(ClsMmunby.class);

	public static void metPsfhf(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValVlqezynessc = new HashMap();
		Map<Object, Object> mapValWmrvafpevfi = new HashMap();
		int mapValZjsyeowtsck = 32;
		
		boolean mapKeyDrxyhpkivro = false;
		
		mapValWmrvafpevfi.put("mapValZjsyeowtsck","mapKeyDrxyhpkivro" );
		
		List<Object> mapKeyCqamzwexzqa = new LinkedList<Object>();
		int valEncvcfqacvk = 177;
		
		mapKeyCqamzwexzqa.add(valEncvcfqacvk);
		boolean valEjdebunowuj = true;
		
		mapKeyCqamzwexzqa.add(valEjdebunowuj);
		
		mapValVlqezynessc.put("mapValWmrvafpevfi","mapKeyCqamzwexzqa" );
		
		Object[] mapKeyZiogzovajsx = new Object[10];
		List<Object> valXffitnlgdsk = new LinkedList<Object>();
		String valZksnyexiwtg = "StrIlmrcsmafme";
		
		valXffitnlgdsk.add(valZksnyexiwtg);
		long valStwdrcrrhbb = -1963565805837474437L;
		
		valXffitnlgdsk.add(valStwdrcrrhbb);
		
		    mapKeyZiogzovajsx[0] = valXffitnlgdsk;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyZiogzovajsx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValVlqezynessc","mapKeyZiogzovajsx" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Unhj 4Zugeg 12Gpbngdedtoryr 11Qgvbcrprunqy 6Arqtqya 6Rlicxco 6Uqeuibl 4Whypw 3Kuzf 3Ggdy 8Lsiyxaamq 9Wppgiazipn 10Ddzzoamzrlp 8Micsnggks 5Nqvoxc 11Zpokbpuvxkul 12Ppxvqtukiugpg 11Plloumnmkosd 9Zigcyaqoak 9Zrympqyhbq ");
					logger.info("Time for log - info 5Fbdkdy 11Okhdekqubofw 8Fgxmvsdot 9Fbrvivayzw 10Niutugjhsxm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Nkhbbkjxtlumd 7Uovkuygi 3Magi 4Myxsp 6Aotixno 10Raopqmmutmb 11Mhipajjbyxew 8Wlihhwiut 11Cfwdxinovxds 12Jzqojczznxhwo 4Qvoyz 5Bejbsm 9Bsktmhifkw 10Nveoauwlpok ");
					logger.warn("Time for log - warn 3Xcft 11Stxkerlwtola 5Ktremy 12Rqhgvonrwoauy 10Qazvbafbvbr 10Tfabjnxyipe ");
					logger.warn("Time for log - warn 8Zberluehx 5Pmxoox 9Srkwnzwrqr 11Zxkpqpryikds 7Vrduxarg 8Gurykxzki 8Ktucrmvbq 4Zlgpz 9Vccppyrucy 8Njxivffob 8Dolojdqlm 12Trqppywemcqwu 10Sorpxntctgc 3Boox ");
					logger.warn("Time for log - warn 10Qrwczalmkwd 7Blipcxtw 6Sethpkr 12Ljhstsmrzzmbe 8Njucsencq 3Mqjn 6Bmixmao 4Ndeyn 3Cejs 9Mxtaebnwyb 10Rtoluoeiklh 11Yonmikrzyxex 8Enqhyusnf 10Gkxajlzrxes 11Ycxvmeimatcs 11Ftzmockuabnl 9Dnkycxwvfy 3Xepm 11Xkukoroywfxa 3Zlvd 8Uflivyuhj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Zqkkwzfsifgvl 6Flvbchj 11Rtowipxehqqo 11Abvhpynyadxw 10Erehgupginv 3Gxcb 8Naeppbotd 9Gjeiwvynhw 5Pvmhbt 7Gywpclhy 11Ejqflavnplda 6Tayzfnt 3Wdpl 9Cnedshxjqk 3Fbqk 11Xjwdgruyjfmn 8Eqaxapmdn ");
					logger.error("Time for log - error 5Rpgbbq 9Erinxihpbp 5Bqskdy 11Sfljlkfmiabm 10Yfgktneyfvd 6Sybsxiv 5Wajlco 12Qwdvpzpjqakul 12Iblehcmtvulvr 9Rylxjjfbvi 3Saps 3Rhro 7Efaksoyx 5Uduhzi 6Yuiidzj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.iwmr.swhrn.ClsOqphojsm.metAtffyacmyd(context); return;
			case (1): generated.pema.ddj.ssuh.ClsIlinaijnkxxo.metUxznbuacrrpc(context); return;
			case (2): generated.nexb.cijvx.oksu.fhpbq.ivltf.ClsErarfyfw.metMuphdva(context); return;
			case (3): generated.blsj.gki.ClsOuhbksvj.metOmfsztvrsb(context); return;
			case (4): generated.qnzm.livr.ClsPutzsgygioejxl.metMebbiihjouloja(context); return;
		}
				{
			long varEdqsdicviqb = (2628);
			long varYhqavbwjsnu = (Config.get().getRandom().nextInt(979) + 1) + (Config.get().getRandom().nextInt(110) + 5);
		}
	}


	public static void metRokhpzyzafegb(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[10];
		Map<Object, Object> valEptcqqxiriq = new HashMap();
		Set<Object> mapValRnxigdeswtk = new HashSet<Object>();
		boolean valBrunyfmmgbd = false;
		
		mapValRnxigdeswtk.add(valBrunyfmmgbd);
		long valJrhffxaurqr = -5569033063030740483L;
		
		mapValRnxigdeswtk.add(valJrhffxaurqr);
		
		Map<Object, Object> mapKeySvgwaatbdsd = new HashMap();
		boolean mapValKwjjndfeoke = true;
		
		long mapKeyVnwuzficdvr = 496943605712784553L;
		
		mapKeySvgwaatbdsd.put("mapValKwjjndfeoke","mapKeyVnwuzficdvr" );
		boolean mapValHetjwlqfcjy = true;
		
		String mapKeyOhhllfuqony = "StrJlgdxgbikah";
		
		mapKeySvgwaatbdsd.put("mapValHetjwlqfcjy","mapKeyOhhllfuqony" );
		
		valEptcqqxiriq.put("mapValRnxigdeswtk","mapKeySvgwaatbdsd" );
		Object[] mapValNejmaraarfv = new Object[7];
		String valTytfpwvblgc = "StrXjzgxjbfrmf";
		
		    mapValNejmaraarfv[0] = valTytfpwvblgc;
		for (int i = 1; i < 7; i++)
		{
		    mapValNejmaraarfv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyAdzbbqvlfpt = new HashMap();
		String mapValKtlszyizcwv = "StrEuirhrfjxvh";
		
		int mapKeyZrdgrtxsfpg = 977;
		
		mapKeyAdzbbqvlfpt.put("mapValKtlszyizcwv","mapKeyZrdgrtxsfpg" );
		
		valEptcqqxiriq.put("mapValNejmaraarfv","mapKeyAdzbbqvlfpt" );
		
		    root[0] = valEptcqqxiriq;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Jaah 5Vgepbm 9Oxljihusas 11Xsdmgihxfkjo 7Kofdypmk 9Iblkusacry 9Vpjtdjhzmg 9Zlflajgoop ");
					logger.info("Time for log - info 6Ogureap 6Fhjakwy 5Bksaid 12Tkhwfxjoxqzzo 12Bxuxedsmarrul 6Wfrhpyi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Ipcutkrqydvcz 11Wbyvmaoqeixk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Vwvdcapozsrca 6Vrndtyn 8Plcumektx 7Kmnrpjmm 12Vajbtcrycjuqr 7Ueolojhs 9Wbavjsisck 5Fqylau 5Pjvufv 7Yuyeremr 8Obtzpviap 12Xxzfyazrzqivm 5Trrwib 9Nucpvypkxd 5Uomero 8Tiypbrqrh 3Iwzb 10Nhowgkhfvey 11Qvicqzponhcc 9Gfdhzljjxy 5Deyxnt 11Opqjxchwtdcc 12Uqkjwahqwozdm 3Evyd ");
					logger.error("Time for log - error 12Ajirqxxlwftah 8Tfwuypsbw 9Dkfxxmnsqy 12Ykmwrwqiqcyey 3Pzfd 9Nzcxnlstcd 6Nzmarnp 6Jazltma 4Lxaxe 8Hpktnnqeq 6Qmfmsun 6Vvuzmjq 11Lmavzbbzihqy 6Kopqffk 10Sbkaydishkv 9Cxojgglwaa 6Hfeqloz 4Gdyih 10Csldxfbpgjm 11Ipbkxmocyybe 11Ybktflonwiie 8Maoudcoqw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.idpj.vmnmp.ClsRgyokulekkkb.metRovgxbargonqf(context); return;
			case (1): generated.gyic.epw.ClsQxhbkrqjzoqujk.metGcqcxmaffuic(context); return;
			case (2): generated.qnmn.narfk.rdhdk.ClsPtwatcpapj.metSoquexyw(context); return;
			case (3): generated.ocklj.sbz.ClsVzertfboftzd.metSzwoijjcwsu(context); return;
			case (4): generated.pxy.vesv.fuz.ClsEaskwlgtcshts.metCnqxpzkxiqea(context); return;
		}
				{
			long varPdyzwmoqsyp = (Config.get().getRandom().nextInt(247) + 0);
		}
	}


	public static void metAhzyvaxwwvb(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[9];
		Set<Object> valNazdrxdpfkp = new HashSet<Object>();
		List<Object> valWjjfegdqulj = new LinkedList<Object>();
		long valGvelvcibqzc = 5319201592115218683L;
		
		valWjjfegdqulj.add(valGvelvcibqzc);
		
		valNazdrxdpfkp.add(valWjjfegdqulj);
		Set<Object> valFmkjghmxlwh = new HashSet<Object>();
		boolean valMjxhrvyoykx = false;
		
		valFmkjghmxlwh.add(valMjxhrvyoykx);
		int valSbkgiizhfnk = 563;
		
		valFmkjghmxlwh.add(valSbkgiizhfnk);
		
		valNazdrxdpfkp.add(valFmkjghmxlwh);
		
		    root[0] = valNazdrxdpfkp;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Rykrrptl 6Ghtizol 6Kmxcnsz 6Vwthrbi 9Lvyslifgnm 3Pjdl 5Ewnuws 4Jqhrf 9Aliioaqrsj 9Ysrjrmkmmq 5Eqntrr 4Xhgft 10Vttzmmsqdnw 5Lcsvmi 10Uwfsnzlekoq 3Whvn 11Tkfcrxlbgsrl 7Tikqnyzo 4Nyvaf 10Twhohwllaxi 9Bbkbzkmwbg ");
					logger.info("Time for log - info 6Swuxedl 12Jjlnlrbapegyp 6Cjzipqq 10Htfbapwttaw 10Amkftbbdvuk 5Byibvw ");
					logger.info("Time for log - info 4Ucefe 6Esmpasy 6Jstqfmh 10Dukindyxpkf 4Lggac 8Kjepsycpx 10Xtmbyyapenj 12Mrpqrjldpbwbx 5Jzjdxu 10Wpdszmweodo 8Puyffuamz 10Zwxikjizrfd 3Thlk 12Oidhgxweutpay 5Mdtiqf 12Ytempwnvvmiei 9Pevlmgnpsi 10Ccygvprwtob 4Thvni 9Ghvgrrrexp 6Ctmcmsf 5Psuoml 5Lacrrk 6Vlrmmbz 12Tvtpmegzqgpre 7Eirpzuem 7Jajrswrl 4Nobpt 4Yhbez ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Tocfgvhq 5Ulsddl 9Wgogoahqgc 6Nspzvgd 5Pznxzn 10Amzvdllrxwo 10Sxtflrqhumm 7Plzfizub 4Eiwsx 3Mvvb 4Swsud 8Aevfnoyrl 10Fahwebulucv 11Ehkbvjtdlktx 3Ijkd 10Ovephcnzlga 9Coxqpgoypb 8Zkwrlpkka 6Aitctvh 6Bncquky 11Clwcydozxwjx 6Clnoysq 11Kkclmizxuvzh 5Titvbl 8Rbrpltoxe 7Fivywmub 6Pkaacvf 9Kspxxcnvas 7Muewmjvp 5Bvcnin 4Dkufu ");
					logger.warn("Time for log - warn 10Xuqpumzqkrr 7Bgyegwww 10Oitqpgsspku 7Hjbqltrf 10Bkmrhuemnab 12Rffldmdibwrvv 3Vonf 3Jayw 12Vjhlubdbzhxvd 10Fvjfrbtvqbj 3Giiy 4Irnym 12Eictposkmwdxy 9Zsifdcjnkn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Llup 11Zqyugbwhycnc 11Vccupmuofhut 11Tgvcwmldtpwg 8Skultjoyp 11Tdyegbohxztj 12Mmqpakzmcasrp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rjuw.mmbua.ClsRawvqxmhewbl.metOsciin(context); return;
			case (1): generated.owqo.mlfkn.xvo.nivs.zcmac.ClsNuoghbmezp.metYnvilumdjys(context); return;
			case (2): generated.exhp.ngeqz.saycv.ClsTbfjaj.metDyioavqwafahi(context); return;
			case (3): generated.mbn.igyf.ivup.sglb.ukb.ClsQzhoqgskicnjw.metWrxexkxzovhdv(context); return;
			case (4): generated.rnr.pwsrq.cbi.tat.ClsQsqavl.metNujgqvqobxeyw(context); return;
		}
				{
			long whileIndex23233 = 0;
			
			while (whileIndex23233-- > 0)
			{
				java.io.File file = new java.io.File("/dirZqbqxslewwk/dirEtrqsoaldte/dirAbrjtwylfwm/dirEjmdscvhxzs/dirHarmsurcakv/dirIiyuimzvnvl");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
