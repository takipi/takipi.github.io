package generated.mrz.embg.gydr.vls.fvllv;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsYrxhq
{
	 public static final int classId = 296;
	 static final Logger logger = LoggerFactory.getLogger(ClsYrxhq.class);

	public static void metPmjofrckzavphr(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValThbqjvywuuz = new HashMap();
		Object[] mapValFedhnmzssat = new Object[7];
		int valOclczeutxyi = 858;
		
		    mapValFedhnmzssat[0] = valOclczeutxyi;
		for (int i = 1; i < 7; i++)
		{
		    mapValFedhnmzssat[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyGmauiymsdub = new LinkedList<Object>();
		boolean valWcusynuxkos = true;
		
		mapKeyGmauiymsdub.add(valWcusynuxkos);
		boolean valHnvxaotrjhx = true;
		
		mapKeyGmauiymsdub.add(valHnvxaotrjhx);
		
		mapValThbqjvywuuz.put("mapValFedhnmzssat","mapKeyGmauiymsdub" );
		Object[] mapValNumcnmbhstl = new Object[10];
		long valVuapyldfity = 2050452597897104943L;
		
		    mapValNumcnmbhstl[0] = valVuapyldfity;
		for (int i = 1; i < 10; i++)
		{
		    mapValNumcnmbhstl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyVlprutoduck = new Object[7];
		boolean valMeybfnhpzjq = true;
		
		    mapKeyVlprutoduck[0] = valMeybfnhpzjq;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyVlprutoduck[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValThbqjvywuuz.put("mapValNumcnmbhstl","mapKeyVlprutoduck" );
		
		Object[] mapKeyTjixxyskokt = new Object[11];
		List<Object> valDrbacsgyfjx = new LinkedList<Object>();
		String valLwkkjzmeeba = "StrHcmqewwjuhj";
		
		valDrbacsgyfjx.add(valLwkkjzmeeba);
		
		    mapKeyTjixxyskokt[0] = valDrbacsgyfjx;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyTjixxyskokt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValThbqjvywuuz","mapKeyTjixxyskokt" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Vhyvw 12Wepndzmtsvwdu 3Qpqm 10Xoojyunpflw 9Lvtvdylpmy 9Rdxyasygsa 6Xtpysht 6Nwyafav 11Uakjqaiedbyo 3Knta 3Pxma ");
					logger.info("Time for log - info 3Ahrs 10Ygfpbuicxfa ");
					logger.info("Time for log - info 9Qszayjovzd 5Pgeajc 12Qjdlvnexfagqq 10Yvojwhwzrlh 4Lbjif 3Xmte 7Ctsbgxoo 5Aclnwa 11Opbnnwiterzs 6Vhclvrd 3Vijd 3Qgqy 8Ddrbtitja 3Ifni 12Xseyixnnjmtep 12Dlkfsiqjqnvho 8Jjseusudx 3Doxt 12Eomjonejaltvv 3Zgri 4Smquj 5Xjzzyy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Dgtbwixpuscvz 11Onxrsnbkcyiu 5Ksxysx 4Scnwd 3Sdoc 10Vcigcwihuop 7Cqnnfvun 11Dbnmglitgpax 8Qzyatvivl 5Geolbl 7Wcrzxwup 10Jtvxyomthig 4Qrvrb 4Rhhns 8Uwvqfcqvf 11Zalypqkmlkqh 4Hxwqt 7Acfyqzws 10Ssxzqhonbxz 5Xmaver 6Ugxelyf 7Odxaqcfs 9Epbqyltvrx 11Efufeiivnezr ");
					logger.warn("Time for log - warn 8Wepkaewai 11Defflaqlynmi 9Qhqeacoivc 6Mdfnscl 9Poaqrvydhc 12Ropidhtegvkqq 6Cwpqved 11Jyaiuyrdgvrl 7Ktmikuft 3Kwqd 3Jstl 4Lglvs ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Dwjzzprupkiu 6Kaybigt 7Nauhwovq 9Hwxctufmou 3Bdfw 12Uxbpvibeqawlz 6Psglgud 7Wyjwlvng 4Isleu 7Solwhtkg 4Rhpde 5Nzhmyt 7Kvizpwhl 8Afdnazets 6Mfijgoy ");
					logger.error("Time for log - error 11Fgyuwbklxqdq 8Tpbruwgep 4Wnohu 3Maov 8Ztixwdawp 8Cbktjwwnm 12Mtfjisohrsevk 5Xvizya 5Ahtriq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gpnn.qul.pdexl.hxjph.zmndq.ClsIcvyndtrplxfkf.metWyrdoedscqrw(context); return;
			case (1): generated.hyq.yrx.ucb.jdut.ghw.ClsXwcyosgzsc.metGxlvnhkhnqc(context); return;
			case (2): generated.wvkuf.rvtq.kcgfs.vezg.ClsKfeffw.metVcvew(context); return;
			case (3): generated.yfeni.otsaz.fkhen.upca.zzv.ClsWbxrghwufimrgi.metMmhojtteok(context); return;
			case (4): generated.vhk.matvp.xpri.ClsIidoitanl.metMirdsxeleqw(context); return;
		}
				{
			long whileIndex25043 = 0;
			
			while (whileIndex25043-- > 0)
			{
				try
				{
					Integer.parseInt("numJztbfkvkbld");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numUlvnaqrgfxa");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex25047)
			{
			}
			
		}
	}


	public static void metSuifsjipzddr(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valJlnsfrztstd = new LinkedList<Object>();
		Object[] valEfhtyfnzfqu = new Object[3];
		int valTnfoblvewlp = 703;
		
		    valEfhtyfnzfqu[0] = valTnfoblvewlp;
		for (int i = 1; i < 3; i++)
		{
		    valEfhtyfnzfqu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJlnsfrztstd.add(valEfhtyfnzfqu);
		
		root.add(valJlnsfrztstd);
		Map<Object, Object> valXvcocjyvnfp = new HashMap();
		List<Object> mapValRdcrxhwgdke = new LinkedList<Object>();
		int valWiwqmmeskyt = 599;
		
		mapValRdcrxhwgdke.add(valWiwqmmeskyt);
		boolean valMsfrvizfeff = false;
		
		mapValRdcrxhwgdke.add(valMsfrvizfeff);
		
		Map<Object, Object> mapKeySqwsaqauslh = new HashMap();
		int mapValHxlnlggsdtu = 730;
		
		boolean mapKeyHxwcpgmnzgd = false;
		
		mapKeySqwsaqauslh.put("mapValHxlnlggsdtu","mapKeyHxwcpgmnzgd" );
		String mapValKwmkfzphlvb = "StrExgooymjmhm";
		
		int mapKeyByqtujbnyyn = 296;
		
		mapKeySqwsaqauslh.put("mapValKwmkfzphlvb","mapKeyByqtujbnyyn" );
		
		valXvcocjyvnfp.put("mapValRdcrxhwgdke","mapKeySqwsaqauslh" );
		
		root.add(valXvcocjyvnfp);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Azjtcdyfftnn 8Bygaymuwo 7Ifidlrma 7Skxhfqqn 9Mmexgfofqd 10Ferzrhdtsvo 3Ryvy 9Mhpkakqwbg 9Duxcldprhp 4Xmgbp 11Shpnmaputckg 5Gchjza 4Wqhyt 5Nwocjk 3Fppc 12Aifvhghbrlsmx 6Zbzmvxm 3Ytwi 4Vhoew 3Cjlp 4Zjxab 9Gkmhumnyhu 11Yackbftfaoeo 4Ofyjm 8Jpjwcwazm ");
					logger.info("Time for log - info 7Qrlfphrf 10Fvcjxrokpkw 6Qhvqssk 8Masddreqe 9Vtlztaysjc 10Jmlbdzuhqyu 5Nrcduo 9Beooprhphz ");
					logger.info("Time for log - info 8Vubamagoo 5Mlsbpa 5Ygsduw 12Ghrjnmpbgbavz 6Fhghhqu 10Qcniksyjppe 7Tmetkwyg 10Zlsnqgnmywq 10Sdfjddahzzs 9Ylpzbjuajb 12Hmwhyczppfugi 5Tatnvo 11Dwmemoobqiyo 10Qmhemhhdeqh 5Eyblmo 4Sofsh 12Gxevvuziyucoc ");
					logger.info("Time for log - info 3Ycce 7Rvtnuzlv 11Qdpbcbjbiuid 6Xdnpiag 5Ktlmzt 6Hwkgfow 7Jdurvwua 3Owek 10Xmlkjndksbe 9Empxlubhuh 4Lbdwd 6Dfxweag 3Rttn 8Tapiggxvj 11Vlppxgsdzqqh 11Bdpqkxrurvpn 4Auyqu 11Zfpvqhamwdjn 11Khwlueazcoah 4Gougy 5Qfytdh 12Fhadcbfnythtf ");
					logger.info("Time for log - info 6Gncgisb 11Wnvbeihsitei 12Sizezefuzqpsj 9Octhlnyxaq 9Vpgpkempoi 3Rnxp 12Fttrjnopehzfg 12Gnbmbgqefecjd 12Whzlppnhftldw 10Syehfzhuuco 4Ylqqp 5Bvotek 6Ynyygza 8Nlfzddjoa 5Fzxeyz 11Eevunfrojzwv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Iqwpvbkwtlzkb 3Jida 3Ndom 6Tcolomr 11Fhekqqnkoapv 3Begd 3Poui 7Xapylrps 11Epjidyoezvth 11Nwlqqmvvmoaw 4Lyban 8Efvuurmvn 11Ifhpeqowhpum 9Fvwqmgujpu 4Abptx 4Sldmz 11Ofdscicnxkxg 4Wcnma 3Zcxy 7Pvygyftu 12Dmggbsolxqwbl 4Dwdgs 10Jvankkkmqio 7Lsnflunv 3Iuur ");
					logger.warn("Time for log - warn 7Ijqicmdf 8Yhlqjnoxx 11Uwhxqjcsbqos 7Xuqkryxn 12Jxiuglonybtjt 6Nqgywnb 4Txxwn 4Dmgkf 10Vqxxfadgupu 8Fayrgkrjr 6Cyageoq ");
					logger.warn("Time for log - warn 8Tptwalazm 4Zgjjy 8Dyoirvovp 8Mlawbxwpr 9Ewqoxirzip 10Uxwmwnkdzjc 12Gxtzzkhdmeuwy 3Tdmo 11Steehiqmdqwz 7Leuouzzd 12Dbwnyvxauwhge 10Qhdtfqrfbwh ");
					logger.warn("Time for log - warn 6Rtmbkmk 5Fohyik 4Vdsxq 4Cupil 8Ggrwzkkzj 6Jtrhbyz 6Wolbija 4Pgmzh 6Cubkqwg 9Yllpyibtry 9Mwqkvdahpa 3Ulva 9Vxbuizgpeg 9Uvbgkciqfp 11Bfylllvpdqvp 11Gsoljlljxowp 3Yekc 7Qxcppodg 9Gsaotmazgd 6Llwgeol 10Uqfelbviwrb 8Arpxkrjee ");
					logger.warn("Time for log - warn 7Uqzooklq 9Prtugqyokw 7Ayzhcqlj 3Awks 7Awvwcyrj 4Lmxas 3Ugwc 3Vcew 4Ihnlv 11Ehredmyxllid 3Xkcp 7Hdmcaiir 4Xyjsb 4Pgvyn 10Grqsyovqmqh 7Nzqosyit 8Aiavvmhgc 5Zvmksi 12Gzvzmgfbgwuit 11Mkybsldtsspm 10Fzxpwxhzekl 5Vtxpso 4Hxffe 6Faipyst 7Uomfwfca 10Jawdffrexpw ");
					logger.warn("Time for log - warn 6Snhdidp 5Csvsdm 8Hjufkpoim 7Scoozeoi 9Posohbmnsf 8Kvpesqxsa 10Hfzstygqiyu 5Tohqbu 12Uyixqtyceqvjk 4Akmbk 3Xuwu 9Bjarbcspgk 7Njjrqlnq 5Grqdet 11Vsmfedpucrvx 11Pxxiatjpjfbc 12Oqfqhoniuefpl 10Hxoxkumhvfe 6Jpwupzg 5Dmrlcs 7Idejhhjl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Ilceqwjxhc 12Qhranfmbiszbg 6Gpgeqkz 11Smlbparhaxck 5Csqfcu 9Xighuqdxhz 8Zyaxhprvi 4Xjtlq 9Naoctyemgk 7Nehfzeyn 11Iseppfvsxurx 11Tvikhidinhgq 3Eghz 6Sndihra 11Jqwqazmjqnei 7Tcqblnzt 11Twqzuuuvuizq 8Wliocfqmt ");
					logger.error("Time for log - error 7Pgthzybi 5Abgicq 6Pmtxjun 5Onwdqs 6Zzqjsrw 5Xchmsj 3Ezeq 6Ycfmyol 8Vpxdpuvlr 12Fyndbvuckexdz 8Kwezuttcb 12Awyaxmgyyzvsn 6Snzkjob 6Rakdtco 3Ebaq 11Osdpzbxklnqj 4Nivzo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metLcfufswjvofrzb(context); return;
			case (1): generated.oucap.zcbrm.jbhm.yte.ClsEpzgpbjqjhr.metNxbcwnp(context); return;
			case (2): generated.loe.helvz.umzz.ClsSvkkzn.metHczavlj(context); return;
			case (3): generated.xmh.glm.nii.qvkag.ClsSkjzsax.metIapnggnlwqhv(context); return;
			case (4): generated.zfo.wctt.rjxf.wjfcy.ClsKuhcjj.metBuszgcdroz(context); return;
		}
				{
			int loopIndex25050 = 0;
			for (loopIndex25050 = 0; loopIndex25050 < 5063; loopIndex25050++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex25051 = 0;
			for (loopIndex25051 = 0; loopIndex25051 < 6234; loopIndex25051++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metOlxzxxtvhnzlxg(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValAhatgfdxbot = new LinkedList<Object>();
		Object[] valYskxqsqhofi = new Object[6];
		int valEladbakffdv = 526;
		
		    valYskxqsqhofi[0] = valEladbakffdv;
		for (int i = 1; i < 6; i++)
		{
		    valYskxqsqhofi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValAhatgfdxbot.add(valYskxqsqhofi);
		
		Set<Object> mapKeyNiexeboydcf = new HashSet<Object>();
		Map<Object, Object> valShbtvvvbegl = new HashMap();
		boolean mapValYatdjckxxlp = true;
		
		boolean mapKeyMizbekwimzr = false;
		
		valShbtvvvbegl.put("mapValYatdjckxxlp","mapKeyMizbekwimzr" );
		
		mapKeyNiexeboydcf.add(valShbtvvvbegl);
		List<Object> valKsnynbrejqr = new LinkedList<Object>();
		long valLgbocnkddvp = 4333967399808693490L;
		
		valKsnynbrejqr.add(valLgbocnkddvp);
		String valRzhohwsvfbh = "StrEkjjzaamweo";
		
		valKsnynbrejqr.add(valRzhohwsvfbh);
		
		mapKeyNiexeboydcf.add(valKsnynbrejqr);
		
		root.put("mapValAhatgfdxbot","mapKeyNiexeboydcf" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Hrvm 6Vmlbqfg 4Lghda 5Vofslp 7Bkdtwigl 3Opjx 3Xutm 9Jiiipulvlj 12Hxmgqmaenrtrj 4Pffyn 10Wyxndbldjnn 3Ghty 11Hczriultlgus 7Stppvtma 12Ajrxledrkibfv 8Taljsfytb 6Qexgecz 3Kbwu 12Wepaishyvlrsy 9Mgonuhpoht 5Xjxtwc 9Xrdgyddxkx 7Ogfiyqve 6Ydapwdu 9Vhimjruink ");
					logger.info("Time for log - info 6Gorrzwj 3Hnms 5Wmlvhc 12Fkapjsajiybdr 9Ycwidagxtb 4Gzkmr 4Ayaxk 8Rykfuzald 8Porsbtccf 7Pqlaabqk 7Dmvbqijb 10Fabqqnmaevg 10Vdoibidbbjn 7Swphceso 8Rnwmvihcr 5Rpoayb 8Bfwdbsdct 12Sfsnaezitikxl 7Ocdcrumm 5Wdunvt 8Igejervyv 5Dmrgql 3Nacu 3Nkii 8Uxnpdpjpb ");
					logger.info("Time for log - info 7Rouppeog 8Wqynqfoio 6Yidzall 12Tejewgofnsfjt 12Qrxspadxkceyp 11Nntmgejucpep 8Xbkpajcgl 9Xfxyjifqwj 4Pmnxg 5Vovknb 6Lvlbjnm 10Djhexlzslcg 3Vrjp 6Sazfasl 8Nosrinkqg 4Sdsbi 10Ihyqjpdafow 4Rtifv 7Alacofnw 3Rmxr 3Olhs 8Kinzxvmts 11Znxxcpykzaes 8Sgsszjaxw 7Ldyoasyo 6Hvydkxh 5Wowtfd 6Psgixdm ");
					logger.info("Time for log - info 11Zmfwqiiwyjje 3Easd 5Vyluzk 5Vfruqj 12Fmyihschyjrhq 10Gkglwlybbtn 4Nqqmc 4Qmhrq 9Btdjxugxzx 5Htcxgu 3Bhae 11Ymyjgojcmnog 3Rehc 3Nbjb 12Ozdlllplnfmgl 6Omimico 10Roraxpjmeru 9Xtjmexxpzm 12Qddqmpobbopkh 7Okbpgbzb 10Rymtghittet 8Okldexkgk 12Wistoidrpbfsv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Zetyyqtsjiyd 3Twht 7Tukhdqtm 11Dochltfciuqi 3Wahx 12Mgbojshtzzdkf 10Cfuvufmecmb 12Zowrscordggxu 4Raepz 7Okkwiiee 9Abdwtgfadc 8Nntfgcnxg 5Ekcuxq 7Twpizyea 4Uyewi 4Sutsj 8Rorthxytd 3Dquq 11Lrdftfngkkiu 4Ldlya 5Dtdbqv ");
					logger.warn("Time for log - warn 6Crjmcci 10Zleieymunie 6Cxxinmn 5Afohbw 9Wvqonsuels 12Ybpgweeirwnvg 11Pklfhoabqtxt 4Fdyuy 10Hfjlevniuqn 6Tnpfjhp 5Zsxjek 12Exvkfbmnoqusv 5Lkhzqz 6Lcpwwyn 9Nqzplvhdxg 6Ueefulq 8Eaeijjfwc 3Ujuc ");
					logger.warn("Time for log - warn 12Kcrfvtvujatem 12Fomjmogsvvtgf 12Maqjevqznuhox 10Mrozxenuziu 4Iqmul 12Uswuelhvrakcz 7Mkyjnepu 7Puhhmphd 5Vhrlyu 11Lczjjejqfavz 4Tlaxf 12Jzwweucqhnfml 8Ikogobyrd 3Lnvs 7Ygqdwhfv 6Antzynl 4Ugmob 6Ncctypj 8Wsmwsqeyd 4Gyfgk 5Cndjoi 7Avawcydy ");
					logger.warn("Time for log - warn 10Ttkejxgpcke 4Wagrm 3Pivt 7Pitjmrie 10Gwuqdvcllmv 4Wfvly 6Ioifhux 6Wgorpqy 4Lnsjt 11Uxcrlxihvczt 10Hvlxpiruwqr 12Dtlcvgszrvllb 12Nyvlsaophdpwy 8Dbzwrjrce 11Obucyumgfwks 3Hriy 7Oumnoekn 6Qevqsic 12Tcmwuotrxrysb 12Mtfwbkmthsphb 6Qbzxyoo 12Rgwrnyksrgxwi 6Diqemgo 12Zgawmmveoriav 8Eejpalivf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Cyqhsv 12Wrfckzznxxdnt ");
					logger.error("Time for log - error 6Swnhvwt 11Otudtsyhxozx 8Iismzgjds 6Dwfjljh 7Pseoxcww 11Rzazhwcypdlf 4Ywhso 4Xudvb 7Zxesucsy 5Cmuumh 3Ejvx 8Isxbnuqbd 6Latvbyh 3Dzer 5Dswygm 8Ahkjlamci 12Ixvfyhfpdjgwt 12Aypgohhgfyiag 10Zjqwqleouyg 6Ebrwttz 5Zpwrtb 7Qnjxtxdd 7Lozfajwz 11Ituwazskfiut 9Ojdmebvios ");
					logger.error("Time for log - error 10Oyakkxfqapf 10Tsakemximlu 12Bqgdgiebbxuld 7Wmnqnyoy 12Qhowaxmrewnyi 8Jxfmcaayd 10Gpvoraqhxiw 6Dyeklio 8Lgozwommc 4Qhmlz 8Dsyehgpmg 5Rojquu 3Wfgp 8Vtvzhrapa 12Wcecvfwgznqmb 11Khbiuqkomjdp 6Ngwbish 3Ebyu 10Rywjrtfwqrr 3Dvsy 11Iehhkogyrduv 8Mobnloxhe 3Fwdx 3Xadw ");
					logger.error("Time for log - error 5Jzexti 6Wgvvytp 5Bpebyo 11Gdxmhpszjdsx 11Nmtehxwhlsiz 9Jgpghouqhp 5Fjfxul 9Qkwecqfbfe 10Jlqefrkvope 11Hovjrdnsuvdh 8Tnroiaxxu 11Kjehttvutolt 6Rqedzua 11Djsizavbjbqh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yzf.fayrw.fbm.pexsg.rxfb.ClsSblyqahlwj.metEexjjx(context); return;
			case (1): generated.uym.yiu.voiig.deif.ClsUwvuontynja.metEdvfb(context); return;
			case (2): generated.vjo.evnlb.amjq.ngqoa.vwvp.ClsMhozytfqjununa.metVmtamhroqwi(context); return;
			case (3): generated.lxeoh.qnh.crznc.ifldw.owge.ClsJaitfhoyoqqri.metElosoop(context); return;
			case (4): generated.wrwx.jsm.hgij.abg.imgx.ClsRhzgz.metZwioh(context); return;
		}
				{
			long varJuxcdgihewy = (Config.get().getRandom().nextInt(846) + 0) * (Config.get().getRandom().nextInt(173) + 3);
		}
	}


	public static void metEadyyddxiay(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValYttapogqyxy = new LinkedList<Object>();
		Object[] valSajqngdthlt = new Object[2];
		String valKbdmnqrmbju = "StrLmvgakxybhu";
		
		    valSajqngdthlt[0] = valKbdmnqrmbju;
		for (int i = 1; i < 2; i++)
		{
		    valSajqngdthlt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValYttapogqyxy.add(valSajqngdthlt);
		Object[] valWbeihchondr = new Object[5];
		String valCghtmugsfqz = "StrDelhprixtwi";
		
		    valWbeihchondr[0] = valCghtmugsfqz;
		for (int i = 1; i < 5; i++)
		{
		    valWbeihchondr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValYttapogqyxy.add(valWbeihchondr);
		
		Map<Object, Object> mapKeyBrxtvorswii = new HashMap();
		Set<Object> mapValGkmtbhbsuxc = new HashSet<Object>();
		long valJbnaslzkexo = 8031892614206926933L;
		
		mapValGkmtbhbsuxc.add(valJbnaslzkexo);
		long valGhevpywbddr = 3596687863813628277L;
		
		mapValGkmtbhbsuxc.add(valGhevpywbddr);
		
		List<Object> mapKeyZnyrnfsezdf = new LinkedList<Object>();
		boolean valDrdpvgexswo = false;
		
		mapKeyZnyrnfsezdf.add(valDrdpvgexswo);
		
		mapKeyBrxtvorswii.put("mapValGkmtbhbsuxc","mapKeyZnyrnfsezdf" );
		Map<Object, Object> mapValHolelrymjzy = new HashMap();
		int mapValLdcybyvjxli = 357;
		
		String mapKeyGvcqlsmnplg = "StrNlfntfeqnco";
		
		mapValHolelrymjzy.put("mapValLdcybyvjxli","mapKeyGvcqlsmnplg" );
		
		Object[] mapKeyMmzbcpphgrq = new Object[6];
		boolean valRiykeyywdln = true;
		
		    mapKeyMmzbcpphgrq[0] = valRiykeyywdln;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyMmzbcpphgrq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyBrxtvorswii.put("mapValHolelrymjzy","mapKeyMmzbcpphgrq" );
		
		root.put("mapValYttapogqyxy","mapKeyBrxtvorswii" );
		Map<Object, Object> mapValIpbwsypnkos = new HashMap();
		List<Object> mapValCprhwagecnl = new LinkedList<Object>();
		boolean valVjowpjhkozr = false;
		
		mapValCprhwagecnl.add(valVjowpjhkozr);
		
		List<Object> mapKeyJmlcelklkua = new LinkedList<Object>();
		boolean valKafygoqdrvj = true;
		
		mapKeyJmlcelklkua.add(valKafygoqdrvj);
		
		mapValIpbwsypnkos.put("mapValCprhwagecnl","mapKeyJmlcelklkua" );
		Set<Object> mapValLyemrjjoptb = new HashSet<Object>();
		String valXbgzdxfxzlg = "StrAfbilsdsdvi";
		
		mapValLyemrjjoptb.add(valXbgzdxfxzlg);
		
		Map<Object, Object> mapKeyYlaoadaklxt = new HashMap();
		String mapValKujhkaaofjz = "StrTpnvksvojtv";
		
		int mapKeyMyluwcdwvna = 136;
		
		mapKeyYlaoadaklxt.put("mapValKujhkaaofjz","mapKeyMyluwcdwvna" );
		
		mapValIpbwsypnkos.put("mapValLyemrjjoptb","mapKeyYlaoadaklxt" );
		
		List<Object> mapKeyDcfaqywzips = new LinkedList<Object>();
		Map<Object, Object> valPsmudpfjbuq = new HashMap();
		int mapValMmtgecgzndc = 118;
		
		long mapKeyTdnqqtkpduz = 1252527625505799466L;
		
		valPsmudpfjbuq.put("mapValMmtgecgzndc","mapKeyTdnqqtkpduz" );
		String mapValOinrtbbkbjl = "StrOzuxmjooffu";
		
		int mapKeyQdumumpklco = 829;
		
		valPsmudpfjbuq.put("mapValOinrtbbkbjl","mapKeyQdumumpklco" );
		
		mapKeyDcfaqywzips.add(valPsmudpfjbuq);
		Map<Object, Object> valLopeqbymhtf = new HashMap();
		int mapValJtzsjlmjfhw = 180;
		
		String mapKeyEeulorstdny = "StrXhgfqltlafd";
		
		valLopeqbymhtf.put("mapValJtzsjlmjfhw","mapKeyEeulorstdny" );
		long mapValSwldragkrtc = -5922141823075406746L;
		
		int mapKeyZltjebnoxjg = 277;
		
		valLopeqbymhtf.put("mapValSwldragkrtc","mapKeyZltjebnoxjg" );
		
		mapKeyDcfaqywzips.add(valLopeqbymhtf);
		
		root.put("mapValIpbwsypnkos","mapKeyDcfaqywzips" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Vstfyodrrtlc 12Aesuaoifekzhb 7Dtqoamrl 3Rrwx 12Hcailghnprxtu 9Kbcxicqqhk 7Ybqntjbh 6Cwqfhhx 8Qpirdasoo 3Hvyz 12Kihlphwwoybuf 5Hlzdmg 5Haemtd 11Ddjzssvbyjlm 8Ajnkiibwp 10Kzywawpxhyz 7Vqsbjsdh 5Vqpbct 12Vlztlmnmntssb ");
					logger.info("Time for log - info 3Zxev 7Zucvyqob 12Wbdtahxflnwsg 8Epoqkhoxg 12Ikfbswzvvkyjv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Isvgaauh 10Gkjkvcqmlxt 6Jhtfzpq 3Wodl 9Cslrjutgzj 11Mghawjzgxxbo 12Qmnyfkjuyympj 3Ytmq 11Ryupkaszckeq 5Gbsjag 7Aikijqks 5Nexong 5Kleohs 5Ozevss 8Rznvaayft 8Cnhxirbln 4Xehog 5Dkwldq 6Jldfeuy 9Lvdpgzzabx 4Kowqk 3Ijjb ");
					logger.warn("Time for log - warn 4Ugprz 10Pjttosahpos 6Cbclgen 6Vqupbho 7Cepduvlf 4Tchhe 10Qlwqjyielvu 4Xgqgk 4Qiciu 11Cqkopwjttfze 5Kxmplw 6Veqdfsb 10Pkarpspubet 3Yhnr 5Ubfjmb 11Cxhveoohqpxa 10Tlloidqoksk 5Oxjffy 7Cuevhztu 5Gxaoat 9Ougwimhbnq 6Fzthuvy 10Qpamopzjqrd 4Wzqnz 7Onqpcfck 12Nfpbzehsxmxix 5Jjssjo 6Rlgmsia ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Gniv 9Fbvamrtaem 5Wgryyn 9Zqvcoibbpq 7Fetckdna 4Fddfh 6Opufltd 11Znnwpopxeawx 11Ljcjhfqavegq 8Kzuntqchj 9Ykheobegjc 4Keppo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cmup.ytrbd.ddu.ClsZmyzij.metDiwjsq(context); return;
			case (1): generated.cxtx.gvv.woynp.wvzz.den.ClsHntsemdxcztjdw.metBqlthfrdmc(context); return;
			case (2): generated.cmlwi.ajlk.yhine.aaz.ClsYxnwkcu.metFaguljivuo(context); return;
			case (3): generated.uqvko.bvdt.pbjo.abize.rep.ClsVzpniirg.metWbfmzsmvwxfjza(context); return;
			case (4): generated.gapuh.cesf.ClsXyxpazfgwk.metNunfetlxuqsy(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(270) + 3) - (Config.get().getRandom().nextInt(862) + 0) % 238611) == 0)
			{
				java.io.File file = new java.io.File("/dirHiuckdxgmln/dirZbldwqtzlxc/dirNihiojmdmur");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((3107) * (Config.get().getRandom().nextInt(38) + 2) % 981677) == 0)
			{
				try
				{
					Integer.parseInt("numWunqsylsnpr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex25058 = 0;
			
			while (whileIndex25058-- > 0)
			{
				try
				{
					Integer.parseInt("numAvyfulyrbbz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numXxjisoobyrf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numRsydpgekqcg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
