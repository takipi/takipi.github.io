package generated.tzk.wxrm.bwm.qkv;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsTeonxo
{
	 public static final int classId = 367;
	 static final Logger logger = LoggerFactory.getLogger(ClsTeonxo.class);

	public static void metQpntvyruck(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValVqanunkbyna = new HashMap();
		List<Object> mapValBkewbvhxost = new LinkedList<Object>();
		long valZpsakqfztkt = -4036748284642986159L;
		
		mapValBkewbvhxost.add(valZpsakqfztkt);
		
		List<Object> mapKeySayiowntuif = new LinkedList<Object>();
		boolean valAlwftzvkcqa = true;
		
		mapKeySayiowntuif.add(valAlwftzvkcqa);
		long valIdvuhyjftcn = -3142044956249379800L;
		
		mapKeySayiowntuif.add(valIdvuhyjftcn);
		
		mapValVqanunkbyna.put("mapValBkewbvhxost","mapKeySayiowntuif" );
		
		Set<Object> mapKeyKgghsapgkix = new HashSet<Object>();
		Set<Object> valZaecapgkisp = new HashSet<Object>();
		int valBositykrmyq = 96;
		
		valZaecapgkisp.add(valBositykrmyq);
		
		mapKeyKgghsapgkix.add(valZaecapgkisp);
		Object[] valAprjdtxlerp = new Object[4];
		boolean valYlyyqwchnri = false;
		
		    valAprjdtxlerp[0] = valYlyyqwchnri;
		for (int i = 1; i < 4; i++)
		{
		    valAprjdtxlerp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyKgghsapgkix.add(valAprjdtxlerp);
		
		root.put("mapValVqanunkbyna","mapKeyKgghsapgkix" );
		List<Object> mapValBtgqasdqqri = new LinkedList<Object>();
		Set<Object> valKfyvvyzxtrt = new HashSet<Object>();
		String valMxcadtzeqxb = "StrClxncpzvevv";
		
		valKfyvvyzxtrt.add(valMxcadtzeqxb);
		
		mapValBtgqasdqqri.add(valKfyvvyzxtrt);
		Map<Object, Object> valJmpczckeupc = new HashMap();
		boolean mapValAgcavleqavz = false;
		
		long mapKeyKmlseifciqh = 891852732001060807L;
		
		valJmpczckeupc.put("mapValAgcavleqavz","mapKeyKmlseifciqh" );
		
		mapValBtgqasdqqri.add(valJmpczckeupc);
		
		Map<Object, Object> mapKeyOjbgbglnttl = new HashMap();
		Map<Object, Object> mapValQwqbhmaklzo = new HashMap();
		String mapValScjdlhbeehv = "StrYoesgpqkhpc";
		
		int mapKeyArttcloihui = 569;
		
		mapValQwqbhmaklzo.put("mapValScjdlhbeehv","mapKeyArttcloihui" );
		long mapValOhfedigouxy = 2945375199942731421L;
		
		int mapKeyBlyrcsclcyh = 978;
		
		mapValQwqbhmaklzo.put("mapValOhfedigouxy","mapKeyBlyrcsclcyh" );
		
		Object[] mapKeyVfchvsbfder = new Object[3];
		String valNywrbmxnnhg = "StrCbdjdamgzax";
		
		    mapKeyVfchvsbfder[0] = valNywrbmxnnhg;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyVfchvsbfder[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyOjbgbglnttl.put("mapValQwqbhmaklzo","mapKeyVfchvsbfder" );
		Set<Object> mapValCgoesubsomi = new HashSet<Object>();
		String valGvuxdoxylnz = "StrUwzthojghvr";
		
		mapValCgoesubsomi.add(valGvuxdoxylnz);
		int valIwtprnfunhb = 399;
		
		mapValCgoesubsomi.add(valIwtprnfunhb);
		
		Set<Object> mapKeyXhabitjwfkk = new HashSet<Object>();
		int valVbpcnvyscgc = 338;
		
		mapKeyXhabitjwfkk.add(valVbpcnvyscgc);
		String valLnbbxqdkmen = "StrHbjrrypnjex";
		
		mapKeyXhabitjwfkk.add(valLnbbxqdkmen);
		
		mapKeyOjbgbglnttl.put("mapValCgoesubsomi","mapKeyXhabitjwfkk" );
		
		root.put("mapValBtgqasdqqri","mapKeyOjbgbglnttl" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Bgvxwfpujt 10Eltoysnslij 11Cgwgugbyqvwa 6Gesusxw 3Okof 10Xwpdnwuvsfx 11Vwmzwdylgafg 11Tgadloyibupf 9Wdzykuqsnz 12Sgpgkatqpkmup 5Ahjgwm 4Xfyyt 6Pgsqvts 9Cgcicquzic ");
					logger.info("Time for log - info 9Mfifcjwpew 10Ckwlykyypxg 10Kwhjyrrmnvv 6Fbglane 6Ziszagp 10Wcwzeonsydi 11Ouomjqrvnwfw 10Wshjcbbklve 3Vojr 3Xeuo 8Hvgesaelw 12Iixyuopuuynkx 7Lilsobbu ");
					logger.info("Time for log - info 11Rcufhyxaffpm 9Ngklobkfes 6Udxteit 11Oixfvoypoksb 12Sfclwvkymquth 7Ixtmbvlz ");
					logger.info("Time for log - info 7Zrahhxss 12Grmagizxcuzki 4Wguik 3Gwgn 8Ydasqaghz 12Cnhsnyigmmrkl 10Ztkauhfyeek 11Jqgwgcjpvldn 6Tqrhyxz 7Thjbzuip 8Xlxwrlrum 7Ijgqmrqa 8Gxcloqfnj ");
					logger.info("Time for log - info 3Ffvy 5Akwkhl 9Ibviwuclua 9Igjtcbuuzp 7Qavxyotc 8Ojliskcpe 5Gzpego 8Wlqyzyvia 12Cgivmxyoiqugx 11Clvxijmfmudk 12Krgrfsdleesvp 11Dweljydakswd 9Jwqjiwltkd 11Dhulfkfimkdl 9Mfxaviumnp 9Nlqoxmorkk 12Kanngjhrhrmyn 7Ifobkarw 4Gxiez 5Xpzgrc 11Dpbgvsukgxsb 10Tsdrevgsrsz 9Qgotrxiyzv 4Elxxc 8Acxplcjlu 7Htplhjsg 8Rwamxmezl 11Ftdsyywjpgrf 8Njqgzawfd ");
					logger.info("Time for log - info 7Fkhyclhr 6Anmfziq 3Yodn 3Pxdl 4Lkgaq 12Xetkvdumppijo 7Yymvcflv 11Yylpcjxixipb 10Fsqrzjjixzx 7Lpczvaud 4Qnnjz 7Iedettnd 8Aagsmqxcn 3Bqxd 7Cirrfiex 11Cpjztqmcmjaf 3Vmim 10Aemgrjbpyrx 8Fmaqoefan 7Iohympjg 5Chvvye ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Ijux 10Djyawdvmdao 11Vmqklkiynprq 4Cccrs 11Nmglvhdvhesr 10Dxyucjrerdb 8Asszpzwoj 6Bgauvoq 12Tsqkuglwcrowz 8Vxanjskvr 10Nplambtznlu 12Nqmgffwehqcuk 6Vmbdfht 7Slzoswpi 9Imdeodnpve 6Cnxwajs 3Gubi 5Vhszba 11Ctmxmhyxmtcg 12Dlmxtsgxexutq 10Cvtprocppby 11Cdqaqngzvfim 9Civqtkqibb 11Cxzusvermlrw 12Hzausidlnulsx 3Hvnu 4Glwqy 10Qdfwszumyhi ");
					logger.warn("Time for log - warn 4Pnhfv 4Uexny 7Agzzluzh 9Uykmqwedbb 8Brzitprsi 6Hhdqiqa 9Kxeljztikk 6Qomwapk 7Bxikvqxm 9Hfcwsbtnkd 5Hfrdhg 12Qpwnrmfqpjigv 8Goctflzdp 6Fsrnjau 6Nmlcbyv 8Rdiauwjyy 8Qlzwpmbik ");
					logger.warn("Time for log - warn 11Mishbeqhuhtd 3Dxlr 7Ixzgzaxh 7Zucgvjbi 10Brkmveshzkg 6Qslexsf 4Deatb 12Bvtxyjkyqfyvl 4Wtvbj 3Kqoz 11Lygffouyntpa ");
					logger.warn("Time for log - warn 8Mhcrmdwkm 4Rcjyl 12Hopsvdsrjtneq 6Jcluiuv 4Xtgjy 10Yvfmslmxkpg 9Nllidymmni ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Aqrkjglij 6Fonccvp 9Kctqombbgb 11Fuhzhtjpzwlq 11Dwsmdgmytmzx 12Uuixldabvzeux 7Wrnzterb 3Jhvc 7Pnmsasyp 12Wkbslutbywntt 11Ihpshdhlznxs 5Rjekkh 8Okvzfsbll 8Xfmknjlwm 6Dqfrwsa 12Gwfpjpbrqnzjl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.phtjf.bzplf.izqn.pznr.nxe.ClsUtlzborau.metFkmmdnkjyn(context); return;
			case (1): generated.fpa.lsm.ClsOulug.metRvwreotu(context); return;
			case (2): generated.rub.wtuur.cpewn.fdq.jektc.ClsLiscwkily.metAyhva(context); return;
			case (3): generated.xnl.gdx.dmkh.hpyan.ClsNxgzyqd.metRbhfzkkxtnc(context); return;
			case (4): generated.tzk.wxrm.bwm.qkv.ClsTeonxo.metXcoghnr(context); return;
		}
				{
			if (((831) - (Config.get().getRandom().nextInt(562) + 8) % 935152) == 0)
			{
				try
				{
					Integer.parseInt("numGjsberpqrht");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirNplirvcbbdk/dirBtvruprsbsb/dirFlliivqzkrv/dirMvryznpwsmw/dirVilosjyrfuu/dirVhavehzkmxm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex26167 = 0;
			for (loopIndex26167 = 0; loopIndex26167 < 2705; loopIndex26167++)
			{
				try
				{
					Integer.parseInt("numNyucnwjgujn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metXcoghnr(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[7];
		List<Object> valJnuwfosbnkt = new LinkedList<Object>();
		Object[] valUkigcaaxxds = new Object[9];
		boolean valZqxehjgkgsk = false;
		
		    valUkigcaaxxds[0] = valZqxehjgkgsk;
		for (int i = 1; i < 9; i++)
		{
		    valUkigcaaxxds[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJnuwfosbnkt.add(valUkigcaaxxds);
		Set<Object> valXltqyagskdz = new HashSet<Object>();
		int valOwpxglfqlre = 818;
		
		valXltqyagskdz.add(valOwpxglfqlre);
		
		valJnuwfosbnkt.add(valXltqyagskdz);
		
		    root[0] = valJnuwfosbnkt;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Vcwljmhq 7Esjbsvke 9Ajfkraphuv 8Pzmizcnii 11Kvonpbdbwlfg 10Kgubdrigkdi 10Cajdneayftv 7Gjxxdink 9Ndrcrtvqft 10Hgofkevkrwv 6Cxpbrbq 7Wiszwekh ");
					logger.info("Time for log - info 9Fkrmjudcdo 4Oeycl 8Bogqgicxc 3Phog 10Biiylahveml 8Qpplwjcoz 4Cribd 8Hvedhgpfn 11Nmzpmoydjywi 10Zzyvtnohlpw 7Ixkffblg 10Afyomvneheq 5Mqpiyr 5Bqgbcx 10Gpzcjqiavkj 3Sbax 7Ibvmklcw 7Xnovvqtg 12Hwhsidfrbhtft 6Hjyhakf 12Lnjmhtjwqeznt 3Zmsi 3Ajsr 6Yqaikqj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Obbgd 7Obhseqab 7Zktiqgky 12Zgsygraxjrlpe 4Ayvyw 10Vzhkzjilyda 9Xwsucsvzkl 4Qbajb 3Mhgx 12Pcwpsmnshhucq 5Lflxsj 12Yqkfehrqypkzd 6Duqndfv 8Rseqmskwh 3Rtcb 8Iflurnubp 9Jakgfxjnlg 4Qhrxm 3Mmjb 8Pnkvckaxh 10Tywywcjdoof 3Yfig ");
					logger.warn("Time for log - warn 6Vxdzbqn 3Ehco 3Tkei 7Fagbtgsc 3Nzoe 12Xtyfrsdkkwjrw 10Ehafytxxxdp 11Rnxqwoundeuy 11Uxqxbkbudweo 12Amiorknwyzjbv 12Qwkqybmuedgyp 10Cslpycdvliq 12Appwdwusgewah 3Akxp 7Bjiimxck 3Btjs 9Cyaojjhnth 4Bsehg 9Riuqkjkykq ");
					logger.warn("Time for log - warn 4Gydzd 12Kueuyqokbrxph 5Sxunbe 6Faudubu 6Cittwrm 8Hfgsuhwhh 3Cdsh 6Tnmgtpl 3Alwn 9Vetyustfud 10Ciytwsyemca 11Lzhsmdjezxks 6Gzpvjio 4Gytbw 7Sjszyrbe 6Eivsgcn 4Lxiha 9Ssancrwcsv 4Yicrd 10Zcyiuusduld 3Zjce 6Zxaxwru 4Sbnzg 5Deycax 11Yanvyysvdahh 4Sviyn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ydzsq.oryaq.elxyy.ClsOrteugmzafy.metMvpbi(context); return;
			case (1): generated.tuih.veohx.ClsLezjqptgnoj.metYotukfqbpk(context); return;
			case (2): generated.owqo.mlfkn.xvo.nivs.zcmac.ClsNuoghbmezp.metLndbwkmjawsc(context); return;
			case (3): generated.qspb.cjle.nfu.jdnb.hwx.ClsNgqnidoia.metUiocavtovwi(context); return;
			case (4): generated.hbqjp.kifli.leg.jlyd.ClsYgtwztbknhdmc.metHsrmkfyvnv(context); return;
		}
				{
			long varNdikcjiizag = (Config.get().getRandom().nextInt(677) + 2) * (Config.get().getRandom().nextInt(201) + 2);
			if (((varNdikcjiizag) % 727082) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
