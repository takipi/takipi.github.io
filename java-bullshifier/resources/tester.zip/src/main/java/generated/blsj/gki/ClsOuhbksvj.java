package generated.blsj.gki;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsOuhbksvj
{
	 public static final int classId = 128;
	 static final Logger logger = LoggerFactory.getLogger(ClsOuhbksvj.class);

	public static void metOmfsztvrsb(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valUjdamjdwvhn = new LinkedList<Object>();
		Object[] valEbbvakhxlju = new Object[11];
		boolean valCeuhjwrhhxx = false;
		
		    valEbbvakhxlju[0] = valCeuhjwrhhxx;
		for (int i = 1; i < 11; i++)
		{
		    valEbbvakhxlju[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valUjdamjdwvhn.add(valEbbvakhxlju);
		
		root.add(valUjdamjdwvhn);
		Map<Object, Object> valGvvinckjoiq = new HashMap();
		Object[] mapValVoadtbkynss = new Object[3];
		long valZzgnwfmluqv = 2149988916665311245L;
		
		    mapValVoadtbkynss[0] = valZzgnwfmluqv;
		for (int i = 1; i < 3; i++)
		{
		    mapValVoadtbkynss[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyAqhtkogwens = new HashMap();
		String mapValMburpfatvvx = "StrOssxojbjyzj";
		
		String mapKeyUscnojhvypa = "StrWtqrxnatwfe";
		
		mapKeyAqhtkogwens.put("mapValMburpfatvvx","mapKeyUscnojhvypa" );
		
		valGvvinckjoiq.put("mapValVoadtbkynss","mapKeyAqhtkogwens" );
		
		root.add(valGvvinckjoiq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Fcnteuks 11Tgatltwjksjk 8Bmewdgjcq 8Wamxuewng 10Fszspimmysa 5Xfzijn 7Nfgxwarp 6Modmuvr 10Lfcpxmckcjd 12Glpkqcsyrphli 8Htgreiaxi 5Scwkys 6Yflfocl 3Zagv ");
					logger.info("Time for log - info 11Tdopbioywqpa 10Kgmdlqfxzxm 3Tjbd 6Rognuyw 10Qjtmhbptxno 4Ipeyo 5Yrkmnm 4Fnwly 6Qlzqdem 9Lbpltplort 4Lxtpr 11Gkmyzvfujlaq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Qsdoxb 10Awaookpuhru 10Jkyrjrnkqcu 9Yvdaiwuzmh 6Aazvbvp 4Iambj 3Jlgz 11Nojuoifelqxe 8Zmfrpmiol 12Qamelwcmehdds 5Sgkfta 3Rttc 8Kowzthmmx 6Uhbnghq 7Awkemlzx 8Kimmdyalh 8Mxwjdhnmb 11Fwvoiscqxcya 4Natkr ");
					logger.warn("Time for log - warn 12Txikmikkiyqbg 9Vhcjavwbgy 9Bdrixgfsua 9Koaohpwlgm 10Rrnsobksrzd 10Yextlckwpzk 9Uopvicfamc 5Bwjwxy 8Vljowruwt 7Pqfzmidj ");
					logger.warn("Time for log - warn 6Fwelljx 6Fivbhru 12Prnjxnpdabvjm 11Tjtjlzwmtmvf 7Dxxuajqc 6Znwxkoa 12Rzwtudofkwhdw 3Tsva 5Khigsa 12Ymtdawvznqdfg 6Bbmyesg 11Upcuxpzlpwxq 5Hglyru 12Hkfelnqskpsms 4Loqdh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metOebzatkpa(context); return;
			case (1): generated.udzdg.aoq.runwl.jiwf.ClsBbcobewbgt.metVygkbiannogx(context); return;
			case (2): generated.mzwyl.mypv.ClsZjjiybxk.metXkyprwkbozhl(context); return;
			case (3): generated.rnv.dtvl.uhnk.ClsTzqkdsb.metSeczfqzvcdesmp(context); return;
			case (4): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metUsjlmntvgpvw(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirNlqljsuposb/dirCjwilsmaakr/dirOyiccktcjkl/dirQbiagdfdogf/dirZolpdiaezow/dirChjndlljxgv/dirUvfoklpywrq/dirOxgyvatbpcj/dirDdlzwlzvchv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex22329)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex22326 = 0;
			
			while (whileIndex22326-- > 0)
			{
				try
				{
					Integer.parseInt("numSlyutlphjak");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numCqcevdwccwg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metZabhogiwotxh(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[4];
		List<Object> valAckslaiqqqt = new LinkedList<Object>();
		Object[] valEtdtvcueytg = new Object[11];
		int valGpyggwvwujm = 48;
		
		    valEtdtvcueytg[0] = valGpyggwvwujm;
		for (int i = 1; i < 11; i++)
		{
		    valEtdtvcueytg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valAckslaiqqqt.add(valEtdtvcueytg);
		
		    root[0] = valAckslaiqqqt;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Lisle 5Fusuci 11Kbezrvukvqju 3Soxe 5Umycre 8Uftjuazal 3Kspt 3Brmx 12Uzslfhicfmqkl 5Gnedcj 7Dwuycitp 7Pdtqyjso 9Uxjgcwqjyt 5Bvrdir 6Kptzyre 12Hxflercgipueg 4Eyvap 5Ovsepy ");
					logger.info("Time for log - info 7Hytitauy 3Zhlq 12Evlzbonwcwwtz ");
					logger.info("Time for log - info 5Gtucpy 5Gzwtnz 5Peylwk ");
					logger.info("Time for log - info 9Hcxbeoltrv 6Uyprtqk 8Mozipvivd 12Odtxmzevutepm 8Kkijlqxwk 9Crmlhepmhx ");
					logger.info("Time for log - info 6Mwsgbjy 8Wtgkiyaxx 10Jglozoanzwx 9Fdksbizotb 4Isahh 7Krqehxit 5Gusjhz 11Arljsgembzdr 6Uhwflhz 11Nqifzfiqbyfp 5Mqxwjn ");
					logger.info("Time for log - info 8Htdcdnkpk 10Pzadfxfeawd 10Vxelrhcmjtw 9Tztasefqht 6Znlfper 10Rskleaacmsm 7Qccxpljw 3Uamc 9Sespclxeuj 6Xwzpqpl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Adtb 8Fkiellcpj 11Ypsqbjqrudcr 10Nqecqjhhltz 12Fgkpsdbtoypru 11Zaauuenqxwup 5Oqwhxl 10Esbzbrnbftc 6Awinybm 5Eylbtc 11Geymmrdadkhd 11Tritsvxwncur 4Eoixy 8Lxbgumsvi 3Qkyh 6Ppcnzwz 6Atqlhht 8Kkwrmljbu 9Zeqslmxvih ");
					logger.warn("Time for log - warn 10Lrepwivylty 3Sjzf 5Vezmuk 9Cyvhnbqyhv 8Odhfvfiuv 5Fhvkwq 8Zoagkjqfh 5Gjpayx 4Lnpts 9Wwswszboqp 6Ztpkgdd 3Hliz 8Kxaruhfih 9Cthbscobqi 11Erhrsistmxre 9Buzynsxnle 6Gkyqpna 3Druu 7Ckdisupf 10Xuonulwrkna 10Jzcrwajrnzv 5Zucwgk 4Gjwgm ");
					logger.warn("Time for log - warn 12Joiibqtokyhyj 3Wtxu 10Jjjbeihlluw 5Jtmbwb 4Bfjle 12Prxqwqbeqhpnc 12Kybohtennofdx 7Lymjxeyd 10Zopqdwxpaqw 9Rkyrqbwtpz 12Mnpugsjijqeql 7Pjxnmlob 6Tugeuro 12Hoxuppqserogs 12Etoradqbctrel 8Pzqtiymjn 9Kzcbqbmxvo 4Gmwdx 8Lqsmebzxt 6Rjjiruo 4Gkoug 4Yegws 9Plppyrwujj 12Xvxiclwvkoowd 5Wfynye ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aneiz.novw.ClsBxulfvm.metSgvcxn(context); return;
			case (1): generated.gjcdq.ygxj.ClsOmksrfdawprnyq.metBlrdhncfbkct(context); return;
			case (2): generated.siinn.hrk.mef.ClsDcfbqxc.metVimubl(context); return;
			case (3): generated.juea.qhm.ClsOhhvy.metHndknqq(context); return;
			case (4): generated.wwbmr.iqko.nht.ClsCnzakidxmh.metYvzavpzpnbo(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(701) + 5) % 883286) == 0)
			{
				java.io.File file = new java.io.File("/dirQujvgxcrojy/dirDnrukazffqo/dirThcnvhdrddn/dirBdxnxayzfjh/dirHudzfvtqkko/dirOcipeqbtzbn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numHnesnjjdmiq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metEkzrb(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valXfjuodlvcbo = new HashSet<Object>();
		Map<Object, Object> valVpdppewkomw = new HashMap();
		String mapValUijwrfxmsqe = "StrHuxablnuznf";
		
		boolean mapKeyCrdnokfgkow = false;
		
		valVpdppewkomw.put("mapValUijwrfxmsqe","mapKeyCrdnokfgkow" );
		long mapValMricfqpwecl = 3343587813098195998L;
		
		long mapKeyRmiqgqxeete = 6247203541852545254L;
		
		valVpdppewkomw.put("mapValMricfqpwecl","mapKeyRmiqgqxeete" );
		
		valXfjuodlvcbo.add(valVpdppewkomw);
		Set<Object> valZbciztmmjdb = new HashSet<Object>();
		String valTsjisiwyuvf = "StrLasnkfgromm";
		
		valZbciztmmjdb.add(valTsjisiwyuvf);
		String valRmwxdjszmwh = "StrMrzjfmufnpv";
		
		valZbciztmmjdb.add(valRmwxdjszmwh);
		
		valXfjuodlvcbo.add(valZbciztmmjdb);
		
		root.add(valXfjuodlvcbo);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Wiherrpiyt 12Cqqibiioozkdv 6Iofspfd 8Xofrlgaza 6Frzeazn 12Vdexrksneuhgm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Lgmzdasd 12Llyrhasddintf 11Nficslslarrv 11Fgtyycuucwuv 5Iosfea 9Plgtctdgpd 5Esjssv 12Ffqxquwmkigjs 6Qhutmyg 12Yvyaaupfudeos 12Wihkkqodjyvtu 11Hawibtnrorxo 5Ebijyh 9Jaknktfusx 10Fsfhnewbxvj ");
					logger.warn("Time for log - warn 3Nyiv 3Dmdi 11Urvdbfpilgso 12Nfoztjoihzwiz 9Bloksohshb 6Btmdueq 12Igqghrjghivdm 12Xqjcsnngvypyi 7Sxecktfj 7Jvudkoyw 9Kpyeqtaypg 11Bbzntryqvpbx 12Cvnjnjesraqcp 3Meoc 3Rilr 6Ssdqayg 8Ldvabqrnq 10Teqbetanlqg 5Yudzzk 6Vutjskd 3Auqd 11Xwramgveuvfj 8Vuxkcjoko 6Yebmlyz 7Wuvwkvmj 9Lqvffopyma 4Mkemr 8Gnhdcjuyt 11Namldvadolqe 12Ehuofeixcenem 4Qsavh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Zqnvldbsh 6Lfcmqij 4Rbcsw 10Gpfgpbokwol 5Ysirhi 4Nenni 12Ofdxkmlrokayb ");
					logger.error("Time for log - error 11Cspdlzjkrjal 10Dwhxywuubuu 4Alxzy 6Cmssrin 3Ztjl 7Fdgmfalg 7Hydikcoy 6Owadwle 6Ektuxvc 5Fdnblo 11Dtwxdbddxjuw 12Ugsmfxzuufvtj 3Sbfy 9Wcgrpinvpa 4Isjcz 4Tylqf 3Mzox 11Efajbvjzotrj 6Hmhkgbt 6Bzjusfb 10Qmcoqeycwpe 9Qilqufuhoo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rnivz.zhh.uhei.req.ClsPtwayhomjjn.metIvavionsx(context); return;
			case (1): generated.qnzm.livr.ClsPutzsgygioejxl.metJtxtxkipo(context); return;
			case (2): generated.amxo.ekvdv.ClsShqqngjhvyrxx.metPxdjzije(context); return;
			case (3): generated.kdf.pknx.zlwl.ClsKeeubrxremfhhw.metOxjieq(context); return;
			case (4): generated.spdv.axe.ClsZyjdutdtmcu.metZnyfnrroyfp(context); return;
		}
				{
			long whileIndex22342 = 0;
			
			while (whileIndex22342-- > 0)
			{
				java.io.File file = new java.io.File("/dirJgzgxbbdfof/dirNabukzaxccx/dirKcaytzsaual");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
