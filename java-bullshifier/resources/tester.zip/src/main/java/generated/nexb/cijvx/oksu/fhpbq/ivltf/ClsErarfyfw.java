package generated.nexb.cijvx.oksu.fhpbq.ivltf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsErarfyfw
{
	 public static final int classId = 318;
	 static final Logger logger = LoggerFactory.getLogger(ClsErarfyfw.class);

	public static void metNftve(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValWjfkbmripsq = new HashSet<Object>();
		Set<Object> valWxcrabkpkdt = new HashSet<Object>();
		int valXmvpnbvovsw = 8;
		
		valWxcrabkpkdt.add(valXmvpnbvovsw);
		
		mapValWjfkbmripsq.add(valWxcrabkpkdt);
		
		Set<Object> mapKeyRbtyygddurz = new HashSet<Object>();
		Object[] valIpbtndscbly = new Object[3];
		int valTaufbgdmxbf = 630;
		
		    valIpbtndscbly[0] = valTaufbgdmxbf;
		for (int i = 1; i < 3; i++)
		{
		    valIpbtndscbly[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyRbtyygddurz.add(valIpbtndscbly);
		
		root.put("mapValWjfkbmripsq","mapKeyRbtyygddurz" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Gtglwhf 8Vfxphiojz 9Sxnudxmxam 9Eumbausbqm 7Rpcefkth 10Ejxbawaeeei 5Grcvdm 6Xoxhncc 3Ewqq 12Wszlucfyjksyi 10Sevbhzhyevp 3Ppts 9Hzzsetxrqb 12Tduepuacpixus 5Tjsxvg 10Eilvrvnuaad 4Tioon 3Hxvg 11Lqiesasytkmz 5Tomspb 9Pdygyhcixi 7Dnqzbbdj 5Fxdjwu 3Rttn 4Lunhb 9Zarknyklaw 3Iwwu 8Unekfnjri 4Uxpib 7Tubjvcrb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Oheaoedgsytl 10Ufhvhnpkwei 12Veweqpkcchlot 12Lpikdxrdbkdxp 9Fjzjhpklbl 7Llrglozc 11Hsfpxwqheqqe ");
					logger.error("Time for log - error 12Xrbzpzwfwoygt 8Keranvikz 4Ysctn 10Impuudywdnd 8Xnhjuhuin 8Btjdqotet 7Bbpahabh 9Cdtmpurids 4Cezke 11Bbdkuickazmh 12Vhbangbjmnffz 4Cybxz 3Huxf 9Wemurvhmrf 7Fnxbkzyx 4Gqlyf 9Aijeowaqjr 7Ecwjptpx 3Nzzr 9Kxajhpcfdn 12Efvbxehdsimin 5Lvzycy 11Arsdejjwiqxg 5Zmqwtr 5Vvfjrj 9Iugqxtcpww ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kmtdc.slqlz.nmqcy.naaq.ClsKsliquh.metNmcayldfqz(context); return;
			case (1): generated.zsia.unbq.ozcif.caj.yiysy.ClsRbxlkiybibs.metYfrggz(context); return;
			case (2): generated.bolg.tnlb.nmug.ClsHstaiufsowx.metPapexcx(context); return;
			case (3): generated.nrrh.nxnu.xat.kha.ClsLoiagobs.metImjogkxzrsynw(context); return;
			case (4): generated.xhxl.owx.ClsJgljylyqsyfqzr.metWircnlydewe(context); return;
		}
				{
			long whileIndex25396 = 0;
			
			while (whileIndex25396-- > 0)
			{
				try
				{
					Integer.parseInt("numIviezqaubzo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metMuphdva(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valYtxcoufghcw = new Object[3];
		List<Object> valZrtrzsfmcob = new LinkedList<Object>();
		long valLkbhxbuvojp = 3087086996835784883L;
		
		valZrtrzsfmcob.add(valLkbhxbuvojp);
		
		    valYtxcoufghcw[0] = valZrtrzsfmcob;
		for (int i = 1; i < 3; i++)
		{
		    valYtxcoufghcw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valYtxcoufghcw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Dpsikgbu 3Hcci 12Wnqxpmkwhsefk 10Eernrayfduf 12Bcyjddajwwthm 11Mvzuzgjhdhis 5Nlxgdi 6Kltsknl 11Ukzofshnmpbp 7Tgnmqfof 4Rytbo 6Pfokskh 6Pwggags 4Ydpxo 8Ntikhetmf 10Kghqpbredvm 3Znrn 5Jmoica 4Ooueb 10Fbavnkfjlot 3Rsys 7Cnqeshva 6Ugdgzcs 3Tzok ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Ysrrcekyvrt 5Uprkid 9Qnmaobnjfs 4Ukchh 5Nzlvkt 3Nvvj 6Ikelwai 5Pxpnxh ");
					logger.warn("Time for log - warn 9Xadtacitjd 12Eibifmwfeypjg 4Roohc 3Txrt 3Nfdt 10Nnqmhwgxbww 5Pomgka 8Ivhqzzktq 9Qqbhkpkued 8Eccxvpdmr 4Aebkc 4Fmcsr 7Poayxtql 6Junuwgt 5Vcsmpr 6Fdbvxlw 11Jzsosxyasmwd 6Rgiyphr 7Uzbrbmyi 8Ueujqhczq 11Dllekiqilhgo 5Zqpssv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Boxmj 10Ymondwfxdaj 11Ufjgdrclutta 4Sikba 3Dhcy 7Aeuggcwo 10Pqiwetudkpi 11Kafinkqgsove 5Ditfxt 3Drja 8Wcisojhhe 10Ntvijgcgwln 12Ixdxqcwmrcyqa 11Hpfzjzywetxe ");
					logger.error("Time for log - error 3Yzqk 12Kdwkizhnogbuy 10Ciwaodbpyqb 10Kvbxdfdqaij 9Brhyuacxgm 12Qgtcpcixlqzya 3Pxga ");
					logger.error("Time for log - error 3Mlsr 7Sfvcdnjm 12Vbfvmmzrwizja 5Lnxkob 10Azgvuwbtuni 4Tlcxq 9Ujuyvljjdj 7Gqjrgdob 3Kpcc 5Oawhvn 3Iyux 5Nhkvui 4Zvdif 12Kdkxtdozjqfzc 6Ibakorw 4Suyyg 5Icugtj 10Iohglsuutkk 9Ydaqslftjp 6Ubfdpdj 5Xcatnz 4Vveuo 10Btawajuplea ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.epi.quvm.dwt.ClsQoovjnirkdxzq.metDdmuknlewzs(context); return;
			case (1): generated.bftm.jkb.lcr.ctpvk.ClsYfbhukzct.metRdbrizfs(context); return;
			case (2): generated.bad.yds.jib.otl.ClsBzgol.metOnfznlwhtrhjye(context); return;
			case (3): generated.godw.hlszo.mtqbt.shx.tbgwd.ClsMygvrmsqnwlsdw.metAxjcfalqbdxrb(context); return;
			case (4): generated.ryyqn.hafq.oqfv.ClsRsktinox.metWreewxm(context); return;
		}
				{
			long varUzezovjogdc = (Config.get().getRandom().nextInt(673) + 7) + (Config.get().getRandom().nextInt(568) + 2);
			try
			{
				try
				{
					Integer.parseInt("numHxzrpnesiyp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex25402)
			{
			}
			
		}
	}

}
