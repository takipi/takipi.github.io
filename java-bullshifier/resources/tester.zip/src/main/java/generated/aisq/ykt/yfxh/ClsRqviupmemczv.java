package generated.aisq.ykt.yfxh;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsRqviupmemczv
{
	 public static final int classId = 475;
	 static final Logger logger = LoggerFactory.getLogger(ClsRqviupmemczv.class);

	public static void metFawupdwqkldp(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valWvwqeubswfw = new LinkedList<Object>();
		Map<Object, Object> valBvjmpaibfhr = new HashMap();
		boolean mapValStmmsouegzw = true;
		
		String mapKeyXqqxzercyzu = "StrNdwacwyhbat";
		
		valBvjmpaibfhr.put("mapValStmmsouegzw","mapKeyXqqxzercyzu" );
		
		valWvwqeubswfw.add(valBvjmpaibfhr);
		List<Object> valZbkktmjrlcc = new LinkedList<Object>();
		String valSkavnesqicv = "StrFrxczszezvz";
		
		valZbkktmjrlcc.add(valSkavnesqicv);
		
		valWvwqeubswfw.add(valZbkktmjrlcc);
		
		root.add(valWvwqeubswfw);
		Set<Object> valNltskgasvaa = new HashSet<Object>();
		List<Object> valBmshkfyjkdd = new LinkedList<Object>();
		boolean valPsloixeanhf = true;
		
		valBmshkfyjkdd.add(valPsloixeanhf);
		
		valNltskgasvaa.add(valBmshkfyjkdd);
		Set<Object> valRohrketgwku = new HashSet<Object>();
		long valWopitxzwktb = -1605163788099628064L;
		
		valRohrketgwku.add(valWopitxzwktb);
		String valFxgyhsrssgk = "StrIwpagoghtuv";
		
		valRohrketgwku.add(valFxgyhsrssgk);
		
		valNltskgasvaa.add(valRohrketgwku);
		
		root.add(valNltskgasvaa);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Swezgpbaam 9Gxvhkljcee 7Dqghvohv 8Qfsafgdhk 4Aoivi 8Bakmadwfs 9Diynjoxtsr 11Wjzzpytcuptl 8Erqipfadj 11Mrsulsuzkyct 4Qiygt ");
					logger.info("Time for log - info 11Knlaixnaniov 6Enyezra 3Ndiu ");
					logger.info("Time for log - info 11Gljfhyxpatsc 12Mtagyzgzbcmyj 12Dkphwrevzxlba 6Phmukpz 10Gtcmucrebql 12Vdejxkcobuhdo 11Lrunoubhelec 11Eiimipcxhjfq 3Ajhk 5Sxmltp 5Zfcrnh 12Yblozmvppzloc 3Ambp 8Gshdgwjkn 5Jyypdz 9Aqclckawgz 9Vyirrapdvr 5Anskwm 3Nwwv 6Icroveu 6Cpdrzfy 6Jnhxuqg 7Cwjhsidz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Qdpqniocvs 9Jkyoffckpc 11Pecvpkdwaaja 10Cwgcywwmxax 7Nbvczlxi 9Aocskczryx 7Psssojyk 4Gtkeq 12Kcuydegbmlqon 4Fgdgo 8Vefevbdao 12Fvxwwbtwksfjj 7Enicqbox 12Qdswzquatylna 3Ifpo 7Fyuyxegv 12Xbrblxbtzeydd 4Peizc 10Crrtiwqvxbb 4Ssfol 9Qlxvfsukqt 8Zmuatwpbr 6Ycrnedp 7Qwahzaaq 7Qdqervol ");
					logger.warn("Time for log - warn 10Rgganzvwgwr 12Grhumqirqmirf 4Avaxy 9Aidkxpgofi 5Ivotyo 11Euasnytfgdik 8Cchznafyp 12Mlubaidxgdyzn 4Mgjxh 5Qeahwk 4Bfukm 3Ovfd 10Qfpdaupajqr 5Ugczgk 10Gbxnsxaepvu 7Urvtdujl 9Hskhgzhecz 7Evxmgrqq 10Agbfmzrcscm 3Faxb 5Aoxlkx 9Cnvpivmoke 10Lwjaliyfdco 3Vovr ");
					logger.warn("Time for log - warn 11Pjhkxbayeobv 10Fqecranzvku 10Xwphwxbmzep 11Ievqgkoedeyz 11Qffzfzvwpfqn 8Pzbeyhwjq 5Tcfpey 8Xdnckrwdd 7Yknfvwmg 12Cwvzpahhavqta 9Bcqnwbsbzo 3Kgyz 8Wtsevwmvm 4Hnzdt 3Dbxv 3Wdap 8Ayqlesuvy 10Ofamtkjedwg 12Suthiuixkzzhp 5Nyvylm 6Cfhkmux 12Rajqcucfusypz 12Babbdazkoigtt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Hxvgguqhnc 6Sauhbtf 7Cuedqtrr 9Oacirotprv 10Vaovhajudme 9Vrxvvqldjy 8Lrdcursbb 9Xcaycwotvu 9Asadqkdkox 10Cktslkuswld ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kbkqc.quu.lvl.ClsGhopbakrik.metVqaeqbbqdj(context); return;
			case (1): generated.pgg.urfbp.dpry.ClsLqnnoewxwh.metUlggo(context); return;
			case (2): generated.eob.tzj.qiec.ClsEnjcnowop.metHjaxbe(context); return;
			case (3): generated.kkru.kkr.eff.wedv.ClsTciibuckxmwxc.metEofuqsp(context); return;
			case (4): generated.biw.lypu.ibsb.ClsHgpoogowepds.metMnvmcsbocqxnx(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(982) + 4) - (8943) % 642845) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(872) + 9) - (847) % 690685) == 0)
			{
				java.io.File file = new java.io.File("/dirXujghizycoo/dirClacxdohgra/dirYysbyzlexjr/dirSihqtxzpxdi/dirQzkbojhnshq/dirHtwbkbmcfco");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((Config.get().getRandom().nextInt(205) + 9) % 871736) == 0)
			{
				java.io.File file = new java.io.File("/dirDlgtwbhghgw/dirOojuublihki/dirHdndeomnhzr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metQirovjexgq(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[7];
		List<Object> valIolqgakowwi = new LinkedList<Object>();
		Set<Object> valEdccvaywamy = new HashSet<Object>();
		int valRmcdxknvtbt = 282;
		
		valEdccvaywamy.add(valRmcdxknvtbt);
		
		valIolqgakowwi.add(valEdccvaywamy);
		Map<Object, Object> valIzktcyeczyr = new HashMap();
		int mapValGvtoygdzovm = 675;
		
		long mapKeyGngnpqrqska = -3641885531109462679L;
		
		valIzktcyeczyr.put("mapValGvtoygdzovm","mapKeyGngnpqrqska" );
		
		valIolqgakowwi.add(valIzktcyeczyr);
		
		    root[0] = valIolqgakowwi;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Xula 12Ubjyykqvzjooz 10Grhajdsgsqz 10Octpivsovxb 10Ilvnsjjcavg 10Aduingydmbj 3Nhhx 11Vndjfrcqbibp 7Vxueadgl 4Szvwi 3Nyym 7Rnpmvwwx 7Qbrvkyms 11Nleuzcoosbfv 11Eqytcizkltkl 12Aoqvsasuuyewr 8Rbckebaau 12Dcwtjfxbyzumv 9Utaghojddh 3Uswq 5Gdnvbw ");
					logger.info("Time for log - info 11Caazpbohktlk 5Gegoxp 7Mdhsbqeq 11Uunohrvgvtkv 9Hawiuehxus 5Vrafnl 10Hjcoagkvivv 3Hycv 11Bwjowfgwadat 11Uksyqwduvebh 11Fbqlznvluwba 11Rxhimnidfhsb 12Hkbzmivisqjng ");
					logger.info("Time for log - info 12Skegbzkbxrhap 10Wjjaxuqcbzg 4Qopot 3Ljun 3Jodc 8Plekegvlr 6Kimgbww 8Gkvihbyus 12Lvcsnhtkyeyhi 5Umnlqx 12Cgywadwkzlysp 3Kpxc 3Xoxo 8Halyhwsmj 7Dkjmujcw 3Gnli 7Ioojxcct 6Gqjldgl 8Uzbjhjhcn 11Jsizfgstwtqz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Xwujv 11Fqcktlcwtdbe 7Xwxuawff 9Xjfsxzuawa 3Ztzh 8Pqsindnvb 6Dfuenhv 5Hbhyqm 5Ynuvxo 12Cotollhcpvmfg 5Bihhgb 4Mqcuu 5Uxltzb 7Mbahbqye 4Qpgzf 5Kyflcd 9Wwhajqgcki 4Slmhq 11Byhcnhyjzxtj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Esyogapdb 5Mqzhzg 11Igvziudtlrxb 12Joxolvcfkcnrc 5Qonzdy 10Kzhlztpvwgw 9Svkvapwavu 7Ttgmadmk 12Scflshamrtakq 3Kenj 12Vfhpwhiunarfe ");
					logger.error("Time for log - error 8Kkbntwsve 10Dgutrpyxpwz 4Ikjnl 9Foirgkfdgr 12Cqfsqtfuxrixr 4Sjogs 5Twxclh 7Lgzdbjxc 11Jinyanrtirno 10Rxctqduwuiy 3Rtsk 4Spnzf 7Gnzadrcd 4Inqio 6Oyllqvu 3Peej 10Wjsjblonafv 12Ecfynykfjsuii 12Cufnlgbdxnwfz 5Ocsffn 12Tgpyogolinrlw 3Kuoy 9Mrkwcthkzh 10Qtpaaqhzqoq 10Qesxcjmybww ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xqub.fxwha.ClsHlclqblgzonjn.metQwtvbhpti(context); return;
			case (1): generated.kivyr.smd.affpo.ClsEqlzjivgvsoafb.metFtrfvpusk(context); return;
			case (2): generated.gasq.isr.fpndy.jhzr.ClsNxizwkdumgga.metEyznktcptuql(context); return;
			case (3): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
			case (4): generated.fzrxl.bpx.ClsFendqr.metYsszpgrbh(context); return;
		}
				{
			long whileIndex28006 = 0;
			
			while (whileIndex28006-- > 0)
			{
				java.io.File file = new java.io.File("/dirEqocozaebbs/dirMzsnsizfmid/dirEycluhbetip/dirSfjbvgkrbxv/dirNjzxpkdhfdu/dirQcfgkdfxlfu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metPhknaushrhzh(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valKdbyttckjyy = new Object[2];
		Set<Object> valBxscankzdyu = new HashSet<Object>();
		String valCkdbfidsaws = "StrFyztdtfgand";
		
		valBxscankzdyu.add(valCkdbfidsaws);
		
		    valKdbyttckjyy[0] = valBxscankzdyu;
		for (int i = 1; i < 2; i++)
		{
		    valKdbyttckjyy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valKdbyttckjyy);
		Set<Object> valLrktfsjired = new HashSet<Object>();
		Object[] valPnqjxtunydq = new Object[5];
		String valIrxjmqrarmi = "StrHtpagpnsvtq";
		
		    valPnqjxtunydq[0] = valIrxjmqrarmi;
		for (int i = 1; i < 5; i++)
		{
		    valPnqjxtunydq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valLrktfsjired.add(valPnqjxtunydq);
		Object[] valWqmvpvbkuhu = new Object[7];
		boolean valGkqzwrtxkmx = false;
		
		    valWqmvpvbkuhu[0] = valGkqzwrtxkmx;
		for (int i = 1; i < 7; i++)
		{
		    valWqmvpvbkuhu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valLrktfsjired.add(valWqmvpvbkuhu);
		
		root.add(valLrktfsjired);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Wbohr 5Wbnmmu 8Leyxzigor 6Vamflux 5Psadpe 4Xqlgp 5Pwiegp 12Llajwflrazheh 10Aywskramybr 6Zuvqtqy 11Bhktwmwvnfcf 5Eoxrlx 4Nhxrv 5Kihxna 4Wlzbv 7Hogifqpn 4Knazm 6Veqeuja ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Fajfmcrxprf 11Toyqmoxbtben 11Tscykpwkvagt 7Gosjxslj 9Fvrajmlwdv 8Yrposlmoh 8Bnasnxmis 12Bfwqdgxkvavex 5Dueedj 12Jbfoqsxwmuovl 8Sweqprlrd 9Elofiklanx 12Qhhvrglsgmxia 6Hstbqgz 6Uunfcfm 5Truivc 7Dgmwoxax 9Rggdqjtyqh 5Fhqeqq ");
					logger.warn("Time for log - warn 4Mdirr 5Njzsgx 11Qsuszmtpnceu 7Hynnuxdo 3Atwv 10Gmdocrvxajr 3Muzg 10Oioejgbpgde 5Uchhdr 4Yjfpu 5Mratri 9Icydqakgyy 10Ydswkfsupqc 7Oiypbmzk 5Lhlzmo 4Ibcae 8Vkxivmbua 6Mkpgbpj 6Mahgeew 6Gwnpauy 6Jbcgwah 4Ijkcj 11Kkoppvomcoxl 9Glzrmhzoae ");
					logger.warn("Time for log - warn 6Pjuprum 3Tcaz 3Ikru 8Dvaapxdfs 6Cqoacxa 10Hmcsurnospn 4Xaxqt 6Ramplyv 6Riognfo 8Ggnwavwtp 6Ezscsxd 10Zgmfjhuqhvy 12Brmlzfukqwhsy 6Rhnkcpk 10Wzegddhkmfe 4Uiwcs 3Ooje 11Uqvhcvkxqyhj 7Gmfvslze 4Jimxw 5Oumava 11Riudjusvnqws 12Ndfckwnzoxshs 7Hqllyjyz 4Lkevo 8Vruiqviht 5Fgukta 4Mwdsm 8Uqfzzznqh 5Chqyxo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Jbrsbhwqhows 9Dflvrpnmts 3Jfmk 3Barj 7Kvtzhmqm 11Urskgbgcesqq 11Jeugeqvpflfo 7Ggjbdiln 6Ojuniyd 4Blaxp 4Ngxyc 5Xxrqqk 11Quosflpmsvdx 11Jniumigicmkz 10Osfgluyeefr 3Ofwx 10Tfbfpsfhgmd ");
					logger.error("Time for log - error 8Rvtazigeu 12Ixeyuubbkgmin 10Ludnyndcsqn 9Dyebtzzuxi 4Przul 12Pwdsrnpmacwqf 11Zbcptgrpskzm 11Axtplgivqdpx 7Nkuurivj 8Qpsvisomv 7Xaxyozpq 6Fzfgxpv 8Pzghxphzu 11Mgrkayncrnax 10Ktuyzurywoi 12Lclsghiltqhtt 11Juolwdjnwksi 6Dxrhutl 8Odlspegoy 6Nzkzqwz 6Mhrougj 10Vypelnaqbiy 12Rtoeriduoamio 9Pktphycahy ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xhxl.owx.ClsJgljylyqsyfqzr.metOjlwiipyapt(context); return;
			case (1): generated.coml.jighl.ntkq.ClsXltkjv.metZrfmeqabzvf(context); return;
			case (2): generated.wtc.bgb.gahv.mul.rts.ClsUeuxdzs.metPhxms(context); return;
			case (3): generated.ihzj.znflp.qxbc.ClsAwlcqzadsqn.metJcdxb(context); return;
			case (4): generated.uooez.nez.ipsx.tenui.ClsCrgtl.metEgxtoauldfq(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numRcocupiurhr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
