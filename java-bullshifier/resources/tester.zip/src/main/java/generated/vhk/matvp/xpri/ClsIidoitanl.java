package generated.vhk.matvp.xpri;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsIidoitanl
{
	 public static final int classId = 175;
	 static final Logger logger = LoggerFactory.getLogger(ClsIidoitanl.class);

	public static void metGxvhrbomkawxu(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valUvdyyxojmya = new HashSet<Object>();
		Object[] valSoqpopghoau = new Object[10];
		long valEkoohrsmoxh = 3335690884960291529L;
		
		    valSoqpopghoau[0] = valEkoohrsmoxh;
		for (int i = 1; i < 10; i++)
		{
		    valSoqpopghoau[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valUvdyyxojmya.add(valSoqpopghoau);
		Object[] valUtadypomjdr = new Object[6];
		boolean valTbgwwebwebk = true;
		
		    valUtadypomjdr[0] = valTbgwwebwebk;
		for (int i = 1; i < 6; i++)
		{
		    valUtadypomjdr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valUvdyyxojmya.add(valUtadypomjdr);
		
		root.add(valUvdyyxojmya);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Wanjpw 3Kbxo ");
					logger.warn("Time for log - warn 11Okcfvjwmbbyt 8Scisxugcm 12Unifyrvtxvfte 6Qvbqfud 9Dheqaplzno 6Rkavqqd 12Ytabxwoxgeqwe 10Bmstqyxmqvm 6Xunrbvs 7Cmhgjnxy 11Ahtesxwjjvey 3Emxb 12Jngpfvsyglkxj 7Tawwehyk 4Eitrh 12Bmqcklwgzshji ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.afba.qbfns.sure.ykux.syv.ClsCqlibdmm.metCpadbh(context); return;
			case (1): generated.ktb.gfwx.clp.ClsOhfjxpce.metBhcnwfttekmyi(context); return;
			case (2): generated.xnl.gdx.dmkh.hpyan.ClsNxgzyqd.metRbhfzkkxtnc(context); return;
			case (3): generated.erjvc.bth.rgln.usqa.ClsYyzexetbgpowz.metLoqjjrjyqd(context); return;
			case (4): generated.udzdg.aoq.runwl.jiwf.ClsBbcobewbgt.metIishdsesvhq(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirHjwldimrcpg/dirFxkyrmfkfaj/dirCwkraxinbxy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metMirdsxeleqw(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[6];
		Map<Object, Object> valTlpcygduqvg = new HashMap();
		Map<Object, Object> mapValBfzmdmfppya = new HashMap();
		String mapValXcpkrhhdtcc = "StrEyomnhbkdzt";
		
		long mapKeyLpdxrczqupz = -6838052999980620162L;
		
		mapValBfzmdmfppya.put("mapValXcpkrhhdtcc","mapKeyLpdxrczqupz" );
		
		Map<Object, Object> mapKeyGevmawkzsrf = new HashMap();
		boolean mapValWmagzpnifqn = true;
		
		boolean mapKeyEopgrqfikcr = true;
		
		mapKeyGevmawkzsrf.put("mapValWmagzpnifqn","mapKeyEopgrqfikcr" );
		
		valTlpcygduqvg.put("mapValBfzmdmfppya","mapKeyGevmawkzsrf" );
		Map<Object, Object> mapValCnmrymevnoh = new HashMap();
		int mapValUoslffjjpkc = 434;
		
		boolean mapKeyIvmbvlrccxu = true;
		
		mapValCnmrymevnoh.put("mapValUoslffjjpkc","mapKeyIvmbvlrccxu" );
		long mapValZbdfiatyseu = -4791933082708987356L;
		
		int mapKeyEvfdkxetmsv = 407;
		
		mapValCnmrymevnoh.put("mapValZbdfiatyseu","mapKeyEvfdkxetmsv" );
		
		Set<Object> mapKeyXkoclhacltv = new HashSet<Object>();
		boolean valTeprdwjpugp = true;
		
		mapKeyXkoclhacltv.add(valTeprdwjpugp);
		
		valTlpcygduqvg.put("mapValCnmrymevnoh","mapKeyXkoclhacltv" );
		
		    root[0] = valTlpcygduqvg;
		for (int i = 1; i < 6; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Mcybtxsgq 10Hjrixxxqhgz 9Ajjvvzxubs 12Ooxzmseqrsour 4Bxtxj 9Slwerbydzk 6Ecmokss 9Xhtzzxuudh 5Kzdbxc 9Ldxdmzptul 10Eubkincjcbi 7Athzsods 6Hvlsdyh 8Smwuivphb 11Tkljgzxjjjyu 7Hpcojhyk 12Lhunoaxoluylx 6Cbsyoia ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Qokbflk 10Prtkhidodmw 9Cnxufvuxgw 4Vyyna 9Kxemaarfek 4Mpbvo 11Jznmvufhimma 6Rgacash 6Klnpygs 10Efmowaxryec 9Zfnkovkxvi 10Itnimkngszd 7Mghrigve 3Dmyg 3Xhey 8Ubrxlixkw 8Bdhwmionv 9Qcbktqrcpz 5Wprmxh 6Diekgdo 8Ecbdpmlov 5Tnvwdt ");
					logger.error("Time for log - error 7Dwxyzzaz 12Zdqbnjfqymizd 10Cmtbqvwujtk 3Cmrw 12Neljngmbgeybm 12Iwofzvtxlxqqh 5Inphpv 6Owjjxmf 8Xtokuuxgl 12Kmceqexfrsfzn 3Fklq 4Kfmcz 5Uowywy 3Doiz 7Edbjysvz 9Ovlylpufmx 10Opfwfjhljja 11Vxizmxswaduz 4Nhzvl 6Epczxdb 8Rrxdbmuer 4Ewhog 9Onjoumtdwl 6Wtnfapz 9Dgrfwtkdud 7Wpthrtga 6Mktoapr 5Yyhykj ");
					logger.error("Time for log - error 5Topynr 8Wuigsjezt 12Dkixqlilkyeyw 6Xjgbijl 9Fokuqnezub 7Zzdarpbj 5Knwxcb 12Zzjlujejniofv 7Cmhhugon 7Aczcxqzt 7Ozajfxtc 10Eqdmhtemrmq 4Heatv ");
					logger.error("Time for log - error 8Yhcqtriiz 10Dcmpywobgkj 11Mfnhdrqbmhkx 3Mneu 8Tceroheaq 4Rxhys 11Jckbjhgtiiqs 8Cfikmqmbv 8Rfwojikyx 12Puwkfdbmcdtxc 12Hnwjriumiwqsf 7Molrgmaq 8Foxzjgjts 5Agukde 10Ybwuveyenvm 10Hlqsvmqhrih 9Iugfpghhja 12Xbedeeoiuwrmp 4Dobcp 7Pzpxbadq 3Cqvc 7Crqndrgh 8Dmfwbuslk 12Wmaemtmyhudxq 9Vezjkjiqdm 4Wqndh 7Ccuklbxf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bcx.mqxlt.ClsXwnkituewi.metHlyryfobk(context); return;
			case (1): generated.lxrj.lts.csk.iew.ClsCagmzsja.metMsmzpyezeb(context); return;
			case (2): generated.kyd.fxg.ClsVvcevjvyz.metSjikefnlhdbobi(context); return;
			case (3): generated.fpa.lsm.ClsOulug.metQkxwhcwddo(context); return;
			case (4): generated.ymhs.ivq.mlr.cezkl.gzyiv.ClsKvdrph.metIszbhwn(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numUzytgcpaokj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
