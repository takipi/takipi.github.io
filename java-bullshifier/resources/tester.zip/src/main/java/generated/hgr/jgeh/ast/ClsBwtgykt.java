package generated.hgr.jgeh.ast;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBwtgykt
{
	 public static final int classId = 253;
	 static final Logger logger = LoggerFactory.getLogger(ClsBwtgykt.class);

	public static void metGnslwfxjnxwudj(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValEphemugcxwd = new Object[7];
		Map<Object, Object> valDpprjycfkew = new HashMap();
		boolean mapValXtevxzrpluh = true;
		
		int mapKeyIpccgwivcuz = 933;
		
		valDpprjycfkew.put("mapValXtevxzrpluh","mapKeyIpccgwivcuz" );
		
		    mapValEphemugcxwd[0] = valDpprjycfkew;
		for (int i = 1; i < 7; i++)
		{
		    mapValEphemugcxwd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyAqwzbijtpdc = new HashMap();
		Map<Object, Object> mapValSrzedycylxj = new HashMap();
		int mapValSaaomdrrwtp = 850;
		
		int mapKeyWwmvfcislyz = 126;
		
		mapValSrzedycylxj.put("mapValSaaomdrrwtp","mapKeyWwmvfcislyz" );
		
		Set<Object> mapKeyDjtnclrnnhl = new HashSet<Object>();
		boolean valXopxqzpuqtx = true;
		
		mapKeyDjtnclrnnhl.add(valXopxqzpuqtx);
		long valKqimgljasey = 3740473974619303259L;
		
		mapKeyDjtnclrnnhl.add(valKqimgljasey);
		
		mapKeyAqwzbijtpdc.put("mapValSrzedycylxj","mapKeyDjtnclrnnhl" );
		
		root.put("mapValEphemugcxwd","mapKeyAqwzbijtpdc" );
		Map<Object, Object> mapValOeljdxfnkgs = new HashMap();
		Set<Object> mapValOlijilmbfon = new HashSet<Object>();
		int valGqwvxhyceoa = 812;
		
		mapValOlijilmbfon.add(valGqwvxhyceoa);
		long valYdbnalkcwtf = 3119187990693638146L;
		
		mapValOlijilmbfon.add(valYdbnalkcwtf);
		
		Set<Object> mapKeyTpaqitzamyi = new HashSet<Object>();
		int valDxhetqasscy = 17;
		
		mapKeyTpaqitzamyi.add(valDxhetqasscy);
		
		mapValOeljdxfnkgs.put("mapValOlijilmbfon","mapKeyTpaqitzamyi" );
		
		Set<Object> mapKeyTvkxvqrsxor = new HashSet<Object>();
		Map<Object, Object> valIiagxaoxtxk = new HashMap();
		long mapValLzfzodwbexg = 1294990268670985284L;
		
		String mapKeyWkqmfewydvw = "StrRtcwooggogy";
		
		valIiagxaoxtxk.put("mapValLzfzodwbexg","mapKeyWkqmfewydvw" );
		int mapValVyafngrizgf = 478;
		
		String mapKeyQeyzhdkrode = "StrSwvzgbqyxxd";
		
		valIiagxaoxtxk.put("mapValVyafngrizgf","mapKeyQeyzhdkrode" );
		
		mapKeyTvkxvqrsxor.add(valIiagxaoxtxk);
		Object[] valXcgtqqhxpxm = new Object[3];
		String valJrisidjysmk = "StrAcfmsoyrcfk";
		
		    valXcgtqqhxpxm[0] = valJrisidjysmk;
		for (int i = 1; i < 3; i++)
		{
		    valXcgtqqhxpxm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyTvkxvqrsxor.add(valXcgtqqhxpxm);
		
		root.put("mapValOeljdxfnkgs","mapKeyTvkxvqrsxor" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Aqex 12Zefohazxbacht 6Ecerayf 3Jjqk 6Wxcdjqu 8Kvemnewrj 4Yybhp 5Qejmqn 4Etdpb 5Rxjruk 9Ycrtyjgasg 12Gicncbtxlftts 4Moiht 3Bqir 9Criaehhiwr ");
					logger.info("Time for log - info 4Zwxad 7Ctrtncvu 10Atomqjietbg 3Rygb 8Dleeftxpr 11Btgmcnhfcwey 3Kgnn 8Hechtvtuu 3Lofe 11Aclceiixncwa 3Zlum 10Zgkjysexjax 5Yxzric 5Tnemoe 5Ediipk ");
					logger.info("Time for log - info 8Cnyiavsvs 4Bvtro 4Jgyoe 6Ghgzqxe 12Tjvbzhtizqjmp 9Qobqjwbisu 9Wfvyggulnd 8Iutujpspt 10Ehbfloxibni 5Msaljl 8Xvafhwesl 6Knjesuw 6Tjzwlgl 8Hpaluyejc 10Dtqddxwekeg 10Fibezhbcmeb 7Jexcpzhj 5Pwjibg 3Ywpy 6Phhsqis 11Xpkjdystdcag 10Reexblyxhga 3Egoc 5Pikble 3Ngro 9Viuhdeckkq 11Dwcjsoghtlhk 10Ozbxqgrybsx 11Rhmvkyxpetzw ");
					logger.info("Time for log - info 7Jzpyschp 12Gkhtdpppygybz 5Kbqbdz 4Jdfhv 7Rykdcnus 12Lcfaxmjuwejqe 12Tjhgejiqkvesd 7Wfqkrniv 5Tvrbab 7Uredtmuz 3Lwng 9Lpwmihugyz 4Smxdf 4Zimjm 10Qamnjexlwob 5Gpequa 11Qulifhtaabsd 3Cwcn 11Umooshebervz 11Mzmfcmsvlqdb 3Ppcb 11Jrfekxssorya 10Udktajwqauc 6Zyvhnyo 10Goeoztuqiod 5Tqbprf 3Fbwx 4Lyxeb 8Nnroxekcx 3Qslm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Wqniipyalshsx 11Fmmwazxzuzod 12Lvahqwyavltdg 11Fmafqgetmtlj 3Jsyf 11Ockmlwrbgcjn 6Jnyghzx 9Mlislkblgb 12Bmzbnypstcvuz 3Fmok 6Xudqcqm 4Qbvst 3Njrd 6Cmwinbe 8Sruosqmfj 4Vahiz 9Kxjszkvleu 6Qvihbhc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Cqrwytx 7Poqcuhjt 9Kjtlswiknl 8Lfklmvvdx 5Dgkpnb 5Ypkjjw 5Wtwndp 5Bvhhwp 4Wvixz 10Indljsecjjz 4Yvvxq 5Tdmohh 10Kkmtoxhdbtx 8Luvbvoghc 11Ioswkgkyafnv ");
					logger.error("Time for log - error 7Ecyoioqe 6Kvxmsrh 10Ovnadfowroc 8Dlprkucpv 11Rbmsjscvxilq 10Ophzymyafdd 6Lptfead 3Lfnk 5Xlucrs 7Scububcs 4Wcoet 8Ddysrhndr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aqqfv.gdkxm.pact.ClsAgtwrqa.metXrocwodxu(context); return;
			case (1): generated.gww.spuw.jrq.nmv.xowli.ClsKosigq.metQasyaqoccfnym(context); return;
			case (2): generated.aqdnu.puvg.gdad.ClsIxzvdsuksw.metUndfk(context); return;
			case (3): generated.ddlri.xli.qud.ytlvf.ClsNvsmjkbfbxcsj.metIasfjtbluwvaig(context); return;
			case (4): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metJvnsuyubxdox(context); return;
		}
				{
			int loopIndex24431 = 0;
			for (loopIndex24431 = 0; loopIndex24431 < 6760; loopIndex24431++)
			{
				try
				{
					Integer.parseInt("numMfansuekdfp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metBmeyjwcjjjikwl(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Object[] valOiirzajyxrk = new Object[5];
		Object[] valSpyntqnwehj = new Object[8];
		int valSdwllhdmikq = 384;
		
		    valSpyntqnwehj[0] = valSdwllhdmikq;
		for (int i = 1; i < 8; i++)
		{
		    valSpyntqnwehj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valOiirzajyxrk[0] = valSpyntqnwehj;
		for (int i = 1; i < 5; i++)
		{
		    valOiirzajyxrk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valOiirzajyxrk);
		List<Object> valMyqfpvzoflm = new LinkedList<Object>();
		List<Object> valUbqxnrxfaws = new LinkedList<Object>();
		int valNrbospocohy = 918;
		
		valUbqxnrxfaws.add(valNrbospocohy);
		int valDybxdjqtsyp = 67;
		
		valUbqxnrxfaws.add(valDybxdjqtsyp);
		
		valMyqfpvzoflm.add(valUbqxnrxfaws);
		
		root.add(valMyqfpvzoflm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Apfjmeaq 3Pjlt 8Tlcdkimcr ");
					logger.info("Time for log - info 12Cpwiiuacjpbxs 5Umnkbe 12Ytdfhmgqmxumc 5Mtthjr 10Nvpbsztregv 7Ehuzxqqq 5Vscwbd 10Eggatdzttku 5Fudvsx 12Zhofauiszpghc 9Stgkuprbrv 6Cjpjyre 7Uqkywgba 4Tmiws 7Reujajtf 6Mbjwlkn 12Xzjivbuongonw 9Eyfllwerys 8Sgomzfneb 5Spqsic 6Axrrbrg 8Xzscwlxpj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Flfkcfmwzlz 12Kkqanatjrwkls 5Usqyne 5Qsbqqf 5Gvzxcw 4Oksjr 5Sfkivg 6Lwhojzu 8Ykgiiknyw 11Iykwzpbpirrl 5Udtpgf 6Dkeutjt 8Fvcegiclh 9Tjvdikubuw 5Vfwljs 7Akaqwwjp 7Bsvdraoj 3Cggd 10Zuhrslhzdvc 4Hzhhs 9Cacxhjfnpo 10Ieqdzvgpllf ");
					logger.warn("Time for log - warn 9Pzgkxurlrg 11Zdqlhdpnqyco ");
					logger.warn("Time for log - warn 8Hjvcbwekp 4Ngmbi 6Gikpqyk 6Jwawmoq 5Vkfxpd 10Pebszplirzv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Ibccy 9Nospptqcry 11Byqvkspszilm 12Wtcxsouzfjngd 3Uuxb 5Zcowli 7Ojlhbrjh 10Htbynuhzrex 7Rdojgyqj 7Yxfhabfl 8Fnjrjppcd 11Eyxrlbmioava 4Oeton 6Ohecdaf 11Kwjwtttzdbnn 9Qkpxlysxsm 7Nqbthert 5Lwitpk 3Uzpj 9Elbxkxcxwd 5Qhzmmn 6Aqxicfg 10Zyskktkcmzd 5Leqnoh 11Ysibcjqpptug 9Nrgzyqetxv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.exa.yssf.ClsHuxmu.metYpznuybxbixhh(context); return;
			case (1): generated.dnnlu.krjt.bhw.ClsLntkclh.metCanmcyztyd(context); return;
			case (2): generated.ajbel.dvbe.pmx.gfhen.qjvpo.ClsFwkvrnv.metXipxiwvyvncxvi(context); return;
			case (3): generated.lnvho.rhfct.ClsGgdasahuvsgcd.metEhvvpiwjzqivv(context); return;
			case (4): generated.lmq.wwll.mcjoz.ClsBqjxdpu.metLzmwjdeakzh(context); return;
		}
				{
			int loopIndex24435 = 0;
			for (loopIndex24435 = 0; loopIndex24435 < 3918; loopIndex24435++)
			{
				try
				{
					Integer.parseInt("numKyhzkiservc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
