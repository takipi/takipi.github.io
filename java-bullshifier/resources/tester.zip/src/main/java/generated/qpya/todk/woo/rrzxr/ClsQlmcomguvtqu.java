package generated.qpya.todk.woo.rrzxr;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQlmcomguvtqu
{
	 public static final int classId = 346;
	 static final Logger logger = LoggerFactory.getLogger(ClsQlmcomguvtqu.class);

	public static void metVbgwaaycr(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valGavfegmcgud = new HashSet<Object>();
		Map<Object, Object> valEuccqjnnjlt = new HashMap();
		String mapValKmexdhchmig = "StrTnpldwjnssf";
		
		int mapKeyOjogjgokcao = 419;
		
		valEuccqjnnjlt.put("mapValKmexdhchmig","mapKeyOjogjgokcao" );
		
		valGavfegmcgud.add(valEuccqjnnjlt);
		List<Object> valJmoojeyebfc = new LinkedList<Object>();
		boolean valVscdymjanpb = false;
		
		valJmoojeyebfc.add(valVscdymjanpb);
		
		valGavfegmcgud.add(valJmoojeyebfc);
		
		root.add(valGavfegmcgud);
		List<Object> valHcaazdpjnei = new LinkedList<Object>();
		Object[] valGgadryshtnh = new Object[4];
		int valHoacbnorcsw = 714;
		
		    valGgadryshtnh[0] = valHoacbnorcsw;
		for (int i = 1; i < 4; i++)
		{
		    valGgadryshtnh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valHcaazdpjnei.add(valGgadryshtnh);
		
		root.add(valHcaazdpjnei);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Ociuk 12Vrmtykyjvugfs 7Nssxnpyt ");
					logger.info("Time for log - info 5Rsyaea 9Kijgxypbok 5Shlstd 5Smukhf 9Tvlqakdftx 12Ygjzzhbvjebvc 11Lcatwdzibtkw 12Lezudehyntpiz 9Bebklqzbmk 12Imlpnxggyjegr 12Ffbmxvhpwalqq 4Zoiqw 11Uizaheokkqlt 10Dvowhebwvkx 4Wtjmr 7Kuagrprs 4Wmahx 6Wobpkvs 5Stqhde 10Qqppbxumazf 3Kvry 4Twwth 10Xrvbpxtavfv 4Fwqxk 5Ozyerm 11Ueixknjpruws 3Hfwq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Jkpamt 3Guau 4Bpidc 6Naiiywr 6Jfbklfi 6Zljwbsx 7Vglmcsud 6Bsfhuue 5Umbmlm 11Ftrwdqxkylsw 6Zqjnpym 12Bhugesfnxcdnd 10Ymjdukserxz 9Gqcagctytd 5Hrqffu 11Bpiqvusxddyt 8Dpodwvqul 10Ygdgshncnkj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Usqrk 8Rbwikvfhm 11Uiamzxyhaedb 8Tgxcocaai 8Qqaexphuf 3Bqin 9Hkymqharui 4Unooi 6Ptlxqen 10Rdsqzecsazp 9Ppnhadlqxi 10Gqcefjrljkj 11Quvixbjopftr 10Fhgkrbdrprh ");
					logger.error("Time for log - error 11Bmhxavaupipa 10Ptzrdfvexci 12Cyvlhnmjrexhz 8Qnquogwne 10Lfxncmoppkk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ionxn.lbvax.tzn.gjpzs.dvu.ClsMscwr.metGxebiuwchcnygz(context); return;
			case (1): generated.pef.kybz.yzpf.dzs.obqpv.ClsKizvnatyigi.metKzutin(context); return;
			case (2): generated.kkru.kkr.eff.wedv.ClsTciibuckxmwxc.metSuyddmghay(context); return;
			case (3): generated.wspiu.cmqv.pvdxy.isdgi.ljwn.ClsZpnvzubxm.metXtcjjfosrwkks(context); return;
			case (4): generated.uym.yiu.voiig.deif.ClsUwvuontynja.metKobtinihjvflj(context); return;
		}
				{
			if (((4569) - (Config.get().getRandom().nextInt(52) + 6) % 280724) == 0)
			{
				java.io.File file = new java.io.File("/dirZwtbsxgeyrh/dirYvesmkoaknv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((Config.get().getRandom().nextInt(293) + 9) % 26649) == 0)
			{
				try
				{
					Integer.parseInt("numQnmzefdbjoq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(46) + 4) - (7559) % 289570) == 0)
			{
				try
				{
					Integer.parseInt("numRehlozhsnwr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex25845 = 0;
			for (loopIndex25845 = 0; loopIndex25845 < 2129; loopIndex25845++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
