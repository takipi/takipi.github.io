package generated.uooez.nez.ipsx.tenui;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsCrgtl
{
	 public static final int classId = 498;
	 static final Logger logger = LoggerFactory.getLogger(ClsCrgtl.class);

	public static void metUnmartob(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valAdtlhhcjywf = new HashSet<Object>();
		Map<Object, Object> valPvvxnkbfxje = new HashMap();
		int mapValYawfypmwuzp = 551;
		
		String mapKeyAnfyvxbpkzk = "StrScglyvgpfsw";
		
		valPvvxnkbfxje.put("mapValYawfypmwuzp","mapKeyAnfyvxbpkzk" );
		
		valAdtlhhcjywf.add(valPvvxnkbfxje);
		
		root.add(valAdtlhhcjywf);
		List<Object> valQizfqwijoud = new LinkedList<Object>();
		Set<Object> valJotcqytduhf = new HashSet<Object>();
		boolean valMdpkyftoxkq = true;
		
		valJotcqytduhf.add(valMdpkyftoxkq);
		boolean valLsxadwrdxyj = false;
		
		valJotcqytduhf.add(valLsxadwrdxyj);
		
		valQizfqwijoud.add(valJotcqytduhf);
		
		root.add(valQizfqwijoud);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Gbfsbq 3Yeyh 7Jfrgikqr 6Rrjklnn 11Akixucgngezo 8Ofbzvcapa 4Ozqgf 10Qdhvhmjwlgq 4Ehviu 9Sibauyryoc 12Wtxcgxxaflzos 12Bdyrjgrqdcqvp 9Anmmejvgwr 10Mruxonsdkvx 5Ydzzms 12Vbtjmvrmxffko 12Preypamxdrtik 7Gjplojcw 3Xvls 11Xabyaxbyexsa 8Gbsvanimu 10Zirvrhgpmcs 8Hqlyakdpu 9Xaiatdpcff 12Noaeosuarqysg 5Jppfka ");
					logger.warn("Time for log - warn 8Cxlffiqur 9Aquebiqawd 12Fkeqixtghnewa 7Qjehupcv 11Vqsdsruzytkb 10Aegvckhtjvw 10Kfmqwkeodrm 7Xxfhvqna 12Vgwifstvoukjj 3Kunl 9Npvigzsrsr 9Bxyznyhasv 11Tkuvajquoffi 10Wpzwtjhsrie 5Uzvytl 12Mkqxmnslxjkdz 5Mrekch 8Xykzovuya 5Eqpomk 7Ronckmni 6Ezqoupl ");
					logger.warn("Time for log - warn 8Qkzgvrfrr 5Heuplu 5Aihpas 11Zdpzlielkxwo 5Ngiqrx 9Wgaldtcqwf 12Wdaztfzjtbekm 10Yvepkulitfi 7Ydqkztlp 11Xhivikzdnxcc 9Upxvrsgsby 4Yeixw 5Ufypzs 8Qicivetnv 11Huknztneboyt 8Oytbzbqjg 10Matkpwilzdk 6Hjseane 11Jndswgjxiydx 10Cvejpfzmtti 7Qapspran 10Xhzyfmlxpcj 8Eygwmaaks 4Umrgk 7Krppghkf 5Kbqotp 6Wajqflc 4Sidsm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rorl.wuo.lqgdf.ClsUltodfmiuq.metZqbkch(context); return;
			case (1): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metDcqlrafmtcoxm(context); return;
			case (2): generated.nxf.wvris.vmp.ClsGllyounxce.metExmyrcamcnqvv(context); return;
			case (3): generated.dpe.jvo.jwdtk.ClsKqcmvv.metOqhxfxoow(context); return;
			case (4): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metGigic(context); return;
		}
				{
			int loopIndex28408 = 0;
			for (loopIndex28408 = 0; loopIndex28408 < 3559; loopIndex28408++)
			{
				try
				{
					Integer.parseInt("numVnnblrduwpw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex28410 = 0;
			for (loopIndex28410 = 0; loopIndex28410 < 4229; loopIndex28410++)
			{
				java.io.File file = new java.io.File("/dirUkghvodcsmr/dirZkunnwszlvp/dirQinmqkmngwv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metEgxtoauldfq(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valYjmgxqozwgz = new HashMap();
		Set<Object> mapValYwahmugoqeh = new HashSet<Object>();
		boolean valVniotfzyrhk = false;
		
		mapValYwahmugoqeh.add(valVniotfzyrhk);
		long valFeoisvkwcmq = 964748033838116776L;
		
		mapValYwahmugoqeh.add(valFeoisvkwcmq);
		
		Object[] mapKeyXtztuqvxaqb = new Object[9];
		int valCamzufheucc = 131;
		
		    mapKeyXtztuqvxaqb[0] = valCamzufheucc;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyXtztuqvxaqb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYjmgxqozwgz.put("mapValYwahmugoqeh","mapKeyXtztuqvxaqb" );
		Set<Object> mapValSxnsgbhvzjh = new HashSet<Object>();
		int valQsmdvenctxb = 249;
		
		mapValSxnsgbhvzjh.add(valQsmdvenctxb);
		
		Object[] mapKeyKmppbokpkid = new Object[7];
		boolean valGxcnwcurguu = true;
		
		    mapKeyKmppbokpkid[0] = valGxcnwcurguu;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyKmppbokpkid[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYjmgxqozwgz.put("mapValSxnsgbhvzjh","mapKeyKmppbokpkid" );
		
		root.add(valYjmgxqozwgz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Vyehark 9Mayzcwddvb 7Vntjetjc 5Cmouhf 10Ydhakulcjnm 8Wnerfscxj 10Vgagtjbeexa 8Mgyfyurhy 9Qpwsvnghxv 4Sljpc 10Migvhvvweby ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Fhsvqnynx 7Benarmtt 4Gxqoz 10Zsgabhdgnau 11Gldessafsmmf 8Htlfxwlxx 8Gqvmxtuxt 5Kvdvlz 9Stbvmvbxmd 10Ccotsbivwld 8Ncicsngze 6Ofinjvm 11Fkzytuylvtyn 12Gwpkdluphwldf 4Hpqnv 7Jnumnyvx 5Ouocyt 5Wbqzjz 6Twhweaq 12Gyrwpoaaqnhiu 7Daqeiqij 12Ejaatjbsevsqf ");
					logger.warn("Time for log - warn 5Arwcpl 5Dennko 11Ymyagtmyvlso 7Vibveujc 11Cjxrcxehsgag 3Ysse 12Upwmjxcsigjeu 7Mhnjtxwo 8Lztudbxnh 4Qaqxn 3Guiz 4Zuvpc 7Xwcborne 7Gofsaaet 11Zqmjwmhiggwr 9Ymyssxgbct 7Mweeiewq 7Sxnwidvz 6Zapxnol 5Hcltez 11Eusdyutytpfk 7Vskqumia 7Ismwobuf 12Iofvdzaecgygx 12Ihuionwhnsxtu 8Qcarnbdlp 3Mvfp 5Qznbsz 12Fwtksxheanghn ");
					logger.warn("Time for log - warn 9Bsxnbervct 3Tekv 3Oofh 11Stickpiicxun 4Hmcet 3Oliz 6Aiqkzmv 6Mfylrzl 6Kmftqrh 12Goihzbsypnwjz ");
					logger.warn("Time for log - warn 5Xqzcdf 11Nnunvautdkyy 11Sogmldojxwru 8Byrogoblr 12Lxqnwdayaomzk 5Dfdeex 9Iynoilfjqb 8Wxzdrevue 12Zdiyrfxkvnoqk 12Apuwodgbsnehy 12Jtqmlhymuznrx 4Nvwiz 9Vdbprqzezk 6Qngttge 8Fpqveoefc 4Dnuca 11Wnmvukzucauj 3Yiry 9Nlxtdqpbss 6Ytrxtwa 8Iyocxeady 4Kpovr 7Ewbttywh 11Anbxmlobopmz 9Egbqdseeiy 8Shjqmvtjz 11Gmukdjmivsuk 4Biknc 12Kamwkpghaxvpg 7Fjhllsoe 7Fskgjaib ");
					logger.warn("Time for log - warn 11Dutrazvvccle 7Rwortqjg 12Cecsbbcapyjfl 7Dyonqjyb 5Ylantm 5Hmcsxa 11Rdoakzrrnrvf 8Xefritymf 5Nsaxkb 6Hgileft 7Qypbjivq 6Lqnfmzy 7Iemqvcpi 4Fdbiw 12Ufucnmtufpxnk 6Rmeoytm 4Mifyj 10Rzjbtgeqgzt 5Cepkwn ");
					logger.warn("Time for log - warn 11Ivnwyzclpwas 7Uztqykyj 4Epklg 5Kzwvsh 6Lyolkqj 12Vjygsszpvwnwh 9Pkciwltbxi 8Fxvjbxlrt 7Wehvrwcl 5Wsbogo 4Wshaz 11Javekgwpesdx 3Uxrx 3Cucq 5Tgfgjm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wvctc.whp.ftjy.ClsPwdcftvpjt.metEsqbhpd(context); return;
			case (1): generated.pxy.vesv.fuz.ClsEaskwlgtcshts.metCnqxpzkxiqea(context); return;
			case (2): generated.dyv.vxo.ClsWrwpfswr.metBamfflypcsi(context); return;
			case (3): generated.ylqx.lamew.rrd.tiu.hut.ClsBorecfhsp.metVjvfkt(context); return;
			case (4): generated.lwjvh.jknhf.givvv.ClsBgfhlg.metVudhurmppkohax(context); return;
		}
				{
			long whileIndex28414 = 0;
			
			while (whileIndex28414-- > 0)
			{
				java.io.File file = new java.io.File("/dirWdmgjlqupig/dirSdljdjkfrmr/dirBgdtpvglkrl/dirPgralrzqddi/dirVkfkvwxpmve/dirFvaqwbemkhf/dirXvwvfavyeno");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((whileIndex28414) - (Config.get().getRandom().nextInt(348) + 8) % 118401) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((2850) % 146438) == 0)
			{
				try
				{
					Integer.parseInt("numQrfxusizadx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varKlepsbivjhp = (8721) + (7587);
		}
	}


	public static void metHrkchutdgiq(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Object[] valQimbqbxsqog = new Object[10];
		List<Object> valXfgqazyhudk = new LinkedList<Object>();
		boolean valVgxubdglmgd = true;
		
		valXfgqazyhudk.add(valVgxubdglmgd);
		boolean valYnsbvfwxkor = true;
		
		valXfgqazyhudk.add(valYnsbvfwxkor);
		
		    valQimbqbxsqog[0] = valXfgqazyhudk;
		for (int i = 1; i < 10; i++)
		{
		    valQimbqbxsqog[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valQimbqbxsqog);
		Object[] valXznuledtlbf = new Object[6];
		Set<Object> valMvvwndpnwah = new HashSet<Object>();
		String valPbouqomzmki = "StrPjqjgokrmwr";
		
		valMvvwndpnwah.add(valPbouqomzmki);
		boolean valFdnttevwewr = true;
		
		valMvvwndpnwah.add(valFdnttevwewr);
		
		    valXznuledtlbf[0] = valMvvwndpnwah;
		for (int i = 1; i < 6; i++)
		{
		    valXznuledtlbf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valXznuledtlbf);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Gfbhuwec 4Sfcvn 11Mnbotffnrkfo 6Mhdlalb 9Wdpqzfsosi 11Wtdaootyphdu 7Dhfrgtzk ");
					logger.info("Time for log - info 4Qbqbu 5Zdhwdf 11Jcftwyidlakr 3Wypf 3Scpq 8Dsktzdwmp 5Rcuwol 8Lecolezad 9Wzbgytphgp 9Dcyloympql 5Jfgrsq ");
					logger.info("Time for log - info 3Utiw 7Phjrismr 12Hljfejgkyfouo 4Porwn 11Gjzgdqykroyf 10Kicmlgrhhvn 9Jhjnqsqyvw 5Bawiby 10Cfdttfitpna 9Vaxvkhcbbj 5Epvbsl 11Vtssfbzjqswz 4Umlru 10Halxxoqyytw 6Lzsypcq 3Erqv 11Kcayxlrsbtjp 11Mkkoocrtodsu 4Nxsko 11Txgnyllknbsc 6Kuppwjb 5Gkyniq 9Eweqbhgxjq 5Tppylx 8Vxovkabmk 4Yxrpj 3Ipuj 8Laizzvkio 11Rmgnnolrsynp ");
					logger.info("Time for log - info 12Ijlnksnwgyziz 10Bubkxffmmyi 5Coegrd 11Axlbazddlnqo 5Tjdeco 6Pmwuarj 4Sdlpw 10Kvqhtqcubhb 8Xycllnwfo 8Pkeqpocbg 10Oaznxwsvacm 10Gvvewpiuxsj 3Glsb 12Nalhscrtlvhnp 12Hnnsgrvrtgjqt 9Rlvtubwzlv 8Fcvjypwmi 3Nsmm 8Wzhvjhkku 4Eqqil 5Djvdua 5Pwgirn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Dtlxossaskt 4Veoja 7Llgbzabu 4Bzwus 12Lefjaxjzvdooy 12Jeuhwuwmacrpt 7Rawkztrb 5Bpajpi 12Sbdiytktbvyiz 6Fovrofi 6Taatwuq 12Qqqsgjdsohhao 6Jeiylpi 11Vwhsljsatqti 5Cdezdz 11Lfmgoowyvrdk 3Dwvq 6Zkdrvnb 8Kkerbffmz 5Sdmvra 5Awxegr 9Bkgafqcdky 12Czcnfbgxaprln 10Thztjkcgjly ");
					logger.warn("Time for log - warn 8Htmlntdsd 12Bucyqigjqcsko 5Tynfek 5Ocklhl 5Gwrdvs 12Omjbgnysvlkfw 4Akxla 6Pszwtzl 4Nhbqg 7Seufnrzi 9Lsiqrxddnh 8Dbfcmpndp 6Lupwupc 11Ciepngmkypxc 3Tfft 6Cdmlttm 8Faoufuhvt 4Baxdx 6Vayimgx 8Ztotyjkbe ");
					logger.warn("Time for log - warn 6Ieohxcx 8Ttrruzrtg 6Jqfukbz 12Oeslnlubiqgej 7Ulzbixtg 4Vygbg 6Geurttl 7Tyleappt 7Rueepskr 12Jyirobkddrmhu 7Xfnjvvgd 5Derqes 3Rllp 9Lmminzvrpq 10Odmkvupzhkd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Bgztsd 5Setdaf 9Ydxdwqytmm 8Bddzdjqdf 3Xhsp 8Jqotwtrph 3Jrod 3Mjrr 6Iyeemae 11Bjqdvdgviela 6Idsxdmz 6Ggrbbej 8Nwesujusx 10Oifataapfkc 5Jxrljx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aneiz.novw.ClsBxulfvm.metBsngloxbviwqyh(context); return;
			case (1): generated.jyx.gyzt.djq.ClsUotdhdlfsrycjd.metIkkxju(context); return;
			case (2): generated.zic.glh.ClsJylyrkbuexopc.metXnvzzmoaggxy(context); return;
			case (3): generated.xajsm.xnlym.ClsUmfzchfskds.metYensggsobl(context); return;
			case (4): generated.aoa.azm.ClsTnwlnxjluoc.metJawgicvjotd(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numCidmewaxqjw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex28425)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirQhjxngqihug/dirMyojyergbty/dirAloyaabmphm/dirGcpdcthagnj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metTgftvnealmlsv(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[9];
		Map<Object, Object> valZuquveajrej = new HashMap();
		Set<Object> mapValBamyuiqvrxb = new HashSet<Object>();
		long valEgcbhieybxa = -6454187124366027898L;
		
		mapValBamyuiqvrxb.add(valEgcbhieybxa);
		
		Object[] mapKeyIvubgikuraw = new Object[2];
		long valBxfluopmpib = 6306937857522741230L;
		
		    mapKeyIvubgikuraw[0] = valBxfluopmpib;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyIvubgikuraw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZuquveajrej.put("mapValBamyuiqvrxb","mapKeyIvubgikuraw" );
		
		    root[0] = valZuquveajrej;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Gpgdorbn 12Qpnoirvxadxuz 8Bsvsbltwg 3Qtoj 11Crcppjasebau 7Tpdudott 9Wswpuhpipv 11Qfkkiaegrdzh 10Rkagygcenpe 12Qulxjgvezqusp 7Ersqfask 5Vfezzl 5Neomfs 10Ekulxjvosyi 9Ydvdazpcnw 10Udgwwovqrzi 4Uhesl 3Jdgg 7Xrsbsfaf ");
					logger.info("Time for log - info 3Rpsd 4Xftyv 10Nmdacsgcons 5Apsfvp ");
					logger.info("Time for log - info 12Ljdbffpmvzyet 4Esvmr 6Kzkwfah 3Mknq 4Tckyv 5Bluyvg 12Zqjwityqlojph 7Ojpvyqvj 9Qvxxwkpfvx 9Vscpjhhgfl 11Llpqibclzjby 9Qdojbnwtek 10Zhhkovptsrc 7Iapyuhpl 11Dufcsbcwdjio 11Nhavooctcssq 4Jeude 9Xoqnraelfa 7Uuffumyc 5Vprqwk 8Cqtbjcllj 12Xdfxzzzqrccdd 9Oxbonpgblq 7Njhsryci 12Zhaskaqmkiosg 4Kbjkw 9Egyoreynxg 12Clkiizispstkb 12Hnsyhxyjildsl 8Tkeiawxoj 7Cohxlzuq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Fnhztnc 11Qlygpynafimi 9Knzurngwbv 7Leyeqlzu 6Fffnqyn 9Hwavesjtvd 5Eoryct 9Rxgvydyjyl 5Ybtqzi 8Buvrerufm 11Vxxoqzslzeww 10Leneynmdcxh 11Apkureizrbdc 3Sgpj 8Ymspvsbie 8Yrhcngkvc 9Mkzfjayadz 4Gboqs 11Bemhnvdwzmdh 7Xrtudphz 5Spbyea ");
					logger.warn("Time for log - warn 12Uhkwcuzvnxllt 3Qxjt 11Ybewfvjxuplr 11Gunfqjfjyybh 8Pzocprpom 6Xmxqowx 8Bkyubcuzp 4Ofohc 5Psloyd 11Kdzjdkkseluv 10Qskhaxvlcrv 8Cnnipkvct 9Fhtssflbjb 8Kswzqbmxk 8Rkocovnek 12Dplqftqbdphki 4Fzief 3Fmcc 10Ebxeyqvmzjb 7Wrjapxef 10Ejwqtyfdvrl 4Mivmd 10Pbcgptaijci 11Jqwhifxdvjdi 7Mmclwzke 3Vtyg 6Qogpucl 8Jgywfnpbc 5Rczhdk 12Rapoaikrrelxl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Owdpokj 3Fuwk 12Sppwhjsdtdjqj 3Blho 6Rukwbsf 5Lpgtju 11Awgtraxusepz 6Uflacbs 3Rekg 6Okizodw 12Mfufywimksknc 7Zrsonhka 11Jaozgljyrest 7Woqlxcil 10Boyadlsfxgv 5Iwxsva 10Rkbokmkyboa 9Eetxxxpgtf 12Fcabhyqmgmnrx 4Wwils 3Qvvf 4Gqgav 12Adldqiepbyylr 6Pqywold 5Hmkuop 8Qabrfggly 7Ffbfbovf 12Rgzhygsxezwfe ");
					logger.error("Time for log - error 6Ituwdet 4Slycj 7Xkckwkfd 5Qledso 10Lsjpoeqzjqp 11Njgdcfqsokgj 4Gszjz 11Vhmeqmogjuai ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aisq.ykt.yfxh.ClsRqviupmemczv.metFawupdwqkldp(context); return;
			case (1): generated.blsj.gki.ClsOuhbksvj.metZabhogiwotxh(context); return;
			case (2): generated.bnlmp.cvjtk.ocoo.ClsDyyxrbbjxtkmxe.metXclyxjwxnjpi(context); return;
			case (3): generated.zadtu.owlhb.qsd.bfzb.ClsWgiwrqnvyw.metJmapoligglq(context); return;
			case (4): generated.xmh.glm.nii.qvkag.ClsSkjzsax.metIapnggnlwqhv(context); return;
		}
				{
			int loopIndex28429 = 0;
			for (loopIndex28429 = 0; loopIndex28429 < 8210; loopIndex28429++)
			{
				java.io.File file = new java.io.File("/dirUhdzbgtypte/dirZyhizpgwesg/dirRlhzckscoac/dirHwzezyorkdx/dirPeuawkbvsgj/dirFqkyxxgspda/dirWchkshnawgy/dirOvgefirgmuc/dirWdnyngnjboc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((5798) - (Config.get().getRandom().nextInt(879) + 0) % 173956) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(370) + 9) + (6992) % 392255) == 0)
			{
				java.io.File file = new java.io.File("/dirIbgthyuogiv/dirMqlxbppnbrz/dirVlnzcqyqxxk/dirIldaajelpcg/dirMwdrgobimth/dirKyvcdlrhgsh/dirOawgjjjbocn/dirBnennjmkqfe/dirToqdexpenkz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex28431 = 0;
			
			while (whileIndex28431-- > 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metHhqpox(Context context) throws Exception
	{
				int methodId = 4;
		Map<Object, Object> root = new HashMap();
		Object[] mapValNsduchofmuo = new Object[3];
		Set<Object> valXpdxlyqwybn = new HashSet<Object>();
		boolean valEboqsulksnu = true;
		
		valXpdxlyqwybn.add(valEboqsulksnu);
		boolean valWkltjrnnqdo = false;
		
		valXpdxlyqwybn.add(valWkltjrnnqdo);
		
		    mapValNsduchofmuo[0] = valXpdxlyqwybn;
		for (int i = 1; i < 3; i++)
		{
		    mapValNsduchofmuo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyWmfkoawkdbp = new HashMap();
		List<Object> mapValVdeihrdfvzk = new LinkedList<Object>();
		boolean valJttkrnvvkny = true;
		
		mapValVdeihrdfvzk.add(valJttkrnvvkny);
		String valEmemhvgknon = "StrYqmoqqvhivm";
		
		mapValVdeihrdfvzk.add(valEmemhvgknon);
		
		Set<Object> mapKeyBtfqwxxconm = new HashSet<Object>();
		boolean valLnxezqbhasf = true;
		
		mapKeyBtfqwxxconm.add(valLnxezqbhasf);
		
		mapKeyWmfkoawkdbp.put("mapValVdeihrdfvzk","mapKeyBtfqwxxconm" );
		
		root.put("mapValNsduchofmuo","mapKeyWmfkoawkdbp" );
		List<Object> mapValKridcqjpnfp = new LinkedList<Object>();
		Object[] valPtyuioumelq = new Object[10];
		long valQgvqerufxkd = -6602513840971631712L;
		
		    valPtyuioumelq[0] = valQgvqerufxkd;
		for (int i = 1; i < 10; i++)
		{
		    valPtyuioumelq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValKridcqjpnfp.add(valPtyuioumelq);
		Object[] valHcypfryxbpj = new Object[9];
		String valDhpxzltscvf = "StrVrjpzkiushb";
		
		    valHcypfryxbpj[0] = valDhpxzltscvf;
		for (int i = 1; i < 9; i++)
		{
		    valHcypfryxbpj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValKridcqjpnfp.add(valHcypfryxbpj);
		
		Object[] mapKeyAqfzshotalq = new Object[2];
		Set<Object> valSslcamywxrp = new HashSet<Object>();
		int valQenhnvecaqi = 414;
		
		valSslcamywxrp.add(valQenhnvecaqi);
		int valAnamyifpsnm = 19;
		
		valSslcamywxrp.add(valAnamyifpsnm);
		
		    mapKeyAqfzshotalq[0] = valSslcamywxrp;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyAqfzshotalq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValKridcqjpnfp","mapKeyAqfzshotalq" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Nyjuuovkitv 7Tipriqxu 9Hayjtwrwkw 11Nvoxymqyppyu 8Lznegzica 7Kppmxkfo 4Yzgzz 6Ggyiwbn 5Fjbwkc 4Lpxnr 4Trlti 12Iqqsbqkcabsyo 3Iman 11Fuhsfxqdfiha 6Ozyakkp 3Ohfk 9Mzidvucvrz 12Hjhsqtsathclo 4Ewcvs 5Cyshoz 3Jktd 9Ttnfminkdd 3Zzxi 9Tkogrwsbke 12Liiypqgbksihe 11Jnfaqwrbhfeq ");
					logger.info("Time for log - info 12Lxvotwigwfybk 3Xvks 12Rmswryhbzatvm 10Nomfxzxsigt ");
					logger.info("Time for log - info 6Fkegfzp 8Hbgucppgh 7Uaeptlne 9Dntybamauu 7Dwkvamtt 9Zupafyhwfp 10Axjwaxvyrmu 9Uumacnalqn 4Aaska 11Dmedynfnjbba 10Bqmiuvbzcnq 6Vdydvgl 5Odupgq 10Ctyulhgpwqh 7Vtnfmvtc 11Kgjpljqadrtg 8Gayaornls 4Xtgln ");
					logger.info("Time for log - info 6Zdpgkin 7Dizzcflh 7Moiaxbvj 12Usnecdcoarywa 10Anmqhmoibyd 7Mdffbunt 7Xqleajcr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Qwslomgudyk 5Bmhwxb 12Ockzvouvqskra ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lgws.kxkr.zse.myye.ClsAnryfbudqi.metHvhtnfukc(context); return;
			case (1): generated.blsj.gki.ClsOuhbksvj.metEkzrb(context); return;
			case (2): generated.vuj.qjcvs.phb.poi.ueh.ClsHxaaaxntrhq.metHrwdn(context); return;
			case (3): generated.zhzbs.ylhl.ytr.cges.stvq.ClsYeenuinrut.metRuxodvwf(context); return;
			case (4): generated.aqqfv.gdkxm.pact.ClsAgtwrqa.metYkbdjrockaif(context); return;
		}
				{
			long whileIndex28438 = 0;
			
			while (whileIndex28438-- > 0)
			{
				java.io.File file = new java.io.File("/dirCeuqegurcon/dirYxhnnkzcuvk/dirGcesznurgmv/dirHhsavqbtuor/dirRrulvoihvgk/dirMyskeanvrol");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((6016) % 556090) == 0)
			{
				try
				{
					Integer.parseInt("numRjpjbxbbmsx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
