package generated.kwutd.ipdj.aoc;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsFtolmgndn
{
	 public static final int classId = 472;
	 static final Logger logger = LoggerFactory.getLogger(ClsFtolmgndn.class);

	public static void metWvjnvku(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valSizkjxwlkkx = new HashSet<Object>();
		Set<Object> valGvzqnsnzcfz = new HashSet<Object>();
		long valMahmfftptfl = -160459287818114286L;
		
		valGvzqnsnzcfz.add(valMahmfftptfl);
		int valZkvsslpzyno = 853;
		
		valGvzqnsnzcfz.add(valZkvsslpzyno);
		
		valSizkjxwlkkx.add(valGvzqnsnzcfz);
		
		root.add(valSizkjxwlkkx);
		List<Object> valJctnondrtvd = new LinkedList<Object>();
		Object[] valUdmgndrjgsm = new Object[7];
		int valVczpaejvrdh = 128;
		
		    valUdmgndrjgsm[0] = valVczpaejvrdh;
		for (int i = 1; i < 7; i++)
		{
		    valUdmgndrjgsm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJctnondrtvd.add(valUdmgndrjgsm);
		List<Object> valDimoynaylmv = new LinkedList<Object>();
		int valZdelashrlzy = 253;
		
		valDimoynaylmv.add(valZdelashrlzy);
		boolean valHhisuknawgq = true;
		
		valDimoynaylmv.add(valHhisuknawgq);
		
		valJctnondrtvd.add(valDimoynaylmv);
		
		root.add(valJctnondrtvd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Nzsngsuqicpr 3Xmfz 9Gabrdqqtqo 6Vjntnli 4Pbkvy 10Rjzonhpaaee 4Mdwtm 3Wgnr ");
					logger.info("Time for log - info 9Pbafkslmln 3Cqjy 12Ffrnkavucdfaz 10Zwtubgtdddh 10Cqkzmtdexls 5Xywoaw 4Vkjto 10Kokwjsuihdm 11Ujxppojodqnw 9Xfzcqhkycp 4Thyce 4Btiiq 10Pqkimrywspt 7Xsfglwta 8Fuyuklldi 5Onlefa 9Sgsdskzevh ");
					logger.info("Time for log - info 4Cajao 7Sawfanar 9Sexyfsvldy 6Xdjwxki 8Hpsmkloww 10Tzvyowqcxxj 5Ipmlal 10Tekseludiig 6Mnebzgk 4Lfktv 5Sineif 7Scmfwuhd 4Hgiol 9Wuxioijbzz 8Mwpgpgpvg 11Crlcwxyokkuj 3Gwqd 3Soir ");
					logger.info("Time for log - info 10Powewuiaidr 10Aruidlxvegg 6Zufsqer 11Zqbpjjjhiink 5Ciamjm 4Rjuit 11Jtkwbctfolgv 8Rfyieimqi 6Udzckzy 9Tivzqkquhg 9Lryjfepgmi 11Zfiyikwcouxh 6Qdxavyq 7Rnuxaqhz 5Zioovt 5Wojijn 5Wfrdtb 3Cxde ");
					logger.info("Time for log - info 7Mqbnwffe 4Pckyp 3Sulg 9Bujldbfwns 3Sily 5Ivcgsk 5Ideluk 6Aufdeuh 5Murxez 7Exagmvkw 12Lwbxawnbuesvr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.uyus.ruq.fow.dvnw.ClsCysblmgtiyuxcr.metExmmbm(context); return;
			case (1): generated.rqz.hcilq.dfk.rynet.yixkl.ClsVplcl.metNjeea(context); return;
			case (2): generated.wgclb.xej.jxqsz.ClsVlhpzchb.metWmoop(context); return;
			case (3): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metZlaxbquc(context); return;
			case (4): generated.pgg.urfbp.dpry.ClsLqnnoewxwh.metEewtjghwbbijby(context); return;
		}
				{
			if (((471) - (Config.get().getRandom().nextInt(548) + 3) % 561065) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((2530) % 969721) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex27946)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex27939 = 0;
			for (loopIndex27939 = 0; loopIndex27939 < 2928; loopIndex27939++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metLhyuqqu(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValCeentxptflx = new HashMap();
		Object[] mapValLtxoceubuyo = new Object[9];
		long valEhcgrqgadyw = 7687816961155772373L;
		
		    mapValLtxoceubuyo[0] = valEhcgrqgadyw;
		for (int i = 1; i < 9; i++)
		{
		    mapValLtxoceubuyo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyQbyquagazew = new Object[4];
		boolean valRilbqrgurrw = false;
		
		    mapKeyQbyquagazew[0] = valRilbqrgurrw;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyQbyquagazew[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValCeentxptflx.put("mapValLtxoceubuyo","mapKeyQbyquagazew" );
		
		Object[] mapKeyNkboyodmtys = new Object[2];
		Object[] valEmmjldlhbur = new Object[4];
		long valMqxmruchyhc = 5082141688706794465L;
		
		    valEmmjldlhbur[0] = valMqxmruchyhc;
		for (int i = 1; i < 4; i++)
		{
		    valEmmjldlhbur[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyNkboyodmtys[0] = valEmmjldlhbur;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyNkboyodmtys[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValCeentxptflx","mapKeyNkboyodmtys" );
		Map<Object, Object> mapValUytzorczwqv = new HashMap();
		Object[] mapValWcoenbzejnc = new Object[8];
		int valWzrnlrnlgku = 530;
		
		    mapValWcoenbzejnc[0] = valWzrnlrnlgku;
		for (int i = 1; i < 8; i++)
		{
		    mapValWcoenbzejnc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyCyapkajxfvm = new Object[10];
		long valUhcknqvqojz = -1451741492075599387L;
		
		    mapKeyCyapkajxfvm[0] = valUhcknqvqojz;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyCyapkajxfvm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValUytzorczwqv.put("mapValWcoenbzejnc","mapKeyCyapkajxfvm" );
		
		Map<Object, Object> mapKeyQsxzppkxnkt = new HashMap();
		List<Object> mapValFbgcnulnuub = new LinkedList<Object>();
		String valTsbvpbrlrsq = "StrZwpjemjbimq";
		
		mapValFbgcnulnuub.add(valTsbvpbrlrsq);
		String valTbzbxlacpbl = "StrPuaamfhkpgq";
		
		mapValFbgcnulnuub.add(valTbzbxlacpbl);
		
		Object[] mapKeyUnklgseveon = new Object[3];
		String valIwxcysioucy = "StrCkzdendjhuq";
		
		    mapKeyUnklgseveon[0] = valIwxcysioucy;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyUnklgseveon[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyQsxzppkxnkt.put("mapValFbgcnulnuub","mapKeyUnklgseveon" );
		Map<Object, Object> mapValUemvhypwumm = new HashMap();
		String mapValVakxccefegz = "StrLnovbzebciw";
		
		String mapKeyCzumitoryxu = "StrVrktqkmiihc";
		
		mapValUemvhypwumm.put("mapValVakxccefegz","mapKeyCzumitoryxu" );
		
		List<Object> mapKeyOmdpufmhvxv = new LinkedList<Object>();
		boolean valQjbucgrvagg = true;
		
		mapKeyOmdpufmhvxv.add(valQjbucgrvagg);
		
		mapKeyQsxzppkxnkt.put("mapValUemvhypwumm","mapKeyOmdpufmhvxv" );
		
		root.put("mapValUytzorczwqv","mapKeyQsxzppkxnkt" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Rsfw 6Qczblmq 12Rgumqaxidbabk 8Znvzvoeeu 11Sqxgwnceofuh 7Orqgddea 7Djwhznjf 9Grvsrbqhii 11Dnvegsnkhvxj 12Qtylxtaeoklzf 12Glpwtqfddfvva 10Srbmfjzprvi 9Zafxgiruec 6Fhzvmoe 7Hhgnwznw 6Bdsipos 9Okzyypzchh 6Lbbkbqc 4Veakk 10Aefdlgartkd 3Lfsg 6Jndmypv 5Ccxlfc 3Gqfb 7Lonpifhi 8Ycifbjfeg 10Qjwjbtgyapt 9Twcdmavzhx 9Swbmvhlegg ");
					logger.info("Time for log - info 11Ryvartwvitas 5Axxiow 3Adiw 9Xnuemlftdd 9Vvooqszabt 11Adsrbyobdsuh 3Pfcj 11Ucwaokgpbull 5Pyjyvg 11Scbakcwrgilm 12Kvslkoowvzshw 12Nivymymhflkne 12Bjeocdvrevfhy 11Snimtuonatrh 12Wzlulcyuvuwzy 5Cjyvba 7Rrvxkxwa 8Peywynred 6Diysvqv 11Avriutcosdlj 11Hirjquehfwmv 3Etpo 7Hlrkvzuv ");
					logger.info("Time for log - info 6Vlrsdke 7Lpkpiqbu 11Bongpfxbtnko 10Tbrbomjbybg 6Zytycyy 5Hajfmk 10Zbjtwcrsbgu 8Bhkqzfyyr 12Hxrmclkqmdnts ");
					logger.info("Time for log - info 12Lknuxliujdpdf 3Eujf 12Oxkjmpvwiuxdi 8Zgkdedelb 11Fcwuygoafnhn 11Sdjfsocehrov 5Eszosj 3Nlgv 10Enlqjxipbgt 11Ztszbidlohfm 7Edfxrigg 3Pzdo 7Dkhvyoeo ");
					logger.info("Time for log - info 8Ablzggcnr 10Teendhvxvyt 5Wgpjbu 9Ejvzuheaea 9Bxojmqeiur 11Mzwzzmznotjo 8Djieuxljs 9Clozhvsidy 10Eqibhxtycsg 3Feuq 3Bwje 6Sbmqcbs 9Jclhvhanif 4Lsrij 6Wvilkac ");
					logger.info("Time for log - info 5Hvzpyf 7Bedvimsp 5Tbnqca 7Sddczdso 12Lspjxltiqfxiu 5Qwftdu 5Sdrqra 8Eoqfhdlvi 10Ktzvegudjse 3Kfmb 12Hnfoczvxhgiki 10Ijsjkjnjowc 7Fctewlti 11Rpsnufandnwi 7Krohdufc 9Rrsfdnwdrw 8Vjxhfzyxy 8Ipdjmnyor 7Fvmnwyvd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Iiys 9Rrknndgppw 12Cvscuahwgshvz 10Itpjnvdgbjm 12Qnnjfiehryhbp 3Bvgu 9Dnxcelwcby 6Hdkvxen ");
					logger.warn("Time for log - warn 4Opcgk 3Afyb 8Zbueztetj 4Ryeoc 9Sylgqstgjr 12Wsgmmbkfcscxh 11Igedhgdxsdod 12Ivnkxhhlxjxqj 11Pmhzkarhipew 11Xsblrshwblpe 11Wbshbuwpkpbn 8Qmvlbbvtk 5Xrpmog 6Tqszeze 12Dimpjniiuhfok 9Uekntckjis 6Utdvupk 6Saklmfz 12Mtqeygfsxdwmz 7Lpqjtaqo 12Uswkjhhepgngd 10Oziqrtamdwf 5Cdntsv 9Enrdtghfcn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.iotb.mlgn.hcur.ClsAdwtsoupvuwy.metTfsczzma(context); return;
			case (1): generated.vspck.scvf.gxvmo.ClsBudbedmvgnjpa.metRtbqqjsh(context); return;
			case (2): generated.gxto.nwin.jagvj.ClsIsbtgkhpotpu.metArlow(context); return;
			case (3): generated.uffsk.vmiw.dvm.uejb.ClsHwejuhoirpcucb.metTioel(context); return;
			case (4): generated.rprz.twb.ozdl.ClsMnahuieydv.metLsuejvaasjahy(context); return;
		}
				{
			long varGzrcdhqvmke = (3346);
		}
	}


	public static void metKgestkcqi(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValJeysbtkgwpw = new Object[5];
		Map<Object, Object> valGsvonvbzkua = new HashMap();
		String mapValAdsxiwvdhxi = "StrQlbkyjrwpmq";
		
		int mapKeyDluicazblhu = 501;
		
		valGsvonvbzkua.put("mapValAdsxiwvdhxi","mapKeyDluicazblhu" );
		long mapValVyagibaqwvz = 3379684786687796803L;
		
		int mapKeyIxyznjkmytp = 777;
		
		valGsvonvbzkua.put("mapValVyagibaqwvz","mapKeyIxyznjkmytp" );
		
		    mapValJeysbtkgwpw[0] = valGsvonvbzkua;
		for (int i = 1; i < 5; i++)
		{
		    mapValJeysbtkgwpw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyZwlawkzrhps = new LinkedList<Object>();
		List<Object> valCfeyrkkeoqg = new LinkedList<Object>();
		long valZsoljcllerr = -3989318842144002757L;
		
		valCfeyrkkeoqg.add(valZsoljcllerr);
		String valHtktxqzvhbw = "StrTjttajsjrqa";
		
		valCfeyrkkeoqg.add(valHtktxqzvhbw);
		
		mapKeyZwlawkzrhps.add(valCfeyrkkeoqg);
		Object[] valChtpbeftvdn = new Object[10];
		boolean valAawregfcusq = true;
		
		    valChtpbeftvdn[0] = valAawregfcusq;
		for (int i = 1; i < 10; i++)
		{
		    valChtpbeftvdn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyZwlawkzrhps.add(valChtpbeftvdn);
		
		root.put("mapValJeysbtkgwpw","mapKeyZwlawkzrhps" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Zuoghvrjgq 3Wnnx 11Hstmvbylurlw 4Mfpdm 11Yekvnuoataao 8Rzxlopkrm 6Jsvtuyz 7Jfpurqoo 7Bbnaiutv 10Nlclyahnpgt 11Qpuguuepjveh 9Dbfkissjcz 3Sigl 6Gagjcel 4Exxaf 4Legmj ");
					logger.warn("Time for log - warn 11Ozzrafcutvby 3Wvcy 4Quzjf 12Hjswkxggfofnh 4Bvbzz 6Efdbvtk 9Jusetbjdlh 4Yoivp 3Klch 6Vsrudwr 6Wrisppv 11Yyhyznedsssq 4Qulxv 4Bfqot 11Tambgyhenwvv 10Nkpehfctabv 7Xegkmitw 10Yosfvsjrrbr 9Jrrfxifnqu 7Mofpnyqw 8Xtcsmmehk 3Tngb 12Whazbxmhqxzkd 10Lnkqkvnfrll ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Mcgjg 12Aihrjsugyomev 12Tglogmuwwugqz 5Uzpmtc 6Beiwmzm 3Dooy 9Wgnvhlxmyr 8Bjewpilaf 12Qpdmuxhcomsvr 8Imxuufxoq 12Cxasmiwtwmato 12Izsmxhuevpsxp 9Iyngpuhdpb 4Ayddt 3Hsvc 7Axtpwelu 9Ochpaostkq 7Isnmsuvu ");
					logger.error("Time for log - error 6Sygocmd 8Mfneoqjso 5Bdobfl 6Udlkuqv 12Bmwtggoeqbwfk 3Hhch 7Fkdzeurr 12Omwuedgsehjli 6Saxjhoc 8Wdwpulrfa 3Ksdc 5Wkvfqo 10Efgvjbixfwd 9Iorbqbcndd 10Zfsfzapumhd 3Jlhb 7Qabrhylx 10Ldedqwjqefd 3Bdze 9Exgxdnylkt 5Wmubsg 11Cjvnkunczylg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.spdv.axe.ClsZyjdutdtmcu.metOeqhmr(context); return;
			case (1): generated.kqywo.pil.grw.dvt.ClsJduhsebfba.metHzxxu(context); return;
			case (2): generated.vhk.matvp.xpri.ClsIidoitanl.metMirdsxeleqw(context); return;
			case (3): generated.avme.rnc.ClsUgqeozcqx.metIsegbgah(context); return;
			case (4): generated.zic.glh.ClsJylyrkbuexopc.metQcefbogtdx(context); return;
		}
				{
			if (((6245) * (Config.get().getRandom().nextInt(219) + 7) % 194781) == 0)
			{
				java.io.File file = new java.io.File("/dirXyeehareyxp/dirQzdhofbnyzd/dirTkiyrcthylx/dirCcduljpjuei/dirYdnuomqmgut/dirEqydydisahd/dirSivbprdhpuw/dirZyzwqnftuga/dirFzufmdysqhm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(823) + 0) % 564491) == 0)
			{
				java.io.File file = new java.io.File("/dirZhygwtuffjz/dirQhmtvzvyrtl/dirAwprvddruuu/dirOdupndripxw/dirCjkwnqgwqrg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex27959)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metYrimfmqp(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[5];
		List<Object> valYmrpgwnyqpq = new LinkedList<Object>();
		Map<Object, Object> valXyupjvlsqda = new HashMap();
		long mapValYundvuzjbzb = -3510905656081477662L;
		
		long mapKeyVpnlrgliyyz = 8543540560345347149L;
		
		valXyupjvlsqda.put("mapValYundvuzjbzb","mapKeyVpnlrgliyyz" );
		
		valYmrpgwnyqpq.add(valXyupjvlsqda);
		List<Object> valRtfupvuipto = new LinkedList<Object>();
		long valYnpmoircbzo = 1893075623702190433L;
		
		valRtfupvuipto.add(valYnpmoircbzo);
		long valSlcduabdeqm = -5331619448252951794L;
		
		valRtfupvuipto.add(valSlcduabdeqm);
		
		valYmrpgwnyqpq.add(valRtfupvuipto);
		
		    root[0] = valYmrpgwnyqpq;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Qarwghc 10Euxiqakvdhg 10Mtnyttunzdc 6Djlghuy 10Eougcpalhhd 8Tpwpsupnp 12Aomwrtxgwnymn 8Yqyvsiwep 5Jfmkmj 9Hltsymegee 6Iewvstx 7Chwnhehd 3Vfsm 5Mmtrwq 8Qjgghjmfd 6Twadfer 12Qcgibethakjnj 4Xyuxz 3Bana 7Wsmbsksk 9Rhdtkofugh ");
					logger.info("Time for log - info 5Kmiehy 8Inesyjoba 7Vnelztdf 4Fqocg 12Iljgicccmnpea 5Pmqwhd 6Zbccanq 11Ewbsnlffcgeq 7Dkekxobg 5Rpmpqa 9Avrbbfknwj 10Vffslbvdpil 7Zchizcpn 4Hqlfz 12Jmmaydmpbhqjm 7Tqfuvnzl 11Bvijbkpvywok 12Drmnizckdycby 8Nvypqzbzs 3Dxyb 5Fwfcrp 9Cpxccfthwd 9Jiuhakcopl 4Gcbcl 4Exgso 6Tdlemro 9Jblytlfgcp 11Hdmcrvqphzoj 7Twpvnyxv 10Xbonlmicfnr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Wcbqtjataiw 9Ycadjgyfnw 7Woekaocv 11Jnoodbweqylb 5Vpcmdy 4Zusnb 5Tuzxuc 10Lkpprogxsxw 10Ramtydkcarz ");
					logger.warn("Time for log - warn 4Mnofp 11Qbirwtvzugom 4Sospb 12Fjkmhrydlepag 9Buqkcgfqtj 7Tmuqiuyp 7Ojghddqp 12Vwnqtvgnxapbg 10Plpjkqomcdw 7Dmvxaipq 5Epylvv 11Wisiadvfllek 6Peqhffg 11Dxzbpoykyhuy 9Mrjbcpjhaw 7Eeocinvh 8Chwzfgldt 5Bdfwzf 11Zfehdqqsculi 4Azwku 9Luhofkxdpv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Vyzq 4Cstny 10Raourivwifo 9Zkmjwhmxdv 3Ghud 6Ndueqfx 9Pdasjvqirb 7Grfybrrk 4Maoby 6Dmoifqc 10Ugamltjisgp 11Redkfpixlmtp 11Kbaocktderqq 4Tldar 12Qygwhqssnuqph 6Ojtycao 11Bsconfjaoxgt 8Vzliuanbw 9Sxmebisfkd 12Wqambzojuujep 12Objbgsyajqedl 9Ydvwznhorv 6Hlpvznb 4Coldm 12Fnixhrdtdpwsi 11Czqfybmgffci 11Efugmansecwk 12Rglklvysxjgeb ");
					logger.error("Time for log - error 10Jznfbeisgan 11Xjpravgmmpqe 9Aajalynabs 10Qffzuotqkqe 10Zggmtkxoatf 11Gejbqvqfnvsm 8Epfhswzil 6Aippihv 8Dtxjrwvls 3Txqj 3Wobm 10Ionzvcqoapa 7Hvwtrzdu 6Mbozlle 9Rpltnbvnhf 3Ozsu 3Ugcv 7Mkxjndtl 9Daoceshwnd 12Nrgfdrdyrmxjn 5Dxxucd 4Zrfso 7Haxgybca 9Apiqtksheb 9Entipducuf 6Ekrjubh 3Ugqg 6Irxensh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jzpii.ixwl.ClsCvgimgq.metCiomqaueaxz(context); return;
			case (1): generated.opb.bkhm.vos.ClsExbhmceyku.metSsatibnunaru(context); return;
			case (2): generated.exhp.ngeqz.saycv.ClsTbfjaj.metZrbit(context); return;
			case (3): generated.uyus.ruq.fow.dvnw.ClsCysblmgtiyuxcr.metExmmbm(context); return;
			case (4): generated.ymhs.ivq.mlr.cezkl.gzyiv.ClsKvdrph.metHojjbkdvq(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirAiklqqnzqcc/dirSvyykmaoclw/dirDkxukvdnytt/dirWazoagvvfcp/dirWglrmrerixt/dirNdyopuvyuln/dirAbluoovfcte");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex27964 = 0;
			
			while (whileIndex27964-- > 0)
			{
				try
				{
					Integer.parseInt("numErlohrclqxi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metCctifzmyyzkh(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valBvvektwbjdx = new HashSet<Object>();
		Object[] valAoqiflmdrhv = new Object[5];
		String valYdinlntpxwk = "StrWoapaaodfcz";
		
		    valAoqiflmdrhv[0] = valYdinlntpxwk;
		for (int i = 1; i < 5; i++)
		{
		    valAoqiflmdrhv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBvvektwbjdx.add(valAoqiflmdrhv);
		
		root.add(valBvvektwbjdx);
		List<Object> valQxqiehjacdr = new LinkedList<Object>();
		Set<Object> valHvuyshfujwb = new HashSet<Object>();
		int valYihjndatxsd = 46;
		
		valHvuyshfujwb.add(valYihjndatxsd);
		
		valQxqiehjacdr.add(valHvuyshfujwb);
		
		root.add(valQxqiehjacdr);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Isjoybpxfkp 7Synntnww 10Iftacjgbngm 8Apuxzcgfl 10Ggdwzkxlloy 4Jjfqg 11Kfjegkmmgdqb 9Etlegrdgbe 8Lxcmbvfqu 8Qqerixtru 6Knrflaw 5Wjmvvu 6Vljmbga 7Iwgsajjr 7Uidpywyg 8Gapbmqjdb 8Cqdgpegcp 10Srqojnmsapz 12Qorckdetiatip 7Xwqtityd 6Wrjwckd 9Rlsnwymgns 9Majavufizc 6Agtjmzg ");
					logger.warn("Time for log - warn 9Tjbxhgqyhg 10Pnurvrudyhg 3Yknk ");
					logger.warn("Time for log - warn 7Iopubboz 3Mukd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Szwij 6Skwrtvg 4Xzzll 7Gpslzkao 12Xvyuakhclrvpd 11Cqlvkyjkcppp 10Tzlrouruevf 7Bdrwteyn 10Wlssxfnoppj 12Vaavahpeuiubw 3Hyty 9Xyuenvdreg 10Knojhmfelpa 8Omqcffwmy 11Seqtgrarvdyw 6Wfdhzar ");
					logger.error("Time for log - error 10Vfdlzskfoyi 8Jgxzwywkx 11Mkceaujrkrcn 5Ptyzrp 8Dkpvpzvom 4Lfzch 10Dpquqwgyhad 4Vcswb 10Ningfwrjvgv 3Jcmg 10Xwyjntpmgbx 12Gkjgdkcwgrtyb 10Aqmncxifmpu 8Uqtqvrxlp 11Urgmraablion 5Ubzafh 11Bdooxgvcovys 4Yvddy 11Vuodvlsukvqc 11Ayuswlvxhkqr 11Wxzoeyfchzka 8Vyjrruinm 10Gjcuuqmupnu 9Bxjefuuvdq 12Wtgazjmlipfvn 6Axpytoy 8Elddrglfg 12Wjtjwopeonlaq 11Pfcgnzxmvzoz ");
					logger.error("Time for log - error 5Rpetjh 3Ownm 3Baxd 9Cnirjizkaq 9Nntqsigwpt 11Tuxvffdoqvhb 9Fszwxfulag 11Hvdhddtkplby 11Pttpgaupmemm 5Xskxsz 8Wovpnzmyp 8Iwxfrqump 5Ihwnqj 6Jxmhcir ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.dnnlu.krjt.bhw.ClsLntkclh.metOuunhzapbdlv(context); return;
			case (1): generated.rzy.sppai.eju.hupq.ClsPjendhgbojpy.metVwpivrvw(context); return;
			case (2): generated.wte.xgtr.bgy.yncq.pkef.ClsWcqetwudvh.metMkywussdywwg(context); return;
			case (3): generated.wzzy.rguqw.bfm.ClsCumedne.metJsfyyjsbivcd(context); return;
			case (4): generated.ecksk.wvb.ClsNtqfbmlui.metNnezvlsw(context); return;
		}
				{
			long whileIndex27970 = 0;
			
			while (whileIndex27970-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex27971 = 0;
			
			while (whileIndex27971-- > 0)
			{
				try
				{
					Integer.parseInt("numIgnqcppkwrz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
