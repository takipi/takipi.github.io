package generated.idk.jvavb.vjuwp.iuzf.fawz;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsRtwkffyfhbvpjl
{
	 public static final int classId = 149;
	 static final Logger logger = LoggerFactory.getLogger(ClsRtwkffyfhbvpjl.class);

	public static void metJglxxxadpzz(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valKrjrqngenud = new HashSet<Object>();
		Map<Object, Object> valHsurxgrgkyo = new HashMap();
		long mapValHewmevwgeyx = 9037013185812642204L;
		
		String mapKeyCcclxlovijl = "StrQnkrktebmfd";
		
		valHsurxgrgkyo.put("mapValHewmevwgeyx","mapKeyCcclxlovijl" );
		String mapValYcfeyrgrtuo = "StrHkngtaajohk";
		
		boolean mapKeyGmymncxkeeq = true;
		
		valHsurxgrgkyo.put("mapValYcfeyrgrtuo","mapKeyGmymncxkeeq" );
		
		valKrjrqngenud.add(valHsurxgrgkyo);
		
		root.add(valKrjrqngenud);
		Object[] valAtqvycwjvhm = new Object[6];
		Set<Object> valGepsysraijj = new HashSet<Object>();
		String valDekfpqgmxpc = "StrKlttbeuqvnu";
		
		valGepsysraijj.add(valDekfpqgmxpc);
		long valRuddbrjqhrg = -6775430562854078362L;
		
		valGepsysraijj.add(valRuddbrjqhrg);
		
		    valAtqvycwjvhm[0] = valGepsysraijj;
		for (int i = 1; i < 6; i++)
		{
		    valAtqvycwjvhm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valAtqvycwjvhm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Ilxszqncleo 12Fhccuhzunpuic 8Mdedknkvj 12Cpgljpxrcdqsl 4Uiwux 6Plbmwvn 11Vjfqgjrktihr 6Fvsvijk 3Krpg 3Gear 8Fvubfpcxp 5Vwruds 5Bgkirv 9Jdcbziglcl 9Xllbimdlcn 5Eszwdn 5Jqjyxz 11Bomlbahxxstn 11Kltvsooeaoqq 11Luolwrpuxofn 5Dmkitb 9Bisbfvwcuh 5Vuszqa 8Cfpbfhnyt 5Bwgooh 10Ajqpjmxihug 7Wrcqrldx 3Pizf 9Pwcceiwotp ");
					logger.info("Time for log - info 9Ujvfkfjapq 8Jqgxvklsq 10Jfdvgmljnte 3Fqtk 10Hzojsbcwanh 3Ptqa 11Ihdvbmkmpsho 10Cnztxokqiro 7Qyqeqcoq 6Rdssebt 5Hnjqbr 8Grfefqdyl 3Jrzt 7Bbquhtya 5Btphdp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Gpfycnpue 12Dgrkddashpojf 12Wciwwtaspsyfs 11Manizwqudwpa 11Cfquloxevotw 5Xcjwqn 4Jifbj 9Eyadoijqbr 9Bovlovweep 8Kpaubpxeo 11Frzupqivkxqn 7Dgdklkog 9Zbyfgynhbv 8Stkyjfhfm 10Cmhbvwdqded 5Qyfwvw 7Hgjzksll 10Ibikmrqtpqk 3Iuqu 10Mlacoueethg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Cgrxeqku 5Dxflxu 6Njnrqoj 7Tlnipfuw 11Aecpmhtzkdfj 3Acdl 8Kvvmrkmjx 9Qlktfuaxlk 6Rtairhw 11Ltwfmyemdmvf 8Zlxwvlzvu 9Hpxwxhjunc 12Qthgzgjejihnr 9Olvdvejrmk 7Iszliiye 4Zblik 10Ecxofwtztlw 11Sbxliktqmcbx ");
					logger.error("Time for log - error 3Wxit 7Nhpnaxjj 7Nepkkrtn 6Olohiga 4Lqyah 11Sajflslrczmt 6Qgejzbw 6Qfvjivw 5Pnjxpx ");
					logger.error("Time for log - error 3Ejze 11Nrvzzcmymfso 12Exyfernqcxfqw 10Vunwqkrxwjn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hjt.myuvv.hkc.tfpi.ClsJfukwmizredp.metYduwrchx(context); return;
			case (1): generated.loe.helvz.umzz.ClsSvkkzn.metEikqrawh(context); return;
			case (2): generated.reb.nzlh.ClsFjrtwsmg.metFxpwoaoeszaq(context); return;
			case (3): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metEvvtbxshkftg(context); return;
			case (4): generated.kbkqc.quu.lvl.ClsGhopbakrik.metXlfzfoihvptoa(context); return;
		}
				{
			long varOybdydpivlc = (Config.get().getRandom().nextInt(678) + 8) + (Config.get().getRandom().nextInt(82) + 6);
			long varHiliygixotj = (7668);
		}
	}


	public static void metFydywnh(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[8];
		Set<Object> valLvvpmxaogfc = new HashSet<Object>();
		Object[] valAjcvgzesnoe = new Object[5];
		boolean valAaopoqiryah = false;
		
		    valAjcvgzesnoe[0] = valAaopoqiryah;
		for (int i = 1; i < 5; i++)
		{
		    valAjcvgzesnoe[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valLvvpmxaogfc.add(valAjcvgzesnoe);
		List<Object> valCuvunnvoheg = new LinkedList<Object>();
		long valWcehhpzguxj = -1474762156244100426L;
		
		valCuvunnvoheg.add(valWcehhpzguxj);
		
		valLvvpmxaogfc.add(valCuvunnvoheg);
		
		    root[0] = valLvvpmxaogfc;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Fopunfmwwjta 7Wnthqfxo 7Vcupymwy 3Risi 3Uxvd 9Ixcfcdxzom 8Xacagthrh 8Lxyqxfuhp 9Prcuodqdyl 4Tjbhf 12Oanvsidcrtvnp 9Aukbmtazca 12Eeykozukgsaxf 12Cetinkmqfwbne ");
					logger.info("Time for log - info 12Rnmdalhvkjftv 12Tcgtfeyppfyor 12Ammzxmsaiiqid 12Cwgnhlutohxxa 11Xqclxbgoimji 6Gvprmsl 8Rxfdlaapq 9Vudqgfkodu ");
					logger.info("Time for log - info 11Xfihpawarbmp 5Bixmyf 6Zycvmot 8Hvcqevztq 4Ljjde 4Ugxmi 12Cvvrqlguvhozg 3Qnrr 9Roejbxopxq 9Acwdazbwfd 3Afnx 6Cdcsbmi 9Hdovvgzkgw 12Nnzttozshjscw 10Jdfgvanwyfb 5Ehkecm 9Hyxkziiado 5Dpycby 11Xnfjjrqszjne 10Owkxfeeuivk 3Duwu 4Efivh 9Wyxgmrwjwq 10Fhmiflkdvhc 7Tnxqfeqd 6Gmanpyd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Vgekn 10Zgbwdsrnqob 4Mcify 8Arhsbldar 7Vwwhutpl 11Jnsfztuusmbv 8Ymsauafmh 12Ferttgkdmfivh 7Wfsvhhcb 12Acxxlbkzyqssg 12Kwmmtdxlglbsv 6Fcxqlse 5Moxauq ");
					logger.warn("Time for log - warn 7Jomngjwg 11Jhaccbapoabz 5Iuixpx 11Qjdyozeytssq 10Bdxafgqsfdy 6Vtjchuz 10Zfbaoejaqsk 4Zlfvt 4Cqhqn 10Cekrvtzaenm 12Sqrksnturhwwb 7Kpfxletr 10Jrlhqidoebf 11Acfqmoeafqnz 9Fbctkgccrv 11Bwmcvnkycjvp 12Enrwqvqejtews ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Sujl 7Djbsnioi 8Ojwcuthrr 8Htxxyohtg 7Uvayywwh 8Fukwjnvsu 4Hzlas 11Nikwjytmdkad 8Biuccujja 3Engf 5Ktnbib 12Cjwbnssmzbmrj 12Kveglrktpulop 10Ifogkjuwdbg 3Syey 11Umsehxgcuqpm 8Ebyuuepkh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdhb.psopx.ivn.rkn.apqvp.ClsKaatjkanbespks.metLvjabphis(context); return;
			case (1): generated.fzd.qgqjp.ClsVzqqvdhb.metMsjbhqpplani(context); return;
			case (2): generated.ogy.ayf.aijxy.ClsNdoxmvj.metCsqrhmq(context); return;
			case (3): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metWpheeqsxvjk(context); return;
			case (4): generated.svrd.bbp.ClsZenal.metIcwqskzzdn(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirAdecuwgrlny/dirFjhjwhmiqmh/dirPdqndpuicyh/dirWqsewxhbhdr/dirAemthufnsgx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metHdimsltzwuwz(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valLmrguytrfsa = new HashSet<Object>();
		Set<Object> valKlysigmjxry = new HashSet<Object>();
		int valLytxrvzzemi = 459;
		
		valKlysigmjxry.add(valLytxrvzzemi);
		
		valLmrguytrfsa.add(valKlysigmjxry);
		Map<Object, Object> valXlesuoxswli = new HashMap();
		long mapValIpaovbutuig = -3628575728521537266L;
		
		int mapKeyRzemsbcwzwb = 811;
		
		valXlesuoxswli.put("mapValIpaovbutuig","mapKeyRzemsbcwzwb" );
		
		valLmrguytrfsa.add(valXlesuoxswli);
		
		root.add(valLmrguytrfsa);
		List<Object> valHmvhxplggdl = new LinkedList<Object>();
		Map<Object, Object> valXzgslzfwkpj = new HashMap();
		String mapValKzughvkjavp = "StrXxoocntkfux";
		
		String mapKeyBmpkisxggnp = "StrZoqkaconjru";
		
		valXzgslzfwkpj.put("mapValKzughvkjavp","mapKeyBmpkisxggnp" );
		int mapValKqolcrxkbmo = 928;
		
		boolean mapKeyVhvtgvncfar = true;
		
		valXzgslzfwkpj.put("mapValKqolcrxkbmo","mapKeyVhvtgvncfar" );
		
		valHmvhxplggdl.add(valXzgslzfwkpj);
		Set<Object> valXfqjsxowmxm = new HashSet<Object>();
		boolean valCkookiccmvt = true;
		
		valXfqjsxowmxm.add(valCkookiccmvt);
		
		valHmvhxplggdl.add(valXfqjsxowmxm);
		
		root.add(valHmvhxplggdl);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Cgoj 9Uhcnxmfqdo 5Zyybwu 6Sxglonc 4Knlkd 3Ezvr 11Iakoduxupzyv 5Msuibn 7Xerfcaot 8Ubsgjveng 8Fziqrkaof ");
					logger.info("Time for log - info 5Uzqxop 7Oxxjfbvf 8Wwoiqundx 10Bmxxjetgcuu 8Ospomwsco 12Yveztqhhhpnyb 12Qadoyxlttvtut 8Clxmiccfy ");
					logger.info("Time for log - info 12Lumhqkcwilweo 12Jxxouejzgfjzk 10Urudiwanrei 5Lnegxo 8Ckgnrevgl 11Wflqnjdemxvk 10Uhxojmlbpgj 5Ovwrdy 10Semqlldpjlm 10Fohyscwnwfw 9Thujqwpsex 8Xiagmemsw 5Lwypxl 6Jqcxjcl 10Tuyjplbajqv 3Txsd 7Mymurjwg 4Rjirr 8Kuftlwfnb 7Atgnpsrg 12Sgqimflkwshwg 7Ycnyinwm 11Xxxswmjpxjka 5Jwnocr 11Lsqowbqkiyux ");
					logger.info("Time for log - info 12Lcfauwofzrvje 7Kwpdtcod 10Qqlkwdtwngq 5Cjpavg 9Wujejcatef 7Qmxbpeth 12Zcakmhpuiifde 6Fnngwei 11Taeotfnqhuza 4Bjkgr 10Anhuubtacfp 7Zqexnuup 5Giprqo 7Lzfbnevt 10Ksvohbazkbm 11Yfrnnddhnuew 8Ggbawjmna 11Gecytknghvsa 5Dxhrqa 10Eljkghjyuiu 12Ldrfglljcrmqs 4Nhnjg 10Cubkhceodoe 12Ojpsdhlfkuycx 5Bflsbb ");
					logger.info("Time for log - info 11Lwlenxhyxeca 5Sbfpax 7Kxpdtyta 3Bdwq 6Hqfdmmz 6Mbvluqf 7Afwxbrtm 7Uunneghk 10Hkxghrjupln 5Msoyln 4Vubpk 8Qmsazucwf 4Jycjp 10Puwpmrgahik 3Lwjs 5Kkhwbl 3Aras 12Tvqcqrugpsjff 11Vjptocxsaoap 12Julmqyfqrflnn 10Nlxwherebxt 9Auulilefjl 10Afhykcavpun 8Anqpsgqwh 5Sdnkic ");
					logger.info("Time for log - info 11Bscktmbqmehb 12Pezqljkbwaypn 12Enzxugqrijuoj 8Rtybgqrae 4Pgplx 6Dpsegwc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Zzrtwkb 5Lfymel 7Diljhkrr ");
					logger.warn("Time for log - warn 12Cfftrguxeaqjk 4Jhava 6Ffgcksz 12Fbnjomixaktqt 3Dofx 8Hwlmunkfw 8Lmtwufdho 9Zofejavbzc 5Tkyaoy 6Yaipgbh 10Fbrwdlpyzmc 5Kkiseu 5Yiolqk 8Bqsxlgrcq 4Glhwp 9Rxjwncwzfn 7Rewrvyzq 5Fidfgd 4Ijcqg 8Limgphuet 12Wqcrteaqipkzv 11Weojigxoomft 5Jsoegl ");
					logger.warn("Time for log - warn 5Dqegfs 4Fmciu 12Nyusfctrbvyzb ");
					logger.warn("Time for log - warn 11Vwvyzpuvfgkl 6Lqgluvx 4Evtdh 11Ohhurxujhumb 12Oahlvbquzbxnj 9Mqtjhezjik 5Bwyggw 7Eecgapol 4Eijrm 11Fiaboavfugsz 5Fdroec 4Phvnr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.eob.tzj.qiec.ClsEnjcnowop.metRglvwndsjd(context); return;
			case (1): generated.blsj.gki.ClsOuhbksvj.metZabhogiwotxh(context); return;
			case (2): generated.usy.jqyb.aoxm.cmxc.tdb.ClsGdtxkhc.metYudmw(context); return;
			case (3): generated.jcxsg.qox.wcj.hdpzl.nki.ClsNcldofdlyjb.metXbvhtc(context); return;
			case (4): generated.lxab.bkb.mqw.ClsMiouvnamcvsap.metKsjeyneapvdv(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(263) + 7) % 613516) == 0)
			{
				java.io.File file = new java.io.File("/dirZzzhftspvuo");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numNpgxcbwyoyj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metOmoezhsktc(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valQwitldzrols = new HashMap();
		Map<Object, Object> mapValJymycbrejgy = new HashMap();
		long mapValHmlotnjdhaa = 3750361437845993528L;
		
		String mapKeyTqwfdmudcdd = "StrYyugbbydgrd";
		
		mapValJymycbrejgy.put("mapValHmlotnjdhaa","mapKeyTqwfdmudcdd" );
		
		Set<Object> mapKeyMmmogwhlfmx = new HashSet<Object>();
		long valDqumgtjzovb = -8020348754867900824L;
		
		mapKeyMmmogwhlfmx.add(valDqumgtjzovb);
		
		valQwitldzrols.put("mapValJymycbrejgy","mapKeyMmmogwhlfmx" );
		
		root.add(valQwitldzrols);
		Map<Object, Object> valNylcjmrarda = new HashMap();
		Set<Object> mapValQfwupeofmhw = new HashSet<Object>();
		long valVikhmplwbez = -3084947734577429L;
		
		mapValQfwupeofmhw.add(valVikhmplwbez);
		
		Map<Object, Object> mapKeyVfoomxbqpms = new HashMap();
		String mapValRqxdmuaqtjz = "StrYtsinmnpifh";
		
		long mapKeyFymahtjysfc = 2856050480607713512L;
		
		mapKeyVfoomxbqpms.put("mapValRqxdmuaqtjz","mapKeyFymahtjysfc" );
		
		valNylcjmrarda.put("mapValQfwupeofmhw","mapKeyVfoomxbqpms" );
		Map<Object, Object> mapValChpvyoktadv = new HashMap();
		String mapValWliustsqast = "StrJhwocksaohh";
		
		int mapKeyHyshvnobghs = 432;
		
		mapValChpvyoktadv.put("mapValWliustsqast","mapKeyHyshvnobghs" );
		boolean mapValHnebpuesaba = true;
		
		int mapKeyEovxlucrgma = 262;
		
		mapValChpvyoktadv.put("mapValHnebpuesaba","mapKeyEovxlucrgma" );
		
		Object[] mapKeyRdmddmwyqrm = new Object[11];
		boolean valNaowxjyipwv = true;
		
		    mapKeyRdmddmwyqrm[0] = valNaowxjyipwv;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyRdmddmwyqrm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valNylcjmrarda.put("mapValChpvyoktadv","mapKeyRdmddmwyqrm" );
		
		root.add(valNylcjmrarda);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Igplggoowrn 8Vmeqpzjer 4Bbpqc ");
					logger.info("Time for log - info 7Xhyqkonz 8Jtdvrfcfx 4Romdm 10Tawqjpfqpve 10Ndfjtzyrkzu 8Jaxitytyu 12Vomcxrjxiaypa ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Cmnjonbiil 4Tfttm 11Omoburmurxmy 11Qyujhbuedjik 9Uetrcqvmby 8Sbbgfarcj 8Dwwbpiagv 4Hpbam 4Avkkj 5Hqbjld 4Dumje 9Jstvonjjox 12Bgajqodypskjb 12Iwqoibngjurhv 5Epfjkp 12Dvkqqkismizby 3Axbe 8Byychgydf 7Ivzhbceu 5Vigrrx 12Sfqjjkvbjlkkl 11Zcgahwovyqoq ");
					logger.warn("Time for log - warn 11Dzkqkzfrvyqx 8Pscprmmbw 12Xyufxaqyewagj 7Aukkvtvx 11Cdrslsrjmujf 7Csegeiuh 8Hvhubgpzo 8Zmmhbnrcv 10Gmjkagulsqp 9Hnbdwmfvdd 6Qfwblji 6Ikbsnzx 9Johbqbmpvd 7Vdlupdjb 11Izboimrkmltu 7Yucuxesz 9Nvghnyfodc 3Ufec ");
					logger.warn("Time for log - warn 9Qbevkiaone 4Dttiw 11Mayxsudlxutf 9Stjnmfqcdu 5Pbhsrv 4Rtfzj 10Mqpkxzpghzw 5Jqpqkp 4Qnlyb 12Cwjmhthfoefsh 12Tvkgfruagixpe 6Hpftgub 11Nipivefmicxr 12Pxwolkysphpse 5Iyoouo 3Wzyl 4Jritn 8Nkpbjzhnp 7Dyhydawd 7Yjizkfkt 8Xncjtwqrj 8Mpukjvuwm 5Cwcnhg 4Ncihw 6Cbltuzx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Xmpapg 5Juouwj 4Anssb 3Ocvt 7Hdpafdoj 4Eqnfh 11Lhotrzydhkga 12Zfooigdfknmgi 9Vobvffgnev ");
					logger.error("Time for log - error 9Fzcwrhjmdc 7Utocrggp 6Yoyelpb 7Ozechfbe 11Cmmmrzdiydyh 12Dnyimixjgygpy 8Jtpltwvjy 10Jkmzcpehibq 8Eoariuble 9Nufxtbjnbb 3Ryxm 5Tdxrxd 3Dpmj 7Ggckodok 4Hjxku 7Riboekre 5Lexngf 11Vhejajbckrup 10Ujeesmjogzz 6Rwkyktf ");
					logger.error("Time for log - error 7Farljhng 11Atssclmkniio 11Andnaxwtiyvg 7Arphzpwm 7Asvfylxe 10Bbolbryzirx 9Dxbchojjac 7Mpqofqru 12Fmpypptskxntg 6Zxxybxn 3Bepi 3Czvt 11Ynpghvxabufr 6Amwnhvz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gww.spuw.jrq.nmv.xowli.ClsKosigq.metQasyaqoccfnym(context); return;
			case (1): generated.ucgs.cys.qrt.ClsGwmfnzjfaj.metFonacuizikxef(context); return;
			case (2): generated.mvh.wsi.ClsXxvtrnameonpg.metVrdqdrupoen(context); return;
			case (3): generated.deuz.rvz.jsq.ClsHbyckyeswad.metNsroqeuzcfbif(context); return;
			case (4): generated.cxoq.hzjj.hhxu.ClsXfvidhbawjojdu.metGjokxistgrq(context); return;
		}
				{
			if (((6575) * (Config.get().getRandom().nextInt(649) + 2) % 257826) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((795) - (Config.get().getRandom().nextInt(262) + 7) % 35293) == 0)
			{
				try
				{
					Integer.parseInt("numTjvbzlmpowc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirPgrnakujjut/dirWipjuawhauv/dirNyiblxljrht/dirIkylknpudea/dirOykmugdfmor/dirZeemvxhbuci/dirDtqmrpbzmbp/dirHfarltxcotw");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
