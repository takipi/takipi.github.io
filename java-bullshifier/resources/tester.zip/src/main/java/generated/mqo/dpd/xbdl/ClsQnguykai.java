package generated.mqo.dpd.xbdl;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQnguykai
{
	 public static final int classId = 24;
	 static final Logger logger = LoggerFactory.getLogger(ClsQnguykai.class);

	public static void metHmnydiyr(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valYlkedyqjqnm = new LinkedList<Object>();
		Object[] valYqznfrdltgn = new Object[8];
		boolean valQeduogudvkl = false;
		
		    valYqznfrdltgn[0] = valQeduogudvkl;
		for (int i = 1; i < 8; i++)
		{
		    valYqznfrdltgn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYlkedyqjqnm.add(valYqznfrdltgn);
		
		root.add(valYlkedyqjqnm);
		List<Object> valDaotwjzvhqy = new LinkedList<Object>();
		Map<Object, Object> valHapnrsrqsip = new HashMap();
		String mapValTirrjjjejff = "StrUpxywlfpynm";
		
		long mapKeyDtelrjhnzxd = 9136810018975990066L;
		
		valHapnrsrqsip.put("mapValTirrjjjejff","mapKeyDtelrjhnzxd" );
		String mapValUxyqrgiisio = "StrCxtfpixjmek";
		
		int mapKeyJrzxohnlhym = 316;
		
		valHapnrsrqsip.put("mapValUxyqrgiisio","mapKeyJrzxohnlhym" );
		
		valDaotwjzvhqy.add(valHapnrsrqsip);
		
		root.add(valDaotwjzvhqy);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Oczetjajsn 11Kksdseywxcoq 3Xhwl 7Dpjrfjwv 3Yeea 5Sqbryx 6Cjpplvg 6Dlknboe 5Mmwnes 7Uutylycv 4Vlvju 12Hoyjsmclfhicl 9Qpbeelpvad 11Dkxdfrfolyzq 6Fesaitn 7Ppfmvfou 5Sqzcdb 3Kpjq 7Mcycfxyw 7Htniyhln 7Jglmywji 6Fdqrrlm 7Torzjipc 5Czupcx 6Jsmohrl 12Wzeiexyqiijaf ");
					logger.warn("Time for log - warn 10Bxelqrxdaae 5Bcuftq 8Tryjrfbac 11Lbgdjrefurfm 12Lihhnwldtgnol 6Zjsjvcu 5Yqkbya 9Cjgzioedko 11Nhtoqijpthwl 11Krqqsoytymxe ");
					logger.warn("Time for log - warn 6Msmnjgq 10Fllvpewvoja 3Nupg 10Ubcqwryeybd 6Fjdzdcn 7Athmiwen 11Nsgqtceqepfw 10Vcrowkqiuxh 9Zhnraruqvv 10Lgeolutvnlc 12Aqdqslkjcviwm 8Nnmqznlym 5Saapnl 8Jcpxwkhbp 4Dnsme 10Ikfiquopetf 3Ujle 5Drhffv 6Iehrgjn 3Xgyt 6Vbldmwl 10Lmbectgqczk 5Mtfdjc 3Jbej 10Wxkrvippddy 9Ybudvlzyqw 10Njcleygqzdg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ueynf.ovqsn.bjpnz.bhq.ClsPrqva.metWqdhwnlfsbba(context); return;
			case (1): generated.ctymn.uic.kza.ClsBochsrrjh.metGygnvmjatcdvgy(context); return;
			case (2): generated.zfv.ypwo.wuncq.ClsFveqnpanl.metApyyqiuohqp(context); return;
			case (3): generated.pmny.tmdlo.mfapc.ruez.fnhku.ClsHncyoaufamsb.metZiouerfahj(context); return;
			case (4): generated.cfolx.abg.ClsZqloaugvusc.metIpjezogguhroh(context); return;
		}
				{
		}
	}

}
