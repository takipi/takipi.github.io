package generated.gucbl.hxhv.qux.siytf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsVpdrty
{
	 public static final int classId = 445;
	 static final Logger logger = LoggerFactory.getLogger(ClsVpdrty.class);

	public static void metBpjjua(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valHwuxihxdera = new LinkedList<Object>();
		Map<Object, Object> valYchgjjaoquc = new HashMap();
		String mapValHtgdveuxrnm = "StrAqkyvpkrlcc";
		
		int mapKeyDajisjspqur = 498;
		
		valYchgjjaoquc.put("mapValHtgdveuxrnm","mapKeyDajisjspqur" );
		
		valHwuxihxdera.add(valYchgjjaoquc);
		Set<Object> valVkfxcvhdcic = new HashSet<Object>();
		boolean valLjnegnqmfdr = true;
		
		valVkfxcvhdcic.add(valLjnegnqmfdr);
		boolean valQorxsuolwda = false;
		
		valVkfxcvhdcic.add(valQorxsuolwda);
		
		valHwuxihxdera.add(valVkfxcvhdcic);
		
		root.add(valHwuxihxdera);
		Map<Object, Object> valKnsynnkfvbr = new HashMap();
		Set<Object> mapValTjtasctspzt = new HashSet<Object>();
		long valFwkfdumvevy = 5706808313533716937L;
		
		mapValTjtasctspzt.add(valFwkfdumvevy);
		long valImdceumpztt = 4638059783324523406L;
		
		mapValTjtasctspzt.add(valImdceumpztt);
		
		List<Object> mapKeyElurfxdjzlj = new LinkedList<Object>();
		long valUhflbbpkahf = 1091270510798770325L;
		
		mapKeyElurfxdjzlj.add(valUhflbbpkahf);
		
		valKnsynnkfvbr.put("mapValTjtasctspzt","mapKeyElurfxdjzlj" );
		Object[] mapValMmaxbudbhlc = new Object[3];
		String valIcyackarxaf = "StrGdelnwuhgws";
		
		    mapValMmaxbudbhlc[0] = valIcyackarxaf;
		for (int i = 1; i < 3; i++)
		{
		    mapValMmaxbudbhlc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyAmvackofakg = new HashMap();
		String mapValZlhphqzwytk = "StrNjmczfjkkyk";
		
		long mapKeyOzgdnabanzf = 6108002473992621007L;
		
		mapKeyAmvackofakg.put("mapValZlhphqzwytk","mapKeyOzgdnabanzf" );
		
		valKnsynnkfvbr.put("mapValMmaxbudbhlc","mapKeyAmvackofakg" );
		
		root.add(valKnsynnkfvbr);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Cravvwfwoisru 12Oqumvqanyqtmt 12Zwribxcktagor 9Gqmkkomioz 8Shjqcluch ");
					logger.info("Time for log - info 9Ngxsjulfhk 12Cejcuhftyrdrj 6Fgmjfnj 3Pszc 10Hwdcqeeaqgj 6Qjnsdfp 10Guvjpxcipbd 6Lqxpwdp 7Uaidjrlq 12Zpbshwdktnhfb 8Wqbqvwirt 11Keppdudzlxbs 6Fuperdz 10Uglymjlcpmp 5Hqmoem 5Xxssbr 7Oyvofdvw 6Xzmasnf 7Tdfgyvjo 6Dweqpdi 10Ffsfygdkhrt 11Eutccekgxiwd 10Qoayfnxkirm 5Qdeudb 3Ubmd 9Ivvarhybvv 5Bgnbuk 3Ahcv 10Amqrsffshmh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Thukrd 10Zmritnpszpf 12Rqwohhgzrlzoa 7Xoanneml 4Ktstf 10Tltdwwavuhu 8Efvymqvhp 9Pmopnlyrfv 10Uugkdpdapuc 7Rvvigizw 11Wlrrshoxavzp 8Gwuxlttqv ");
					logger.warn("Time for log - warn 7Qbyqhsmz 9Mggevowmoq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Vmjr 7Clsygzuh 4Cebjh 10Qqnnzkeeyfl 11Ndvoxllwzucs 9Yfzkjhmgko 6Qxtfjde 8Lwppsnpwg 3Ontj 7Xcovbbtp 10Fqywpreenhn 3Wbqh 8Qehvupzvo 5Uuxhvk 6Tpviojl 6Ankosje 9Ivwkdspcwx 9Rjopiuipmc 5Jeesii 7Whbiyfnz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lraiq.fcmvy.qwp.rkzex.eokht.ClsJupuz.metWvwztkw(context); return;
			case (1): generated.knck.lbfq.hgji.ClsItijgi.metCjgswneqtpuoq(context); return;
			case (2): generated.tjsh.wlc.kyb.psqfd.qzhn.ClsOhdwrykfu.metMgbovkjrbbj(context); return;
			case (3): generated.zfo.wctt.rjxf.wjfcy.ClsKuhcjj.metWzuumt(context); return;
			case (4): generated.kjubh.rgz.earxz.ypjc.pmupv.ClsUctrmkk.metPxspawrgwl(context); return;
		}
				{
			if (((5217) % 400) == 0)
			{
				try
				{
					Integer.parseInt("numXiaqdgrkfza");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((8451) + (1220) % 631896) == 0)
			{
				java.io.File file = new java.io.File("/dirEhojvlphfme/dirKsvlakaykcm/dirSyiljwgzhav/dirRfdkbyismvb/dirPdijyftszpx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metCznjhqz(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[10];
		List<Object> valBvfwhznxzcf = new LinkedList<Object>();
		Set<Object> valAdlrbhsrkpc = new HashSet<Object>();
		long valLngtfwhvoxz = -2588226117854764649L;
		
		valAdlrbhsrkpc.add(valLngtfwhvoxz);
		int valQafvvsrpmgm = 739;
		
		valAdlrbhsrkpc.add(valQafvvsrpmgm);
		
		valBvfwhznxzcf.add(valAdlrbhsrkpc);
		Set<Object> valPnqjuorhjfv = new HashSet<Object>();
		long valXzevvgwcqba = 8269217267044419311L;
		
		valPnqjuorhjfv.add(valXzevvgwcqba);
		long valZlzkuzqltjq = -1513863589835209398L;
		
		valPnqjuorhjfv.add(valZlzkuzqltjq);
		
		valBvfwhznxzcf.add(valPnqjuorhjfv);
		
		    root[0] = valBvfwhznxzcf;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Tqckqeujf 12Mzreaqemrsrdc 3Crzy 10Prxjgndbwat 5Orxlnf 11Hesqevmvpdmq 7Etjlaniq 8Avktmhsez 3Xqit 6Ofyiand 7Kkhbnqkz 12Imjkhxgkkmfsj 8Dtuibkjmf 10Tjsbizgjajk 12Zypakfsskqijb 12Zwrjjyaennsps 3Kmkc 8Nxfbdxkse 6Acrhkmo 11Rrdptzfjolsc 11Tzqkgpynvovt 9Swcsaqbbtd 3Tfai ");
					logger.info("Time for log - info 6Xncupvm 3Fvqu 10Gjisjtpzbke 10Kfxzzjifxxn 4Lsdrc 5Eawiss 5Hjfljl 9Meogsamikh 10Fwqolffjjfb 10Smbuubotnsc 6Ugpoabw 7Extfjinb 3Pdwi 7Dsswkzkj 12Gcxgxgkahftih 9Xrnxxnvtnn 9Ppaevjeybk 9Zediszeyle 9Hmxeuzviye 12Lcfxjxbrwkked 5Ssxfob 8Vuhuzaubo 10Yeiuuteoxfl 10Uwurhuntlev 11Vxcvbmjwhuye 7Hofkuyac 5Ucfhtp 7Wpthwefx 3Ifqe 11Rvwfavihjzpk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Xwpylpuflmgg 8Wxcikkrod 6Qdhfpkq 4Dorvq 8Armwnmgrg 6Wpngkxu 3Ewkw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.htfwc.kxkr.hjcg.ofg.qaif.ClsGjqugtpsjo.metOyrdlzxaj(context); return;
			case (1): generated.avpz.xulx.yey.mrdy.ery.ClsVwwfgnwmvvmf.metHfphp(context); return;
			case (2): generated.eob.tzj.qiec.ClsEnjcnowop.metHjaxbe(context); return;
			case (3): generated.wmjc.yywge.qivf.ClsNtnaiojgyo.metQvixcwqsm(context); return;
			case (4): generated.uqvko.bvdt.pbjo.abize.rep.ClsVzpniirg.metZxjubfw(context); return;
		}
				{
		}
	}


	public static void metXdgufsukawoajk(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valXujrcaamibd = new Object[9];
		Map<Object, Object> valRbtwikzvjpo = new HashMap();
		boolean mapValEceetjagwmk = true;
		
		int mapKeyVpjaanqgkon = 933;
		
		valRbtwikzvjpo.put("mapValEceetjagwmk","mapKeyVpjaanqgkon" );
		
		    valXujrcaamibd[0] = valRbtwikzvjpo;
		for (int i = 1; i < 9; i++)
		{
		    valXujrcaamibd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valXujrcaamibd);
		List<Object> valVjphhjrmtqr = new LinkedList<Object>();
		List<Object> valFlcqjzazdlx = new LinkedList<Object>();
		int valXbjzryzohli = 594;
		
		valFlcqjzazdlx.add(valXbjzryzohli);
		
		valVjphhjrmtqr.add(valFlcqjzazdlx);
		List<Object> valDknbgktmpeu = new LinkedList<Object>();
		String valPnnifghcwet = "StrOqpzsgiixng";
		
		valDknbgktmpeu.add(valPnnifghcwet);
		
		valVjphhjrmtqr.add(valDknbgktmpeu);
		
		root.add(valVjphhjrmtqr);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Uloivxrt 7Wpzkgfpo 6Onixpjf 5Halrhl 6Ygdpdxa 9Imkjvbwcyy 10Atbsikgetwf 6Dkkobth 3Mkid 11Mcrabbtcadgs 4Gizqp 3Ecxv 7Lmyymcpk ");
					logger.info("Time for log - info 7Zflrvukm 12Tyhiioeraxioj 5Oxkeyf 8Axefmuoha 11Atxsfclmmral 7Wlrlxhyk 3Hjzb 8Xtxpwgyzh 6Eowhewg 7Upqvxgxp 5Zaxaia 9Poilrbylaz 7Qsuljifd 6Hvcihfa 6Weikbck 3Bqeo 7Kxpmywoe 7Yskjsejd 9Djiwdzbcfy 3Fwku 10Swpassooano 9Rhxnjruhfc 8Quvzlybmc 8Dqdlnzchd 4Utpij 9Aflzfylrti 9Afmdcizhft ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Szrnanllewx 5Jtexev 8Ioqluknzs 4Mutgq 9Jrsksxnkkj 4Dizxz 5Tvuaiq 3Oyyk 7Kdvxmlvg 7Uepwhexs 4Nzibp 5Oyazfy 6Fijdfek 7Ogbahydv 11Qdbwhovjsszj 7Wpivrusx 10Waucifkjuyp 5Wngssm 12Deqxcgbfhwqjg 8Tgxrluftc 4Bkati ");
					logger.warn("Time for log - warn 12Oszmztvqwwvlr 9Zkooysuecj 9Alnkawfowe 7Zrodvupz 8Zqlrwxqdq 3Geni 8Smcqnmnqd 5Tbwcqs 12Dfqesbcghrwyw 8Nezdmhxkh 10Lvlwfnflqpr 4Lzudu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Tfxprghn 4Yjlwf 3Dqyb 3Ihee 4Ymtds 12Koityauwnhsma 4Juxbf 8Vqdfqcevx 11Nyvqoywomzlm 4Gbjlp 9Wszfrbescy 6Uckonjh 4Jtrzc 9Ofqdpwvlgo 5Ddfxra 11Jcfibvcklyea 10Lptjkvahilq 11Syyctejjekax 10Khgxmdllyou 6Sjxcdzv 10Fkdbzwkkywa 12Fzcdtqtlslfba 5Tjmghg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rkfhx.ntcs.qoe.lasd.nzzym.ClsDftkqmvmp.metVydzwrio(context); return;
			case (1): generated.pacx.kivel.ClsQdjis.metGrknaqjnx(context); return;
			case (2): generated.zxd.ssm.wrmu.ClsZpxwrsfothfgl.metAomskmmjub(context); return;
			case (3): generated.qdml.hmlho.ClsQuiharvpvfv.metXrurj(context); return;
			case (4): generated.qnmn.narfk.rdhdk.ClsPtwatcpapj.metXporgbykmc(context); return;
		}
				{
			long varYsujmvlsxxr = (8681) * (Config.get().getRandom().nextInt(408) + 2);
			varYsujmvlsxxr = (2745);
			if (((varYsujmvlsxxr) - (varYsujmvlsxxr) % 935874) == 0)
			{
				java.io.File file = new java.io.File("/dirFivijdgigej/dirJkljdyldwjl/dirVrjzxlhctwz/dirDbryjlboobm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirVebanoxjmwo");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
