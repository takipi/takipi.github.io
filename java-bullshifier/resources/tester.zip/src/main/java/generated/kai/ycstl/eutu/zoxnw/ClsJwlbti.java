package generated.kai.ycstl.eutu.zoxnw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJwlbti
{
	 public static final int classId = 95;
	 static final Logger logger = LoggerFactory.getLogger(ClsJwlbti.class);

	public static void metKycmtt(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValHdosywcvkhj = new Object[6];
		Map<Object, Object> valUlizzxzwmna = new HashMap();
		int mapValTxjhirbilyl = 7;
		
		long mapKeyChgoewhdugl = -8316615302010162487L;
		
		valUlizzxzwmna.put("mapValTxjhirbilyl","mapKeyChgoewhdugl" );
		
		    mapValHdosywcvkhj[0] = valUlizzxzwmna;
		for (int i = 1; i < 6; i++)
		{
		    mapValHdosywcvkhj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyItpawzrmtti = new LinkedList<Object>();
		Object[] valBrygchzkavk = new Object[4];
		boolean valZrkzqxajbdc = true;
		
		    valBrygchzkavk[0] = valZrkzqxajbdc;
		for (int i = 1; i < 4; i++)
		{
		    valBrygchzkavk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyItpawzrmtti.add(valBrygchzkavk);
		Object[] valXalkggkbniq = new Object[11];
		boolean valIlvvraynlok = false;
		
		    valXalkggkbniq[0] = valIlvvraynlok;
		for (int i = 1; i < 11; i++)
		{
		    valXalkggkbniq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyItpawzrmtti.add(valXalkggkbniq);
		
		root.put("mapValHdosywcvkhj","mapKeyItpawzrmtti" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Ukwdgypi 11Ljbehszsvcwp 11Wnkhncxygcyt 5Ikroqq 9Comltbkzpa 10Hkivqztcbma 12Fnxopvxsiwrab 9Xkgdbjrpxl 4Smkbk 11Fwcynduofsxu 11Btbyvtyvztmi 4Wygoa 3Xfbu 3Emgf 10Pcjogbriyye 6Vvsybnj 3Xgtd 3Mimf 9Coaohobcrw 9Dmdgrbqgom 8Yfqmvnitb 5Ofudzv 9Ibnrjgpywd 9Kgyndrarmh 8Yeglrendn 6Pxnmulq 8Sspvvacon 8Fbkzrkifm ");
					logger.info("Time for log - info 5Iksnsq 4Ygoww 6Femowlb 12Acngrhoehrvlz 12Npsagdpuzqomt 9Rbrefqjxnz 7Xqwtaqqr 10Cxmzxuxkkyz 5Zwwbmi 3Ecuz 10Zbxvhcpzizd 9Aeugdktarg ");
					logger.info("Time for log - info 3Mgtg 4Wplmi 7Wjrmbnwd 5Cqhewn 11Qxlqprcanstb 5Npbknh 8Qqihezyhk 5Ukcbov 9Gpujlxwqgq 10Zxtjgnswvce 11Ddvpdqazougx 12Igphzmcnxhilm 10Njdbpfphtxf 12Hpszxhwvvrztu 8Hqnvhxdio 12Eywhgfjeifkog 12Ngrghiviisnvn 6Atbhuqj 7Oaeqqbum ");
					logger.info("Time for log - info 8Ctfupjwum 8Vtnvmadar 12Hxsmrmchuslli 11Naxcdbwucqwb 4Wucid 10Opjopedrguv 3Fjsw 12Pxvmtxiuzmtvd 5Jbappm 7Cwgnuezd 12Nulurocgmwhkq 11Lgqsgdkmnupy 11Iscbwivotfzc 5Hxdihs 8Ahflvabjy 3Lgny ");
					logger.info("Time for log - info 8Gmodycfcm 4Teqcn 3Uqhj 6Gyzqjyz 11Wkoyhhikgsoe 8Eofgqpqkm 3Uypk 10Fiiihwrzjgk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Edyvhvpcjnn 9Fkzfukkbci 12Hcsxbtszmzfxj 8Bwlgctiav 3Xxqf 6Gnjyaam 4Mmdby 10Gsvwbyrsoat 12Prdbkyhjzykfb 10Qcftqgutkzd 10Pwqayrzxewt 10Yazuvxmkzte 8Oohqnfdyo 10Mjukqatrcrf 4Ylkvn ");
					logger.warn("Time for log - warn 10Qrfuphoutuk 4Qvfzw 4Jsxbz 12Oyjdbsaldysfj 8Mdlewzwcg 12Ccfjvtypabxsu 12Btejiugsfdujo 4Yuhdr 11Yizzlhtrmriy 10Lqwdsqagnnz 3Rcpg 10Nyhylvcuvhh 10Xauxcmeldcl 3Efxa 5Axytyt 4Hgchl 6Qtgulli ");
					logger.warn("Time for log - warn 11Omhxqowookxl 4Jlwwv 4Xfkyl 3Bcee 7Xbfmogge 6Iwsgdpe 3Sodv 4Dbloz 4Yyxfi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Eqqb 7Wezjbqba 12Kikanraumlkwk 6Nqdxsel 9Wwexvzjnlc 10Uuxgtwhgypy 8Hnbitjvsx 3Kqaa 8Cxxgtbgjm 6Mwqjhxl 8Svpwumxvr 12Pgvxcqlpabdka 6Tuacrtx 7Kifcpxjj 10Pqvvblkvpcm 3Siao 12Sjhxkrjmzrhpl 10Fkmhlvqqjbl 5Sowrby 6Sxkhtbt 7Snjvkfnd 3Ksfp 11Cjerbgwalzbw 7Ivfwzzyp 7Xltxkgwn 9Ccxgkmbzxi 5Mnnhkp 12Fzxvyfmykfcyd ");
					logger.error("Time for log - error 4Bhefc 4Agmnk 11Bgyoresysock 4Pvlgt 6Ykfywqu 7Qqfikled 6Pjgfzkp 8Qbrbdepbi 10Lkpehuaucnq 5Xdpcui 3Qfkn 5Hektgs 6Naeaifm 5Lpurtf 4Foxmg 5Skzcdt 3Pjqm 7Dieqqbjq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ufqu.ddqdj.nsc.ClsAchghkwny.metKntxpyoov(context); return;
			case (1): generated.rnr.pwsrq.cbi.tat.ClsQsqavl.metRlyadlfqaso(context); return;
			case (2): generated.swyg.szfbf.ejprt.ovbj.ClsEqyrgxer.metIorzpghwry(context); return;
			case (3): generated.vhk.matvp.xpri.ClsIidoitanl.metMirdsxeleqw(context); return;
			case (4): generated.gpnn.qul.pdexl.hxjph.zmndq.ClsIcvyndtrplxfkf.metNldde(context); return;
		}
				{
			if (((3496) % 160607) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirKqgbqvwujrh/dirYfdnflrkjal/dirYqikqirshls/dirEsssgvigslx/dirAvyjjzngddo");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metUsjlmntvgpvw(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Object[] valRmdawdxdjjo = new Object[4];
		List<Object> valKdweaqheuna = new LinkedList<Object>();
		int valUidxlgshoff = 949;
		
		valKdweaqheuna.add(valUidxlgshoff);
		
		    valRmdawdxdjjo[0] = valKdweaqheuna;
		for (int i = 1; i < 4; i++)
		{
		    valRmdawdxdjjo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valRmdawdxdjjo);
		Map<Object, Object> valUrtchgoiddm = new HashMap();
		Set<Object> mapValFbzoyeoxkaz = new HashSet<Object>();
		String valViwebgarsph = "StrVimuwoexpue";
		
		mapValFbzoyeoxkaz.add(valViwebgarsph);
		
		Set<Object> mapKeyQwntgqahzyb = new HashSet<Object>();
		int valXbkidpaoqil = 802;
		
		mapKeyQwntgqahzyb.add(valXbkidpaoqil);
		String valXhmvmbfdjvr = "StrGfodbvemuoh";
		
		mapKeyQwntgqahzyb.add(valXhmvmbfdjvr);
		
		valUrtchgoiddm.put("mapValFbzoyeoxkaz","mapKeyQwntgqahzyb" );
		List<Object> mapValFqdmzwlfqyk = new LinkedList<Object>();
		String valZolppooamwk = "StrBfjfblbzuuz";
		
		mapValFqdmzwlfqyk.add(valZolppooamwk);
		
		List<Object> mapKeyUzasmvggnsj = new LinkedList<Object>();
		boolean valEretqjgwlvx = false;
		
		mapKeyUzasmvggnsj.add(valEretqjgwlvx);
		
		valUrtchgoiddm.put("mapValFqdmzwlfqyk","mapKeyUzasmvggnsj" );
		
		root.add(valUrtchgoiddm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Osyel 9Hnokvofvtl 5Gfpueq 12Mbhpcjrhrmkfj 11Ofiwdhquqmgg 3Wblq 4Keoli 5Zndndf 10Lnveczxplni 5Dtjtpx 10Olpbhcibyrq 4Crkdx 11Yoftnaynkhpc 3Fjws 8Zpyamspny 12Whfekkqzubwif 10Zzxvtwzpcjy 3Mygs 10Kesgtkwtxkj 9Ccqduhhzts 9Tgiiibknsv 10Odzlowwifnu 10Aifqinzvpzs 12Xuwsruogblchp 11Nfzovwcdmbar 5Ygqbdi 4Vqbzy 11Rafcpcgwqbua 7Kaarqfxn 6Rpannid 4Gqawq ");
					logger.info("Time for log - info 5Yeqlre 3Eked 9Wcblunvmaw 9Yewczbhwxg 8Scmuomvwx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Iyloyirn 3Pwlg 6Smzaeva 12Fxatnnjpwpqfo 6Tarnrdv 5Kuyccl 8Lqjlorfhm 8Idnopoyls 12Fsbxxfgdfrirc 11Grybyspeywyn 3Bdaw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bhfun.zpnwj.czfe.augg.ClsEdcxpvndelttu.metGbtgraxg(context); return;
			case (1): generated.baxd.moelu.dfhna.pgrdw.pgae.ClsTifyecuw.metBnfwficdpxvbr(context); return;
			case (2): generated.bhfun.zpnwj.czfe.augg.ClsEdcxpvndelttu.metUlhmbyyc(context); return;
			case (3): generated.hvqh.qdnb.tawyn.ClsAaddylg.metCsnugb(context); return;
			case (4): generated.ghn.esb.odxb.wtax.ClsJgsbwdqv.metPazubjuncrdr(context); return;
		}
				{
			long whileIndex21746 = 0;
			
			while (whileIndex21746-- > 0)
			{
				try
				{
					Integer.parseInt("numSbddtfcjkws");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex21747 = 0;
			
			while (whileIndex21747-- > 0)
			{
				try
				{
					Integer.parseInt("numKjpygndmoyt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varDdcigdxqbxo = (Config.get().getRandom().nextInt(990) + 0) + (4725);
		}
	}

}
