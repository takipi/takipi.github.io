package generated.gpnn.qul.pdexl.hxjph.zmndq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsIcvyndtrplxfkf
{
	 public static final int classId = 169;
	 static final Logger logger = LoggerFactory.getLogger(ClsIcvyndtrplxfkf.class);

	public static void metWyrdoedscqrw(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valRwuzkdgauhh = new HashSet<Object>();
		Set<Object> valVglorrgunfy = new HashSet<Object>();
		long valWlqnnmtyvwz = 3296292137490516595L;
		
		valVglorrgunfy.add(valWlqnnmtyvwz);
		long valMrjajpcfjev = -9009229600496498005L;
		
		valVglorrgunfy.add(valMrjajpcfjev);
		
		valRwuzkdgauhh.add(valVglorrgunfy);
		Set<Object> valGyjlgogzenl = new HashSet<Object>();
		boolean valQhxkvtvkxqr = true;
		
		valGyjlgogzenl.add(valQhxkvtvkxqr);
		boolean valJvjthgtqekg = true;
		
		valGyjlgogzenl.add(valJvjthgtqekg);
		
		valRwuzkdgauhh.add(valGyjlgogzenl);
		
		root.add(valRwuzkdgauhh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Tilapf 11Rwqqzhcxuwgg 7Hmzrbyum 3Jjld 6Mpzbgcc 9Tisopgirst 11Rbjngovyvalg ");
					logger.info("Time for log - info 4Mfflt 7Virocdsx 10Yqwwahgcche 5Ahwlba 5Fjwtdz 5Khrpcp 8Inqrmizhs 7Fkeknrua 6Fynsvmn 5Zgdlai 8Dfgspvpdr 7Jdiptrmc 6Thimzki 10Ntxayucfnfk 8Seyrpfuif 5Hgcfzk 9Biituhotsh 5Kcbxcv 4Btafe ");
					logger.info("Time for log - info 12Buraymbhgetuu 5Fhfwvv 4Vieoy 11Mkbkiegcxvvd 5Kcdpoz 4Nlgwe 8Qkoqwzcig 11Jjnaoiefrcfh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Adermzuderio 4Yvixe 10Ipxmkudumdp 12Bmzetgceyewlj 9Uzvtrlapgn 10Sigfglhieiz ");
					logger.warn("Time for log - warn 9Mvhidvbuyx 3Toty 6Xgjbsti 7Nclacliv 5Qkndsb 7Pzanhxsp 9Eoidzmrrtm 9Chmjutrbqh 10Kgrqsotxpqe 12Ajaoycaclciom 6Ivcaydy 8Srmqupree 6Cenmrjd 6Fgtyyjx 11Sgmxliaufldx 10Uytyxskoxow 7Xpgmoopz 6Kguxtez 11Rvpvpfvquevs 6Yhmqzgl 12Gqmtoazxlzurr 9Xambdjngwy 9Xfjhgokjer 9Igbmaanenx ");
					logger.warn("Time for log - warn 3Ycmr 7Zllizqmd 10Xlabiqdfkkt 10Ltixgrwmbiz 7Mdfvwlvh 11Wovqwjtxkcoh 4Kijxb 5Doztjp 7Tpuogkta 4Vczxx 8Nkfcznpwf 8Cosaymeoa 12Uidkoochfnipu 6Ggjaejf 6Yizuzbk 10Yqhaugjopib 7Ijftdfdx 6Cunsjbj 3Fgcg 12Dobqcytjmqfvw 3Bztz 9Aduouovgmf 3Xiuq 6Ycdmyzm 3Bamw 3Kngc 5Iechbd 10Hwwrrksvfcx 10Aqvxjqdzurp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ifyrm.rwj.ajr.gkqyg.ClsSfeshwgdectgpm.metKuczfwtup(context); return;
			case (1): generated.jbipj.zrsb.daypv.qszx.ewk.ClsVnncvmwdx.metEgxuxcqraj(context); return;
			case (2): generated.vere.yue.xag.ClsLhubirlwqfrd.metNbhkew(context); return;
			case (3): generated.cjexh.ehrl.mtwqa.ClsVshethruisurxt.metQbgbwpmyakda(context); return;
			case (4): generated.crkmz.uuny.smq.vvmxn.khxb.ClsQbvzuhroxdituh.metAiybrixueywscr(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numWcoiaavxwel");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex23054)
			{
			}
			
		}
	}


	public static void metNldde(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valUbpmmekpvrg = new HashMap();
		List<Object> mapValAkdbrdbnqql = new LinkedList<Object>();
		boolean valPvcfejhbhfv = false;
		
		mapValAkdbrdbnqql.add(valPvcfejhbhfv);
		String valTwpaqwfaemb = "StrKforhbyofaj";
		
		mapValAkdbrdbnqql.add(valTwpaqwfaemb);
		
		Map<Object, Object> mapKeyHngudmkfisu = new HashMap();
		String mapValXlsimbnuahv = "StrUvpqbrjougt";
		
		boolean mapKeyVqovtrnoxme = true;
		
		mapKeyHngudmkfisu.put("mapValXlsimbnuahv","mapKeyVqovtrnoxme" );
		
		valUbpmmekpvrg.put("mapValAkdbrdbnqql","mapKeyHngudmkfisu" );
		
		root.add(valUbpmmekpvrg);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Bocfhjmjzns 10Buwcvazihij 6Pbayegj 11Dcxezgbvhiyb 11Dkdcmrtxwvzs 5Pgdhkr 6Urzxfbt 3Ffsf 10Cslydjmsyok 5Vwcnuf 8Fxjotogia 12Qsnsrgikubxwq 3Zwag 7Kibpmvmm 8Vluypeoro 12Uqzosvnkvelxs 11Kkoayujgmfjg 9Qfcvdccbee 3Hvtm 6Sreqwik 7Gwyfgtiy 12Zgycwxaiqodxp 8Fgahdprah 12Pbpjmmmhnoase 12Dniznkwligncl 8Occgtooym 4Yjqqp 3Sjwy 5Mfuaie ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Dgdioaaw 11Siemwrzguvzr 4Jatdr 11Ncfkvnqliegu 4Wqxib 10Jyoviouggeu 11Casacpurnyyv 8Ljiiumqmr 8Kxksojidr ");
					logger.warn("Time for log - warn 6Ejcqsll 8Pjzuwpvre 9Vjfgrrzqby 5Llsgzg 10Vgscvqfhxed 10Sbezwmxemed 8Iynucgnky 3Pidx 8Kqcvywpqr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Uvatri 4Sthhx 12Qwvvchhhqiytj 10Uinjultgfaf 5Horzar 12Wvxssxnekyoqg 7Ovtsjngz 3Dnav 3Mizn 12Fxbazuzmqeaud 9Qdvjuobawo 4Gibfp 11Dbifhjfynowt 12Jwajrnqpjyaev 9Toeubufqzi 12Afvxeuzdowcjv 8Xvrbeipgj 12Pjbqtwjcxyfad ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.decno.psqz.bhc.ykgc.ClsIhnrz.metNfknyrmpq(context); return;
			case (1): generated.tvv.ioy.ClsEqfmidfypp.metXtylbkjfsv(context); return;
			case (2): generated.rnr.pwsrq.cbi.tat.ClsQsqavl.metUgatrdxyhn(context); return;
			case (3): generated.pli.sac.lcrkw.ery.xwlo.ClsIghyijbnkvoubq.metAbfxcknztmtxd(context); return;
			case (4): generated.hehz.xzg.akn.rdsvf.ClsKsukcv.metYviizisnunbnph(context); return;
		}
				{
		}
	}


	public static void metUexjnwdywcfac(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valXgaijklblaw = new Object[4];
		List<Object> valCxexiorgese = new LinkedList<Object>();
		int valYsrqsbpxfds = 820;
		
		valCxexiorgese.add(valYsrqsbpxfds);
		long valUhghtjtmwhi = -5276578168310655097L;
		
		valCxexiorgese.add(valUhghtjtmwhi);
		
		    valXgaijklblaw[0] = valCxexiorgese;
		for (int i = 1; i < 4; i++)
		{
		    valXgaijklblaw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valXgaijklblaw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Icrvzzzsbzkv 10Urfrbezofbv 3Tclt 8Edjkbazct 11Fnozezjmompo 5Yvhxrk 4Byrwe 4Epmcf 9Pjncavcxdy 9Ctfhqeodiv 10Kzqfwryxmtq 12Nnlsyjglpioga 9Rghfiqmuby 6Hyyijib 7Zmnpbups 8Dcfqenruu 7Bylzfsxy 3Bhzf 12Dpedsjpdbptec 12Tmjhbzswlnjdp 5Acsehm 9Ysajbahgmg 8Mgbprftpm 12Miwdioevdjigg 8Islibdggl ");
					logger.info("Time for log - info 12Ochlisfkuelre 9Tpgabetzjz 11Rgkogkcrcwcw 4Zyiiz 3Mmpo 8Sbgoledcl 5Jakqlt 5Icqxuu 10Fpvtcgbppxo 11Asrfqtlqhsto 11Egdtxagytjaf 4Fuaro 12Tovyfoemkjaga 10Svwjfaoymxg 12Yhfxmojtxixjp 3Iefw ");
					logger.info("Time for log - info 9Hoaztbioqh 7Daocfqff 11Sisysuppjemx 6Gkiikzf 12Rothwzmtwlykv 12Gqppschqthxee 6Acfyves 10Luyzaspuihd 7Vjyhvggp 5Fxpzav 5Ohjdsx 3Sagf 3Bdbo 12Jexkdelsjlgjh 5Mrfdgz 8Pgxregehh 6Sdkmapw 4Bfabr 4Gmwaf 6Moedwyo 6Zmyotcm 12Haencakgsvrvi 9Hgfrvhcqpo 6Yxfxzqa 8Tadtmnyir 6Yohobpq 11Mvtbuslxrdgz 11Odfrenjfgcgt 8Pvbddoyqs 5Ckwhcv 12Uqjjnnlkeyksl ");
					logger.info("Time for log - info 12Kitnbumgetrpg 10Ovyhygqgykc 3Hfcw 12Voolygnqdbjzp ");
					logger.info("Time for log - info 8Dtqnrnsap 4Edsoa 8Gamptbfzv 4Bpkzk 7Duolwauh 6Hfllniz 8Mybpglmdh 8Hgvjqocia 12Dcgnkoevzccyr 8Aieneyuqh ");
					logger.info("Time for log - info 12Xnkzahntegzga 6Obzyeow 5Dprgko 6Rlyzeco ");
					logger.info("Time for log - info 3Zphx 8Zdkhfwhsx 12Xakdoudpjojrc 10Nmqrewioefe 3Kanv 6Usmwosr 3Kyfo 6Ypannmb 4Djfbl 5Dutley 7Kbarcifo 10Mfyqmheyolq 4Xitrr 12Cvbtyqulmakoe 7Jnbbosnf 6Byjpfag 8Kocyzjoqo 7Ghyyyhyi 9Oiorykkrcg 5Vstmjr 11Hssqdvyzvdrf 12Kgiyaemhkrndx 9Mxtkrsqxpi 7Vpbsmkjl 5Jlmtpc ");
					logger.info("Time for log - info 9Ameilcxlgm 3Wekf 4Wloni 9Mvcvacffgo 8Wjefqzyth 9Lbfgoyxtnf 4Rmxac 5Ymxaty 11Rkgcgcnvamcd 7Zyozrxlx 5Oafqmv 9Yssrudacbl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Nyprjbhekfn 4Tmiee 11Fwqmgrtcxmew 10Cesqxaiiili 9Pxhlehcgct 6Hlhuxmj 5Ulzlkn 10Unpxguzgewe 11Mvttfvgepchv 5Bdjzot 11Jfuthzewlukf 7Xqqndpqn 3Zflw ");
					logger.error("Time for log - error 7Wwfknttw 5Tidwyg 9Dyhyckgteh 3Jouc 11Wxnqrrtxvlpb 6Kmfrsry 3Vbiv 11Wkhbcswtxgjd 5Sgobfe 5Jjhmxk 5Otdhfn 9Irguudnhku 9Qthwdcxxgz 8Kzszkkddl 9Afnfqquhcm 4Bsfbo 12Rbfbqfpndxckm 12Rodgjywwtliqb ");
					logger.error("Time for log - error 4Kqose 7Abteonqk 6Yilbvgh 5Hgakwe 11Isrfembpwzmk 3Aqht 10Xofongdhsbf 4Trkpj 10Tdaaydhytoh 4Pmfey 12Xlmgqhmbuymny 5Kkoklf 9Yhheuixjem ");
					logger.error("Time for log - error 12Aylpnjbpfowhv 10Kyolituywpb 7Fvqqsrpl 10Mxkvqckfdmw 11Qeusldcpbwtq 6Bqvnsfn 8Dmazcgdbr 7Ojexmhsh 4Wemnv 11Brckeepndiqi 8Eimmovmhv 11Vrwlmcmhuhlu 9Xkxfdoeytc 10Jgyyxemhpnf 4Yhmij 7Unnasgap 7Nnkfpxse 8Oqfylblow 3Wkcf 11Ricdtdomoily 6Cvpuwjb 3Vfjt 10Ilmlkdnpepx 9Itfevfigus 3Stbw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jzpii.ixwl.ClsCvgimgq.metSxvhwbhsdlyr(context); return;
			case (1): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metEvvtbxshkftg(context); return;
			case (2): generated.hdrlt.jxdm.bjqs.pupxs.ClsZoyaigxdyb.metCofpcgjfkt(context); return;
			case (3): generated.qer.bwl.ClsCbeyhqqy.metFgzkaoqzw(context); return;
			case (4): generated.kfjp.bzn.mda.sfyxf.ClsAguszlzt.metWsvlopnliexx(context); return;
		}
				{
			long whileIndex23059 = 0;
			
			while (whileIndex23059-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((6624) % 473638) == 0)
			{
				try
				{
					Integer.parseInt("numNkrbotlnmda");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((7800) % 198997) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirVwnozliaitl/dirYedqeenpaog/dirVyfzmmjnzce/dirPghgmowpnru/dirMkbshijoevz/dirMgbplgxgfwq/dirDcekpkzkfru");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varDmmsthjpyko = (6583) * (Config.get().getRandom().nextInt(275) + 7);
		}
	}

}
