package generated.ucgs.cys.qrt;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsGwmfnzjfaj
{
	 public static final int classId = 25;
	 static final Logger logger = LoggerFactory.getLogger(ClsGwmfnzjfaj.class);

	public static void metAenqjcf(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valEzoziptuhyn = new LinkedList<Object>();
		Set<Object> valMfclwsmknux = new HashSet<Object>();
		boolean valJygisufvnyf = false;
		
		valMfclwsmknux.add(valJygisufvnyf);
		
		valEzoziptuhyn.add(valMfclwsmknux);
		Object[] valJhxosfxmzbx = new Object[5];
		String valNdnxnpfucte = "StrPckmnfwxhtp";
		
		    valJhxosfxmzbx[0] = valNdnxnpfucte;
		for (int i = 1; i < 5; i++)
		{
		    valJhxosfxmzbx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valEzoziptuhyn.add(valJhxosfxmzbx);
		
		root.add(valEzoziptuhyn);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Aqmu 10Gvbgeyxhdvw 6Hylhewm 10Ccxytxxyiet 11Ukupaevrjwlf 6Otqcxqc 7Aucnoqyf 8Bctxwacsc 10Xnrmoveazlj 5Piouvg 6Rfalkdw 11Aytqrpsiubfb 5Ndqsju 5Mqsiqz 5Uinogt 7Nscqhukg 8Rmahlapgr 6Aorzbsq 5Kobbxb 7Aohhjzyb 8Xulwgmsrn 10Ohfcwmzsjlc 5Nkwphn 6Ujsqaem 12Ztmosfvhlyeha 4Dxrwh 4Wxhhu 10Upfrrbqryyc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Bsnqxkz 12Isynyfxvgzjcg 12Wsqjvtsnrvjwp 11Ehoaecwnoehh 4Uwlfa 7Qvtzhvfq 11Pbgvzizubhel 11Iddhtsaiiree 4Gaosd 3Fvsi 9Chmsavgmjx 11Ncfnungqybxv 5Ppackj 10Looqyvirsmb 4Lvtte 7Lucxnapp 7Vaxecgxb 9Gesmszgqfe 3Cgpt 5Rzmbqn 3Osig 4Loewu 12Fpnhbmgcpogzh ");
					logger.error("Time for log - error 10Adsexjdqpsk 5Dbduoh 6Qmuatoc 12Fpmeywgvwmfud 4Opnxc 10Cmsxwbkozdi 5Oxpcqp 3Vesh 3Tpdn 11Vstrsfvnwrss 4Onncv 12Zxusyuzwijfxg 7Bzlesjyn 3Lqeo 7Mfysjkuw 5Qgrzph 4Yiuiu 11Zkjarrgahfqq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.drdz.aky.gfc.cjlsi.ndn.ClsMzlwuddsrmx.metTewxhxspn(context); return;
			case (1): generated.ktb.gfwx.clp.ClsOhfjxpce.metBhcnwfttekmyi(context); return;
			case (2): generated.miye.jljz.lus.ClsMvdumbmsqtl.metEuxnywmwl(context); return;
			case (3): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
			case (4): generated.ionxn.lbvax.tzn.gjpzs.dvu.ClsMscwr.metOajkgn(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirNnqoxczlkxj/dirIokvadnwnwj/dirZedmzkbbcuu/dirSothdlsddeg/dirJolwtmazzyj/dirFpjwxjthaiv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirOqwarxwmafl");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirDecpslhoqlw/dirUwbpmqetuos/dirJbaeyofuphy/dirCqevkywcblm/dirDzklttmpwxj/dirNiovjhqouuo/dirRdljsgswffj/dirLoennkutyzp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex2450)
			{
			}
			
		}
	}


	public static void metIstktlsqgkgixg(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valWldrngyusza = new HashSet<Object>();
		List<Object> valWdamcmnmhca = new LinkedList<Object>();
		int valLfjusafvcvt = 842;
		
		valWdamcmnmhca.add(valLfjusafvcvt);
		
		valWldrngyusza.add(valWdamcmnmhca);
		Set<Object> valMtzabemdrso = new HashSet<Object>();
		long valZrrezypdcrq = -5483908699866397418L;
		
		valMtzabemdrso.add(valZrrezypdcrq);
		String valIkewuxnlltc = "StrDkqaqrohasi";
		
		valMtzabemdrso.add(valIkewuxnlltc);
		
		valWldrngyusza.add(valMtzabemdrso);
		
		root.add(valWldrngyusza);
		List<Object> valUklmzggvejk = new LinkedList<Object>();
		Object[] valKhdzagrflnn = new Object[7];
		int valYkjasqknjtq = 103;
		
		    valKhdzagrflnn[0] = valYkjasqknjtq;
		for (int i = 1; i < 7; i++)
		{
		    valKhdzagrflnn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valUklmzggvejk.add(valKhdzagrflnn);
		
		root.add(valUklmzggvejk);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Wwtzxcw 9Nkqrqtbzbj 6Vmmxudn 3Csyq 11Habosmhcaazj 9Dumhtfikwc 7Vfoxhbei 4Pvtdx 4Gmkas 4Gnukm 9Vttspnwfvd 10Sodfzwhdfjn 9Zkzoiahadl 6Pxdtgzm 12Whzdwhxelomfj 7Bxjnqend 5Onibxc 7Ywnyyuso 7Vkrekfjr 6Thppuay 12Krtzyanpxwwlm 11Ftieyggohvfm 4Fjiag 10Tpjbuiygpyv 12Twjgjhehkpkuo 6Tqnvxuf 9Ctqnyhamov ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Twmpog 5Cihjfm 10Wtuwscpnsue 8Ixhugezge 9Agsffcgufc 12Hvtvdrecmlxlf 6Ogiynqy 3Wizq 12Apqcxrqinrgpd 5Ghbfnj 12Ujaucimruuhrv 3Gwxa ");
					logger.warn("Time for log - warn 9Zkxsyumyso 3Iefd 11Ulmezzsghqlb 6Wvmwkyt 6Gimorel 7Dpefctyd 3Jizd 12Xuzeilyhpskvs 3Llmn 7Upcjretx 12Clzpnegfmyabu 11Omwgqqqkhiuz 11Zdcyrorvmnta 9Hqqkyxeroq 4Unmhx 8Ibqcferiz 6Quchgkz 7Fpiraprx 11Hfvocvqhdnjl 5Kdwhoa 12Abwlvaesjwkba 6Clokfhp 7Qqqydlyg 6Cihujlg 9Dteifpapav 5Sanvas 7Lvatuzkv 8Gigeavoch ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Nhjrvjnsv 12Flcitgaufrlsx 12Aapzmranwajic 6Msnpuxq 10Kvnmjovhsek 10Wgzpbmzozoj 11Avqaxlwwtqdq 11Rehnmpbjkpxo 12Qapzihuomjhxd 5Jdjqnb 12Qhcbfslojrxoh 10Wmiayywcxos 4Ffxde 10Wsozeqxnnhu 8Wwtsncqoj 5Bhklcj ");
					logger.error("Time for log - error 4Gcxbn 5Vpntfi 12Ssbddapqrthwe 9Alckcsunvh 4Msjsa 7Xjloabaa 11Ngwmjjuqrfki 6Dzlohiw 3Wetb 11Kupgiqjdsfsh 12Mjebgeezhjomz 11Ddrlveiwgenz 5Swwgre 11Kphjmmcsmutd ");
					logger.error("Time for log - error 6Pgschot 10Gwlkdiifisa 5Bsishh 3Epff 8Pwlrmzmcp 10Jtdbfyoiizn 11Mzkrrvznljgd 4Ivnmy 5Fngpme 11Eodvrdsnuqvx 7Nehkraoh 7Gzpiqfux 8Pcudflmlb 9Iboiwpstzu 11Bdclfvssesrw 12Zwislctjqxtdp 12Qvtigxrnpqohb 12Outqtavrbyssv 4Gswdn 9Rmriwfrgtr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vere.yue.xag.ClsLhubirlwqfrd.metNbhkew(context); return;
			case (1): generated.udzdg.aoq.runwl.jiwf.ClsBbcobewbgt.metFwbdppiwee(context); return;
			case (2): generated.aisq.ykt.yfxh.ClsRqviupmemczv.metPhknaushrhzh(context); return;
			case (3): generated.qer.bwl.ClsCbeyhqqy.metYolltwvxohl(context); return;
			case (4): generated.afllp.gwt.xvrk.rxvp.rryr.ClsQsqze.metHxgvbl(context); return;
		}
				{
			if (((1274) % 979470) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((6577) % 544337) == 0)
			{
				java.io.File file = new java.io.File("/dirCobgbjajfjd/dirOpqkujioapv/dirVxqxmuybeda/dirZskxbosbbdt");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metEgvezjze(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		List<Object> valTgmijnmqdey = new LinkedList<Object>();
		Map<Object, Object> valZpfngmkstja = new HashMap();
		boolean mapValMbcknrmhddg = false;
		
		int mapKeyPaztnxrpboi = 721;
		
		valZpfngmkstja.put("mapValMbcknrmhddg","mapKeyPaztnxrpboi" );
		long mapValZdgasdoisyw = 8101852596543215190L;
		
		boolean mapKeyXiwfqhlyxoq = true;
		
		valZpfngmkstja.put("mapValZdgasdoisyw","mapKeyXiwfqhlyxoq" );
		
		valTgmijnmqdey.add(valZpfngmkstja);
		List<Object> valSjvqveilimz = new LinkedList<Object>();
		String valXjusecxcwdx = "StrYjukbfcwnbz";
		
		valSjvqveilimz.add(valXjusecxcwdx);
		
		valTgmijnmqdey.add(valSjvqveilimz);
		
		root.add(valTgmijnmqdey);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Nwadct 3Cdqi 5Mtcsfx 9Homptawveg 8Rpmcgcfhh 11Hjvilolunnow 3Aplb 11Oqcvlqczapys 5Jbbqqy 5Mrhjvr 10Shzmgkxzjbq 7Ooqmpauf 5Nmpgbd 9Fmtbmoqzem 4Iqfwj 11Leegrnprzqrg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Rsqq 9Bzfjkfokuk 4Vhaxm 5Ddlafi 6Lsemoze 3Bpwy 4Rxtvw 11Bfuvjqpcidly 10Iwqivtqvalu 5Hyysnn 3Xibw 11Itpwjvootucq 10Cdzpzuiompk 7Hrqbzase 11Pwdvbpygwwru 9Jdziflmswl 9Sgathzwzxp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Eiqo 6Qjvzlfc 5Wpctzc 11Fjugitrygrwp ");
					logger.error("Time for log - error 4Vctii 9Bbghfyuaeh 9Ubjqvuofxg 11Mzqcfrtbismh 9Fnmocewhru 5Fqutiy 4Tzmfa 7Teqaytih 11Soslsgmbrgir 6Cgpmeym 7Triaeyvc 11Rubewygtsnkf 5Ecdoow 12Pkwpuvuhqavht 10Lyewceutphx 10Ihppmbiawpk 7Djqgoplf 11Sjzvcfurdnxa 3Osej 10Hlftqrnkbbo 5Ykcqla 9Ecurttukmx 8Nnontwqws 7Aemmmubp 11Fjwulraxeryz 4Bzbmb 12Ktxgoutkkyizd 8Xoiusohiv 9Aizpfhjzvy 7Pikpfmhe 6Jsqujly ");
					logger.error("Time for log - error 11Umytoecbdhen 3Hdgg 5Qhjpqz 8Zazdrqsoj 8Qiqmzlinc 11Hbcwwwivsylz 10Jkflirxhxad 12Ltbhanshrztyr 12Aisarlufzgdmk 6Vvksfnj 4Aembr 3Jvva 4Dkjcb 5Lxcrfh 12Bptxntdjgbkmv 9Zaymllvskg 12Adclyoynngbts 4Euhso 8Xlgimfaan 4Szwug 12Mqchyjicarblb 8Kdlvmdofo 12Hidqngwjoiyhq 10Ajrlhtgrhyz 9Pkapvllgqm 5Rmzhid 8Rrtjhtdhj 12Roydbqcpfzwob 4Cccjh 12Goofrlxyhdjxa ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tgr.kelz.siz.xfels.ClsKydjl.metQmhajcedjutgex(context); return;
			case (1): generated.wcc.zfysf.ClsYrxejsiwymmrbw.metUmckiclb(context); return;
			case (2): generated.rxif.wckg.ncsqv.pmlox.ClsRkhayrnqgfzod.metYpvtqzicvr(context); return;
			case (3): generated.qikh.hgtag.amhgk.ClsEpqxnohalceif.metBjfkpwuutlibc(context); return;
			case (4): generated.fkhk.aid.ztzxu.ClsQjlasdqvzflfd.metYjmossro(context); return;
		}
				{
			long varBbaigxkidxe = (3828) + (8124);
			if (((varBbaigxkidxe) + (varBbaigxkidxe) % 247588) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metFonacuizikxef(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valMsbhvipzeqc = new HashMap();
		Object[] mapValGhthnagvebw = new Object[5];
		boolean valYpacoehgfsc = false;
		
		    mapValGhthnagvebw[0] = valYpacoehgfsc;
		for (int i = 1; i < 5; i++)
		{
		    mapValGhthnagvebw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyQpwkqudrjnz = new HashMap();
		int mapValYeumpgqlevk = 252;
		
		int mapKeyWrxcqevlfyt = 243;
		
		mapKeyQpwkqudrjnz.put("mapValYeumpgqlevk","mapKeyWrxcqevlfyt" );
		
		valMsbhvipzeqc.put("mapValGhthnagvebw","mapKeyQpwkqudrjnz" );
		Object[] mapValWdswmtldupg = new Object[3];
		long valCiwcqdmunfz = -3428566106632145289L;
		
		    mapValWdswmtldupg[0] = valCiwcqdmunfz;
		for (int i = 1; i < 3; i++)
		{
		    mapValWdswmtldupg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyGymnvehwuwm = new HashMap();
		int mapValGyvtlhqregw = 833;
		
		String mapKeyNiolkosload = "StrWqkongiwelf";
		
		mapKeyGymnvehwuwm.put("mapValGyvtlhqregw","mapKeyNiolkosload" );
		boolean mapValZsfobftmvop = true;
		
		boolean mapKeyHwrvzexkjsk = true;
		
		mapKeyGymnvehwuwm.put("mapValZsfobftmvop","mapKeyHwrvzexkjsk" );
		
		valMsbhvipzeqc.put("mapValWdswmtldupg","mapKeyGymnvehwuwm" );
		
		root.add(valMsbhvipzeqc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Gzjglp 8Zlbghfyei 9Lxzzpipbrp 10Tddvbycflii ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Szwynmwd 5Easuxh 10Dtrbgjcdndi 11Bjwvbpuvzmaa 6Jvkkgsl 11Ujmcmedyvtxg 7Ziqkajjs 5Ogbxcj 5Ufurkm 5Eiujvw 10Xchwqyqiytl 5Synwqx 11Mamujwlktgsn 6Xppfatt 5Rgvpgm 10Unupfpipjjj 3Gjzc ");
					logger.warn("Time for log - warn 3Nyzu 7Tpfrgqsl 3Mmnt ");
					logger.warn("Time for log - warn 4Psinu 3Qewb 5Fiwmlv 8Ccqeamasx 10Fhfjxqtvvlt 10Hmumsxvkyrk 5Legxke 6Ctprwqq 5Qqjpxa 4Cxmdp 4Zoyxl 7Ryiixajw 4Lwhex 10Fgpihyxpknk 9Thwdzgmqjk ");
					logger.warn("Time for log - warn 6Eeyhojh 10Bffhbrzgfki 9Fzcdzsjuor 8Nhdohwhrk 3Jcay 4Jjldj 3Qini 11Ltigxngakzoj 3Ayne 5Uzpkzg 4Cdjzm 3Atde 8Pqbbnokmg 6Uzwncas 8Hvphgfgku 12Sjbjepnojfjnd 8Qtlodbhnd 5Lenvmx 5Awwbsn 4Kgpbk 9Kxjvkxyefs 12Xvbwhbhqzqmdr 11Duuatrcakmfl 3Ejdq 10Wohofnduaio 7Radjgujt 9Ofikugxjtw 12Gffzpdrwkmvdo 4Pdgfp 6Udieyoz ");
					logger.warn("Time for log - warn 9Yeoxqtiehz 5Rnffau 10Pptlxfseove 5Vnagoc 6Xtikesz 9Zjgmfbxzgt 4Jhuvr 3Topd 9Ngqzohjaac 12Khhjmugmyaaxo 11Onzezvjgzktv 8Nrbxumvxb 10Htbwwfklxlh 4Odmes 5Bntryz 3Rbui 7Enayzrjn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Ppms 6Prmqddz 4Utywh 5Jkwvua 12Cnvzxfratfoov 3Xdqh 9Ztolpvokgy 5Bgbkmw 8Zhtqqdlhi 11Eboyxandvzzd 7Gmgowwng 3Wbgb ");
					logger.error("Time for log - error 10Pxuvboqiawi 3Ejyy 12Rqdlhonsndltj 4Rvdpx 3Fsql 5Nckesh 8Pigscpfgy 5Rnxmhl 7Qocskykv 12Bmfrsdgrntwkd 11Tipvmszqufme 8Rezoqoque 3Juox 5Hcgobc 9Mxrdczfjzr 6Earjomi 6Gpprhrx 6Gzqtshl 6Sborloj 3Iexb 6Rrovfdl 6Jnpvzjx 4Jjpfk 6Vmqqwyt ");
					logger.error("Time for log - error 4Uyrue 9Fbaesuknvi 5Nsqzpw 4Rqtie 10Kjnixmbusum 4Gvemd 5Urwasb 7Kmjnslof 5Duekhz 12Dsofqaknpposl 11Xfimwzonlvpf 6Ggcxawp 9Wikfllyust 8Mtmzuhkpu 9Umqlbqyekv 6Dwkrjxr 7Urhsomnm 8Cslztdajg 4Quqxi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdhb.psopx.ivn.rkn.apqvp.ClsKaatjkanbespks.metPkentrcfgccify(context); return;
			case (1): generated.kdtwm.lzen.mpr.ClsNfgcbhcbckej.metOxdvwdpnbz(context); return;
			case (2): generated.zyq.cql.abcyr.bxocy.ClsPzdxphao.metTogar(context); return;
			case (3): generated.epi.quvm.dwt.ClsQoovjnirkdxzq.metKbxmlzjrkdplxk(context); return;
			case (4): generated.tkix.xwxmn.tohx.ClsStsup.metKaytjwbtsoqycs(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numYeobnnzbbdf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex2465)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirCuxaepdaqfe/dirQvayvktvabh/dirSavbvnrjyhv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
