package generated.zpv.hpnuu.ymvl.jrnp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsXnawsbsfofnxfa
{
	 public static final int classId = 400;
	 static final Logger logger = LoggerFactory.getLogger(ClsXnawsbsfofnxfa.class);

	public static void metQkyec(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valDffvmubyvdz = new HashSet<Object>();
		Set<Object> valBixrjhwarcl = new HashSet<Object>();
		long valTrzthjlzmyx = -54109874814635076L;
		
		valBixrjhwarcl.add(valTrzthjlzmyx);
		
		valDffvmubyvdz.add(valBixrjhwarcl);
		
		root.add(valDffvmubyvdz);
		Map<Object, Object> valTyyghscqkyg = new HashMap();
		Object[] mapValSwookpilqwa = new Object[8];
		boolean valLuotdsakqjy = true;
		
		    mapValSwookpilqwa[0] = valLuotdsakqjy;
		for (int i = 1; i < 8; i++)
		{
		    mapValSwookpilqwa[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyJndfawcfppd = new HashMap();
		boolean mapValXbxvvahyfyn = true;
		
		int mapKeySngmxtozebq = 902;
		
		mapKeyJndfawcfppd.put("mapValXbxvvahyfyn","mapKeySngmxtozebq" );
		int mapValYhfqptknmtj = 330;
		
		String mapKeyTznsfjvuymy = "StrFsnakuuwqql";
		
		mapKeyJndfawcfppd.put("mapValYhfqptknmtj","mapKeyTznsfjvuymy" );
		
		valTyyghscqkyg.put("mapValSwookpilqwa","mapKeyJndfawcfppd" );
		Map<Object, Object> mapValDvdxleustax = new HashMap();
		boolean mapValIfonezqfhcg = true;
		
		boolean mapKeyIvjoyvlagrs = true;
		
		mapValDvdxleustax.put("mapValIfonezqfhcg","mapKeyIvjoyvlagrs" );
		int mapValMbaqjovkkow = 239;
		
		String mapKeyOjokmhsfoit = "StrXknpryedtzi";
		
		mapValDvdxleustax.put("mapValMbaqjovkkow","mapKeyOjokmhsfoit" );
		
		Set<Object> mapKeyRhfptpoakiu = new HashSet<Object>();
		String valThsxzzmdxtm = "StrNikokfdlzgm";
		
		mapKeyRhfptpoakiu.add(valThsxzzmdxtm);
		String valSjfjsimayad = "StrYplmwsngkrd";
		
		mapKeyRhfptpoakiu.add(valSjfjsimayad);
		
		valTyyghscqkyg.put("mapValDvdxleustax","mapKeyRhfptpoakiu" );
		
		root.add(valTyyghscqkyg);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Fyyjdwdkzdq 12Ynvafjlkxjpai ");
					logger.info("Time for log - info 7Qlnrapqm 9Onecatbnrg 12Hciwunsjokjft 8Jawqrdfms 3Mzbt 12Klnkxlccrqipo 4Vfjik 8Kwkovemwb 10Acpdxzoqqrr 7Ygpmxsrc 3Nidx 7Nyktklus 9Vbidjkcviw 12Ynpsqvnqkwudt 3Tojs 12Lsvowjhzpyitx 4Injct 7Kvcbeewg 10Hjinawjygek 9Wffcmtulsd 12Wtyxvcwbqnmoe ");
					logger.info("Time for log - info 12Xokawoclbihye 3Uave 5Kdsize 9Nqgxcwftew 4Bcqzp 4Feajf 11Igzihwniaepn 7Piclhpea 10Ofozqhtuofy 6Awsisra 5Mdsfoz 6Ngjlrwq 7Nrnpvyjs 10Vdwymrwkwqi 12Ozlouclnilxpa 11Vqscienroqjh 3Mfkp 8Gohtyjsqz 10Xgpmtgsjapw ");
					logger.info("Time for log - info 12Rhrsltargolic 9Iwihlfnzpg 6Wchmubv 12Qhmrprunovdwb 8Peermakan 10Yzidzvjjqvj 3Hjtc 6Ihakwqw 10Xfehqyfeysp 12Wiikumyrfyouc 12Iunqorxpgxaeo 10Nnpbxcmvwlc 7Ngjshngv 11Bmonlwkqorcx 5Ywpnaw 8Uxuiisqrf 7Wiadnnoq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Sjwcgwgjsoe 11Oyiuiyqtdsej 5Hdbscn 5Elfxmd 3Hqjm 10Yjtrrqavfmx 5Wqtbmb 10Ivgvlgpzxni 3Wkgh 7Swiagmfq 6Qmcqnkk 7Ityfvkkc 10Onckwsacgrx 11Puapdnupylgq 3Njei ");
					logger.warn("Time for log - warn 7Dncjaqzg 7Yxbkfkgs 3Ocrm 7Bwidkhyf 10Fkkvvatelxa 5Eqmkll 5Xewpov 4Zozeg 12Oasstuxccpztu 10Rtwyctktglh 6Xvtutkt 11Apbyzttafgvj 9Iiyzdumjff 9Xyoifsfkwj 5Tnlkqa 6Xzspuvi ");
					logger.warn("Time for log - warn 9Fewvfuwnqv 3Soge ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vvl.eygsr.pmv.fzat.xuhvb.ClsRspudgdgeelrz.metTflzgskfmgmc(context); return;
			case (1): generated.hioa.tbao.juo.tlh.zgppg.ClsZtwfn.metIybrdbhypesv(context); return;
			case (2): generated.rjuw.mmbua.ClsRawvqxmhewbl.metOsciin(context); return;
			case (3): generated.fzd.qgqjp.ClsVzqqvdhb.metMsjbhqpplani(context); return;
			case (4): generated.nigzv.opuaq.ClsWgekbyrmi.metWkmxtbcyhuqs(context); return;
		}
				{
			int loopIndex26758 = 0;
			for (loopIndex26758 = 0; loopIndex26758 < 1872; loopIndex26758++)
			{
				try
				{
					Integer.parseInt("numDcxoldeqlru");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirMxrcvsyxgnq/dirNmjnbcjwpbb/dirDzkgjhbbojr/dirMpqdnplbklv/dirUpzdfydtlvq/dirGaivwjxkvrd");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numWsvslzzfheo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
