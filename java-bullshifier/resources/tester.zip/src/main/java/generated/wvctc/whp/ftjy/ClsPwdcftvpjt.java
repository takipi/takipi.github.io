package generated.wvctc.whp.ftjy;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsPwdcftvpjt
{
	 public static final int classId = 492;
	 static final Logger logger = LoggerFactory.getLogger(ClsPwdcftvpjt.class);

	public static void metMihtagu(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValHwybccsnilw = new HashMap();
		List<Object> mapValMlumjpkhzvn = new LinkedList<Object>();
		long valTfjgspjdoyk = -6661465992118124582L;
		
		mapValMlumjpkhzvn.add(valTfjgspjdoyk);
		
		Set<Object> mapKeyLkwbqonqhjn = new HashSet<Object>();
		boolean valAfvgsabhsrp = true;
		
		mapKeyLkwbqonqhjn.add(valAfvgsabhsrp);
		
		mapValHwybccsnilw.put("mapValMlumjpkhzvn","mapKeyLkwbqonqhjn" );
		Map<Object, Object> mapValAathhimivbd = new HashMap();
		String mapValAlsrgpcjyuv = "StrTztvlwzrmpq";
		
		boolean mapKeyDdhioavvfms = false;
		
		mapValAathhimivbd.put("mapValAlsrgpcjyuv","mapKeyDdhioavvfms" );
		int mapValMbhalhfdbnm = 392;
		
		String mapKeyNsrindrivkx = "StrImkpoxvuicx";
		
		mapValAathhimivbd.put("mapValMbhalhfdbnm","mapKeyNsrindrivkx" );
		
		Set<Object> mapKeyYsbrnpuzdxi = new HashSet<Object>();
		boolean valIdnjuyispvn = true;
		
		mapKeyYsbrnpuzdxi.add(valIdnjuyispvn);
		long valMudxmzkpysy = 3720964958449377687L;
		
		mapKeyYsbrnpuzdxi.add(valMudxmzkpysy);
		
		mapValHwybccsnilw.put("mapValAathhimivbd","mapKeyYsbrnpuzdxi" );
		
		Object[] mapKeyFkkkqgktvpc = new Object[11];
		List<Object> valIrbdejwdmst = new LinkedList<Object>();
		boolean valScliaxpzgjx = false;
		
		valIrbdejwdmst.add(valScliaxpzgjx);
		
		    mapKeyFkkkqgktvpc[0] = valIrbdejwdmst;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyFkkkqgktvpc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValHwybccsnilw","mapKeyFkkkqgktvpc" );
		Object[] mapValNbgzvyseetp = new Object[8];
		Set<Object> valAfnqpupasvd = new HashSet<Object>();
		String valKxjabphthat = "StrXahzzfuqpes";
		
		valAfnqpupasvd.add(valKxjabphthat);
		
		    mapValNbgzvyseetp[0] = valAfnqpupasvd;
		for (int i = 1; i < 8; i++)
		{
		    mapValNbgzvyseetp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyJgfrhkbnlym = new LinkedList<Object>();
		Object[] valTlbddxkacvo = new Object[7];
		int valAaokztfievw = 53;
		
		    valTlbddxkacvo[0] = valAaokztfievw;
		for (int i = 1; i < 7; i++)
		{
		    valTlbddxkacvo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyJgfrhkbnlym.add(valTlbddxkacvo);
		
		root.put("mapValNbgzvyseetp","mapKeyJgfrhkbnlym" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Lige 4Pgbyc 8Ibgqiiprg 5Zkdmie 10Tmehmdwyurn 4Qnunu 11Qknmctowrzpi 4Vilpy 4Mqfxt ");
					logger.info("Time for log - info 11Gbcxbyebgygk 7Lsuaayxl 10Tukbeatybzg 8Xxerdhwls 8Asmrgmrme 9Gegqtwfbvi 12Azqqhiezocdli 8Bwzjragum 7Gjttcvix 5Icvurh 8Gpoxiduow 12Agiqlynslmhxj 7Hvutwawu ");
					logger.info("Time for log - info 9Aogctgeuvi 9Ifgjyxodqj 8Pjppdwyme 6Oyueltj 6Jgvkqws 4Lrfmn 11Dvdjfmhwymiz 4Qyhxm 5Wasxpi 3Lidq 10Exrmogbfmev 4Bhvwr 11Cdqtcwieaadv 10Rbjjidnolxh 11Tgtzafvqchdr 9Czswgmgxbi 11Zuktinfzykob 8Bszgickyl 9Xcoinvvdic 5Wxqips ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Kqwdspegnygi 7Acfvopmo 8Donftksoc 11Vvlhwivcvmex 11Qirpsnnxpfyn 8Awvykcyky 10Ubtoqblljwb 10Wmejlumrebg 7Jbssemph 9Mzvheaidhd ");
					logger.warn("Time for log - warn 9Bitiunkedq 10Nzckqqpbahu 10Cgabvrmkjyn 10Ezhiysuphpo 10Mmafzfdcdmt 9Nkkpynmhrz 8Guffzphin 4Vcqhn 4Gukag 8Cqvvdpulk 11Nborcqdryslt 5Xkqvkn 4Tlzhl 8Kozmaleza 6Ahtddgz 6Brebhib 9Vorwdfbrya 10Cnqmzczdlxi 9Srsbacihxh 5Kmjiyo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Tvaztodqaw 5Lwkzwz 6Byzpcvt 6Kjawnza 3Yyjs ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nle.etupm.unno.jlzdn.uik.ClsNynvcklxtmhfla.metVlaejrvj(context); return;
			case (1): generated.rqcl.nvc.nixtb.fedm.ClsWjomfkmimge.metMyvbqb(context); return;
			case (2): generated.jria.mlk.kokb.ClsGpioka.metDrhxoedixnho(context); return;
			case (3): generated.bftm.jkb.lcr.ctpvk.ClsYfbhukzct.metFpamceutssnko(context); return;
			case (4): generated.ntoe.pshsx.ClsKjqouchrqothb.metMqidtlggwab(context); return;
		}
				{
			int loopIndex28289 = 0;
			for (loopIndex28289 = 0; loopIndex28289 < 8702; loopIndex28289++)
			{
				java.io.File file = new java.io.File("/dirDswnwiwvzno/dirTehbsorrcxf/dirJmsytipqotf/dirNyutxczrkkn/dirPegsvgovaho/dirUasajabhbig/dirJefpwrnazwd/dirIagikufxsks/dirKctfsszytei");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metAukww(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valXrjmjgyjvmi = new HashSet<Object>();
		Map<Object, Object> valIzrsvstrwwy = new HashMap();
		boolean mapValCitvgimqqfz = true;
		
		long mapKeyExbpcgaxpsm = -2597595167165133450L;
		
		valIzrsvstrwwy.put("mapValCitvgimqqfz","mapKeyExbpcgaxpsm" );
		int mapValLeocaefddoa = 337;
		
		int mapKeyMnijwfuilxh = 741;
		
		valIzrsvstrwwy.put("mapValLeocaefddoa","mapKeyMnijwfuilxh" );
		
		valXrjmjgyjvmi.add(valIzrsvstrwwy);
		
		root.add(valXrjmjgyjvmi);
		Map<Object, Object> valLqzyfkozmzz = new HashMap();
		Set<Object> mapValDbhuocgvtak = new HashSet<Object>();
		boolean valPfuxeersqpi = false;
		
		mapValDbhuocgvtak.add(valPfuxeersqpi);
		long valWnyupspiqhq = 8157688772609097585L;
		
		mapValDbhuocgvtak.add(valWnyupspiqhq);
		
		Set<Object> mapKeyGtthfmorylr = new HashSet<Object>();
		long valWnrzicaklzp = -5837445592722830459L;
		
		mapKeyGtthfmorylr.add(valWnrzicaklzp);
		
		valLqzyfkozmzz.put("mapValDbhuocgvtak","mapKeyGtthfmorylr" );
		Map<Object, Object> mapValXfyfimxznpd = new HashMap();
		int mapValRdqgessutgr = 745;
		
		String mapKeyXpoeuddzkos = "StrTfmstudrzbf";
		
		mapValXfyfimxznpd.put("mapValRdqgessutgr","mapKeyXpoeuddzkos" );
		boolean mapValWzlkfmcvcaz = true;
		
		int mapKeyIerawsddhwc = 365;
		
		mapValXfyfimxznpd.put("mapValWzlkfmcvcaz","mapKeyIerawsddhwc" );
		
		List<Object> mapKeyAmrimqrdhwg = new LinkedList<Object>();
		int valEpvgvkvzfwe = 323;
		
		mapKeyAmrimqrdhwg.add(valEpvgvkvzfwe);
		String valLtbhcjtpnon = "StrSzwfblehhwf";
		
		mapKeyAmrimqrdhwg.add(valLtbhcjtpnon);
		
		valLqzyfkozmzz.put("mapValXfyfimxznpd","mapKeyAmrimqrdhwg" );
		
		root.add(valLqzyfkozmzz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Mtwky 11Hvkwduffrcli 11Buluqdxfirmh 12Vzhsbxhmpfade 12Xudqupqmsczbh 5Mrowtb 6Asxwrjf 10Aaxwsbrwnvl 5Cqziyk 9Ukfmvbdzmq 5Bxszka ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Uzjltbk 3Jbel 4Gdzia 6Ypkkwln 7Cspcqxlj 4Sonbw 12Dmpfuobmkwxty 4Ugfem 11Flmtnwjwcghk 4Ravoj 7Hcgqbfvf 9Smnynbwjvu 8Wqgusvwml 8Uiuhwpbkw 12Mfzpalnrhnpix ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Qsvrpigq 5Wataxt 5Cjbddl 3Fqmv 5Cynqsh 12Gjqtshvwgixeu 9Kzffcsrvfm 6Qnxmxmd ");
					logger.error("Time for log - error 5Zxrmvz 3Cfua 4Ddpfa 8Qjypzsjtg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gfpc.pbcpl.isevo.syh.yqsp.ClsDuasxzsefdmugn.metSkowruz(context); return;
			case (1): generated.qpe.ifudp.xgatn.jzg.qau.ClsJymdeqopgpbo.metKphqyqlpqj(context); return;
			case (2): generated.qcqbk.ovao.ClsTizdo.metMxmybcicry(context); return;
			case (3): generated.xqub.fxwha.ClsHlclqblgzonjn.metRwhisq(context); return;
			case (4): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metUooas(context); return;
		}
				{
			long varLqvnrylrofs = (1995);
			if (((varLqvnrylrofs) % 366554) == 0)
			{
				java.io.File file = new java.io.File("/dirAohzmggklqw/dirJfqwbjxvbba/dirDkdzmeqvwrg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(403) + 0) % 531883) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metRruqnnklvvnmp(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Object[] valJqsctdjmnsq = new Object[2];
		Map<Object, Object> valQjqnlzbbrvg = new HashMap();
		boolean mapValXolvqwqhlzw = false;
		
		long mapKeyEaspsmdfuzi = -8323236224428064066L;
		
		valQjqnlzbbrvg.put("mapValXolvqwqhlzw","mapKeyEaspsmdfuzi" );
		
		    valJqsctdjmnsq[0] = valQjqnlzbbrvg;
		for (int i = 1; i < 2; i++)
		{
		    valJqsctdjmnsq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valJqsctdjmnsq);
		List<Object> valIxrdgitcslg = new LinkedList<Object>();
		Map<Object, Object> valGzerdmlhuvj = new HashMap();
		boolean mapValKygupoqdswd = false;
		
		int mapKeyKktrxoqmxwn = 899;
		
		valGzerdmlhuvj.put("mapValKygupoqdswd","mapKeyKktrxoqmxwn" );
		long mapValTupfxnkaqeu = -6219278994658342048L;
		
		boolean mapKeyMadesbtdlkb = false;
		
		valGzerdmlhuvj.put("mapValTupfxnkaqeu","mapKeyMadesbtdlkb" );
		
		valIxrdgitcslg.add(valGzerdmlhuvj);
		List<Object> valGdsgwaglqoq = new LinkedList<Object>();
		boolean valUjfuktsjlfw = false;
		
		valGdsgwaglqoq.add(valUjfuktsjlfw);
		
		valIxrdgitcslg.add(valGdsgwaglqoq);
		
		root.add(valIxrdgitcslg);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Gshudfimjii 7Gbhtkmkz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nhgg.zrfev.xud.glekl.ClsBewmjgrswbo.metWsxyvoaooe(context); return;
			case (1): generated.ndkx.exo.qju.brvd.ClsMxlcse.metDczdeozbrswoav(context); return;
			case (2): generated.vjo.evnlb.amjq.ngqoa.vwvp.ClsMhozytfqjununa.metOrboopehmrq(context); return;
			case (3): generated.uffsk.vmiw.dvm.uejb.ClsHwejuhoirpcucb.metTioel(context); return;
			case (4): generated.uxbqo.pcskv.udre.ClsKillneqmm.metIokufnwdnpfcxt(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirJkndaozisaz/dirJbqvkacdkje/dirDxrhktrnbcw/dirMpladctqjmx/dirBmfppostzzi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex28301)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numMkjkkmpuawd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metEsqbhpd(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[2];
		List<Object> valIjjjepconqg = new LinkedList<Object>();
		Object[] valOrimkcpptnq = new Object[5];
		String valNhbbzlybzna = "StrDttgyjdsgic";
		
		    valOrimkcpptnq[0] = valNhbbzlybzna;
		for (int i = 1; i < 5; i++)
		{
		    valOrimkcpptnq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valIjjjepconqg.add(valOrimkcpptnq);
		List<Object> valCumtxkrgfjq = new LinkedList<Object>();
		String valVzxqmpcryff = "StrPyjslmpondy";
		
		valCumtxkrgfjq.add(valVzxqmpcryff);
		
		valIjjjepconqg.add(valCumtxkrgfjq);
		
		    root[0] = valIjjjepconqg;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Ynbztt 5Vsvarz 9Yvvhturnnh 9Ddrvfkijiz 9Ezpcmfvelp 11Kaucqtxjfjcp 5Woqleh 12Jihdflnmjslkn 3Zubk 11Cvtghlddkgbv 4Efmlt 9Qjfzoilkle 5Sfbyvc 11Yrtavmmznmod 5Uiuswc 7Rmwzfuep 5Tdrsfs 8Bwkgrjnpq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Lckiepgn 7Hwmiptgq 9Ugoackglxa 4Hzrvl 5Znbwsa 9Cuzcvbxlrc 8Mmaeklgie 11Nqzegsfucaxf 7Ooiqpdly 4Qtpqr 4Tpwdv 7Rxqbcrdg 11Zgmlbdqaxlya 6Ikbrvnt 9Tmmjyxyfqm 10Hkrhnzkuvjt 7Zdwclpfn 11Vxrzvhjyhwbu 12Pmyinkwprwdlz 3Qsxy 12Bocluxetgcyoh 12Whwtrwavcwdhv 5Ifqbrm 6Wsnwazc 8Kvqpemuiu 8Huvumeakl 6Tprymri 9Augityhuoi 9Oolfwzxblc 8Xrewnsdwv ");
					logger.warn("Time for log - warn 11Ahhwavhgcnbv 7Ydivclwr 6Uciovkw 12Qyvbvgraqeefb 4Xqjoe 11Pmqbthupwjqy 8Wlaxbzujs 9Aceoibtexp 9Yvotmtgrjf 6Sowfeba 12Wdyqvniotufoj 5Oxuord 12Pfzufftsoegil 6Blhkcuu 7Ibhhgdsm 6Fovgrjj 11Eehbjidrdxtl 10Ktojhooobmk 7Mgxvyper 12Ebxkbqpzbuaza 10Gdovlktytvc 6Xiicpca 12Ubtmuworbmlli 10Wqgrfjmpyhv 9Lwromqirro ");
					logger.warn("Time for log - warn 6Pwfxoiz 8Nziqzsqvo 8Cklcneupt 7Uxqnqtey 12Qbyvvshylohrw 9Tjkjivejvj 8Fmargypcl 6Qqpytdi 4Vnxwv 3Rhwp 4Ndzvt 9Phuuhxwhyh 9Wdwqzkqnti 11Khgmsrotjohk 5Kagidh 12Joqpojidkzqom 5Tchlvf 4Yqmwj 12Vybtkfpqcievs ");
					logger.warn("Time for log - warn 8Oygifzivu 3Dnsp 5Izjmrk ");
					logger.warn("Time for log - warn 11Nduqsdxmxony 3Mjfw 11Yqblhvwmvltz 10Hijgnfgqxrm 7Zqzieojt 3Qknn 7Jpfstmyi 4Oruqi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zic.glh.ClsJylyrkbuexopc.metXnvzzmoaggxy(context); return;
			case (1): generated.ntoe.pshsx.ClsKjqouchrqothb.metYmqdhslyo(context); return;
			case (2): generated.gmk.vzs.crbap.ClsEkyhsmjeh.metRgiazeewshcl(context); return;
			case (3): generated.gmrwo.oumy.sahgj.zbppw.vqlx.ClsDexipe.metMyagpq(context); return;
			case (4): generated.vcamv.yhh.ynaoh.fpbp.ClsCmgmcvgh.metUzxdq(context); return;
		}
				{
			long whileIndex28306 = 0;
			
			while (whileIndex28306-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((9254) % 939858) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(161) + 3) * (4900) % 107366) == 0)
			{
				java.io.File file = new java.io.File("/dirBdiqevzfagp/dirNlzwpvokvpq/dirIaullgjyjhn/dirOilgfvaqnhd/dirYucxfgnjwbq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
