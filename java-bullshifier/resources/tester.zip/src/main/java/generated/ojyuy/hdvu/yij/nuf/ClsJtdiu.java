package generated.ojyuy.hdvu.yij.nuf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJtdiu
{
	 public static final int classId = 319;
	 static final Logger logger = LoggerFactory.getLogger(ClsJtdiu.class);

	public static void metUymohzkoe(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValFgkueqcgsiy = new HashSet<Object>();
		List<Object> valTxrblkglvxp = new LinkedList<Object>();
		String valTnmcwkwbqvk = "StrDsifhvohmki";
		
		valTxrblkglvxp.add(valTnmcwkwbqvk);
		long valGcpimoeyppz = -852810422366590272L;
		
		valTxrblkglvxp.add(valGcpimoeyppz);
		
		mapValFgkueqcgsiy.add(valTxrblkglvxp);
		Object[] valUgvkpcfqnos = new Object[3];
		String valLfckneweusy = "StrAsxqiledpck";
		
		    valUgvkpcfqnos[0] = valLfckneweusy;
		for (int i = 1; i < 3; i++)
		{
		    valUgvkpcfqnos[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValFgkueqcgsiy.add(valUgvkpcfqnos);
		
		Map<Object, Object> mapKeyDpwyumskper = new HashMap();
		Object[] mapValRxkeabsrtxf = new Object[9];
		int valBojotxxcyck = 301;
		
		    mapValRxkeabsrtxf[0] = valBojotxxcyck;
		for (int i = 1; i < 9; i++)
		{
		    mapValRxkeabsrtxf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyUxjmaqjiktc = new HashSet<Object>();
		long valFwompyrhjqp = 6310643123601139437L;
		
		mapKeyUxjmaqjiktc.add(valFwompyrhjqp);
		
		mapKeyDpwyumskper.put("mapValRxkeabsrtxf","mapKeyUxjmaqjiktc" );
		Map<Object, Object> mapValXxefqnmoonu = new HashMap();
		long mapValUdxlpqmyozg = 3931519493884380096L;
		
		long mapKeyJrjwaogmdgh = -8935520768722072360L;
		
		mapValXxefqnmoonu.put("mapValUdxlpqmyozg","mapKeyJrjwaogmdgh" );
		
		Object[] mapKeyDzisyokmruv = new Object[10];
		int valQwutofwonkv = 304;
		
		    mapKeyDzisyokmruv[0] = valQwutofwonkv;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyDzisyokmruv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyDpwyumskper.put("mapValXxefqnmoonu","mapKeyDzisyokmruv" );
		
		root.put("mapValFgkueqcgsiy","mapKeyDpwyumskper" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Vojfufyvyc 3Uolh 11Iqvqyasmpoqf 7Sorbhuqe 10Nfhouidibwk 10Ezciqgvwqoi 3Lufb 8Spyycmdbl 6Huawahh 6Ukhhusr 7Cljozamw 5Vjyvko 9Slsfqwvkza 5Onpvaz 4Phsoy 9Nbmiolpipf 12Jewuigliqmpdx 3Dyhu 4Nvgcv 12Gldkklbgmdzqn 5Wjbmux 9Aavxmaippf ");
					logger.info("Time for log - info 9Lztqwdmjnk 6Azwmydb 4Lfzbf 7Uovumpga 12Kfqkygmohcbwx 12Escfftrwmnknt 7Qftmkcwx 8Zdbajlxun 11Ugjjhvzihoez 5Ruswna 9Pkhxmnxlrs 3Syzs 6Dtsnpjx 5Finypb 12Qhsaycizzjupy 7Rjjnqjkc 10Heyprspxiaf 12Ablzcozwidkdd 4Ziwmu 12Tqydqnzqnktzv 3Nzlq 5Amuzlj 4Snlsp 5Osoxoy 3Rvjy 5Thhjyo 6Ozkonqw 9Pulmgyohcr 10Qmhkqdrzuiw ");
					logger.info("Time for log - info 3Febx 4Mzrlt 7Ufqsicjn 4Sxyws 8Ebrppvrxf 4Glejw 10Vvqgkadgjoj 8Dtmfzeocw 6Zijhkvy 12Kuiqpmgpfmoih 5Qbokqt 9Lewuzbnfyx 7Nhmjyoiv 10Nodjnkqefmj 5Ivxzby 10Cwzochdsxbt 10Zjmquamadbv 4Xfpwu ");
					logger.info("Time for log - info 10Tksixcjijph 3Nfud 8Wpjzjuafm 9Wdcpzjevwj 10Lusyghddptl 9Ycrkwpehiv 5Zndlav 9Uvkzepvehs 3Hrfk 3Dcto 10Urxfaytqcac 7Xomanqvl 6Lhvwrbr 5Lmaegk 7Muayyser 3Szns ");
					logger.info("Time for log - info 10Kboqranrepm 12Hnihasvxxwros 8Poxsidctd 9Vpkxqmuzdm 7Qpdiitnc 9Yrpyieqnyp 4Aqgcr 3Ytao 11Tpkziiysjlbs 10Kqungbzmkyc 6Vqgqhad 4Bncnf 3Yyhk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Uxjiwxh 6Emveldh 5Fhvvok 8Tknbyvfkc 6Xselhrv 9Mvjzhxowyt 10Padfuqmbkue 11Guiaoiyfmhna 7Fngynaiz 9Ahncwujgnr 12Aoortrdvpjtrt 6Clgwjbx 6Bbjkvxg 5Tufypv 12Iprgnmzecoglp 5Wbmtao 6Yuuxrxt 10Ezexfpyocqd 4Yjwqi 9Wkmarvnsjt 7Rahapbnd 6Cotoabv 7Klepbllw 7Fkygkclx 3Vixb 9Bncgmwrlfa 8Tadcwrexk ");
					logger.warn("Time for log - warn 8Ghreaxerk 9Lwkpepofra 9Qnfuhyupdt 11Sfyhbehwrkmx 4Sjvkj 10Mcskfxnrism 8Fnyarsxbs 10Cazkjncjbjt 9Ystrdqycry 4Prdgt 10Ikgqxwvgczi 5Etkysi 4Rsynz 8Ufupuxjbn 3Gioy 3Qbjs 9Ynvqnjgkaw 10Uiwjxjkalaa 11Vxmqiakbfkmm 10Biqjmdbhmiw 6Pvifxsa 3Hapy 8Lgrsjdkrb 11Cocvlvjcnwcj ");
					logger.warn("Time for log - warn 7Psgwdywe 8Wqhupircr 5Emrvse 11Iqyzjnyzufyn 3Sbzt 8Civhiqaev 7Ufyoykzb 5Mavbmh 5Lzhgjq 3Vtds 6Ekapbsa ");
					logger.warn("Time for log - warn 7Zmaxajxc 12Guqqcufdqdemq 5Brgsrt 5Pxlell 5Jyckuq 7Dzxxlybw 12Fxmihnyzdxozf 11Iihrpmoauzzo 8Myuzqwduf 10Tjogfmmwzsl 9Fzwojxivcb 6Rcbqgxo 3Laaw 9Bqbemydqiv 4Zcncx 5Ufsudx 8Ndyaruxbz 7Emzswrde 12Pexndwnztgdaz 3Xihk 12Jndhtvsxfwivx 5Ulhdgt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Etstjqptpv 5Gphamc 6Jjigzyk 4Ydzfk 10Svkifahdfxv 11Nvpffqyaemze 5Aqpnqa 8Vhnluagmf 4Nclxb 11Kysxthziifkm 7Jpdwejpi 3Mipx 6Nmqtsnf 12Poufpmmgrfilp 5Emswri 3Eung 5Bltobi 6Gvwnifq 10Bcjgsdyrtgj 3Ptnx 6Kgxjwxe 6Xugryot 4Fowdc 10Kwrgfazlzhb 11Ufrymcfmkjhv 4Rtmhj 4Xfzxa 12Magjiikutmvsk 12Stmvmizbxzxmu 3Wpzh 12Vhnkvmxaxhenw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.duzy.rxrsw.ClsQbnde.metFjxesghunaac(context); return;
			case (1): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metOsxqvqfsqlaj(context); return;
			case (2): generated.gmrwo.oumy.sahgj.zbppw.vqlx.ClsDexipe.metBsktjpxjygwoz(context); return;
			case (3): generated.olnh.vng.ClsLcraqevyogmja.metHrpnbihsknjv(context); return;
			case (4): generated.oue.dqjq.ClsSjudu.metWeuhgimyctvvr(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(793) + 6) * (Config.get().getRandom().nextInt(868) + 1) % 546271) == 0)
			{
				java.io.File file = new java.io.File("/dirJluwjtfqehx/dirSyhbfepfayr/dirDbnzwdxqhcn/dirPzhrqafqlma/dirQtpuzjitula/dirVynauffouzw");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varOueumikqocd = (Config.get().getRandom().nextInt(913) + 9);
			if (((Config.get().getRandom().nextInt(339) + 9) + (varOueumikqocd) % 659980) == 0)
			{
				java.io.File file = new java.io.File("/dirQgrrgvsarxp/dirZokxhsxvscd/dirJsjeaomxxif");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metTlubvqwqs(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valJsuixxhyvyz = new HashSet<Object>();
		Map<Object, Object> valRckjgxasuno = new HashMap();
		int mapValNjbzmhoizog = 767;
		
		int mapKeyRwrzqhajttx = 753;
		
		valRckjgxasuno.put("mapValNjbzmhoizog","mapKeyRwrzqhajttx" );
		
		valJsuixxhyvyz.add(valRckjgxasuno);
		List<Object> valLekkkkyuqei = new LinkedList<Object>();
		long valHhocaqzwtpp = -5987506593686479901L;
		
		valLekkkkyuqei.add(valHhocaqzwtpp);
		int valExanybhoakk = 353;
		
		valLekkkkyuqei.add(valExanybhoakk);
		
		valJsuixxhyvyz.add(valLekkkkyuqei);
		
		root.add(valJsuixxhyvyz);
		Set<Object> valAbkpziaqipx = new HashSet<Object>();
		Map<Object, Object> valKoosvkyshxm = new HashMap();
		String mapValRgxoogikxmk = "StrIdbmbeyslvx";
		
		boolean mapKeyQybcvslwdnx = true;
		
		valKoosvkyshxm.put("mapValRgxoogikxmk","mapKeyQybcvslwdnx" );
		
		valAbkpziaqipx.add(valKoosvkyshxm);
		
		root.add(valAbkpziaqipx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Flycb 5Bzpelt 3Gdit 11Ojhavnqdteud 9Nhrzeshsxr 12Zecjdegykvnuv 12Tttsohejctgrs 8Kcyfzrthe 11Zycivdraogky 5Ccqauv 7Jdlbsdhn ");
					logger.info("Time for log - info 12Rprbbfkxoxeps 7Heitefmr 3Ftph 3Hjqw 6Ttuxgsj 12Acekkqsvhivza 3Hejw 10Llyxxvzpevq 8Mbgwtkkoo 10Xmhqqvcouht 11Vtfivpcnrmgh 6Vuvdapd 10Ujjuagzbvys 11Apjmlwoawhyd 10Pjsdwhriunf 9Sfpbgpyyen 9Avycpfowkq 4Txcst 11Ilnneewiagnf 10Myrgtbxbuie ");
					logger.info("Time for log - info 10Gcgjkxrhtbn 7Dnyflqur 9Lwzolyxucm 10Ewrnykzghhr 4Nrbrs 12Mbmsnxpzhzqrx 7Jgwcqeaf 9Ufhxtiimva 4Yqela 11Vebbsruftijo 12Dwqfmdnifeuoi 6Sexdrhy 9Gmjxocszaz 12Xhdyswrgsyryc 12Syqsmpfnubqxo 5Poemfz 12Jruigksrpgdhg 4Zfkjt 12Idexfmbhnypwr 8Umuavgyps 12Gvrmbgrtxosjf 4Afxll 7Xrhupude 3Mtrz 9Cxjapntkng 4Hbigi 6Ffzlthb 3Nrqj 5Qeifcf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Fxpiqlajd 5Omrnmn 9Yzvywwtoyr 8Cafznhfbd 6Aqapgnj 9Xkeuessgsf 6Ocdrgac 10Ldtgoshdggr 10Fnizdrvqlvn 8Wcpuxgizr 10Rnjyzugmrgv 12Brtkflkezacge 12Zibzxomhlnuwb ");
					logger.warn("Time for log - warn 10Pcmewyyrret 10Yabvbskhpya 4Ytubh 5Idgwtp 7Fenrclie 5Fhcrxj 3Uait 10Zpfzrquzdxs 9Eyorzgcsrx 9Wycvpjynwb 8Lufyzqxya 10Yodatfpsjua 7Vwzxcbnx 12Wdrfdsemigqnn 8Ynrwuordk 3Romo 8Vtbadamxb 9Ujrrfwcnsl 12Ijiedsiogpnot 4Vqclu 11Aqszwxisogyy ");
					logger.warn("Time for log - warn 10Pyrfhpoihqb 7Jcghlbmw 4Jaddj 8Gxgnhlwxo 4Tspev 12Jjmeixfkvtyqq 6Lwtqlrn ");
					logger.warn("Time for log - warn 11Jrcugovfuyxu 5Vdcbnn 9Qeqqmgqgvd 12Gypevfkxtonuw 11Svxzyenbmvtr 9Fpcukhxztv 11Aicqrzlaystv 12Fenpnwdpvznsa 9Kcdzvlgkkk 6Jrivjjd 3Qzvz 6Ujgliqu 10Tykyesudcog 11Lbbnyptraksd 3Adxv 10Sigonzixmsu 10Nxwfhnxgviu 7Pmoiacdg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Wzcxzjzhyrsh 3Yety 9Nvnvggumjo 6Icwurgt 10Qytskhirvpw ");
					logger.error("Time for log - error 7Sfxvrfjf 6Smyhxwe 5Vlhwxz 12Ofitztrulqqic 6Lamlbjr 11Mvkvyqsxdveh 9Rdkqgizcbd 11Idlmzpqbaghn 12Akabwdjzjydcm 9Xowuqlmhla 12Yifsdqqybkkol 3Wnbl 6Aaqsxbd 11Zrbpypjtxneu 11Ubxxpopkmeuh 9Nyhwxyzpdg 7Mebzlbpq 6Rslwelk 12Qmwvqedewyfqy 3Pibv 12Nkrmoqoedonzx 8Fsagsfecg 12Nvistwtwackxn 6Yyhtrmi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gfiaw.wgvz.askqs.ClsGbqekumwdbwfn.metRznpltfgjhr(context); return;
			case (1): generated.ythhn.vxvz.yizb.ClsLckdkkeapmss.metHwwjfniyy(context); return;
			case (2): generated.lnvho.rhfct.ClsGgdasahuvsgcd.metSxkgdfchrlbdm(context); return;
			case (3): generated.ctymn.uic.kza.ClsBochsrrjh.metGygnvmjatcdvgy(context); return;
			case (4): generated.hkyc.tzi.ClsYwknearnl.metPubmxeffq(context); return;
		}
				{
			long whileIndex25412 = 0;
			
			while (whileIndex25412-- > 0)
			{
				try
				{
					Integer.parseInt("numKhxhzlzfbho");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varSmdmvaunlug = (Config.get().getRandom().nextInt(801) + 1);
			int loopIndex25414 = 0;
			for (loopIndex25414 = 0; loopIndex25414 < 823; loopIndex25414++)
			{
				try
				{
					Integer.parseInt("numXamxscjqsoo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
