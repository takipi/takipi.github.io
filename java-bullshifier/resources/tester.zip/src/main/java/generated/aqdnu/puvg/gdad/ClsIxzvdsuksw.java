package generated.aqdnu.puvg.gdad;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsIxzvdsuksw
{
	 public static final int classId = 134;
	 static final Logger logger = LoggerFactory.getLogger(ClsIxzvdsuksw.class);

	public static void metItvqgpv(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[4];
		Object[] valNpzzwjaprel = new Object[3];
		List<Object> valZaeckjfaaqj = new LinkedList<Object>();
		int valSjfmpazwvgw = 37;
		
		valZaeckjfaaqj.add(valSjfmpazwvgw);
		int valIeryouvpwet = 526;
		
		valZaeckjfaaqj.add(valIeryouvpwet);
		
		    valNpzzwjaprel[0] = valZaeckjfaaqj;
		for (int i = 1; i < 3; i++)
		{
		    valNpzzwjaprel[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valNpzzwjaprel;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Jsujs 5Upmwmt 5Rxnrvq 9Pwghprvkfy 5Omirao ");
					logger.info("Time for log - info 5Ragnrp 12Ckankfhagqmyi 7Zdziivpg 3Evzy 6Uktrcsb 5Ewbxbt 11Qmnecsidpqck 12Upxdwlblellup 7Zvofwczy 8Pbqpbpadn 10Tbbfcgfjygi 5Gjuvli 12Jjkrynaanspyy 7Gyepfwlg 10Adqiyqmevrj 10Aujzvhbjfll 10Skxbyalgayi 10Cdjtjqagitc 4Isree 11Lxwcknxoqolg 11Obqaaiqxyvuf 7Ecwyfers 12Lowcbcobycxse 7Oikfzicw 6Kodrvql 7Iotgpbgi 9Ocmdycfeqt 10Znoxqtqmgww 8Ryjuocdxw 7Wsgqkfaq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Hwzimn 5Nvxwvz 11Aghdtrtdtjhx 8Fcvqhiaug 6Wmmhgtv 6Oztxafm 8Dvcjueikf 4Wqgtk 6Kalzrhl 7Lbecxuag 3Wxim 4Guivd 12Vdokayvvqgrhy 3Nxfw 4Pcsdb 5Agoxrm 9Fzifgqquye 11Bzxvtfaeuxou 6Rdlxgjg 5Xtpucb ");
					logger.warn("Time for log - warn 7Ugvyemdh 3Dzsk 9Iknqxdxbef 7Mafvjtwo 11Nabzctolkpkt 12Ajkpnmsjajbbm 9Vdhqmqlhwi 8Tshqkhlhn 9Dckuslpspe 8Auguhijib 7Fcjsovmd 12Gzhphvuamabea 11Ftzastozfpvn 10Mcugyogpnxc 12Xggnrpvwkmcos 3Uzgj 8Vyajdvilm 7Jmqjzpxl 4Zmqcs 12Gmrbijmgqzvag 4Nwkvv 5Dybfsk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Lstkgaucr 3Wqoq 9Hgevhtfhrn 10Zomswwmnfxr 8Vfvpnwwyv 6Paeoewo 7Gxvgbvmd 7Qthszjon 10Mbbjcqgklma 12Mujnvsbbzribo 11Ztilyxvvooob 7Faeouucu 11Aapecrtuytfg 4Bcdmz 12Yjtolravubpas 12Fdwsjcysuosvb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.udzdg.aoq.runwl.jiwf.ClsBbcobewbgt.metVygkbiannogx(context); return;
			case (1): generated.cin.hewe.akg.wyf.seuvv.ClsFgxjhcrdocnyas.metKhzutma(context); return;
			case (2): generated.jmrw.ryri.ClsDmqllltcxdlzd.metYuhkkpnyjimu(context); return;
			case (3): generated.mccr.hhayo.cgyp.gjrvj.ClsTjitk.metTxgopsgvmsurv(context); return;
			case (4): generated.njly.vbegw.ClsZmoko.metPycenvfgxhrdu(context); return;
		}
				{
			if (((2689) % 472424) == 0)
			{
				try
				{
					Integer.parseInt("numHaqgzuvurzy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numYjvgskyfjbo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((Config.get().getRandom().nextInt(83) + 6) % 903568) == 0)
			{
				try
				{
					Integer.parseInt("numEadkloyjeir");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((8005) - (Config.get().getRandom().nextInt(152) + 5) % 821504) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metWaxopqbol(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValWmdbaoqhzue = new Object[11];
		Object[] valGgqepexelop = new Object[7];
		long valMazukzdrwta = -6753074563943700518L;
		
		    valGgqepexelop[0] = valMazukzdrwta;
		for (int i = 1; i < 7; i++)
		{
		    valGgqepexelop[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValWmdbaoqhzue[0] = valGgqepexelop;
		for (int i = 1; i < 11; i++)
		{
		    mapValWmdbaoqhzue[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyBnqnphiulgt = new Object[9];
		List<Object> valCodsmeaffom = new LinkedList<Object>();
		long valYlmzkxtsfbg = 3320778133052464884L;
		
		valCodsmeaffom.add(valYlmzkxtsfbg);
		boolean valUjlqpvnnndi = true;
		
		valCodsmeaffom.add(valUjlqpvnnndi);
		
		    mapKeyBnqnphiulgt[0] = valCodsmeaffom;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyBnqnphiulgt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValWmdbaoqhzue","mapKeyBnqnphiulgt" );
		List<Object> mapValKwfgbuerltp = new LinkedList<Object>();
		Set<Object> valGkhrzdzjtce = new HashSet<Object>();
		long valRrxuognzqdp = -8404722047703785154L;
		
		valGkhrzdzjtce.add(valRrxuognzqdp);
		
		mapValKwfgbuerltp.add(valGkhrzdzjtce);
		List<Object> valNdsfammaeui = new LinkedList<Object>();
		boolean valSvehramlnqu = false;
		
		valNdsfammaeui.add(valSvehramlnqu);
		boolean valCuzhkwwwazg = true;
		
		valNdsfammaeui.add(valCuzhkwwwazg);
		
		mapValKwfgbuerltp.add(valNdsfammaeui);
		
		Object[] mapKeyZissgsksrvd = new Object[9];
		Map<Object, Object> valAhopeyjhapg = new HashMap();
		int mapValXuaakjsrqlr = 714;
		
		String mapKeyZmpiftcupbd = "StrKlxechwwsnw";
		
		valAhopeyjhapg.put("mapValXuaakjsrqlr","mapKeyZmpiftcupbd" );
		boolean mapValRqjlvwegdho = false;
		
		int mapKeyHwzprravjhj = 958;
		
		valAhopeyjhapg.put("mapValRqjlvwegdho","mapKeyHwzprravjhj" );
		
		    mapKeyZissgsksrvd[0] = valAhopeyjhapg;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyZissgsksrvd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValKwfgbuerltp","mapKeyZissgsksrvd" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Wgog 6Yhsqiav ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gfiaw.wgvz.askqs.ClsGbqekumwdbwfn.metPzonhuiu(context); return;
			case (1): generated.ylqx.lamew.rrd.tiu.hut.ClsBorecfhsp.metHsrsgh(context); return;
			case (2): generated.tyg.mzcly.ClsYmwmvdb.metOjvgmec(context); return;
			case (3): generated.qwlax.zei.ClsAdxloruwrrth.metHsjxayjzgkwe(context); return;
			case (4): generated.bwwh.pcsa.hpav.bbh.ClsXicvnzwjqnoh.metTwqbt(context); return;
		}
				{
			long varWzvbntjcekx = (Config.get().getRandom().nextInt(951) + 2);
		}
	}


	public static void metUndfk(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		List<Object> valQelztcylxii = new LinkedList<Object>();
		Map<Object, Object> valBhbrhynucli = new HashMap();
		String mapValPbxpgnvrzdf = "StrVnxljcbyioc";
		
		int mapKeyXjkpesrcvop = 489;
		
		valBhbrhynucli.put("mapValPbxpgnvrzdf","mapKeyXjkpesrcvop" );
		
		valQelztcylxii.add(valBhbrhynucli);
		Object[] valOpezxqzcbpn = new Object[2];
		boolean valTzinielihda = false;
		
		    valOpezxqzcbpn[0] = valTzinielihda;
		for (int i = 1; i < 2; i++)
		{
		    valOpezxqzcbpn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valQelztcylxii.add(valOpezxqzcbpn);
		
		root.add(valQelztcylxii);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Ttuycmeznku 10Fyocffkizby 12Awlrcebugnoyp 6Iidpocs 7Rluedvkr 9Yrjiklckpr 12Vdhdbjojkvvao 5Rgtgii 4Oatbi 12Dgrivbnpedgiv 3Zboy 8Ikqxoqhox 8Jruglgawg 8Etcrlerlf 8Locagiyxz 4Iggrh 6Kqspocd 11Lvlcdvirrzqh 7Mhcwnojc 11Tosgqrlxxqdg 11Umcucpgmrvyi 4Yqlnu 5Tpuarn 3Chkm 5Vipney 12Kllqbqmdcoeln 7Sxaleacx 3Mphi 6Qyvskvh ");
					logger.info("Time for log - info 5Nnuhrr 3Zfpa 5Sdswiy 3Msxo 4Usiep 9Zhmxkewfop 6Mbqkvcu 8Obxknmjdz 9Uudwwcaqov 8Nzygxrdnr 5Towavd 6Fcuyvwh 11Sjcdfaagkczi 11Bguualyupfbf 10Ccblukqdnje 8Nnblafpcz 11Viszljbnuupj 5Isjkmx 3Shqr 4Ppufb 9Falvleitya 3Rvgk 12Uhkzodmpjsfvp 7Cldotgrf 11Miabxozfctbt 7Kvdtmhzm 12Hshlqsqbwqkmn ");
					logger.info("Time for log - info 8Nvhszaswo 10Feazqqwihnx 4Blhqw 11Qqeumyftndca 7Dlhgtwim 9Vhggeeyczn 7Ceeqlmnw 11Eprpqtbxsyph 6Lancojq 8Wvepnbnzc 7Dqvlocba 11Jahxicwftfkk 11Snleltuzmmgl 7Weojkwxq 3Ebbh 11Nwbxpyffcfli 3Gecx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Zmjkwzx 8Twpihzxzk 6Lbspgrh 6Rvycjhu 9Pdzshiwnqh 7Kzvqfctn 7Ywsendfr 4Oiiuf 3Uaex 4Zacpe 12Riybznwlasizt 12Pjfttgcahctac 6Qabxfqi 12Vwiptoaicnlhv 9Gaxwrhqrmw 4Jvqsg 12Vmkzpjlirytyw 12Wxellrwxmrdkx 11Hacfkywjszsi 3Qgfp 9Ikaiqszziu 5Yedwib 9Rjuleoaqpo 11Axzuhztxfcsy 6Yyvztrt 11Aagknjkwzaip 3Iyoo 4Ogvld 5Bxpxyu 10Vjlkrxlsooh 11Vmwhbqfjsdlq ");
					logger.warn("Time for log - warn 6Yetlyan 4Ikugr 6Lxwcyqv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Ohns 8Jwamcvfpi 9Umczvfuggw 6Wxcptmp 7Pqdrexuq 8Xcwwyxudx 9Nuaunrtywb 5Opcvuj 4Lvgdx 10Rudtqohwvsi 5Lgqwiv 9Tgnkcceiea ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qyalc.lus.ClsKvouelboluo.metVctwjruk(context); return;
			case (1): generated.pxdt.vcuzq.tfk.bjngo.ClsCaopcwu.metNrjzvdamjddqk(context); return;
			case (2): generated.aneiz.novw.ClsBxulfvm.metSgvcxn(context); return;
			case (3): generated.wmjc.yywge.qivf.ClsNtnaiojgyo.metQvixcwqsm(context); return;
			case (4): generated.opcr.jgy.rftd.rkx.ClsJjouwg.metKtdrtpazip(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(327) + 7) - (7654) % 331591) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(651) + 9) % 620057) == 0)
			{
				try
				{
					Integer.parseInt("numZyifzvqijfm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
