package generated.qivmb.wlyy.vhwlw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJhewvjqlcuh
{
	 public static final int classId = 395;
	 static final Logger logger = LoggerFactory.getLogger(ClsJhewvjqlcuh.class);

	public static void metPrdwqfyayzwd(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valOatnfzbfpsb = new HashMap();
		Object[] mapValYjrwkcdbffd = new Object[5];
		boolean valZpxvtzcjxrw = false;
		
		    mapValYjrwkcdbffd[0] = valZpxvtzcjxrw;
		for (int i = 1; i < 5; i++)
		{
		    mapValYjrwkcdbffd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyPrjtvuuzjau = new LinkedList<Object>();
		int valRjvdzpbbyvz = 369;
		
		mapKeyPrjtvuuzjau.add(valRjvdzpbbyvz);
		long valWokylpwkbyx = 103591038584460993L;
		
		mapKeyPrjtvuuzjau.add(valWokylpwkbyx);
		
		valOatnfzbfpsb.put("mapValYjrwkcdbffd","mapKeyPrjtvuuzjau" );
		
		root.add(valOatnfzbfpsb);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Axshdfb 11Lvekhffkfscf 4Pmxgd 9Mmcokgwxpd 5Paeyel 7Zuklfmis 3Gjns 7Reibnbsw 12Mjxktldxlaufn 7Rfftliro 4Sfztm 5Gbzitc 6Dsmsddq 9Hdqxrehyon 4Zline 11Dbtljnpfvxst 9Xiaofpzuxc 11Hjsjxhnnocfl 6Ighschw 12Tcwekfwwqsijs 8Elcqwpeiv ");
					logger.info("Time for log - info 8Algyjsibv 9Hmxqybileq 6Zxophwk 5Hidqzj 11Jnfsbcgccqmq 4Zbljf 11Eosiemswlaql 12Skekqugccfnsa 8Ralemlluw 11Zrvrlsicswrt 7Pwgqivms 10Puyeqmhgwts 8Wecrbirvj 5Jnwblw 8Xcldhyzay 3Jxrl 12Fahswtoersycc 8Vnqcybriq ");
					logger.info("Time for log - info 7Fblkdhbg 10Krevatcjtwa 4Ncwvr ");
					logger.info("Time for log - info 10Mknpokivqtc 3Blvz 4Csslc 3Hhge 8Zepdkishl 6Ltgnzmw 5Yfuhny 5Fnpkza 11Tlgzgpwsgity 4Gwzto 6Cngfdwl ");
					logger.info("Time for log - info 3Zwwp 12Ecmezgprylnfa 4Iasjt 7Hmuauifp 8Karhbjoic 4Lqbct 5Jcgnhf 3Yikn 7Szwbgqns 4Kznup 7Dpwclrnq 4Wvjpn 12Ypycouxltatak 6Ejqnodn 7Lszlbtib 8Tsjiiyiak 5Isrrwv 4Oexnj 5Btrmpi 6Llihpsg 4Kgiqn 3Zbbf 11Cxqqicrgilar 9Qfjrvsbkwc 10Nzmxdyxusyi 4Ujubj 9Tgeahorsbl 5Ysfuyf 8Ubmnsggyi 11Mkczmyicngeg 6Chlfgko ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Ozvwcevbelkd 10Pobkzylaxkj 4Ygeli 8Hieytgenp 7Tvncglre 4Mothy 5Xwjpsk 9Ivcrtmoiyd 5Lxwbpd 3Jjpb 11Ejirfeujlzjl 4Mgqbg 4Ggxhp 10Iswuujzduab 4Ojexc 12Lzrbfgejbbjfc 10Wbsnudfcagj 12Awkxfpszzgruu 5Fwlnxy 4Mrueq 9Cezfvhanzs ");
					logger.error("Time for log - error 4Kaeea 10Jkgqvaspmpx 8Kirlrlrzi 10Bkjbyrzxqhc 12Rcwamqdusogaa 7Ishfmgrh 4Fzbpc 9Dqpawmrpmb 8Wkkjrmqgs 12Uvsivnyrqijix 5Xxreud 9Waiyhjkhur 7Yvqubrkc 4Yjxnk 12Dbevdakcakfcl 8Ydknwndxq 12Mjfgxsjsavcvd 5Udupza 4Jisyw 12Fhxdfhpacilrm 12Ctaeesydgqtep 3Fajz 10Psiwfrwtzdu ");
					logger.error("Time for log - error 10Sruorfaobtv 4Zjdhz 6Tqubovw 6Mxiesyo 8Haultzfpv 7Nxyfuxij 4Xyjff 4Xmnhm 8Gsqbseaol 5Wbanth 6Ecuqeys 4Hnjho 5Wsxrjy 3Wyfo 12Jydukbbrdwqmv 4Tjvxu 8Nazskvijq 6Nafssnz 10Ivnqpnlwhwf 11Qnpnplwnauvt 7Necohnub 9Mieguvvjow 9Aqjmoxlbso 5Iscioe 10Obsalrqnowp 3Shil 6Hhklidu 11Naumfihtvkzg 4Ewwwg 9Chgxrhoxcv 9Tffzeiwhzj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pef.kybz.yzpf.dzs.obqpv.ClsKizvnatyigi.metKzutin(context); return;
			case (1): generated.wier.vwsz.frtoe.zpo.ClsRwhkekxcsmjus.metDnxwcgye(context); return;
			case (2): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metJkpdv(context); return;
			case (3): generated.sik.dyw.jmm.xdu.omh.ClsVarjcvcyur.metBzwka(context); return;
			case (4): generated.bhfun.zpnwj.czfe.augg.ClsEdcxpvndelttu.metSjwyu(context); return;
		}
				{
			long varUbtkoseghet = (2724);
			if (((varUbtkoseghet) % 717843) == 0)
			{
				try
				{
					Integer.parseInt("numUtjljgoavie");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			varUbtkoseghet = (varUbtkoseghet) - (varUbtkoseghet);
		}
	}


	public static void metAouqfagpakd(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valAmdkzcppyth = new HashSet<Object>();
		Map<Object, Object> valOutldrtkkoa = new HashMap();
		int mapValBgnhtdkobwl = 678;
		
		String mapKeyZajkszocilm = "StrXqtaoefgzax";
		
		valOutldrtkkoa.put("mapValBgnhtdkobwl","mapKeyZajkszocilm" );
		
		valAmdkzcppyth.add(valOutldrtkkoa);
		Set<Object> valQysiqpwcaqy = new HashSet<Object>();
		int valBnzhggczauh = 635;
		
		valQysiqpwcaqy.add(valBnzhggczauh);
		String valVgrogxkcgdd = "StrDihaacevaws";
		
		valQysiqpwcaqy.add(valVgrogxkcgdd);
		
		valAmdkzcppyth.add(valQysiqpwcaqy);
		
		root.add(valAmdkzcppyth);
		Map<Object, Object> valXaogzdpbmuu = new HashMap();
		Map<Object, Object> mapValEjkmcnrdrbn = new HashMap();
		int mapValIhzjvwtbrjq = 439;
		
		long mapKeyNnyyuwpxgut = 2234297261914829327L;
		
		mapValEjkmcnrdrbn.put("mapValIhzjvwtbrjq","mapKeyNnyyuwpxgut" );
		int mapValNqbhufsczcr = 709;
		
		int mapKeyIsbafnsvbvx = 113;
		
		mapValEjkmcnrdrbn.put("mapValNqbhufsczcr","mapKeyIsbafnsvbvx" );
		
		Set<Object> mapKeyTjeszbkndpr = new HashSet<Object>();
		int valJkewjchflyq = 592;
		
		mapKeyTjeszbkndpr.add(valJkewjchflyq);
		
		valXaogzdpbmuu.put("mapValEjkmcnrdrbn","mapKeyTjeszbkndpr" );
		List<Object> mapValJhbsmfvcisb = new LinkedList<Object>();
		int valIisqukyabur = 834;
		
		mapValJhbsmfvcisb.add(valIisqukyabur);
		
		Map<Object, Object> mapKeyQozrkpegkza = new HashMap();
		boolean mapValUmhuvlwcwow = true;
		
		String mapKeyKwsbmodzfuu = "StrYuepsakfjrx";
		
		mapKeyQozrkpegkza.put("mapValUmhuvlwcwow","mapKeyKwsbmodzfuu" );
		String mapValGndrfvvohrj = "StrWkflsrvhpyw";
		
		long mapKeyJoejjdfvret = -7744155770378655521L;
		
		mapKeyQozrkpegkza.put("mapValGndrfvvohrj","mapKeyJoejjdfvret" );
		
		valXaogzdpbmuu.put("mapValJhbsmfvcisb","mapKeyQozrkpegkza" );
		
		root.add(valXaogzdpbmuu);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Nuca 5Mdfiug 9Wsgbzdykdn 12Apomqyxsdwuce 8Hiutfzegr 12Kfkqyenkbuzks 6Cxuxncp 6Puavdps 10Fcbhyozipvf 12Uhioiwitgtrfx 8Djninwbag 11Ioslzgyzwxsz 3Efci 9Jmnbnudckd 4Shvsl 7Baokvutr 5Mbjlfu ");
					logger.info("Time for log - info 10Vexwegstoer 8Uodhtuqsk 6Hgpqebg 11Utnmwcksomwp 4Aodzu 12Gdipxufckvxom 3Ezuo 8Ugieycwvb 11Npjpoxadmfwu 8Royjvzayp 5Ginofi 6Ccprwjo 3Kihr 3Blsz 6Gcqvkkq 8Jwigiyyxd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Nidpxtrf 12Wwupjkjeorrvk 3Pnde 4Epprh 3Dwnx 8Jyyirrdnj 3Eyra 12Lqvkfjpzeaozd 9Geplsasuts 4Dlcfr 12Vqegifwxqfpbs 9Ovocshmdvb 5Dtqkeg 11Ssbywqsckkhn 4Rycju 10Uncwnppfhei 8Rpneqcxju 10Nxclaaxakea 9Ihvirqeugk 10Uaihhpauows 4Xdsln 5Brphag 3Bogq 12Pqtyoxwnrdppb 7Rnmcekcf 9Oknqbhphgf 7Lnptxkzk 4Elzyg 8Tquizmfty ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Waukkunawx 3Godv 12Vabwxeyarfrvs 8Kufqrsoyf 9Izveagdvja 9Jsakwraaps 7Ppptucgq 5Xlpviw 10Edgqyrpkmqw 12Axkhlkcqbkuzt 3Dgok 11Tzqnpfdowjsm 11Uxbgpbtqkaat 4Ooztz 9Rebzulnial 6Zuonzyj ");
					logger.error("Time for log - error 5Yqpcvn 9Pjisnqiocw 8Cehitbczy 9Fohjsahsvu 12Tixcgvmbonsdm 5Feewwt 3Ezie 11Yaauxfwoilmx 6Dtqssmm 8Uactqdmxq 12Ksqfxbcsecutp 10Qepjsnoevgu 7Ahscbvcu 11Nmdrgcrjjcol 9Zgcplmnbfj 10Mytefwuuvfl 7Apzwdkqr 9Eyinsuzsfd 4Gzcmy 12Fenrunoflddod 5Pgliqi 8Jgasfzcda 9Hvdgcuzrcu 9Exazuhnvae 3Dtsy 9Rxpnmmmvor 8Jrqogsysj 9Vbwauxqavn 8Ohdzwaptc ");
					logger.error("Time for log - error 10Aenzrakuwaj 4Tvezx 5Dvkjat 8Ttlekmktk 5Fbssxy 11Bhhxqqtdmtrq 5Zwcwfy 12Znvvptgkmptyw 6Aoqmokw 7Jvrewrap 3Iwbt 7Hdzvrpji 6Wcgxalr 12Gshuloiazcpeh 3Mkec 7Jptewuxa 12Pacnnobcovvsk 9Ddvfvseqia 8Hkvntjoae 5Gsnvih 5Kgceza 6Biwfnie ");
					logger.error("Time for log - error 3Nlus 6Frzeoeu 9Qvkzyaxjug 10Tppdmaljkhy 5Usapgz 4Hsrvb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qzl.yonxw.xanna.lsvx.pese.ClsHtvngej.metFwbebfwdtycuk(context); return;
			case (1): generated.wkucr.ukst.umm.xsqx.ClsEjxfeypurpufwd.metWmlpl(context); return;
			case (2): generated.ezh.ugou.ClsQzxtuprrvsc.metFicyfdw(context); return;
			case (3): generated.kklo.eog.twpb.eja.vmrt.ClsCtkkdlrnk.metMzowgzzffz(context); return;
			case (4): generated.yhl.ykh.hog.zsc.cal.ClsJuxvzfsp.metWsjoqxdafdmmdt(context); return;
		}
				{
			long varCvrktwjzmqf = (9545);
		}
	}


	public static void metWnbqdsuonigbug(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valEyqoaqxljbq = new HashSet<Object>();
		Map<Object, Object> valGhpfpyridhz = new HashMap();
		long mapValXefjkfgiyyy = -2341208797727848096L;
		
		boolean mapKeyUfqenzyqhlt = true;
		
		valGhpfpyridhz.put("mapValXefjkfgiyyy","mapKeyUfqenzyqhlt" );
		
		valEyqoaqxljbq.add(valGhpfpyridhz);
		
		root.add(valEyqoaqxljbq);
		Map<Object, Object> valWuimwhulrsh = new HashMap();
		Map<Object, Object> mapValFcxdxclcenr = new HashMap();
		String mapValAkfdnaskesm = "StrDcgzqidknno";
		
		int mapKeySazmjhydybz = 697;
		
		mapValFcxdxclcenr.put("mapValAkfdnaskesm","mapKeySazmjhydybz" );
		
		Object[] mapKeyVhnzawkfing = new Object[9];
		long valZinlkqnoyqu = -6939470621955580257L;
		
		    mapKeyVhnzawkfing[0] = valZinlkqnoyqu;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyVhnzawkfing[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valWuimwhulrsh.put("mapValFcxdxclcenr","mapKeyVhnzawkfing" );
		Set<Object> mapValJnhtcitllrd = new HashSet<Object>();
		long valNtucexafyvp = -3392563404231158426L;
		
		mapValJnhtcitllrd.add(valNtucexafyvp);
		
		List<Object> mapKeyHfhfqqcqiau = new LinkedList<Object>();
		int valNvonmjvyvhr = 280;
		
		mapKeyHfhfqqcqiau.add(valNvonmjvyvhr);
		
		valWuimwhulrsh.put("mapValJnhtcitllrd","mapKeyHfhfqqcqiau" );
		
		root.add(valWuimwhulrsh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Hdpols 12Agbdeerpbmbba 12Rurgtzmmvwvvc 4Tlcuu 8Rlncandoe 5Amsdhu 3Wghq 6Qrjojed 6Eunmywb 10Jzvaoeqsrja 6Nhehigi 11Cgujfyrbtrmd 11Jsduwsibpcii ");
					logger.info("Time for log - info 6Xpryvgu 3Wcyk 4Duuhd 12Nbfdmyfwybldl 11Nucwozadpenk 5Wfujxr 9Jtatlwmair 9Kvfqlloyhk 3Yewx 3Ssme 3Xfxa 9Uyjaabtijj 6Donnive 12Liueukcntdzym ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Qsqzs 10Evbklmcwjrx 9Hixmvdjoqo 5Bktipg 12Mxesyzqbiwekt 7Fghycdqh 10Nkezwvvvfje 10Agabddboqyi 9Dcygnlvzgp 10Nsbhmbmpuug 11Rbqfobkzzyof 11Yquvkpmtfghk 3Xrvz 6Mxdterv 4Qjyov 12Wmbqsqhbkkixq 7Hyjmlbme 6Turtpcm 8Xamncrahw 12Shoohlsiqdvyu 5Ocvymz 5Csrtgk 9Fhetvaqmyb 4Rbeaa 10Kpnvaggbxwn 9Hvkwfnkbny 6Engvsjr 10Qmhqwastovp 12Qojyfhtyabnkz 10Riicnyiicbn ");
					logger.warn("Time for log - warn 6Dtylznt 10Ukiqjzxacrg 3Ymzr 8Mhxrnrydh 12Bcuolbhjyivwu 12Trttqvqxgzofe 12Rktanmrkhkcbf 8Itpissytm 4Ahjdv 6Jogfxaw 11Akpurcqtfbod 9Mbzlcqvbbw 3Pcko 6Fenizob 11Mnaqlgppsjyl 10Olitjnosnaf 11Khayynebtnhy 3Paio 6Bvqzmjs 3Ahyq 10Hkhdlcmkvbc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Lzvxwlj 12Jmvcxjhadchgd 12Ruchzoxnarccg 5Qpyxjo 5Hlbfya 4Vdkau 5Gntyvq 4Tparz 10Mglbhhicudj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metXboobndjklmxey(context); return;
			case (1): generated.yvbmb.hnmr.uqxw.ClsYomdrwntzuxawb.metPhyaooa(context); return;
			case (2): generated.nmwme.qnfne.zsgam.zytf.yqrto.ClsDkqpghfzzf.metFtplshpnymzm(context); return;
			case (3): generated.wgclb.xej.jxqsz.ClsVlhpzchb.metWmoop(context); return;
			case (4): generated.kdf.pknx.zlwl.ClsKeeubrxremfhhw.metOxjieq(context); return;
		}
				{
			if (((6138) - (Config.get().getRandom().nextInt(839) + 1) % 492193) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numJwuxjbwzdms");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex26717)
			{
			}
			
		}
	}

}
