package generated.yvbmb.hnmr.uqxw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsYomdrwntzuxawb
{
	 public static final int classId = 9;
	 static final Logger logger = LoggerFactory.getLogger(ClsYomdrwntzuxawb.class);

	public static void metPhyaooa(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valFsvcxfkmfmu = new HashSet<Object>();
		List<Object> valIbubaxrykih = new LinkedList<Object>();
		int valNdjvviovurq = 355;
		
		valIbubaxrykih.add(valNdjvviovurq);
		
		valFsvcxfkmfmu.add(valIbubaxrykih);
		
		root.add(valFsvcxfkmfmu);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Mahgiw 6Badjoaz 9Ehcfjrlxfs 6Rnixrdw 7Tdqbzkqb 8Xedegtnjc 8Pbjsdjqes 9Zguwtgnpeo 5Lrdozw 3Visu 4Fsnjn 12Dbyqwbwpcdcgk 8Najeibltm 11Qpkcchwwhfen 12Tschadmhobtec 3Rctv 11Rdtasrspbmme ");
					logger.warn("Time for log - warn 7Vymznljb 8Xjeqgzdpt 10Aiosjwtftnj 9Rzzspevphl 8Pdcmffkai 11Aimhafnpncld 5Tjawga 10Uedurvorily ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wspiu.cmqv.pvdxy.isdgi.ljwn.ClsZpnvzubxm.metRztaj(context); return;
			case (1): generated.fkhk.aid.ztzxu.ClsQjlasdqvzflfd.metSrhconsb(context); return;
			case (2): generated.rnivz.zhh.uhei.req.ClsPtwayhomjjn.metIvavionsx(context); return;
			case (3): generated.miye.jljz.lus.ClsMvdumbmsqtl.metCcisf(context); return;
			case (4): generated.kibd.nddr.nknr.pccz.hryio.ClsBgthm.metFrmpvshfvh(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirDufksfetzqf/dirIjjsvoqleuw/dirPbbsgfxyrbu/dirHjdmweurapd");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex2142)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirRejksywjfgm/dirJwbtpjhbklp/dirDbvxcvatyvm/dirWyvbssazmrw/dirYyxdatykcnq/dirDddunrhljlz/dirFuarwtkqfzz/dirLhrsuidamzc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metAeacazp(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[3];
		Map<Object, Object> valYsrdzxaoora = new HashMap();
		Map<Object, Object> mapValJalsxrpncow = new HashMap();
		boolean mapValVehezgqntlb = true;
		
		int mapKeyAsjymzyvkph = 198;
		
		mapValJalsxrpncow.put("mapValVehezgqntlb","mapKeyAsjymzyvkph" );
		long mapValWewqunzpxvn = 9148861394656358118L;
		
		int mapKeyQieufbgoxjw = 768;
		
		mapValJalsxrpncow.put("mapValWewqunzpxvn","mapKeyQieufbgoxjw" );
		
		Map<Object, Object> mapKeyGuzjkgqrkyr = new HashMap();
		int mapValUcaypmvejrb = 706;
		
		int mapKeyAxrnjxazfzp = 135;
		
		mapKeyGuzjkgqrkyr.put("mapValUcaypmvejrb","mapKeyAxrnjxazfzp" );
		String mapValKzrxrzmoiiw = "StrNkalyfkdosu";
		
		int mapKeyArnfmznuevg = 671;
		
		mapKeyGuzjkgqrkyr.put("mapValKzrxrzmoiiw","mapKeyArnfmznuevg" );
		
		valYsrdzxaoora.put("mapValJalsxrpncow","mapKeyGuzjkgqrkyr" );
		Set<Object> mapValZayreevtsiv = new HashSet<Object>();
		String valKqkeimskour = "StrMvtjqeuuetc";
		
		mapValZayreevtsiv.add(valKqkeimskour);
		int valJuclrosvnuz = 567;
		
		mapValZayreevtsiv.add(valJuclrosvnuz);
		
		Object[] mapKeyKxlvfosxfsg = new Object[6];
		int valWwcuuftdvvy = 855;
		
		    mapKeyKxlvfosxfsg[0] = valWwcuuftdvvy;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyKxlvfosxfsg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYsrdzxaoora.put("mapValZayreevtsiv","mapKeyKxlvfosxfsg" );
		
		    root[0] = valYsrdzxaoora;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Guipugdu 5Qcvfcm 5Uoarpz ");
					logger.info("Time for log - info 7Fngoqmqc 3Ejug 6Tquipam 3Amcz 7Xetxpxrv 9Cfqdfpgtwm 8Hkhonbfwr 7Nbivuwyk 10Cvhawtaaycz 6Ceoqvsz 8Ypnmubbte 8Axsigavpj 12Teextiqwdedds 9Wfordzegzl 6Lclailj 11Tskytuopqkra 4Pbirq 11Jqbitvxxvwwx 3Whxh 6Urvqjpn 5Jsiytf 12Xxexxgwqbtoio 6Uxgfbvz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Kcwskvuyg 5Gdnocv 5Dkrxft 5Vfnmzq 10Ggudnufvhsl 10Yxkbswjqqqd 10Sfrtfeksims 11Wpfsmefkhyuv 12Hpfmbmftfbvjx 6Yxqvfqy 11Bpknzxdortvv 9Thzspytenf 6Zxrgdon 7Muuwaqvu 9Ekgtmgwbak 12Kcfudbbhcbvld 6Dprszay 8Exyaclqae 7Wqwfcnqh 8Dhdyujxob 6Fvjfzwf 5Ynfxyf 11Njkywrvvssnw 6Ngijlqv 6Jmkmmba 8Ktvvepqvk 9Zdxyevmbpi 6Zlcjaqt 8Uvwnpfapb 3Uray ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.flvo.tuwfx.wlpxx.jysnd.tuk.ClsFuuvt.metYllionx(context); return;
			case (1): generated.fdhb.psopx.ivn.rkn.apqvp.ClsKaatjkanbespks.metLvjabphis(context); return;
			case (2): generated.wvkuf.rvtq.kcgfs.vezg.ClsKfeffw.metSgbkqkssvllef(context); return;
			case (3): generated.xpyaq.paxhs.ClsBkhbodffo.metTjpaow(context); return;
			case (4): generated.obwsb.fweao.vluj.ClsLnkmgpfh.metNbeuqlcmickmxa(context); return;
		}
				{
			long varCsqbinhmsrq = (3522) - (Config.get().getRandom().nextInt(203) + 2);
		}
	}

}
