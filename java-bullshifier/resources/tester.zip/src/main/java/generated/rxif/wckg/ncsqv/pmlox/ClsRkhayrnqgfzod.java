package generated.rxif.wckg.ncsqv.pmlox;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsRkhayrnqgfzod
{
	 public static final int classId = 275;
	 static final Logger logger = LoggerFactory.getLogger(ClsRkhayrnqgfzod.class);

	public static void metYpvtqzicvr(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[5];
		Map<Object, Object> valGunuowqlcfv = new HashMap();
		List<Object> mapValDivljoaadqo = new LinkedList<Object>();
		boolean valBjhqmqbdkxo = true;
		
		mapValDivljoaadqo.add(valBjhqmqbdkxo);
		
		List<Object> mapKeyTubowmasfjh = new LinkedList<Object>();
		long valAgckvyafbre = 799971710336371192L;
		
		mapKeyTubowmasfjh.add(valAgckvyafbre);
		int valGmssrrduwlb = 198;
		
		mapKeyTubowmasfjh.add(valGmssrrduwlb);
		
		valGunuowqlcfv.put("mapValDivljoaadqo","mapKeyTubowmasfjh" );
		Map<Object, Object> mapValHrjpjfjehky = new HashMap();
		String mapValCdbdvlasdgb = "StrPsoyvczygls";
		
		long mapKeyGjcoyxsexrv = 5085527836641096717L;
		
		mapValHrjpjfjehky.put("mapValCdbdvlasdgb","mapKeyGjcoyxsexrv" );
		long mapValMyexdqzpgva = -2355306995647986261L;
		
		String mapKeyRijkflmhbbg = "StrEmzflhtvnwo";
		
		mapValHrjpjfjehky.put("mapValMyexdqzpgva","mapKeyRijkflmhbbg" );
		
		Set<Object> mapKeyScxzpfxbixf = new HashSet<Object>();
		boolean valYndlulrxjli = true;
		
		mapKeyScxzpfxbixf.add(valYndlulrxjli);
		String valPbdpsubccwc = "StrEzsbbyrfwtg";
		
		mapKeyScxzpfxbixf.add(valPbdpsubccwc);
		
		valGunuowqlcfv.put("mapValHrjpjfjehky","mapKeyScxzpfxbixf" );
		
		    root[0] = valGunuowqlcfv;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Fphmxbpwddm 6Spoeioh 12Crivyvjaydgsq 7Vaxgppql 3Wddx 8Jcvppeptz ");
					logger.info("Time for log - info 5Svtcin 7Iqfxuagz 5Udgzof 8Gepjofpvy 11Vfmklujcfgxs 6Cylzgqk 6Pwguagx 3Wbkg 9Hlkigtzwtx 3Mgmv 8Friuypgfn 6Cowtxwd 7Hlqojvij 8Kxatezant 12Oklmyemdozfxw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Jdsujly 12Vzimmvseiubxh 4Tnhcr 10Plzyaiuvtrc 11Vcaswvptsjlf 10Bartzncyqhh 12Rycrgadxpzlkl 7Xmdyvozr 11Jizqjyxwcfvb 5Nlcgoq 12Ebabzjrldecjn 5Wguwra ");
					logger.warn("Time for log - warn 7Fzreviwd 10Rskfpzkinok 3Ljkv 3Bonm 5Jwwdgt 4Gxihz 5Pippha 9Bibgylyken ");
					logger.warn("Time for log - warn 10Nrwkxgqcfjx 5Tejsge 4Ewnly 6Praqqrp 7Rgpttjtz ");
					logger.warn("Time for log - warn 6Jpgzcxl 6Ipyjgnp 8Eyrfclhkh ");
					logger.warn("Time for log - warn 5Qghybb 5Cxrjry 11Ldpgqkcebtyb 11Ljdatlpogxhp 12Sowpfzmczodew 11Oyumnxlkfovg 12Rytusdtbivzqm 9Cnucvyzlce 7Ebddduom 7Jnfkfcxf 10Sbdrghmchul 6Jfktkkc 8Qtjgqekzu 12Vkejrqiwwvwnm 6Pcfkjvs 5Mdswot ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Bogmpdxuejhae 9Zmpiemwtug 12Zjrqzisvumium 10Urmccvektfh 4Lftpv 11Vvafjhnouyxs 4Andwf 12Gogvfcjokxshp 5Tfnuns 12Ghpocciuokktj 11Xyemrktxfiiz 7Pzxqotne 7Rbyckgzp 3Tjxp ");
					logger.error("Time for log - error 12Sdgprpktvqtnu 8Vwldhnnyz 12Lpjrmoogajhoo 10Dqkfmgvxwcy 10Uubmwsqptnh 11Dfbllviuzlqz 6Dmbwmpz 10Nwsohakptyi 11Ykizrugejdch 6Wdxzxps 11Dupeqqecmrip 9Fgpllcdprg 7Btitiyap ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.agl.duqt.yfyli.jnv.jpizl.ClsQbgwqgmsxm.metEmnhch(context); return;
			case (1): generated.ymhs.ivq.mlr.cezkl.gzyiv.ClsKvdrph.metIszbhwn(context); return;
			case (2): generated.abpq.uqd.wdeqd.mcta.ClsWlrvlsbwwa.metRclnhtyvwiwwcq(context); return;
			case (3): generated.kdf.pknx.zlwl.ClsKeeubrxremfhhw.metSoxbamiezrzd(context); return;
			case (4): generated.lsv.svu.ClsVsswgqo.metQifxnxo(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numUenpruytpao");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex24765)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirImtwdtvvnqg/dirPygwrhhcaoy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metVuvkwlczu(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[4];
		Map<Object, Object> valHcptncrouxr = new HashMap();
		List<Object> mapValQdwzvsxwrfy = new LinkedList<Object>();
		boolean valSgoobqovwiy = true;
		
		mapValQdwzvsxwrfy.add(valSgoobqovwiy);
		
		Object[] mapKeyWhwhytyqekp = new Object[9];
		boolean valEmxgvdqzuvn = false;
		
		    mapKeyWhwhytyqekp[0] = valEmxgvdqzuvn;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyWhwhytyqekp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valHcptncrouxr.put("mapValQdwzvsxwrfy","mapKeyWhwhytyqekp" );
		
		    root[0] = valHcptncrouxr;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Tkxytlonibrlh 11Fgotfhlysfgc 10Yylwypfwprf 11Qhnioxdokzkf 10Ojjnarigdyn 11Knoyjfgrwgua 4Xdwmm 5Vaaacd 9Kixvhajsjd 10Ekykeipcbcz 7Xuvlskfq 5Hulzug 9Gkqpwvcuqw 6Dvcrafo 5Fqreut 12Yvungqqvpxceu 7Ezquefmw 8Nepboqrfg 5Enfoos 11Hfhdkaevlebm 8Flndulvqo 5Qzqkui 8Iunxhjpdm 11Mfaedzhctomb 11Totiydvseigz 8Tqauvlmxo ");
					logger.info("Time for log - info 12Anzscjdrkhvcq 10Eamshocuxov 4Fiesk 12Hepcgzowszexe 12Yuzmlgjqrscot 11Jxyguhhpseyj 3Rtxx 11Qxxhxsxrjmwc 11Muehgewipzqr 3Kpua 4Vssuw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Yqva 7Erwcnhdw 4Ovqjo 11Civjzzmdwpix 11Hgwcvhyxsdqd 12Wucdqydrqtqkh 5Wfegku 3Otck 12Gixvczgcnnznb 10Cpbufowyqwd 5Rdrloj 12Qtibtfdectjpq 12Blhfneuxohtok 3Hjcp 10Wvkjdqzhasr 7Puarhhfv 4Dlsht 9Ifrvwxqyzz 9Bjvmsirsng 8Vlfhvjbfo 6Gppgyfr 6Hqbvtrw 11Iymrjyacmjww 11Aaarndcyxlfh 3Kybk 5Zrmvtu 12Iqvdbdebvtnkl 7Rzwlvahf 8Xojzzlzhg ");
					logger.warn("Time for log - warn 6Olxrznx 8Xpnpqynhu 5Sskduk 7Napkraud 5Zvflax 12Ipyuqhjevdjzz 10Bblvzzdqjwg 6Fwecknn 8Flnacxktz 6Kdmutyy 8Qhhjygama 5Npoykl 10Siwdeeijehx 7Ozbixowx 4Rcxac 11Neyzejchvmlb 8Ugzhyhbfm 8Vvkzkoylr 4Yrdit 7Yvnrvwli 7Fcjiiogu 12Lmohousbrhmym 8Vuafyohah 9Tytamtiyda 3Lxau 12Hdpvpxduupqyb ");
					logger.warn("Time for log - warn 11Elwblxwgwugg 12Gdorbnfhihlog 9Zbktfxsbts 11Wnosrqakmzyt 6Ywgzdyu 7Fmqlflyr 5Vzlilk 8Mnaboawnz 3Irlb 11Osuqgynzcjom 11Ccryrgzkfkzi 5Jpcgqj 5Rjbyza 7Mpdfjrwn 3Vnwj 4Xhabv 6Avbqoku 3Lmqf 10Ahauwctjkhl 8Tgbrwzoxu 8Wmdfdoicb 4Kfzke 11Tmrkhwlsvbze ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Jlfyxisfjckgc 6Xfxlweb 6Stxnqax 10Yjwtfjzrkdy 8Wwejbousm 3Jjzf 11Lljgtpyfwtud 5Kbqyuf 6Efnwtbq 3Fgxm 8Lzpwynxej 9Sifqzjifkh 11Xrgjcubpkfnr 3Vdgc 8Hxcwwukyq 3Orui 6Cxrsxwf ");
					logger.error("Time for log - error 6Cicdvof 5Svxpqk 9Nsrkehoujs 12Bljhfalwvwmig 4Xwnkd 4Shubo 7Aehcetdd 12Szcnlkzsikwoe 7Rrfrsmpz 8Qnbebsfla 3Lxcz 3Wlnz 6Lsmdbdv 3Mvoj 3Lbda 12Slukyfpezpwuq 5Xnpzqs 7Zctwjgtf 8Taueklgka 3Iscc 9Wltnmsyhre 8Lvghzzifx 5Lwnczi 6Tzpshlo 7Xjamyhrv 12Tnchgdixlgovz 9Axhwfydrws 6Lmnznis 9Awfmmtoafu 7Kgtsrqwq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rnt.ihen.ClsUnbfdq.metTwiriwczsepmwk(context); return;
			case (1): generated.tau.glw.atmw.ClsCedrqvgmxtsj.metRecbeoqusgpv(context); return;
			case (2): generated.hiv.mgg.zog.vzpz.ClsYqryx.metKmqjahpkjfw(context); return;
			case (3): generated.zdmfw.qfic.ClsQmanwrctuzecr.metEvpjjip(context); return;
			case (4): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metOsxqvqfsqlaj(context); return;
		}
				{
			long whileIndex24769 = 0;
			
			while (whileIndex24769-- > 0)
			{
				java.io.File file = new java.io.File("/dirEkngvajihqc/dirFoxasbbpcxn/dirLgmmwxooxcl");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metOqicwb(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[2];
		Set<Object> valLbarkgyzjsv = new HashSet<Object>();
		Map<Object, Object> valPrxucmbrbst = new HashMap();
		boolean mapValNadalsnqjgz = false;
		
		int mapKeyKcyuxvovukr = 167;
		
		valPrxucmbrbst.put("mapValNadalsnqjgz","mapKeyKcyuxvovukr" );
		
		valLbarkgyzjsv.add(valPrxucmbrbst);
		List<Object> valAqjtdpixosr = new LinkedList<Object>();
		int valOxejchmqopy = 296;
		
		valAqjtdpixosr.add(valOxejchmqopy);
		
		valLbarkgyzjsv.add(valAqjtdpixosr);
		
		    root[0] = valLbarkgyzjsv;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Kafbqp 4Ygsvo 7Zyqhryft 8Lbehllvkw 7Rzpdhzcb 6Fwzyzuj 3Qvyq 7Kagkhsde 3Drpl 9Hwjtozanct 8Fuhjpufou ");
					logger.info("Time for log - info 9Swdkggpfne 6Rnhzjkc 7Mxjakcar 5Sinpsj 8Bpkwtzpdx 9Tftghfnhdr 3Rhpo 10Rlkdsdusbyl 10Lgcbmykquyn 8Xnhzzibqu 5Mdpeol 5Lrgylr 9Kmvltwevcm 12Iadrphxrxnuxq 9Tnbplbkwty 12Uhhzclevnkkpj 5Hglwdg 12Qezmamvppeaec ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Nbxlngdepb 3Hdxd 6Iaxzjar 7Xbkumuwj 10Fcdrezbxziv 9Tbemxadgwy 4Kwqeq 8Bggagrptt 10Mdhldaencdf 10Ivxtbidjzra 12Jeasybmlxpqqm 9Uvurerpsou 10Gujoomblant 4Fdvwk 3Oubl 7Vasjemcq 4Czkgf 5Sqndyz 12Svcbvawungpsk 3Prfd 10Xyvaiytxizc 6Zpvergr 4Vdatq 12Erznffgyxywiu 9Gugcptckjs 8Xsodmhddc 7Lvhckdwi ");
					logger.warn("Time for log - warn 8Xwgrnmqor 5Hnbkek 5Kxnott 4Yiinj 6Xusfchu 7Tgkdknuj 10Maijhcakvnt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ogy.ayf.aijxy.ClsNdoxmvj.metCsqrhmq(context); return;
			case (1): generated.kmtdc.slqlz.nmqcy.naaq.ClsKsliquh.metNmcayldfqz(context); return;
			case (2): generated.rnivz.zhh.uhei.req.ClsPtwayhomjjn.metIvavionsx(context); return;
			case (3): generated.rjuw.mmbua.ClsRawvqxmhewbl.metOsciin(context); return;
			case (4): generated.krka.pbdp.kxfhk.gqt.tfv.ClsAdvwmtrn.metGbpohttt(context); return;
		}
				{
			long whileIndex24772 = 0;
			
			while (whileIndex24772-- > 0)
			{
				java.io.File file = new java.io.File("/dirEmmahecgicx/dirDxgqjadgrnz/dirEspbkiiwtbx/dirZfnnuexzanh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varRguibmzkvrt = (Config.get().getRandom().nextInt(74) + 5) + (4458);
			long whileIndex24774 = 0;
			
			while (whileIndex24774-- > 0)
			{
				java.io.File file = new java.io.File("/dirQpqvptdpyoc/dirIxytyngopog/dirYouhccekctz/dirJoaxsncsmny");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
