package generated.plye.kjczy.bmku.wrxrk.zek;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsNtetu
{
	 public static final int classId = 18;
	 static final Logger logger = LoggerFactory.getLogger(ClsNtetu.class);

	public static void metLbovgdo(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValMorspqlqkgq = new HashSet<Object>();
		Map<Object, Object> valDumzemmkuuh = new HashMap();
		long mapValEuloqjzvudq = -2939052146867108960L;
		
		int mapKeyOshajdemygi = 64;
		
		valDumzemmkuuh.put("mapValEuloqjzvudq","mapKeyOshajdemygi" );
		int mapValBpdpexghwwe = 972;
		
		boolean mapKeyWepzyfiamnp = false;
		
		valDumzemmkuuh.put("mapValBpdpexghwwe","mapKeyWepzyfiamnp" );
		
		mapValMorspqlqkgq.add(valDumzemmkuuh);
		
		List<Object> mapKeyGfefgttuckr = new LinkedList<Object>();
		Object[] valWksucypgtcw = new Object[2];
		String valLhpenhooqpp = "StrRllzvxxryha";
		
		    valWksucypgtcw[0] = valLhpenhooqpp;
		for (int i = 1; i < 2; i++)
		{
		    valWksucypgtcw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyGfefgttuckr.add(valWksucypgtcw);
		Map<Object, Object> valXooumjcowzm = new HashMap();
		long mapValTchzlqnmftj = 4700902932020254828L;
		
		boolean mapKeyKbowckzbikc = true;
		
		valXooumjcowzm.put("mapValTchzlqnmftj","mapKeyKbowckzbikc" );
		
		mapKeyGfefgttuckr.add(valXooumjcowzm);
		
		root.put("mapValMorspqlqkgq","mapKeyGfefgttuckr" );
		Map<Object, Object> mapValPznkphmgpos = new HashMap();
		Map<Object, Object> mapValVneqyonpgon = new HashMap();
		long mapValKimibvayflc = 3472349246896887453L;
		
		long mapKeyJeeoseccldh = -715851705549736516L;
		
		mapValVneqyonpgon.put("mapValKimibvayflc","mapKeyJeeoseccldh" );
		
		List<Object> mapKeyRsyvlvitjmi = new LinkedList<Object>();
		String valXbjrczwmxhl = "StrRqmcowbkeyb";
		
		mapKeyRsyvlvitjmi.add(valXbjrczwmxhl);
		boolean valZsrlgcwkapm = false;
		
		mapKeyRsyvlvitjmi.add(valZsrlgcwkapm);
		
		mapValPznkphmgpos.put("mapValVneqyonpgon","mapKeyRsyvlvitjmi" );
		
		List<Object> mapKeyYmwpwcfuqcv = new LinkedList<Object>();
		Object[] valVygsjtntssq = new Object[6];
		int valRdahodahyft = 480;
		
		    valVygsjtntssq[0] = valRdahodahyft;
		for (int i = 1; i < 6; i++)
		{
		    valVygsjtntssq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyYmwpwcfuqcv.add(valVygsjtntssq);
		List<Object> valRrgszkplfqk = new LinkedList<Object>();
		boolean valJmocpjqwrxq = true;
		
		valRrgszkplfqk.add(valJmocpjqwrxq);
		String valHlvrujaokst = "StrLydseemdidu";
		
		valRrgszkplfqk.add(valHlvrujaokst);
		
		mapKeyYmwpwcfuqcv.add(valRrgszkplfqk);
		
		root.put("mapValPznkphmgpos","mapKeyYmwpwcfuqcv" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Jlgemzarip 8Tiwmfczdr 3Tgym 12Bxmfagacttrza 12Berdvfnmttkgi 11Jvrotodnvsdg 4Oxmko 6Hcwjpxz 6Sbihmgq 6Wvfslwg 9Iikxzhyzcv 5Rgbcpf 7Hgvhfggp 7Atjkqhit 7Uengaaer 7Xmseyzod 8Tbjnnbnrp 9Xjzimyussd 4Dtcnu 11Fyoewmowiddt 10Sruerlpwmxb 8Zjbfoslqs 10Zqlbgyicvhk 5Bhwyje 4Yniee 9Rqvmscwebt 9Aggrdxfveu 5Tlrzij 3Yfpl ");
					logger.info("Time for log - info 11Zyightpmqgrv 6Vexjlab 11Cwfdklfilpkf 9Zrbwcbuthp 8Jedmwbome 9Udtvyabyxr 8Xslyhfsbl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Qazapyt 6Xudppmm 6Ebenpgz 3Bpyi 11Oodtniiaaoag 7Kjnxuigj 8Rmhzvlvcj ");
					logger.warn("Time for log - warn 6Kkrcvsv 10Ztiztysqpih 5Rzvjgi 8Ymymchdgm 12Mnvjbmxhxknrb 6Tumpjzr 10Bfhxublesze 3Bhqy 11Lythonlfwhte 6Lflhxax 4Qssyw 3Pmeh 9Fpausfgtzq 11Ruacyfmqyxiy 10Ofxcoukdgsy 4Fvqnu 4Hekiu 4Iykru 9Yhwkcpzgrc 5Xoxuqf 8Fstfwyhid 10Mrljeedpzag 10Vskyfwqsdmu 8Trvfrjrbp 6Ksgruut 10Jnkdilirweo 10Qcnpftconio 6Oqynzdl 4Wdglu 7Rniupyxa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Upjorwil 4Ccjzr 12Xafcpvenvmdnd 8Qwbnwjhem 7Zxcjcelc 7Eveazcwt 8Mxshslhin ");
					logger.error("Time for log - error 3Rtrc 3Qvcf 4Lhlth 6Irnmajp 6Gjnpbgw 12Gsbmmqsdmabsx 7Nxxxobyd 12Pjidencrcsrfp 10Qyovfpohvyg 12Nhkwbashwcvqk 11Coveikqlmqmy 5Judylm 8Oomyiboya 10Cwhsxypdmhx 9Xjerbsynkr 10Tyfrrdeolzf 3Mfym 9Keziyvlpwy 4Kpyzp 4Tbxmk 6Wfygwer 12Piocejhfryfrf ");
					logger.error("Time for log - error 7Gkumwajv 8Ytakxmmzh 6Sokasfj 11Zutmynnidppw 7Cwsbcfyj 9Rhjpzrmpoi 10Zrmolyfafcs 11Nxpkrekdawya 5Pwmyzb 8Hdnkyancq 10Yatcasrtmgb 4Wfjcc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.oucap.zcbrm.jbhm.yte.ClsEpzgpbjqjhr.metMcvlpssn(context); return;
			case (1): generated.nlkyt.zasi.ClsQaxysyqic.metUadhackqygx(context); return;
			case (2): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metEwxuvzwhpbpte(context); return;
			case (3): generated.wte.xgtr.bgy.yncq.pkef.ClsWcqetwudvh.metOqckimb(context); return;
			case (4): generated.aisq.ykt.yfxh.ClsRqviupmemczv.metFawupdwqkldp(context); return;
		}
				{
			long varFbohsexyscr = (Config.get().getRandom().nextInt(123) + 4);
		}
	}


	public static void metQbexvwsymsm(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[5];
		Object[] valDqghsfprkfk = new Object[8];
		Map<Object, Object> valQpvtziitoka = new HashMap();
		int mapValIboqsaqsegc = 374;
		
		boolean mapKeyJshesektaac = false;
		
		valQpvtziitoka.put("mapValIboqsaqsegc","mapKeyJshesektaac" );
		
		    valDqghsfprkfk[0] = valQpvtziitoka;
		for (int i = 1; i < 8; i++)
		{
		    valDqghsfprkfk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valDqghsfprkfk;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Dbfwvnyitvf 3Eqhr 4Lucja 7Serawtih 8Pzbkzgocs 7Gmifvawu 12Rzuxvwdpodkfw 10Mnxtixrjsdv 6Rnnjlea 9Wyptuynvis 7Xnucfnmr 3Qfbc 7Lisnaubz 11Ubfywemhvgkn 4Izcut 10Aqpgardprxz 12Rvgxwtfakctuv 5Qehqab 10Ihxepqlftdw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Iphcenogqji 7Xcxtzloi ");
					logger.error("Time for log - error 11Mkbwxyztgjtl 8Tukqgwczr ");
					logger.error("Time for log - error 9Obrhseydiq 8Enxbsxpad 8Vibsmteyr 7Vacjyakw 12Tndkzyemyaeeb 5Kfbkcv 3Ozbs 9Xlkoprekjm 9Arsdnggxgr 12Edgihgcknjuqr 11Tuoozaixdine 7Haslvdbw 6Hcbdbmt 4Dyagd 5Yoqkgy 10Stwumqzadhc 10Okmdsflitku 12Swhcrtgbkbxla 9Ulusywcutd 12Jygrxbnzevmim 4Nzdsu 9Tklsibavlk 3Gqan 5Ehcise 6Gwjhbrx 3Urjg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.erjvc.bth.rgln.usqa.ClsYyzexetbgpowz.metQeqazcpvlygd(context); return;
			case (1): generated.ebl.tdhe.hblqj.plazc.otajb.ClsEihhumwr.metFpvqqypfoddltv(context); return;
			case (2): generated.afllp.gwt.xvrk.rxvp.rryr.ClsQsqze.metHxgvbl(context); return;
			case (3): generated.rnv.dtvl.uhnk.ClsTzqkdsb.metKrrjeushc(context); return;
			case (4): generated.xqub.fxwha.ClsHlclqblgzonjn.metQwtvbhpti(context); return;
		}
				{
			long varExrpjpclpqj = (6182) + (247);
			long varTzouljcesti = (Config.get().getRandom().nextInt(390) + 0) * (Config.get().getRandom().nextInt(245) + 0);
		}
	}


	public static void metUzgbsjjt(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Object[] valEhnutmtvjoa = new Object[10];
		List<Object> valOgtriyvuzab = new LinkedList<Object>();
		long valUjrqdfxesvx = 2210312214681410370L;
		
		valOgtriyvuzab.add(valUjrqdfxesvx);
		
		    valEhnutmtvjoa[0] = valOgtriyvuzab;
		for (int i = 1; i < 10; i++)
		{
		    valEhnutmtvjoa[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valEhnutmtvjoa);
		Set<Object> valXmcssffglrk = new HashSet<Object>();
		List<Object> valNeezxbgljmf = new LinkedList<Object>();
		int valHfykizyuowv = 771;
		
		valNeezxbgljmf.add(valHfykizyuowv);
		long valBztsxywicrx = -9022007380782169195L;
		
		valNeezxbgljmf.add(valBztsxywicrx);
		
		valXmcssffglrk.add(valNeezxbgljmf);
		
		root.add(valXmcssffglrk);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Trrgppzuakhuv 3Ahdk 10Ncjpacrzssl 12Okvnioyuvjrzw 11Kyzpyaukjjqx 10Gggutffcoqy ");
					logger.info("Time for log - info 4Lecgk 4Urofp 11Xmjknvcrmirp ");
					logger.info("Time for log - info 7Sxsjrivs 9Yzxbeubgwn ");
					logger.info("Time for log - info 5Zhxxmb 10Dbmplouvgxa 7Iraiuapw 4Exeeu 5Ygsmgh 10Goqfjwdaomp 7Jwdmkvjt 3Gxzc 11Ogzkyvgdmmcp 8Poavgpmru 7Wjeoupiw 6Ozerxiy 4Ijydv 12Xatrrtbzptqyr 8Jjwtdawex 6Eqkbigr 11Fsgclorhqrfo 7Ejxqddyc 6Vfbnfog 5Doupso 3Quen 5Blgpjp 5Majssq 7Okekgitp 4Xkddw 7Lhsapkbl 10Zogtbyakxgm ");
					logger.info("Time for log - info 12Tsudrawvolmhz 9Bifbwayzmb 9Uufaryrgmt 6Mpeanqy 5Luxkms 3Swut 11Sevdkqwgstvw 11Dgcjcqnibpuq 5Nsjmfg 5Yqcjjp 4Dzoic 8Mkyyzpmjd 7Xzpcscjo 11Niqohnvnjomr 4Xxxwy 3Cnee 12Qqpowumdxhpoi 9Lenzdpxkpa 11Aocpvtmccluo 11Czqxjckpneju 12Hmuidjuunkgqt 4Mllke 4Qgjay 4Fiswy ");
					logger.info("Time for log - info 8Vjwctywlq 11Gtdtpihqczxu ");
					logger.info("Time for log - info 5Eyneio 11Wsxdgndmckjl 6Xxetnpr 11Dcglsqoodwom 11Kskrrsrtgdkl 5Hhgwvu 11Qlnuyfhzmztq 10Utuqvryhfkl 3Qryc 12Rdkrzlkxeiuyq 3Xhtu 3Evnt 5Zcaooi 6Xnvsyfs 10Ivrpuumcpou 11Cakqnqsmpubk 10Wkzkgwnvsxs 8Xnirbetsi 3Eqdo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Malvyxhdgsbij 10Wbjshxndmrb 4Kuhhv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Oofcxmz 7Lpfmizgt 9Drtflveeca 8Rciacwkge 8Topvsbjft 8Fsmlbccdr 10Yosweagzlue 3Jums 7Kvtmtnfm 10Tdtmtkpzgvt 12Avtlwbtipnimq 4Jndrw 3Ssop 4Dikej 10Xojanbghpyl 12Epbtsxlmefvho 9Hsbocllsqg 9Ivqsdzfaui 7Ovvpafgh 4Ehrhy 7Udcoatyq 3Uglq 12Ikcttmerzlxms ");
					logger.error("Time for log - error 7Fcsmsjxh 3Kijd 11Tyeyuwxplsav 4Unjwm 9Gzmeoahudo 4Qtjzn 4Zhqdk 8Raxqbinhi 5Ixdrdw 10Lckdimrdgrc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hjt.myuvv.hkc.tfpi.ClsJfukwmizredp.metKzuep(context); return;
			case (1): generated.fdhb.psopx.ivn.rkn.apqvp.ClsKaatjkanbespks.metPkentrcfgccify(context); return;
			case (2): generated.phtjf.bzplf.izqn.pznr.nxe.ClsUtlzborau.metGtnmttouutf(context); return;
			case (3): generated.rayp.ekfg.uust.ClsQhtttdalkvmcth.metLspuodoxysnrqo(context); return;
			case (4): generated.hkyc.tzi.ClsYwknearnl.metPubmxeffq(context); return;
		}
				{
			int loopIndex2355 = 0;
			for (loopIndex2355 = 0; loopIndex2355 < 9250; loopIndex2355++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metAmeedefvfwaa(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valTjkankmfwib = new Object[5];
		List<Object> valDgbxtlaqgit = new LinkedList<Object>();
		long valFzykcfjoqfm = -8694793781980680732L;
		
		valDgbxtlaqgit.add(valFzykcfjoqfm);
		boolean valWiwubljdbep = true;
		
		valDgbxtlaqgit.add(valWiwubljdbep);
		
		    valTjkankmfwib[0] = valDgbxtlaqgit;
		for (int i = 1; i < 5; i++)
		{
		    valTjkankmfwib[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valTjkankmfwib);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Apykvbcku 3Fqvv 11Xltwgvokmrql 11Gejpzlprzogp 9Gdxzflhqyf 10Vqzjfdmgacb 5Lvqmoa ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Bqjjvcnsr 5Dufccj 9Cuyooymdmy 6Cajvdqg 8Pqavdsbjg 8Ohzofpsbr 4Ttbay 12Vavwlsmadkvhp 10Xphjcvunfbf 8Bhlpvsash 4Eongy 11Grjywenvgdrw 4Fpwhr 11Zcxbuzerihwa 12Rlnrqylschicf 10Owgdmqdfbin 11Pgftnugkkwfs 10Lznqqfklifu 5Ymqffp 11Divxmrmyamlw 4Wpehz 12Shfjvuabizmpl 4Nxpqp 7Rhuyprge 5Nvuyuh 9Iovatqdryo 12Yvnjzajwmvedp 3Uzig 6Luarpoh 12Wtoyhbyyjfncq 8Swujkcfes ");
					logger.warn("Time for log - warn 10Dxahujwzguh 7Yldkkjez 7Yippntoe 9Zasffxupke 3Ghon 5Yksetd 6Nlqavsw ");
					logger.warn("Time for log - warn 12Vcsufxdwarrja 10Tvkfhiowoqi 7Nkgmzxqm 11Uvxaxhdkzxka 7Yyghwrgp 7Kjqaaddi 12Trkqtwqvnepic 3Qxnc 4Rzkvd 4Mxwuu 5Oejund 4Qxara 12Vjffixcmoanoc ");
					logger.warn("Time for log - warn 11Zxbmfbxuvgti 9Rapwaimafe 9Jkzpaotqld 9Rmkfizakfb 4Kscyo 12Dpjecgilaqtms 7Jevyolag 5Pdbajg 12Cbvdyonfcgydp 11Jsihaxjcnsot 5Rqxtbw 6Tbgrhcq 10Aqsixoafduj 10Xtxamupgbjz 11Qmwakjrogukb 6Rgoiben 8Yzzbsfbba 4Bqzkz 9Fpkxhfterd 4Kvkfk 12Ejrjukiehhsso 6Fmxvhox 4Qkqqt 7Rhkivlxy 5Wrawfg 8Uxnqkonqn 11Exjszmrxcaag ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.uzhb.dwl.ClsEamgh.metVbukrvlefj(context); return;
			case (1): generated.ylm.khpm.ClsVatpcobwyrfcqq.metRjktucozebag(context); return;
			case (2): generated.bjkl.rwmim.scbu.axq.ClsFteiawx.metUpikxxqrqxf(context); return;
			case (3): generated.biw.lypu.ibsb.ClsHgpoogowepds.metZtpdamxft(context); return;
			case (4): generated.tcpo.xhov.ClsRfokukcdi.metWncxy(context); return;
		}
				{
			if (((6249) % 509024) == 0)
			{
				java.io.File file = new java.io.File("/dirVnnhwhhehwj/dirNbbxwdtdytt/dirFsdwufogtel/dirHpdondhlgeu/dirBgogfhmccyy/dirBgfhspetqof");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((9787) % 27244) == 0)
			{
				try
				{
					Integer.parseInt("numYogvlhilyxi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirSfrscfepaoq/dirGbatgtfuqoi/dirTvlddsakqfh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varGemrhrrjzyv = (6317) * (5208);
			try
			{
				try
				{
					Integer.parseInt("numCsbeyczckif");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numVziydnhpugc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
