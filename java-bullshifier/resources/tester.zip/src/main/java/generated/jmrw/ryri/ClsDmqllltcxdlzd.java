package generated.jmrw.ryri;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDmqllltcxdlzd
{
	 public static final int classId = 383;
	 static final Logger logger = LoggerFactory.getLogger(ClsDmqllltcxdlzd.class);

	public static void metQoxlfxubml(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValVvhvrnlgzrp = new Object[4];
		Set<Object> valFptuyfwhinl = new HashSet<Object>();
		long valNbqohnqonyo = -8678157199886084389L;
		
		valFptuyfwhinl.add(valNbqohnqonyo);
		
		    mapValVvhvrnlgzrp[0] = valFptuyfwhinl;
		for (int i = 1; i < 4; i++)
		{
		    mapValVvhvrnlgzrp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyEfsenvdkmmm = new HashSet<Object>();
		Object[] valHforcwrnpxa = new Object[3];
		int valDisumwnaekh = 489;
		
		    valHforcwrnpxa[0] = valDisumwnaekh;
		for (int i = 1; i < 3; i++)
		{
		    valHforcwrnpxa[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyEfsenvdkmmm.add(valHforcwrnpxa);
		Map<Object, Object> valOadkvyikqfx = new HashMap();
		int mapValGeipouqvjmi = 406;
		
		int mapKeyNljagxoaqva = 711;
		
		valOadkvyikqfx.put("mapValGeipouqvjmi","mapKeyNljagxoaqva" );
		
		mapKeyEfsenvdkmmm.add(valOadkvyikqfx);
		
		root.put("mapValVvhvrnlgzrp","mapKeyEfsenvdkmmm" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Ygwowumrqzeop 10Anxbwcogwsr 10Rqcitsqzswo 5Mhghit 7Obaghnvz 7Grikbunu 10Ipiguwednfx 10Rjlhxxuconb 7Swadqsfx 7Xiigtoyp 4Saudp 4Dacir 4Hkqje 12Qqjaswjahsvkv 11Qlywenndoimq 7Ctbmisfp 6Twlamxo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Vfmpa 7Cryybmgh 9Ydkwyoditf 8Bpkirlzji 8Hqnlcydbk 6Imrmssq 12Ytdnjvlqxtkoo 11Cebmuijslboi 5Uwvwqk 11Stadapvukupv ");
					logger.warn("Time for log - warn 5Fhzjuq 6Ydwsxqw 12Mcptpbnupajmr 6Unkajvi 5Aiejzo 4Uptyv 11Awzxcvbodjmk 9Awqmjwbzez 4Jpzgz 9Swssoxablt 12Gapauidsxqsbk 6Jfhuxcx 12Zlqvpuxheregw 8Ynwgpnctv 12Ovtlnljjzflms 6Miljcvn 9Igrsvcbcbw 9Ufuppsxbsm 3Nyge 3Ckbz 9Mwitarsveo 12Mfvtnllhaifqm 4Aqokl 8Iycipneoe 11Mvyatcqjfbhk 11Qyfqgekbcpsl 5Cmkwqp 4Oribf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Vqymheywgidws 12Gvywcyftmzrcy 8Yfunqdzlz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ebl.tdhe.hblqj.plazc.otajb.ClsEihhumwr.metZzqrbtidxpltas(context); return;
			case (1): generated.kivyr.smd.affpo.ClsEqlzjivgvsoafb.metFtrfvpusk(context); return;
			case (2): generated.lxrj.lts.csk.iew.ClsCagmzsja.metOondcg(context); return;
			case (3): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metWpheeqsxvjk(context); return;
			case (4): generated.uym.yiu.voiig.deif.ClsUwvuontynja.metEdvfb(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirOfthkhakczi/dirAerhpqspiuu/dirRjcijishvps/dirOxyaunqjjuv/dirOywnfvctlld/dirTylxsulnxja");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numOhhzgtfkwrt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metYuhkkpnyjimu(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valWdhyihcmzmc = new LinkedList<Object>();
		Object[] valKzqefbxnsru = new Object[7];
		int valRrmlwsjczya = 479;
		
		    valKzqefbxnsru[0] = valRrmlwsjczya;
		for (int i = 1; i < 7; i++)
		{
		    valKzqefbxnsru[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valWdhyihcmzmc.add(valKzqefbxnsru);
		
		root.add(valWdhyihcmzmc);
		Object[] valWetbemesbmf = new Object[8];
		Object[] valIxaykwqhpra = new Object[5];
		long valSagehvpaffu = 7446496575662183448L;
		
		    valIxaykwqhpra[0] = valSagehvpaffu;
		for (int i = 1; i < 5; i++)
		{
		    valIxaykwqhpra[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valWetbemesbmf[0] = valIxaykwqhpra;
		for (int i = 1; i < 8; i++)
		{
		    valWetbemesbmf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valWetbemesbmf);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Iddtldxvrbau 3Gkmf 6Ltjzpvr 4Amynp 12Cssaukiqfxuhj 5Lakvli 4Rehdm 8Dhiegulug 12Sgtxxattrnqdc 7Jzglshlv 5Cctkfq 3Amuq 11Cuenawbbaenv 5Fhgliz 4Ypfwt 10Sngvviaxlbw 11Vkessssbfnvq 6Hpuajgq 5Hwnalf 7Ryrzlhvg 8Ziwsijnvo 9Rgkctovqeh 5Uzmrml ");
					logger.info("Time for log - info 10Wjatnrfnhlh 7Kuwzxsye 12Duqtxgbhzssva 4Ahsgs 3Hiry 6Ylcfuab 3Ovdn 7Zuzpdpqd 3Yzki 3Azfe 9Hemhepsfpq 10Vsbovaibfel 10Hvnzwilbgav 9Feczzrdhow 7Eeswpnjc 3Mcjn 6Dpnfqur 4Rvnei 3Nrgh ");
					logger.info("Time for log - info 4Qbxns 6Siosmak 9Zwhcrfocnb 3Ijgw 3Mjny 9Mckjyvsezh 5Hapacv 4Kbsrx 6Ycakjgx 9Xbbctudjig 4Htnwe 4Fwjjo 11Tekanehcdxvc 3Ilnm 8Grrvtavlp 8Ntsxdqpnw 8Fvzgbeoyg 4Saaxp 12Ibxhxvowmpzdk 5Yvsdku 3Qcql 4Qhxzw 8Szxxldxvf ");
					logger.info("Time for log - info 9Vlfhgsrrzo 10Xwnqraozgys 6Toagntj ");
					logger.info("Time for log - info 4Iamws 8Pdaqmusij 9Vnykdnfkcc 8Zvorvdiko 11Phgzpuzpkhae 11Zpwuwcjwdvvb 4Yzazf 8Dcridnfst 9Mzxawlwezo 7Pdagphxv 7Urzkykzs 9Bpgpxpjnxl 5Favqxj 10Cmaxzbebivd 5Hobqzs 10Cgsbyspfsra 9Buiawrofud 5Tkviqr 11Wihcelvawwzb 9Lmzpxjoyml 10Bvlmakkpmmj 11Gjehpzffwnoh 8Ndnnpjlvs 10Xwkhdqzeyeo 3Ljlb 7Rmswcijy 10Cufmgccutiw 6Qlpnfvb 4Bmjcw ");
					logger.info("Time for log - info 5Ykqoja 8Nqvlctwua 7Zvperinv 11Ucjupkmgqsob 6Bklneee 4Gvitt 4Ickds 4Dngrk 7Ixhxafce 5Qbtbfq 4Bmtdh 8Dojjueyut 12Vibsxfdgvejyz 11Ggtfmarztzpc 12Yjoggxabfojuc 9Mcudnpefet 5Xivgfj 11Fsbvtkynoadd 7Wpmniaqp 11Esohixsmauda 6Bvfrpvl 10Xjkjznmuygq 7Rftrorae 10Uqucmyyolrj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Mhjbyg 10Tvplhnmixom 4Rcjdw 5Gkrbco 8Boylgrepu 7Cunqtkie 7Wvfoqiej 6Jrlksgr 6Dfgnqil ");
					logger.warn("Time for log - warn 6Lovwyid 6Vmyuppn 10Mnxrodymytp 3Tzaj 8Azyhnrmob 9Txztjwjquz 5Ckgcjl 4Katir 8Pzopwxhoz 8Sztzocpop 11Xlbwxtjkkvot 3Bbgz 11Bxgeocgrjric 11Isyygujpbusg 4Jzubd 8Btevmkjya 10Clwjptfgfns 9Sluniddjps 11Jquuywdnkgnm 4Nnhwd 6Pkplflz 5Otjdvx 10Ddxenhymrgk 12Tuqktsvtqtfpy 4Daztb 6Rvabdow 3Wuuz 5Svijtm 3Upwf ");
					logger.warn("Time for log - warn 9Tcogohquoj 5Gjchxs 5Skfigu 10Hlylopjqymy 6Uiutqsi 4Oeklz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Lyjqol 4Fsldq 11Tcnzibrlgyxh 6Aidnyse 4Awofg 11Tthhnlzjbtvw 5Gjgszh 6Tmfyfar 5Eedcgd 6Tjckleo ");
					logger.error("Time for log - error 3Edjp 6Zqzglae 8Hmcrahcap 6Oahtibk 9Hhuwfpdtzu 4Yjduh 4Kzdnt 11Ktpqjlugmbxk 6Wstimax 7Wbyexzyn 7Hsvzoluk 5Znvyme 10Sxnxnlnrpop 8Sinrtajzf 12Gadsmnakysvyk 10Qjshvpbaxyj 6Lpsjori 4Wmbpx 12Cyitdrsnjschf 8Eabuktqov 9Mwmohucgwf 5Muiyfg 12Enubiqmcwpgwi 12Ykzuxihfujhoj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aoa.azm.ClsTnwlnxjluoc.metDtywcweejrgwcl(context); return;
			case (1): generated.zdn.ayby.ClsMelkmphvwjkgwh.metAcvmturnoh(context); return;
			case (2): generated.erxl.yyilk.mxe.gagu.ClsTrmbyzemtaola.metLaszacoe(context); return;
			case (3): generated.eob.tzj.qiec.ClsEnjcnowop.metRglvwndsjd(context); return;
			case (4): generated.vcamv.yhh.ynaoh.fpbp.ClsCmgmcvgh.metEomzpcisih(context); return;
		}
				{
			long varTurnpuzvnbu = (7869) + (9212);
			int loopIndex26487 = 0;
			for (loopIndex26487 = 0; loopIndex26487 < 8221; loopIndex26487++)
			{
				try
				{
					Integer.parseInt("numOeymhmynjta");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex26488 = 0;
			
			while (whileIndex26488-- > 0)
			{
				try
				{
					Integer.parseInt("numQnrlblzwyre");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metRywqezozvo(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valKfpbeiacpjh = new Object[8];
		Map<Object, Object> valNxvlwosumyg = new HashMap();
		int mapValHnsrkgbuyfd = 796;
		
		String mapKeyVeowawhfgxe = "StrQvlbouusahw";
		
		valNxvlwosumyg.put("mapValHnsrkgbuyfd","mapKeyVeowawhfgxe" );
		
		    valKfpbeiacpjh[0] = valNxvlwosumyg;
		for (int i = 1; i < 8; i++)
		{
		    valKfpbeiacpjh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valKfpbeiacpjh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Dlpqhthafb 8Vnnxjsbqv 4Ofdbd 11Pqhxpxlmvycc 5Utnkdm 4Vlzpn 4Cygav 5Glrzsk 5Gsglos 11Jrcjmdkspvoa 9Bqmcznorqg 8Fnfaawajz 12Yruatoutxbyre 7Atfayczo 12Jvlzzaycvdian 10Asjniktbvhm 5Lpsmge ");
					logger.info("Time for log - info 10Xisgezwlgjm 3Pshj 11Wijphtkwdqyu 11Anheihgnqnrf 12Eqeftxkxerxzc 4Olnbq 7Bgsbnwjz 5Iawxoa 7Vjjrblin 6Tsvwsor 3Oenn 9Dammiruoop 12Ssssllchfucik 4Pxchg 7Nowwqobg 6Xrkhguf 11Zslerodwwlqf 10Ympysomimua 11Fntkafsuumrq 7Juvoazlw 8Serjobnvq 12Bmlxsbtttkwoi ");
					logger.info("Time for log - info 3Xfjf 11Hwbfczljpttm 8Sjnfckjwm 5Wyevdn 7Edxwzbtj 6Zpfraba 11Gphhmtqhuptt 8Mtducafel 5Eanrnn 10Gtzukpjbukq 12Hxhscduqyglek 8Ilrnpzgzc 5Saeuai 6Fwyotrl 7Znwzxopm 10Wpaxxnkpzpu 4Ndbbn 12Jiauignnuabtm ");
					logger.info("Time for log - info 6Rmwfxyp 7Uztsqbma 4Yuhde 9Pxeekmpbmg 8Tcjwgtpwg 4Sqnlj 10Plndbidwxpg 5Afydsg 11Hsadhulvalgx 10Nvonympszza 3Rice 12Givazztdsstgc 5Yjcrol 8Qljbnrswo 5Osbfru 5Gftpaw 5Lwcpsf 4Bwnhc 6Hlqvain 11Anapsspeisgj 6Fnalyww 9Qcofyqdjcu 4Yoxbg 5Hpscxx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Sypkhf 5Gjqzvo 6Gidyysj 6Ewhevyi 11Negvzkhsmdoc 10Jbnkddqdzza 12Pjcsajskuagcu 8Sdiuqyjkx 6Ozawihi 4Xkzum 6Wefujhq 12Mlpzkewbsqaeu 9Xhppcqztjl 6Ahaygfp 8Vesqlcfiy 10Yltsucgahwc 6Okeyfqo 4Drnzo 11Fliqafjfarvp 6Dedzwxo 8Ugxvbnliw 10Lauwlsahmib 11Tlvnufncrevn 10Wgdewmzleur 7Xmzgnklx 3Bxza 9Fjobydhmai ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Zfozhpaaxlfi 10Jgbhmpbscyx 5Mqsper 8Htfqvaoku 8Xycxeamel 10Pdzvtgeumik 11Wiptzxwaublv 3Fgwk 3Nrye 3Oigd 4Euowe 8Slmkqtdhg 12Xvkuzxrzkrsgr 7Jyxqhljx 10Qynsljsclka ");
					logger.error("Time for log - error 8Pmcihrtkw 11Mxbclbkvwwqp 9Skuxgureom 12Brwlwtjrsvfmf 6Scouuxv 3Ljvo 8Kerlvvqru 4Djfkr 6Xmpghbj 6Zgqprsc 4Bfaxm 5Rmjsyl 6Shohvua 7Isjbflpk 5Okvigs 5Phvoof 3Ppma 10Pbunmoithfb 8Pfdsymhex 5Wxcwbh 12Mgrpkifreweox 10Rpyisxyjhyv 3Cdzn 11Ucnhakxtbxsr 5Deubwv 3Rhve 6Svxujgz 5Mricwf 3Laiy 3Olpc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ulj.ogxe.vbwy.ClsQmshqdjff.metXvyria(context); return;
			case (1): generated.hrks.gbo.qgg.fgvtm.ClsHtrpxdwwowcxea.metDgjcrvmdu(context); return;
			case (2): generated.livfd.xzg.uuzce.mske.ClsRchbllfcclbcum.metEtgfstyazysxtu(context); return;
			case (3): generated.zeo.tykl.bkniu.uhs.uwxh.ClsUegpnzqhmar.metNitnfqpe(context); return;
			case (4): generated.ktb.gfwx.clp.ClsOhfjxpce.metBhcnwfttekmyi(context); return;
		}
				{
			int loopIndex26492 = 0;
			for (loopIndex26492 = 0; loopIndex26492 < 2455; loopIndex26492++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metZvfqiitm(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[10];
		Object[] valWiefowdghta = new Object[10];
		Object[] valIyatykmtxkh = new Object[3];
		boolean valLtkogzsqjzv = false;
		
		    valIyatykmtxkh[0] = valLtkogzsqjzv;
		for (int i = 1; i < 3; i++)
		{
		    valIyatykmtxkh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valWiefowdghta[0] = valIyatykmtxkh;
		for (int i = 1; i < 10; i++)
		{
		    valWiefowdghta[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valWiefowdghta;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Npqrbcg 6Qhcffse 10Ipqvunycarg 8Gxxtiyeyl 11Utpbyoobculs 12Pxpritovrbwaw 9Jsueybsvph 4Ngpoj 4Rzpys 6Vbfzinw 3Zrce 5Uokpxj 7Jrlozflt 9Qccmhzjwro 6Cmbmlwd 9Mmlpcbvgma 12Ybckqxpqlpuqm 8Zsstvvjhc 3Onzz 8Vnqggvktt ");
					logger.info("Time for log - info 3Sbek 10Qhcfdxzzqyx 5Smmkrp 10Wjmbcafjjcg 4Olwkt 7Zxzcnbkg 12Jzlqarexzjopd 9Bgqncsluxx 9Duwobkmzle 4Xhnaf 3Azhz 7Qdveozyr 11Ewchffgdfzey 3Ssad 9Cfushhjfrk 9Swrqerqyce 10Ggmmcawpjqj 8Fklnnuher 3Gnla 12Yvdlndoawnoqt 7Nghztmvm 12Wysxzugehchvu 10Memsfunvvgj 10Vvpkcryjmre 9Zbgkgptetm 6Svjtine 11Dvknqqbmcjem 11Njrwmynsnwri 4Pfpcw ");
					logger.info("Time for log - info 4Ftbfc 9Vpmdctbmfd 11Xedvhbvqysxw 7Ixwqknrn 5Yitnjv 7Ndjohgho 9Dvdhltqxkb 7Ynnuyoal 7Ocnndlrd 8Wibqidfuj 12Gdkoamqackfbd 10Lpuohlywnpt 6Cgzxxrs 8Dbyzfeytu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Niyifxxwqzwl 6Zjubyxj 7Uwmmzndd 9Bknvaljvnl 3Ssbx 11Appyifvdctuu 8Yhigvfxqr 11Eisgfrjgnmue 4Jhgzv 6Byfafqf 7Qewzvulp 5Faodfu 7Rsywhsyi 9Jfawfsdhva 11Fhxshwxpqwss 8Hwausqvzg 10Ltugmvidsqu 7Rpamsalp 8Cofmhjgjc 10Nmyodicnvoc 11Zlswhwihccyu 8Vwozcbddz 9Lyglnvtiuc 11Phoksxatqhuf 12Uipbqpbdjcway 8Ytaqfpzix 3Foth 10Gnxkccpgtcn 4Gfjvd ");
					logger.error("Time for log - error 6Ltwocwj 6Xisbbkl 5Afxkca 11Dcdninbdignq 9Ubedyuijbd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ythhn.vxvz.yizb.ClsLckdkkeapmss.metSqcrplv(context); return;
			case (1): generated.inao.viw.ClsZkxazvlqxnvyzx.metDbsezno(context); return;
			case (2): generated.pgg.urfbp.dpry.ClsLqnnoewxwh.metUlggo(context); return;
			case (3): generated.ajbel.dvbe.pmx.gfhen.qjvpo.ClsFwkvrnv.metJxbxbolmcyk(context); return;
			case (4): generated.npa.tuyd.ClsLxzuwxfsi.metPbpsvdupgp(context); return;
		}
				{
			if (((2283) % 518786) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(632) + 7) % 909861) == 0)
			{
				java.io.File file = new java.io.File("/dirJkdtblmwgyn/dirAtdkiyugsvf/dirXydpdihsbct/dirUrgsjcwakwc/dirCotmwhgchnf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex26496 = 0;
			
			while (whileIndex26496-- > 0)
			{
				java.io.File file = new java.io.File("/dirEndebobpkpd/dirGzrhfvfiuvz/dirWbureswnkjh/dirLldjbnipibv/dirLtnvnnvvaeq/dirNrggbyisoln/dirEeehraxpmdd");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex26497 = 0;
			for (loopIndex26497 = 0; loopIndex26497 < 5666; loopIndex26497++)
			{
				java.io.File file = new java.io.File("/dirXyhbcdgbgpe/dirGfflbzcopky");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metKkdvnukxkg(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valRygipwmtnza = new HashSet<Object>();
		Map<Object, Object> valJsnfxumkekh = new HashMap();
		long mapValLptgkzovebc = -3097799817428200648L;
		
		boolean mapKeySqomtzbkbar = true;
		
		valJsnfxumkekh.put("mapValLptgkzovebc","mapKeySqomtzbkbar" );
		
		valRygipwmtnza.add(valJsnfxumkekh);
		Map<Object, Object> valJwfypktvrcx = new HashMap();
		long mapValXqkzqnezhnx = -3789934748929507957L;
		
		long mapKeyBtstsdzsaxj = -5192170189000454140L;
		
		valJwfypktvrcx.put("mapValXqkzqnezhnx","mapKeyBtstsdzsaxj" );
		String mapValZaiuxgxwvzu = "StrFnyepcshpkc";
		
		String mapKeyAfyrbbradiy = "StrYflghwqphoe";
		
		valJwfypktvrcx.put("mapValZaiuxgxwvzu","mapKeyAfyrbbradiy" );
		
		valRygipwmtnza.add(valJwfypktvrcx);
		
		root.add(valRygipwmtnza);
		Map<Object, Object> valVbxwmnymsnm = new HashMap();
		List<Object> mapValCczttjxkjot = new LinkedList<Object>();
		int valToiibfzjsku = 764;
		
		mapValCczttjxkjot.add(valToiibfzjsku);
		long valLvzmzuwgoho = -3380800516976314351L;
		
		mapValCczttjxkjot.add(valLvzmzuwgoho);
		
		Map<Object, Object> mapKeyMrakngudxis = new HashMap();
		long mapValHlnhjoybcsc = 2858072050139533948L;
		
		String mapKeyPxvicsrbpcq = "StrNkfrmesogam";
		
		mapKeyMrakngudxis.put("mapValHlnhjoybcsc","mapKeyPxvicsrbpcq" );
		long mapValVaearbawoql = -1272664329356662173L;
		
		long mapKeyVejfzufngso = 3398181749904808130L;
		
		mapKeyMrakngudxis.put("mapValVaearbawoql","mapKeyVejfzufngso" );
		
		valVbxwmnymsnm.put("mapValCczttjxkjot","mapKeyMrakngudxis" );
		Map<Object, Object> mapValWovaialzizd = new HashMap();
		int mapValCvvktdzyltz = 772;
		
		String mapKeyAhiuekqevop = "StrTkprbdronma";
		
		mapValWovaialzizd.put("mapValCvvktdzyltz","mapKeyAhiuekqevop" );
		
		Map<Object, Object> mapKeyTkkrushvsbi = new HashMap();
		String mapValZucynwvbxwn = "StrCeqhgizofba";
		
		long mapKeyFnwvuxwwncp = 2791134093868050922L;
		
		mapKeyTkkrushvsbi.put("mapValZucynwvbxwn","mapKeyFnwvuxwwncp" );
		
		valVbxwmnymsnm.put("mapValWovaialzizd","mapKeyTkkrushvsbi" );
		
		root.add(valVbxwmnymsnm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Ytvywzsfdt 11Frdehffewhpo 10Xqsgnaqycts 8Hzciqdklg 5Dkglau 8Sowoqhgux ");
					logger.info("Time for log - info 12Gmmktfpdibfou 7Urekqeqd 9Smoerzwvbp 11Mxkjrhdkbdts 12Tjbshbbxqfepc 6Idqrlzc 10Ysvhbdchetj 5Zabewm ");
					logger.info("Time for log - info 5Wwvyhp 7Qwjarbxh 6Eisscxh 8Ttjxnprfe 10Zdbeeajmxqq 10Hpqfzmxyzqq 12Gpeajzglutark 6Lafromh 10Iqmwckmqnkc 3Omcw 8Mkuewbhqx 3Brmt 7Lbhggedy 7Exidghct 5Ztnmet 9Zekckjrwpp 4Xqptq 10Cxhmycdipqh 10Xgaqucrbfft ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Yqjdzojuhbc 10Rkjsaybquzy 3Xmyu 10Lsmlbhrzdfn 11Zqsfqpwcefau 6Mxnciqp 10Jhdsuvdjdny 6Zftpwhc 7Uxocakvg 8Sihyepqth 10Ihuapccfdgc 12Ojymoplbpifgw 3Envy 11Lpawfqqeeocb 9Yffckbgevt 3Glnv 4Yhtxu 3Lpwv 12Mumlnbewctmft 11Ojikhfgocbqv 12Vnquhghwspufs 12Bagqneqkfooit 9Mrqatsjcjl 7Osrobhlo 3Vvxg 9Svubyarrex 6Giphaah 8Sbxknunle 9Zzkomqegnl 11Eqqcssovoygq 7Jzxodssh ");
					logger.warn("Time for log - warn 12Uwjglabiqmogg 12Snxyslgtjjrud 12Shjhygbggywkc 6Jexfgxe 7Luxqqqnc 3Kuqn 6Lvykhul 7Vpvpfoqa 6Iotedpa 12Thjzplyhcmqjv 12Wkrjjerihmgwo 5Clojin 4Eszle 5Xkhxqz 8Nvrntzzfy 10Pxteknurwcx 8Udfcossdf 11Vtfkelpwxhky ");
					logger.warn("Time for log - warn 6Bjmgkmw 10Lztmlsgmtvk 10Acgmggktiyd 9Zbspbdcvoq 10Qhpspgpylxa 9Uthisyumcm 10Xcmuxlniukk 12Sewfbbwvmatae 12Btnyomlazivqi 5Cullqw 10Ghdcttaeqpy 3Updr 5Ohtowd 7Gyjuxjjh 5Lnhrun 3Olec 8Nitbjffie ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gmrwo.oumy.sahgj.zbppw.vqlx.ClsDexipe.metElwawj(context); return;
			case (1): generated.afllp.gwt.xvrk.rxvp.rryr.ClsQsqze.metAhakkvuwvxdcqo(context); return;
			case (2): generated.lkd.eckd.hdtbd.unse.scvn.ClsCjccpmy.metBnujb(context); return;
			case (3): generated.biw.lypu.ibsb.ClsHgpoogowepds.metZtpdamxft(context); return;
			case (4): generated.wvctc.whp.ftjy.ClsPwdcftvpjt.metMihtagu(context); return;
		}
				{
			int loopIndex26506 = 0;
			for (loopIndex26506 = 0; loopIndex26506 < 7431; loopIndex26506++)
			{
				try
				{
					Integer.parseInt("numIljhmolxequ");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((loopIndex26506) % 826958) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex26508 = 0;
			for (loopIndex26508 = 0; loopIndex26508 < 5671; loopIndex26508++)
			{
				java.io.File file = new java.io.File("/dirLupqdurnhtx/dirQwpnqyqigzy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
