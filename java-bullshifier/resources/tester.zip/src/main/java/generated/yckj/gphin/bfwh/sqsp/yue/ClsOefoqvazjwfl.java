package generated.yckj.gphin.bfwh.sqsp.yue;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsOefoqvazjwfl
{
	 public static final int classId = 137;
	 static final Logger logger = LoggerFactory.getLogger(ClsOefoqvazjwfl.class);

	public static void metFjgyzxmr(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[5];
		Object[] valSiiesevywnm = new Object[8];
		List<Object> valLvovyhljxoc = new LinkedList<Object>();
		int valUllgvphrdnv = 780;
		
		valLvovyhljxoc.add(valUllgvphrdnv);
		int valEzutjxvfooi = 838;
		
		valLvovyhljxoc.add(valEzutjxvfooi);
		
		    valSiiesevywnm[0] = valLvovyhljxoc;
		for (int i = 1; i < 8; i++)
		{
		    valSiiesevywnm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valSiiesevywnm;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Gebdyuksqu 3Jgvb 6Gpccazc 3Ymnt 6Bmfmvtq 5Zdvkgy 4Lacxi 12Etcltpmidgveo 3Lety 11Lmykwpbmszip 12Nesiktglgnicb 4Uxczc 10Hycwhslbtyr 12Xnktlyxyjahka 9Hgltuivxpk 8Jfqmpenof 9Ogqqkanizj 7Tvfihbtq 6Ekehltw ");
					logger.info("Time for log - info 4Icivz 3Rfys 7Wvcmbmik 10Zkslthvjicr 4Wdwbo 3Nhci ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Wzss 9Ouuwvfoybv 4Gmhzw 11Urwwkkeybvcc 7Bxogdgkl 10Nydzugiegql 3Oesz 6Xgnipxk 6Cteqxqc 5Ijtmmn 6Tkitjhk 7Ircyhwiw 6Ikyerqw 10Wzwgukjzwrq 6Oolukpk 5Axjlde 12Wtxahuslhyehs ");
					logger.warn("Time for log - warn 5Xnqbie 9Qfztghuzhc 9Icowaknfob 8Wwbynqfdd 8Fpdukahfo 11Vqzaelxnrhqp 6Gyuxpnh 8Zyohetnuw ");
					logger.warn("Time for log - warn 9Facnikfrgn 4Kabkc 4Ivrxi 11Ufcbyvyjoczf 8Myunuqhya 9Gadhntzndi 12Khmnfzacjqbhe 9Uqmmvzkvui 7Nzlffemd 7Qidhkfbi 3Jfdb 12Wbxfdbasuqdpi 9Btqzlmaiab 7Npdnbojl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Leaae 8Eqyspggtf 7Gblcobjt 7Wdvbibwl 9Ajpfotxgfr 9Jyjuhojnwj 9Aoxgcpfyre 5Igmbnh 3Xulr 9Ulzkrvpmsl 12Epwheqrfktawr 4Ewhik 7Jpbuvheo 8Nfqryzvkl 8Jkuahupcx 12Ynlwqmverhfkd 5Qgpzxj 11Vlswzkejviyy ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.exa.yssf.ClsHuxmu.metIeneankndf(context); return;
			case (1): generated.ojyuy.hdvu.yij.nuf.ClsJtdiu.metTlubvqwqs(context); return;
			case (2): generated.liyl.sfhr.ClsNilzqakfd.metIodijouzvnszdm(context); return;
			case (3): generated.zdmfw.qfic.ClsQmanwrctuzecr.metFgdlbhq(context); return;
			case (4): generated.aoa.azm.ClsTnwlnxjluoc.metGyncsfsf(context); return;
		}
				{
			long whileIndex22478 = 0;
			
			while (whileIndex22478-- > 0)
			{
				java.io.File file = new java.io.File("/dirKplabeuista/dirMbmoikcqatm/dirHqulcvvqhew/dirGdtuuwmnwou/dirLdsvavwtayl/dirGrjkeirqpfh/dirUqshywpedfd/dirBoenyynpzoz/dirUgltedwvytg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirHiaulwlpihc/dirYgvcjgqqgbi/dirBpmsebtbnpz/dirApfrzpezyph/dirGhvkibjpwzb/dirLywrvzzxtdc/dirKooppwnkung");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirUoyczppojdp/dirGxaquooyhce/dirQxruissdmiu/dirYloekaushlp/dirAqyvdfiywtn/dirUlztzvtysqt/dirOzdqiallpak/dirCobqzgupoeg/dirMbymhsmyyyn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
