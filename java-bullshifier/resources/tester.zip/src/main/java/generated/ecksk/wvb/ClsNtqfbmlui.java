package generated.ecksk.wvb;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsNtqfbmlui
{
	 public static final int classId = 294;
	 static final Logger logger = LoggerFactory.getLogger(ClsNtqfbmlui.class);

	public static void metJftpyt(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[6];
		Set<Object> valLygcnakrggv = new HashSet<Object>();
		Object[] valFnknznkmewz = new Object[9];
		String valIpzxusnchrd = "StrKbctjxisuuq";
		
		    valFnknznkmewz[0] = valIpzxusnchrd;
		for (int i = 1; i < 9; i++)
		{
		    valFnknznkmewz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valLygcnakrggv.add(valFnknznkmewz);
		
		    root[0] = valLygcnakrggv;
		for (int i = 1; i < 6; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Fohffrc 7Kftvxoer 10Ooarmofbzbh 7Qeryudvr 3Tnov 12Fkzquonnkiscl 5Pjfndc 8Woprrvyov 10Ieoohutiign 6Uotkuwh ");
					logger.warn("Time for log - warn 11Mxctvyfjyxyg 9Tahxpmigwf 12Aycntckpiiczi 11Ulnhvqpxseyi 8Bsvcrelnu 9Abjgpubjlp 4Rzlij ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Apylwt 4Gahzz 11Ohoqnaonbqpl 8Rldcljidd 5Mjtauz 12Pekeuzxtswxmt 5Lxylqq 10Ilacovjcrqe 7Zpvwbuub 5Hnhgva 12Nkrpqnfuokwoz 11Hrghzwntteda 5Oniuvd 11Ftxfcaywqicv 9Vxkojhbkpi 3Ttkw 3Wjdb 12Nuzlnstbdtbdz 9Dvfppkocos ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nigzv.opuaq.ClsWgekbyrmi.metUuviwodimvy(context); return;
			case (1): generated.vyk.nsacl.bsfy.saukt.ClsKpfdsyokiohmf.metOfxfjxkcir(context); return;
			case (2): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metHnipemdqhlr(context); return;
			case (3): generated.zoaxa.yfbb.ClsTybiqkipwo.metQnlswcnqbxmqgz(context); return;
			case (4): generated.agyh.aakn.unf.yzvm.uvtp.ClsPvvezxsnka.metMjhlk(context); return;
		}
				{
			long whileIndex25008 = 0;
			
			while (whileIndex25008-- > 0)
			{
				try
				{
					Integer.parseInt("numByoyhunkzti");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metNnezvlsw(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[3];
		Set<Object> valCgsofczbfou = new HashSet<Object>();
		Object[] valVttfbdtqmwv = new Object[6];
		boolean valWgrcafjfprf = true;
		
		    valVttfbdtqmwv[0] = valWgrcafjfprf;
		for (int i = 1; i < 6; i++)
		{
		    valVttfbdtqmwv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valCgsofczbfou.add(valVttfbdtqmwv);
		Object[] valWylhuvkbbpt = new Object[10];
		String valZpwxcmmwyem = "StrWxnsanyciet";
		
		    valWylhuvkbbpt[0] = valZpwxcmmwyem;
		for (int i = 1; i < 10; i++)
		{
		    valWylhuvkbbpt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valCgsofczbfou.add(valWylhuvkbbpt);
		
		    root[0] = valCgsofczbfou;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Udvjbcn 10Snajuriyrfx 12Qcrjyikwjkevh 3Snhi 8Ncqvyzjnm 5Juvxgy 10Hvlxxfbzgle 4Rrpgm 10Hgxmzdruuoi 10Frtyfwsedhh 11Aadxgclrgsut 3Mzda 3Ralp 6Laiiyji 7Xmfhhlym 9Wfovrfchkc 9Zybzspzfhp 3Pxnv 11Rpxsmjuxzyru 9Oxrjsrvgsr 9Kvrmgxvytz 5Oijsle 3Shmv 5Yxezyf 9Tuaydzytki 7Aqucuxrm 7Ucvpuvjj 12Xzhydviqkpwal 12Qhncuwribsypv 9Reccqrnslq 4Mowis ");
					logger.info("Time for log - info 5Exbnwk 9Agvpzjghgu 8Bhzuakovj 8Tfwcbwlfe 12Fmzxmldntufep 10Fkgnarizrbe 6Ujiopoa 7Samnfhrx 10Ofopdkpsngs 8Rrngsdohm 8Tgxbjikxu 5Agesit 7Ryjahrul 12Qugvsoysvrriq 4Khoch 5Soccic 10Vlnnakdyyuf 5Gaatua ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Xmxnhwpnreqf 7Vuxkzpie 11Zeluqtvrlrsx 7Zhefvecp 11Awhugdzhzktw 9Oluhfslrxf 3Sesv 12Tqhynhsmrpfkt 5Xtwhht 6Ggeolsh ");
					logger.warn("Time for log - warn 3Iurx 10Bzfhzbvhhop 4Qkwvb 6Uizjlbg 12Kiykaajnvdoaw 11Jzwcmpmgmqbj 9Hidiekghko 4Ipixr 6Kpbcqpn 9Ackihrfiwg 5Buagow 10Frocgfkcqja 9Jzuaadmfmf 8Ugmuvrymp 11Lryrzidmmznb 12Ehdntvvnvgjdf 3Sgzt 6Pxtcplw 8Srgejunit 12Fqxljxenqpqkk 4Mzkjy 11Xecqnsxuepdr 10Hkgxtwepkpx 8Qgremjjas 11Bltjmoyruyyc 10Mdbfdjyxurr ");
					logger.warn("Time for log - warn 10Fkaczfxvatf 12Vjwpuwpwxvean 3Lsvy 10Fzshxzepaoe 7Azixphfu 5Msbjuw 10Qcomnhapgoi 4Yxbcs 12Rqhejdsgoisqc 9Rrrktkijwg 4Tzbcy 7Wjfxwpao 10Wdfvziickde 12Fqpecbgxscxoh 11Cnnotuljoish 3Toxj 12Wltgwekbgzobn 9Oabakptsxy 4Vcygd 5Drwzef 5Zipmmv 6Bggsbek 3Nknk ");
					logger.warn("Time for log - warn 4Lzgxm 5Rqlomh 12Spqsduyjxalyc 6Shneoro 6Iwouajk 11Hshutenjfmht 7Oafcgrqi 7Gffaosjj 7Psftpotr 8Emywmfmmg 12Mcdupqrmtgdje 9Zfanbixsdu 12Ydrpfdfdpdbnc 12Wikhykxuklaik 3Atag 9Nqlzgayosa 5Fqfsti 12Cyhlcdvvwjrpb 10Gmauvtsqwnv 10Qylctmykgop ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Bozsmqgpx 8Fueoolaqg 8Ozvnjlndz 5Vysvev 10Vdojgqzreqa ");
					logger.error("Time for log - error 8Vuivicjup 3Bnjg 7Yrjqzzyo 12Pfyaqlwjxldyf 6Whxrnme 12Mvdklvrgnepvq 11Pxkvjyonkmzw 7Fhmfrihj 6Mzdvqpm 9Esnwzqrkjp 11Pngrhcdtarts 3Xdwn 7Oovvnbgo 10Icziafxsviy 5Ivsuua 3Ozxs 4Qujrq 11Mgrhbswksxba 5Wwqhkm 7Gmdczeda 4Wqwet ");
					logger.error("Time for log - error 8Hpzijtscz 9Gblphzknem 7Frongvtv 5Bwemyy 9Fskrgobskc 6Ymkyutq 8Ntuwdttsl 5Bzxwhh 8Mecoqesya 4Dneme 7Inxpbgkq 8Kwdegrfbx 4Cfemd 10Rsnmugshlvh 11Lqlzocixltrn 9Bcvdgwfriy ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cjexh.ehrl.mtwqa.ClsVshethruisurxt.metGryimbv(context); return;
			case (1): generated.tvv.ioy.ClsEqfmidfypp.metXarnsiydwdk(context); return;
			case (2): generated.tjmm.euxn.jmtp.ClsNhugjkj.metQafbogfqlngiyk(context); return;
			case (3): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metWpheeqsxvjk(context); return;
			case (4): generated.gasq.isr.fpndy.jhzr.ClsNxizwkdumgga.metHritpjgfte(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirCdmrguxhknn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex25013)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numLydcetyfihd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metOzgvgztdgxgwck(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valAprkrvsgfvu = new HashSet<Object>();
		Set<Object> valHearnkfzkou = new HashSet<Object>();
		String valNrgizqrfhjc = "StrRfsoufwgzsw";
		
		valHearnkfzkou.add(valNrgizqrfhjc);
		boolean valTjinsuugcra = false;
		
		valHearnkfzkou.add(valTjinsuugcra);
		
		valAprkrvsgfvu.add(valHearnkfzkou);
		Object[] valMixosfbukjb = new Object[7];
		int valXcybfmhlfsk = 90;
		
		    valMixosfbukjb[0] = valXcybfmhlfsk;
		for (int i = 1; i < 7; i++)
		{
		    valMixosfbukjb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valAprkrvsgfvu.add(valMixosfbukjb);
		
		root.add(valAprkrvsgfvu);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Fsmxqh 7Jegypwgx 8Afrhqacnz 10Fnlwtxfxcov 7Ssmfghbw ");
					logger.info("Time for log - info 11Mymeneigvfhi 8Inqjtrgap 4Iyqut 5Cjtipm 5Mchpwr 12Tkopsxgmsxzkl 10Lrjkinswlmc 12Nitakekrtaohv 8Ynxfipfvf 9Ssqalrgtnp 4Devvw 9Cpdhjfbhse 10Gknjbvdtppo 7Wojnwpeu 5Kshlen 5Ltujzk 5Nyumuc 6Buydyun 9Hkdfwvjyns 8Kzrcslhpj 9Hhhfedyxle 5Dcjnhx 8Eznaxgktq 5Bsukje ");
					logger.info("Time for log - info 6Obrplyq 7Oscwgrva 7Idhixihn 4Nkscm 10Ujbandcxgag 8Ialtdvpli 12Nwjufpiuvgtxp 9Bhzrunimze 6Uwerugr 11Bfnpggqwdlpy 10Lydatvrrhho 11Fwjyvbdoaggn 6Axacuzp 7Loxbwebk ");
					logger.info("Time for log - info 7Qhqapqpz 7Vnqqxagu 10Xkwfdbidvtw 12Xeqmbtffrtvst 5Vxpfsm 12Dcjyyijfyfftm 10Bjyqrtkdazc 4Uwdgw ");
					logger.info("Time for log - info 10Rjijuzcbhia 4Rrzab 6Ckdihxb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Yeegfwhzyvt 3Xbtk 11Somqunykwtfp 8Bvzumehcl 6Tkbogab 9Dktddfdnyp 9Wqsgsdqfir 9Uecojybpzn 7Xhbyzrxd 8Hcyjgkxhc 3Seaf 7Fuvqwybe 11Xdwksexifcjs 8Jaevlacrg 9Qxkngwuuqe 10Rztxjbamdbq 4Jdxaj 5Vvjfow 12Mjirbvlgczbmf 9Gziguuolug 7Hwgaqqui 7Zwcsgphp 9Zatpzidcig 6Idqjpbn 3Teop 12Zzjafrjydzmll 5Bbkokl 10Ibyjctkpycg 12Vqbjbzlbanhho 11Huqponowdgpk 7Dnhqjyab ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Imevvmuax 4Taoky 5Yslipo 4Bultt 8Vimqiukiw 7Actqedbd 12Blunczwqdfhlm 11Voabwssrioag 4Lwttc 3Ywoy 3Gxsy 4Paeyu 8Kfcxefoqg 4Goufz 4Ggogu 11Hulmmlknnori 4Rnltd 8Qfvpkguhx 12Vaucxazxdfmva 5Vgcxcb 11Hjnvhdccmyqj 11Gzbncdyyirpf 11Mvolffvzucaq 12Genfbqbmcvapa ");
					logger.error("Time for log - error 5Ctamcq 7Lxaidfky 5Anklao 6Fwpigbk 6Uukjnvg 12Flnlckbgjyvui 11Jiegyezevrii ");
					logger.error("Time for log - error 9Igmhegjkks 11Tubrzvctmmod 4Rqfev 11Gmnfapndymku 7Uhwjzfva ");
					logger.error("Time for log - error 12Ahsirkxwxtsrl 12Cshpdjpfiiqbo 9Touxgbohis 4Udyrg 10Nwwjasnmxlu 8Ddnkgbkxu 9Yoyiqrxlft 12Oclmjhaooznhw 12Gxlyikkvnoxld 10Kdpvjrtqrfk 5Fhxavt 10Gxwesfobuxx 5Aowrhk 7Jpojxbhq 6Dqpbvqa 10Qrqdaerdzoy 10Jfdfsslorjf 7Ykiftpdb 12Icxexxkalammn 3Ccrd 6Zhlnplc 8Zxcvupcrg 12Twqrgjubxommt 11Etuezwtpfftl 11Iggwnnmxpimo 9Bzzlkgiohk 6Omyelht 10Avqegikurhz 9Dnwkeytrkc 5Uepuqu 11Lvodtwolbkaa ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qrzc.frg.utv.itv.ClsGoyvsxo.metOllflngqrpzh(context); return;
			case (1): generated.afz.qen.lrlj.ClsTvxlbccvg.metBrsibddpey(context); return;
			case (2): generated.kyd.fxg.ClsVvcevjvyz.metAvlkamwowqupb(context); return;
			case (3): generated.mao.kidk.mlsjr.hew.xst.ClsEfomkejxcxzr.metEruurpx(context); return;
			case (4): generated.rnv.dtvl.uhnk.ClsTzqkdsb.metWwthjnaijwlfi(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex25018 = 0;
			
			while (whileIndex25018-- > 0)
			{
				try
				{
					Integer.parseInt("numOhhnrfodvpc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metChuplbpiowm(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Object[] mapValIcanhbiceji = new Object[5];
		Object[] valLkyjffgblvi = new Object[8];
		String valWibzgqxmfjh = "StrZclzwldvhdc";
		
		    valLkyjffgblvi[0] = valWibzgqxmfjh;
		for (int i = 1; i < 8; i++)
		{
		    valLkyjffgblvi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValIcanhbiceji[0] = valLkyjffgblvi;
		for (int i = 1; i < 5; i++)
		{
		    mapValIcanhbiceji[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyXzttebsvuau = new Object[10];
		List<Object> valLnutwiknnxl = new LinkedList<Object>();
		long valIktkmtzeuhf = -3678509394145378722L;
		
		valLnutwiknnxl.add(valIktkmtzeuhf);
		
		    mapKeyXzttebsvuau[0] = valLnutwiknnxl;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyXzttebsvuau[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValIcanhbiceji","mapKeyXzttebsvuau" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Ylbbwvyfb 11Tsqnpomuemvv 5Rthjcj 3Qdlv 4Wkmji ");
					logger.info("Time for log - info 10Apxghwlnxfn 6Hlytljj 4Ycydt 10Uumqzkbvqqp 4Vtzma 12Zsqudwsltkuek 5Avnqei 9Sljhznxnap 9Jfiemysulg 3Mnpe 9Itknjagtkl 6Qgpjzog 3Zgrs ");
					logger.info("Time for log - info 8Whaslhmsr 10Exyadlefxxi 11Bkoxllwdrump 4Jcoby 10Gpxeccyvoae 6Unbxqha 12Xromlxayxahfh 3Wxcu ");
					logger.info("Time for log - info 6Hyogeej 3Piqs 7Cmqexgwy 8Boqeihoir 5Glfjpg 4Txfcr 4Ejilm 6Ldlldik 12Hyctribxqxaqi 3Ikkz 5Rbiwvf 7Bvbiqlsp 6Kkidjjg 3Qfwv 8Qsdigvpte 3Tbgc 6Mxvkgfr 9Tkrwnmdvsy 12Nwyryofxavesm 5Zjmtlm 7Zrfrsiej 10Ipspfuxbhgu 4Kyjtz 11Euyraznnwpol 4Zcolh 12Osfwesybxddfp 6Bgeivwn 6Cwunrrj 5Bmdywg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Wrtznmnkjdp 12Kefsvvoqzytbc 4Nmawr 11Rzhiwrpeobqu ");
					logger.warn("Time for log - warn 5Utwpdo 9Rjlatvpdwv 11Pojlmymnxfkc 9Fvypubnllg 7Sndzpwxn 12Henabigxecprt 5Avibvo 8Ycbitpopi ");
					logger.warn("Time for log - warn 5Mmdayq 4Gudry 4Ghsfm 5Gsxrii 5Fqkcme 8Abccbncja 6Nuatxnr 3Ilde 5Mmfdit 10Isehptahazg 6Hqcfwor 12Nbzsrvvhigvcv 11Kprpjludrqjg 9Nxjfilsbfq 9Jgwkphwewk 9Cgrljjgfsf 7Vckkqivz 3Coip 8Rgsjmzqmr 8Dpuidaidp 3Uguw 3Nbny 11Livsmdzfqeid 7Bezpgdac 3Hqyj 7Uyijywve 10Syohqjsokef 3Vrsq 6Ggymdde 6Bdxsqkl 8Cqkulykkn ");
					logger.warn("Time for log - warn 12Qpdwoulqmteci 3Kxlt 4Ykxzw 8Eccpkkvtm 8Oholdlxdd 12Nafhqhmwsbijm 11Drszyuhkpslt 7Gdlcmejx 6Lcgnkjl 12Maqzrwkszilzz 3Djjb 11Jlcnzueigcch 3Snme 11Cbxpygxyinps 4Jwrkp 9Qlpvoniwdx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Xpluglru 9Dozmhzqcep 6Omexycl 7Uchdklbx 7Btieffqs 7Ltmjdwfq 5Phtpqz 4Qjzaj 3Irzn 7Rmgbmsss 3Vojg 11Hfhraathrock 10Rqackafactx 6Tdlnkiz 5Rinvqr 4Nnjqn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aqqfv.gdkxm.pact.ClsAgtwrqa.metXrocwodxu(context); return;
			case (1): generated.pxdt.vcuzq.tfk.bjngo.ClsCaopcwu.metNrjzvdamjddqk(context); return;
			case (2): generated.zeo.tykl.bkniu.uhs.uwxh.ClsUegpnzqhmar.metVjrdqy(context); return;
			case (3): generated.kwutd.ipdj.aoc.ClsFtolmgndn.metCctifzmyyzkh(context); return;
			case (4): generated.cxtx.gvv.woynp.wvzz.den.ClsHntsemdxcztjdw.metSzmkjzex(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex25028)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirQdrbxquvwgj/dirMxzakknybsm/dirWmwqugoexai/dirLpomhopayyi/dirAukjsuapbxl/dirUvjggdzafep/dirJozpuwafuxx/dirVqwjpdoxrqs/dirXvxyyhsmmie");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varKiojxgbfwps = (Config.get().getRandom().nextInt(345) + 8);
			if (((varKiojxgbfwps) + (varKiojxgbfwps) % 76815) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((6962) - (3337) % 517927) == 0)
			{
				java.io.File file = new java.io.File("/dirXcisfsskwsq/dirNpgnlvpzbqz/dirNazvxebvsni/dirNfytgoidoaf/dirFlhprnveief/dirCtlohjjvqdc/dirWczqbgbdxnj/dirUznagfdqjgw");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
