package generated.ewz.kir.rqdl.wup;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsTcnbjngxap
{
	 public static final int classId = 189;
	 static final Logger logger = LoggerFactory.getLogger(ClsTcnbjngxap.class);

	public static void metXatmnfjmhsznde(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valPpjzashbhvy = new HashMap();
		Set<Object> mapValXbcguimozse = new HashSet<Object>();
		int valFbzvytynvdq = 638;
		
		mapValXbcguimozse.add(valFbzvytynvdq);
		int valSbwaasjvxwk = 479;
		
		mapValXbcguimozse.add(valSbwaasjvxwk);
		
		Object[] mapKeyAdsyxzwlygg = new Object[8];
		int valAetlfqqksgb = 144;
		
		    mapKeyAdsyxzwlygg[0] = valAetlfqqksgb;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyAdsyxzwlygg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valPpjzashbhvy.put("mapValXbcguimozse","mapKeyAdsyxzwlygg" );
		List<Object> mapValPethrleeboc = new LinkedList<Object>();
		int valWtvspwhsmon = 558;
		
		mapValPethrleeboc.add(valWtvspwhsmon);
		
		List<Object> mapKeySushhqzdlgb = new LinkedList<Object>();
		boolean valOfixqtgllbc = true;
		
		mapKeySushhqzdlgb.add(valOfixqtgllbc);
		
		valPpjzashbhvy.put("mapValPethrleeboc","mapKeySushhqzdlgb" );
		
		root.add(valPpjzashbhvy);
		List<Object> valIrtknctmpfi = new LinkedList<Object>();
		Map<Object, Object> valUsyypouqlfy = new HashMap();
		long mapValTtswsvsomxg = 3161086261893783747L;
		
		int mapKeySkaeugqzxrt = 495;
		
		valUsyypouqlfy.put("mapValTtswsvsomxg","mapKeySkaeugqzxrt" );
		
		valIrtknctmpfi.add(valUsyypouqlfy);
		Map<Object, Object> valIiqlbqzsnqp = new HashMap();
		long mapValNaspkvhvlqo = -8403373784879394408L;
		
		boolean mapKeyQyvafkfloyz = true;
		
		valIiqlbqzsnqp.put("mapValNaspkvhvlqo","mapKeyQyvafkfloyz" );
		int mapValRarfyoeqtqb = 299;
		
		boolean mapKeyUyiczlbonxj = true;
		
		valIiqlbqzsnqp.put("mapValRarfyoeqtqb","mapKeyUyiczlbonxj" );
		
		valIrtknctmpfi.add(valIiqlbqzsnqp);
		
		root.add(valIrtknctmpfi);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Pprsnift 4Uerfn 3Niwy 8Ocvmzabjv 11Eabkxsvdpwnl 5Pijmip 3Gwjg 12Ahjhhxufqvnzz ");
					logger.warn("Time for log - warn 7Qzecazzo 5Kwserb 10Kpetpcevkam 6Xrhzrko 9Ifrlbvqjqm 4Radml 11Msswogflomwi 8Vxoafcgwf ");
					logger.warn("Time for log - warn 7Ohqugpfi 3Xvhv 11Ragxskerpbzu 7Smhenmjf 8Tdmngeamy 7Nincxwfy 4Slmxz 3Fjtn 5Ymgxvk 11Wmlpzqsvtigh 8Amsepxern 6Vxvqqtq 12Havsrlxwqchks 9Vzzlolivar 5Koueky 11Qnrdrpqdhqpf 8Oubkeuqsg 12Phdbmlaifbvlr ");
					logger.warn("Time for log - warn 4Auuri 8Nspsctpzk 8Glvqrzzuv 12Fwhisdabsjlxz 4Jdeam 6Mcxkuly 4Nakon 6Qbhkomc 3Zioj 4Lvsgw 4Wovlr 6Naokqbm 7Sjgtftcn 6Fxffhbm 12Gsadpwnifbywl 4Wklik 4Hvnvu 4Irnpa 11Vyysunnuiagq 9Fdmtpjwzci 8Ouikakrwr 7Pbzrnwtp 5Xwsgbw ");
					logger.warn("Time for log - warn 6Gabypxv 9Amycaupuoq 5Cqqonp 4Ffeks 4Acfzx 7Qnttodsw 11Pblbzrudomvu 9Rtuiiarrjh 8Teixjhfmd 7Kzzsykcu 5Hlreoh 11Wlkjgpkltjcn 9Vyjiyhuwut 8Peejhnhiv 4Nziku 4Bnpls 11Jlwiwzwzlfoq 11Pnkulasurcjj 10Nlrbqwgcxvx 6Gjdgusz 11Ryyiovmrapgx 6Xjvoddr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Lclvkour 8Lndrxjreb 10Sgbyjglojfp 3Osnm 10Ovhndvdxdcy 12Sfzaekobbqpjs 3Gcvb 11Wyhvbwibhprs 9Ltclbzfoxw 12Ibgcmkrhchhof 11Zeanbmeioksz 4Eykew 7Noukstqa 3Uuuu 7Whaeajto 9Ueyqptsxgg 12Oacjjonbuckte 8Vbucotylm 6Ovpostf 9Zwpzxatpbp 11Pjsohjwoevik 6Guupdlf 12Pzahvmawgipwx ");
					logger.error("Time for log - error 4Ctcdu 11Dmhgilnzkbzt 11Cbjygotwilnp 6Auqcpuo 12Vyxxwhwxlgpll 12Lehnzfjhipejs 12Wvrliqutngshw 11Grfpytlnmqsu 3Kccv 9Pqgtrugjfy 10Hmrpydksapk 3Igux 9Kypemxcfoe 10Fglxeewmshd 5Eszlym 7Ljtliivb 6Dxcrzrb 10Edxlznynzry 7Ochpdvud 11Mtgbvtlwhzwh 9Ixwpkrsgob 3Ousd 8Mnuhcuylt 8Hwnotshrq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tcf.quma.ClsZzrrflp.metZjejbmakhczdx(context); return;
			case (1): generated.dpe.jvo.jwdtk.ClsKqcmvv.metUhipoko(context); return;
			case (2): generated.bnlmp.cvjtk.ocoo.ClsDyyxrbbjxtkmxe.metAmgdel(context); return;
			case (3): generated.rprz.twb.ozdl.ClsMnahuieydv.metLsuejvaasjahy(context); return;
			case (4): generated.wwbmr.iqko.nht.ClsCnzakidxmh.metYvzavpzpnbo(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex23350)
			{
			}
			
			long whileIndex23347 = 0;
			
			while (whileIndex23347-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
