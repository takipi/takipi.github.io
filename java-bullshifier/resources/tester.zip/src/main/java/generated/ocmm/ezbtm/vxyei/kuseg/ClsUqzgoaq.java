package generated.ocmm.ezbtm.vxyei.kuseg;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsUqzgoaq
{
	 public static final int classId = 273;
	 static final Logger logger = LoggerFactory.getLogger(ClsUqzgoaq.class);

	public static void metSglyom(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valVqcgagpxxog = new LinkedList<Object>();
		Object[] valXmjttfwvbdw = new Object[11];
		long valEfzlupwhpqa = -8196901058072297740L;
		
		    valXmjttfwvbdw[0] = valEfzlupwhpqa;
		for (int i = 1; i < 11; i++)
		{
		    valXmjttfwvbdw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valVqcgagpxxog.add(valXmjttfwvbdw);
		Map<Object, Object> valWtflfydobzu = new HashMap();
		int mapValXnrfhjxhbjs = 787;
		
		String mapKeyIxbjhyihwqf = "StrEhkxxbnznuy";
		
		valWtflfydobzu.put("mapValXnrfhjxhbjs","mapKeyIxbjhyihwqf" );
		
		valVqcgagpxxog.add(valWtflfydobzu);
		
		root.add(valVqcgagpxxog);
		Map<Object, Object> valUplfykwylqc = new HashMap();
		Map<Object, Object> mapValObplzqswoqq = new HashMap();
		long mapValXpoujypeivs = 6314418223255686762L;
		
		boolean mapKeyArtcbqgqnzu = true;
		
		mapValObplzqswoqq.put("mapValXpoujypeivs","mapKeyArtcbqgqnzu" );
		boolean mapValStxoiakbovx = true;
		
		String mapKeyCuubhgzwiwl = "StrYxjoymztowp";
		
		mapValObplzqswoqq.put("mapValStxoiakbovx","mapKeyCuubhgzwiwl" );
		
		List<Object> mapKeyOoaweidjqop = new LinkedList<Object>();
		String valMlaxtwoyaoe = "StrRbjkzaqsacc";
		
		mapKeyOoaweidjqop.add(valMlaxtwoyaoe);
		boolean valRlgxegogktd = false;
		
		mapKeyOoaweidjqop.add(valRlgxegogktd);
		
		valUplfykwylqc.put("mapValObplzqswoqq","mapKeyOoaweidjqop" );
		Set<Object> mapValBttajcnhqov = new HashSet<Object>();
		String valKcbeywjxlhm = "StrIcgaiaxpgqn";
		
		mapValBttajcnhqov.add(valKcbeywjxlhm);
		int valAnirxnolrpg = 811;
		
		mapValBttajcnhqov.add(valAnirxnolrpg);
		
		Set<Object> mapKeyQwmyxbyrbnh = new HashSet<Object>();
		String valVnbdcoodfmz = "StrOrrnsjrucpj";
		
		mapKeyQwmyxbyrbnh.add(valVnbdcoodfmz);
		String valOfbstbgwrfe = "StrIyrrcdwkblh";
		
		mapKeyQwmyxbyrbnh.add(valOfbstbgwrfe);
		
		valUplfykwylqc.put("mapValBttajcnhqov","mapKeyQwmyxbyrbnh" );
		
		root.add(valUplfykwylqc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Sjyufzmbzlo 5Dplzrn 8Eqigbkfyb 11Tjllvsmffpli 9Odpmtaztsg 9Mrnoljaqlx 10Bfjyosxbwzu 6Riysbnp 9Xyfqcjmnrf 7Jzkdpbxo 10Pslovvxqxmr 12Pjudmihnejhjz 11Knokwuzvbwiv 4Vfobh ");
					logger.info("Time for log - info 11Rohgobhrmjps 6Thxfgeq 11Tvwujqnffind 7Ypozqvgy 9Gwkkqnimjs 8Bpcjktzce 10Ihfypupcifz 11Itbryuecxled 11Uiznvcsdfzsn 11Oyvcssclsmla 11Vjhvntynbslz 6Vwkgfpa 10Xyilmclwpor 10Gmepohjcslt 6Nomcnfy 5Tlctin 11Gvbtoelhhuhd 5Vjnmyt 3Ugra 5Dfectf 12Ugnwyxeppeyis 12Wshegfkrvcmen 7Fncfhlnv 3Nahb 11Uechdyygpdrw 9Rflhhudpys 9Iweeflqhij 3Qhkc 3Cwtu 12Uffeoljidazon ");
					logger.info("Time for log - info 9Gthgjteduo 10Dhsnyllblnf 10Tvnqdzuippk 12Uffhlprlepvny 5Ekjygb 8Wuxipeufm 11Tzhgncegdjam 7Fmgvrauo 12Vyttlpnfdzgit 9Clyfftsvcr 5Oetbwy 10Oxjifmdtlon 10Dhrnoyjsugi 5Gvgcjo 11Onuqzurashwh 4Rkzzw 9Gyaukonbds 4Uwdsm ");
					logger.info("Time for log - info 12Ufpdabkhikwqc 4Auzpy ");
					logger.info("Time for log - info 5Xfbktp 7Algnstmf 5Wanngy 4Vnvxy 7Tqjrxxix 3Uykd 5Sznvxl 3Dycd 5Fbchbr ");
					logger.info("Time for log - info 6Tbsjyia 12Kuygvoupcbqgp 4Vavrz 10Eseerpcdsuj 10Fkimivhxpcy 10Crjjpkwjkcb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Rgytv 6Koijlho 7Sqksdnks 10Whshjuveqgb 3Esfy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Tznhulp 3Dryd 4Zmdhy 4Ywqmc 9Zkegudzsxa 4Qoqvb 4Shtzh 3Quxj 10Uykyqsnuuif 5Bgktfs 11Odrlsbopcrzu 4Foijr 3Fbun 7Wnhznmyi 3Gznl 7Evueulmr 11Pyzgahrihxqv 4Vlrrd 5Cqxrwu 8Igyuaritn 8Ngosrplew 8Wxsdgukgi 5Uqgvms 6Khxvvhh 4Kafhq 7Zxnradpx 4Slznp ");
					logger.error("Time for log - error 12Vvmhvdesjeqys 10Kgihgsomflk 11Dzkvfcykvhgc 7Rtjagpme ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hadv.dozj.puo.ClsVowitvkgtx.metBrrizswg(context); return;
			case (1): generated.loe.helvz.umzz.ClsSvkkzn.metHjtxfwvar(context); return;
			case (2): generated.kklo.eog.twpb.eja.vmrt.ClsCtkkdlrnk.metMzowgzzffz(context); return;
			case (3): generated.liyl.sfhr.ClsNilzqakfd.metIodijouzvnszdm(context); return;
			case (4): generated.qcqbk.ovao.ClsTizdo.metOqeer(context); return;
		}
				{
			if (((2781) - (4050) % 747288) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((3246) % 81466) == 0)
			{
				try
				{
					Integer.parseInt("numQewzikhhxnc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metIufhbdjk(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valXnsegbvsllh = new LinkedList<Object>();
		List<Object> valOhdvnrvyugs = new LinkedList<Object>();
		boolean valAmbxrtnauzs = false;
		
		valOhdvnrvyugs.add(valAmbxrtnauzs);
		long valRuwvelokpig = 6033680271493100080L;
		
		valOhdvnrvyugs.add(valRuwvelokpig);
		
		valXnsegbvsllh.add(valOhdvnrvyugs);
		Object[] valXrrajmkjssr = new Object[3];
		int valQpqnufbprpk = 960;
		
		    valXrrajmkjssr[0] = valQpqnufbprpk;
		for (int i = 1; i < 3; i++)
		{
		    valXrrajmkjssr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valXnsegbvsllh.add(valXrrajmkjssr);
		
		root.add(valXnsegbvsllh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Uqbgsho 12Bycszbrsernok 3Vobf 11Hrhhsjipnrmz 6Bcacrmv 8Fvvfdxwzc 5Xiwzxp 10Obhjoodmtde 6Hvtpuoz 7Jgzdlhob 6Ewemnmh 9Sbeysexokc 12Bwuinwbuyearq 12Nbrfgfjiehxuw 6Qgrbiam 11Zqhcutvnsvhq 12Tpsjfvuciycre 8Altncnggz 6Olcqgqv 11Sibsrplnjuau 8Vtmsnxjkm ");
					logger.info("Time for log - info 10Itthtixtpav 8Dmoqasufu 10Ksmsgnmmvhe 8Xbypkmvin 4Dlrlc 6Trsmwgl 7Bteomwbk 7Iqlopeff 11Hsvkewwnhhyr 9Edapiwwvxu 4Vgvae 12Fvsmcnaavuysk 9Qujnaxtqir 5Tywrxw 5Rgqras 3Pizd 12Djpxgzaxlqpne 5Gdqxwk 5Lzdari ");
					logger.info("Time for log - info 8Qszawcjhw 11Hwvjadgzsqbg 3Wuor 11Zmmhofipvalx 4Yihge 7Jpfqoekg 4Lcjgh 7Dtdbkmjm 9Ychyfjwzic 11Xufxtajnydbf 10Qcqzyjovjyh 10Ksbdvokcija 6Deuktjz 8Zldhqfjti 3Dyjv 4Pfqlr 10Vuvmhzufgvd 3Chsj 12Bgindokdbfbrp 8Jpoxvumfx 5Ulzkpc 11Rsykytzhgnur 6Tvgtyut 5Xbtuzb 6Bzrqpca 8Bmdzduxuh 12Omnjxogsagdhn 3Bahq 4Pljdm 5Qmyolz 5Rlloaq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Pahezwoc 8Yabiwbcnk 3Ewex 11Yabmsbrrqnet 11Ljnnrvwvithm 8Heapbilet 12Irigepbtfxyyh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Fcgpfsomcunm 11Tnykalvjkmjr 10Hofmfooavgr 6Eektasx 12Bdaruzwrsytvo 7Nwundsqx 11Mzhroeiawqer 5Iwmwpy 3Pnmk 9Vbhliktlep 9Qekolpfkip 10Ejbwidtweqa 4Hipsf 8Zzdhofokv 6Zvdxdsg 5Rpwxrn 10Jfebbakbqfl 9Flnciyfeuo ");
					logger.error("Time for log - error 9Cyybuqmrdi 10Evmvpmroenn 9Zsazlkxbfb 3Yacf 6Xcmbvqr 8Txyxjlfwe 3Bwgq 7Ubxpgyrn 7Nxzfvbws 10Nuhokfpaizt 3Jwmb 6Sosbjfa 9Zikwkdomru 9Wuefzclvdv 4Aqgmq 9Fyeqkwpnfq 7Skjhbokn 4Xyidi 7Zpnffnua 6Zgxfjum 7Mrgzajnl 5Itbwbx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hvqh.qdnb.tawyn.ClsAaddylg.metCsnugb(context); return;
			case (1): generated.wxgmf.hjxrw.ClsYvfyyrknqfec.metRjzexmwk(context); return;
			case (2): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metLlvwdlebp(context); return;
			case (3): generated.qdml.hmlho.ClsQuiharvpvfv.metXrurj(context); return;
			case (4): generated.fdf.qdha.fywc.gjubl.dtsb.ClsBinezgxhqjfe.metSxeoz(context); return;
		}
				{
			long whileIndex24731 = 0;
			
			while (whileIndex24731-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varUoncugemywq = (2445);
		}
	}


	public static void metGzyab(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valJliacyzxohq = new HashMap();
		Set<Object> mapValTwinhnhpbtf = new HashSet<Object>();
		int valFdlpzlxqply = 832;
		
		mapValTwinhnhpbtf.add(valFdlpzlxqply);
		
		Set<Object> mapKeyWyhobcobkxr = new HashSet<Object>();
		String valGmzekdinctw = "StrCeceqvnahov";
		
		mapKeyWyhobcobkxr.add(valGmzekdinctw);
		
		valJliacyzxohq.put("mapValTwinhnhpbtf","mapKeyWyhobcobkxr" );
		
		root.add(valJliacyzxohq);
		Object[] valWxirgzgtont = new Object[2];
		Object[] valSkjndpozrpe = new Object[4];
		String valHccaecerdbv = "StrJzybqqyxinj";
		
		    valSkjndpozrpe[0] = valHccaecerdbv;
		for (int i = 1; i < 4; i++)
		{
		    valSkjndpozrpe[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valWxirgzgtont[0] = valSkjndpozrpe;
		for (int i = 1; i < 2; i++)
		{
		    valWxirgzgtont[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valWxirgzgtont);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Laky 8Ojibeikuk 9Foosmxajjm 5Dboktc 11Dnzprdvmdhll 4Gujdr 8Slkpxiscq 5Cpquop 11Wzvibgoibqtd 12Pavarntkumomr 9Gucdhlugss 12Cesmpvheayyil 8Qyvmbpbda ");
					logger.info("Time for log - info 3Uuiu 12Renhvorqpivdg 10Szakydkjiyt 11Zktszalzpynv 9Ynbybybqvj 9Uemaksvuws 8Fgxnprsku 10Egwruygiawk 5Fdjtte 9Xejrusuhrm 6Wnepswt 11Afuxrdrqsmkj 5Banjkk 8Tbealtdrc 8Loawyrubq 9Kylhbavlvw 5Darofv 6Kuxfoqj 11Xvmiualpbrlc 10Kclvqcxywgy 12Nkeyvrmqomfck ");
					logger.info("Time for log - info 4Aolea 7Qcuetdmy 4Qnlgd 8Ddzclhkum 6Pgtdbla 9Tprztuxxgy 11Pyrcbqzpmoaa 4Rqxox 7Agjcacyx 12Vuxsskbstkpbr 6Mdmuyto 11Zojmbwcszizo 6Xlbzjgw 10Zyqzdjtvwka 9Ifxwmhjsci 8Xdkawjojl 5Bjqdec 11Ncpqwxnildjq 12Vuzkhzquwzroo 9Xxepvhyuxk 7Oocogimv 6Ctggjgi 11Ckkrgcvboyxs 6Eqhjcjn 8Fhchqamdj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Drjolrvweva 9Auaaevelxa 5Hyzwlp 9Pgfdgjnxew 8Qvhkvlhpv 8Usysfiunq 7Mvgytkme 9Ndpbfdwkwj 11Mwfvgdvbppnv 11Fuksnbmxsksc 8Xdhoxvlpo ");
					logger.warn("Time for log - warn 3Mguk 7Zcmrgkrn 7Udbbuvhk 7Slrwmmbe 9Pficatpyou 6Lpxuuno 6Jfrabgi 11Webxufnqhrib 9Qochtojrmy 3Leca 11Cmfwsiwpnbcn 3Fdty 3Hjrs 10Wowdaqbmzgv 10Vuyydefspxt ");
					logger.warn("Time for log - warn 12Uhitumzgyuxwf 5Rhtdnm 8Ivvphtoqs 4Kgslt 3Ccik 11Hltyfevxwudq 7Qtvvvxta 3Kcrn 4Txazc 9Nzarmbcgaq 5Amrlwk 5Wbbres 4Yyupq 5Omtwgc 6Hyknrtv 3Pief 11Capzlhkgqwza 4Sjdxl 10Eduuyqmsjyj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Olylwhdmf 8Dduasyjzc 7Gejblwch 8Wkzzasaad 10Clzlxzfasnq 12Fyhohfdawqnog ");
					logger.error("Time for log - error 12Xvcpujshogoqa 7Acmjnnhb 9Bdyxdbeuhw 9Kkqkxrnble 8Yenjbrdsr 6Eoibwtx 3Pomx 12Tefkznkrndatv 4Yvcit 11Vqjbvpjzrccw 8Catsadwpx 5Guvvgj 12Wkqsmhyanjzrq 7Udesvhbt 8Cmcepwqoh 11Pzborvxtzlft 3Xokg 8Bgjonraex 10Asliwtlltnm 8Khzpgihia 9Khrqsqcigt 10Shzhmzuozsg 9Kgavqxshtb 6Vwjzwdg 7Crshgneo 6Otdvyqo 11Eygrccmowwig 8Nhfdoactq 7Vhpoahdf 11Rgwsbvrbhbah 11Alisdvycoolf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lzrmm.bjgfs.ClsQdamrbuivuq.metJaltcvoopburb(context); return;
			case (1): generated.bde.vdlp.frn.zsrjp.eqwxd.ClsMvedn.metBrdejrtmmvqjyb(context); return;
			case (2): generated.kklo.eog.twpb.eja.vmrt.ClsCtkkdlrnk.metMzowgzzffz(context); return;
			case (3): generated.pgg.urfbp.dpry.ClsLqnnoewxwh.metHqhcu(context); return;
			case (4): generated.ymhs.ivq.mlr.cezkl.gzyiv.ClsKvdrph.metXevuffadmfcuxi(context); return;
		}
				{
			int loopIndex24736 = 0;
			for (loopIndex24736 = 0; loopIndex24736 < 4148; loopIndex24736++)
			{
				try
				{
					Integer.parseInt("numVnhwrwwttgq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
