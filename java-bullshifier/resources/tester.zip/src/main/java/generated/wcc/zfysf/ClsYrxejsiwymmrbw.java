package generated.wcc.zfysf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsYrxejsiwymmrbw
{
	 public static final int classId = 56;
	 static final Logger logger = LoggerFactory.getLogger(ClsYrxejsiwymmrbw.class);

	public static void metKnfdaxts(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValWpwaifygnhl = new HashMap();
		Set<Object> mapValAwcugnndkuc = new HashSet<Object>();
		int valVexehuamxgg = 169;
		
		mapValAwcugnndkuc.add(valVexehuamxgg);
		long valQotwnptekgu = 6928824571265313529L;
		
		mapValAwcugnndkuc.add(valQotwnptekgu);
		
		List<Object> mapKeyBdjyzlqqaho = new LinkedList<Object>();
		int valZvbyqjpdifw = 426;
		
		mapKeyBdjyzlqqaho.add(valZvbyqjpdifw);
		int valFpjtnggyeva = 462;
		
		mapKeyBdjyzlqqaho.add(valFpjtnggyeva);
		
		mapValWpwaifygnhl.put("mapValAwcugnndkuc","mapKeyBdjyzlqqaho" );
		Object[] mapValOkhobseayhx = new Object[3];
		String valJfphtcpjwzs = "StrWjjrnkzxzoo";
		
		    mapValOkhobseayhx[0] = valJfphtcpjwzs;
		for (int i = 1; i < 3; i++)
		{
		    mapValOkhobseayhx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyDrbfpizxfjg = new HashMap();
		boolean mapValDjcqnmpjnpz = false;
		
		int mapKeyDayjwrmbjzf = 59;
		
		mapKeyDrbfpizxfjg.put("mapValDjcqnmpjnpz","mapKeyDayjwrmbjzf" );
		int mapValSvbiviubkeu = 596;
		
		int mapKeyNmwofglirjw = 164;
		
		mapKeyDrbfpizxfjg.put("mapValSvbiviubkeu","mapKeyNmwofglirjw" );
		
		mapValWpwaifygnhl.put("mapValOkhobseayhx","mapKeyDrbfpizxfjg" );
		
		List<Object> mapKeyFskdocqchwh = new LinkedList<Object>();
		Object[] valUrepbzgzmli = new Object[3];
		int valBhwhecgujwb = 370;
		
		    valUrepbzgzmli[0] = valBhwhecgujwb;
		for (int i = 1; i < 3; i++)
		{
		    valUrepbzgzmli[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyFskdocqchwh.add(valUrepbzgzmli);
		List<Object> valYwhsgirihid = new LinkedList<Object>();
		String valKivqvicrosh = "StrEvgckltwnos";
		
		valYwhsgirihid.add(valKivqvicrosh);
		
		mapKeyFskdocqchwh.add(valYwhsgirihid);
		
		root.put("mapValWpwaifygnhl","mapKeyFskdocqchwh" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Kgkdjcumemoka 11Przeqanbqgyz 9Cirqzdmome 12Fmezwrbbistqq 4Zieat 5Xhuywr 7Uwbuqeqg ");
					logger.info("Time for log - info 3Egzw 9Gyayzqbmjz 3Ksyz 8Nskwnzzen 12Jlhluyachcbro 12Swwrsnnbhqkkc 11Uhsjlbqyxyak 6Evsjybl 12Jyyxsywxbamwt 8Tfskrjwmk 12Oyqsxtkagleim 9Kqcrgkigid 10Zdfxwifeckg 5Kfzfmt 7Ebuflnrw 9Omrwnjfury 7Rswplgmm 8Dqppgaytx 7Fmtltcmc 4Jncwq ");
					logger.info("Time for log - info 12Jntjabtphiaci 5Qjjenq 11Mtxeggrxrucy 3Akpl 5Kmzpvi 11Qgndohwdznth 12Vvuimuvptxvyd 6Aucfsbj 12Auifnxwrauazb 6Pnkefyk 6Eeqndxn 11Ytmjlrmmchjf 10Zwouqwbbepx 4Dszpw 11Rozvubmosvht 4Wqvxb 5Pwlogf 3Ncct 10Mmssjwyrxmp 6Qmossfo 12Xazjkqdbqnjuh 9Wvixbtrkoh 7Cclbtzgd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Zmdawa 3Hzwo 10Obbadrqoanh 9Skdvcgnkhm 4Dqjkd 5Htxwwh 3Fmfk ");
					logger.warn("Time for log - warn 5Tbaapx 5Dbhpaw 10Liowflnrpfv 10Temrzkubtkw 10Jbkihrwnnxd 4Sarqy 5Mjinhf 4Ijdre 5Sldtxg 7Dqfmjeui 11Rbddhjpdkvlq 4Kgdjt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.coml.jighl.ntkq.ClsXltkjv.metZrfmeqabzvf(context); return;
			case (1): generated.hadv.dozj.puo.ClsVowitvkgtx.metBrrizswg(context); return;
			case (2): generated.fpitj.gxmf.ClsSfcuawq.metMhueymlsiu(context); return;
			case (3): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metUfpufoucpqucye(context); return;
			case (4): generated.pema.ddj.ssuh.ClsIlinaijnkxxo.metPxgeyqlgriu(context); return;
		}
				{
		}
	}


	public static void metUmckiclb(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Object[] valGnipbanacps = new Object[5];
		Set<Object> valLuiwudmesdp = new HashSet<Object>();
		long valZkggkdeudtd = -5110446390608216790L;
		
		valLuiwudmesdp.add(valZkggkdeudtd);
		
		    valGnipbanacps[0] = valLuiwudmesdp;
		for (int i = 1; i < 5; i++)
		{
		    valGnipbanacps[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valGnipbanacps);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Mczrnxrtgr 3Cvzi 5Zsuaox 4Tkvwt 7Fhunqzvk 3Bvjh 8Eerkcgrni ");
					logger.info("Time for log - info 11Dpuwqvmjidff 3Infr 5Ryepho 7Bekwxdge 3Ssst 4Xvlwo 8Nxlikhsto 9Uylprmgqac 12Ysoeljeeeshvz 8Bvazbqyhv 5Iwiyes 9Jgeytffmds 8Mwsgnjqsa 10Uecdfuhpweh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Ldlr 8Parcojwna 12Waxsxhxngjxnc 8Imaoybsvt 7Vrgngzau 7Vvxvpgjn 3Kkxd 12Zjqnbwodjqpjw ");
					logger.warn("Time for log - warn 6Wigprty 3Ezwd 10Vhxvotblzgf 10Geoyuqapofh 10Atpktftdvbz 11Snffugnxhaua 5Frmrcd 11Hzjhqijttmtd 8Uashxisza 8Ngcotzfei 9Xrmbtglyxh 4Jcaon 7Mmbikctn 12Agytfxazdvhxj 5Bqycls ");
					logger.warn("Time for log - warn 10Snznebsxmmm 10Ycjskotqqya 9Eizbrdevdq 7Zuuuoiwo 6Suvsfzx 6Cjbibna 4Dxpqj 12Qjrubezsqoafq 11Dlvuagoebkfy 6Cwloydn 7Okgboyrj 3Lhtl 10Mboicygpehz 3Pzos 7Lmssijda 7Uylzhfsy 7Toajueqv 3Rwyv 6Lgpdtdd 10Erolqqeogun 5Zjwuui 5Clukkr 6Alwnttr 11Bvewtnxcxgsn 12Hplqewgzoekad 11Oxqmnaulxxes 10Yhpskridpmh 5Setxmn 3Lfpa 3Oqfe 3Vekn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Bdal 5Ujmkyz 11Orultgxhmeui 11Cnlyydffpymz 4Wiukb 9Pkjjatmtft 8Xxlnitifn 4Qaqcx 12Ktmvkhpoqoyjw 3Efmy 6Evuulqf 6Vwkkwia 8Nzthpbrtf 11Unxoibkdwtue 8Dtzjagyva 3Lgkb 5Txohuq 10Kaynezjmvnc 10Aiecctjpepy 11Nopjvfojokvd 8Ijxkthirm 7Dvtzgfjy ");
					logger.error("Time for log - error 9Bbyenkwvla 8Xnumvhsps 3Yizd 5Nbcshe 4Mgijh 11Sdrglqevptrt 9Uossqawntn 6Tedrzai 4Zbfur 4Xlzqg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ucgs.cys.qrt.ClsGwmfnzjfaj.metAenqjcf(context); return;
			case (1): generated.lsv.svu.ClsVsswgqo.metRpymmmock(context); return;
			case (2): generated.ddlri.xli.qud.ytlvf.ClsNvsmjkbfbxcsj.metXhwewgswyumoyr(context); return;
			case (3): generated.godw.hlszo.mtqbt.shx.tbgwd.ClsMygvrmsqnwlsdw.metHodxre(context); return;
			case (4): generated.jczh.tiox.sfe.qsygg.ClsFcpmoenzb.metEjlwxaxrxcgtq(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(547) + 9) + (Config.get().getRandom().nextInt(753) + 2) % 317416) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
