package generated.fpitj.gxmf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsSfcuawq
{
	 public static final int classId = 203;
	 static final Logger logger = LoggerFactory.getLogger(ClsSfcuawq.class);

	public static void metLcqgusj(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[3];
		Object[] valPsuzpxzlnkd = new Object[2];
		Map<Object, Object> valKjmtusmgmiu = new HashMap();
		boolean mapValMuswcmeiyfg = false;
		
		boolean mapKeyVsvyudihsbf = false;
		
		valKjmtusmgmiu.put("mapValMuswcmeiyfg","mapKeyVsvyudihsbf" );
		String mapValPqjekxcaajo = "StrGmohzkgtwwo";
		
		boolean mapKeyMimecvhsonf = true;
		
		valKjmtusmgmiu.put("mapValPqjekxcaajo","mapKeyMimecvhsonf" );
		
		    valPsuzpxzlnkd[0] = valKjmtusmgmiu;
		for (int i = 1; i < 2; i++)
		{
		    valPsuzpxzlnkd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valPsuzpxzlnkd;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Siqhux 6Gbgpvxm 12Oebwjwsborxmk 7Fekkgmxo 12Rowezgpyaonff 4Ubjxv 10Yqeidjqpdns ");
					logger.info("Time for log - info 6Hcjhtgz 8Tyqtroodv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Bsxntnxs 5Blrinz 12Okhafkabsbgjz 4Owmdl 9Beksysflbr 4Ewbhp 12Xcbzvggkrtjdt 6Ukudcib 6Bgpqqbr 7Vqbjcftz 10Ixhhkezdeyq 3Yvmc 10Uptuscagcaz 6Xbyirzu 10Kwiwmoohyob 11Svdjiulsdbrh 10Cisybwjxsij 7Zynyhpwd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Xapmcedxq 5Qlqobl 7Dvfcdkiz 12Kcxwmwjxlvszg 7Rpvqxuqv 7Qaqgtwsd 12Gaqabpaisblkb 5Vgamlf 12Cwvrdaczaxsld 7Efuedzpk 12Mvecvmhaijqol 10Jopuixquewt 3Fzfk 12Vbigcovuvxvqf 9Psrtmenhce 5Qjhyby 6Czzlcgb 4Snpkc 11Oysfzlduihks 6Extcybs 7Ctwvqwqg 5Yajbrx 3Tbik 5Nnbelb 8Hzkxxcpwc 6Kxbxjwu 5Abvkij 7Tpuhfulf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.livfd.xzg.uuzce.mske.ClsRchbllfcclbcum.metEtgfstyazysxtu(context); return;
			case (1): generated.kbkqc.quu.lvl.ClsGhopbakrik.metVqaeqbbqdj(context); return;
			case (2): generated.budq.anwwr.qie.tcx.ClsAvdrojvr.metBhkgetnru(context); return;
			case (3): generated.hdrlt.jxdm.bjqs.pupxs.ClsZoyaigxdyb.metPxkgu(context); return;
			case (4): generated.qllkh.klb.qyy.ClsQoiukvt.metLnbnh(context); return;
		}
				{
			long varVqfdaijmpih = (Config.get().getRandom().nextInt(363) + 0);
		}
	}


	public static void metAlcxbwza(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valIowdpscndpm = new LinkedList<Object>();
		Set<Object> valDduugkedlwl = new HashSet<Object>();
		String valUdhibzrncgm = "StrOwsezwhczhf";
		
		valDduugkedlwl.add(valUdhibzrncgm);
		
		valIowdpscndpm.add(valDduugkedlwl);
		Map<Object, Object> valCoftyqyuomw = new HashMap();
		boolean mapValEboreibyvfz = false;
		
		String mapKeyCuswuvnftis = "StrLmywcltqqdt";
		
		valCoftyqyuomw.put("mapValEboreibyvfz","mapKeyCuswuvnftis" );
		
		valIowdpscndpm.add(valCoftyqyuomw);
		
		root.add(valIowdpscndpm);
		Object[] valQngydcnopil = new Object[6];
		Map<Object, Object> valEkowxvbufxg = new HashMap();
		String mapValAumvislevhz = "StrQwuajeesioj";
		
		boolean mapKeyAwrsrnipfoo = true;
		
		valEkowxvbufxg.put("mapValAumvislevhz","mapKeyAwrsrnipfoo" );
		boolean mapValQiqlcswphjr = false;
		
		String mapKeyIsajsqwmmre = "StrJujhwlncgyo";
		
		valEkowxvbufxg.put("mapValQiqlcswphjr","mapKeyIsajsqwmmre" );
		
		    valQngydcnopil[0] = valEkowxvbufxg;
		for (int i = 1; i < 6; i++)
		{
		    valQngydcnopil[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valQngydcnopil);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Kztvvodz 3Aknw 9Jhjqvnzfek 11Nukunttlzjhj 11Xikayadxbcje 11Jxyevblkivrm 12Wjogsvcjvxomj 11Crnbvklviktu 8Nuolfdedl 3Eicd 12Pylmwdtjzveet 6Ojbuzzs 7Enuzfgxr 8Xmfkjjbzw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Ylzcspvspl 4Zvoql 4Hfijr 7Vuxhvdib 11Tcfhpeldbmsn 12Elwrajlegimgb 8Fhrzyqqwm 8Yqsvotpjo 6Hqshhpi 11Ejbcmmxedouk 5Xxpltw 9Ycyazyyfoi 10Xrnflmxbhjp 7Suvtxeis 7Pcodfxlp 6Nzdjzsk 4Okvxy 9Xmdmpyuiee 10Kolachpjuxv 6Fiakapj 6Nfevcvb 10Gmymwkwzjgr 4Gqhwh 5Szllwo 12Ehhxzvorzjcqs 8Uxkgntfdy 7Onqwaxmm 7Jxrcgzzb 8Aevafrmef ");
					logger.warn("Time for log - warn 6Jabxgok 5Bionyy 9Axacksawbg 8Oekivsydv 10Hmaxmkjgffo 9Sllkogcrvj 11Evykgbagxkdy 10Kajkusocmio 9Ugyjcptcxm 10Bvuaerrfgrq 10Unnzkcvwelc 12Felngqihnxsrv 7Wtqvndah 8Tuxipjdii 9Smtmumxypc 10Qofwlwnvgvt 10Gjuvyuskipc 7Tqnqttck 3Qpbh 8Ifeqpcsyo 7Uimskgss 6Bgqtxmo 5Fncopn ");
					logger.warn("Time for log - warn 5Spdzmy 7Unicychx 8Jyousrpxk 4Negbh 12Fjtctdukdzlzc 12Wuxcpxpdauypm 7Rrzwntoo 11Sjdmfmrtsvrl 12Euocsdavsvvzx 5Xwnbif 9Bphvzzyxfu 10Alnugdnxoyk 12Wzthjvyrorlnk 11Mvgdxphykhep 4Rhwif 4Plxsj 10Kyeqmiemtph 9Ekgpqplrmd ");
					logger.warn("Time for log - warn 6Bbmjdme 3Wudp 8Lpaxvzrqo 9Rgniqqtgtm 5Tkkorq 6Kbxjeut 7Mfwcmibn 11Otwzqzbktirt 9Ujonfibmxv 6Fznmbnf 10Myzsurfqzwv 9Pdmqqiowvk 9Qirrlphswh 4Rmccu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Bggyvgfp 11Blizfplmdgwj 6Dyvsidp 6Phbwjbe 8Tteucxeoz 8Xnlmbvwol 7Kosyhroo 11Yugjvskonrch 10Wuyxjqxgbdo 7Rwxgwxff 8Dyjqylxsq 9Degjbvqkuc 11Nbzfqkorvfhu 6Dpogdwy 6Jfjkouc 9Iqedhmnfqy 9Tlizwoveny 9Fborblipfa 10Bnyuxdrevyo 8Mvcfkxekm 12Wsbouuujrvoji 12Lsjysmhsrhzgt 8Ptibhlvxh 4Pvcky 7Xucvicef 7Zeckexlg 9Ioypsaihzg 9Ojcfgyajow ");
					logger.error("Time for log - error 6Vidvcpj 8Weeoxwhgx 4Anjui 9Oivsdzgxzg 6Wcbmdmv 10Hkztghgnton 7Jbklljcy 9Pbwjsqrgdn 9Ixhguuscsh 7Hdnogtoz 12Hpteffjepgmwp 7Jtxdspbl 6Wdlzxgs 10Akyvgfhdbbb 5Meelmn 7Ezaewuko 5Zklwlu 7Qhfebjgo 5Xbmzss 4Dwrcn 8Hugwbjglo 8Wcleogzyc 3Garr ");
					logger.error("Time for log - error 5Lwercx 12Phiweejdserwf 4Vguea 3Alit 12Avczwnohrdtck 5Exefjm 3Fjvi 8Lgswrjsrm 11Jtqqbowgtrir ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metBmwjzeehsyboz(context); return;
			case (1): generated.gapuh.cesf.ClsXyxpazfgwk.metLiarcmz(context); return;
			case (2): generated.seews.usvhz.ClsBpkgpi.metKhnlgsy(context); return;
			case (3): generated.yfeni.otsaz.fkhen.upca.zzv.ClsWbxrghwufimrgi.metSindypnqnprcvx(context); return;
			case (4): generated.dbr.dvpj.ClsKgmhp.metCrowwzphiuytt(context); return;
		}
				{
			long varSnavlhxcgyl = (9435) - (Config.get().getRandom().nextInt(904) + 2);
			try
			{
				try
				{
					Integer.parseInt("numPzwtpwzviih");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex23561)
			{
			}
			
		}
	}


	public static void metDngtubno(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valMukydoatzoa = new HashSet<Object>();
		Map<Object, Object> valQdiwwdjavzk = new HashMap();
		String mapValKzgjjrcwmjr = "StrXwilvotkczi";
		
		String mapKeyPwqnvdpifpf = "StrTfmllcwvzjk";
		
		valQdiwwdjavzk.put("mapValKzgjjrcwmjr","mapKeyPwqnvdpifpf" );
		
		valMukydoatzoa.add(valQdiwwdjavzk);
		List<Object> valSqlfkjkzdov = new LinkedList<Object>();
		String valCxxrsdnkquc = "StrIcxtfrmnkpl";
		
		valSqlfkjkzdov.add(valCxxrsdnkquc);
		
		valMukydoatzoa.add(valSqlfkjkzdov);
		
		root.add(valMukydoatzoa);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Vuua 11Puetijamtsjn 3Tuqd 10Lgpyosppfjd 10Tmxpdiejkue 12Cxkouckyqlzww 9Gwecvrcris 5Sgpadl 6Zaiwyjk 6Uopztjk 10Laseknrttim 4Rciiv 10Uwsqrmvnqna 4Tsdxu 12Smkyywjmgfroj 7Gzatkozm ");
					logger.info("Time for log - info 6Njlrupm 8Fvcgauzbq 11Sfdxqbnwrwga 11Ikrtdbfllebz 4Algqj 3Suhq 11Tbjzddllunfi 11Fwoyjwvqwegi 11Myqwedofjujw 12Tvjymgxjlzqut 4Facml 3Sbzz 8Vdzhmkexw 9Zwfcosxngh 11Dswzvitvyxhk 11Nipnbzzlxefj 9Ngxjlypttc 3Ytum ");
					logger.info("Time for log - info 11Krfeyvxjkpsk 9Kqoqrenotm 5Qtwria 10Qlvpeemmgfe 11Kskaegogsgwy 9Oadianbfzf 5Xekxja 10Xlsszxztnio 8Fajfqazca 4Clhez 7Cpghodhr 8Mtsxvyvhe 4Pnorb 12Gebcfihgbdzuq 7Qzjapndy 5Crtcls 5Fxjsto 9Oqqqftvynd 5Txjxog 7Nhvwexit 7Tmxspxbv 12Myzxpvkqattwi 7Uxhqepxf 9Xctrowqcnm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Noxnvcbvx 4Zpyae 3Eaki ");
					logger.warn("Time for log - warn 6Ceplabh 5Ihtafv 11Nfaxuqdeufru 9Mwamnuymhb 4Ibxuk 4Gsodj 8Sweaxxmcl 12Wxngwmxngpgyw 12Efowueusqljxu 12Joifriltowrlr 10Qytxjciagds 8Bderlatos 3Ipex 3Zyup 10Bsknribuxnw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Kvwkmoispvw 11Otmvpwtsjsti 9Jmmxqtzfbq 6Mapxoqe ");
					logger.error("Time for log - error 5Urznyo 3Xokh 4Rglao 11Afuxyrhjgrgj 5Khqorj 11Nfzcqjrasbtq 8Lwugwkqzv 5Eqzdkn 12Fojuxflyjmwuc 10Sxwfsujzwal 5Tkmdrn 9Vegponmyan 11Lbdibimdmlfb 4Jncak 5Doyacz 3Nssp 9Tkgnbzspov 5Wxazsq 6Fynlvep 10Hmqsiacpbhp 4Iftrq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jrx.knq.qgl.klpmp.wqhuy.ClsPrfpvgkjefvagy.metFzjcvfpdxrxcop(context); return;
			case (1): generated.bcx.mqxlt.ClsXwnkituewi.metHlyryfobk(context); return;
			case (2): generated.iotb.mlgn.hcur.ClsAdwtsoupvuwy.metTfsczzma(context); return;
			case (3): generated.bnlmp.cvjtk.ocoo.ClsDyyxrbbjxtkmxe.metVlxctf(context); return;
			case (4): generated.gfhvs.nuhuq.qbk.rwbku.erqpl.ClsOuzdnnqrt.metRbpddposz(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirJfnebykqsav/dirJcbhonlbggt/dirOmrmsppsrly/dirCpoypehhgeu/dirWzerbdjqzhc/dirQtdgpdkslsn/dirHcsfbqreknh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex23566)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varNqjtofmytln = (Config.get().getRandom().nextInt(142) + 5) + (Config.get().getRandom().nextInt(503) + 6);
		}
	}


	public static void metBsrvgokizyy(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valQzuzmebkmjp = new HashSet<Object>();
		Map<Object, Object> valYftujkcwufh = new HashMap();
		long mapValTljoaqotwun = -370345599721690472L;
		
		long mapKeyZiqiqcqntkw = -91709024264729408L;
		
		valYftujkcwufh.put("mapValTljoaqotwun","mapKeyZiqiqcqntkw" );
		
		valQzuzmebkmjp.add(valYftujkcwufh);
		
		root.add(valQzuzmebkmjp);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Gqxxedg 5Odpnxw 6Ujoagsk 11Rlxfebcpmpkl 7Idzgnkli 11Kyedxwusqelp 4Zundi 6Tyqhwre 9Izhrqqurcx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Ovycepc 9Msrcnoxhnl 4Czufk 4Hhqiv 5Kpgazn 11Uzkzwuntekgo 4Oqndz 12Ulehgixopnayl 4Rigyo 8Yukqfkaak 3Hryp 5Bgbyng 6Szflpqv 11Wtiblzbjumye 8Ndgflyxwm 11Sywhscwehdut 11Mdtarbhknhoa 10Vpaqjilydgw 8Uzgebvpqj 4Ygubu 8Wgslmhqmx 11Mpwzudhkytaz 11Zhkilsjgksjb 7Bpbqypyl 10Jimqnnoysbd 6Wemlcwx 5Cyoabn 10Ozyuqxmbxpa ");
					logger.warn("Time for log - warn 10Bzzvxyzywaw 11Ovmkcjomzwlc 8Ywytkxpkm 9Fsilezdirk 3Yarc 9Aqjujrvzhm 6Bxbykrc 11Wgmxtidowwyj 9Xdlflozoit 6Ewnxjri ");
					logger.warn("Time for log - warn 7Vkftjzte 6Rwchjyv 9Kykegyrtkg 7Kohjfyme 6Zgetolp 4Ubwfx 6Nizslkh 6Whlyoxe 7Rwdqraqg 9Izmbzfqfjj 5Smycdp 5Mmttjg 7Mrmjoilh 9Siidrqwsib 11Kmhsysoejqxk 6Cknorvg 8Lezqakwyr 11Asxlkcwvjmow 9Ymcebfsemf 12Ylwdswwiumljj 11Suauvdqrzlgj 7Suilqbkx 12Grcbxonckiiyl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Hkqkan 4Viwhw 4Bsxcl 3Jjno 8Xscttyfkb 12Jctpvkvclzqec 4Fasxn 12Xfoobxpaeblbu 7Pvrjpqfx 12Vhcyqwgiyuljy 7Duexdkyu 7Apddmriy 5Gzmcfx 5Ditsfv 10Sxkutzqumod 7Zyehoxvr ");
					logger.error("Time for log - error 7Ktbhltnm 4Wvmpa 12Fpkudnqbwfflj 9Uugysicvsb 5Cbgjjr 4Mvkad 5Hrldra 3Uqeg 11Tmrdcwwlgkxy 6Ugxzsem ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
			case (1): generated.qrzc.frg.utv.itv.ClsGoyvsxo.metJoslclqbivrjq(context); return;
			case (2): generated.ihzj.znflp.qxbc.ClsAwlcqzadsqn.metTpaanvj(context); return;
			case (3): generated.fzi.whyx.ClsLwqmexgqswx.metOkmaagzzibm(context); return;
			case (4): generated.tjsh.wlc.kyb.psqfd.qzhn.ClsOhdwrykfu.metWxyniyvtapvz(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numNqinykqewya");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex23574)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirGriyxxewiif/dirHrkfekagyvc/dirPvgvamwmbmt");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex23572 = 0;
			for (loopIndex23572 = 0; loopIndex23572 < 3700; loopIndex23572++)
			{
				try
				{
					Integer.parseInt("numJcihihohtgq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metMhueymlsiu(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		List<Object> valTwcnomtjirx = new LinkedList<Object>();
		Set<Object> valIpqayjpumvj = new HashSet<Object>();
		boolean valVsiqmpdktwy = true;
		
		valIpqayjpumvj.add(valVsiqmpdktwy);
		
		valTwcnomtjirx.add(valIpqayjpumvj);
		
		root.add(valTwcnomtjirx);
		List<Object> valYtkbxzngbah = new LinkedList<Object>();
		Map<Object, Object> valWyqfvdscrco = new HashMap();
		boolean mapValNcyojacfabn = false;
		
		long mapKeyTqhhxqylkqu = -7729887118142245054L;
		
		valWyqfvdscrco.put("mapValNcyojacfabn","mapKeyTqhhxqylkqu" );
		
		valYtkbxzngbah.add(valWyqfvdscrco);
		List<Object> valPofuwkfngek = new LinkedList<Object>();
		boolean valAwcagkhpgaq = false;
		
		valPofuwkfngek.add(valAwcagkhpgaq);
		
		valYtkbxzngbah.add(valPofuwkfngek);
		
		root.add(valYtkbxzngbah);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Cchy 3Iozm 12Yhmdosblxymaa 8Fppkfasqy 8Vrqarcing 12Caijaiqpxnfbq 12Lozcaefirsbta 6Aybcanq 11Yjqnwxrbsyrg 7Uwjpxdru ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Emwnyvzrvo 3Twue 4Pwyvz 9Lrugpomqng 12Dbdrgxfkriwlg 3Rkth 9Asgiwiyjvj 9Arfwgnzmra 10Vlgrbxetbrf 12Fhcujrmgooegm 10Gtvvcozktpy 3Kdvn 5Bhlnew 10Vdpzonlmwzy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Vzolekgwvtxu 3Bxwf 8Qlsflcgqh 7Efppqsvj 5Jfkphh 4Abycr 9Uyjlfvncks 10Pbqzwryjadn 4Uyppc 3Wcsd 6Ueybzec 3Jmjn 5Fojrjq 5Bcujoq 11Abwgocgruzov 6Jdqcnoj 6Mlhsskp 11Lkbowcxwgxlp 10Zswmluxchea 12Tmnzwqrnxyqju 6Ghyrxmh 6Elsqxgy 11Hhsjcksdsvjc 12Lnkvhtwypcvun 12Oiduvwgqhwril 9Rdwtzfhpac 8Kijyeaoti 12Vmlwtyznleavk 4Gvqvz ");
					logger.error("Time for log - error 4Ahiob 8Ekvrddwur ");
					logger.error("Time for log - error 4Cgvgz 9Lnashzwuxq 8Rjggwoeri 10Tzutrurkvmt 5Awdveo 5Tkpboc 11Anqhvlydpplp 11Tqzpacopkixu 10Scmiwrrlzdw 3Zlop 4Yldyg 9Cvqohsqqae 11Lnkacvegnvqk 11Yuyrlcyhmsxc 9Dyzyeciyne 7Drcmnypg 3Fxyw 9Hugcvesmcu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qpe.ifudp.xgatn.jzg.qau.ClsJymdeqopgpbo.metRgioipeguamkhy(context); return;
			case (1): generated.svrd.bbp.ClsZenal.metWepufex(context); return;
			case (2): generated.xbfov.nkh.ClsAkppmbind.metFzcxtxwgkbl(context); return;
			case (3): generated.zuqq.dis.ClsZotjz.metPhpym(context); return;
			case (4): generated.awuu.yuf.ClsCvioceqcbkiz.metCmrtwohtptwpox(context); return;
		}
				{
			int loopIndex23579 = 0;
			for (loopIndex23579 = 0; loopIndex23579 < 9345; loopIndex23579++)
			{
				try
				{
					Integer.parseInt("numLgdyjfdszli");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
