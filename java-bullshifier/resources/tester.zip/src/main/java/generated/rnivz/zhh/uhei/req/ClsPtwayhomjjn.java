package generated.rnivz.zhh.uhei.req;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsPtwayhomjjn
{
	 public static final int classId = 63;
	 static final Logger logger = LoggerFactory.getLogger(ClsPtwayhomjjn.class);

	public static void metIvavionsx(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[5];
		List<Object> valPpzpbfxywaz = new LinkedList<Object>();
		Object[] valPxksxfmhhro = new Object[2];
		boolean valMntctlxqrie = false;
		
		    valPxksxfmhhro[0] = valMntctlxqrie;
		for (int i = 1; i < 2; i++)
		{
		    valPxksxfmhhro[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valPpzpbfxywaz.add(valPxksxfmhhro);
		Map<Object, Object> valBxcbhwbcbar = new HashMap();
		long mapValEbcdjoofhii = -7546590084779300171L;
		
		String mapKeyBfhynmaymry = "StrAjyzswwesnh";
		
		valBxcbhwbcbar.put("mapValEbcdjoofhii","mapKeyBfhynmaymry" );
		
		valPpzpbfxywaz.add(valBxcbhwbcbar);
		
		    root[0] = valPpzpbfxywaz;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Sawnw 5Yhhdoy 7Jhndujgi 4Ogkei 8Ecrcwfxyw 11Bduabtrnlzko 10Cpwybmtivmj 7Eqrssgnf 10Jrvdhibauvh 3Aiuj 7Lygavmyo 7Frublghw 7Qegezdov 8Nbujiathv 4Qysfg 8Hzhyveqve 11Vepqpgwktdxw 3Ndto 11Mcykbblplwrx 7Qddvrlro 7Yzyitcom 3Zafh 5Kdxgqj 12Zvbfzegdrkdtq ");
					logger.info("Time for log - info 9Nvtthzmwvn 4Epwgn 11Qkxyimznrjmg 12Bexbmhcvvmzzl 6Ooyrahd 12Fuamzlporswaa 8Nahtjrtxd 11Vwrezfojonrg 9Tavsimohyj 12Kxakuycbxfifi 5Uzzlwe 6Rmznxyz 12Ztbfttucnmtyl 9Qetjejhjxm 11Mlshkwgblyju 4Pixbg 11Wzmaancghrtg 3Qoki 12Nvuygigodqbjm 11Cfybkmpsttnk ");
					logger.info("Time for log - info 11Veuwlkkmyntt 8Smtuvlohq 5Kpsgmq 4Hfvre 5Yigqzv 8Makjfkvpc 4Zvixy 10Ozmdgjhqgzh 11Wkptyuykmpgs ");
					logger.info("Time for log - info 9Qddmgjqcur 12Eguvyzpfmuzvu 8Itklsykvt 5Sssqqa 8Lkhthbgmm 9Hednmtqpgb 12Mzlcmktanpqnl 9Cthllqpdsw 10Hvhkiigltld 11Bjaeyegpqrsz 9Uzlgmxfaii 6Typimtb 8Gbomfsccm 5Lykaiw ");
					logger.info("Time for log - info 3Wimj 12Dqsmyqszshjwq 4Fdykk 3Tpnp 10Mlxnkcwpjzu 12Pdtliilxzsejk ");
					logger.info("Time for log - info 6Gitbrvf 12Uunchushquvma 7Jwuluuqo 5Evhkys 9Tdmnuacbfi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Yifbpwyadq 5Ecmruf 11Eehjysnwnanj 8Etchaeoik 5Xgzosk 7Wvvqcxgj 10Lbhugodhhag 10Xfjhshjsved 8Mtwblamoy 8Nbhqnabuh 12Vmnwpjzqonkem 4Kiapo 8Xwncmizjx 3Pjdr 12Opqvafqatwanp 11Cevodxbppkne 4Pjfiw ");
					logger.warn("Time for log - warn 12Jnwztzqjxrxjo 8Fntjidfsu 11Wppliqkvorew 9Bjfttboroz 8Gllcfjhme 3Hilv 7Lfrrvshk ");
					logger.warn("Time for log - warn 8Wuajnqahb 9Eljwaeozuv 10Fibxgwljvoj 12Yoxldpprklsar ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Buyqef 11Vrvholuzcsxw 10Tyfvnunstex 9Nwdwpgbwfh 12Ctdqauvgxsssg 6Argrcmq 12Fuutlqzfvrhca 11Qrpayqidiyrp 3Bxhs 7Xnutkpik 3Aaph 6Hahxfpg 10Fwnqhkxshna 11Ppdlxzlngawf 10Semlkoatkva 10Wjwtacdalrm 5Zyuwnw 10Zwrcpplyikd 8Xjndumxyg 4Iafpr 3Rqcl 10Ftnxejutyqn 8Sszxiudel 11Cfdpgwcowans ");
					logger.error("Time for log - error 6Bqiuzko 7Xtqujclh 7Cgwnmexu 11Mtsfykueecwa 3Rojy 12Ldojfendqhirz 4Xsfgq 3Cwvz 7Pmifvndj 5Kcdpqe 3Qxev 4Njltg 8Xskfvwkmu 7Xcbzyeux 3Lzns 3Okun 11Hhffjtbzhhpg 9Iftewnduxr 3Psqh 12Uehwiqfgsqdah 9Xdszavhikj 4Mehhd ");
					logger.error("Time for log - error 8Lohilbnbu 3Afnl 7Hsljnxxw 5Jrgyxc 9Ltqscudcca 3Qylc 12Zmwmlthtsvlan 10Csszeanedpz 7Gqbeaewj 9Gxhlitdxuz 9Upqyuqyazc 7Ovtbktvq 9Ecijbvluwj 11Krjzmrgkcpad 8Lilyhiasa 10Grhooqvfzyf 12Oufyeoyqumrqy ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zfo.wctt.rjxf.wjfcy.ClsKuhcjj.metRopywvqfbispip(context); return;
			case (1): generated.fzi.whyx.ClsLwqmexgqswx.metFhjktel(context); return;
			case (2): generated.hgr.jgeh.ast.ClsBwtgykt.metGnslwfxjnxwudj(context); return;
			case (3): generated.lgws.kxkr.zse.myye.ClsAnryfbudqi.metIqhcyelitowr(context); return;
			case (4): generated.xpyaq.paxhs.ClsBkhbodffo.metDqshp(context); return;
		}
				{
			int loopIndex21127 = 0;
			for (loopIndex21127 = 0; loopIndex21127 < 802; loopIndex21127++)
			{
				java.io.File file = new java.io.File("/dirGtykwzbguxr/dirUbsrjqcvvno");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varIknhjtuykjp = (5153) * (Config.get().getRandom().nextInt(449) + 5);
			long whileIndex21129 = 0;
			
			while (whileIndex21129-- > 0)
			{
				try
				{
					Integer.parseInt("numJrbavbwcwdc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
