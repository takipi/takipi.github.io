package generated.wkucr.ukst.umm.xsqx;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsEjxfeypurpufwd
{
	 public static final int classId = 32;
	 static final Logger logger = LoggerFactory.getLogger(ClsEjxfeypurpufwd.class);

	public static void metWmlpl(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valMsikejlodhm = new LinkedList<Object>();
		Map<Object, Object> valStgwuehxshp = new HashMap();
		int mapValCxcqaseytae = 697;
		
		long mapKeyYybhjwtmvnx = 186872428252893399L;
		
		valStgwuehxshp.put("mapValCxcqaseytae","mapKeyYybhjwtmvnx" );
		
		valMsikejlodhm.add(valStgwuehxshp);
		Object[] valMsinkctqpob = new Object[3];
		String valCketshgznjo = "StrUpefiwpmmix";
		
		    valMsinkctqpob[0] = valCketshgznjo;
		for (int i = 1; i < 3; i++)
		{
		    valMsinkctqpob[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valMsikejlodhm.add(valMsinkctqpob);
		
		root.add(valMsikejlodhm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Opddylxtd 9Txokpnseaz 3Yhok 7Hdhdtfjg 4Liiym 9Fitdstarej 11Itajykvxjoxv 6Uuhlgaw 10Wqfpfdyuckp 3Uzrm 10Zkhqfrqvhbx 8Yzltrxdwx 7Zedcxdlm 7Qbzwepwy 3Znjs 10Zhisgscwkip 5Hqqhdc 11Vboxhwpzmdme 3Hcug 3Wxio 11Pmafyzwylfyl 10Auykepdmoyj 4Waonn 4Xcupl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Xfjxjexznldq 6Hrkcsiv 8Ljuvwcled 6Xvqxfef 11Gtmhcteiglsa 3Wrzc 12Uhokinfdfkxop 7Xdufdtcy 12Euyiyshuqysvx 3Safg 3Idsu 3Pijb 8Rfbsdwbmx 5Towaym 6Tgjnthk 7Bbagvfww 11Gyqouegobynk 7Bqoflqxd 9Fhvgkemrgl 5Uqmddm 9Zyggmrwojp 8Jwfdeapew 11Arhmwthyokdn ");
					logger.warn("Time for log - warn 6Vqqxjhj 5Deedii 10Yqmsrkhnxbd 9Obtzjusyah 5Aiznmi 8Tnopvyeej 3Hydf 7Twluetlw 12Xpcnidvvbsxod 6Hgawram 11Wkpapzaqyofm 4Epzfn 5Dpsuqn 11Zgppyavcsfyo 8Bshntpjja 3Hmuk 3Gwxn 4Zsyij 11Jujuqyllcooj 12Nmxpgtckrbyns 12Uujrgdqthkpze 7Yplemkxv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Qitmgmarcukah 10Rxbusryjblt 5Txpsjc 7Swkkafcj 8Hakrklbsf 12Itvlksrnqwwuo 6Qhkdjii 5Onolyp 7Pfhabdse 8Tmdjmksub 6Mykeaxo 3Dftq 3Ipzj 12Bzbckqabhgmmw 10Ndqzubdfxuv 8Rzgidhvrk 3Zbgk 4Lkfrz 7Cxgzlcqs 8Bjemzbrnt 4Optap 3Agte 10Fzsnelmokeu 12Ksxhvpcjgnsrk 6Kcmywoo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xluq.wys.lexvj.ClsEsonclfnnvbg.metKsdklzxlnfg(context); return;
			case (1): generated.gar.mdz.moh.znab.ymyxm.ClsZduvwawzb.metIltzdkawhx(context); return;
			case (2): generated.cfolx.abg.ClsZqloaugvusc.metOemdylmefcn(context); return;
			case (3): generated.gfhvs.nuhuq.qbk.rwbku.erqpl.ClsOuzdnnqrt.metYemauozpyth(context); return;
			case (4): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
		}
				{
			long whileIndex2569 = 0;
			
			while (whileIndex2569-- > 0)
			{
				java.io.File file = new java.io.File("/dirJnanobydzvv/dirJacvvrfikyc/dirHzwvqgfkkoh/dirEcsifenyqbp/dirJnvkwiegcdc/dirOzfbiufuavr/dirThgiywlshem/dirSqjyzhdsniq/dirMfaukbtvtxs");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metOatblxssahe(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValWiqjrdizoly = new LinkedList<Object>();
		Object[] valTfuhsysoppj = new Object[5];
		boolean valGebcubdeqlp = false;
		
		    valTfuhsysoppj[0] = valGebcubdeqlp;
		for (int i = 1; i < 5; i++)
		{
		    valTfuhsysoppj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValWiqjrdizoly.add(valTfuhsysoppj);
		
		Object[] mapKeyJiukirqbgls = new Object[3];
		Object[] valYmwtisnzvbp = new Object[5];
		int valBavdykzpaby = 582;
		
		    valYmwtisnzvbp[0] = valBavdykzpaby;
		for (int i = 1; i < 5; i++)
		{
		    valYmwtisnzvbp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyJiukirqbgls[0] = valYmwtisnzvbp;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyJiukirqbgls[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValWiqjrdizoly","mapKeyJiukirqbgls" );
		Map<Object, Object> mapValBlisbpzlnrw = new HashMap();
		List<Object> mapValOawvpgjglux = new LinkedList<Object>();
		long valJheyqbhxkaq = -8445377263964389603L;
		
		mapValOawvpgjglux.add(valJheyqbhxkaq);
		
		Map<Object, Object> mapKeySmlqdhesxka = new HashMap();
		long mapValAwnnngixdid = -2198255948269727217L;
		
		String mapKeyCiokcmwccfa = "StrNeyzifwpwlp";
		
		mapKeySmlqdhesxka.put("mapValAwnnngixdid","mapKeyCiokcmwccfa" );
		
		mapValBlisbpzlnrw.put("mapValOawvpgjglux","mapKeySmlqdhesxka" );
		Set<Object> mapValDehfwwoktvm = new HashSet<Object>();
		long valGbkbkekwrsx = -6660247817196912420L;
		
		mapValDehfwwoktvm.add(valGbkbkekwrsx);
		
		Map<Object, Object> mapKeyTdryfhibpmv = new HashMap();
		int mapValXutufejtcgx = 64;
		
		String mapKeyHvyfvjgarti = "StrLwlyddngedk";
		
		mapKeyTdryfhibpmv.put("mapValXutufejtcgx","mapKeyHvyfvjgarti" );
		boolean mapValUlpkvxwblfb = false;
		
		boolean mapKeyXxbsvwosxtc = false;
		
		mapKeyTdryfhibpmv.put("mapValUlpkvxwblfb","mapKeyXxbsvwosxtc" );
		
		mapValBlisbpzlnrw.put("mapValDehfwwoktvm","mapKeyTdryfhibpmv" );
		
		Object[] mapKeyPnshdloomev = new Object[11];
		List<Object> valZzrhbwfmzoe = new LinkedList<Object>();
		String valRqnajlzgwns = "StrQoxyhyaqvbi";
		
		valZzrhbwfmzoe.add(valRqnajlzgwns);
		String valJbzqfnijotg = "StrBzhrhqwfogu";
		
		valZzrhbwfmzoe.add(valJbzqfnijotg);
		
		    mapKeyPnshdloomev[0] = valZzrhbwfmzoe;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyPnshdloomev[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValBlisbpzlnrw","mapKeyPnshdloomev" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Urbnrot 7Rclekmhq 5Iouypu 8Zijszndau 4Fxxpq 4Puvir 9Awogkmsbxe 11Nxaeglfcrahl 12Lbxoeotwjzsva 6Wdtjyrd 11Wihmxxykonuu 3Cbhq 3Qmsf 5Chfvsv 4Yiqbr 6Xrswgow 9Cdajrnnmlv 9Pmfphnpdei 9Irhpjcdafa ");
					logger.warn("Time for log - warn 11Gwnfjfolrpfx 3Iqek 7Aqqwrcoy 6Beltqxo 7Bhrhgtdh 3Ucfl 6Byouqgn 4Nmxea 6Wymorof 4Xnkmd ");
					logger.warn("Time for log - warn 6Ryfhzyq 5Eekjss 9Nwxhvlfdpn 7Xikzntnf 3Rfkt 3Oskv 9Ijixwsacin 11Szjajlopltzs 5Mptolf 3Rlbh 5Osvuzf 3Rhtn 7Xoqyaqhe 7Evnhyueu 5Pdigew 12Pshfmiiqjbrzc 12Ugerzepjdhfna 6Rlrkflw 12Tyoizfabbjsuz 12Qdvwlkenulegp 3Nbjj 4Bafrd 10Jfvgcmipyse 10Baiafocotht 7Cokwizhn 4Hgelg 3Eyxx 8Ahxxcotso 12Nppdprfcatgna 5Irfsxf 4Bgogr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Owgi 10Kosyybppvjc 5Gsgoni 10Driaijgosmi 12Zgmrhidkqeplc 3Lwao 7Svhjdlpg 3Wkxs 12Vxmikfxgrktpz 7Tpnomfvl 12Tjhyrmgigecro 6Amejoom 11Kzmtsznfjyzb ");
					logger.error("Time for log - error 5Lbmzjs 4Pondq 12Onwjwvwhkbtvu 9Kmdgxtvmqt 7Fdfwvrba 5Gkuscs ");
					logger.error("Time for log - error 5Forama 4Sfayn 5Ldrkfr 3Gepu 5Iicgae 3Aano 6Rbuqaqj 10Hjkjsjpqxwq 12Enjqvunfvidog 3Gyui 7Hhxqsmlp 5Vrvmry 9Ezwufgbnos 12Lxuienbycabwx 11Jonhggtreudz 11Trwrgyxtbzqp 12Byyjmxnwdkbbt 12Ahmriymnzlkot 7Hjhiiiqz 3Xynx 8Aqlfjdoct 9Vaghagddop 11Qrpumwbjfxww 6Pjqufzb 4Zmgfo 4Akewo ");
					logger.error("Time for log - error 7Nqpbkidt 10Pwqtmlaxhcj 8Bmvsltqyl 12Luyfmovvzsjdy 9Jrseikhsjx 3Aubo 8Xnfbdppun 7Iabsghll 6Glyzrin 12Vxumujyotqqlg 11Bdbqsdilhmjn 4Vqvlr 3Xmog 7Szfhktqp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xbfov.nkh.ClsAkppmbind.metCoxqxndopdgbb(context); return;
			case (1): generated.njly.vbegw.ClsZmoko.metYqrfdvqsyetp(context); return;
			case (2): generated.lle.fzxn.utis.ClsYhanmsbp.metGdkojhgtko(context); return;
			case (3): generated.gfhvs.nuhuq.qbk.rwbku.erqpl.ClsOuzdnnqrt.metRbpddposz(context); return;
			case (4): generated.qpya.todk.woo.rrzxr.ClsQlmcomguvtqu.metVbgwaaycr(context); return;
		}
				{
			long whileIndex2572 = 0;
			
			while (whileIndex2572-- > 0)
			{
				java.io.File file = new java.io.File("/dirTfiukiewvii/dirSlznoegjmoy/dirRchxcdkcdpo/dirNfgaqeblrbj/dirZzglksiexpy/dirDshkapuijem/dirXfvoapseedo/dirXhuwdyibfhv/dirTwhmitaexqb");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
