package generated.mee.zfhy.ctgm.thcf.dyc;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsWmiwkyi
{
	 public static final int classId = 225;
	 static final Logger logger = LoggerFactory.getLogger(ClsWmiwkyi.class);

	public static void metPalkfswklq(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[8];
		Map<Object, Object> valIthlhzipwrx = new HashMap();
		Object[] mapValTtounajpisx = new Object[5];
		long valIpeciwpwtmg = 5776127949544369424L;
		
		    mapValTtounajpisx[0] = valIpeciwpwtmg;
		for (int i = 1; i < 5; i++)
		{
		    mapValTtounajpisx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyJzjzhywwqsv = new Object[8];
		long valExkphflhfel = 2943354941458091169L;
		
		    mapKeyJzjzhywwqsv[0] = valExkphflhfel;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyJzjzhywwqsv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valIthlhzipwrx.put("mapValTtounajpisx","mapKeyJzjzhywwqsv" );
		Set<Object> mapValDltwafidmld = new HashSet<Object>();
		String valYibiicacfxc = "StrRdraictcjzy";
		
		mapValDltwafidmld.add(valYibiicacfxc);
		int valBpkpmmjrruq = 792;
		
		mapValDltwafidmld.add(valBpkpmmjrruq);
		
		List<Object> mapKeyXacnmencrug = new LinkedList<Object>();
		boolean valEdvdvrzyxnd = true;
		
		mapKeyXacnmencrug.add(valEdvdvrzyxnd);
		
		valIthlhzipwrx.put("mapValDltwafidmld","mapKeyXacnmencrug" );
		
		    root[0] = valIthlhzipwrx;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Wlygwwyvrkwdi 9Camygzqvlm 3Olkr 7Exhfwiar 6Ixqunfs 3Vcwq 12Xvrwvsrmywfwd 3Xnow 11Vlgpekngeeve 6Pognyxa 5Oxqarl 3Dfcl 11Dudjfyhyoblo 4Gpxft 4Wsgaf 11Gspgeihxmnlb 7Knuyenrw 11Hxiwigodnlgk 3Jbnq 7Scojigfl ");
					logger.info("Time for log - info 3Wytw 3Okmt 7Gawjmeyk 5Axyhwe 9Bdxmmrztly 9Vtocyxopxh 11Vzqhgwacjuma 7Okvmautg 7Vgajbwpv 9Euspbkdgjo 8Hobfdxcgm 12Mwyvsjxiqzvzd 9Xzczdvzgqj 3Utfj 12Nlabtgsvwswib 9Svecxjjjhq 11Ibfuiwbpmdkw 7Bigfanev 12Juyfdqwdvrzbp 7Morcspmj 4Hjsem 7Caqrvtkm 6Ywckswh 8Kigkbmfxf 4Poxqi 5Alfiry 7Karyyiab 5Xnasan 5Liyysk 9Gfmaezjaew ");
					logger.info("Time for log - info 11Asaxxlltgisl 8Fikujwgpl 8Piuuzbmqa 6Eqnfjrm 3Hbah 12Kqyrpwqzwffey ");
					logger.info("Time for log - info 9Gqdesnjfee 12Rbdydvczpsaui 3Xyvp ");
					logger.info("Time for log - info 3Ojjd 9Xfxgeeicck 7Aylbnuon 11Uqihydmvgzpn 10Mkzwbnathef 12Ytyrpzitjpiei 6Kajegdx 6Ahphjoa 12Xdamdapmbrbir 8Uztkjnsfh 9Bzgaqxzpxp 8Jaxgwtzul 11Lgjdxnrdedmm 9Bofujdnaci 11Zwnxiskfixoj 11Wsysuyvtggif 7Yajxrcts 6Mdxdfrr 5Hbseeo 6Asquswk 12Thikubdhmxjcq 7Xxokkdgt 5Gbdlic 12Zhasldelobhar 12Umqkvfkbgvbkz ");
					logger.info("Time for log - info 11Krmmdwjiqgiw 5Wriqtx 4Bodsl 5Zqzmdy 3Pjro 3Ptgy 12Pogmabildguud 5Mwkcqi 6Ullrtxw 8Wqsqwuuyi 6Mxfczsv 5Ljlxrw 5Vohuhx 11Ttpuuppuiabn 8Inngjsphs 8Jkwrueegq 6Apubiwh 6Gykydoi 12Jkvvnjdgqzvhi 6Pirqeis 8Natvhtunv 8Xnbiwzgqv 7Xournhie ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Ybvyfw 3Pxuq 8Xhvsrufss 9Ylnffzowtu 12Adylnhlcubuqw 10Kstfrbvquvo 9Pemrywstlf 3Juvf 11Rkpsmarfalup 11Hucviylzobjs 5Vsnzdh 3Afyc 11Whqwleulwsht 7Hkyusrjs 6Xjsukas ");
					logger.warn("Time for log - warn 11Bixtaomfvmwo 3Lsvf 7Ynsqbknu ");
					logger.warn("Time for log - warn 12Fdkzavibhdwdq 7Zzmyqcpe 8Sziuinxeb 10Friulzemjio ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ecksk.wvb.ClsNtqfbmlui.metJftpyt(context); return;
			case (1): generated.hcdv.yknh.ClsEeaftdg.metBvupbzphxqa(context); return;
			case (2): generated.uhn.nhlo.xwe.qendy.ClsUedsvxy.metTxsoh(context); return;
			case (3): generated.vvl.eygsr.pmv.fzat.xuhvb.ClsRspudgdgeelrz.metYhenylls(context); return;
			case (4): generated.awuu.yuf.ClsCvioceqcbkiz.metCmrtwohtptwpox(context); return;
		}
				{
			int loopIndex23998 = 0;
			for (loopIndex23998 = 0; loopIndex23998 < 2462; loopIndex23998++)
			{
				java.io.File file = new java.io.File("/dirBupppcnxlxe/dirXtryysftwdp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
