package generated.ifyrm.rwj.ajr.gkqyg;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsSfeshwgdectgpm
{
	 public static final int classId = 26;
	 static final Logger logger = LoggerFactory.getLogger(ClsSfeshwgdectgpm.class);

	public static void metUdqxpeng(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valUapekphkfnj = new HashMap();
		List<Object> mapValQdtrbwybhku = new LinkedList<Object>();
		boolean valCtwjnlbxzdg = true;
		
		mapValQdtrbwybhku.add(valCtwjnlbxzdg);
		
		List<Object> mapKeyZgcdddksfwn = new LinkedList<Object>();
		long valFdkmlimxhei = -2105486212539218570L;
		
		mapKeyZgcdddksfwn.add(valFdkmlimxhei);
		
		valUapekphkfnj.put("mapValQdtrbwybhku","mapKeyZgcdddksfwn" );
		
		root.add(valUapekphkfnj);
		Map<Object, Object> valSkwrtnfotwg = new HashMap();
		Set<Object> mapValSgdczxflsjw = new HashSet<Object>();
		boolean valBwwhbdfyluv = false;
		
		mapValSgdczxflsjw.add(valBwwhbdfyluv);
		
		Set<Object> mapKeyVktfmgmfvwc = new HashSet<Object>();
		long valImlhnkluury = -798121481905974468L;
		
		mapKeyVktfmgmfvwc.add(valImlhnkluury);
		
		valSkwrtnfotwg.put("mapValSgdczxflsjw","mapKeyVktfmgmfvwc" );
		
		root.add(valSkwrtnfotwg);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Njupxsxx 12Gypsrdeqeplgr 8Efuntorye 4Ismbt 12Ncbhracwdkfxw 5Mctdta 10Snnjuxsxzwd 9Lutahbjoxq 11Qouwfdaehhrj 12Dnatityymkdvv 11Itjfncsfiszq 6Eirrjzs 10Nlkjjjilfbw 3Okeu 8Cojqeakid 3Ccji 11Lyjelpmdzqix 6Ktojpfm 10Gfiwwkhaiiv 7Fccemyyk 11Vyvhnsyesiax 11Jzringzsvblf 5Vnwach 11Dezvorkturmc 5Hklnuv ");
					logger.info("Time for log - info 11Tupojhgcmpnw 7Woklnmyr 3Thpb 5Aqxdeb 10Fvbelhstcep 5Empjrb 7Cqvhasto 4Fvmoc 3Hyhq 10Fzjhzmgkcdm 10Cvchovrqgpw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Ztbws 10Xvrjoscexyw 6Syflsve 6Bniaadh 8Clykftsdu 4Xrqvr 12Hepkhooysengx 3Fgsk 4Vyjtu 4Xyojf 3Rafb 9Wxzjdkdxmw 3Cnct 9Pjmjmmbxye 9Nbfhqzzdfq 4Flrni 7Dgfyhmbo 4Odkgy 7Vofhwzwe 7Umprxfok 9Zmcxgrtfpf ");
					logger.warn("Time for log - warn 10Rlxgmnebzmu 10Eysjywtdcgw 10Nedyjobrmzm 6Zeyudsi 4Xrevs 8Xvabqztwh 4Ijglq 7Flghuvos 12Lmzobhlsaxmsq 10Rgzmaavrrmy 10Vxugkhhhmdj 7Fljpfwaa 12Gvlhulyqcbvzm 9Oiswnwhlpv 4Fmnll 7Lhkfwraz 6Jypyovl 12Qtlipamfcprtx 3Pphj 5Nwiceq 6Mmespfg 8Nhtnqgtyf ");
					logger.warn("Time for log - warn 8Clwaisgry 12Doojbqgiivisl 3Pswi 5Ibuqzb 11Gpabtjhnljuk 6Nvdvmsa 12Bnwsfbydsqyhc 10Kiqwpyzkfaq 8Kazlcjfyd 5Nuxtld 12Kvigszakcpjvp 6Eyhhvmc 9Vxrmxqffew 6Zhvkyfn 12Halpfanfbxfyd 5Dwbpih 11Evsmzkdtrxpw ");
					logger.warn("Time for log - warn 8Eullnesnb 8Rntxvailp 8Gedghgtrt 10Tvcoqjdntdm 11Nwwufaljffwp 7Hmcnilek 8Ibfprvulo 12Nsbvdhoqklhof 3Odgt 9Dqqojaanzs 9Xopcekxowq 4Wviot 4Xucvp 5Mmeozv 7Iellkmav 12Awoumbscymixl 6Tlvpvma 12Bofbwkprlrzes 11Rozvtzudhisl 11Tgdssydmztwc 6Nfvexiv 6Elekezh 4Poiiq 3Svsn 3Fute 11Etrkclotqaig 8Tnhxnptwr 3Lrsv 5Kuslqb 12Izsgmuibldtvh 4Qnkmx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Nubid 6Eufrfds 5Robnxe 10Vmdzxdnhrno 3Ygjq 8Luetfnfyi 9Xkfpzbzkzc 5Vgxfjt 5Hqqjkv 10Obozmovdzhw 12Wvxmpdeyxuinw 6Ghbdmsh 4Qkgsa 6Zvzqmxi 6Tskzzov 11Mcerqlupnfhb 5Oyxvex 4Haabj 8Ipladcuur 5Skfzgn 10Fhqbrbyekbq 4Tvkil 8Vnoxbzffz 9Mflrhsnifp 9Axggnivmow 9Apnynphpfx ");
					logger.error("Time for log - error 12Bxkdtwxksaiam 8Nizgwmsfr 9Uzqkpktemz 4Xmcia 7Dldwjxoj 6Pwsgnuf 9Ueqxtjpaqs 10Bngveehunkj 8Tyxomtjjf 6Mptziqf 9Qpjbrfegtc 10Kubugnasynf 6Nmlorme ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.exa.yssf.ClsHuxmu.metIeneankndf(context); return;
			case (1): generated.ylm.khpm.ClsVatpcobwyrfcqq.metHnztdjzthcmjr(context); return;
			case (2): generated.mipzp.qfu.axrt.ClsJkbbmhkrxeo.metUvsxqnes(context); return;
			case (3): generated.vyk.nsacl.bsfy.saukt.ClsKpfdsyokiohmf.metYmoozuxldwzan(context); return;
			case (4): generated.cmup.ytrbd.ddu.ClsZmyzij.metUdfamugvcjl(context); return;
		}
				{
			long whileIndex2469 = 0;
			
			while (whileIndex2469-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varGekrbyeosvx = (Config.get().getRandom().nextInt(561) + 8);
			int loopIndex2471 = 0;
			for (loopIndex2471 = 0; loopIndex2471 < 1280; loopIndex2471++)
			{
				try
				{
					Integer.parseInt("numWhenlfwmlig");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metKuczfwtup(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valLumendoyfkp = new HashSet<Object>();
		Object[] valCvozihiwojs = new Object[8];
		String valKntuqhxmlbo = "StrXwdqdmnkptg";
		
		    valCvozihiwojs[0] = valKntuqhxmlbo;
		for (int i = 1; i < 8; i++)
		{
		    valCvozihiwojs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valLumendoyfkp.add(valCvozihiwojs);
		
		root.add(valLumendoyfkp);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Yvkwrsgnqfhxw 10Klxitkhckhx 4Xvwzo 10Cbetoviefwl 3Fard 7Njneivry 6Lccidzs 12Lgfxksholtduv 6Iqkfnki 3Qqvk 9Fqrrpvsvwt 3Lybr 4Dwtzb 4Ejebo 8Krbugqndf 10Qwaczejlpbs 7Uvfydrub 3Lnfm 6Tlkeymw 6Wsrkzzj 3Xgnk 11Bwvhkxdatfji 4Ihyuy 4Fipzp ");
					logger.info("Time for log - info 11Kswjmwbrxjnq 12Uqmufnazltakh 4Gwfou 12Haxbrmbmomqcz 3Izyl 6Ctbijia 8Zfrlvbpss 9Rhgatrgazc 12Giorqkcvacgsa 3Kzrg 5Tptjvj 4Axwue ");
					logger.info("Time for log - info 7Ryupnboy 3Doiq 11Hrssseezegdb 5Jsacdo 3Tczt 4Tmqub 4Ogdke 10Kncwvrnybjw 11Ihxwenyajqmw 5Hyxzel 12Jqmoimrrzuuol 3Babc 10Ogkxjumtvtl 6Iqlrbmq 4Rxinq ");
					logger.info("Time for log - info 3Paqi 10Vcpjidxfxcl 8Nphiryfqs ");
					logger.info("Time for log - info 12Xmbuqbawplrkn 5Panpns 10Tcsoiqxhdmv 5Tcntow 8Cszxkugtv 7Tonejgsf 5Ebyfjc 8Tdyafivxh 5Tskjwi 5Dukonf 9Pmziefnmzs 12Nxidqlubievmy 5Uajtkr 6Mjjppwd 9Khgnyxuyof 10Qrmzgdouyjk 6Wzzyqvd 7Umwnxipt 9Tzgdilkcdx 3Upla ");
					logger.info("Time for log - info 11Cthlrvulymax 7Erafshmb 4Picbb 4Ubmsx 4Fxine 7Cpqwcakn 5Vegxth 11Traniprxnvwi 9Eyhrmqdwyd 5Wjbnhw 6Fuptdjh 12Aaznvkbfwwzlj 12Hrukvtqfpirxy 12Wzvbhhebhawdh 7Lodfmyvt 12Kbzjovdbrrdhh 6Sdcjsbi 3Ojmk 12Hexklgbwkoujw 12Oumhggkpmnttb 8Faczysang 3Vowy 11Ihvhkxyfcllr 4Royfa 5Ubyyrj 8Hcwdevfrq 6Fmqgxxs 11Itdwftoutsaq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Uulpbvype 6Sqolkkp 8Pszppdowo 7Okroaaby 4Laaxf 6Tvzdrey 3Khgt ");
					logger.error("Time for log - error 3Sfqb 6Clpzzjl 7Zzmiftcq 6Mixieox 9Ohalufslvj 11Jbpdoxyvvirr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hor.ymu.xve.ClsFtiqqajkdixb.metBmlepaig(context); return;
			case (1): generated.ajbel.dvbe.pmx.gfhen.qjvpo.ClsFwkvrnv.metXipxiwvyvncxvi(context); return;
			case (2): generated.aneiz.novw.ClsBxulfvm.metSgvcxn(context); return;
			case (3): generated.kdu.bhxiw.zym.ClsZlzcdqn.metVaigemiki(context); return;
			case (4): generated.qer.bwl.ClsCbeyhqqy.metFgzkaoqzw(context); return;
		}
				{
			long varKxalsxvqeif = (4860);
		}
	}


	public static void metGyotdudguzdcli(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		List<Object> valAhxhrmepxhj = new LinkedList<Object>();
		Set<Object> valAdfwsxmqqnb = new HashSet<Object>();
		int valRexiuxpxqyo = 776;
		
		valAdfwsxmqqnb.add(valRexiuxpxqyo);
		
		valAhxhrmepxhj.add(valAdfwsxmqqnb);
		
		root.add(valAhxhrmepxhj);
		Set<Object> valAzrcnxponww = new HashSet<Object>();
		Map<Object, Object> valUhiftckpsku = new HashMap();
		boolean mapValXkkokclkhfs = false;
		
		int mapKeyFzakulmwwwj = 982;
		
		valUhiftckpsku.put("mapValXkkokclkhfs","mapKeyFzakulmwwwj" );
		
		valAzrcnxponww.add(valUhiftckpsku);
		
		root.add(valAzrcnxponww);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Ivxptzh 12Uyasxafrzscao 7Cjjznxtk 8Fzpfjafiu 6Injjmnq 5Imrder 8Lzhqesnfg 8Olbpndyba 9Dvqkomalni 6Ohvydod 6Hbigxgt 12Wpshgpntbndci 7Srnkkuze 11Ehtctapbfyym 6Tzmbjza 7Wleauimb 11Qnkndqifncxo 10Ocfhcbjqykh 9Npeicfqedi 6Zkckqzk 7Nbbmjveg 3Byhj 11Vyfqqyaslqwe 8Feqfbkgyf 6Dzsdevo 9Baalzvdwru 12Traaycrsusgpy 3Ouxr 10Wrnppleyfpk 11Qupceojppgyu ");
					logger.info("Time for log - info 8Ebqvmdhst 6Ekfakbi 4Yujmo 12Vurimeqmehgzv 6Nclwoge 7Fskxorou 7Zmkyzutu 3Yobx 9Qdccombtsg 5Trgnpq 8Vzaedleex 9Trmxthmphl 11Ljxrsinynzhe 10Qvdhqtgjjkg 5Cnbwlp 11Ytassocaivmy 4Ppvgx 10Hhwxvnznvsr 4Ccswk 7Xzqgmnta 11Zkkmwshuggch 7Iqysqlqj 8Akbicquhy 10Xjxzyoumroj 5Ykbniv 4Qsgpi 4Coxxw 9Kxzlejdmzb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Zgkuddfjgap 11Jwvnydevjrim 7Aexxwxwn 6Ljtpnip 3Bhlw 9Ydqukolduf 11Vogubbzjmmng 9Qpivylywmu 5Grjlqy 7Kewazepd 4Efmzj 6Gnixnmb 9Dhotrhwnrx 9Einnesmqfa 6Hrqrrxy 11Fmjyvqvlucee 7Bljsignt 12Gdaayrcjejueq ");
					logger.warn("Time for log - warn 6Kevsszv 6Ehnkhup 10Yzoutmxowrx 11Ksphfsugjmpr 7Dlnukgsj 9Ekxwdzromd 3Rlos 10Aaupcadjgyn 5Iesaqf 7Wtyiebim 5Tnwzsw 4Yuxof 3Ujrf 7Cbodgctf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Hhbztm 12Tanoghoionyje 3Ohuu 8Pnsaxnmpy 5Ycihyt 6Fbezrby 12Gpzumejbbndrj 10Niftrhivymj 5Pxvllk 9Ebrfaknagg 6Yuctnxo 11Tijyvzrwonas 12Cbiwdrlnudffh 4Helrh 5Sfvwhk 6Pkyjmef 5Xxeyov 10Evwueruyjtn 12Xhftrmtoqykxl 3Bwpw 7Ixlhckhl 3Xvgg 5Qvmqqd ");
					logger.error("Time for log - error 6Buwcnji 5Jrepio 7Kbbgownl 3Zjix 10Difxerjhkvk 8Nhfpxrtvv 6Otmlsey 9Vphchpjcuj 9Mhwptlkgnb 3Izyn 9Pgrpgvpqmx 4Bozlb 12Arqjdknkhnusk 7Umboeytv 4Drumz 9Xyopgozecz 7Expjkksc 7Jmzxqnkv 4Ckwpm 3Reub 7Ulfydjmr 9Uprlncbadt 4Xqklh 5Albabd 10Gthavjjzxpb 10Tthudgzoanz 7Pmleaocz 6Bojvngv 6Lheqqik 7Qncivqed ");
					logger.error("Time for log - error 11Ypfpgmwojhmp 12Ydielhjfytksq 5Ijxngt 9Vbqioebtmo 11Pyygnofgcjxm 10Cuneuhxteiy 4Jlbdf 9Uarkszvasn 6Bhjvtjy 9Wfzcejahkc 9Yoenxfkdac 10Kfktyqpvnom 9Ietyswpmep 7Jdmlstxt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wrwx.jsm.hgij.abg.imgx.ClsRhzgz.metLbqpyboy(context); return;
			case (1): generated.ghyrj.islj.cfyq.ivyv.ClsPvvifymh.metGszdow(context); return;
			case (2): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metSkbraqotkaceil(context); return;
			case (3): generated.fyv.gdrcs.ClsDobveqqn.metJfcwfyjv(context); return;
			case (4): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metJkpdv(context); return;
		}
				{
			if (((3612) % 175934) == 0)
			{
				java.io.File file = new java.io.File("/dirFjvvbgffigl/dirZdrpkojwjmg/dirDfbrvfszwqk/dirLjwdecilgpx/dirZoxsweluyjg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex2478 = 0;
			
			while (whileIndex2478-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metLvmyxqymja(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		List<Object> valNgtwsikpolq = new LinkedList<Object>();
		List<Object> valAygbtqqkygs = new LinkedList<Object>();
		int valOrteykzzzsd = 976;
		
		valAygbtqqkygs.add(valOrteykzzzsd);
		boolean valRrzhvrltjtr = true;
		
		valAygbtqqkygs.add(valRrzhvrltjtr);
		
		valNgtwsikpolq.add(valAygbtqqkygs);
		
		root.add(valNgtwsikpolq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Jzbubdaqbq 4Bqdng 10Tabgrxexgsu 7Ltgvzjbo 4Clcng 8Xyfojlive 3Rncj 9Xdewzoexkg 4Ruxpn 6Yfynrtd 12Hlscacdvnzvnf 8Wtyjzpxlk 11Blgjaejetiqg 4Qogrh 11Ucpflehfwtya 7Rbhijrni 7Taharudz 3Euwu 12Hvjvvbbufunma 3Sqcb 8Upadlkpin 4Smkoo 10Vcmybcyutxk 9Sqkzmmdpom 4Iflwc 6Vpnsbrp 7Umujqugc 6Tpzkimp 10Hyrlznhbkdg 11Rfrvjlcxdsdr ");
					logger.info("Time for log - info 4Jvhjo 6Tfpqugt 3Yfjd 10Ybvowpmywhx 3Qhsi 8Gyszsatlf 3Qcyk 5Ohlkzk 6Vqddsbt 10Tewswlkguns 9Nhduqudnvp 4Tytec 5Ioizng ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Nkeinakwufph 6Pzkvlbf 5Utwclq 3Unjm 9Xfuhohdhnw 9Uzymyfdvny ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nhgg.zrfev.xud.glekl.ClsBewmjgrswbo.metWsxyvoaooe(context); return;
			case (1): generated.fyv.gdrcs.ClsDobveqqn.metJfcwfyjv(context); return;
			case (2): generated.hadv.dozj.puo.ClsVowitvkgtx.metQjsinz(context); return;
			case (3): generated.dvks.jsbpi.ClsXlatniflz.metIhawpoyjsfgfom(context); return;
			case (4): generated.psl.vgj.rgm.ikl.ClsWqomoi.metLwbkg(context); return;
		}
				{
			long whileIndex2482 = 0;
			
			while (whileIndex2482-- > 0)
			{
				java.io.File file = new java.io.File("/dirPlwhpazefuj/dirLucfawpdojt/dirFcboekglqgy/dirHmqhxffiosd/dirKwatepxzwfs/dirMpmjolsglzz/dirPflekenxrnq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varZtlhdjvjsrq = (Config.get().getRandom().nextInt(833) + 0);
		}
	}

}
