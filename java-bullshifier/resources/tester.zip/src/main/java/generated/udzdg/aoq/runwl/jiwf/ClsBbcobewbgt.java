package generated.udzdg.aoq.runwl.jiwf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBbcobewbgt
{
	 public static final int classId = 74;
	 static final Logger logger = LoggerFactory.getLogger(ClsBbcobewbgt.class);

	public static void metFwbdppiwee(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[6];
		Set<Object> valWjrxjdpguoa = new HashSet<Object>();
		Object[] valApaszxqiyww = new Object[5];
		long valBdaovxomieu = 4901055390085941129L;
		
		    valApaszxqiyww[0] = valBdaovxomieu;
		for (int i = 1; i < 5; i++)
		{
		    valApaszxqiyww[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valWjrxjdpguoa.add(valApaszxqiyww);
		Set<Object> valHuvopwvzgju = new HashSet<Object>();
		long valXfnkufzsaad = 3369280666380373179L;
		
		valHuvopwvzgju.add(valXfnkufzsaad);
		
		valWjrxjdpguoa.add(valHuvopwvzgju);
		
		    root[0] = valWjrxjdpguoa;
		for (int i = 1; i < 6; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Hmmbrfafiqf 9Wnntyrpbvf 8Jdrsulsvz 8Ojhqefgpa 7Zfarvwpb 3Ybkb 10Rniepatjtda 7Dxuuiwjj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Fbygtsrstuf 7Xcmczdtt 6Kstueax 12Zauwgqmwgygkh 11Vvpvgznldcvn 10Nlflyxgbqdc 7Xwkjqtgn 7Blbjwddq 3Ntvq 6Ykfzmiq 3Aout 12Ifjygnmtshzvs 8Pdfdypgpm 4Qwbia 7Svtuxumf 7Kafbwfnt 3Bfmt 8Wglrbwvxk 12Xbqpzusqjlvwk 7Irngpsuk 9Hwjzxzwpah 6Oeddcmt 10Fupiwqnmmji 9Lfwmgcxpts 9Diannryyey 11Otvpqijstfjl 7Gymrncya 12Cffhpfhcjpstp 9Ytslupstih 3Kmho 5Rxoibm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Pnzrgtcfcsp 8Fdtpmfhgf 9Ecswyvmirn 10Rgsydctqokx 3Ybwx 12Snuzbqdwfnaap 3Fpoj 7Ccmvkajp 12Leesgfficqvwb 6Dvdewkp 9Msxmwfcqky 7Bddsxczs 3Pqag 10Fhflyaqgktx 5Zjaphb 5Fdbafo 4Zwbhd 3Rixb 5Eyyzwm 6Gnetxsz 9Fdfkodftml 12Xxuplratupsey 6Bncovbo 4Jhqli 4Jnkie 4Fldnh 6Tuxnofc 9Qcxwbtcrnd 8Lomzwpzcu 9Rvivcujtsi 11Rmghliuhntfr ");
					logger.error("Time for log - error 4Giyhq 12Xuxsmmoooyept 5Ilhsgu 12Nxvsgevjyopjz 10Cjpblqlpbdg ");
					logger.error("Time for log - error 5Vagtxd 8Bbmzkccbe 6Fnflqzb 3Cnom 7Ohlgbvzg 7Vpdeedpt 12Pouicqcnfobte 3Vvby 7Zdiglmjm 8Tqqlaavnw 8Kjnmjocwn 10Urpraogunvl 10Hjjasnxhgac 11Kbdoaqjdewoq 8Dbevsvnfm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gww.spuw.jrq.nmv.xowli.ClsKosigq.metKcjzvalu(context); return;
			case (1): generated.kfvy.ymxa.end.hazk.nwqfn.ClsXakhsfoyrlse.metSihzklw(context); return;
			case (2): generated.bolg.tnlb.nmug.ClsHstaiufsowx.metPapexcx(context); return;
			case (3): generated.bnlmp.cvjtk.ocoo.ClsDyyxrbbjxtkmxe.metXclyxjwxnjpi(context); return;
			case (4): generated.uyus.ruq.fow.dvnw.ClsCysblmgtiyuxcr.metRytcxfzpgayhlo(context); return;
		}
				{
			long whileIndex21332 = 0;
			
			while (whileIndex21332-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metIishdsesvhq(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valLmbtxkbyswp = new HashSet<Object>();
		Object[] valVknphpszdzr = new Object[6];
		int valMisatxrgnvo = 669;
		
		    valVknphpszdzr[0] = valMisatxrgnvo;
		for (int i = 1; i < 6; i++)
		{
		    valVknphpszdzr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valLmbtxkbyswp.add(valVknphpszdzr);
		List<Object> valFymvsiwpjtd = new LinkedList<Object>();
		int valOypreatjtlq = 456;
		
		valFymvsiwpjtd.add(valOypreatjtlq);
		
		valLmbtxkbyswp.add(valFymvsiwpjtd);
		
		root.add(valLmbtxkbyswp);
		List<Object> valRdihiidwqoo = new LinkedList<Object>();
		Object[] valGvbrekxigqq = new Object[7];
		String valSlywgceqazf = "StrFndxechapin";
		
		    valGvbrekxigqq[0] = valSlywgceqazf;
		for (int i = 1; i < 7; i++)
		{
		    valGvbrekxigqq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valRdihiidwqoo.add(valGvbrekxigqq);
		
		root.add(valRdihiidwqoo);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Fowesvhx 4Wbsee ");
					logger.warn("Time for log - warn 4Cvxgf 8Mupcsrgrn 6Vmotmob 4Wcgve 10Ylklgnuqigb 10Mdgyzbhoqsw 7Bniskjjc 4Oxezh 11Wdggchbpcqos 11Ovkbdrssofac 7Bhbgvsnu 3Oyzl 7Mbsmuqwl 7Gciaclip 8Vgropkcwn 12Bughadpvhleqk 8Wngbjzxjb 7Sfiicoei 12Bxxvakmrjlyxl 7Tyddfbbu 4Ytotf 7Zxlsypdz 4Zblkd 12Deqtysjcttwcy 7Oenqstxs 11Olthjtoujrwq 9Hzvegsvdnk 4Cagds 10Ozgahhxznqg 7Jdbiyerp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Gwnxa 12Csocrboyezmsk 4Vmyld 6Kfleshw 12Lwnqdyuctpdvl 12Stoegjvckswsw 11Yxbllcdhcsls 4Fzicu 12Hzgbyzezqmbec 5Fltglv 6Cokhirf 11Jdhxnyrvfgnj 3Oirv ");
					logger.error("Time for log - error 12Avfppwdmifetx 3Wogi 12Wxxrxgycfhimr 3Wycv 4Ujltt 8Mhyzbqshw 6Letsjzk 8Uglcqappt 8Tczhzazlh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vqvzb.mlzv.dxgr.ClsUgxxgr.metEqbgkl(context); return;
			case (1): generated.siinn.hrk.mef.ClsDcfbqxc.metIvygazu(context); return;
			case (2): generated.mtq.flhse.ygibh.yfs.ClsSzzuamch.metIuxgxgafdnqnhh(context); return;
			case (3): generated.pxdt.vcuzq.tfk.bjngo.ClsCaopcwu.metNrjzvdamjddqk(context); return;
			case (4): generated.rjuw.mmbua.ClsRawvqxmhewbl.metOsciin(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numQwckhfpmgfj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numTrkknvqzjre");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metVygkbiannogx(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[9];
		Object[] valSvidmjemygw = new Object[8];
		Object[] valOjtcppmiqze = new Object[5];
		long valVblhvyeuewm = -6160588250292118061L;
		
		    valOjtcppmiqze[0] = valVblhvyeuewm;
		for (int i = 1; i < 5; i++)
		{
		    valOjtcppmiqze[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valSvidmjemygw[0] = valOjtcppmiqze;
		for (int i = 1; i < 8; i++)
		{
		    valSvidmjemygw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valSvidmjemygw;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Cluobu 6Tmradpf 6Bwnjgta 8Icnikfjvn 8Zijcprfrb 6Anahnki ");
					logger.info("Time for log - info 9Lobhwliznw 9Whvpnscolj 6Vekyavg 12Oyxftjynviegi 7Myyinsei ");
					logger.info("Time for log - info 5Mbiprw 7Rnyemqxh 5Kzztul 10Hnnslvjqebz 6Lxgaxvw 6Ulkklfg 10Qffcxgexlpa 7Vnpbmfqe 8Bfyngtjrr 4Frwum 8Kymqunyjn 3Hyxz 10Grntdghbdjn 12Cmaoktvbcistb 10Mtrrwpcfyhc 5Zscdej 8Lcylnbczz 11Qntvxjjidurg 10Syvhfznuoil 6Pvixpqc 10Cpcmeobsojh 12Hbalhnlifcdqf 3Xjne 3Ccrg 11Ykfqcptzgvfu 10Lnfcsmeaqai 8Hahvsbodw 12Incwzvsirdcgm 8Olsrgzkql 10Lybbqxhwvnm 8Hvlzjscvf ");
					logger.info("Time for log - info 8Erctwotqe 6Mnmrwmz 9Hswczhywjo 5Ejmlws 5Qavzkw 5Jmmklt 8Cjgleadcp 12Kvgtfnhckydlu 7Oruohsgp 7Bvmzndym 9Deibrklwdn 3Rbcw 9Niecivtdau 12Porabhlyuuopf 6Wotwjvz 12Bsbkmmvvqlqxt 11Ssbsmadaeori 4Gqxml 10Egbapvmakhh 6Uhagxwq 7Ymvomijh 6Pxxzosf 9Pyadimzwrm 4Zrvkt 12Atzpaxsvvzdjr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Wyudckm 8Zadwksjja 11Ylapcyjzhhbn 6Xicadbe 9Nuldvzzogt 6Pdvefof 9Pdotkfeumq 10Jxyocgfwegw 9Rprnmaxhdu 8Ykrjahmhb 12Mkdayrczwdsgn 8Yhbtlhear 7Dflanfoc 11Zjxphcqqlscy 6Bnpjhgo 8Uhzkijqfb 3Bics 3Arxy 6Ehgnuki 12Nlnudzxonhhjh 8Kmgwmfwhx 6Xfnnjgp 12Hppgijxrrdhid 8Fdlftocgi 11Mneuvifebzwo 3Vlei 9Lfpbwthcmi 4Ytkrf 11Bzykihevmzdw 6Plbuqfq ");
					logger.warn("Time for log - warn 9Mokhwnfcmx 11Iyfordpljlgs 6Bgctaay 9Zqnlhzahue 8Ojemhmujy 9Jygceeioro 12Lnhptowhwnvoq 4Caetk 3Hrzp 10Mixsiacjiot 4Vrfxj 6Lsyklct 5Ffslxo 6Tuvmgbe 4Ntbqo 12Hbifpulntntfg 9Munolcdjof 5Hsxour 9Bdxwfznosx 11Miseeljfvwln 10Tjuzapnrqnb 7Crrhruvh 11Ujofpnpvwluc 7Hxfdcpmx 4Dhtaf 3Tmzl 7Rmunstjz ");
					logger.warn("Time for log - warn 11Buyivnrkxrpr 4Izcpc 5Xjkzgm 6Jmilwas 11Mvvwromkjonz 5Avbdiv 3Qzaz 5Utnein 7Nrjywjlu 12Plljzjyihotlf 5Jrwjtk 5Hvgefj 6Jqurkle 6Xjzybpr 10Ofwzoanbfpj 7Asffnoaw 8Vueiwxxgw 6Cstbnog 4Woewr 7Qytyvpzz 8Fjbnsyqpz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Fvjxojml 5Athzcq 9Keeunvhbmo 12Uqwumooyolnks 8Luiekksud 12Abolbqqustnkp 7Rqswptnm 7Zedmikls 10Femvlrguofi 11Ulyqmwsxlyfw 8Jqzptbbqk 5Pujnec 12Dtlraaawjjsbc 7Ebfbkxda 3Mdob 8Gvfsufptl 10Nbxupaxflfk 3Ynrb 4Rpqvf ");
					logger.error("Time for log - error 11Bqjyxeqfdnhm 5Txymqt 3Grdw 11Hbzzewxjuwzg 4Pvzey 5Fdbrav 8Xftnxespo 8Lywxamivq 9Cawgdjdzan 6Ricerod 11Foptrbfvyazm 11Odfqmjntrbek 4Lyrno 10Eugnceiahcl 5Ckbjcs 4Wzuom 9Rpkoaeqhii 10Hllfbtnilxa 4Cstoy 8Fzowmgopk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metUfpufoucpqucye(context); return;
			case (1): generated.zic.glh.ClsJylyrkbuexopc.metXnvzzmoaggxy(context); return;
			case (2): generated.ezh.ugou.ClsQzxtuprrvsc.metPwweyllheinay(context); return;
			case (3): generated.nhgg.zrfev.xud.glekl.ClsBewmjgrswbo.metWsxyvoaooe(context); return;
			case (4): generated.iyxve.emn.dzc.ClsAggygwujkgt.metWmlfsxai(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(733) + 7) - (Config.get().getRandom().nextInt(146) + 2) % 896836) == 0)
			{
				try
				{
					Integer.parseInt("numFafiewobpqb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirJhyntexgjea/dirWaluqzfdenm/dirHmslnqxnsjz/dirMexwwgwzkpq/dirJdyuxvwgtyi/dirEelpkvouqni");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
