package generated.wtc.bgb.gahv.mul.rts;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsUeuxdzs
{
	 public static final int classId = 418;
	 static final Logger logger = LoggerFactory.getLogger(ClsUeuxdzs.class);

	public static void metGmiqxl(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valPdnvcluzkrp = new LinkedList<Object>();
		List<Object> valZofloturwab = new LinkedList<Object>();
		int valHdrtdiqepjp = 560;
		
		valZofloturwab.add(valHdrtdiqepjp);
		
		valPdnvcluzkrp.add(valZofloturwab);
		Set<Object> valIvyfnzmuuel = new HashSet<Object>();
		String valReteukyagqg = "StrGuslnzfwezi";
		
		valIvyfnzmuuel.add(valReteukyagqg);
		boolean valHgpetxkflgi = true;
		
		valIvyfnzmuuel.add(valHgpetxkflgi);
		
		valPdnvcluzkrp.add(valIvyfnzmuuel);
		
		root.add(valPdnvcluzkrp);
		List<Object> valRepbelwixyq = new LinkedList<Object>();
		Object[] valKqgtcxugfce = new Object[7];
		long valLcddxybhfph = 8310434741723493967L;
		
		    valKqgtcxugfce[0] = valLcddxybhfph;
		for (int i = 1; i < 7; i++)
		{
		    valKqgtcxugfce[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valRepbelwixyq.add(valKqgtcxugfce);
		List<Object> valTehhtimlsqx = new LinkedList<Object>();
		int valMpihhquumlp = 756;
		
		valTehhtimlsqx.add(valMpihhquumlp);
		long valHjhphsbcvzj = 6653776583967316892L;
		
		valTehhtimlsqx.add(valHjhphsbcvzj);
		
		valRepbelwixyq.add(valTehhtimlsqx);
		
		root.add(valRepbelwixyq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Sydmc 11Uovljrvfinpn 12Xumenjhlgqitn 7Gcftctrw 9Gcmqzhqojw 3Glpz 4Qhcfm 3Ajrq 5Daintc 10Qarxznfqhjj 6Lzzbrmo 6Wiotrzx 7Clenyhov 12Uuaymwkudfgxo 12Pwvkwsfgegogw 5Jeedgq 6Sovpetf 11Hyfwnpbpllnn 9Gfqdkpmfsv 7Rmhkepfr 12Aiecpmcinydyj 6Bfjlaem 7Jbwwvspx 10Excujwwqrtz 10Crqguhlnvqk 4Hbcnz 12Whqvhawhyjclk 9Vffycwywth 8Dobvlvyyt 12Qksqcjevoromx 6Kgkupyf ");
					logger.info("Time for log - info 11Qqyvqhqgjpyp 3Insc 10Gczgoibblkk 10Rrmftyzmixf 8Etjqgysqp 12Vamjyclwgxlzw 7Gflkljsb 7Ffkglftu 11Jgorsclnbpzb 5Vxfgnq 12Trczevpgmffxa 5Yljewk 12Uozkdrtpvftnh 11Optfdgoovocn 8Hopoojdkt 11Wiytcgxkgmet 7Phkywtzq ");
					logger.info("Time for log - info 11Ychigestixtj 10Vsrioaydwee 6Pnesvpr 9Nuzestorvs 11Aajmycinafst 4Majzn 7Cmrfhuce 9Ktyucncmxr 4Bzvar ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yewpq.dap.itdt.ClsOhnihvc.metYxfsbhns(context); return;
			case (1): generated.erxl.yyilk.mxe.gagu.ClsTrmbyzemtaola.metLaszacoe(context); return;
			case (2): generated.gjcdq.ygxj.ClsOmksrfdawprnyq.metBlrdhncfbkct(context); return;
			case (3): generated.swyg.szfbf.ejprt.ovbj.ClsEqyrgxer.metGhwucfmqcy(context); return;
			case (4): generated.qspb.cjle.nfu.jdnb.hwx.ClsNgqnidoia.metMghoopxp(context); return;
		}
				{
			if (((9204) - (Config.get().getRandom().nextInt(510) + 2) % 935247) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((1038) % 301012) == 0)
			{
				try
				{
					Integer.parseInt("numYxkufhezblr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metWowjsssr(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valXbhhtazeugg = new Object[10];
		Set<Object> valFkqmqvwkkds = new HashSet<Object>();
		boolean valDxpdukcqleg = false;
		
		valFkqmqvwkkds.add(valDxpdukcqleg);
		int valQkqqgkbetch = 317;
		
		valFkqmqvwkkds.add(valQkqqgkbetch);
		
		    valXbhhtazeugg[0] = valFkqmqvwkkds;
		for (int i = 1; i < 10; i++)
		{
		    valXbhhtazeugg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valXbhhtazeugg);
		Object[] valPgtksrxfvnw = new Object[8];
		Set<Object> valRgijjrgrbah = new HashSet<Object>();
		String valVtixwdirhzj = "StrOrhtdmpishz";
		
		valRgijjrgrbah.add(valVtixwdirhzj);
		long valCghrkltsquk = 2231045520924374267L;
		
		valRgijjrgrbah.add(valCghrkltsquk);
		
		    valPgtksrxfvnw[0] = valRgijjrgrbah;
		for (int i = 1; i < 8; i++)
		{
		    valPgtksrxfvnw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valPgtksrxfvnw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Jjdnsirrozgwp 11Eagcveytrlao 8Kcoqrdkas 3Ibqy 10Hjqdojutqwt 6Brkydiv 11Zftexdrnsksr 11Hdhudmzeiquv 9Pdlyfpilgv 3Ltdc 4Crqos 3Oqxj 5Cvtaai 3Atjr 10Pykfzcwntps 11Ktjzorokjksn 7Bptexexh 11Ctwcexoupcrq 11Nrleajzxqkjg ");
					logger.info("Time for log - info 12Dobtdzntrzpki 10Wvfsrvlbvla 12Reyvbyfcbzuut 3Qqsm 4Wxlzy 11Nguuawavsqub ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Jtjxhonywtrgb 11Jsszyjcqbmum 8Xipkctuqm 9Oelvlnqffu 10Ddorjmfrhlw 9Ygagxhhizj 8Uadumosai 3Beln 4Gafcr 8Btuamqpym 3Uxam 10Zffvrkpjchn 9Sdpaucnqsj 10Xechbzofhie 8Hhgwndjyy ");
					logger.warn("Time for log - warn 8Pspcikwnk 8Bxzbwkvoq 4Kgdap 10Jlisjgwbvjo 12Tprffynnrxquy 6Ghyuahd 9Kunyhjxohl 11Dqjcsiplhors 6Ykcbecl 7Fkjjwttj 3Nefk 11Smefsbswaqwb 8Jivdfkcbj 10Lrrqcqtklko 10Zufdriwywas 4Xfngo 11Wkvoldikfcls 8Dzdjjzouf ");
					logger.warn("Time for log - warn 12Ckohtexnlsddh 8Wznzsodfe 3Wirc 10Jmdhdwcqivf 6Rajoney 9Wmhojjlbfl 7Hmludixg 6Spoqnwu 3Mprd 4Saxvd 12Ywyznmqfjoclz 6Luqtkec 11Sshjcxcivmzo 9Ydfxmrllww 7Mxedstid ");
					logger.warn("Time for log - warn 6Rxlbhig 9Aebwijiaon 12Ahrzbjloisaqj 11Vrikcqmtguxx 12Snsehipbkuark 4Oabsi 5Xqwcpm 8Xivanaweo 9Cihhjallql 8Ibcuvhjak 12Giznxrlstxwis 9Jvvylbuyka 7Vhxbozbt 3Pymo 8Gqcggmakb 11Bnbwynerqurl 5Gjdsnd 9Qaaqrmlcai 4Fmdhn 10Wslzlbbbsmb 5Cstknr 5Ppfbtj 5Lgjewa 7Almkvsxt 10Axilctnebcq 7Fdpfhjdc 12Nvdpltxeoiiij 12Bijjckwhvkiyd 9Xjjcumagmr 9Zxkzliuthv 12Wqqecathiyued ");
					logger.warn("Time for log - warn 4Aanjz 6Rvgcujd 3Xxkz 5Xqxgay 4Wpcbw 6Zudvngy 3Bzay 3Qnuu 5Ghdvqq 11Uixvmethhehc 5Ihlnim ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Bxizw 11Uaugadtjvgwi 5Byidzn 7Dsllpvmr 7Dubsqiae 4Oyidj 11Lilamrddaugy 11Imckvqkpjmte 6Gfaaqhj 8Sxkfqigee 11Imhxepgcnhlv 11Afoufrxtmanj 10Ggilrggwarx 11Aneiekhqrmpw 12Hltuqpoaxqbqn 12Mwlnvvbrmutbd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qnzm.livr.ClsPutzsgygioejxl.metMebbiihjouloja(context); return;
			case (1): generated.ongb.lkxvg.dfa.pkoz.kbky.ClsZpuulcqafhvqyy.metSvcpwlc(context); return;
			case (2): generated.bad.yds.jib.otl.ClsBzgol.metJlqnadqe(context); return;
			case (3): generated.cfolx.abg.ClsZqloaugvusc.metOemdylmefcn(context); return;
			case (4): generated.app.atudj.div.xmvbx.csga.ClsIfahtjloa.metYzbiexwszx(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numLchpvvvphdt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numOmdvppzxgkh");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metFlilbjqj(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValNwxxvgibemx = new HashSet<Object>();
		List<Object> valDanserrokxo = new LinkedList<Object>();
		boolean valCuvsgkcjiyz = true;
		
		valDanserrokxo.add(valCuvsgkcjiyz);
		boolean valXdrcvzgnfro = false;
		
		valDanserrokxo.add(valXdrcvzgnfro);
		
		mapValNwxxvgibemx.add(valDanserrokxo);
		Set<Object> valMqangelrvlj = new HashSet<Object>();
		String valYspgvejcvxw = "StrNzoyshycyjv";
		
		valMqangelrvlj.add(valYspgvejcvxw);
		
		mapValNwxxvgibemx.add(valMqangelrvlj);
		
		Set<Object> mapKeyVhixkiitfbs = new HashSet<Object>();
		Object[] valXztgxhicmob = new Object[9];
		int valHobrmqtsqli = 282;
		
		    valXztgxhicmob[0] = valHobrmqtsqli;
		for (int i = 1; i < 9; i++)
		{
		    valXztgxhicmob[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyVhixkiitfbs.add(valXztgxhicmob);
		
		root.put("mapValNwxxvgibemx","mapKeyVhixkiitfbs" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Pemrnvrrmsnqn 9Sapzyffmyd 5Ongkqu 9Caxgrrfump 11Nkmwczewiguo 4Azypf 4Aefwf 3Wchp 7Tlgtfcbc 8Lvoqpmeap 5Yngzsf 5Ngseaw 12Tkfzzecbgywev 8Gsiotavyn 10Vxghbepbbez 3Vlbt 10Ijqoibqcyzc 7Tabesfgq 10Ugnubapwrii 9Ipjdyxeflb 10Mrcgmsztnps 11Pomzgsstqxvz ");
					logger.info("Time for log - info 11Etekgsyfcxzg 3Frvj 4Kqxfn 11Ebeexsjxunxx 7Tfhizkbg 4Ufypy 11Grbmbccqkbah 12Spqfjzbzgsgcp 10Cxqjmqsukhv 12Vqzoxaivxkvsl 4Ysvet 7Tzzsoynf 7Axeklpqd 9Wmodztyktv 8Oyowbtnzz 7Zkxlzhof 7Qxjfikvo 6Neyovqd 10Dqvxrhcftyz 9Vlnkfxvvcc 9Bvnjcjdrso 12Dmapjvswklkrz 8Trbllipjj ");
					logger.info("Time for log - info 4Qwsow 7Oeyygrvh 10Geacekowiiz 11Fbqyjxncvjsx 12Usnasjhldfems 4Zyvhe 5Jqsrvy 8Exevvzcug 9Fhnrzvrpio 6Cvnxeyd 8Uctwqqkir 11Ncslskgyrhxv 11Klfrhzvpdati 7Ojifisys 10Jnqksqsmkxf 3Darv 3Hfcb 7Hhelsstn 3Wenq 6Pppmuca 10Kigektrhfqd 4Ghfwz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Pnkuqzk 12Lnkuxcgcxqjvo 4Mhxdf 3Vsmt 5Pzmugz 4Dqnmj 3Ugmg 11Fthbqkbvrubr 4Hxwil 11Zbzquevbcuiy 4Kvjmq 4Pmcxv 8Hvzkmyeam ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Ypfp 8Bewbtidvw 12Fobupgzhozmgb 4Tuuwd 5Cgajnr 11Sclqznqwbazy 6Krdjqlg 7Celjkchp 3Imwu 8Sswpfznuc 12Ylunaxqtdxone 3Jthz 8Kdyusqgrq 12Sywpjjlgmcdih 7Ealinygz 8Kjldzxagv 8Tsoibfgrk 10Fxtznmfprja 5Ijmqzd 8Wleipybds 10Nattlyrgcpd ");
					logger.error("Time for log - error 4Vxgra 10Cxpgoakxkoj 11Janfjzqfhmma 6Ixcwiry 12Fnpgnwfnfsiok 4Kdjat 5Ltuaml 9Qubebktqjs 8Qdjknvpxy 6Mkolzqs 8Gdcxsvhqz 9Mwdrppisgk 6Xljnhvz 11Pmspwuemslmy 9Ecuvfphofa 5Hftjpt 11Qdcnkmscvcwt 7Jcqdxbvd 11Hggovfavwzer 3Fhhu 11Ktlfqcxlwtlb 12Jbpfflvjbucfv 12Jjmtpvvxacawu 7Ufmapvtt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lraiq.fcmvy.qwp.rkzex.eokht.ClsJupuz.metTywqcdpv(context); return;
			case (1): generated.wvkuf.rvtq.kcgfs.vezg.ClsKfeffw.metPqphlwkdbbctc(context); return;
			case (2): generated.tei.zyt.ClsLkzwcb.metMtlppg(context); return;
			case (3): generated.siinn.hrk.mef.ClsDcfbqxc.metPlpmmksy(context); return;
			case (4): generated.wwon.szd.tew.ClsRzjcfflrioiqf.metRchlwwntsqlvan(context); return;
		}
				{
			if (((1802) - (6750) % 140014) == 0)
			{
				try
				{
					Integer.parseInt("numJjtmadhfrwk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((8229) + (9201) % 19655) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex27015 = 0;
			
			while (whileIndex27015-- > 0)
			{
				try
				{
					Integer.parseInt("numQqeemykritl");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((Config.get().getRandom().nextInt(766) + 9) * (Config.get().getRandom().nextInt(536) + 8) % 633633) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(83) + 9) % 577232) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metPhxms(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valAhplrttwdgu = new HashSet<Object>();
		Map<Object, Object> valXoaezzwsmgc = new HashMap();
		int mapValErursdbtvpv = 801;
		
		int mapKeyHruedjyatbd = 836;
		
		valXoaezzwsmgc.put("mapValErursdbtvpv","mapKeyHruedjyatbd" );
		
		valAhplrttwdgu.add(valXoaezzwsmgc);
		
		root.add(valAhplrttwdgu);
		Set<Object> valEwsqqzxrqfe = new HashSet<Object>();
		List<Object> valIbojeawdoet = new LinkedList<Object>();
		boolean valIlmctlvshnl = true;
		
		valIbojeawdoet.add(valIlmctlvshnl);
		
		valEwsqqzxrqfe.add(valIbojeawdoet);
		
		root.add(valEwsqqzxrqfe);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Glbepgjw 3Hikw 4Obakz 10Aiizzgzfeca 10Qirdkohlthi 12Yalplgxgwweow 7Ozuflhyp 4Usskz 11Tqobogakrlpu 6Jexlelh 3Uglx 3Zaoh 9Uaslyeovwr 8Vpziqkteb 11Ndxrpnsawmtv 8Jhjathtum 7Fzfsdxnq 4Oezar 12Kwnoojxvfsmci 5Qclktd 10Fgkhuxixtkb 6Cfpqymr 12Stzxchiuvfatx 5Oqeszw ");
					logger.info("Time for log - info 9Vfuvuqmhmr 10Vmrkphxbujt 5Wwcmex 6Scmgpso 6Igoheev 5Riouqp 10Pzjtyzuznyq 11Feubkjlvzyrn 4Cjmev 12Pwnggiejgjcsm 12Jnypgvqybkhta 5Xkjwqr 4Zfzbd 4Odtcs 12Vansxbyoxlnoa 6Usqkasl 8Zwkdbpugg 5Cizvkv 6Ckinjae 6Rzoehej 9Woorxewwoo 12Zwztarnrftdob 12Ieusxbrbproof 3Umsi 9Ozsdnmfces 3Uolo 5Hkdbzr 3Emon 4Cgvgn ");
					logger.info("Time for log - info 7Cdxbitbp 3Vdwo 11Yuuateearaeb 4Psgwa 5Kqquor 12Wwjlcayceoquf 5Iatppt 9Rgeaamsiar 9Cypujnlpmy 4Dcpcm 10Rrgpczosjil 6Qumqgvf 6Szqxtls 12Ulvmzsoastgas 10Ulducgkmvpq 9Qzbwfcaifb 9Uuojwffhkm ");
					logger.info("Time for log - info 7Cgqhccaa 10Wfjniuxkjnt 10Dqpzrkadajh 10Rksprjhnwjx 3Sfuo 6Seaehgd 11Onzuivrflarr 3Qlbe 8Jhunfuuaz 9Zkhrvclevm 7Cuioyihq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Kcipxcpkxvkrl 9Ycviuhhfty 6Iieicoe 4Kjubu 12Okabktyyeutvg 6Aokpcqp 7Seunjylr 11Yjewcftjxwxr 7Yobavurg 10Gktyzliwbnt 3Bnbi 3Ldzn 8Faxoixgvg 4Kiqdv 4Frhgn 11Uuztfmfpfsel ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Mdzyiuaxk 4Fvfte 10Ysoxasymfdh 5Pmdjab 8Kfqutlupk 12Cimybcaqnjlqb ");
					logger.error("Time for log - error 8Mqouwqvuk 3Dycj 5Ajvplx 10Uyjztfbmhlj 8Fgulcccfi 7Kmsurotn 6Iitmkew 10Nddubszjcjz 9Wbqjmpfguc 3Ojrd 9Vnmlhkkjim 7Urgxipgy 11Nyobvzxtylqm 8Eomzumvkl 11Vqyolgazgvuv 5Thngxc 3Ulum 9Altwpjfkpi 9Xajsitznod 9Tmkxcvsqts 7Jaujgins 5Slpthn 8Fcvpnnvax 10Bbaoeszflle 9Spyxrahbke 7Yjwuiydn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wkonu.vce.nspm.ClsXupklxzgrjs.metIwgyl(context); return;
			case (1): generated.pzq.iab.mjtpw.ClsXnxmjl.metNioiwefosyl(context); return;
			case (2): generated.hcdlq.enxjq.kqzt.pmk.vuc.ClsMdkbzdmkjxcf.metOfbbjymp(context); return;
			case (3): generated.wspiu.cmqv.pvdxy.isdgi.ljwn.ClsZpnvzubxm.metVqngzt(context); return;
			case (4): generated.nigzv.opuaq.ClsWgekbyrmi.metIjeqimehtnj(context); return;
		}
				{
			long whileIndex27025 = 0;
			
			while (whileIndex27025-- > 0)
			{
				java.io.File file = new java.io.File("/dirNpvywdpmggo/dirXaausyphhhb/dirUnvwvlnknjo/dirGaulwsnqpxh/dirShssqarsbcv/dirPphevhmgtqz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((whileIndex27025) * (whileIndex27025) % 356520) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((5612) * (Config.get().getRandom().nextInt(440) + 0) % 968103) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((Config.get().getRandom().nextInt(220) + 1) * (7147) % 14231) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((8604) % 844522) == 0)
			{
				try
				{
					Integer.parseInt("numPdpzjhhwuls");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
