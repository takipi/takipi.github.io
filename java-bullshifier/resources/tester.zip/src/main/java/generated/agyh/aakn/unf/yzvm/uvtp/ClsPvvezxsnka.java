package generated.agyh.aakn.unf.yzvm.uvtp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsPvvezxsnka
{
	 public static final int classId = 116;
	 static final Logger logger = LoggerFactory.getLogger(ClsPvvezxsnka.class);

	public static void metBiufhu(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValDapynmgejrt = new LinkedList<Object>();
		Set<Object> valTiwwgtcihgl = new HashSet<Object>();
		String valCtcsjmpemps = "StrGnfhldhlxnr";
		
		valTiwwgtcihgl.add(valCtcsjmpemps);
		int valHfxhbwhegpj = 393;
		
		valTiwwgtcihgl.add(valHfxhbwhegpj);
		
		mapValDapynmgejrt.add(valTiwwgtcihgl);
		List<Object> valLbesiscxefy = new LinkedList<Object>();
		long valTfyknlwemhz = 6689883227751526555L;
		
		valLbesiscxefy.add(valTfyknlwemhz);
		String valVexyzzasfjw = "StrUhwpaozvzyv";
		
		valLbesiscxefy.add(valVexyzzasfjw);
		
		mapValDapynmgejrt.add(valLbesiscxefy);
		
		List<Object> mapKeyNbbhrvsmpok = new LinkedList<Object>();
		Set<Object> valGopmclzavtr = new HashSet<Object>();
		int valFprtplxxeez = 561;
		
		valGopmclzavtr.add(valFprtplxxeez);
		String valCgymquqnpcz = "StrBqonyutvdua";
		
		valGopmclzavtr.add(valCgymquqnpcz);
		
		mapKeyNbbhrvsmpok.add(valGopmclzavtr);
		Set<Object> valJklzpvqsfcm = new HashSet<Object>();
		boolean valOoodztpxjzb = false;
		
		valJklzpvqsfcm.add(valOoodztpxjzb);
		
		mapKeyNbbhrvsmpok.add(valJklzpvqsfcm);
		
		root.put("mapValDapynmgejrt","mapKeyNbbhrvsmpok" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Bfzlraabdugpm 6Mtuqmsi 10Cosqzhndzqy 4Atatl 12Zrpculzsrjciq 5Xvknjx 6Ikyfokq 11Lqsgzriayaga 9Btizwwmhsv 10Ugxagygjvjn 4Pifci 8Gqzcljwzs 12Jfubzdcorthcc 7Woyphiok 4Xkzwl 12Zytgvgkjpwccs 8Fhyyzkqmp 7Bhgwptcb 8Gzvlritke 11Owhcoiuvcoyg 7Wtkfgvzm 12Thlbcivgjhimv 5Bwqfde 6Lczwhtt 7Cgkaycmr 9Hrirsraaez 12Zvhgggkfbntxw 7Syqkixsw 9Fwdboaudrz 8Thwoydvmx 7Lgkeayqv ");
					logger.info("Time for log - info 11Lvgzncnhmywo 5Twthga 11Wtkyijprtzqt 6Dmfimzl 9Nozffpaaui 4Trmlf 8Omttocadd 9Rjncjwqnil 5Zugqvg 7Zhsnyfka 9Vdfhozixso 3Viuu 4Jyqnn 5Yjiyxt 4Mqjxq 6Kukvblt 11Dwtoiaveiubf 11Sahxfhffukzz 7Ggzbdevk 4Vovhk 12Ljgnnjmlidjyh 5Vgehao ");
					logger.info("Time for log - info 5Uzmeph 6Elhrxmd 3Puuy 8Ckdzfbkgh 7Azimslyk 3Uviv 3Rwfx 4Lehxx 3Alnt 11Jblcsllkhtnw 11Dwopmnkzsnsq 3Oojm 10Ikzudfxacqp 10Uwcyoedjcsi 5Lydbex 12Nkagijgqzwcub 7Gmxygvpc 4Gzdfo 3Jcni 8Pyitbrwij 11Yhptvgoycpdd 7Lrjcvdqy 5Cgltoq ");
					logger.info("Time for log - info 6Cmdtext 11Bxoupsoeopuv 5Ahygyj 4Ggper 3Ffqq 8Owrhjyfym 8Wbnasecph 7Nqshjppc 9Sssxunsvhm 4Gqfxp 5Cgelld 11Vdlwaqmkmnhb 12Iqcvpgycacwgg 5Sbeqii 10Kdyonqavpmg 6Kbxssyr 5Dcrccg 6Coacqun 5Vsfzug 8Lgavlbffc 5Hcjpyc 5Nanisv 3Oeor 7Fuspuemi ");
					logger.info("Time for log - info 10Bawbnpgpnvg 11Vgtizyxlxmkj 4Cfvra 7Xxczvjef 11Ijywmofpveyu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Zqtppjlywqpto 5Mxztze 11Hybfehqyvbfi 4Qaott 6Xneettz 7Sioycnyz 10Haefxvpvzby 8Qxvcwlama 12Xdhlxiqqdjlix 8Kjdlxvoha 10Uptqxxcqoaz 6Qfngzaf 9Xwvpxpxmcm 9Ccmekiytvl 7Yfzxnupp 9Ijerfjwzts 5Lvpkma 5Bzxwss ");
					logger.error("Time for log - error 11Dgftcxhjshwp 5Jolxqb 12Picehxdzxzgwz 6Jiyeeba 8Lkfryhogs 4Snfhe 10Vertiffoxdz 4Ufuka 9Glpeuqehkc 12Iwbjcwdsttgzz 4Vatoa 11Ugizaojbtbpf 9Tnbchseprr 4Hixdt 10Dchujgcrrjw 5Zjnywe 5Dfypgv 10Ytrurfwuqmo 12Yhytaypidlmun 12Bzzsgtczyqpsr 12Xemnkoxcolffj 4Zpops 9Bgmmkyraxd ");
					logger.error("Time for log - error 8Bazgkcmtp 9Xpvyjabpsr 11Qyczopueawxq 5Vagzax 6Novybpc 9Jycwzmweie 7Ykugztcx ");
					logger.error("Time for log - error 7Pgqptbin 3Pcdu 12Fzidouliebrry 10Vzbdjcsrhrd 3Hyhc 8Hchumqqea 9Rtmxnutbpx 9Edtbviiphz 4Rglrs 4Hqwwu 8Dhvunltfi 8Mfsfxtjpd 3Chab 9Wjlyyiplhe 6Zxhrsdx 9Pyjzrdgsxs 5Vzcnob 9Bimaysynlu 9Rrqgcxotnb 5Pdpogw 8Hkpljqkpr 5Ljmusn 6Cjdvohy 5Fulzjk 3Slgc 7Iqzgabtg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ldtgt.vdfx.cdz.lkx.ClsLvvwnymti.metFkrjypkkw(context); return;
			case (1): generated.rayp.ekfg.uust.ClsQhtttdalkvmcth.metLspuodoxysnrqo(context); return;
			case (2): generated.svrd.bbp.ClsZenal.metIcwqskzzdn(context); return;
			case (3): generated.bxw.hza.cjj.bpzns.qzgt.ClsQbxnaxsj.metCcillrjcyusqec(context); return;
			case (4): generated.aea.iom.ClsOvjtnlwnmq.metKhmaqmoiluaib(context); return;
		}
				{
		}
	}


	public static void metStsgzfp(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valOqjasmjiuhh = new LinkedList<Object>();
		Set<Object> valJgvwypfqjts = new HashSet<Object>();
		long valTkhavjykguf = -6044150112310465915L;
		
		valJgvwypfqjts.add(valTkhavjykguf);
		
		valOqjasmjiuhh.add(valJgvwypfqjts);
		List<Object> valQelknlmbkfl = new LinkedList<Object>();
		String valCdxqorpphcn = "StrPlkhnjvxkgq";
		
		valQelknlmbkfl.add(valCdxqorpphcn);
		
		valOqjasmjiuhh.add(valQelknlmbkfl);
		
		root.add(valOqjasmjiuhh);
		List<Object> valRfgbfhjagqt = new LinkedList<Object>();
		Set<Object> valDncgftglajx = new HashSet<Object>();
		String valFvvmwmfalmn = "StrHicqlbpwrqs";
		
		valDncgftglajx.add(valFvvmwmfalmn);
		
		valRfgbfhjagqt.add(valDncgftglajx);
		List<Object> valJdlotznvaiu = new LinkedList<Object>();
		long valZviziyobhtk = -1340519776568377900L;
		
		valJdlotznvaiu.add(valZviziyobhtk);
		long valAofxvwjudkn = -6735331485164810947L;
		
		valJdlotznvaiu.add(valAofxvwjudkn);
		
		valRfgbfhjagqt.add(valJdlotznvaiu);
		
		root.add(valRfgbfhjagqt);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Zhevbdhz 8Aqxjludhu 5Odsprd 11Pigbdbzvnkfx 7Pjoqwwvs 8Cntpnnewf 3Nplq 3Jnth 8Xhepbrpfn 3Tglr 5Zsmote 3Pjls 9Scieouycyo 4Epyvv 4Jihrf 3Nuqc 8Quqlyvmye 6Irfxboe 10Vdydyrpyyso ");
					logger.info("Time for log - info 5Srpetn 12Rpgxvgjrhkoou 11Nlvhwoxhmunb 5Malkmt 4Ienrf ");
					logger.info("Time for log - info 9Jziqfchxxx 12Vngekeiajldmd 12Mgwcsdovlwssl 8Wnptdtyjt 4Mwfcc 4Vzxjm 12Gsamhqrfxsmgo 12Pzipyejglwper 9Ctotwarrwv 3Ycxd 5Yalzve 5Dfkits 4Zmgmy 8Unhrrcyby 6Gdzvfiz 9Bkvyjehzev 11Mtswukedbxje 6Vrqcszh 5Xswoci 3Ttnj ");
					logger.info("Time for log - info 8Iwwdyinju 7Aithnbzl 4Xexwm 5Zpaocj 11Hzsdjwuisuei 12Xzperniopgltp 3Qzjw 5Nbqohq 10Gunntnvyona 10Znjfgjrbtxp 9Lpimmuicuk 3Dpdv 12Ryuocauiesaph 4Qoctz 8Zblnbgypy 7Xwnhokny 9Tamzygwjxl 4Itjev 6Owopumy 3Bgjl 9Arinwmwhfz 11Pkhtpfxzzltf 5Jtqgjz ");
					logger.info("Time for log - info 8Cmnshkcfi 5Hysxcl 3Wtty 5Wnnatf ");
					logger.info("Time for log - info 4Foaeo 12Eeufzejznkdyn 5Cvspgg 11Ikzguvdzxusu 4Nivhl 11Xypnohvmjerw 3Cwfu 6Yyumqwg 11Rlnfmojhrwor ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Kguhradoritfv 8Ejgbkpezm 8Lujvmayfw 6Cycelaz 4Ifjjx 7Ujvgtzwf 9Tomdkmdclc 6Pwezsek 5Isxjeo 8Pmrotduas 3Qvvt 4Pzdie 9Hnhrgkamaq 7Bfagyqyh 12Jgsdgyqqrkayb 5Tlnrrl 4Xgloj 9Oxpamdzgdz 4Feifj 4Pbity 8Piitsxuhz 7Srsnqqkt 12Rrmhgtaayfats 7Txcmscpv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Oprelt 4Itgbo 7Addbowbs 10Ckewjeymcka 12Sklsofscmyjej ");
					logger.error("Time for log - error 6Krdbouk 4Kymwy 12Vtakabvjwhqxt 8Tlfuuvwsi 4Czywe 3Osiw 11Mryggujpmksh 7Yrqxknbi 10Dxguzhfyegv 9Kdhzbhyykn 8Btbhmvcez 4Gqchb 8Akkfoeahv 12Lwshcwvomlqpv 4Eijvv ");
					logger.error("Time for log - error 12Scqwopydqscst 3Biow 12Mznkqjtojlatx 5Whdoiw 11Hliobvhwrpwo 10Ukyqeiitidi 6Uugfhlm 11Ezqtqqfkfidq 4Gxvjc 6Zqihgjl 3Pxxr 7Vylslgjq 12Bqrbrwrdqulhx 3Mvub 9Uuuhtxikew 7Pjrjmjlm 12Nmjcysgcfepcq 3Iiky ");
					logger.error("Time for log - error 3Luyp 10Ccvizzhnvgm 3Ibkf 4Jdjqp 7Jfsjjnjb 11Hdojigiuouok 10Andlzblztvq 12Swniapahhdbik 7Bkbeybbv 5Lwbjfv 10Niqctqivjps 4Yriic ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bjkl.rwmim.scbu.axq.ClsFteiawx.metUpikxxqrqxf(context); return;
			case (1): generated.mbf.jauhv.phe.sowu.arz.ClsAtgovrsbvzxguw.metBpskpuvrln(context); return;
			case (2): generated.htfwc.kxkr.hjcg.ofg.qaif.ClsGjqugtpsjo.metIuperibrlehft(context); return;
			case (3): generated.pzq.iab.mjtpw.ClsXnxmjl.metNioiwefosyl(context); return;
			case (4): generated.fkbuh.vawj.ClsXsqsadsvdke.metGrquryhkwyi(context); return;
		}
				{
			int loopIndex22114 = 0;
			for (loopIndex22114 = 0; loopIndex22114 < 2104; loopIndex22114++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex22116 = 0;
			for (loopIndex22116 = 0; loopIndex22116 < 7150; loopIndex22116++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metMjhlk(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valJazxhrecsuh = new HashSet<Object>();
		Set<Object> valTqgsusxmoxj = new HashSet<Object>();
		String valWoafgbmqsjm = "StrZallpiobbsc";
		
		valTqgsusxmoxj.add(valWoafgbmqsjm);
		long valGauhkxyxhju = 3606356532384879230L;
		
		valTqgsusxmoxj.add(valGauhkxyxhju);
		
		valJazxhrecsuh.add(valTqgsusxmoxj);
		Object[] valYxtvzjpiycp = new Object[11];
		String valOvqbgbgmtif = "StrGzbulloujjm";
		
		    valYxtvzjpiycp[0] = valOvqbgbgmtif;
		for (int i = 1; i < 11; i++)
		{
		    valYxtvzjpiycp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJazxhrecsuh.add(valYxtvzjpiycp);
		
		root.add(valJazxhrecsuh);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Gthrnbgmrpuh 9Fskcithxwb 10Pgbcygupskq 12Pcifbxlpwfawl 6Rvqttvj 4Ipwqo 8Iconfvxzq 3Xvxg 5Jgefxp 8Ecxvqoehy 5Ofhdfk 9Odimrzpurd 6Brpeido 9Nnighypjtw 3Qpdd 12Jpepwgovwnpor 6Ghqdkmp 4Zjgaa 9Ppvmuygyra 3Ernr 9Xuzwekkmez 5Fqdkpb 10Arlmatsfyyo 8Ucotaqewq 4Bgdtf ");
					logger.warn("Time for log - warn 11Zthpxfdfchnv 12Mmzqpaudzysbs 12Dwtrrhwmfmdvx 8Ilbezquuq 7Yefqqyxd 5Ldldaj 7Upnhwpjt 6Ecuksfz 11Fbdhltkmqyaa 8Gjrzwfono 12Rkdhyhfmbkwti 5Dhbvig ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Ugxsqy 8Ovuqpaiyk 4Cftcw 6Nntgnhm 9Fqkkaomtyh 7Lkfzjdcw 9Urwriohckf 6Rtrpwcw 9Libztyqcjn 7Jjwumygp 4Qqvkb 12Qsuwhovpaoydo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nxf.wvris.vmp.ClsGllyounxce.metExmyrcamcnqvv(context); return;
			case (1): generated.lkd.eckd.hdtbd.unse.scvn.ClsCjccpmy.metBnujb(context); return;
			case (2): generated.lvnhk.isns.uksl.tjjfx.ClsEfuazouhb.metLybrkriiked(context); return;
			case (3): generated.qdt.cqf.kkjo.xjulh.ClsLodna.metIqrkzgr(context); return;
			case (4): generated.cbscy.vax.ifmv.uvjll.ClsXprhoql.metUsqqbascqyi(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(368) + 6) % 268643) == 0)
			{
				try
				{
					Integer.parseInt("numIqwlmbmqufy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(124) + 9) % 860602) == 0)
			{
				java.io.File file = new java.io.File("/dirGqhyuusvivy/dirYgwqvgbbbpp/dirCankncecykw/dirSjxzxipncyy/dirLlxblbgfrno/dirWnevobbegxj/dirFadrhgqdwjj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
