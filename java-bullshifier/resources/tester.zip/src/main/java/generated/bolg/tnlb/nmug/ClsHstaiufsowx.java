package generated.bolg.tnlb.nmug;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsHstaiufsowx
{
	 public static final int classId = 293;
	 static final Logger logger = LoggerFactory.getLogger(ClsHstaiufsowx.class);

	public static void metPapexcx(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[5];
		Object[] valTirlmwhtwtm = new Object[6];
		List<Object> valIninmzlpyfq = new LinkedList<Object>();
		String valDbinxrjmsjp = "StrVwcvtmctxuo";
		
		valIninmzlpyfq.add(valDbinxrjmsjp);
		long valSdswhiwcioq = -1328084156285086972L;
		
		valIninmzlpyfq.add(valSdswhiwcioq);
		
		    valTirlmwhtwtm[0] = valIninmzlpyfq;
		for (int i = 1; i < 6; i++)
		{
		    valTirlmwhtwtm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valTirlmwhtwtm;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Knvrxjnptg 4Fbccz 7Cstyonjz 3Yblr 5Bdvczo 10Vgjjpesrvfv 6Tbnxwhl 5Udtybo 10Xckvtevffcj 3Gjyx 9Taykilhoci 9Cwywingseu 10Blcvzseessd 11Quppiubcinbu 4Fcxyc 10Fhoxkefhonf 10Ioizehjnluh 7Vgiggknt 11Kgmhcodqtydq 12Fwypmkwxexiry 11Leiypdyryrty 9Cqmfrqujeq 6Trfkccc 4Hkbwe 6Fralace 4Bsuww 8Xaxddcntb 4Nihcm 10Cohguosnueo 3Osid ");
					logger.info("Time for log - info 9Zhqtkqmkcg 4Bqacr 12Ojvrjhpuuzlen 12Wqkstdcyzucab 10Nykocazyjcd 8Wxhpigjkn 4Bkoew 10Ytofsylexdo ");
					logger.info("Time for log - info 4Pbhwm 7Uzgtuprt 6Jqmccio 8Tfqtsylyy 7Nfncmmac 9Wvnqnbyusu 7Yteidgxe 4Rkjwk 5Alzwzi 4Llnta 12Lolwctlofamxr 4Yqzez 12Eqwnglplqqlms 5Jcgqde 5Jildwn 5Jrlqrt 7Qgueqcwk 10Brybnptdldt 11Kbjddodjypwr 8Saczoitnp 5Dwsbmh 9Hcylyigrns 4Pvaig ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Ywwqjmhezssr 6Rqftufo 10Hfrqwcukcyh 5Lvwlfc 4Shsel 7Yiwphxtj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Vquvhfj 4Jvagr 12Xtypjbkquhiei 9Tqxmexpoqu 4Ajymh 9Sslrnnksko 5Lgjqro 8Mnurywjds 7Hdyjmovy 10Tqlnyqengce 5Zjdthz 4Ymxtk 6Somjndb 12Nxmtywznadyvo 4Jmvtc 5Nvxxfm 9Jxjsiwxmnz 12Cdootgiooclez 4Vdetd ");
					logger.error("Time for log - error 5Wkygff 12Eksmptrllgtiz 10Mouaovbjawa 4Itfcw 9Ftdmvdepaw 11Lnfxumrxaqtb 5Xfasum 11Qdfnojaadaac 7Fgrjfile 6Kerlouj 4Xwcpp 5Clvbsc 7Zdeqpebq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yvbmb.hnmr.uqxw.ClsYomdrwntzuxawb.metPhyaooa(context); return;
			case (1): generated.fflc.jdncn.ClsHubvnnx.metSnkfjhjtib(context); return;
			case (2): generated.pfu.znq.ClsGxncns.metMcepskxnmqwcwc(context); return;
			case (3): generated.ctymn.uic.kza.ClsBochsrrjh.metGygnvmjatcdvgy(context); return;
			case (4): generated.lle.fzxn.utis.ClsYhanmsbp.metYezvvp(context); return;
		}
				{
			long whileIndex25003 = 0;
			
			while (whileIndex25003-- > 0)
			{
				java.io.File file = new java.io.File("/dirIfmvufblpwy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
