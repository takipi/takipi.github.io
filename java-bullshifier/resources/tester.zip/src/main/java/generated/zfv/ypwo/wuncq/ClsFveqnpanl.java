package generated.zfv.ypwo.wuncq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsFveqnpanl
{
	 public static final int classId = 461;
	 static final Logger logger = LoggerFactory.getLogger(ClsFveqnpanl.class);

	public static void metApyyqiuohqp(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValRoegpfyeqyq = new LinkedList<Object>();
		Set<Object> valZslnhifgdpp = new HashSet<Object>();
		int valIfeaytzdskx = 638;
		
		valZslnhifgdpp.add(valIfeaytzdskx);
		int valQmfvrfwkerl = 660;
		
		valZslnhifgdpp.add(valQmfvrfwkerl);
		
		mapValRoegpfyeqyq.add(valZslnhifgdpp);
		
		Map<Object, Object> mapKeyPoclqnzszuf = new HashMap();
		Map<Object, Object> mapValZymiafczrdh = new HashMap();
		String mapValPntpaoqoayl = "StrZvmtlplhfyk";
		
		int mapKeyGjmbwhzlpon = 28;
		
		mapValZymiafczrdh.put("mapValPntpaoqoayl","mapKeyGjmbwhzlpon" );
		
		Object[] mapKeyDkbfviimprm = new Object[3];
		boolean valApsjsbrhbdy = true;
		
		    mapKeyDkbfviimprm[0] = valApsjsbrhbdy;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyDkbfviimprm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyPoclqnzszuf.put("mapValZymiafczrdh","mapKeyDkbfviimprm" );
		Map<Object, Object> mapValTyujabksonq = new HashMap();
		String mapValSdzmzmzlnvi = "StrImyckxqbusj";
		
		String mapKeyJhxsvdhhlvc = "StrVmmcdchjsry";
		
		mapValTyujabksonq.put("mapValSdzmzmzlnvi","mapKeyJhxsvdhhlvc" );
		long mapValNlcmcmlfefb = -6286487118704415973L;
		
		boolean mapKeyKfxxzzvdjyg = false;
		
		mapValTyujabksonq.put("mapValNlcmcmlfefb","mapKeyKfxxzzvdjyg" );
		
		List<Object> mapKeyRushfsduqft = new LinkedList<Object>();
		int valYxuambmdxld = 918;
		
		mapKeyRushfsduqft.add(valYxuambmdxld);
		int valWdpsohywyox = 285;
		
		mapKeyRushfsduqft.add(valWdpsohywyox);
		
		mapKeyPoclqnzszuf.put("mapValTyujabksonq","mapKeyRushfsduqft" );
		
		root.put("mapValRoegpfyeqyq","mapKeyPoclqnzszuf" );
		List<Object> mapValKicvokjqqwg = new LinkedList<Object>();
		Set<Object> valBrlfxhyskdj = new HashSet<Object>();
		String valJsgtomwdluk = "StrTyzzoaaazdo";
		
		valBrlfxhyskdj.add(valJsgtomwdluk);
		
		mapValKicvokjqqwg.add(valBrlfxhyskdj);
		Map<Object, Object> valYsvritzinxb = new HashMap();
		String mapValMcbgauvqeal = "StrMnfilmxscjb";
		
		String mapKeyHalkfjwbcji = "StrJhrmuheyskn";
		
		valYsvritzinxb.put("mapValMcbgauvqeal","mapKeyHalkfjwbcji" );
		
		mapValKicvokjqqwg.add(valYsvritzinxb);
		
		Map<Object, Object> mapKeyVdfcxqvqwtj = new HashMap();
		Map<Object, Object> mapValZkdoukuiklp = new HashMap();
		String mapValDvbinaudcjm = "StrVzxmcnlzdrk";
		
		int mapKeyRcvkixpgpkp = 882;
		
		mapValZkdoukuiklp.put("mapValDvbinaudcjm","mapKeyRcvkixpgpkp" );
		String mapValFiucvjtxpcz = "StrRzymvcnyjyw";
		
		String mapKeyFgmndmhvzgo = "StrOlydolatimj";
		
		mapValZkdoukuiklp.put("mapValFiucvjtxpcz","mapKeyFgmndmhvzgo" );
		
		List<Object> mapKeySfptfjttrdd = new LinkedList<Object>();
		String valBqiduotkavr = "StrIhkpvamsdyb";
		
		mapKeySfptfjttrdd.add(valBqiduotkavr);
		boolean valJukniqquhlz = false;
		
		mapKeySfptfjttrdd.add(valJukniqquhlz);
		
		mapKeyVdfcxqvqwtj.put("mapValZkdoukuiklp","mapKeySfptfjttrdd" );
		Map<Object, Object> mapValOdqzjmkzkel = new HashMap();
		long mapValLcdausqtyim = -6296443634700318292L;
		
		boolean mapKeyKvnnqogwenx = true;
		
		mapValOdqzjmkzkel.put("mapValLcdausqtyim","mapKeyKvnnqogwenx" );
		
		Map<Object, Object> mapKeyGhxbplluwuu = new HashMap();
		String mapValWfzrhgsfbhh = "StrAwataqnqjfu";
		
		long mapKeyDedljndgywm = 7560524950055766362L;
		
		mapKeyGhxbplluwuu.put("mapValWfzrhgsfbhh","mapKeyDedljndgywm" );
		int mapValEzmmfaucvog = 762;
		
		long mapKeyDunuvrysdic = -2509868012837413664L;
		
		mapKeyGhxbplluwuu.put("mapValEzmmfaucvog","mapKeyDunuvrysdic" );
		
		mapKeyVdfcxqvqwtj.put("mapValOdqzjmkzkel","mapKeyGhxbplluwuu" );
		
		root.put("mapValKicvokjqqwg","mapKeyVdfcxqvqwtj" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Miwsqqbpudk 12Bibeleipkbybx 9Ojrpfgfszh 10Mwbbmhivrjx 10Koxlpbqagrb 11Gsotchfrjlef 10Nhzllbnxvik 4Vwdoi 3Rrgb 8Qooxilotk 4Cdyie 7Jrcevubn 12Wkzcchunaylgm 11Obrttnqfnrlx 10Zklopdrdmrf 4Nwluw 4Tjyrw 10Xrfvjbemdcz 10Gwmfmzerhlk 11Bfqjvumpavvu 10Bnsydgxfntd 10Qfhyxrsnqjm 11Ozpicjwfuwrn 4Nzrss 12Kfrmvsualuxnu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wvkuf.rvtq.kcgfs.vezg.ClsKfeffw.metVcvew(context); return;
			case (1): generated.mfx.chc.ClsHhqqrzfttutmc.metIncutinrfri(context); return;
			case (2): generated.seews.usvhz.ClsBpkgpi.metKhnlgsy(context); return;
			case (3): generated.maoc.ohm.nwzbx.efqn.ClsOzonhytosc.metIeedbzcj(context); return;
			case (4): generated.ebdo.cied.ClsIqlmeepdcmuqo.metBfionas(context); return;
		}
				{
			long whileIndex27780 = 0;
			
			while (whileIndex27780-- > 0)
			{
				java.io.File file = new java.io.File("/dirUqhgiohjbcj/dirGpcecsuqjaj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((Config.get().getRandom().nextInt(766) + 8) + (610) % 143137) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex27786)
			{
			}
			
		}
	}

}
