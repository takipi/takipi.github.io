package generated.exhp.ngeqz.saycv;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsTbfjaj
{
	 public static final int classId = 393;
	 static final Logger logger = LoggerFactory.getLogger(ClsTbfjaj.class);

	public static void metDyioavqwafahi(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValCmjeqotssrb = new Object[2];
		List<Object> valPdktcrgkzgo = new LinkedList<Object>();
		boolean valQkcpmgmwlxn = true;
		
		valPdktcrgkzgo.add(valQkcpmgmwlxn);
		long valBdfybpeyzdk = 2870030792377001631L;
		
		valPdktcrgkzgo.add(valBdfybpeyzdk);
		
		    mapValCmjeqotssrb[0] = valPdktcrgkzgo;
		for (int i = 1; i < 2; i++)
		{
		    mapValCmjeqotssrb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyJfqudyxqbdv = new Object[4];
		List<Object> valJvowtxazfms = new LinkedList<Object>();
		String valZzhqwsdlvha = "StrMtavacipzlf";
		
		valJvowtxazfms.add(valZzhqwsdlvha);
		
		    mapKeyJfqudyxqbdv[0] = valJvowtxazfms;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyJfqudyxqbdv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValCmjeqotssrb","mapKeyJfqudyxqbdv" );
		Map<Object, Object> mapValIrsltvcyeeu = new HashMap();
		Set<Object> mapValWddxeznmvsr = new HashSet<Object>();
		String valIdlcgyslzqz = "StrCfcdqwpqvag";
		
		mapValWddxeznmvsr.add(valIdlcgyslzqz);
		
		Object[] mapKeyRbqyyblqyli = new Object[7];
		String valPphabimvheg = "StrGtcwapcvzwy";
		
		    mapKeyRbqyyblqyli[0] = valPphabimvheg;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyRbqyyblqyli[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValIrsltvcyeeu.put("mapValWddxeznmvsr","mapKeyRbqyyblqyli" );
		List<Object> mapValLxgsvogbrdz = new LinkedList<Object>();
		boolean valOfenvcefypq = true;
		
		mapValLxgsvogbrdz.add(valOfenvcefypq);
		long valNmoirshapuy = -7261693935859440880L;
		
		mapValLxgsvogbrdz.add(valNmoirshapuy);
		
		Map<Object, Object> mapKeyIcrzosxjgoh = new HashMap();
		String mapValXlebxbotzog = "StrMcmatstjdrt";
		
		int mapKeyQdiahqebjez = 1;
		
		mapKeyIcrzosxjgoh.put("mapValXlebxbotzog","mapKeyQdiahqebjez" );
		
		mapValIrsltvcyeeu.put("mapValLxgsvogbrdz","mapKeyIcrzosxjgoh" );
		
		Object[] mapKeyOokafxpfdsi = new Object[9];
		Set<Object> valRhtqiepekmg = new HashSet<Object>();
		boolean valRiyxogdcjvd = true;
		
		valRhtqiepekmg.add(valRiyxogdcjvd);
		String valYkkrshjmdrw = "StrYulcgqktker";
		
		valRhtqiepekmg.add(valYkkrshjmdrw);
		
		    mapKeyOokafxpfdsi[0] = valRhtqiepekmg;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyOokafxpfdsi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValIrsltvcyeeu","mapKeyOokafxpfdsi" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Gymxqgu 10Pejylqlqqtz 6Svwpliy 3Cmzw 8Aybeutpiv 10Zyphmycingt 12Vkzwebqskmfbt 10Eigxydielje 9Gpejqgdoug 5Xtjxwv 7Oflznqgm 3Gymm 9Iwojawdzhw 7Ofrgwwmj 7Vzndtxsu 5Atnvpk 5Tjdohz 4Pykte 12Yjztzktrmtubs 5Ypostd 11Appflzewmtnx 10Orzhjbqyoff 4Gfxjs 4Vkyxv 12Mfsvoidnbvgeb 10Wtcmxochivr 3Emsp 5Cggayo ");
					logger.info("Time for log - info 7Eczlbcao 5Amtggj 5Xurbkv 9Hckiruqksv 5Jknhfq 6Kdsflwt 8Tenafvuao 7Sxhgkvly 12Uumdzqxzmslpb 11Ygoptncnlrvm 10Oyuqcxcjmsa 11Gajdvwwiohyk 5Mirgvt 7Jawftwnm 12Ahmswnosorihv 8Nzaveoeiv 6Nbompli 10Fpbmqxabfds 6Mmjxgyn 3Bkol 4Xlnhv 4Kogxo 10Bclzgeigxll 6Agcloxb 7Twaqgjtv 12Alasbslzmhwnx 3Tcdl 5Wfsfow 8Zvclsliwo 6Celtdra 12Gxmqlrbcvvswp ");
					logger.info("Time for log - info 5Mxbvkb 3Ctsh 9Bapmfdwuah 6Nqdpnsn 7Fcrkaerk 4Vazof 12Ssjavhcdjwadc 4Xcrec 8Rahavrdrn 7Xhwbipkf 9Emrkerrtgf 8Kbvldewfd 12Qubyfkkkhmyqx 6Xfrcbjd 3Ntwx 7Vipcdwad 10Oatkqvwhufq 12Qawcoooqaggbe 12Lfuhlevrshxvt 10Ctxtezeyxft 12Zdpqvalmjwlvs 3Xmcu 4Asakc 4Nlfwc 8Pteoklpit 11Rlrjpcsjwcax 7Bthxakwg 8Zdhozhlch 11Skaiskqjerlm 8Gsqktwnvu 3Rbxv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Bqvpu 6Yxoakxv 10Covqedvqggt 10Xmrykqgveir 3Wwyx 4Wdwip 3Wahe 8Yijhawpmo 10Vwvxabniwtq 3Nwke 10Kisruhzxbol 9Dynwavqwnq 3Bawd 9Enjiorefdd 5Mumbdy 4Zgxrm 3Nmvb 10Dyzzzxrnckv ");
					logger.warn("Time for log - warn 6Csdjbnk 5Evvvxc 5Zzllds 8Zrrtonina 4Yrrlh 11Kxucemdcsvte 10Zmqacarkzrz 9Ufufkkcjmb 8Fxhbypvud 10Qrxpunnjlfm 6Uiabfsk 5Beziqk 4Maipn 12Dnltjfosqtdrh 4Sykkj 12Jklrgrfeqwokz 9Ptquwdmblt 10Mmwwvwteqnp 10Essewnofmur 8Iizfhkipf 7Anarybbw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Zlbimpozts 4Cvecm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kklo.eog.twpb.eja.vmrt.ClsCtkkdlrnk.metMzowgzzffz(context); return;
			case (1): generated.ongb.lkxvg.dfa.pkoz.kbky.ClsZpuulcqafhvqyy.metOzbahhdicun(context); return;
			case (2): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
			case (3): generated.ylqx.lamew.rrd.tiu.hut.ClsBorecfhsp.metQmstdxdcazgt(context); return;
			case (4): generated.mccr.hhayo.cgyp.gjrvj.ClsTjitk.metJjldlhrudpysva(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex26667)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numRttibxgijau");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varLltpmkorlgf = (6934);
		}
	}


	public static void metZrbit(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[7];
		Map<Object, Object> valEfmennrkjfa = new HashMap();
		Map<Object, Object> mapValEcninvthzwp = new HashMap();
		int mapValOnqclvaktyw = 556;
		
		int mapKeyOjxusfgxqhv = 202;
		
		mapValEcninvthzwp.put("mapValOnqclvaktyw","mapKeyOjxusfgxqhv" );
		
		Set<Object> mapKeySeejfsrfiqh = new HashSet<Object>();
		String valXswealimqrs = "StrZwudobxfqkn";
		
		mapKeySeejfsrfiqh.add(valXswealimqrs);
		String valZtqdnsfdmhz = "StrZflrnxdjimk";
		
		mapKeySeejfsrfiqh.add(valZtqdnsfdmhz);
		
		valEfmennrkjfa.put("mapValEcninvthzwp","mapKeySeejfsrfiqh" );
		Map<Object, Object> mapValEbheusigwlq = new HashMap();
		long mapValXcydnwwvjmx = 2560781743577571246L;
		
		int mapKeyYovhcbrddaz = 38;
		
		mapValEbheusigwlq.put("mapValXcydnwwvjmx","mapKeyYovhcbrddaz" );
		
		Map<Object, Object> mapKeyCrhsvdfmmpz = new HashMap();
		boolean mapValLjyjswnednh = false;
		
		String mapKeyLonowhbewqn = "StrAcpiouoyhlo";
		
		mapKeyCrhsvdfmmpz.put("mapValLjyjswnednh","mapKeyLonowhbewqn" );
		int mapValIbqmgzwwngj = 869;
		
		boolean mapKeyFqtuirrkrnd = true;
		
		mapKeyCrhsvdfmmpz.put("mapValIbqmgzwwngj","mapKeyFqtuirrkrnd" );
		
		valEfmennrkjfa.put("mapValEbheusigwlq","mapKeyCrhsvdfmmpz" );
		
		    root[0] = valEfmennrkjfa;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Hhzkcjev 7Fknmljlu 3Dakc 3Aqxi 9Gdvytjshon 4Chkhn 9Mgdqvzosql 9Ddxwihttwy 5Hrznzv 8Ylebustuc 9Ycnhhzndrh 6Vtcvvig 9Wiadwbydlc 5Kizjqt 6Mddlutv 12Zaalegxlbvzpp 6Ybjkgfl 12Bgdexoxerjfsr 4Nukqd 4Nvfzw ");
					logger.info("Time for log - info 12Tengujkxqsuko 11Sjkqqpbbssye 10Xzwtiyuihqn 10Ujdqbsrgysi 5Itvtfz 7Vvmksjkr 8Xwagfjkzc 3Misv 8Dvenlqioj 5Lxizez 10Iljmhflfxwg 4Pkkjh 12Ryhmxnychizvo 8Ontpwikby 3Qqgp 12Cxulktrrgbrhf 4Chait 8Uqxdxpwlz 11Ddjxanawkkty 12Tdeygbotshjng 7Dcomnhpb 8Nmrmsyifx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Ptopmtmc 8Ywehzokia 11Ifvtchlontor 5Jqjjkv 3Rabs 3Fleb 12Yzokhgyewtfsj 7Nllfhdpg 3Kuuk 8Xmdmwxplq 9Mtchoivpxn 3Ohkk 9Qrygkkyazs 5Bpcwqz 11Wibejxxgzcjq 9Ldlruazfye 12Gyqatkobuqcrb 5Vubgrf 3Gqjd 5Osuwvx 5Hwgozp 12Xaooyumlfmdqs 8Xihdjwxvt 11Eosqycqmteim 8Ojirypech ");
					logger.warn("Time for log - warn 4Mxocj 10Nanlolzgvku 7Ekgxhzrz 3Izmw 4Jjvye 9Gdvjdqhcvj 10Pggogrsxrxl 6Dweevww 6Tfbwabf 8Zrkpffhum 4Ictfu 5Nvbvmr 8Veegdqxuh 8Wqcuabioi 10Rczstxfiood 8Xqtgcowjc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kqywo.pil.grw.dvt.ClsJduhsebfba.metRxalgp(context); return;
			case (1): generated.qikh.hgtag.amhgk.ClsEpqxnohalceif.metUhwjekipowr(context); return;
			case (2): generated.vntk.clexr.ClsYpzzbhceuihjz.metZikaf(context); return;
			case (3): generated.fflc.jdncn.ClsHubvnnx.metSnkfjhjtib(context); return;
			case (4): generated.juea.qhm.ClsOhhvy.metAkzdplujw(context); return;
		}
				{
		}
	}


	public static void metOqtzak(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValWptwgkrqegd = new HashMap();
		Object[] mapValFjobqynyeoc = new Object[2];
		long valCumzvjedzau = 8172065905415903008L;
		
		    mapValFjobqynyeoc[0] = valCumzvjedzau;
		for (int i = 1; i < 2; i++)
		{
		    mapValFjobqynyeoc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyWhypwmbobvl = new HashMap();
		boolean mapValUezvwtvcpkf = false;
		
		int mapKeyPsfpzdwhgrz = 711;
		
		mapKeyWhypwmbobvl.put("mapValUezvwtvcpkf","mapKeyPsfpzdwhgrz" );
		
		mapValWptwgkrqegd.put("mapValFjobqynyeoc","mapKeyWhypwmbobvl" );
		
		Map<Object, Object> mapKeyXzzncshnczm = new HashMap();
		Map<Object, Object> mapValYuvptaxtvrw = new HashMap();
		long mapValZjaemulekrz = 9175902851364808627L;
		
		int mapKeyFhmholvownh = 983;
		
		mapValYuvptaxtvrw.put("mapValZjaemulekrz","mapKeyFhmholvownh" );
		int mapValDnceprflgwp = 245;
		
		String mapKeyYipovtsowpw = "StrNkgabztkooa";
		
		mapValYuvptaxtvrw.put("mapValDnceprflgwp","mapKeyYipovtsowpw" );
		
		Set<Object> mapKeyPbdynpolnte = new HashSet<Object>();
		boolean valUwhsxvnlwke = false;
		
		mapKeyPbdynpolnte.add(valUwhsxvnlwke);
		long valQaasqslnuwl = -8929451864378029145L;
		
		mapKeyPbdynpolnte.add(valQaasqslnuwl);
		
		mapKeyXzzncshnczm.put("mapValYuvptaxtvrw","mapKeyPbdynpolnte" );
		
		root.put("mapValWptwgkrqegd","mapKeyXzzncshnczm" );
		Object[] mapValCapgtsixksf = new Object[3];
		Map<Object, Object> valZeewlvgasmb = new HashMap();
		long mapValXkokzbabgqg = 5933452196550973772L;
		
		boolean mapKeyDqwnlaubpqw = false;
		
		valZeewlvgasmb.put("mapValXkokzbabgqg","mapKeyDqwnlaubpqw" );
		
		    mapValCapgtsixksf[0] = valZeewlvgasmb;
		for (int i = 1; i < 3; i++)
		{
		    mapValCapgtsixksf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyXizwaalxucj = new HashSet<Object>();
		Object[] valVyvzsgwcokf = new Object[3];
		long valPxabcukccih = -6838711692884434996L;
		
		    valVyvzsgwcokf[0] = valPxabcukccih;
		for (int i = 1; i < 3; i++)
		{
		    valVyvzsgwcokf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyXizwaalxucj.add(valVyvzsgwcokf);
		
		root.put("mapValCapgtsixksf","mapKeyXizwaalxucj" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Czjy 8Fwnsadpqq 12Fdlktggvakfwz 8Xmgnosqlc 10Xbsrawxsqit 11Lzpamsicdlys 11Yqsdgtgljccw 9Kxgxbfomrw 12Myhlbnbjhygza 3Qhhl 12Sljpxiuwbvynq 12Naalftdfazzzp 12Apxoqctiohbgq 3Wsam 8Mghawthrn 9Hjaidddzqy 12Mhqgpeydurxaq 9Ulymejxoqx 12Smrytaixzcbuy 11Pkkesdavnjaj 10Psyvzjwncko 8Maiyusnmt 5Dzuwec ");
					logger.info("Time for log - info 8Oepccaiec 9Hqmonnslsl 11Qgzvtbcvdyna 8Qigfipncc 9Uewrawjuto 7Smxdsizg 6Uubwbys 4Phulz 8Umlydefiy 5Jagkvs 8Qspglbcan 8Znbeeveoy 7Lqnnkacc 12Tdafkqevostgr 11Uoiygyijcgyo ");
					logger.info("Time for log - info 4Fugob 8Rfclcqxlq 7Qaobhyyp 10Dizhssvxxdz 10Yorjjbfsowq 3Kqhm 4Yulhx 12Tfwzbtiopphmj 5Whdifk 3Breu 11Pdtwhqfjbobi 12Xgglfwytypxoq 6Ykehvaj ");
					logger.info("Time for log - info 3Ybii 6Daswnfw 4Ovegx 8Tzklvfqfu 3Epkx 3Cund 5Gptstk 5Ardarh 12Uiyxpdtdifcht 12Rzlhjkhlraqpr 6Jufvytz 5Wsszos 11Alcqfitovyuk 5Ewpzue 6Hkwtemd 9Prtxddfuzg 9Ffcmvkgkrb 3Bust 12Fccqflxexumbh 3Prsi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Gnrgfssltqkv 5Fqpaxa 5Dlewjh 3Froi 10Cjvdteshekr 8Owoihnhwy 4Kfoix 5Cerrch 8Mcitljtyl 11Medudiochdcm 9Thmjlbriyw 9Uammvrdkfg 7Pxpsausr 9Lezzlzjvyp 7Ggwhenkg 7Ctlkxccv 12Apqslogrzlaxi 7Kzpeorfi 10Rhtvnwdsujd 11Uqlmmcihozuf 5Erldkm 5Xpjsib 9Nioykdtlcg ");
					logger.warn("Time for log - warn 10Kceajuzcbve 6Zciqthq 4Mubmx 12Yfsazatpozfhg 6Bdmjzwa 10Mtmtqxdtdwa 6Hjyrplh 8Mlcllcafw 8Oajfsmikx 12Qkthfngitgglx 12Qkoxozgngqxra 4Tmyoo 5Fcckup 4Obyfv ");
					logger.warn("Time for log - warn 7Ggzasjgn 10Cqoslufyetx 5Rdtqip 6Zxnpfso 5Enexqp 11Zlrjbkufxjhi 9Udbwxcjzqg 5Snrevl 3Izdh 8Jjuesxbmj 11Dlusojnrediv 11Sfetxzcftyth 6Lgrxale 10Rhsdmvrxnkt 5Ebroxz 4Twgzo 7Mazxdoqp 6Xfqzfja 7Bohkidfr 7Jduxfdhl 7Gmghjkcl 3Ntti ");
					logger.warn("Time for log - warn 11Ifibubocyicm 11Snoyryzxtwzq 8Hsgdcbluf 3Hgof 12Smrdpuigorvml 5Imvpxk 7Dpbozeuk 4Uyqal 3Ajkc 6Vpfjxmj 4Wpzjn 11Aajtwjpkavsc 12Kvcdpksibilzc 7Pzxzqmid 4Osnjk 12Etskvlngwtrze 10Tyhxjuwvuqi 10Iijzggndfga 4Gcxkh 4Skyun 11Abiapcnpkecv 11Rhcpndbtcvuz 12Cqimlvwumhtpq 7Nvpzvwdr 7Osuqcshp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Eufcomwcz 3Nsjh 7Mlbwvuxe 10Euegfxklbkj 11Qrdpuhyvlrzf 10Jjphsrxeqzp 3Penl 10Tnzjcflvmoc 3Jmcr 6Wsfefia 4Yaxfh 9Hmgkxjsomb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nclk.lhd.awxff.ClsWzypoogjnr.metXvtfzticubdsik(context); return;
			case (1): generated.yaahc.bwx.upsjn.ClsIxadk.metPvfldng(context); return;
			case (2): generated.eedk.kvsj.tzabg.tqpy.ClsBuuqqzvjfxdiao.metTljcnrnstomu(context); return;
			case (3): generated.mipzp.qfu.axrt.ClsJkbbmhkrxeo.metUvsxqnes(context); return;
			case (4): generated.bkbep.bjvph.skry.qijli.gfl.ClsFlycqobnxjszt.metLjgrsni(context); return;
		}
				{
			long varMxnmzlhzhln = (3270);
			int loopIndex26674 = 0;
			for (loopIndex26674 = 0; loopIndex26674 < 7184; loopIndex26674++)
			{
				try
				{
					Integer.parseInt("numYvevtbmtqhs");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex26675 = 0;
			
			while (whileIndex26675-- > 0)
			{
				java.io.File file = new java.io.File("/dirOlgxzqtupdd/dirQzbpnhxoizo/dirQcoialoupki/dirYfcizmloyho/dirVzvgtnyamau/dirUcsjjvwbkmh/dirUqkyzehxtuz/dirMlkiieulmqj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
