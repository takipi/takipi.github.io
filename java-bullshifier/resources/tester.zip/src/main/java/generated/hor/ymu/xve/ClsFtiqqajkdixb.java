package generated.hor.ymu.xve;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsFtiqqajkdixb
{
	 public static final int classId = 40;
	 static final Logger logger = LoggerFactory.getLogger(ClsFtiqqajkdixb.class);

	public static void metBmlepaig(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valImrssrvtmib = new LinkedList<Object>();
		Object[] valPbqnsekhgos = new Object[5];
		boolean valKxfypeilbwa = true;
		
		    valPbqnsekhgos[0] = valKxfypeilbwa;
		for (int i = 1; i < 5; i++)
		{
		    valPbqnsekhgos[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valImrssrvtmib.add(valPbqnsekhgos);
		Object[] valRzspunzhqcs = new Object[10];
		int valVcoqqmgfsil = 576;
		
		    valRzspunzhqcs[0] = valVcoqqmgfsil;
		for (int i = 1; i < 10; i++)
		{
		    valRzspunzhqcs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valImrssrvtmib.add(valRzspunzhqcs);
		
		root.add(valImrssrvtmib);
		Object[] valBbmiwhnwgze = new Object[3];
		Object[] valHdyenipnfaa = new Object[4];
		long valFejfzhgddbq = -8038765401667597717L;
		
		    valHdyenipnfaa[0] = valFejfzhgddbq;
		for (int i = 1; i < 4; i++)
		{
		    valHdyenipnfaa[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valBbmiwhnwgze[0] = valHdyenipnfaa;
		for (int i = 1; i < 3; i++)
		{
		    valBbmiwhnwgze[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valBbmiwhnwgze);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Pdvozipt 8Dbuiavglz 8Ovfhhgfxj 10Qzodqawkkvz 3Jwux 12Nqiemgccxtnru 11Unuivryjjapc 5Nvrcju 5Bmmkgg 7Uufbplgd 10Atryhupwaay 11Xetjnhieeyza 10Wgudbdxhxzu 3Hdgz 6Mkmimvz 9Kxugejfkyt 10Clsxozrgnwz 7Xqhdjfhl 8Hoobeibjn 6Tmqptav 10Rusbfcajdtk 11Jgxzofkfvamr 11Hshlwhiztwgd 7Benhrwqo 3Otdc 4Pippz 3Qjny ");
					logger.warn("Time for log - warn 4Wixdo 10Biuzjjsqtvd 10Dpssjzvlbyb 12Euktbzfabvagy 10Lvdsydxfqrq 5Gixfjo 9Smsxwuskhm 6Avweonr 3Nbtl 5Yuigxj 9Vlohphyquz 7Bqrybage 12Kttmcpvrzlbhr 8Tvdfncukk 10Amsehsjrdai 10Qgkkonezsuk 6Gahqbll 11Knmbjfwyszng ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Pkksbv 10Qvexmxolalu 11Dsdlqamwbjwr 3Cpqt 11Eerquqaqldme 5Pqzesn 5Knhuuk 10Pyfuoyotqlt 10Alrhpdvpacd 5Kxzedt 3Jios 4Ojunn 11Sjwwngogtrlo 3Uswf 11Shdpgiqwutsv 6Wmsnjbo ");
					logger.error("Time for log - error 10Czhvnbyitab 10Oysixuhiakp 10Eduzekvceuj 8Hwbnpbvuv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fpitj.gxmf.ClsSfcuawq.metBsrvgokizyy(context); return;
			case (1): generated.ongb.lkxvg.dfa.pkoz.kbky.ClsZpuulcqafhvqyy.metSvcpwlc(context); return;
			case (2): generated.dpe.jvo.jwdtk.ClsKqcmvv.metOzjobj(context); return;
			case (3): generated.tuih.veohx.ClsLezjqptgnoj.metZdwzntbregpqh(context); return;
			case (4): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metKlgcwsafmqppr(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirZiaitwbnybh/dirScwanybcewy/dirVkdyqubhxzo/dirNyxtxonppew");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex2729)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numVpmbgviyynn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
