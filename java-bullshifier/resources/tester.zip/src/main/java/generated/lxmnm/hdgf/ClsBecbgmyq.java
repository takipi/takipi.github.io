package generated.lxmnm.hdgf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBecbgmyq
{
	 public static final int classId = 195;
	 static final Logger logger = LoggerFactory.getLogger(ClsBecbgmyq.class);

	public static void metXxaphxbxrzzp(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valEdhofvxtmnw = new LinkedList<Object>();
		Map<Object, Object> valIyvqzwgmgao = new HashMap();
		long mapValMyolwqoyybr = 1229293556746442954L;
		
		boolean mapKeyErplkuyhhtj = false;
		
		valIyvqzwgmgao.put("mapValMyolwqoyybr","mapKeyErplkuyhhtj" );
		long mapValOvfjvaspxjs = 4987139457937640362L;
		
		boolean mapKeyKixdgfmldir = false;
		
		valIyvqzwgmgao.put("mapValOvfjvaspxjs","mapKeyKixdgfmldir" );
		
		valEdhofvxtmnw.add(valIyvqzwgmgao);
		
		root.add(valEdhofvxtmnw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Sbriwalv 10Jsekfgftqfp 4Agnpw 3Mwre 6Tkdtxhu 9Ccxuszhtyx 3Niqv 9Zqylbxktcv 12Czwwbrbmyanum 6Owacaao 10Wnbclbanaci 11Qweichvdgdmu 12Rcgfsiufcozub 7Xsmcdsoi 6Sbtdiup 5Fyqttg ");
					logger.info("Time for log - info 6Brgixxs 10Epgrjzwznak 11Luoffbtzykdr 12Oeuhqvkgptunb 9Vdlwoyditg 7Zgcgrylb 9Hynobhxkph 9Cdjwefaomw 11Uiipewkllwfj 5Hcnwuh 7Wmrpylsb 12Ldzpkwgiotreh 10Hrdfldlhfae 6Rmgffgd 6Eytnuus 12Fkymkwmsuhetp 9Wlbsgdhmvm 10Aqihlqcjwzo 5Exwsin 3Jelg 4Dxfdw 10Gckmhexunav 5Mcjlwp 12Uvgqiccqoggsv 12Vvfbhkrlnpgbl 10Usbixwrgtnl 9Liyaiqezgx 8Hxmkqccxo 9Fslbgjuhqy 7Jqmcgbxt ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Koalyi 5Yrmryu 7Jgmdufzl 7Doaehfwt 11Ulkuzdxokidv 5Cipycy 3Dndf 6Uxbllfp 4Jcbev 6Kivehrt 4Doaif 3Zinb 4Dfbur 12Rfbjdvlhnliia 7Vqgdddgo 7Voludiuu 5Fxxwcw 8Wrtrxmlkz 4Rznts 11Pwrdsoojfvka 6Oncqpti 10Uxzsvbkkxyd 7Inewehxe 10Unwwxoqrhra 5Renwfy 4Uxcjx ");
					logger.warn("Time for log - warn 9Gtpsbjoycc 11Shthzcjrwtpq 7Udounwhh 9Aqvobmmtaw 4Nnwlf 3Vvrq 3Kmpc 3Qiah ");
					logger.warn("Time for log - warn 10Dpmvoakpzhc 4Xydcc 5Gjylwt 7Xfgxmmrl 5Jvfztk 5Uheosx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Zleeyue 11Zhiywnadcuko 3Dzex 10Nckfkafqvqf 6Tdcfssn 10Ruwoasqufzg 10Lozcyhvlsfd 8Rgajsbsfv 11Somjjjbodsfp 3Ktwe 10Psepxjvdyes 12Zvsjeaoyhbelk 9Qnlxidrtof 4Enohu 6Vjdpqcy 3Rlhn 12Etspovtireylx 10Fitrkbgvpbf 12Ccovcybobvhsx 6Cjokygm ");
					logger.error("Time for log - error 9Ryljypwojb 7Vfhmgfdp 3Ncrp 5Sqsofg 5Kqfifv 10Wkdbmmioadr 9Kjccclboyh 9Qnqhtmkfzf 6Wilkopz 6Hcesmzy 5Nylvih 5Bqivyi 4Cvklh 12Vmgunmocjwumg 7Ivfywvao 5Mkvemz 9Aohcxmwilo 7Azgyzepm 3Qavn 10Ywebridopht 10Mkzjsxmupnk ");
					logger.error("Time for log - error 5Tewuzq 4Iqqgf 5Vhpbpw 8Fwarvwqcz 8Mackyzoti 5Lournk 11Nrfbdujwgvto 8Weijmxyca 4Jjfvq 8Pvvouvhqb 5Sceyoa 9Xwtddoefua 12Ewtacufdqexve 8Mfvtcgzgw 8Dclrikbaa 7Ylicqgyq 9Iacmbfnpyu 3Qyze 3Ydks 12Gzukwtihlfvlu 7Axpnrqzp 7Jynscyqg 4Vccgc 12Zxvhnytfmbdzx 4Essdm 8Xismmudaz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hnmnf.dxh.laih.zpf.ClsDfldwucgkze.metVnovmwgbhe(context); return;
			case (1): generated.ufqu.ddqdj.nsc.ClsAchghkwny.metKntxpyoov(context); return;
			case (2): generated.nrrh.nxnu.xat.kha.ClsLoiagobs.metImjogkxzrsynw(context); return;
			case (3): generated.ncau.ibhi.ttuvu.ClsHlbobsu.metTahxaryiutr(context); return;
			case (4): generated.agl.duqt.yfyli.jnv.jpizl.ClsQbgwqgmsxm.metEmnhch(context); return;
		}
				{
			long whileIndex23432 = 0;
			
			while (whileIndex23432-- > 0)
			{
				try
				{
					Integer.parseInt("numTvsxjazdbhu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metPukzgrfysjdgcx(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valKqbhdkwaigt = new LinkedList<Object>();
		Map<Object, Object> valKbtawgadely = new HashMap();
		long mapValXucyhnretjv = -1432998926952456405L;
		
		int mapKeyBcyichyrahj = 686;
		
		valKbtawgadely.put("mapValXucyhnretjv","mapKeyBcyichyrahj" );
		
		valKqbhdkwaigt.add(valKbtawgadely);
		Set<Object> valLzznkjszbdk = new HashSet<Object>();
		long valQoyvjibwmtu = -1681594582505052869L;
		
		valLzznkjszbdk.add(valQoyvjibwmtu);
		
		valKqbhdkwaigt.add(valLzznkjszbdk);
		
		root.add(valKqbhdkwaigt);
		Map<Object, Object> valLfjeykhauke = new HashMap();
		Set<Object> mapValZqtortshalu = new HashSet<Object>();
		String valPmxpuyetiqb = "StrRpdtsbddzvf";
		
		mapValZqtortshalu.add(valPmxpuyetiqb);
		int valCdcaofrtliq = 495;
		
		mapValZqtortshalu.add(valCdcaofrtliq);
		
		Set<Object> mapKeyYkhdlwutomu = new HashSet<Object>();
		int valErbfdqdutng = 30;
		
		mapKeyYkhdlwutomu.add(valErbfdqdutng);
		long valNijiortorbe = 4841641884749944741L;
		
		mapKeyYkhdlwutomu.add(valNijiortorbe);
		
		valLfjeykhauke.put("mapValZqtortshalu","mapKeyYkhdlwutomu" );
		
		root.add(valLfjeykhauke);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Dejotqe 5Qsgdny 10Vusulmjtzyz 12Lmpmdsjguxkoa 3Scch 9Svcbuvbtfm 9Tmnhnudcma 12Jyqcebyojsuvn 12Lbkmaqfeaylgj 12Arihgjjzcrjcx 9Ugmmznwcrp 11Ixrrzqifijzr 5Xkvuaq 4Fjyju 12Suqomsnrouzuj 9Yndidcuaqe 7Ftjlpozn 7Mgickfny 4Xwyrg 6Wvxbccc 6Adktgsi 5Rbouhb 11Drjgoknbcocl 5Aahhaa 6Opmuvpc ");
					logger.info("Time for log - info 5Ncgnua 5Vwykiv 8Cferikanv 12Epyijirljvdvf 10Ghyaftebxfs 6Fqgskld 5Zztlcn 5Mcxnlx 12Moalftwiufiez 4Bkjxa 3Rkpe ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Prwf 9Nfanomknfb 4Wcfja 4Aoutt 11Ucdyzabnmkik 3Fnrr 5Vhgtrj 7Lqvfzfmi 7Comqxcko 5Fewuew 5Inaync 4Fclce 5Ehyogn 6Fuiwjtg 4Aymgk 7Xjufytug 3Ymob 9Lcxemvwxzk 8Bjcdltahw ");
					logger.warn("Time for log - warn 9Dqwjjqldix 7Bqaarkpc 10Dmgotilzhna 4Gxrpf 10Atbnaboloxh 10Hofgrvifrgw ");
					logger.warn("Time for log - warn 9Rvvygjuphc 3Wcrg 9Vfjcomjxgc 7Kndowcmt 7Kykxrwau 9Znrlbksdnl 12Kmwcvnbvzjxqv 4Nxsxq 8Ddstwhuhm 12Jyqdtsksxymqm 9Zswpavcvqt 11Spcknniaxocv 7Hfevuvuv 4Rjrfm 7Nyydrxjk 7Hfvcgngn 12Nfdasrgxylgnp 5Tnbimj 3Dhfx 12Isgtucyvhksim 9Fumhmozdbv 6Cvzehnl 4Mzbtm ");
					logger.warn("Time for log - warn 3Lnfo 12Orxlvmclnxbla 12Dsvqptwkvqhss 4Vlqqx 10Rdhfxxjgmkf 6Tgqnzta 4Rrsne 9Bhxvmefxkl 7Kyfhinlc 5Tjnmxw 3Pfvo 4Tzern 8Dfazvxnud 8Bhjhodgvo 5Lrjxmy 5Xdlsgu 12Sqkqganjvpcry 5Tibndw 6Eigexxd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Tkmmjvsnvtcd 11Dcnqioqjpmph 6Mszvfsk 5Ebxokn 4Pylzb 12Omlvxarpzntjd 5Bddzzs ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gasq.isr.fpndy.jhzr.ClsNxizwkdumgga.metGyvkgyzcookm(context); return;
			case (1): generated.godw.hlszo.mtqbt.shx.tbgwd.ClsMygvrmsqnwlsdw.metHodxre(context); return;
			case (2): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metZlaxbquc(context); return;
			case (3): generated.npa.tuyd.ClsLxzuwxfsi.metPbpsvdupgp(context); return;
			case (4): generated.wtc.bgb.gahv.mul.rts.ClsUeuxdzs.metPhxms(context); return;
		}
				{
			int loopIndex23435 = 0;
			for (loopIndex23435 = 0; loopIndex23435 < 695; loopIndex23435++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex23436 = 0;
			for (loopIndex23436 = 0; loopIndex23436 < 1128; loopIndex23436++)
			{
				try
				{
					Integer.parseInt("numTvheoypedfm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
