package generated.lnmsy.sfi.xnlu.mhn;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsTvqndlzazist
{
	 public static final int classId = 110;
	 static final Logger logger = LoggerFactory.getLogger(ClsTvqndlzazist.class);

	public static void metCxqaycr(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valXcftocavmdl = new HashSet<Object>();
		Set<Object> valJddjsdqsifo = new HashSet<Object>();
		boolean valLbtwxknlaxd = true;
		
		valJddjsdqsifo.add(valLbtwxknlaxd);
		
		valXcftocavmdl.add(valJddjsdqsifo);
		
		root.add(valXcftocavmdl);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Uoko 3Bhge 7Pzrrfnjf 6Svvxxsh 12Qnsjpyoejyjoy 5Fgzoas 3Efcc 12Sznkrcdfaxptz 3Klrj 6Gqztqqg 6Uxdxwim 11Fpnbqqjpdchs 6Zscrcor 12Zwbjmfzebxrec 10Ceowxxeqhpi 5Nvqoze 5Czeyro 11Gbkuruqldnnw 9Jhvujaflks ");
					logger.info("Time for log - info 6Jonrscw 8Iskacvtoi 5Mhflsm 4Mtfwo 4Ffwgq 3Ehki 9Raxqngzsxy 11Sgsskrcxhzmb 4Atxha 11Gwnbvmtxyfnn 3Msmh 3Vxds 6Iunykrv 7Uttlvokp 12Flvyvbvdlxuvc 5Cvjoli 11Srbtldbputhl 4Ngjdj 10Tummwdtyvri 9Thmitcrzik 9Ypoaovzxrj 10Igrnmrkpgot 3Fmee ");
					logger.info("Time for log - info 5Btirin 7Krcajrln 8Ppzglxket 9Rkurmslety 5Jqkjsv 12Lqlczkjwctsap 6Mpnncvk 10Bfzsdxservz 11Faofvvubgfec ");
					logger.info("Time for log - info 9Oskdztmxsi 9Ejgxsgxjuk 9Kejpoqtiup 8Noopmhfcp 8Bxduirvol 10Lhxyjedmjlj 5Gofhkp 9Lvmkqvfiml 6Alrkfym 12Vdhovambftjvh 4Rhbod 11Veamrhruhwaz 10Wtvndjgipjh 11Etcylclxeykg 8Uewcohkbq 6Ieirqkp 7Qjehwqjc 9Hvizghmwzq 6Cchvlsv 4Yeuro 6Qbhuznz 7Lkoceeae ");
					logger.info("Time for log - info 12Ddlaameqiequb 7Qlhawcwu 7Mcitlmyr 10Itaqtdiyihj 8Dzeikeghv 9Fcqaojmsjr 3Ggoa 8Kabojycwj 6Ylljstr 3Lvez 8Ghzxgbcwu 8Rrndzmtwc 10Yiviyqejbfu 9Exfkierghh 6Clhlahw 6Gdonozz 11Gdzeqzlwtfqc 8Vggupsxge 10Zrblqcalqcb 4Iwrfo 10Rsaaxfhdzcb 12Ksiknwvroqlhf 3Twot 4Cncvc 7Mytohouf 6Ovetirn 3Njju ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Gsaahonhgjxnu 6Usevvwt 9Ysaetnlsgt 10Bpokqpdkrmr 9Hosbjjmqki 12Uqxsvseforotb 3Fmzz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xajsm.xnlym.ClsUmfzchfskds.metYensggsobl(context); return;
			case (1): generated.bvvh.vrkq.ClsCiivqtifsuv.metImwfpxpepgga(context); return;
			case (2): generated.ogy.ayf.aijxy.ClsNdoxmvj.metCsqrhmq(context); return;
			case (3): generated.baxd.moelu.dfhna.pgrdw.pgae.ClsTifyecuw.metBnfwficdpxvbr(context); return;
			case (4): generated.usy.jqyb.aoxm.cmxc.tdb.ClsGdtxkhc.metYudmw(context); return;
		}
				{
			long varXifnfhhajae = (Config.get().getRandom().nextInt(384) + 1);
			if (((varXifnfhhajae) % 261588) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((347) * (Config.get().getRandom().nextInt(63) + 7) % 291949) == 0)
			{
				try
				{
					Integer.parseInt("numOfjyxqdvtnu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex21996 = 0;
			for (loopIndex21996 = 0; loopIndex21996 < 7548; loopIndex21996++)
			{
				java.io.File file = new java.io.File("/dirGmmvnwnhqsp/dirDhabhpspetr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metEvvtbxshkftg(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[7];
		Set<Object> valYqfsuimxsvh = new HashSet<Object>();
		Object[] valMwbmwewdukl = new Object[11];
		int valSejjljafkao = 803;
		
		    valMwbmwewdukl[0] = valSejjljafkao;
		for (int i = 1; i < 11; i++)
		{
		    valMwbmwewdukl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYqfsuimxsvh.add(valMwbmwewdukl);
		
		    root[0] = valYqfsuimxsvh;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Jkpyebrek 10Qguxtxzehio 10Uizamywcpmh 10Dchbdruetmc 12Rjssiwmtrolxy 11Puaedsgldnvj 12Jlfjhrorvweqe 12Vgswtvsaswjga 3Jyhu 7Lwfsjhnt 6Abozokv 10Djknkysrmgy 9Gpjmubzujj 5Yfyddl 12Egufbfktnthzg 10Euvaskzcqvm 3Qbjs 3Csmk 9Lkdkkxcfgh 10Ufpnitrijvy 8Bounjmwjh 6Oxqrzvj 4Iytva 3Msjn ");
					logger.warn("Time for log - warn 4Arzkt 11Ufvipxbcsune 11Hxviryzrxkdi 4Tpmnm 4Xozti 9Yivvpxxycr 9Irabncwbbc 11Vrvwdvgorvav 4Hrjqb 3Lkos 7Nxlulspd 4Kfktl 12Hncxuiagksqsn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Xrhcqdvqctl 3Jhmy 10Dhfxdkqwgor 12Cxbepxonlmopv 9Wiiblsqjgg 8Lzldqidrx ");
					logger.error("Time for log - error 7Jwejzsis 12Iqxxuhycpsrmb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gmk.vzs.crbap.ClsEkyhsmjeh.metAjrgrsa(context); return;
			case (1): generated.rkfhx.ntcs.qoe.lasd.nzzym.ClsDftkqmvmp.metEliwmlxsgnolka(context); return;
			case (2): generated.jmrw.ryri.ClsDmqllltcxdlzd.metQoxlfxubml(context); return;
			case (3): generated.wxgmf.hjxrw.ClsYvfyyrknqfec.metIuqusbvrsb(context); return;
			case (4): generated.ocg.pnhd.assci.ClsEkxxqpavkqxkay.metChyppmprgvzqeo(context); return;
		}
				{
			int loopIndex22002 = 0;
			for (loopIndex22002 = 0; loopIndex22002 < 8246; loopIndex22002++)
			{
				try
				{
					Integer.parseInt("numGsfmlzcodmu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metJalvuxwrjutsw(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValWrzdbumroij = new HashSet<Object>();
		Map<Object, Object> valUspfkncnstk = new HashMap();
		int mapValBkktcoswhyn = 205;
		
		String mapKeyPvvrtjygado = "StrMvklgrzorua";
		
		valUspfkncnstk.put("mapValBkktcoswhyn","mapKeyPvvrtjygado" );
		long mapValAompzgmkaoi = 7740513448164225485L;
		
		String mapKeySzbrogtdfap = "StrTgmwifnmoxr";
		
		valUspfkncnstk.put("mapValAompzgmkaoi","mapKeySzbrogtdfap" );
		
		mapValWrzdbumroij.add(valUspfkncnstk);
		
		List<Object> mapKeyAaihqvulczk = new LinkedList<Object>();
		Map<Object, Object> valCfzklccukzo = new HashMap();
		String mapValToanitczpmf = "StrUunyfdxvavy";
		
		long mapKeyVxsqvlfwzpq = 7288084099485498456L;
		
		valCfzklccukzo.put("mapValToanitczpmf","mapKeyVxsqvlfwzpq" );
		boolean mapValRolffphtfrc = false;
		
		String mapKeyZcfgsoaqilb = "StrWpgkvugojgt";
		
		valCfzklccukzo.put("mapValRolffphtfrc","mapKeyZcfgsoaqilb" );
		
		mapKeyAaihqvulczk.add(valCfzklccukzo);
		Map<Object, Object> valXzsrwgrfath = new HashMap();
		String mapValAnaaovcbtei = "StrKoheqrnuczf";
		
		int mapKeyPlxzabqnjex = 434;
		
		valXzsrwgrfath.put("mapValAnaaovcbtei","mapKeyPlxzabqnjex" );
		
		mapKeyAaihqvulczk.add(valXzsrwgrfath);
		
		root.put("mapValWrzdbumroij","mapKeyAaihqvulczk" );
		Set<Object> mapValOcltgpwsruk = new HashSet<Object>();
		List<Object> valWazlmpqponx = new LinkedList<Object>();
		int valGklrcwestci = 508;
		
		valWazlmpqponx.add(valGklrcwestci);
		
		mapValOcltgpwsruk.add(valWazlmpqponx);
		Set<Object> valImuuixnidvd = new HashSet<Object>();
		String valZyvatiqzjgw = "StrNyutguiditk";
		
		valImuuixnidvd.add(valZyvatiqzjgw);
		String valHomvpmdeoqi = "StrQjlybviyujo";
		
		valImuuixnidvd.add(valHomvpmdeoqi);
		
		mapValOcltgpwsruk.add(valImuuixnidvd);
		
		Map<Object, Object> mapKeyWpbyquyeuio = new HashMap();
		List<Object> mapValXlcycogsnhg = new LinkedList<Object>();
		String valEqdvmnkihfz = "StrVtnovudblji";
		
		mapValXlcycogsnhg.add(valEqdvmnkihfz);
		boolean valLqxnhnwyitj = true;
		
		mapValXlcycogsnhg.add(valLqxnhnwyitj);
		
		List<Object> mapKeyRtktmjxrhxv = new LinkedList<Object>();
		long valMjqjbmnovvb = 4050787856646014285L;
		
		mapKeyRtktmjxrhxv.add(valMjqjbmnovvb);
		int valFdcoetpqocy = 895;
		
		mapKeyRtktmjxrhxv.add(valFdcoetpqocy);
		
		mapKeyWpbyquyeuio.put("mapValXlcycogsnhg","mapKeyRtktmjxrhxv" );
		
		root.put("mapValOcltgpwsruk","mapKeyWpbyquyeuio" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Zysjxuivea 10Rxncsjtkttm 3Dmcy 12Atdlbnnnqasdt ");
					logger.info("Time for log - info 6Siccggq 3Ztlg 3Vmra 3Endy 10Ldrdpfupawm 12Crlpakvwlicsj 7Nutamcek 3Trpy 5Ohknlq 5Rpybsg 4Tyood 8Bbrmqewwb 12Iphfvaqyccmhj 5Vackqk 6Gpvuwvz 5Sdyizt 5Onlfzi 7Ksaslype 9Jnoafdvtjo 5Blojms ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Cftdsnj 6Ykvbepl 5Vwhvuu 12Vjxlgwwyyskfd 6Xoxrkjz 4Xwnyj 12Xqlrgrrwxukoq 7Qhkuvviu ");
					logger.warn("Time for log - warn 4Cjcgz 10Eyqogwlalpe 4Fudsv 8Xwducpphj 8Fgqcdgvod 6Muljlsm 11Mugakxijdsne 8Banrkwrge 12Sbfimtnsdxevf 3Ktsu 11Espevxhpfmgl 10Zjjpbrbkcye 11Qmlwvnqmkhoj 7Bxshbnkt 12Hslglpwnhbuum 8Qsiohznus 4Xjnfh ");
					logger.warn("Time for log - warn 9Qlkgdxivlc 8Xjfnqwdov 10Dgxxubigvoc 12Wfnaemlwnukej 9Qfdezltiys 10Jeqtiumcxwt 12Vrlyzxvueopqm 6Edgmsmi 6Vrkwdpd 11Qkdxapuizvvg 9Awgjqcdrni 11Uuieqielxfke 4Laqyp 12Xfjllyxkwearp 10Vdzgbzozcbr 6Jfcsnyx 3Vmci 6Gynxxhu 4Wyitq 10Gozecjuueks 4Zuhpw ");
					logger.warn("Time for log - warn 4Urmzr 9Jdhqeboxsr 7Ivbhhbzn 9Ukgyxvpofv 4Jbgnl 3Ddvr 7Kfysymmd 3Dwdn 9Jfqzaprcfm 11Yydrhyiiedft ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Ynkkgiae 7Ekgwrdqr 7Ujksimmt 7Hzwwzeec 5Grywqa 6Cgljxij ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.flvo.tuwfx.wlpxx.jysnd.tuk.ClsFuuvt.metQxwuot(context); return;
			case (1): generated.bywcf.xycgt.wqguo.ClsDsjomnr.metHbpetwyyyphnb(context); return;
			case (2): generated.bvvh.vrkq.ClsCiivqtifsuv.metBcfndjmmnf(context); return;
			case (3): generated.mtq.flhse.ygibh.yfs.ClsSzzuamch.metIuxgxgafdnqnhh(context); return;
			case (4): generated.app.atudj.div.xmvbx.csga.ClsIfahtjloa.metSmwloig(context); return;
		}
				{
			if (((1221) % 367643) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numVifzxqtgbjx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirCuhlndeifnp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex22011)
			{
			}
			
		}
	}

}
