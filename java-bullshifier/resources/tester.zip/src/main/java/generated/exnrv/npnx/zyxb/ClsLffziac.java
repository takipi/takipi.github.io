package generated.exnrv.npnx.zyxb;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsLffziac
{
	 public static final int classId = 211;
	 static final Logger logger = LoggerFactory.getLogger(ClsLffziac.class);

	public static void metKrjqsyrbe(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[9];
		Object[] valUwwgtrdvsip = new Object[5];
		Object[] valOkdyckwtdhd = new Object[2];
		String valHtzkcwxcjan = "StrElleohsofju";
		
		    valOkdyckwtdhd[0] = valHtzkcwxcjan;
		for (int i = 1; i < 2; i++)
		{
		    valOkdyckwtdhd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valUwwgtrdvsip[0] = valOkdyckwtdhd;
		for (int i = 1; i < 5; i++)
		{
		    valUwwgtrdvsip[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valUwwgtrdvsip;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Xnlwlgvfj 7Bdgsmlux 11Dtcdtacsywhd 9Vkwofpzghn 5Ctmyhy 7Wnwumjyb 3Jure 6Ogkigwm 10Gexlwejbyoq 6Myhcrra 4Mensm 9Mvdiappxas 7Brgbngdy 5Izutuv ");
					logger.info("Time for log - info 4Eqosw 10Ckeairlzjzs 4Nrbii 6Tqwkmkt 6Ztyuiju 3Apzj ");
					logger.info("Time for log - info 11Esfbiphfoggn 6Ckznjru 7Ucjrctos 5Khfysz 10Jsgtkmfnpxx 3Rpjp 7Vxiwynyz 5Xelyfk 12Oyhqlhypmafst 9Iesclzgena 6Wcfpidj 7Uojlwvcf 8Exkdauuma 8Xayvfvkhz 3Yyms 7Neqqscqe 10Wpfnijljncz 5Bnulet 5Zbuwyk 9Jlnnyysmiw 5Dwtofo 3Dmxx 12Wskmexhgohtky 5Xxaovz ");
					logger.info("Time for log - info 11Veojdgywayzi 5Jmruyk 3Anvg 8Adntwszyo 8Crklovmjr 7Sxnwpgdr 3Qmkg 6Qojntrn 10Nvlbhvrismk 10Jewrnagbezn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Rzeyhwynvqgl 3Bhnd 7Ovigoyjp 10Byyjfvofhve 9Wlevwejarx 11Rqjvvqbfymyu 5Lefdqv 6Yzkwzal 3Mmgg 12Qqwgwpzrblllj 6Nqogmfx 12Pijcoicboizyn ");
					logger.warn("Time for log - warn 7Elfnlhzy 4Slgwb 8Jhyoplpbf 12Ybvbucjrqwnab 4Fvbkp 10Ppkpgzmleik 3Hhuc 10Cvfhuqmyigf 4Mtgmh 4Znclm 8Fiybupzap 11Bkibjxxraurv 9Twdabmmmtn 5Eqoiqw 8Ipoeelaib ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lraiq.fcmvy.qwp.rkzex.eokht.ClsJupuz.metYgzcykugupxev(context); return;
			case (1): generated.mvh.wsi.ClsXxvtrnameonpg.metGcmnvyet(context); return;
			case (2): generated.dyn.peov.bqa.fptp.ClsXhblgjpkehiigi.metEiaaqrx(context); return;
			case (3): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metNvgqnwoj(context); return;
			case (4): generated.cin.hewe.akg.wyf.seuvv.ClsFgxjhcrdocnyas.metKhzutma(context); return;
		}
				{
			long varPhemdaexxbg = (7219);
		}
	}

}
