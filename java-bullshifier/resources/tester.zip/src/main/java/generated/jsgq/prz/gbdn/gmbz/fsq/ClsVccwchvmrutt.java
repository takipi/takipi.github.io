package generated.jsgq.prz.gbdn.gmbz.fsq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsVccwchvmrutt
{
	 public static final int classId = 399;
	 static final Logger logger = LoggerFactory.getLogger(ClsVccwchvmrutt.class);

	public static void metCkwhkgpby(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valTcuhsjxhfai = new Object[3];
		List<Object> valJebfkhvlflh = new LinkedList<Object>();
		String valAchkbgxvcti = "StrTqafsrhryjv";
		
		valJebfkhvlflh.add(valAchkbgxvcti);
		
		    valTcuhsjxhfai[0] = valJebfkhvlflh;
		for (int i = 1; i < 3; i++)
		{
		    valTcuhsjxhfai[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valTcuhsjxhfai);
		Map<Object, Object> valXmgvmmwmoqd = new HashMap();
		List<Object> mapValDydhhtdqpun = new LinkedList<Object>();
		boolean valJomdovfpjvi = true;
		
		mapValDydhhtdqpun.add(valJomdovfpjvi);
		
		Map<Object, Object> mapKeyBlilfooprdl = new HashMap();
		long mapValTflwrydvbdl = -6778190998721075249L;
		
		String mapKeyCfktinxyhqg = "StrVwrsqutndgf";
		
		mapKeyBlilfooprdl.put("mapValTflwrydvbdl","mapKeyCfktinxyhqg" );
		int mapValRfdbgxwjkor = 196;
		
		int mapKeyHwhkqjdgmps = 57;
		
		mapKeyBlilfooprdl.put("mapValRfdbgxwjkor","mapKeyHwhkqjdgmps" );
		
		valXmgvmmwmoqd.put("mapValDydhhtdqpun","mapKeyBlilfooprdl" );
		
		root.add(valXmgvmmwmoqd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Zwxqhnyddrvde 5Klkxny 3Jrrn 12Cmogpnyveiynt 8Ydtqqkfqr 8Ojlacrnlh 12Vxdkdkhnfzgaw 12Ptdfdgnxjmibc 10Ybyudxpnoaf 6Ouwraun 4Uihtl 4Icdhq 9Nkztlxmiyt 6Vzinptt 6Nrckjcz 4Mmzou 3Bcwy 7Esbrjlop 12Xseufmfklclrh 4Ffoiv 11Mifvmwdxxzxo 3Jbqv 4Itqsw 4Iwamz 11Xsugrzcapyfa 11Egvjsqqswbqe 12Dldvhhhqnhkvi 11Vkojtrumouwl ");
					logger.info("Time for log - info 9Pjhkihwlqk 5Irvexn 4Fakgg 12Rcmqkzhmbtsxi 12Iowepoqxppabk 4Gerhi 8Lkblqwjsa 9Mdutgrxeob 8Eutkegmzt 3Lyso 8Ekbznmyiq 9Nakgdulcvg 12Jatrmzgxslcvd 9Gbfxffgqth 11Skczhonlpjfu 6Dsschno 5Jsrjhi 5Nxphqk 8Rrrbmtxon 12Yojvvrxkiuvrx 8Klzmbtkwf 8Pdkjnmufn 12Aesofrpqbrogb 7Dgfooyqz ");
					logger.info("Time for log - info 12Pdlznefjxzuxy 5Yaqqet 12Rcbikswydrnyx 12Bmttejetvikye 3Sutg 5Arbkou 5Qvdecu 7Flqlefym 3Pepx 6Whwiyqq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Xjtzwqgaoucv 11Qhnpfelrvrll 3Ehnb 6Lquaxja 5Iilwnd 5Djqylo 9Wtdtmtkjwk 7Xlecerzf 8Mfafuwlqx 5Mjjmfc 3Vlei 4Vjzhm 5Gxitnw 10Aaidshbheuh 10Kaexenfwils 6Nplekmb 6Pzzscim 4Okjhv 7Jcspruzh 12Xrmielceybemn 5Wqguwe 9Msphuficfu 5Agvseu 9Wuvmpaokuc 5Shzxag 11Qyjavpdmltab ");
					logger.warn("Time for log - warn 12Bsvukqevpbgfi 11Eeftqgqqtjox 4Jmqol 12Qturjffmrfudq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Tzxaiikc 3Asnz 11Fcdklzwobekg 6Gfzsrot 5Qiedga 11Vhpuglajhuxg 4Dnccg 7Vzzazskx 9Bqtrbifguz 9Mccslcbpiw 4Phaxx ");
					logger.error("Time for log - error 11Bghmndrkglmv 6Xdvtbly 6Mqvrjto 9Dapzqdfwdr 4Fhbza 8Byloutrey 6Immpymz 4Fxgiw 11Bbtsreecdisz 7Beidrwoc 12Lcbrsvvzcxbpf 3Ropx 3Bycm 10Sxpuhllgrbo 7Qocppphj 9Lppcxzhdhk 11Xrtncsqdzmhf 8Frdboutpi 6Skyhijb 3Dtut 11Smsjwwmlimkm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wspiu.cmqv.pvdxy.isdgi.ljwn.ClsZpnvzubxm.metXtcjjfosrwkks(context); return;
			case (1): generated.psl.vgj.rgm.ikl.ClsWqomoi.metLwbkg(context); return;
			case (2): generated.owqo.mlfkn.xvo.nivs.zcmac.ClsNuoghbmezp.metAcpodlmg(context); return;
			case (3): generated.ayxg.baac.ClsIciuzantocwhkq.metBmijwhb(context); return;
			case (4): generated.hjt.myuvv.hkc.tfpi.ClsJfukwmizredp.metYykvllrlskhqw(context); return;
		}
				{
			long varAlpzlzqceog = (9199);
			int loopIndex26749 = 0;
			for (loopIndex26749 = 0; loopIndex26749 < 511; loopIndex26749++)
			{
				java.io.File file = new java.io.File("/dirBcdterlzhha/dirVnwwajllmad/dirKsgyrrjhwha/dirYpbfjcqezcs/dirChasglvcoiw/dirUukgnubdukh/dirYhapyzwzupu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metJtnvvvb(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[10];
		Object[] valIlcbdsifxzn = new Object[5];
		Set<Object> valNqqhaqhrpuf = new HashSet<Object>();
		long valVrtmuamyubb = -3046962117564610345L;
		
		valNqqhaqhrpuf.add(valVrtmuamyubb);
		long valXmjljpammna = -1030939505745094369L;
		
		valNqqhaqhrpuf.add(valXmjljpammna);
		
		    valIlcbdsifxzn[0] = valNqqhaqhrpuf;
		for (int i = 1; i < 5; i++)
		{
		    valIlcbdsifxzn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valIlcbdsifxzn;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Xahulbfjqjp 9Epkanplgip 3Bzyx 11Sirggmmgkqgm 9Hmsqobhxcj 5Jdawjf 11Kevlyhrywhmw 10Rtgzeejcwtj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Sehmbamg 3Xatf 9Zkbxjywuty 11Bjtinipgarqh 8Btpmevjdx 11Jtguvhpxdhuh 9Uxvxmitflm 10Lrylihoyrwr 7Kzclrlbw 12Wndqsmcumhtqf 10Mzelhljrlxy 3Zrjk 11Fftjfavtytye 10Ibexyubgkih 9Noemhhrcrn 8Ysiflixcz 6Xwcsqjr 10Wqjcvzguhdf 6Ojkoowg 12Oqalndeevdsos 5Opnrfp 10Khqbyrisyof 11Hngmpcgegwol 12Qrdqsfqbotqsy 5Kdvuty 6Rkxqjfx 3Raxz 9Obqpfkauwd ");
					logger.warn("Time for log - warn 4Klssw 5Jamghe 3Succ 10Qqxbftlmxmf 8Efvcvfpof 7Kpkpwgxj 6Pyodaat 11Ayccqempbjjw 5Lpxkfx 9Xnnutyaoic 8Rjmerdslb 10Rqyzilblqnv 5Ptdtoi 7Xstqrdww 12Uoaoegcvftuux 11Cfdyjlbgetla 8Etaizrrba 3Zxhk 5Rwexky 7Xrfzqnzf 9Pplikbwfyw 10Ofunxavsqxe 6Gxjioio 9Awhbqdvbly 8Vwdkfdttj 12Aqpmwsmimegkw 11Tkoojsbpmfab 3Tolr 7Ibijgscu 5Evbuma ");
					logger.warn("Time for log - warn 6Qjxyvtl 7Coekhkyz 10Mexmquxtfgy 11Vjylsjyzzhev 9Lsfozqttgn 9Yvtkbtkhxu 5Lbhozg 11Dvrqtyifpshn 6Ryiwqeb 12Sheyvjgdnazyk 11Ciohltzlgmfw 4Xdtqz 8Bvwesbtjz 12Kurefjzifnuzu 11Sqtlwoqakhqs 7Gyllttli 6Pzarvir 9Evneoslidj 9Rplavjsbud 7Qzbwzzfn 8Vmqphessk 8Rvpuyolqz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Hxdde 10Ozvispxgkcb 6Cydmtmr 11Hthnacyjpiih 7Wyofnpkn 5Fxwuin 12Aisxywgegubvc 10Icjjtlaudcq 4Gmuge 5Xehdaq 4Xoqcq 12Pdhlevdygmzja 4Ysvig 8Btjtoluyo 5Snmdhu 7Pqpplisl 3Cwni ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.epi.quvm.dwt.ClsQoovjnirkdxzq.metKbxmlzjrkdplxk(context); return;
			case (1): generated.tjmm.euxn.jmtp.ClsNhugjkj.metQafbogfqlngiyk(context); return;
			case (2): generated.wtc.bgb.gahv.mul.rts.ClsUeuxdzs.metPhxms(context); return;
			case (3): generated.dyn.peov.bqa.fptp.ClsXhblgjpkehiigi.metEiaaqrx(context); return;
			case (4): generated.rorl.wuo.lqgdf.ClsUltodfmiuq.metLlgpt(context); return;
		}
				{
			long whileIndex26752 = 0;
			
			while (whileIndex26752-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex26754 = 0;
			
			while (whileIndex26754-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
