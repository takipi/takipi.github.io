package generated.mipzp.qfu.axrt;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJkbbmhkrxeo
{
	 public static final int classId = 317;
	 static final Logger logger = LoggerFactory.getLogger(ClsJkbbmhkrxeo.class);

	public static void metJhzcshfps(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valDzwxhmllarq = new LinkedList<Object>();
		Object[] valMqtszjgrfng = new Object[2];
		long valJtxdmeljukm = 8917328955657653766L;
		
		    valMqtszjgrfng[0] = valJtxdmeljukm;
		for (int i = 1; i < 2; i++)
		{
		    valMqtszjgrfng[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDzwxhmllarq.add(valMqtszjgrfng);
		List<Object> valXmuialwlofv = new LinkedList<Object>();
		int valShtwgzkagrf = 323;
		
		valXmuialwlofv.add(valShtwgzkagrf);
		
		valDzwxhmllarq.add(valXmuialwlofv);
		
		root.add(valDzwxhmllarq);
		List<Object> valCwaymdlmvld = new LinkedList<Object>();
		Object[] valUoqmcyghtwl = new Object[7];
		long valBwhafcraeua = 9044942349148494008L;
		
		    valUoqmcyghtwl[0] = valBwhafcraeua;
		for (int i = 1; i < 7; i++)
		{
		    valUoqmcyghtwl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valCwaymdlmvld.add(valUoqmcyghtwl);
		
		root.add(valCwaymdlmvld);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Skwwh 3Rnnj 6Qulqeqr 12Pcmgiqulubplq 6Kydbhoa 8Qnduxgfnq 7Bkrezeau 3Xqug 3Osli 11Nskiprwgdwyl 5Xnubch ");
					logger.warn("Time for log - warn 5Uyulso 3Luli 11Qkkoehzpxyyp 6Xtqooee 5Nvladx 8Lkbwstvad 9Gpxtwmohyg 7Daiqbhaa 5Gjjtui 9Kthtygfpfx 8Zdkhbsrcy 4Knbwx 4Dvpdf 12Xngznaxukliwx 12Hsscvtwybxmxg 4Amkcg 4Nfehl 5Whtfln 4Yvlnn 7Kqgqkkpf 12Towxzetgksbta 6Tytxuba 6Oaeijkg 9Qldiezwgba 12Fhebtosuieyms 10Tpxrtuvfraj 9Vyegwaofyw 5Oarfrz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Zopnql 5Oxslba 8Bpihcvcmy ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zdn.ayby.ClsMelkmphvwjkgwh.metAcvmturnoh(context); return;
			case (1): generated.tkix.xwxmn.tohx.ClsStsup.metKaytjwbtsoqycs(context); return;
			case (2): generated.yhl.ykh.hog.zsc.cal.ClsJuxvzfsp.metNbicj(context); return;
			case (3): generated.zfo.wctt.rjxf.wjfcy.ClsKuhcjj.metXghvhmjkczsxr(context); return;
			case (4): generated.pfjp.usowt.ClsIsioyesmm.metWvpjrpagibthng(context); return;
		}
				{
		}
	}


	public static void metUvsxqnes(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valFluunmniijd = new LinkedList<Object>();
		Map<Object, Object> valMczkynfxktz = new HashMap();
		int mapValIwqugadvovq = 190;
		
		int mapKeyCjifjwwbuuq = 349;
		
		valMczkynfxktz.put("mapValIwqugadvovq","mapKeyCjifjwwbuuq" );
		
		valFluunmniijd.add(valMczkynfxktz);
		Set<Object> valNtlrpdefyzb = new HashSet<Object>();
		boolean valEietpeqqkrr = false;
		
		valNtlrpdefyzb.add(valEietpeqqkrr);
		boolean valPqjprvkhmgj = false;
		
		valNtlrpdefyzb.add(valPqjprvkhmgj);
		
		valFluunmniijd.add(valNtlrpdefyzb);
		
		root.add(valFluunmniijd);
		Set<Object> valDntikugxouj = new HashSet<Object>();
		Map<Object, Object> valYhihosngkxi = new HashMap();
		String mapValLagazhqqavb = "StrSejwwukdabl";
		
		String mapKeySexxhjbpcef = "StrMcnkzuvsqwo";
		
		valYhihosngkxi.put("mapValLagazhqqavb","mapKeySexxhjbpcef" );
		int mapValPhecrwjghrj = 664;
		
		long mapKeyFxplboddfwq = -3765062512726114356L;
		
		valYhihosngkxi.put("mapValPhecrwjghrj","mapKeyFxplboddfwq" );
		
		valDntikugxouj.add(valYhihosngkxi);
		Object[] valVsemfrxwihs = new Object[2];
		int valQekxtfzhryi = 9;
		
		    valVsemfrxwihs[0] = valQekxtfzhryi;
		for (int i = 1; i < 2; i++)
		{
		    valVsemfrxwihs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDntikugxouj.add(valVsemfrxwihs);
		
		root.add(valDntikugxouj);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Jyyjlxqpxrb 12Daulybhayqlvo 12Zmhifxqrhkgfy 8Qqzxxzddb 8Gbrkmnndg 10Wufzotrjwcm 4Wtonr 6Jvtnhle 12Wlbkqvznfaxtj 12Uagagtnyuiidu 5Msqyff 8Kudhzxuik 4Iczni 10Zmtqglnlriv 8Xpgzixdeh 10Krvfxolrtpf 10Ufyvqxbnzdv 12Jxnbagfzuuyqi 4Wcwvw 4Wxkmx 11Fvpdghhcriii 12Foxjlphtddjvj 6Psjekld 5Ymgjdp 4Tdwun ");
					logger.info("Time for log - info 4Nifco 8Ayvkhzruy 3Iecx 4Mawxv 9Schgagbihd 5Athqry 3Fnlc 12Ymsjeklknefvm 6Pnkstnu 8Vncpvnuns 7Afrjubns 12Wobzxnszouvkr 5Mcaizf 9Grqeidpjsg 11Vnyqxgkrajkv 3Zwst 9Crmqpfomzt ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Dpqsh 9Gzejssjwhv 6Wecugmp 3Psth 12Bpkbjogchdmvh 12Ghjwegjgevucu 3Xovf 7Ymjjsuef 5Mzlloz 9Llzqhwnkru 4Qiuxf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Nueoa 9Ectzihykoe 5Bodmfy 6Udukhhi 9Cveftzgjqc ");
					logger.error("Time for log - error 12Vbtwngbtubdln 5Tfhqdl 3Wkie 4Iobpw 4Qygkh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pfjp.usowt.ClsIsioyesmm.metEsxosbsfuwm(context); return;
			case (1): generated.xmh.glm.nii.qvkag.ClsSkjzsax.metIapnggnlwqhv(context); return;
			case (2): generated.ryyqn.hafq.oqfv.ClsRsktinox.metKcbbyaslqqejp(context); return;
			case (3): generated.oucap.zcbrm.jbhm.yte.ClsEpzgpbjqjhr.metMcvlpssn(context); return;
			case (4): generated.tbf.qnyk.tdd.dnbuc.fexg.ClsFiknxpviyjlxbx.metEnugdn(context); return;
		}
				{
		}
	}

}
