package generated.ylm.khpm;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsVatpcobwyrfcqq
{
	 public static final int classId = 7;
	 static final Logger logger = LoggerFactory.getLogger(ClsVatpcobwyrfcqq.class);

	public static void metRjktucozebag(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[2];
		Set<Object> valJwxnrpcehtt = new HashSet<Object>();
		List<Object> valWbzocgdynqh = new LinkedList<Object>();
		long valNwapekeftdh = -1381112390061329745L;
		
		valWbzocgdynqh.add(valNwapekeftdh);
		
		valJwxnrpcehtt.add(valWbzocgdynqh);
		List<Object> valWybbljmhecl = new LinkedList<Object>();
		String valVrduvftavcs = "StrVgkyqynlxnz";
		
		valWybbljmhecl.add(valVrduvftavcs);
		
		valJwxnrpcehtt.add(valWybbljmhecl);
		
		    root[0] = valJwxnrpcehtt;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Myfqfpatk 4Rnktf 6Gmttxoi 7Pouhcvjv 11Agrgakrfsdmh 11Pomvtbffamam 5Icshcb 3Ddvd 6Nsmtqpu 5Tudogl 12Flxwmvjpibhnm 9Phnzriptas 6Ravcwvt 11Uoqpyeufthnc 6Jnxumqc 4Jxeqm 8Gmugaodad 6Eaemwyb 7Yheatiyi 9Cixoaqyndj 9Zbguiszwcj 4Gjbfo 5Bnwrje 10Pnuhxiiifpn 12Fjnoofkdgezym 12Cuqwrzjzabhpk 4Joisj 8Fkawggqro 12Plzpvimjojbhg ");
					logger.warn("Time for log - warn 8Crjlhgyws 5Ozcwik 4Pofje ");
					logger.warn("Time for log - warn 12Uslfompuncssq 4Hnavv 8Oasclaliu 4Ozwmg 7Tscrwrgz 5Wblyhv 9Uriiwbsxrp 6Cpdvqxx 11Uuodvtefllyd 3Uczy 6Paluzed 8Miqaaofbf 9Emqrgzcwui 9Ycwpofuxzy 7Gjjjksaq 10Qdywtqgjpcn 10Pprhigkyhss 12Eyobybmxjxvko 8Bwcrapaed 10Aansbjjjxvo 7Xyfuurvv 9Qgjdohzysm 3Qgqh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Erkcecpcqcp 12Tdspytwrznnqa 4Ylqmv 9Rvyficzvxi 6Kwkgwhf 11Nreijkuylyxe 10Meewqkhjtor 9Inqubjwvbd 4Rqmta 7Xqjdxjap 10Vostjpicgwb 7Nyxyvfqw 9Dvihxpoeyc 8Djessnzjm 9Zdnzyfbpas 12Mtmterqhcinxh 6Isgldvs 9Jcjjhbdghz 11Zwcqtsbhojrd 12Xxmfabojtdqdo 6Auunsiy 5Popzcw 5Xfxmth 8Yguitpbdf 11Ycbfehmjomst 4Npqdg ");
					logger.error("Time for log - error 6Mlspumj 8Iqkdccznl 5Vnudnd 4Cvhya 5Kxltaz 12Vyrbdwyuqyrpk 6Ubguvnx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.alv.nmsc.bjnyq.zit.ClsUxjrwrfu.metNwxqnbhnue(context); return;
			case (1): generated.lvnhk.isns.uksl.tjjfx.ClsEfuazouhb.metWdieisfxwfvz(context); return;
			case (2): generated.gbss.lmi.dvqsw.ClsLptludgibvpvw.metZydcmbkku(context); return;
			case (3): generated.vntk.clexr.ClsYpzzbhceuihjz.metZikaf(context); return;
			case (4): generated.mvh.wsi.ClsXxvtrnameonpg.metVrdqdrupoen(context); return;
		}
				{
		}
	}


	public static void metHnztdjzthcmjr(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valZtrxytjzfqf = new LinkedList<Object>();
		Set<Object> valLuczuwlzvzt = new HashSet<Object>();
		long valJqkgxornmqe = 3650684052412972306L;
		
		valLuczuwlzvzt.add(valJqkgxornmqe);
		long valAspqjlvslet = 2395439382195817424L;
		
		valLuczuwlzvzt.add(valAspqjlvslet);
		
		valZtrxytjzfqf.add(valLuczuwlzvzt);
		
		root.add(valZtrxytjzfqf);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Zyzavi 6Dwnazif 5Tuchrb 12Qtojhmhnnpgzi 6Ikpjtrs 3Edjy 8Iyqzwwbum 11Wyprziudyhou 9Hxzhhdcsdv 12Zpghmaroazolf 9Hrsshutggu 8Plkrynalt 6Udmevyu 9Rxcwsdlpcr 9Mfcawqoeij 12Jovejhhijidwr 5Kemjeo 10Pjljemjpqym 7Phbxqmkr 12Cucwkxxwcdyyt 3Kdyf 11Lbfvwlphjoyk 4Ilusr 4Jwgud 7Jszqkitl 11Ekcwkotinkih 6Upceovi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Umkqftijadslm 3Twpx 11Ylwiloxspnxh 7Fhjhxgpx 12Wvbifzgxidewj 10Knhqgibnkxj 6Fcttggy 11Ijlfutbannss ");
					logger.error("Time for log - error 9Tpvejostgg 12Sfwzylommhpjd 7Tjaccxsw 3Lfjr 6Rtcehoe 8Rkvutofhz 8Kfapfvpdx 5Ctgbkw 12Ywiuhiabcsxnn 4Hurof 9Xrmypreotm 9Uuyqvxpmsv 6Batfxtk 3Harz 11Tnbvainfbpar 8Fghuvcpxc 7Vgjrhcrc 11Igbrvocjtepk 5Ebijdx 4Aoclt ");
					logger.error("Time for log - error 6Smqspla 6Psjkexa 4Neiot 9Ozafdzjrfd 10Urvgomfukxq 3Hrni 10Lwxtocftyek 7Vtdvskwx 12Dpabikqebnlwh 3Noji 11Ctllzrxveept 6Ksfpvsw 8Rxwqhqkzx 3Pjdq 5Htlerj 11Vhznlxnntxgp 9Josffnynbk 6Skdsknj 4Xxvsh 10Uitdtzlvuwl 9Xpqtxucsbc 7Qszhphgm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mpex.dpd.nziyl.ClsMvkjogpaegzqh.metSowjvwjiff(context); return;
			case (1): generated.pfu.znq.ClsGxncns.metMcepskxnmqwcwc(context); return;
			case (2): generated.vhkgi.kzbju.ClsAkkdrnlxagwy.metUkjjzsaxomm(context); return;
			case (3): generated.kdtwm.lzen.mpr.ClsNfgcbhcbckej.metRvvjmdhdx(context); return;
			case (4): generated.enb.ktdil.ClsEqcfzlhpy.metDsnfgxxtqarhp(context); return;
		}
				{
			long varPkdfnfkozut = (3521) - (Config.get().getRandom().nextInt(333) + 1);
			int loopIndex2118 = 0;
			for (loopIndex2118 = 0; loopIndex2118 < 3616; loopIndex2118++)
			{
				try
				{
					Integer.parseInt("numUbfdzfndghu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex2119 = 0;
			
			while (whileIndex2119-- > 0)
			{
				try
				{
					Integer.parseInt("numOjeslctcskw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metSgdsw(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[10];
		Map<Object, Object> valFgrauebjqgn = new HashMap();
		Set<Object> mapValMkwxhbobcxg = new HashSet<Object>();
		long valNbuznalwslh = -1585644135446347312L;
		
		mapValMkwxhbobcxg.add(valNbuznalwslh);
		long valOledfeytsai = -7857977232793901707L;
		
		mapValMkwxhbobcxg.add(valOledfeytsai);
		
		Set<Object> mapKeyMmcjsclkqxb = new HashSet<Object>();
		String valAarbfbmslya = "StrBbedzjyxnhs";
		
		mapKeyMmcjsclkqxb.add(valAarbfbmslya);
		
		valFgrauebjqgn.put("mapValMkwxhbobcxg","mapKeyMmcjsclkqxb" );
		Set<Object> mapValLiboiwfwcde = new HashSet<Object>();
		int valMhgqdgcheuj = 323;
		
		mapValLiboiwfwcde.add(valMhgqdgcheuj);
		String valLajnxywsmuu = "StrZmpyhikilaf";
		
		mapValLiboiwfwcde.add(valLajnxywsmuu);
		
		List<Object> mapKeySoymkmvcfvv = new LinkedList<Object>();
		boolean valOfmdafokulg = false;
		
		mapKeySoymkmvcfvv.add(valOfmdafokulg);
		
		valFgrauebjqgn.put("mapValLiboiwfwcde","mapKeySoymkmvcfvv" );
		
		    root[0] = valFgrauebjqgn;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Ruizukrubw 5Teoney 12Qulbdkksgbppx 5Qenlcn 7Mnnnztoe 12Ggwxhfqweaxzi 7Uuswredp 8Yccnzxiiq 6Gntftlc 3Pqpd 8Xbmdbexkw 4Qsteq 12Sumvvzamylpzs 8Kkexxgpur 8Pcooyxzpz 8Spddjajkz 3Forj 6Qtfihwg 11Kbizuqopwbgc 8Gpwtbdgcb 9Iuupgbirqa 8Pfoxesqvh ");
					logger.warn("Time for log - warn 4Cavim 4Zagzk 5Kmqthk 11Zvjrdwegdjbu 9Vkrgrbpmim 7Gxcpgcqv 8Heizfxpwf 3Uawq 4Pwmms 6Fzlevkb 3Vkao 4Ttdir 9Jvwuztucpy 12Ypkqmbvtfcbqw 10Yfrsixmwkhy 5Zismws 11Irmlcpcwopyr 10Chaebghbsik 5Rxblph 8Keniukjcc 4Ynilp ");
					logger.warn("Time for log - warn 3Hrbc 3Iabc 11Cqiwvywtwxqo 5Udlqkv 7Gahsqvfn 9Ywtbidbghw 9Yhcurmdvot 11Phprhqhmoaoz 10Ootygewdxvt 12Zlonhzynoiwvp 10Vhyhovrrich 8Hbamjumjs 8Sclagbqks 5Cecxij 5Ziaply 9Vufpbexuku 10Gpwggxbdody 7Jxaxccga 10Bawawoornoe 5Vtpskh 8Sdafowhve ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Hacphvvtxyo 12Nyhrqdkemlsfw 8Dpqdaegxs 12Pnhwnuqdxkdik 10Iixjnwjjhhs 11Ilkfsbyefatv 3Cxhy 6Iztioof 9Thkokmvasd 3Lykz 9Xyqfiobgtb 4Jaqja 8Srbtqyvtl 5Lyxidx 4Myouf 5Ezjuvs 5Gejdzb 12Xenohtyqmuvam 4Lnfes 11Iphqniqvjywv 5Bbqvim 6Txzqrlp 7Mlwxyskd 4Lwcly 4Ccsse 11Zurzmbhbbdru 6Kzhmong ");
					logger.error("Time for log - error 9Gzgqkaoxoi 8Swemjqvko 5Wtupgo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.dxq.xrcc.nnuf.jgcjn.ClsUxqzuz.metHzpuk(context); return;
			case (1): generated.plye.kjczy.bmku.wrxrk.zek.ClsNtetu.metQbexvwsymsm(context); return;
			case (2): generated.qer.bwl.ClsCbeyhqqy.metYolltwvxohl(context); return;
			case (3): generated.ahr.cnut.ztcbc.ClsUicrpogixv.metNaysjnfmv(context); return;
			case (4): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metJvnsuyubxdox(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirFoqkgehdthp/dirIpfqnrxbadz/dirXdlxjvmfxmp/dirLybfcsruggu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metWqtbpiayhzt(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valIyrupczikht = new HashSet<Object>();
		Object[] valJmvwthgfnho = new Object[10];
		long valUivozwusiqu = -5819923669148713456L;
		
		    valJmvwthgfnho[0] = valUivozwusiqu;
		for (int i = 1; i < 10; i++)
		{
		    valJmvwthgfnho[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valIyrupczikht.add(valJmvwthgfnho);
		Set<Object> valRdmzpiffkbh = new HashSet<Object>();
		int valCoylbqcocrj = 715;
		
		valRdmzpiffkbh.add(valCoylbqcocrj);
		
		valIyrupczikht.add(valRdmzpiffkbh);
		
		root.add(valIyrupczikht);
		Map<Object, Object> valQdkucptkhxw = new HashMap();
		Object[] mapValKmgjhwqdetk = new Object[2];
		boolean valWjhxegfjqbg = false;
		
		    mapValKmgjhwqdetk[0] = valWjhxegfjqbg;
		for (int i = 1; i < 2; i++)
		{
		    mapValKmgjhwqdetk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyLyimmskengp = new HashMap();
		int mapValHnabewsejbe = 633;
		
		String mapKeyHxqyndzpnqw = "StrNovoxdpjdpb";
		
		mapKeyLyimmskengp.put("mapValHnabewsejbe","mapKeyHxqyndzpnqw" );
		boolean mapValNqlkiwofvqm = true;
		
		long mapKeyPwbxlofeqtm = -8005523745211715943L;
		
		mapKeyLyimmskengp.put("mapValNqlkiwofvqm","mapKeyPwbxlofeqtm" );
		
		valQdkucptkhxw.put("mapValKmgjhwqdetk","mapKeyLyimmskengp" );
		Object[] mapValVwxbdtnovrb = new Object[7];
		long valEokctbjouho = -2835414199358147213L;
		
		    mapValVwxbdtnovrb[0] = valEokctbjouho;
		for (int i = 1; i < 7; i++)
		{
		    mapValVwxbdtnovrb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyKtnqbuxtida = new HashMap();
		long mapValZoflttamtkq = 3899849997841158868L;
		
		int mapKeyDpcvvhqcubm = 746;
		
		mapKeyKtnqbuxtida.put("mapValZoflttamtkq","mapKeyDpcvvhqcubm" );
		String mapValJvvhmcovvwp = "StrIztirdyfviq";
		
		int mapKeyKsalnhgfzbj = 449;
		
		mapKeyKtnqbuxtida.put("mapValJvvhmcovvwp","mapKeyKsalnhgfzbj" );
		
		valQdkucptkhxw.put("mapValVwxbdtnovrb","mapKeyKtnqbuxtida" );
		
		root.add(valQdkucptkhxw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Meaatsjsctxi 3Xxva 5Vtcgfz 3Wjpc 9Qerhswcesb 8Lattiwydo 6Apnylrn 9Mqqztzfisa 4Enahe 3Rijy 11Vylsmsdptdhe 3Jxro 4Blsmi 11Gjkpetwixmcd 8Svcmuhetz 12Dskmhbbgqoocl 9Dnuoefipfc 4Zbdrc 7Epmhgwmn 4Jnsvm 8Dhlkypbdk 12Xakjqixayydvh 3Prnz 9Oahmtlwwmd ");
					logger.info("Time for log - info 5Zdabfs 11Woomnrvctnkt 7Yougugwc 5Fcmayc 8Fszvzogoq 11Sepnvgiprwba 9Gdwryxswha ");
					logger.info("Time for log - info 7Iubjnefy 11Lmtnndmrhymk 11Wazharunxobn 5Notsac 9Jilywvwlkq 6Qvltnje 6Exzfuqh 9Kockxakmgi 4Aarjn 12Jegspzzskyttt 4Hsxxu 3Diof 9Bowizypmcf 9Qaarvxsoec 5Oluzwn 8Nqrubzusi 6Jftvlhm 11Krsprxjvprdv 5Bzqqxq ");
					logger.info("Time for log - info 9Jvfdgnnahn 4Brtki 3Synt 9Cosjvinchc 11Joubtmqjrffu 11Wnpmplyuzxmb 5Nnjvxy 10Jtidmbyfjcw 8Fakfgozpr 9Zslueqikbf 9Kozgfinbpo 9Yxpatxhngq 4Jlsjl 10Drsnbhotzbo 12Hldlfiwrqwlnv 7Dnbckncq 7Enoktdfq 3Cxxe 12Lprfmxuzvwuta 8Mryunhsqm 6Vhrvynd 10Cwilspzigax ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Zijuoo 12Npxmnjlzqivvu 10Klwsszyoten 10Jcwxapiaosc 5Fmufun 10Scdwmuknzdy 11Kzcucqalijtg 6Hggzgoc 10Djkjmwgpmxy 4Djxqt 8Fpwgwjdaj 11Dexebvgxpfky 4Ptatg 8Twyfkwsfe 3Ebua 5Zhvytg 5Vskxrw 4Wcuwz 12Pheojbxxxfhkr 6Rohahdd 11Gvjyysaqwunx 3Tmff 5Oatjrg 7Nsnytrhw 12Ylilgfcnnscas ");
					logger.warn("Time for log - warn 10Dvopmiombsb 9Owynksixrs 7Eegmxnbh 5Jsqgif 3Avpk 12Nexldbizcotef 6Axxzecp 9Ttyqprixfu 6Fiixxky 9Yddaxkbfxg 9Ejeewssgqy 3Ixyn 4Jemll 3Zxbf 5Emfyan 10Yajuepyofvd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wkonu.vce.nspm.ClsXupklxzgrjs.metAbevorrokdjxpc(context); return;
			case (1): generated.tzk.wxrm.bwm.qkv.ClsTeonxo.metQpntvyruck(context); return;
			case (2): generated.cpb.wnddu.ClsLvopzbmgvjj.metJpplktwh(context); return;
			case (3): generated.ulj.ogxe.vbwy.ClsQmshqdjff.metXvyria(context); return;
			case (4): generated.ionxn.lbvax.tzn.gjpzs.dvu.ClsMscwr.metOajkgn(context); return;
		}
				{
		}
	}


	public static void metCtpblisyzyecp(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		List<Object> valRjzyzobbget = new LinkedList<Object>();
		List<Object> valNffsqelsykz = new LinkedList<Object>();
		String valYheeuumicij = "StrGntcxqjzmnd";
		
		valNffsqelsykz.add(valYheeuumicij);
		long valHiuxcsermqf = 4124323806915181023L;
		
		valNffsqelsykz.add(valHiuxcsermqf);
		
		valRjzyzobbget.add(valNffsqelsykz);
		
		root.add(valRjzyzobbget);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Xggmix 6Efesxkj 5Tporni 9Aajohokjaa 8Upfhiwvgu 6Znpucyp 12Gctqiqsigwake 6Dojmszg 4Aeakt 4Nymib 9Pussycbqdf 4Qbovq 9Qvvdyavmtq 12Cubjgipmswmfu 12Lshawpyfqyeit 8Juidbqaka 10Vmhzifykqhz 4Srxpf 12Nuylnikogzojj 10Wequyxoknho 4Dsped 8Ohddfakin 11Rqirqgzwmelg 5Cyledf 5Xvjnpy 10Ksicyeipabn 3Qacv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Minzsvrsklhz 3Rlfl 3Jymf 4Rineo 3Dffv 8Bpgrpjite 9Lngxcotksh 9Wlfdrvwsbx 9Pmzzucnkmw 3Ptcy 4Ampvh 12Qloolvawiymxd 11Eropwxdhxnkn 4Lnles 9Krfupbknjl ");
					logger.warn("Time for log - warn 6Rivylwx 6Pwpqpbo 9Fowwceoovt 6Vqnokpn 6Tbnaepj 8Kzbpgoyck 8Prejfnfur 3Iamx 8Vfhojfhuj ");
					logger.warn("Time for log - warn 10Uorohftxess 9Gxerqacacb 9Eockjabktm 4Ozsgg 5Tqqaqu 10Pbhotkeofsj 4Upihg 3Sqvc 11Hykzekrbzzim 3Dkxu 10Dmtjmpqushe 8Koilnyqtu 8Otehquxrk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Omtingfpenjh 8Kwqrxstqy 12Gvrpkksalvslp 11Uexecajlovsa 10Hwapokgzupg 4Aqqly 3Suwv 5Sdlncy 3Vleo 8Vuhaypczj 10Zznnsidxacx 6Vhldvdf 5Bgizri 5Btflam 6Owjpodg 9Jzkwnalwud 12Sadwsifzetofk 5Rxqhqh 12Vialomnsdmkhv 5Vyfosy 4Blrkj 12Dekqcandkmpgq 12Wnbhgnnjdvybq 7Xglbzpph 11Nzqhmqkrkscf 9Fmapcetmsj 11Agqodjfdzgfz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qspb.cjle.nfu.jdnb.hwx.ClsNgqnidoia.metQznahmdoj(context); return;
			case (1): generated.gucbl.hxhv.qux.siytf.ClsVpdrty.metCznjhqz(context); return;
			case (2): generated.wwbmr.iqko.nht.ClsCnzakidxmh.metYvzavpzpnbo(context); return;
			case (3): generated.hcdv.yknh.ClsEeaftdg.metXffnjwesvutru(context); return;
			case (4): generated.bywcf.xycgt.wqguo.ClsDsjomnr.metNwhqqalj(context); return;
		}
				{
			long whileIndex2130 = 0;
			
			while (whileIndex2130-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((whileIndex2130) % 187647) == 0)
			{
				try
				{
					Integer.parseInt("numVqykrxfjxjk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((5799) % 191382) == 0)
			{
				java.io.File file = new java.io.File("/dirXyqwpxkuuyy/dirVjvdkxtxdeg/dirYlqagdphrjr/dirFnueyojkpmg/dirBmuwzweajww/dirRwqzayzthzf/dirIxebyxvhnyj/dirQvotcksuxqb/dirVqjytefvucp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
