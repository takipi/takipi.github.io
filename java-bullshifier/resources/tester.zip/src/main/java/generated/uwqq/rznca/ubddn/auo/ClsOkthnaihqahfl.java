package generated.uwqq.rznca.ubddn.auo;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsOkthnaihqahfl
{
	 public static final int classId = 84;
	 static final Logger logger = LoggerFactory.getLogger(ClsOkthnaihqahfl.class);

	public static void metTosevyjfph(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valJaqriwswzfc = new LinkedList<Object>();
		Map<Object, Object> valYassvbnatvm = new HashMap();
		long mapValHdlkewjnbnm = 8774902844644312558L;
		
		boolean mapKeyPostrucuyra = false;
		
		valYassvbnatvm.put("mapValHdlkewjnbnm","mapKeyPostrucuyra" );
		String mapValSbcyrmfpwvm = "StrBdxobhlcgtq";
		
		int mapKeyUjxnklauwnj = 369;
		
		valYassvbnatvm.put("mapValSbcyrmfpwvm","mapKeyUjxnklauwnj" );
		
		valJaqriwswzfc.add(valYassvbnatvm);
		List<Object> valYzscgamecxr = new LinkedList<Object>();
		String valQyeaghrizce = "StrGxmjdbbyyue";
		
		valYzscgamecxr.add(valQyeaghrizce);
		String valRqfkgxfjfir = "StrGaejzjrwodh";
		
		valYzscgamecxr.add(valRqfkgxfjfir);
		
		valJaqriwswzfc.add(valYzscgamecxr);
		
		root.add(valJaqriwswzfc);
		Object[] valSqiflqoeuvw = new Object[9];
		List<Object> valYjgnxyjbsda = new LinkedList<Object>();
		int valQumpcibzwro = 750;
		
		valYjgnxyjbsda.add(valQumpcibzwro);
		String valLcgtmoszzrp = "StrLsjtjmckilj";
		
		valYjgnxyjbsda.add(valLcgtmoszzrp);
		
		    valSqiflqoeuvw[0] = valYjgnxyjbsda;
		for (int i = 1; i < 9; i++)
		{
		    valSqiflqoeuvw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valSqiflqoeuvw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Ephpf 4Gtrtm 6Dqjujek 4Uupbk 9Nuvwckvsps ");
					logger.info("Time for log - info 10Divjholwrpp 10Tpjbmtmsotl 12Pnfyzoushetub 5Eumjma 4Hfgjc 12Uabmbwnqtnfaf 9Wdylwrijkf 9Oxfjmclfnr 6Cqlrchk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Lfkyf 9Mkkwtgmpux 6Mphrocs 5Xxfcgx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Qqbdtdyhap 3Aaqw 5Hzrdyf 3Jqfg 12Qiprkdwvicgmk 8Nwyecepdj 4Uhxcj 10Uotqtmmilld 11Kkhadpcwlepu 9Qtkakkfwru 12Dlflargtgdnvi 9Jaizyipfgg 8Mhumhbscy 7Hsyrhzfg 6Qhuafch 4Ucptr 7Cqqpkwci 6Isgiyvd 5Dahcpe 6Argzxnd 3Ruob 9Fbvnfyuccd 12Dohtotecykukt 7Asabncdc 3Ntkj 12Hqvpksdxxwyji 12Qhucrizkonvhq 10Xcuijaxeigf 3Vayt 11Efqzgdxyibkh 9Pdaeraxywg ");
					logger.error("Time for log - error 5Nvpskn 9Thvqyqnrgy 3Brbm 5Yvkibi 9Ywwpbxybeg ");
					logger.error("Time for log - error 11Xzriiuxvnftp 7Niqmsmep 11Iureorglezeo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kkpa.egwla.xylej.ryfr.zebdf.ClsUznbtznd.metLeqdeppbikfpz(context); return;
			case (1): generated.lkd.eckd.hdtbd.unse.scvn.ClsCjccpmy.metYcdmbyork(context); return;
			case (2): generated.exb.zww.kausx.ClsMnvrore.metOasbzk(context); return;
			case (3): generated.uhn.nhlo.xwe.qendy.ClsUedsvxy.metTxsoh(context); return;
			case (4): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metSqibhmdisq(context); return;
		}
				{
			long varVmwgngoncbh = (Config.get().getRandom().nextInt(150) + 6) + (2238);
		}
	}


	public static void metLmnxqvpe(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[3];
		Set<Object> valZlvpufdffia = new HashSet<Object>();
		Set<Object> valGekmrjavoek = new HashSet<Object>();
		long valUttrrrureqz = 4680425169007569062L;
		
		valGekmrjavoek.add(valUttrrrureqz);
		String valZndmzpmjaff = "StrLenvmylzkxe";
		
		valGekmrjavoek.add(valZndmzpmjaff);
		
		valZlvpufdffia.add(valGekmrjavoek);
		Map<Object, Object> valGkugocpnsio = new HashMap();
		int mapValFdbowupnsqn = 346;
		
		boolean mapKeySfnhqzsdbjf = false;
		
		valGkugocpnsio.put("mapValFdbowupnsqn","mapKeySfnhqzsdbjf" );
		int mapValBmtrkmhaezy = 146;
		
		int mapKeyTgnosscgfgv = 37;
		
		valGkugocpnsio.put("mapValBmtrkmhaezy","mapKeyTgnosscgfgv" );
		
		valZlvpufdffia.add(valGkugocpnsio);
		
		    root[0] = valZlvpufdffia;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Mpeq 6Qnquplo 9Ikrxorwuwt 3Qvyg 9Skyiojhvri 6Gibngmq 9Jflyhmkggm 12Sxzghcckqhgvj ");
					logger.info("Time for log - info 9Mlodchryku 11Xkvumdqmltat 4Wnghs 5Wxzomf 10Jhfquiylzoh 5Yhpomd 11Bnrhghwtsumw 9Hrxuspyyob 6Oskrwcb 7Frbevrzk 9Nomwohgokv 8Dojmwyzpy 11Oqnqiikoczxc 3Osfg 12Mszdaxdmtapdl ");
					logger.info("Time for log - info 11Qnoayauavqsc 11Ryynadjtxzxe 5Vsjtzt 5Mppqzh 3Vsjd 7Uebnnzhy 5Alicds 3Yfrv 11Hepdrfagmolb 8Ywovgtrax 3Xwqw 10Uzbgccqmheu 5Dhknfk ");
					logger.info("Time for log - info 3Odje 4Gxxaj 10Gxrlimispqf 11Fznypradeqlp 10Vjqcdvpxumd 9Pgzrnudigo 4Rmbde 10Hwevpdkcrjy 12Airpafmvcjfbk 4Qnlya ");
					logger.info("Time for log - info 9Mtuwvveyjm 12Sbyjyetbkmase 6Gbyolaz 3Dzgb 10Unbpeqdyaem 11Jjezizncrmhy 10Hpatljbvceh 8Tgepgisru 8Zrnhyhfrv 6Wciglja 7Ijcyemem 6Zcvdfms 9Dcgwbtajwl 3Tilm 5Csqdkb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Rgqsfpzpehxz 5Byzala 11Archuvqsqzph 9Igsxrcmqae 5Kglymn 12Swrsjapiujnmr 3Krjq 7Kjbfsedv 6Faljtoc 10Qopqyjyhllx 10Vydhhxbtgpk 12Svronjbgztpoj 3Flcv 6Eafpumk 12Zbguztayhsqwg 11Qputtnfokpiw 4Mtlmc 3Htsu 3Vdew 10Vulxxajzgen 11Edqynnqiqwjz 4Kjuvm 9Xmjumqoumr 10Esoedthepwf 6Dvcixwb 6Iccgjuv 5Sanndu 8Hdzjavtnx 4Vxhqr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cwxj.lmfzj.egfdm.ClsTwbdwdairow.metOcaxrekk(context); return;
			case (1): generated.yudi.kwckr.ClsDwmxwqmygi.metNppyrlnbpx(context); return;
			case (2): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
			case (3): generated.xam.emsw.ClsNwmpfankaxgqb.metVftvklava(context); return;
			case (4): generated.nmwme.qnfne.zsgam.zytf.yqrto.ClsDkqpghfzzf.metLrvrrwj(context); return;
		}
				{
			long whileIndex21490 = 0;
			
			while (whileIndex21490-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metJezqzyduxos(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Object[] valSgssmrqgrgg = new Object[3];
		Object[] valRbkplgabemq = new Object[3];
		boolean valGnqdsvikckm = false;
		
		    valRbkplgabemq[0] = valGnqdsvikckm;
		for (int i = 1; i < 3; i++)
		{
		    valRbkplgabemq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valSgssmrqgrgg[0] = valRbkplgabemq;
		for (int i = 1; i < 3; i++)
		{
		    valSgssmrqgrgg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valSgssmrqgrgg);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Vymzqu 12Clciycyzwevtm 7Lgrewbve 5Qpmqkv 3Usgc 11Egyzgfkpytdt 7Rpkspqna 6Enftnel 7Txbqlfbi 8Ascmgatpm 12Ftwppedbdzrie 9Hyxktycgow 4Rsptb 9Txcaakfbih 7Oslcodnv 9Avdhgwjuon 6Irfpgpp 9Olheiaeboz 7Pzvihxac 9Vciqwtrrht 4Obbdu 10Csvzickoeue ");
					logger.error("Time for log - error 4Rjerm 10Nplohykhmsw 7Ictoonta 9Rtohfcntng 10Jenydutmwiv 9Sasletqufk 3Svco 6Irshwkn 10Xymnyuhkmjy 11Kshnimqoxgta 7Jrifvbeg 6Smfgfde 5Yttrud 6Puuvqmy 6Yrjsixo 4Ugvri 6Xvpomhh 4Vjedq 3Ngej 12Rqhljxyuoiadv 12Qzvaehetvedsz ");
					logger.error("Time for log - error 8Oyqqgnhzn 10Lfozjyrtopp 10Tjbymrucpll 3Nbom 12Ntuntmyzrqfgd 4Jsnjg 10Rxyufbozlgo 8Vtcrerenp 8Jbkojhnoz 6Srpmepm 12Immcsstryhsri 11Uasirhcbwqoo 5Zbofar 4Mdngx 9Diunfhwcga 11Feihghvivfsm 6Gfcihff 7Wjafgddo 5Ielogb 3Igwi 7Ltxmmmmv 9Zjbqtbnrpo 11Exgvmwrhjiqn 6Nktrcyr 5Petvlt 9Pqaupqceqt 11Glcovpnfhwno 9Alqpgexdvp 10Swfbbkzfzig 10Jedgtcqnjsv 9Mnpopgykyt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kqywo.pil.grw.dvt.ClsJduhsebfba.metPsnsdnegsev(context); return;
			case (1): generated.vcamv.yhh.ynaoh.fpbp.ClsCmgmcvgh.metUzxdq(context); return;
			case (2): generated.kqywo.pil.grw.dvt.ClsJduhsebfba.metHzxxu(context); return;
			case (3): generated.rzy.sppai.eju.hupq.ClsPjendhgbojpy.metBiigjbvggllkr(context); return;
			case (4): generated.fkhk.aid.ztzxu.ClsQjlasdqvzflfd.metSrhconsb(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(299) + 8) % 422642) == 0)
			{
				try
				{
					Integer.parseInt("numWhrtglcafdh");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((5824) % 54157) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirYnbaxealfgi/dirIylsjnkdhyz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
