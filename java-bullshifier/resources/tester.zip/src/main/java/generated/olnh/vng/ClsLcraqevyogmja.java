package generated.olnh.vng;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsLcraqevyogmja
{
	 public static final int classId = 14;
	 static final Logger logger = LoggerFactory.getLogger(ClsLcraqevyogmja.class);

	public static void metHrpnbihsknjv(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valAjygaumamew = new HashSet<Object>();
		List<Object> valQvuacxeevde = new LinkedList<Object>();
		boolean valFbmgbsslmmp = false;
		
		valQvuacxeevde.add(valFbmgbsslmmp);
		
		valAjygaumamew.add(valQvuacxeevde);
		
		root.add(valAjygaumamew);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Bjxyqgoadz 4Ptmqz 5Edgeqp 9Ccfqpowfai 3Voxs 5Ftzdsx 6Wbsjgip 7Tmykxrkg 3Nmgk 7Fmwanwhc 8Hbwkijfss 4Ieyzq 8Oukrtnqgo 9Acocposxcz 8Flargqnuw 7Qgvxajkw 10Fhsgfwrbwqh ");
					logger.warn("Time for log - warn 11Hlqszvkwyaii 3Crnv 3Pyct 5Pldftj 12Doubhkwvvnkqy 11Bzpqibbiukwr 7Qosvyoiy 8Tuhojvsas 7Subenrpo 6Mwawsto 11Lxepvllastui 7Bbockblm 11Eaufpbbhpygd 3Srje 5Efbwst ");
					logger.warn("Time for log - warn 6Ehskvxk 10Xwgtyhgctah 12Xcstoeuhrnziw 3Gogy 12Zwmqjhfbfyslp 8Oqpnjnscg 10Gfigwpihihe 4Jixnw 10Ykivqzbhcnm 5Dgqgyx 5Weyfxb 12Rdaairmqhlduy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Priggwtsdjs 7Pteqywdp 11Tscbupzgpnnx 3Mxas 11Jhmjphdxwhaf 10Bxlzruckdcg 5Idlyfo 4Cntic 7Ndkaziog 11Xibusenejmyr 3Nyqi 9Fbvcwdqgtd 8Kclyvquyc 8Lacnjvzaa 4Zchnw 3Zkmq 12Vdpnvjrfmuotr 3Puqr 7Qjytxnbq 7Erpuerim 7Rmmhvjyg 11Wctxldhmoszl ");
					logger.error("Time for log - error 11Okxoicpyacke 10Tfzxsmgmvvj 6Ckwhicu 3Lbec ");
					logger.error("Time for log - error 4Yjcrp 6Ichfzxv 12Shtdrwoyihwee 10Tlizhomccvf 12Vaafsvxbikgnu 9Ekvwzpzijj 10Lpalufgzrcr 5Egsqjw 8Mtbjyjxcc 7Cvnxxube 4Zbfkl 7Ofbgvxar 5Iwditf 8Qswweswqp 4Feupr 12Qsmjimwtcfekg 5Fmhprf 7Qzzakqcx 6Cdozdhe 11Kvofokxtvdkn 3Gfnq 3Zoyf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ooziu.gzrop.rbg.ClsFthgefv.metEguhqfdvtpntfq(context); return;
			case (1): generated.xvt.cmvm.fgj.efz.bawb.ClsIacmgbgh.metHijjkg(context); return;
			case (2): generated.lvnhk.isns.uksl.tjjfx.ClsEfuazouhb.metUvvxajcpzq(context); return;
			case (3): generated.pema.ddj.ssuh.ClsIlinaijnkxxo.metPxgeyqlgriu(context); return;
			case (4): generated.rxif.wckg.ncsqv.pmlox.ClsRkhayrnqgfzod.metOqicwb(context); return;
		}
				{
			int loopIndex2271 = 0;
			for (loopIndex2271 = 0; loopIndex2271 < 7707; loopIndex2271++)
			{
				java.io.File file = new java.io.File("/dirStqqqqnqzxj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex2272 = 0;
			for (loopIndex2272 = 0; loopIndex2272 < 9149; loopIndex2272++)
			{
				try
				{
					Integer.parseInt("numBcfyytwxhwx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numIxbseeqdpnj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metHhcagl(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[6];
		Map<Object, Object> valCremwqngciq = new HashMap();
		Map<Object, Object> mapValRlfeauepszl = new HashMap();
		String mapValBjdzkeyaefu = "StrLyrvbwzxren";
		
		String mapKeyCtydbupixhh = "StrQoxmhhbzryv";
		
		mapValRlfeauepszl.put("mapValBjdzkeyaefu","mapKeyCtydbupixhh" );
		long mapValKgaeyfzfnev = -4265648069588303648L;
		
		int mapKeyTjwcobxipaf = 711;
		
		mapValRlfeauepszl.put("mapValKgaeyfzfnev","mapKeyTjwcobxipaf" );
		
		Map<Object, Object> mapKeyBtofshezoxo = new HashMap();
		String mapValCmhjojuxshu = "StrWdlwvazfiyf";
		
		boolean mapKeyHvkoqmowiwa = false;
		
		mapKeyBtofshezoxo.put("mapValCmhjojuxshu","mapKeyHvkoqmowiwa" );
		long mapValKrllivrypzi = -5321553693829529618L;
		
		int mapKeyBhdhauesrez = 750;
		
		mapKeyBtofshezoxo.put("mapValKrllivrypzi","mapKeyBhdhauesrez" );
		
		valCremwqngciq.put("mapValRlfeauepszl","mapKeyBtofshezoxo" );
		List<Object> mapValEvoixvedraz = new LinkedList<Object>();
		int valDcviponyzil = 33;
		
		mapValEvoixvedraz.add(valDcviponyzil);
		int valCudwvrasmrr = 399;
		
		mapValEvoixvedraz.add(valCudwvrasmrr);
		
		List<Object> mapKeyEemqjfevxau = new LinkedList<Object>();
		boolean valZztgedmjapo = true;
		
		mapKeyEemqjfevxau.add(valZztgedmjapo);
		long valUxlhqoibvhd = 7734809133816148635L;
		
		mapKeyEemqjfevxau.add(valUxlhqoibvhd);
		
		valCremwqngciq.put("mapValEvoixvedraz","mapKeyEemqjfevxau" );
		
		    root[0] = valCremwqngciq;
		for (int i = 1; i < 6; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Smwudvqa 12Trevleoijbwow 12Zzwzfozcgyoib 11Phwyfgsgmvlu 3Rben 5Hvhqrw 10Ukcvixtwnea 9Chgnfktiit 4Yhoui 10Fybramdwrgq 5Ubplcu 11Jmxoiqrgcfqw 5Wrjqje 7Hdxlippt 7Kupmzsmf 10Tztgedwiqay 5Iwilvc 7Zkdgozry 8Lckutyhxw 4Gedzv 6Acrahtd 5Vftyqy 6Hfgejdw 6Ljvzjvy 10Lgmfhysdlom 10Iydljeefrcd 6Exotnea 12Nssvfsdyuibnw 9Jzltrtiwrb 7Dwidhlwk 8Zcnkybdyh ");
					logger.info("Time for log - info 10Hgwrpnobtso 4Qrofi 11Gvgtbaiafgbn 4Csako 12Enrjjqhpduazd 6Jvtirnu 11Xbmtcybvbmia 7Jkmzulaj 8Nttojkhvz 5Ewrdao 7Estekzxl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Tutfvuzuufmpa 4Cnenu ");
					logger.warn("Time for log - warn 3Zxum 6Uylsxdl 12Wzahudvataurb 6Uafqjib 5Dxgjqk 10Rjhqplbnfbm 12Qlxjwayvuyvqt 10Mssffcahinw 12Vvgescwkcaiak 11Lbphkbuoprsr 11Oseetthwvmjx 8Paiurprkb 10Ruskqzmfeve 9Lonwxdcxge 11Fbjfnohuuxix 10Hbirvxdlooy 10Ozuvokepreo 11Fwlfpcyekhcj 9Bundtntyzm 3Jiqc 12Qcugnyxvtpfmx 10Tgoicoikvwz 6Eocsiid ");
					logger.warn("Time for log - warn 8Ayqeumahu 5Jfnjzo 9Fcmcxpcpxx 11Cglhkimdfnhx 3Egzs 3Fdlf 10Ldqxhrthqxf 8Yhssmkkhp 3Afjy 4Ulqoy 5Vqgtvs 3Brwa 9Aajyehjlwn 10Wrgwsidakop 11Qxtnrjgauphf 11Ewzqlvatgrgv 4Pofhm 4Ailkl 3Ausq 4Selir 11Bpovtoqmascl 9Lgssweazur 9Ynplsjknau 8Ahawftjgg 7Sfjtuqie 4Xdpsd 3Fvow 5Olwgxh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Nnxwxld 11Wtraxuorxmcd 12Rbootvmuqfugq 7Ezwkszni 3Gkmn 4Mipcp 9Vxqcralamr 9Hfkysjruwg 9Vqbdaykvqd 3Ckmw 9Udbjotzfbn 9Fgyrydusiv 3Siyr 5Emyiqj 8Xxvwkepnv 5Mulsas 10Idwpcnnmnfo 4Seird 3Kmvq 3Hpum 5Giqvuf 5Twndaq 5Woldlm 9Iadcarvczy 8Tbnkrdkgg 3Ozge 11Engbalcnswuj 10Jdmvpllcnru 7Avyezomi ");
					logger.error("Time for log - error 8Vndnvvwah 11Ijadkpixazja 11Nnqkjhdwzsvo 8Cfdemejqg 8Msdmejqus 5Okdjmo 12Iwpargdbkjpsp 3Tulx 11Zolhfcyhrifh 8Qxybnpjpk 7Nvzsddfk 9Gxknwhrgji 3Rqba 7Ecvxzssj 12Bmlngbxwbgazw ");
					logger.error("Time for log - error 12Hlelpechyhokp 11Azljklvjbksi 12Tqcvqvwyalhjv 7Uclfsfek 3Cgti 8Ttaopcnme 12Fbkvthgrllgzi 4Hejio 6Rwnuihl 12Eeuhsfpgdfztj 11Brduoymkikfz 5Bwpliz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metKlgcwsafmqppr(context); return;
			case (1): generated.yewpq.dap.itdt.ClsOhnihvc.metVezpyfhkrdq(context); return;
			case (2): generated.bolg.tnlb.nmug.ClsHstaiufsowx.metPapexcx(context); return;
			case (3): generated.vyac.iqbj.guc.ClsYpwwsvx.metJtvstyrjix(context); return;
			case (4): generated.bad.yds.jib.otl.ClsBzgol.metFiipzeiyfjfs(context); return;
		}
				{
			int loopIndex2280 = 0;
			for (loopIndex2280 = 0; loopIndex2280 < 8723; loopIndex2280++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((loopIndex2280) - (Config.get().getRandom().nextInt(57) + 9) % 940358) == 0)
			{
				try
				{
					Integer.parseInt("numDqcivqfqwka");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(350) + 2) % 854402) == 0)
			{
				try
				{
					Integer.parseInt("numVieehkvpcab");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirNcafodddaqx/dirXvuzcvlogwy/dirAicivzbwurn/dirCrscewipnaw/dirGkedefopouh/dirYjyrvvrcmgf/dirBxbmrrbnfga");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex2282 = 0;
			for (loopIndex2282 = 0; loopIndex2282 < 485; loopIndex2282++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metPgeabenpeclmvf(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValUtkjpegxosq = new HashMap();
		Set<Object> mapValNxgkcuevfbe = new HashSet<Object>();
		String valCifdarmylmx = "StrFfcqhovodut";
		
		mapValNxgkcuevfbe.add(valCifdarmylmx);
		
		Map<Object, Object> mapKeyBtduiauwihj = new HashMap();
		long mapValQomorgmcboy = -3583124634380486596L;
		
		int mapKeyYgmmbfrbxuh = 584;
		
		mapKeyBtduiauwihj.put("mapValQomorgmcboy","mapKeyYgmmbfrbxuh" );
		long mapValCxsuocevfea = -7080787440770258366L;
		
		boolean mapKeyEeaylkqsikg = true;
		
		mapKeyBtduiauwihj.put("mapValCxsuocevfea","mapKeyEeaylkqsikg" );
		
		mapValUtkjpegxosq.put("mapValNxgkcuevfbe","mapKeyBtduiauwihj" );
		
		List<Object> mapKeyEebhwbiaihe = new LinkedList<Object>();
		Map<Object, Object> valBoxozyopbhe = new HashMap();
		int mapValZvmeggzacpv = 942;
		
		String mapKeyBsbyjwkjuur = "StrJeezmmegfpc";
		
		valBoxozyopbhe.put("mapValZvmeggzacpv","mapKeyBsbyjwkjuur" );
		long mapValBhwtdphsnka = -3010969190010879454L;
		
		boolean mapKeyNrgtlrcjskk = false;
		
		valBoxozyopbhe.put("mapValBhwtdphsnka","mapKeyNrgtlrcjskk" );
		
		mapKeyEebhwbiaihe.add(valBoxozyopbhe);
		
		root.put("mapValUtkjpegxosq","mapKeyEebhwbiaihe" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Dagregpfeh 10Hwqeryhsvhb 5Cxnlao 3Wpsf 11Fhwhonpsobil 4Ysthe 3Kiyt 6Rufwcxq 4Xdolc ");
					logger.info("Time for log - info 4Vqapj 10Ubgizravaaa 5Hxfoik 11Whfzjevxiquj 5Rbsujw 11Imufdzsxxtkb 6Urjtjtx 10Dplyubmlvmz 4Tbujp 12Fjpwfujlbdhnb 11Yubdtpjalqqe 8Uqjogzoax 5Nvtrak 9Rmtbnliwpf 4Jksde 7Qdzticpw 12Kksktsatibacy 12Aaejvzdnpbjak 4Efsvk 3Hrwn ");
					logger.info("Time for log - info 7Voqvylav 12Tbwvdpiaslfiv 3Azwz 9Aipjtxweur 7Fdatuvoc 11Fgbjklfbfvsd 3Ktpa 5Mxeizu 8Urcneukfn 11Xwuemaosmbyr 4Esuub 12Arwebmyfeggek 3Ehug ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Ymbtuxz 10Qlhyiastrhv 7Iatktpxs ");
					logger.warn("Time for log - warn 11Jmflksppjsqt 7Atguwtgu 5Wxijyc 12Obbrarespgqoj 11Sftxjlgkmqcv 7Ikrgmsku 12Xeaiczlhasbcm 9Mcacnhekbi 4Xvgfo 5Rcwnsh 4Ndslv 8Enznldnve 7Dfimgmid 8Hrzkpqqhw 5Vaqpcm 5Sglmev 12Fqwuxbkzzvfui 5Apgnvo 11Egxxhkpjzcnx 10Mohdtxdhtru 8Kajtmrghe ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Bglzat 4Dwlqk 12Pwioyqogvvybb 11Mchkqhammvfn 6Dvcyrib 7Inkiaqhb 12Yzyaikgqhcwsj 10Jgrsdwlazxk 3Qwcx 3Claa 3Gwnf 9Jujlgwdwxd 3Yarm 7Feirpypg 3Zoon 5Lhzsbt 11Inkbgdcgacep 11Bjfjwgjtnmhj 11Hyamkcbjdnwu 9Rymmbfrucw 7Mtfvlnkb 4Bbemd 9Hatfpmcidb 12Bwaayylckmfmg 4Aezxo 6Smyutyp 5Vnrpqo ");
					logger.error("Time for log - error 10Ptcrwmfoild 11Dijrzuixztin 9Xbiyytxftk 8Dkzendhth 3Arfd 9Gzgiyzldkj 6Dfcjojs 3Nzjt 9Tahlrwglns 3Odry 3Lwzh 7Uksphmxm 9Maqllryucp 4Kryzb 3Yhzt 9Ovwunlpaxd 12Dogdtlbigfylx 4Kdztx 10Rtgimokxhjv 9Penwmmqdzp 9Avpiwbfvzb 9Wzlrwgvgqt ");
					logger.error("Time for log - error 3Matb 4Woeot 8Upgvxhzox 3Tcqq 4Cxdqe 7Jqdshved 4Ymhwx 5Lpawqm 7Zewtzhme 8Ohdxcxwhh 10Ppjywkjriir 3Eike 9Fpisqlqlkg 9Zkkkhewwdw 10Jemxjbkixnc 5Nsvfqr 9Foudtgekpa 5Wcjrnt 7Cwhxdrmi 9Amxbbtmdjo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.maoc.ohm.nwzbx.efqn.ClsOzonhytosc.metIeedbzcj(context); return;
			case (1): generated.hioa.tbao.juo.tlh.zgppg.ClsZtwfn.metIybrdbhypesv(context); return;
			case (2): generated.enb.ktdil.ClsEqcfzlhpy.metPzfwhbxomd(context); return;
			case (3): generated.kfvy.ymxa.end.hazk.nwqfn.ClsXakhsfoyrlse.metJcgkp(context); return;
			case (4): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metVduhhhsluhwuv(context); return;
		}
				{
			int loopIndex2291 = 0;
			for (loopIndex2291 = 0; loopIndex2291 < 1617; loopIndex2291++)
			{
				try
				{
					Integer.parseInt("numQvtiscwyzmd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex2292 = 0;
			
			while (whileIndex2292-- > 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
