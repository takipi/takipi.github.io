package generated.tau.glw.atmw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsCedrqvgmxtsj
{
	 public static final int classId = 191;
	 static final Logger logger = LoggerFactory.getLogger(ClsCedrqvgmxtsj.class);

	public static void metRecbeoqusgpv(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valQjhsalomzto = new Object[4];
		List<Object> valJyaxgikurlz = new LinkedList<Object>();
		boolean valFxxfxhumtze = true;
		
		valJyaxgikurlz.add(valFxxfxhumtze);
		int valCzcknphnyey = 370;
		
		valJyaxgikurlz.add(valCzcknphnyey);
		
		    valQjhsalomzto[0] = valJyaxgikurlz;
		for (int i = 1; i < 4; i++)
		{
		    valQjhsalomzto[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valQjhsalomzto);
		Object[] valDfugcsscfzw = new Object[2];
		Map<Object, Object> valRpcjdivlpbf = new HashMap();
		boolean mapValHsbamcqiypq = false;
		
		int mapKeyVylcnvhgdrv = 89;
		
		valRpcjdivlpbf.put("mapValHsbamcqiypq","mapKeyVylcnvhgdrv" );
		
		    valDfugcsscfzw[0] = valRpcjdivlpbf;
		for (int i = 1; i < 2; i++)
		{
		    valDfugcsscfzw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valDfugcsscfzw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Ojoyxvqj 7Edhxrrto 6Jmtqeya 3Lknl 10Hotbybelprz 9Cpjnsrzbvj 12Qmzaxvmkelryx 12Mxwthyzzsspwv 5Athbhv 4Jrsxx 9Ihpxileylf 5Fdroiq 8Arghbjhxv 12Pnexedduslxrj 7Fbvbuoam 5Tnceyg 8Ymqoqerpj 7Ihldtogo 8Ecxnynxwv ");
					logger.info("Time for log - info 12Xxvmvvrfqlsfz 11Rnobrxxepxdf 6Xarcbgz 6Pprrbfz 10Nkwjlkuiuyf 5Gctqzu ");
					logger.info("Time for log - info 7Zkxhrjqt 8Uvsqotbmf 8Flpfxjjhj 8Nebuihpss 5Gvbldf 8Mwdqjfhsp 11Wtuwrelltmys 11Yyfnkaybxasg ");
					logger.info("Time for log - info 5Ezubja 7Fvqtgulz 4Edkma 4Ugfov 7Pxejtrwc 6Lyvfngx 8Novkaebrr 5Dpgdoc 4Pntab 11Gjojksucwrdm ");
					logger.info("Time for log - info 3Aafd 4Qcafj 7Edyopohi 8Yvaqbciru 5Tpygbb 12Zzdblwsdmurwr 7Abqdrhqa 3Mcij 9Jinjdxtqnd 7Imrvopxb 9Xxwskjochq 3Igba 8Xweedbyso 6Satlbsp 5Ltdclu 6Wrwvgem 4Psund 4Gieyo 7Ifxqryim 7Yfktobur 11Fcuzlgmabgrl 12Ktgaalhnltinw 6Bgtjhzs 10Tjyjvywgagb 11Ojzaxegcipro 10Bbdapzmzqvq 12Qmthjsiwrfkrh ");
					logger.info("Time for log - info 7Delyvkjs 8Jbybkjflv 10Qpuqnvsmuwv 4Pjjso 6Hmhhfmg 4Darul 12Frhorurceixfs 11Omkzzlfgrdty 6Tipcpej 11Kzqwsbzsvdwh 4Cgdev 3Zjdv 7Utzejiiu 12Gbpirqterlaby 11Hhetztmrpmqb 6Naikumi 7Muhmkjot 4Mbozx 9Vqqwzhahcs 12Dtyuupuhccbug 12Gxzhdtzyjozwa 3Idhw 12Chbidepgquaxg 3Xzdx 9Zuxxkxmmai 11Agtdbpwkzdzw 12Hkfidfqklpuvy 5Nhbhdc 3Znxh 5Sfwvct ");
					logger.info("Time for log - info 5Fkxyea 12Nqnpwikohlzvm 5Slilqh 7Hfbtwysy 4Eyaos ");
					logger.info("Time for log - info 7Aytlvyss 12Hmjftsbhxuvxc 10Ojivellfnyf 6Warzkmu 8Vttxjsbyx 5Rzmcnj 7Axdexotn 9Ulnwbbfugy 3Mpus 12Esnykcqxwdawo 4Ojgcm 10Sszgbsdcvmk 12Irugzpfgjnngy 5Gvsyzg 10Nanurbafkai 10Dorawnrbskc 4Tdgbu 7Nglitqzi 10Ibmkycfrwvg 5Hxlhfy 8Cupnbvwrm 3Ndvy 6Cpglykc 4Yjgwn 3Txsa 10Bbebaeitqxn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Oagnizme 3Qeef 6Mingceq 10Pmqqyudtndl 11Fxxzdqmtynxt 9Pjomugywrk 4Vleln 6Wyobfhu 4Vcdkc 6Rumncjp 5Qjtotn 10Uonxwglhqzk 5Yebutt 6Fzlkthz 6Minnpiz 8Jiropanpk ");
					logger.warn("Time for log - warn 4Qpohf 12Uunzxxczlyusc 7Jrggukdp 6Twilsyh 3Dybp 12Vgcqbxvqcjeyk 4Lwxgy 8Qjodjrtgx 12Lmvsdmmnrzrur 7Digwztqm 5Puqmdf 10Yvlyfspjiky ");
					logger.warn("Time for log - warn 10Qlstfbcxkwb 4Flprp 9Wwfvmulnjt 10Wsaadkwxebi 12Cddqsxpywjtur 5Mgvryh 6Whclvwi 6Tcjvgtv 3Evsq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bolg.tnlb.nmug.ClsHstaiufsowx.metPapexcx(context); return;
			case (1): generated.hehz.xzg.akn.rdsvf.ClsKsukcv.metYviizisnunbnph(context); return;
			case (2): generated.avpz.xulx.yey.mrdy.ery.ClsVwwfgnwmvvmf.metLnwlgzrb(context); return;
			case (3): generated.yaahc.bwx.upsjn.ClsIxadk.metYrjkkwdkjqjlsx(context); return;
			case (4): generated.xpyaq.paxhs.ClsBkhbodffo.metKfifgmjw(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(821) + 4) - (3552) % 608048) == 0)
			{
				java.io.File file = new java.io.File("/dirOwcjcxpuwmb/dirEhdznujkyif/dirAsjydmnwvak/dirTkyntkqwnkw/dirYtwmnzpkyux/dirAjnpcpooyry/dirGsfnlxwwxtv/dirKvjvqshvxad");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numCckjduhskii");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metFntjmzhfiklyoi(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valPcdsackvnsi = new HashSet<Object>();
		Object[] valGfkzzyolvot = new Object[8];
		int valVfhcomzhmyo = 914;
		
		    valGfkzzyolvot[0] = valVfhcomzhmyo;
		for (int i = 1; i < 8; i++)
		{
		    valGfkzzyolvot[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valPcdsackvnsi.add(valGfkzzyolvot);
		List<Object> valTzcoetmeizr = new LinkedList<Object>();
		int valIkaumgxfxhh = 653;
		
		valTzcoetmeizr.add(valIkaumgxfxhh);
		
		valPcdsackvnsi.add(valTzcoetmeizr);
		
		root.add(valPcdsackvnsi);
		Map<Object, Object> valAnqsxjcgawm = new HashMap();
		Set<Object> mapValPvxkabahjeu = new HashSet<Object>();
		String valKjvpvbdtfaq = "StrIujdqjfmlco";
		
		mapValPvxkabahjeu.add(valKjvpvbdtfaq);
		long valIeeajuksbiq = 1792988412283507384L;
		
		mapValPvxkabahjeu.add(valIeeajuksbiq);
		
		Set<Object> mapKeyKnxlhickdqj = new HashSet<Object>();
		boolean valYbnfsdvjokm = true;
		
		mapKeyKnxlhickdqj.add(valYbnfsdvjokm);
		
		valAnqsxjcgawm.put("mapValPvxkabahjeu","mapKeyKnxlhickdqj" );
		
		root.add(valAnqsxjcgawm);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Fvrsy 6Xbgvucy 12Fmkmsbgwfokcz 11Zoxpiiarisrs 4Qkldb 3Slfe 8Jbwsrvhkh 5Wbvyyc 8Hqdyzxdvm 7Kvvlgrqh 5Xjaizz 11Qwbolmndmrfh 3Lkdc 9Fwxtlavfmb 4Hcyqa 12Zvaeykwijmnfv 5Frxwql 9Bgpjgyrgzj 10Elhswddrbix 7Iwogpkkc 3Jtfd 3Pdal 6Rovqxke 3Iwnq 11Ylpaxocvejsq 9Ztmkyhwlss 10Lcgmmrpfyib 12Qolyihowibhtn 11Jwikpdopvhbm 4Ghdxt 6Eayxequ ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Xjhbeip 5Vxwoup 12Nloytcfsadcaf 6Wzvyabc 11Vjnzkvjbfvzx 7Sbkexbeo 3Jemo 5Stghzw 6Lypkyma 12Hmpqmgnlcygpd 12Xyxjgopisnxci 11Tufeealzkjvp 3Nqgg 8Ufwqqbdrr 10Hljpwolraea 4Cecck 8Nbcecfdly 3Bjpv 3Yuls ");
					logger.error("Time for log - error 6Wxkfikp 6Bemssmx 4Qmiro 4Iaztt 3Jbgl 11Nzswwrvuhdvk 8Ugnjsrvct 3Drej 9Imdeihpmgu 7Mkcciakx 6Mekirsd 5Doucgx 7Hyccsgtq 5Ngdzvv 11Xfdedywskidb 8Sphxnixiu 5Mtzjqd 12Lcugcxwkysqnr 4Nftee 3Xpqv 8Oqdugdwbo 9Oxxtmqrwyb 11Mouolbbwafba 4Zlplz 3Ogdw 6Xzacccj 5Ediyna 12Gobjcrqmqbnwq 9Nkmrefoyff 5Lrhwdz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.erjvc.bth.rgln.usqa.ClsYyzexetbgpowz.metLoqjjrjyqd(context); return;
			case (1): generated.tgr.kelz.siz.xfels.ClsKydjl.metQmhajcedjutgex(context); return;
			case (2): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metEqiixejyhymhk(context); return;
			case (3): generated.bxw.hza.cjj.bpzns.qzgt.ClsQbxnaxsj.metMcvovzzcwbpnsh(context); return;
			case (4): generated.zadtu.owlhb.qsd.bfzb.ClsWgiwrqnvyw.metJmapoligglq(context); return;
		}
				{
			long whileIndex23385 = 0;
			
			while (whileIndex23385-- > 0)
			{
				java.io.File file = new java.io.File("/dirOtpcgtlpisd/dirZinifqkhpux/dirSbtbanawexa/dirOrlbxnpeokn/dirVkdwjiqluck/dirOmofxnokmwt/dirOxjwrcmbtdh/dirWfvytopzdyj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numKtyhsmsdufo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metAxmjhcsear(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[4];
		List<Object> valCwqjhromtob = new LinkedList<Object>();
		Set<Object> valYrgsgoliuiz = new HashSet<Object>();
		int valXlnudxxfvfa = 618;
		
		valYrgsgoliuiz.add(valXlnudxxfvfa);
		String valHtrpbzcuwbb = "StrKqdqhzegjkd";
		
		valYrgsgoliuiz.add(valHtrpbzcuwbb);
		
		valCwqjhromtob.add(valYrgsgoliuiz);
		Object[] valPykvavwxzwc = new Object[2];
		boolean valGjgrweyeioc = true;
		
		    valPykvavwxzwc[0] = valGjgrweyeioc;
		for (int i = 1; i < 2; i++)
		{
		    valPykvavwxzwc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valCwqjhromtob.add(valPykvavwxzwc);
		
		    root[0] = valCwqjhromtob;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Rercr 5Cqnczd 3Agei 11Zofilovnflqo 7Qnstdtya 9Cufcvsxhgb 7Ewnyqgyd 3Xyej 7Jnzeolql 4Cmqrb 8Izlsqqwig 9Lsufoyrswy 6Zctaewe 10Eevslhiaoyz 4Jnvhh 4Ygdug 7Dkzpifet 11Pogvyytjiogb 7Eotnbtsn 4Qivls 4Ojbgs 10Bnkqqekunnx ");
					logger.info("Time for log - info 9Kfvyllbhqj 11Hhvmgfboeqov 12Nmjfjrhgbhqzg 11Tnupbrfcdqqb 4Tiqro 5Plouym ");
					logger.info("Time for log - info 8Vmlzquter 10Ohzxdntauae 8Gtwfnrxyj 12Xphfjymbzbasp 5Gomxxk 3Iehj 11Jixaxqpyquak 7Jeaqifvn 9Hxzrtxszcx 5Ctvifq 3Alzv 10Dwnuqkqukmw 9Jittyqotqb 9Ljkwbyfpsi 9Wisnwdmoxo 8Zbwwdirwg 11Ybgmfslxelcv 7Irmexswz 5Tqnotk 4Gntkv 3Wpbz ");
					logger.info("Time for log - info 3Ggjg 6Cjpwvcc 11Mgbzujyfnuqk 10Baxqqnnitsl 6Pwwpewe 4Mikml 11Tkramxzzpjrt 4Ssasi 11Zhrrladpfols 3Mutc ");
					logger.info("Time for log - info 7Ysgicnkx 11Lfuzrxxxkfry 11Hsgnnbtfpsbt 11Lrmquotsavjl 11Czqucuyjyait 4Rbomu 10Nebxlotwliz 3Mqpx 5Qyrlcu 6Ehouqbx 7Rmneilvi 8Bvwipjabs 6Zypufpz 3Jaqp 11Ndsruwscpphv 12Fsbrmfsgqszup 5Qdzinm 11Vqanhfyeksqk 11Iatwuxrvflay 4Tepdb 11Crfdhorcrodf 5Xqeesk 8Hkglzpovf 12Smrfxkddfkqpa 8Tunarcwgm 3Rjuq 9Hmmugezqil 9Qifjbccupz 6Beeclsf ");
					logger.info("Time for log - info 10Mjkggofoamm 11Dgbljqzqmqgz 4Vrxeg 9Erzvagvjog 10Akbxcvsimqt 4Oleey 9Nspaadslaq 7Tvpedfvx 7Maojnosu 4Parzr 4Osswo 10Wyoxzzylsza 8Tbqqdrund 3Elvg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Pwslnuqpqmej 6Auwdvrd 4Ifnzo 11Rgttajgrwmop 4Xdddp 12Wushywbgerivg 9Syaqrkpafr 5Mehttp 9Ezynjygtpi 5Sgnxll 4Ohlxi 6Ggmtprd 8Wxugtodoy 3Tsud 3Tfoz 6Hbocekv 9Plhqbdhziv 3Niln 6Ynauuaq 8Hpqdmgdrr 4Ulaqf 8Guftebrig 10Fqlnxyircgp 3Flbx 7Omctjkup 9Hnwnshphcx 12Viwcucxdntedx 9Hcwqcxyyiv 6Jekvtzz 11Qdcbwgnekyba 8Csakvezbu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mmr.nvta.lkrp.mhnjv.sey.ClsClqnjloclxx.metHlkppashfhooce(context); return;
			case (1): generated.obqk.bihpl.ehwd.ClsWcpejgvq.metUrpeeajbj(context); return;
			case (2): generated.gbss.lmi.dvqsw.ClsLptludgibvpvw.metJevsr(context); return;
			case (3): generated.pgg.urfbp.dpry.ClsLqnnoewxwh.metHqhcu(context); return;
			case (4): generated.uooez.nez.ipsx.tenui.ClsCrgtl.metHhqpox(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(873) + 7) - (Config.get().getRandom().nextInt(253) + 2) % 845712) == 0)
			{
				java.io.File file = new java.io.File("/dirXgmvmtddydb/dirNlsmtaucknr/dirZelegsxuppl/dirDppnrhcbuhk/dirNrfgsuojwfm/dirFrfxmphkmiw/dirLzybtefchms/dirYwbumllomqj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(720) + 2) * (8085) % 797547) == 0)
			{
				try
				{
					Integer.parseInt("numRzzgljpmcad");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numHlphmlgdnif");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varTaqtikpzafx = (2727);
			if (((varTaqtikpzafx) - (3172) % 912544) == 0)
			{
				try
				{
					Integer.parseInt("numKuasudzpjnt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((6980) * (7185) % 279838) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metVmijeiavbbbbxs(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Object[] valVhgxjdvyavu = new Object[10];
		List<Object> valBahjnkfmfxd = new LinkedList<Object>();
		String valSuzldhbjaas = "StrExsroxmrfbj";
		
		valBahjnkfmfxd.add(valSuzldhbjaas);
		boolean valOboyfwtktnw = false;
		
		valBahjnkfmfxd.add(valOboyfwtktnw);
		
		    valVhgxjdvyavu[0] = valBahjnkfmfxd;
		for (int i = 1; i < 10; i++)
		{
		    valVhgxjdvyavu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valVhgxjdvyavu);
		Set<Object> valNjjukzsbcbw = new HashSet<Object>();
		Map<Object, Object> valRmalweocazi = new HashMap();
		boolean mapValPwjzjnlrgbd = true;
		
		int mapKeyJudocsmkaic = 513;
		
		valRmalweocazi.put("mapValPwjzjnlrgbd","mapKeyJudocsmkaic" );
		
		valNjjukzsbcbw.add(valRmalweocazi);
		
		root.add(valNjjukzsbcbw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Xwzynermgc 4Bcqce 9Yltpanebad 3Wrrn 12Emhzeikehcsjy 5Skzfke 5Hdsngp 4Hyfie 10Vrexkgmnxkm 4Agbow 6Gnlijgw 3Mkoz 10Oneggqnrqgh 12Uznbgjdyzeowc 3Cndj 4Tovqb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Djub 10Rchjwqohbde 9Syffofkqsr 7Ktijjrdo 5Nuqmbu 4Kfjso ");
					logger.warn("Time for log - warn 5Pwnfpu 12Ikloezkwwypkf 7Munigbvb 5Lshqux 11Uhljddoojmvp 10Quqxgwjrwbl 9Nzxybpxqzg 12Orsfgfrlzddta 4Hskdb 3Adfd 9Tvgbgknufh 7Nzddesvf 5Ymxzlw 5Fygxwv 4Vclcl 11Gnsrvzndavhn 4Bqyiq 7Psqemvbi 11Flrrfqueabfp 9Pfhiwoefzf 6Egnksub 6Veufrkq 5Yxplrs 7Filxznei 6Ziislds 12Jakecsngcyixi 7Tthezkfy 12Ipyfebzstygjs 8Bcjanbbvd ");
					logger.warn("Time for log - warn 6Botcnzs 3Xemt 12Xyudepqolozad 12Tpjciltimmhsg 12Nfnnpqhvnrxrv 11Numopiawulwt 7Sranobgi 4Vfzpw ");
					logger.warn("Time for log - warn 5Fdxftl 6Gjktqtr 5Riagrr 4Hrmcl 4Quvrx 7Wvhcilhp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Qtntvhatxa 12Mfjvrxcebqvkq 3Zhwx 12Azazyzgbiejhs 7Juzsgpph 4Zefhw 11Uakkcmoeucwz 6Fvumvvq 7Jjknmivl 10Rqobxarvweb 4Oluec 11Vhofjpzoeqqf 8Ikgpicynj 12Ivolbmlskbmbi 11Atcoftblzqlm 11Xqklotfmjyll 10Hdmjlnpzgwa ");
					logger.error("Time for log - error 11Omwahfjbgqag 4Ybhnj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bkbep.bjvph.skry.qijli.gfl.ClsFlycqobnxjszt.metLjgrsni(context); return;
			case (1): generated.xvt.cmvm.fgj.efz.bawb.ClsIacmgbgh.metHijjkg(context); return;
			case (2): generated.meo.tvmj.xqqix.qdpb.crypd.ClsCqiefbhpitkzjs.metRkiiokfveuzir(context); return;
			case (3): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metEqiixejyhymhk(context); return;
			case (4): generated.drdz.aky.gfc.cjlsi.ndn.ClsMzlwuddsrmx.metTewxhxspn(context); return;
		}
				{
			long whileIndex23404 = 0;
			
			while (whileIndex23404-- > 0)
			{
				try
				{
					Integer.parseInt("numSbvyaeeigbe");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((whileIndex23404) % 207589) == 0)
			{
				try
				{
					Integer.parseInt("numOwaqnhcuiqg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metVvgmrshtcqbse(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		Object[] valIxnczwcwqif = new Object[8];
		List<Object> valGwrgpmpedvn = new LinkedList<Object>();
		String valOhxkdsguzbz = "StrFmonsbjkssw";
		
		valGwrgpmpedvn.add(valOhxkdsguzbz);
		String valHglquvrqvgw = "StrLmznaycualz";
		
		valGwrgpmpedvn.add(valHglquvrqvgw);
		
		    valIxnczwcwqif[0] = valGwrgpmpedvn;
		for (int i = 1; i < 8; i++)
		{
		    valIxnczwcwqif[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valIxnczwcwqif);
		Object[] valMkxqbotsvxd = new Object[6];
		Object[] valRzbdbvpuxol = new Object[9];
		boolean valMhzkbusjykg = true;
		
		    valRzbdbvpuxol[0] = valMhzkbusjykg;
		for (int i = 1; i < 9; i++)
		{
		    valRzbdbvpuxol[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valMkxqbotsvxd[0] = valRzbdbvpuxol;
		for (int i = 1; i < 6; i++)
		{
		    valMkxqbotsvxd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valMkxqbotsvxd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Glglnngqnndcf 4Rfabt 12Qlclmoyblfgkz 6Mfxdura 4Zhgqg 10Bhrttxpirns 4Qciap 3Fbaf 10Nhhaulmxzyu 3Rhoh 7Gtjcoqpm 9Zxuuhvfvxh 6Diucdud 4Qtqyy 9Ecmyrpiwht 3Wmln 10Hoaujngkpbd 8Szdhpivzn 4Ysnmd ");
					logger.info("Time for log - info 12Tfxbhirogahut 12Fzhqzpqalwcms 6Vwznvwq 10Ndqepzrjzga 3Qqwd 12Mbliotrdqkxrw 9Rengjnggfk 7Plcnartq 10Wiepzmpbncm 9Wnbtbrlfmm 4Vdyow 9Qjpasgtfkm 11Azlxcbqljrcx 3Lmpu 7Hkivkvvv 11Jsgqjwhdwzvp 10Svprxwsqgiw 6Zzmltsa 9Xnsshguuth 8Lmjcsxxoa ");
					logger.info("Time for log - info 6Jsalifp 3Vcah 5Soarna 6Nbaidkg 5Ewvupi 9Qkkeuplbml 12Rbukjknknoyzl 8Iubtsdttf 11Punlziripfwz 11Tpxziqwnnqdr 5Cyrbgr 3Vflv 11Wbngamqdvicz ");
					logger.info("Time for log - info 6Zcvpvgk 7Mquoyeht 12Ukzilxsxhebeu 3Cjpx 5Adhuhf 12Wbvaaqnvphtsk 11Uebhragaxlxn 9Jdhqpthhdc 11Ukefznzqewmf 10Vwjvnbamdxt 6Edibgew 10Xgwygmmxumy 3Jhlh 3Llfy 9Axgkthrryq 9Orfcrwqspt 8Atdjlepiu 9Lkuqmwfsdw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Azbbvzsnqjkge 4Imdbh 10Eiyupahqyoe 10Enzmuliezwz 6Zovsccf 12Nbrfvrmmsvjeg 9Vxjsxxzsjq 4Lznix 5Eimnxa 11Vtjjkihybquo 6Hvebyxx 7Asyjmrhm 7Rloltyly 7Zdfawyhm 4Tzngr 11Ualskaehsrlw 6Oqtyxgw 7Beuurkov 10Xvmqcuvnzoz 4Nbavl ");
					logger.warn("Time for log - warn 4Mcqkf 10Lzspmgiiviv 3Pqls 6Jdoamgx 10Ttdebfeziuv 5Nyyoda 7Pqykhwoq 6Inhllsz 9Aumihwfhlf 10Uyikngcsjhb 9Ofadsysyfb 4Qwlfr 3Klap 5Hevgox 6Bfjvhrb 9Pbqgdytoib 6Cmwbxee 5Jiyxew 6Kgeahbf 8Wbeoixqlo 8Nmrduydku 6Qbpxbew 4Ikhpo 5Qhunqt 9Luhewcyrde 4Sqpnx 9Agwardwwsr 10Evahuxhskpe 5Mlnhee ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wrwx.jsm.hgij.abg.imgx.ClsRhzgz.metLbqpyboy(context); return;
			case (1): generated.jgye.cou.ClsWhiobyn.metGldtri(context); return;
			case (2): generated.jyd.enpnr.ClsZxueqcgpd.metEwimth(context); return;
			case (3): generated.dbr.dvpj.ClsKgmhp.metVaplmoyavlsjm(context); return;
			case (4): generated.nle.etupm.unno.jlzdn.uik.ClsNynvcklxtmhfla.metVlaejrvj(context); return;
		}
				{
			long varVfnkmmdikqj = (Config.get().getRandom().nextInt(447) + 8) * (Config.get().getRandom().nextInt(737) + 5);
			int loopIndex23410 = 0;
			for (loopIndex23410 = 0; loopIndex23410 < 5778; loopIndex23410++)
			{
				java.io.File file = new java.io.File("/dirFkejqweqing");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
