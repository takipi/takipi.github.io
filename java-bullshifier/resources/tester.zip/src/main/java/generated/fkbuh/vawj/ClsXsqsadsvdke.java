package generated.fkbuh.vawj;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsXsqsadsvdke
{
	 public static final int classId = 252;
	 static final Logger logger = LoggerFactory.getLogger(ClsXsqsadsvdke.class);

	public static void metGrquryhkwyi(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valWreqiqjkbzb = new HashSet<Object>();
		Map<Object, Object> valWjgkcotaoyd = new HashMap();
		int mapValYkjfrmbwras = 459;
		
		boolean mapKeyDivdmseyxsi = false;
		
		valWjgkcotaoyd.put("mapValYkjfrmbwras","mapKeyDivdmseyxsi" );
		
		valWreqiqjkbzb.add(valWjgkcotaoyd);
		
		root.add(valWreqiqjkbzb);
		Map<Object, Object> valHxccxdlqscz = new HashMap();
		List<Object> mapValUwmkszcgidu = new LinkedList<Object>();
		boolean valFtjlawbkrqa = true;
		
		mapValUwmkszcgidu.add(valFtjlawbkrqa);
		boolean valVvgewwxiarr = true;
		
		mapValUwmkszcgidu.add(valVvgewwxiarr);
		
		Map<Object, Object> mapKeyMfpdnzvgfqn = new HashMap();
		String mapValGmkdwbzbblh = "StrPyyafqxrlxp";
		
		boolean mapKeyCtosqioghwq = true;
		
		mapKeyMfpdnzvgfqn.put("mapValGmkdwbzbblh","mapKeyCtosqioghwq" );
		String mapValEshmwgnfskc = "StrHcuxrvbpuao";
		
		String mapKeyIsktmhcljyt = "StrWtddonzujyx";
		
		mapKeyMfpdnzvgfqn.put("mapValEshmwgnfskc","mapKeyIsktmhcljyt" );
		
		valHxccxdlqscz.put("mapValUwmkszcgidu","mapKeyMfpdnzvgfqn" );
		
		root.add(valHxccxdlqscz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Rezhjwupocm 11Ucmpudxpaoru 10Plvymoateey 9Bokpvpzzbw 4Bohbm 5Ttugcn 7Slftsqtd 12Ojvcgpptiavbr 7Uqmfluba 11Eevatppjjskf 9Izoobyxthd 5Ejwefr 4Ynptl 10Zatdxrgmcta 8Somfnymaj 11Fjjujxgngbak 11Dfhshwnwigbw 3Nefw 12Vutjtwngxcock 5Zghwyg 7Khffadpj 3Mdnt 10Drygspibkgl 8Yfvzqsqoe 11Zbjfaqwsmpwd 6Cevatiz 10Zvfbxsihrfh 7Icdtofxn 7Lvblexhn 5Gtnewg 5Bmtvgx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Ajfjtsvehagy 3Snwl 12Dxxjufyvmdojc 10Qlcuvscsgdj 4Fwytx 10Lyqefrisvnu 5Rftbyw 10Iwwuaolnixk 3Rqvs 5Ynlpkr 12Rmwkurwnwvezl 8Jbfbzzaiw ");
					logger.error("Time for log - error 4Qyhyg 5Fzspxl 4Ljiyk 3Ylqh 4Ewswq 6Smxlfwf 9Clgvvqagvq 8Keluwivys 5Ridxux 7Tucyucmy 6Jtevdgp 12Kfcwtrpcqxymr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cfolx.abg.ClsZqloaugvusc.metIpjezogguhroh(context); return;
			case (1): generated.nrwq.xlmuw.ClsJifahbhi.metKjzfoqdoi(context); return;
			case (2): generated.exa.yssf.ClsHuxmu.metYpznuybxbixhh(context); return;
			case (3): generated.flwv.kjeus.ClsAhjobcsyb.metPpltlaigoqfyf(context); return;
			case (4): generated.kdtwm.lzen.mpr.ClsNfgcbhcbckej.metOxdvwdpnbz(context); return;
		}
				{
			long varTdmacklzhsf = (Config.get().getRandom().nextInt(786) + 4);
			try
			{
				java.io.File file = new java.io.File("/dirHwbbbevsiml/dirAgmiuiyqhwn/dirJhgaxwfiebz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex24429)
			{
			}
			
		}
	}

}
