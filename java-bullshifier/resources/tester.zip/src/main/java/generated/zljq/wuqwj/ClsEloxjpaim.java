package generated.zljq.wuqwj;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsEloxjpaim
{
	 public static final int classId = 193;
	 static final Logger logger = LoggerFactory.getLogger(ClsEloxjpaim.class);

	public static void metYpqwrjj(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valLgfiqhatdeo = new HashMap();
		Set<Object> mapValNtyqgbdhilc = new HashSet<Object>();
		String valDlxdbgypabo = "StrEcrwnqxntza";
		
		mapValNtyqgbdhilc.add(valDlxdbgypabo);
		int valThkrfdytwbn = 449;
		
		mapValNtyqgbdhilc.add(valThkrfdytwbn);
		
		Map<Object, Object> mapKeyUxygsssxoac = new HashMap();
		boolean mapValYkfoyahuswt = false;
		
		int mapKeyFqhoiklnaqu = 559;
		
		mapKeyUxygsssxoac.put("mapValYkfoyahuswt","mapKeyFqhoiklnaqu" );
		boolean mapValNnnbnxpockh = false;
		
		String mapKeyNcilcjttxza = "StrJsnwritrodc";
		
		mapKeyUxygsssxoac.put("mapValNnnbnxpockh","mapKeyNcilcjttxza" );
		
		valLgfiqhatdeo.put("mapValNtyqgbdhilc","mapKeyUxygsssxoac" );
		Object[] mapValDggaqpbfiom = new Object[4];
		boolean valJrlmbeyrjcf = false;
		
		    mapValDggaqpbfiom[0] = valJrlmbeyrjcf;
		for (int i = 1; i < 4; i++)
		{
		    mapValDggaqpbfiom[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyCrmwkwqvbrx = new LinkedList<Object>();
		String valIhgmbofatym = "StrEjldbjyyrox";
		
		mapKeyCrmwkwqvbrx.add(valIhgmbofatym);
		
		valLgfiqhatdeo.put("mapValDggaqpbfiom","mapKeyCrmwkwqvbrx" );
		
		root.add(valLgfiqhatdeo);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Wfuhe 11Tznveettgash 9Oxxqqnjzpa 5Nrysve 8Vtluyenrv 6Qzhdvrt 10Yajgprqotce 5Vsucqy 7Rvbvyntf 7Mkbitwng ");
					logger.info("Time for log - info 10Bznykfguynf 3Qrlt 12Nwmbzuxfkjkua 6Usmotmd 3Ygvf 3Encv 9Gwapjukosc 12Awbdxrzjjjmjr 9Tcyxuuvflk ");
					logger.info("Time for log - info 3Ahis 7Vbrsevmz 11Ikifheftnreo 5Olngaa 9Zrmlpifyzk 9Qibsqrfrsn 3Heqr 10Wdbyvfcezsi 5Ktcxyz 6Wojnuup 11Eegfdircyapy 3Hjtu 7Qyslemwx 3Tcdu 8Tgdvmhadk 4Onlyi 6Zxnpmyp 4Iqmob 6Ixbbpzi 4Vocuz 8Galgljzma 10Ldpsuhfltdi 8Texhgahfx 4Rggct 12Hjqpxczhioxdx 12Kzbomrhdeoqgn 10Purvsavotgv 5Aiidwq 10Jrxdfkjvpro 4Ugiww ");
					logger.info("Time for log - info 12Trsboguislzlg 8Rlazzcfmp 4Mgkqy 9Ehmsinzusk 5Kdnyeu 3Tnyb 5Twywxo 8Zpovyqkwc 10Cosphxhmykg 7Scheqpdl 12Mxbbvdfimhtzt 6Imcvpoq 5Qnmnvm 6Pkuhyiu ");
					logger.info("Time for log - info 4Snulq 5Yhruqw 10Ppfcvsdsqvk 6Awvxsxs 7Bpiqtjfn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Huzv 11Vkiyzgrtfsmn 10Gweluzpsqfo 12Vhrsaudrflxmq 9Ipyapxtwjs 9Ptufpbnnua 9Vawexcubea 3Sgeo 7Kytnwnuw 8Suwkrgkug 9Wzqnumiwca 9Zfxeeqsqpa 6Drkftar 6Mppybos ");
					logger.warn("Time for log - warn 4Ntgbe 9Sszjsawgzv 7Xtlsgchr 5Tmdpnr 7Fzabclvj 11Bjpkameysuaf 8Yhqzmxnca 12Ckgpwvngbelsk 7Knoaatht 5Apkrju 12Ybhxkqwkztpkn 3Kbeh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Cvgcfmuee 5Bibdyi 10Brajlalynkt 3Dltu 7Zkxlrtdb 8Fejygrvnz 3Yxiz 10Ihvejxjhbpf 7Tdqfkkdn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metOebzatkpa(context); return;
			case (1): generated.ymhs.ivq.mlr.cezkl.gzyiv.ClsKvdrph.metXevuffadmfcuxi(context); return;
			case (2): generated.naf.suq.ClsSzodbxxywsfz.metKihakbig(context); return;
			case (3): generated.hbqjp.kifli.leg.jlyd.ClsYgtwztbknhdmc.metHsrmkfyvnv(context); return;
			case (4): generated.dpe.jvo.jwdtk.ClsKqcmvv.metOqhxfxoow(context); return;
		}
				{
			int loopIndex23418 = 0;
			for (loopIndex23418 = 0; loopIndex23418 < 251; loopIndex23418++)
			{
				try
				{
					Integer.parseInt("numVoqfhjxewak");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
