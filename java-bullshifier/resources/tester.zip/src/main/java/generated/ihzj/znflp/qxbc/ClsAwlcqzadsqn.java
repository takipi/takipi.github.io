package generated.ihzj.znflp.qxbc;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsAwlcqzadsqn
{
	 public static final int classId = 12;
	 static final Logger logger = LoggerFactory.getLogger(ClsAwlcqzadsqn.class);

	public static void metTpaanvj(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValUykjtwhznoe = new LinkedList<Object>();
		Set<Object> valCyiiqyciywz = new HashSet<Object>();
		String valFluauocjfdm = "StrCmcctsjcdwt";
		
		valCyiiqyciywz.add(valFluauocjfdm);
		
		mapValUykjtwhznoe.add(valCyiiqyciywz);
		Set<Object> valLvappflzpuh = new HashSet<Object>();
		String valDuvycchbqco = "StrVomfunudvtt";
		
		valLvappflzpuh.add(valDuvycchbqco);
		
		mapValUykjtwhznoe.add(valLvappflzpuh);
		
		List<Object> mapKeyXbrelsrxxvn = new LinkedList<Object>();
		Set<Object> valNnsmxvkmxlj = new HashSet<Object>();
		String valPmlwgocygtp = "StrJagxabofwei";
		
		valNnsmxvkmxlj.add(valPmlwgocygtp);
		
		mapKeyXbrelsrxxvn.add(valNnsmxvkmxlj);
		
		root.put("mapValUykjtwhznoe","mapKeyXbrelsrxxvn" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Nlsso 3Swvb 8Rczooehrv 11Kpsbyeuhsuat 6Myqscio 12Abrnlzpuzkjhf 9Jjjbbcbmla 7Cijeidnj 3Yjmc 4Eopgq 12Crmfatofyvoag ");
					logger.info("Time for log - info 10Dunwkuzjsba 3Mtsk 7Trplbbtv 4Hjohq 8Llebeddsh 3Cmru 11Lxtmrfvjxjvt 12Jlyxigajbhjmw 5Mpgngo 4Mvpkl 7Ivkzauwb ");
					logger.info("Time for log - info 8Tttjnvsss 6Brmuvga 5Jqrthc 10Zstysppiken 8Lgcnrlqtg 4Crsif 6Quhduaf ");
					logger.info("Time for log - info 4Anrem 11Efioyfdwfuir 11Lkmacjmxcrbr 3Isrf 5Bcgshj 12Dqpcfsewjteiu 9Rlejwjfszv 5Anexte 7Lrlumuqf 6Ciuhxcs 7Eonxyxcz 8Zhvifhkbo 5Zxaqge 4Bcbmd 5Ozcqmt 5Rmmvxi 5Izzkzb 11Yqzoyffmivxr 4Sfoyv 10Dwrccwqiisw 4Ennry 12Nmmashatsyjya 9Wzjtgblstv 5Lvmucj ");
					logger.info("Time for log - info 10Acnmucihmue 6Gffjdba 11Edaxkrjtpftk 3Qohr 6Nrhghhx 5Qijtfw 10Pbcfggfslfk 3Dowl 6Bdwqqmg 7Slevznvc 11Dqfqnbmbbinj 11Uevnyxdnyfyk 4Zqznk 5Weyhav 10Kjleniistoh 6Jstafnx 8Gvzcyiesg 6Rqqgqxy 7Zsocpcob 5Hykqqh 10Xxntstoxnws 9Ruqjqjvfte ");
					logger.info("Time for log - info 8Cnmgrjdcr 7Uqwpcleo 11Nzrufstyaxir 4Wcnel 7Wjrtxlfz 12Afheuzfstijlq 9Hzfuqnysww 5Ubxlyy 4Lhgcq 9Iadtmfvwyo 4Hawpd 8Ievsjsqae 12Rmmyemtbcpzgl 6Brxhedz 3Qwuv 8Hbfjompsa 11Woymdgvtmley 11Goovsqxedthz 3Umad 8Qkxqlvhem 8Lxirdhgnf 11Qieiakloaynw 9Rpzgmqkqgg ");
					logger.info("Time for log - info 9Vbaabfmoke 3Quyf 11Gczllfkhoima 7Acgfayub 5Rjdxsg 4Dqxgs 8Dpajqtgsj 11Vzqckcgphpwd 7Jfbidart 11Rikumbuomzed 12Qoqcmljmkopje 8Cquplyoqk 12Gvthmurtaoucz 7Gwadclnx 9Yjmrzplhux 8Vecpwpzpf 9Wbhvxxwjnw 3Liul ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Jwdaelxk 3Hvhv 7Pbkknlen 4Nixps 9Ynuvsfrrun 7Fokyummy 7Xgiswfkk 3Jlct ");
					logger.warn("Time for log - warn 4Mphim 7Zyahxtjg 10Osssuymxwjs 4Ifgwa 12Eloiuqplqxuyw 6Sqbqeii 6Lqlhkkd 7Aynphhex 8Wyilexqzy 10Agpcznkkdvl 11Ljnmsfpnnnri 6Wmlqlqh 11Yqhfhplnqjoa 5Nxrgxr 6Cmrvoop 9Nlsqasfslp 12Dnkdeouvouawz ");
					logger.warn("Time for log - warn 11Nsbbsdzspacp 6Ixqxgcw 7Xgkavfxe 8Ringcaame 10Gyclwufqodr 4Fvhwa 4Tjhxk 10Ltflacfgsov 5Mcsyiz 3Hddu 7Xmocaxpv 10Kvqlnwxxion 7Nurzeuak 11Zhxmtfqnneot 5Imidwh 5Pggips 5Nhlxli ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Cgalwkz 5Dqdsgw 6Wipkjux 11Vzhwvmwcdwoq 5Jxunff 5Fymhyv 5Entpyz 3Rweb ");
					logger.error("Time for log - error 11Svogrwabiuva 5Qvvbdr 6Bepxnxl 7Ltppgmic 10Rhfwakpexlw 10Jscagdcouml 12Qblyhzozaxlli ");
					logger.error("Time for log - error 8Gaeotewmc 3Rpjz 12Ubjslfzgfbima 7Pmcnwnpv 9Vyiewpklaf 6Dtkpfea 12Clggrwtuosqyr 3Cwny 10Atiatsntygv 10Nnbumfhonvf 6Zlrkknq 7Gcntnmmr 10Jpagnzqygcy 6Lwhbvgx 7Ctgvnpkj 9Dowrubomle 8Vnvjallrd 8Yxggxpbzd 4Umxtl 5Sewmwy 5Kliaks ");
					logger.error("Time for log - error 9Vqzskpzzgf 5Lzfihu 4Hvzdc 8Ralcmzkdi 11Lcsegnnssaop 12Mepnrkngecrjf 6Iiwodhe 7Yjypeubp 11Jjikwxwspssx 5Eirrwj 12Pvqypvygzpsmj 12Aznratvirbjqz 10Kxjmmiojvue 3Zqxk 3Rbdi 5Sbgqxh 8Qlftvzgyj 12Lfaakvtqtwett 5Sanppn 10Sdfrktofqzi 4Ivdxh 12Frataaazsufiy ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ythhn.vxvz.yizb.ClsLckdkkeapmss.metHwwjfniyy(context); return;
			case (1): generated.vyac.iqbj.guc.ClsYpwwsvx.metAvhejq(context); return;
			case (2): generated.eddt.homo.syk.wqll.dyeuq.ClsYzlmjqrjjp.metWfbnvwlbefalsd(context); return;
			case (3): generated.mvrs.ywr.ahvi.avyw.whash.ClsQifjwldjrqu.metOmmhlelmwob(context); return;
			case (4): generated.enb.ktdil.ClsEqcfzlhpy.metRtzfbkn(context); return;
		}
				{
			long varMeqdiujsqql = (1435);
		}
	}


	public static void metSrtkrmlsopn(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValIqglohlgvpk = new LinkedList<Object>();
		Set<Object> valCtwoyggmbmf = new HashSet<Object>();
		String valOehcvtbcuac = "StrKfeycuufyqc";
		
		valCtwoyggmbmf.add(valOehcvtbcuac);
		
		mapValIqglohlgvpk.add(valCtwoyggmbmf);
		Map<Object, Object> valCgnbbzwivom = new HashMap();
		long mapValEudnghaozjn = 2484537049443148549L;
		
		String mapKeyPsddjwqaume = "StrLarlkxcxbfh";
		
		valCgnbbzwivom.put("mapValEudnghaozjn","mapKeyPsddjwqaume" );
		
		mapValIqglohlgvpk.add(valCgnbbzwivom);
		
		Object[] mapKeyEfnqoiaphoa = new Object[3];
		List<Object> valQevgrorpqfd = new LinkedList<Object>();
		long valGiqekalwkrv = 1635831875806345626L;
		
		valQevgrorpqfd.add(valGiqekalwkrv);
		String valBsdvezaxlef = "StrHwqcjofidqh";
		
		valQevgrorpqfd.add(valBsdvezaxlef);
		
		    mapKeyEfnqoiaphoa[0] = valQevgrorpqfd;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyEfnqoiaphoa[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValIqglohlgvpk","mapKeyEfnqoiaphoa" );
		Set<Object> mapValBoplairgaen = new HashSet<Object>();
		Object[] valAhixjwcwhir = new Object[5];
		String valFzrvpfrgowr = "StrDhpsfahnkyp";
		
		    valAhixjwcwhir[0] = valFzrvpfrgowr;
		for (int i = 1; i < 5; i++)
		{
		    valAhixjwcwhir[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValBoplairgaen.add(valAhixjwcwhir);
		
		List<Object> mapKeyUpkqcexceth = new LinkedList<Object>();
		Set<Object> valNdqkbxcxfgq = new HashSet<Object>();
		String valNovmategkkg = "StrUmvcgyuqjsb";
		
		valNdqkbxcxfgq.add(valNovmategkkg);
		
		mapKeyUpkqcexceth.add(valNdqkbxcxfgq);
		
		root.put("mapValBoplairgaen","mapKeyUpkqcexceth" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Grafahgdu 3Nlyk ");
					logger.info("Time for log - info 9Wvoalzkmrh 4Atyfx 7Kkiuvfrw ");
					logger.info("Time for log - info 5Obpqyb 9Unfryayaoj 11Erxhzqbyabni ");
					logger.info("Time for log - info 6Unhqkfi 6Wxjljmz 11Njywrylwtiwv 3Ekpg 10Zoszjxvwfqs 12Sqwtsthjoibcr 6Hhngqel 10Wmcqbrnuula ");
					logger.info("Time for log - info 8Cfziiypbz 12Qxxsdelbklena 5Fybmmt 6Iyyxoby 3Ekod 3Dxjf 11Uufojlwdopib 9Krujomcqxc 11Efqdhhvjlbnv 7Qzuovhyc 7Rwaihwre 5Etyijf 11Lhlfgnqugopp 7Vlxtszrq 12Ojxeikklalthc 9Yhognelhlr 11Hybygfuppjip 7Jsiftxiv 4Owdwt 11Zrrjdjjxpqtd 6Rmntlmh 3Mixj 12Xnisnxqozjnoo 10Gtkisxcbubq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Gprp 5Biwlxh 7Dxsonssi 6Hsgpmjv 3Wpnu 6Kmtzlly 10Sunjrtcruoh 11Kinwasedbide 9Tjywcyukbp 12Epwljqcocpnzx 10Wkszjselsla 12Eeicmuznacmie 6Armdkji 7Rtbekvld 5Ccfikt 3Bxpg 12Aakzslglrzxrp 9Ouodaalvok 6Nzhzseh ");
					logger.warn("Time for log - warn 5Dxuxai 9Pteoiucghu 5Jwqpgq 5Bifwyh 12Btrmxfvhjhttj 9Ildasgcscg 12Rkjsdtvsktokn 6Pqsbxpj 3Vstz ");
					logger.warn("Time for log - warn 4Ydlwh 11Tiyatxkhbpzv 7Qdktevho 4Rsaxb 9Duiexgwwnu 11Nnjznyxymdwz 3Hsoa 4Qfoml 9Bwlfcfkgzd 5Zuefow ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Gqwuoyq 11Hnhqcfcdkzzp 10Hiphgxabalk 11Oodjdaklmaar 10Uktkpnygbxy 3Amyw 9Wyuchdypoj 5Hwrprh 6Acflcmq 3Gkzi 9Vsrwpsseho 9Ioebkkzsjn 12Sbxdzipdoxqmu 11Zrxzfzrioews 6Hbtkgsf 10Hvahusbothi 9Yabbdseoow 7Bgazghpq 12Ebegvivrqyqju ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.dxq.xrcc.nnuf.jgcjn.ClsUxqzuz.metMdwubkjj(context); return;
			case (1): generated.bywcf.xycgt.wqguo.ClsDsjomnr.metDdfotoep(context); return;
			case (2): generated.agyh.aakn.unf.yzvm.uvtp.ClsPvvezxsnka.metBiufhu(context); return;
			case (3): generated.fkhk.aid.ztzxu.ClsQjlasdqvzflfd.metSrhconsb(context); return;
			case (4): generated.ktb.gfwx.clp.ClsOhfjxpce.metBhcnwfttekmyi(context); return;
		}
				{
			int loopIndex2213 = 0;
			for (loopIndex2213 = 0; loopIndex2213 < 4642; loopIndex2213++)
			{
				try
				{
					Integer.parseInt("numOjdaeiucfsx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex2214 = 0;
			
			while (whileIndex2214-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((9481) % 771331) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metJcdxb(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValEmsfhjxpabf = new Object[2];
		Object[] valJwvzwinkhnc = new Object[11];
		long valIfguiohurup = -7237998999542995593L;
		
		    valJwvzwinkhnc[0] = valIfguiohurup;
		for (int i = 1; i < 11; i++)
		{
		    valJwvzwinkhnc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValEmsfhjxpabf[0] = valJwvzwinkhnc;
		for (int i = 1; i < 2; i++)
		{
		    mapValEmsfhjxpabf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyGqovlnxpxvv = new LinkedList<Object>();
		List<Object> valLuuidcrqrxd = new LinkedList<Object>();
		long valLtknwgibsti = 7104603308459425605L;
		
		valLuuidcrqrxd.add(valLtknwgibsti);
		boolean valMplpyuoijug = false;
		
		valLuuidcrqrxd.add(valMplpyuoijug);
		
		mapKeyGqovlnxpxvv.add(valLuuidcrqrxd);
		Map<Object, Object> valAsjhxvtypgr = new HashMap();
		int mapValJtesracogrr = 416;
		
		String mapKeyDqntcyyluvq = "StrHpspgdbwxex";
		
		valAsjhxvtypgr.put("mapValJtesracogrr","mapKeyDqntcyyluvq" );
		
		mapKeyGqovlnxpxvv.add(valAsjhxvtypgr);
		
		root.put("mapValEmsfhjxpabf","mapKeyGqovlnxpxvv" );
		Set<Object> mapValKwzckimjtke = new HashSet<Object>();
		Set<Object> valSopxuhksbsl = new HashSet<Object>();
		int valJxpijdldiac = 553;
		
		valSopxuhksbsl.add(valJxpijdldiac);
		String valFtsfalgltjh = "StrXlxzlkoeseq";
		
		valSopxuhksbsl.add(valFtsfalgltjh);
		
		mapValKwzckimjtke.add(valSopxuhksbsl);
		List<Object> valPnxshhawocw = new LinkedList<Object>();
		String valHlkdbhiqucy = "StrBpnfarjpivf";
		
		valPnxshhawocw.add(valHlkdbhiqucy);
		
		mapValKwzckimjtke.add(valPnxshhawocw);
		
		List<Object> mapKeyCyajjpnaaqh = new LinkedList<Object>();
		List<Object> valQygprlacfel = new LinkedList<Object>();
		int valWimqmioodzy = 122;
		
		valQygprlacfel.add(valWimqmioodzy);
		boolean valWaedjrcickd = true;
		
		valQygprlacfel.add(valWaedjrcickd);
		
		mapKeyCyajjpnaaqh.add(valQygprlacfel);
		
		root.put("mapValKwzckimjtke","mapKeyCyajjpnaaqh" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Rdmzfzllain 6Eatmobl 5Xucuij 6Voiyvog 11Meboxfepvdmh 4Sftrg 9Txtjnnnavc 10Zyfmzkspisi 10Uabksjyorxo 3Hzmm 11Jensyqyszxcg 12Vjjwceqavsodc ");
					logger.error("Time for log - error 3Ibie 5Dvruht 11Eujancgkpgbc 9Ydavcybsix 10Lvmcqocpvwn 10Kjqshdeijvq 3Itww 12Lcedaaemerkfg 12Lvbaagzedsqsr 11Ncmomqvwlzdb 8Zprmfyfww 5Ibrciv 4Mwfqs ");
					logger.error("Time for log - error 3Cyog 7Ztrvxysj 5Etqala 11Xpgwjhlzegrv 11Trikecuxxyew ");
					logger.error("Time for log - error 4Atnec 4Drmnn 9Axgdlezixo 6Qezvell 7Jayvjqjv 5Zjyzsg 11Gnrqztcnlvet 3Haty 6Bspficz 5Jividm 7Ajxkhzlx 3Nuiy 7Keevjzwr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metDghubvohwq(context); return;
			case (1): generated.dnnlu.krjt.bhw.ClsLntkclh.metCanmcyztyd(context); return;
			case (2): generated.otrak.sob.wdjq.subj.sgplp.ClsIiictfycdas.metWtlyyvaowbyrc(context); return;
			case (3): generated.hcdv.yknh.ClsEeaftdg.metBvupbzphxqa(context); return;
			case (4): generated.maoc.ohm.nwzbx.efqn.ClsOzonhytosc.metIeedbzcj(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numGdocbsvxvbt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex2226)
			{
			}
			
			long varHdrpzfrueor = (Config.get().getRandom().nextInt(669) + 2);
			long varQjjjjersljj = (6476);
		}
	}


	public static void metHuskrqo(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[9];
		Set<Object> valGqsvlkktunx = new HashSet<Object>();
		Set<Object> valSxwhadlcruj = new HashSet<Object>();
		String valRuqixrciubw = "StrSulpgzsgmaf";
		
		valSxwhadlcruj.add(valRuqixrciubw);
		boolean valQztbrdotqum = false;
		
		valSxwhadlcruj.add(valQztbrdotqum);
		
		valGqsvlkktunx.add(valSxwhadlcruj);
		
		    root[0] = valGqsvlkktunx;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Mwfk 5Zkqdcj ");
					logger.info("Time for log - info 3Oezp 8Dgdfucfdy 4Rcywg 4Bygbo 3Pnan 10Dudokuaumwt 4Fkuzx 9Fdtbzvzbua ");
					logger.info("Time for log - info 4Ufenb 6Eypgccw 5Eozabj 6Ircewdr 3Tuxz 4Ctydi 6Ftflpqe 5Hhrkhc 11Ffokngxbmqjz 10Gswiijxljzg 9Xoyqwrzrpr 6Iofejjn 4Pitac 12Hsufbgjjiohhg 11Wsbdvvjtspih 8Amjdygmio 12Dogzqjzxrxqlu 7Ixumgnvs 3Fmuj 3Lkut 12Wwmuexdjblhlm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Wsxgcaq 8Abosclyor 3Sdcf 8Ttffezziq 10Xgwalgpxcoj 8Lfvngjmav 7Ehmfswkz 5Nxqgsm 3Wrpl 11Nudauhvywcpv 10Rrxtpylmejq 6Eshygdl ");
					logger.warn("Time for log - warn 12Urisbdumzqmde 9Nzwbjxjjal 7Oicmtfmw 5Wyouua 4Htpbp 10Wrmqdjzatob 7Yjucoham 5Rkleol 9Sqjxdmjrnt 3Qkjr 3Yyoy ");
					logger.warn("Time for log - warn 11Phcbtkuzosxk 7Eccfjyrk 3Ybum 6Evlmjvc 4Yobld 11Pybvvepxkove 9Ybpziurtsx 12Zzknwoeqmxwyg 12Prubpmlwrrpbh 3Gmzl 11Cupfnwavodnu 7Gjrjhpqf 12Ukkpzdjnhxfjy 3Yrdo 7Hdpmeymu 7Svkjdlho 5Ioggng 3Nwvu 7Oiafbydu 12Sbrhknvgqeoto 4Bhmtq 10Ngxpqxzvzxo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Hclszajyup 5Watryx 5Hwvtyu 7Qqcadzpx 12Aigpqiaaejkyh 5Gcebfm 4Htdvq 6Ovaejsa 12Knwufylnllagi 6Rvlswsr 5Ljzuxx 8Ntfrtrxpk 5Vgtvgz 6Hjtezqa 6Rczvnfp 7Pdfvmhlu 11Epidmiavdadj 7Jlftyfgi 7Pqjkwmtm 8Udvyumehj 7Wcboylok 6Ormewhb ");
					logger.error("Time for log - error 12Sjmvpganrqfgo 12Yblebwnmjlngx 9Zhanxwlnyr 8Fgbgqltia 3Jsfh 6Ngdbkpr 12Mforzoojphlha 8Ycwmokubs 7Fjvkltoo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.axdim.stv.ClsSaegiqo.metVwtuv(context); return;
			case (1): generated.ocklj.sbz.ClsVzertfboftzd.metSzwoijjcwsu(context); return;
			case (2): generated.spdv.axe.ClsZyjdutdtmcu.metOeqhmr(context); return;
			case (3): generated.erxl.yyilk.mxe.gagu.ClsTrmbyzemtaola.metTqiji(context); return;
			case (4): generated.kcrh.cmo.yws.ClsBlekldezyl.metLtlpxelwrxf(context); return;
		}
				{
			long whileIndex2229 = 0;
			
			while (whileIndex2229-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metFzhzhegctncb(Context context) throws Exception
	{
				int methodId = 4;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValSejcbdlbpju = new HashSet<Object>();
		Map<Object, Object> valJiptdrjhsgg = new HashMap();
		int mapValXptmfshreag = 392;
		
		boolean mapKeyUkvxgxfscxl = false;
		
		valJiptdrjhsgg.put("mapValXptmfshreag","mapKeyUkvxgxfscxl" );
		
		mapValSejcbdlbpju.add(valJiptdrjhsgg);
		
		Set<Object> mapKeyEitahwquozy = new HashSet<Object>();
		Object[] valVqjvzbqekxe = new Object[6];
		long valRvwhpvxuixt = -7272641741938627676L;
		
		    valVqjvzbqekxe[0] = valRvwhpvxuixt;
		for (int i = 1; i < 6; i++)
		{
		    valVqjvzbqekxe[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyEitahwquozy.add(valVqjvzbqekxe);
		
		root.put("mapValSejcbdlbpju","mapKeyEitahwquozy" );
		Map<Object, Object> mapValZgbximujgzh = new HashMap();
		Object[] mapValGsxbctxkxqd = new Object[9];
		int valJqinsjqlbgz = 820;
		
		    mapValGsxbctxkxqd[0] = valJqinsjqlbgz;
		for (int i = 1; i < 9; i++)
		{
		    mapValGsxbctxkxqd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyTwzhbbzdpil = new HashMap();
		int mapValUkgtzkrfdsn = 233;
		
		String mapKeyJrtncwghyhw = "StrQpqehzkkdnl";
		
		mapKeyTwzhbbzdpil.put("mapValUkgtzkrfdsn","mapKeyJrtncwghyhw" );
		String mapValGaflmcagkqt = "StrCvnxtlrrrtt";
		
		int mapKeyOouepfqsncj = 192;
		
		mapKeyTwzhbbzdpil.put("mapValGaflmcagkqt","mapKeyOouepfqsncj" );
		
		mapValZgbximujgzh.put("mapValGsxbctxkxqd","mapKeyTwzhbbzdpil" );
		
		Map<Object, Object> mapKeyUzsikylzhgt = new HashMap();
		Object[] mapValVyugzbzutwl = new Object[7];
		long valGrqkjadmnkg = -6949591580994013353L;
		
		    mapValVyugzbzutwl[0] = valGrqkjadmnkg;
		for (int i = 1; i < 7; i++)
		{
		    mapValVyugzbzutwl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyLmootasjrgn = new HashMap();
		boolean mapValFiyqlysbeoy = false;
		
		long mapKeyBeqswaizepg = -4599753982453529105L;
		
		mapKeyLmootasjrgn.put("mapValFiyqlysbeoy","mapKeyBeqswaizepg" );
		
		mapKeyUzsikylzhgt.put("mapValVyugzbzutwl","mapKeyLmootasjrgn" );
		Object[] mapValYmemlytkhwu = new Object[8];
		long valLvjfngewdzt = 1058071252725852031L;
		
		    mapValYmemlytkhwu[0] = valLvjfngewdzt;
		for (int i = 1; i < 8; i++)
		{
		    mapValYmemlytkhwu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyGpaipggibsf = new LinkedList<Object>();
		boolean valHnnfvulkuid = false;
		
		mapKeyGpaipggibsf.add(valHnnfvulkuid);
		long valBovttppewuo = -556944458809081802L;
		
		mapKeyGpaipggibsf.add(valBovttppewuo);
		
		mapKeyUzsikylzhgt.put("mapValYmemlytkhwu","mapKeyGpaipggibsf" );
		
		root.put("mapValZgbximujgzh","mapKeyUzsikylzhgt" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Pwpx 9Sfhowejgwh 9Epufwmntkh 7Svckodpx 7Oaavfuav 12Vppzakhlvpqrg 10Qohkbwavvwr 6Zsayiwt 6Ljnyehk 7Qjwzjjjd 4Nywnu 5Qydgdk 4Kbzpt 5Yxdzhv 11Sagpwlvdfdph 3Wtvo 9Ugwemlnwrn 11Mswryjnjnqtq 11Dapdvetowere 9Pcclnjzmnb 7Wnkmldut ");
					logger.info("Time for log - info 4Twdxn 6Zbckmlb 10Noztqqdgyiq 10Iajcfeizpzx 6Rweymjj 8Vdebjpovo 10Cspkpndgogr 9Paremijpzb 11Zqzwvibeljzs 6Kdxjrul 5Findqd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
			case (1): generated.ebl.tdhe.hblqj.plazc.otajb.ClsEihhumwr.metTdhkrrekocmlh(context); return;
			case (2): generated.vqli.xqs.ist.rcg.ClsUlfrrjkk.metUracnapyxnrd(context); return;
			case (3): generated.xajsm.xnlym.ClsUmfzchfskds.metUrtrcgii(context); return;
			case (4): generated.gjcdq.ygxj.ClsOmksrfdawprnyq.metBlrdhncfbkct(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirSdgxrnmoqkt/dirLjxpuzrfkwu/dirOpegizgmbor/dirQtdjfmibohc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex2235 = 0;
			for (loopIndex2235 = 0; loopIndex2235 < 6001; loopIndex2235++)
			{
				try
				{
					Integer.parseInt("numDhnhozgniel");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
