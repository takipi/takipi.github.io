package generated.gbss.lmi.dvqsw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsLptludgibvpvw
{
	 public static final int classId = 172;
	 static final Logger logger = LoggerFactory.getLogger(ClsLptludgibvpvw.class);

	public static void metMeokvufzyez(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valBumgxwcaepe = new LinkedList<Object>();
		Map<Object, Object> valJctbpliwoyg = new HashMap();
		boolean mapValEspaipkogts = true;
		
		long mapKeyDffwyxfnwbg = 7512513730696509562L;
		
		valJctbpliwoyg.put("mapValEspaipkogts","mapKeyDffwyxfnwbg" );
		long mapValZvdskhkwslk = 8554254816657016837L;
		
		String mapKeyFobdkxpamlf = "StrLghunldwsax";
		
		valJctbpliwoyg.put("mapValZvdskhkwslk","mapKeyFobdkxpamlf" );
		
		valBumgxwcaepe.add(valJctbpliwoyg);
		Set<Object> valFbcxgkacpwi = new HashSet<Object>();
		String valVszstipnfhr = "StrDfuyenpyfuj";
		
		valFbcxgkacpwi.add(valVszstipnfhr);
		
		valBumgxwcaepe.add(valFbcxgkacpwi);
		
		root.add(valBumgxwcaepe);
		List<Object> valJeavvlheofr = new LinkedList<Object>();
		List<Object> valIrzjiwwybgt = new LinkedList<Object>();
		int valHfukpnvkgzo = 736;
		
		valIrzjiwwybgt.add(valHfukpnvkgzo);
		String valRffojdzeghs = "StrXsrulpwlyna";
		
		valIrzjiwwybgt.add(valRffojdzeghs);
		
		valJeavvlheofr.add(valIrzjiwwybgt);
		Object[] valXuajenwxqii = new Object[7];
		long valVrgufrejeum = -2313575798621576055L;
		
		    valXuajenwxqii[0] = valVrgufrejeum;
		for (int i = 1; i < 7; i++)
		{
		    valXuajenwxqii[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJeavvlheofr.add(valXuajenwxqii);
		
		root.add(valJeavvlheofr);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Meanby 6Aoreseo 12Xhodabayvxrkj 3Ivkj 7Hfunvxyt 8Zdrfmqhfo 8Zoihxjpik ");
					logger.warn("Time for log - warn 12Lvvaqvjrojqql 7Pipqosvd 3Xrfa 4Mzzyn 11Exnsfpapkzkx 8Rgwoxmvuv 5Memxrj 7Aismgcso 7Vxzkmnfr 8Ktxodtpaj 3Bjrd 10Todbuwptftn 4Pcyjt 3Mvxc ");
					logger.warn("Time for log - warn 9Xixsoldoze 9Buezoxazmz 4Ivelh 3Aexa 7Wxslhkrx 3Jtal 3Ojvk 11Xycqumvpwrgk 5Favkll 11Coejzyvvwdgy 12Hvowdvbbvqslg 12Sytyeeigtxzdk 5Lnresu 4Qzshy 7Ghwyomid 4Vrrzu 10Xufnhvdrvuz 9Lbuklcxvux 11Nxrgpccdiooi 4Ghjlh 10Uaxtzwycyvl 6Kjyovss 5Vfywlp 6Rclgads 7Surbprch 12Umsfehczlybqv ");
					logger.warn("Time for log - warn 7Yfapyorg 8Zaamxthof 6Wnzxhbh 12Gbwutwifutzrj 12Xvnzukolanhem 10Lojdfqnnsvy 12Ixzharthsdock 6Zojyvxu 3Dnnc 11Wtdkevotohaq 7Jsknthor 8Eousurdgc 3Xbvi 8Udjqqrcql 5Oslbvg 4Uxbaf 4Fizic 4Uzahs ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hbqjp.kifli.leg.jlyd.ClsYgtwztbknhdmc.metSqhmmbh(context); return;
			case (1): generated.lmq.wwll.mcjoz.ClsBqjxdpu.metYpiqwjcggcaa(context); return;
			case (2): generated.fzd.qgqjp.ClsVzqqvdhb.metMsjbhqpplani(context); return;
			case (3): generated.wyah.shgd.ClsOoifqzin.metOdxfuenha(context); return;
			case (4): generated.blsj.gki.ClsOuhbksvj.metEkzrb(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex23110)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numHhpxpjjtaxt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metJevsr(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valGziqjgzilpc = new Object[11];
		List<Object> valHcyzuzeomii = new LinkedList<Object>();
		String valBhrlikhoieg = "StrQsgwibnquft";
		
		valHcyzuzeomii.add(valBhrlikhoieg);
		String valKczkqndscxp = "StrMtvzvxxdtyx";
		
		valHcyzuzeomii.add(valKczkqndscxp);
		
		    valGziqjgzilpc[0] = valHcyzuzeomii;
		for (int i = 1; i < 11; i++)
		{
		    valGziqjgzilpc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valGziqjgzilpc);
		Object[] valEmjfignrmof = new Object[5];
		Map<Object, Object> valIvttokzhihg = new HashMap();
		int mapValLajpbitkdqv = 242;
		
		boolean mapKeyEyscodebpdb = true;
		
		valIvttokzhihg.put("mapValLajpbitkdqv","mapKeyEyscodebpdb" );
		
		    valEmjfignrmof[0] = valIvttokzhihg;
		for (int i = 1; i < 5; i++)
		{
		    valEmjfignrmof[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valEmjfignrmof);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Uqstcxqmzhd 12Twlbnnezkayxn 7Edbpjxkw 12Vepznwcrfcbvo 8Gkznyekyv 10Ejzqosalndd 9Rxmxmyrwry 8Pgvfilmhu 11Mizxnelbjevb 12Lvdkentchjjvb 7Zvyhltov 11Hxjaxvzgpzgj 3Xhbf 9Corvtwohyv 9Quwdnkovuv 6Ekpbdbm 6Phgjubn 6Lcnkwug 7Jkyjncwt 4Daibj 8Bdgnwpjeb 4Uahvs 3Mwih ");
					logger.info("Time for log - info 4Cgnkl 4Zsxch 12Fwccguzoeygjp 11Uncrrhzdflxa 4Qwotv 11Fzklhazhhqab 8Ugzkbimqf 6Qvncols 3Ztcn 10Hxqvbrxvvtr 12Hhyoksdfhthgd 10Dwzhibsfrva 10Gcciorrjwec 7Dwylolqh 10Vppqojzjjkw 11Muuxykpwueae 4Rbaba 11Dbjbvylcuhws 4Jdksj 3Ebcg 7Olurnpjh 3Gcnb 4Nhqbi 10Yedjflufctw 8Evhfuukzi 11Gujtxjovevwe 5Ormkkd 7Aaitwfey 3Dwqd 6Tgsvkzb 9Dpiioiiyrr ");
					logger.info("Time for log - info 12Nnxcxofelaevq 10Ihvfeoqlhgt 6Fgimnky 8Lzqhlcmpa 3Qmvc 7Cmmgngxf 4Cmkiz 12Mzogapyigaxqv 7Ojbybqvm 4Zauhm 9Jtkpxovhqp 6Rjjmdky 7Zqbvzahf 7Fxvzaacq 10Ilmuxhfdjsi 7Nurmdvfm 9Lmiqhlsdce 8Mvbdvlyiz 12Gzazqcvhkvvnu 4Obsnv 5Jltkqe 10Iiiokvynrkp 12Dglljsffwtksj 12Gzbjqdlmoozvd ");
					logger.info("Time for log - info 6Petrdjb 10Aplhyybdajo 9Bcdwqtxrtn 7Qoolklhz 7Eejsqwlx 7Ukzqhgpm 6Ovrqpiz 9Tsixylaype 5Nzhwmu 3Jjhv 4Qiugl 8Jckocxisg 7Lhvdqgii 8Pzjwmihpp 8Kzhtxemch 4Zpmtg 8Inbrvnaij 10Zxqkzsozppr 5Mmqdfp 5Ykaptm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Cayj 11Jwtghkvvkopb 6Nopcrhx 6Xftsext 6Lkkgtxx 6Rqveeaq 6Rfnbszd 9Oppolwqyvh 8Lnmztxuek 9Mwkpcfuaqm 6Uygzgoy 10Evhudjcurgz 5Lnxtoj 7Zzqshhsj 3Edbr 9Wnmnhcgbqk 9Lebhxkqkky 6Babjqno 12Fymynigbwobjl 8Urfnnznrp 8Gwpbrqjbw 10Ecjkpapuyjl ");
					logger.warn("Time for log - warn 6Rktrunb 9Sogspyxodw 5Ffkawv 11Diafrgvfuckt 9Dxpkdkdqqa 5Ewhchg ");
					logger.warn("Time for log - warn 10Puurrunmgcn 10Oqvgtuyyuon 7Lymewynb 9Fozaurztcd 5Qwcelk 10Utsdopuqawm 11Jdkackvfvnwt 9Gopiytakhc 12Atxkhdokddsvb 4Fvlqu 8Akbzyuonb 11Wdpgtqqvhwgd 12Dfynmbgexcnzp 11Ujyhxbtljgur 8Fxkzzeclw 11Hprtxsnbpqah 6Xnkibbg 9Mzylpcgdpt ");
					logger.warn("Time for log - warn 11Dvfrqcdunoyo 3Aerz 9Usaifooxvf 5Hvnmrs 3Eiwn 8Pgvkqhowv 12Srsuisvnhmezk 10Uyyiamuhmsz 10Xszgkuuutmu 4Cacip 9Kkxlbpamjm 8Buluxsvxp 10Rclamnuiyai 3Laiy 6Dskomoy 7Lqqrhapu 9Wwapyzrbnm 6Wvqegpe 6Fgqwsvr 6Khyioxz 7Atscntus 6Trpeqtl 3Xjbs ");
					logger.warn("Time for log - warn 6Ujcfcyt 10Hucjamxkzno 11Wksqlyrdltrm 7Qoljpjdt 9Ghdffiuyvr 4Klbdj 10Kldkmofelxk 3Disq 8Cigwjlxny ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Qvdygorrpu 4Zcucf 8Ygghncoud 12Ezenfflqmmttr 6Ijfntki 6Jqpilzu 3Rjot 12Fbodjijsquffd 3Vxrz 4Gfglo 4Vqveo 7Wzmihtsp 12Xgcyqlwdbvssb 11Uqchtakjefzr 8Rhgngvfee 6Pmglokr 6Qqqvukb 7Hsoirwrn 12Zsmxpzpfcujvc 4Lvrom 8Dgflixnuy 12Qbvyyizjwwsvj 7Abrufjlu 12Wdzcobavbzdvm 8Xufpzwpgx 5Ymizpo 7Xetigkcn 11Svdrevmtirpe 6Wqgklqs ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.sxepk.qoxr.ClsOlkemveail.metSoyjjijmnpnjwu(context); return;
			case (1): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metChpajwh(context); return;
			case (2): generated.obwsb.fweao.vluj.ClsLnkmgpfh.metZhkbnkixegsriz(context); return;
			case (3): generated.tau.glw.atmw.ClsCedrqvgmxtsj.metVmijeiavbbbbxs(context); return;
			case (4): generated.lxmnm.hdgf.ClsBecbgmyq.metXxaphxbxrzzp(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirMqsthsvipfd/dirQifslaersir/dirNtmlrnjityp/dirPdtfmpyahfn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex23116)
			{
			}
			
		}
	}


	public static void metZydcmbkku(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[5];
		Set<Object> valTevzpmbqesp = new HashSet<Object>();
		Object[] valTvoagqmytjk = new Object[2];
		boolean valQjkzwbndlsf = true;
		
		    valTvoagqmytjk[0] = valQjkzwbndlsf;
		for (int i = 1; i < 2; i++)
		{
		    valTvoagqmytjk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valTevzpmbqesp.add(valTvoagqmytjk);
		
		    root[0] = valTevzpmbqesp;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Uxbtb 9Qxqeqzneom 12Ntvckhpukofac 3Gfri 9Shyigccsmf 11Eyyydtdldzys 8Yooqkgxfr 9Duklabnffm 5Ukraxz 8Ahuwpeutr 11Imfxavpcygbn 9Hqplncqovr 6Ckcafrj 12Htglzdxuisiiq 10Zghiwwptqck 10Frcocwmkxhe 3Qrdb 9Ossflixoxb 10Zhzblmkgcbv 4Fzyvv 3Ieha 6Hzwgmll ");
					logger.info("Time for log - info 6Kkgnldr 4Aavgs 12Gownzrruohyhd 4Qqidn 12Fzkwkeipnejfd 12Qhpeijunvwnqy 3Jbzr 9Adllkjypsm 6Ojqwnlq 11Ugdiijjqlbsg 9Amdqpfuzhy 11Ffstpefkavij ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Mfusyf 8Rzovfyzep 7Tkgyinxg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Pwdbi 9Sdbecynzqa 10Ybudxixubmn 6Dqaxary 8Waoyndool 12Izhzluolnmakf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pfjp.usowt.ClsIsioyesmm.metWvpjrpagibthng(context); return;
			case (1): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metZfqpeqqdiyyj(context); return;
			case (2): generated.xbfov.nkh.ClsAkppmbind.metHtbkmz(context); return;
			case (3): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
			case (4): generated.ado.osup.ClsKlojrrjbtxsxbb.metFvuph(context); return;
		}
				{
			long varHlxiobtiatl = (Config.get().getRandom().nextInt(184) + 7);
			if (((varHlxiobtiatl) + (Config.get().getRandom().nextInt(180) + 4) % 693394) == 0)
			{
				java.io.File file = new java.io.File("/dirRlutfxhboyt/dirMcowbolbdxy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
