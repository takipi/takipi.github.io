package generated.xajsm.xnlym;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsUmfzchfskds
{
	 public static final int classId = 11;
	 static final Logger logger = LoggerFactory.getLogger(ClsUmfzchfskds.class);

	public static void metYensggsobl(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valBfrpkflcade = new HashSet<Object>();
		Map<Object, Object> valLzjfwnyaczf = new HashMap();
		int mapValSvtpufqiqya = 392;
		
		long mapKeyWhkkrycnwmw = -2401051885113232329L;
		
		valLzjfwnyaczf.put("mapValSvtpufqiqya","mapKeyWhkkrycnwmw" );
		boolean mapValIltjwqddvil = false;
		
		long mapKeyWnvrkhtxeae = -3181129547277606973L;
		
		valLzjfwnyaczf.put("mapValIltjwqddvil","mapKeyWnvrkhtxeae" );
		
		valBfrpkflcade.add(valLzjfwnyaczf);
		Set<Object> valNdqcimmntrr = new HashSet<Object>();
		boolean valKzkcxigpbbb = false;
		
		valNdqcimmntrr.add(valKzkcxigpbbb);
		
		valBfrpkflcade.add(valNdqcimmntrr);
		
		root.add(valBfrpkflcade);
		Object[] valSsphpsvsgga = new Object[11];
		Set<Object> valRnqhijtwacb = new HashSet<Object>();
		boolean valTfalyztuqzh = true;
		
		valRnqhijtwacb.add(valTfalyztuqzh);
		
		    valSsphpsvsgga[0] = valRnqhijtwacb;
		for (int i = 1; i < 11; i++)
		{
		    valSsphpsvsgga[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valSsphpsvsgga);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Igospz 5Tsnjcf 6Guzyiko 9Bvcqzamxiv 3Dtih 4Snajs 8Bwwbbfdip ");
					logger.info("Time for log - info 8Gxwtjcafe 6Fftdirp 3Vqir 5Qxogwj 11Qelkzbdnesoq 9Cgapryiytp 11Pextzvaygmhy 12Vabtkxmiydicn 10Zfjnybbwzob 10Ykjotvngjhr 4Mlsun 5Paicpo 3Bgnl 6Zemsixr 12Klbgnallzjjhy 9Tydmvhjaik 7Nxmvkswx ");
					logger.info("Time for log - info 8Gxxakbcge 9Sboepitvux 12Ugxmagvdssfrr 5Pzfolf 9Cqnhdbzlta 12Srhvfwejpoxqi 7Bnivlzwb 10Zwmrpuropgp 3Yhse 6Phprqtg 6Ohtggbr 8Ncdnoabml 4Hrdhr 11Caqbodhydhgv 12Toqyykgmjskof 4Rfrzl 3Ksfy 8Zdqvqiudk 10Gbtfjhfadiw 9Qmqdqdohgq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Gfvjtclnt 9Hhldvxaifw 3Zxic 7Wozoxmfg 11Onyehboakobo 6Wzyfhey 8Xmqxqskbe 12Ougeumdhvrltx 9Gbnorptvyz 3Tjxz 9Gvobwdptrm 9Htihgqdwqy 7Gjkworcq 7Cciwqdgi 3Idbj 3Tazz 12Adyochwpijvpr 3Zoqj 8Ppfgdddex 8Wfrgpvmqs 10Nmhybgpsbwe 7Fdupjxbn 4Cxdja 5Tukpih ");
					logger.warn("Time for log - warn 10Ylsapvtwpgw 12Zxwjawwtpemyz 6Fikkqyu 11Zozkpjsddnlh 9Mqeoiuwyiw 10Ocbbhltzedq 6Ayrddfq 3Voer 7Oijwmsyz 10Kznwkwqwgwq 8Korteogsp 11Xwpofciaduay 6Jxiisqy 9Tkdusrcfbk 4Knhnv 4Dzifd 12Ymqprrtuwohkj 4Rfunu 7Fmqnknwv 8Rjlfcquqw 6Kexprih 9Uuzbjuangh 8Jvjcoksxc 9Lpjsdocjqd 11Mxaslcwakypj 11Efxymesnafkm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Qcrarqgoj 10Tcrfrfhisno 6Idgsmjk 9Acojctrmqn 12Kageduozguqel 7Frrzaxak ");
					logger.error("Time for log - error 6Fenalym 7Jxsvzzsu 11Yeejixfvnksx 8Opmslsjcn 6Obdxqod 10Zdffcsubyev 9Kzgvctswlo 12Ehirxwohuovmn 6Azdnrck 10Wrmkyscagrp 12Fhlwmpexbkkmr 10Zutgrfcmeml 6Uxnrlkn 12Jhlvuzlwgtvno 8Hzmjoysvs 10Wnlesgspnis 6Hmtvfrk 4Tiftp 5Ijcbkd 3Qjhx 7Irjpfhuw ");
					logger.error("Time for log - error 12Bdauaedrvbntq 5Vgvrsc 12Asofekkxljjbb 6Hxcxhzc 4Cnofk 4Lqmbm 10Qpfggcbegfg 11Vqznjbdxewgo 7Vpgrbamm 3Vrzl 9Oqgdylwces 10Ztlcdwmkaaw 10Jnqrbigimjd 5Aieefu 9Iobzevfoyx 10Couszkkmfrh 3Pita 11Hpnjjatbxwyh 3Nkqc 10Trugozovjvp 3Bite 7Ydpdesvl 4Arzrq 9Ioolvsunmn 10Jsulgbxshrx 6Rkvopry ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kagu.fqc.glv.ClsFpqeltegzcdg.metCggjvqrbftuem(context); return;
			case (1): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metUfpufoucpqucye(context); return;
			case (2): generated.deuz.rvz.jsq.ClsHbyckyeswad.metJegrkbyqxodbpi(context); return;
			case (3): generated.sttvf.uvyp.navra.vntc.wlw.ClsLyfkosygvnxgsh.metKtvfgctzqb(context); return;
			case (4): generated.rub.wtuur.cpewn.fdq.jektc.ClsLiscwkily.metFxfyfwekmvvpv(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numFbfsgcnekfn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metGwtzcndljxhwes(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valFjayvwkrixk = new LinkedList<Object>();
		Object[] valSqsiloxowbr = new Object[7];
		String valLoeobrkmsvs = "StrKfqgufeubak";
		
		    valSqsiloxowbr[0] = valLoeobrkmsvs;
		for (int i = 1; i < 7; i++)
		{
		    valSqsiloxowbr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valFjayvwkrixk.add(valSqsiloxowbr);
		Set<Object> valMzotoqrhllm = new HashSet<Object>();
		int valYssqtyzeszl = 900;
		
		valMzotoqrhllm.add(valYssqtyzeszl);
		long valUyciacwkljm = 3176414840460349106L;
		
		valMzotoqrhllm.add(valUyciacwkljm);
		
		valFjayvwkrixk.add(valMzotoqrhllm);
		
		root.add(valFjayvwkrixk);
		Object[] valZitnotagllj = new Object[7];
		Set<Object> valAgysgmntlua = new HashSet<Object>();
		String valHnhilxvihge = "StrRxnzjjbnzjd";
		
		valAgysgmntlua.add(valHnhilxvihge);
		boolean valZowrdmsgyuh = true;
		
		valAgysgmntlua.add(valZowrdmsgyuh);
		
		    valZitnotagllj[0] = valAgysgmntlua;
		for (int i = 1; i < 7; i++)
		{
		    valZitnotagllj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valZitnotagllj);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Gotpycffu 12Bcdusgooemful 4Igzfg 4Tzywl 5Jfscix 12Zcoohudvquhgy 8Llwkdbqch 3Lzoq 6Pidgjal 5Txswlb 3Czww 10Lwnykwojxiv 8Yeldrjcyg 10Pcjelxqzpbo 7Nowpdnuc 5Gbcflb 7Nstzfekb 6Bketcya 9Vtpbbpxrmq 3Putz 9Csvbxbafyl 3Gogy 9Palvnngvyh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Exshvyulat 12Qnfeyqjijtrku 10Vysxiqcuosr 5Nvgort 12Stxdfgbkfejts 3Ifjt 3Agpj 11Dqhlrbucaxxj 8Kfbxbknkn 3Szca 12Lvyopqldeneep 9Trmraolgoo 10Qqcfmifrslc 12Kbmkcettosojw 9Iigjctwojf 11Pefhoizjdhwo 8Nosgulpwf ");
					logger.warn("Time for log - warn 9Mtznmjgnyj 12Ggpusfdvplgjd 10Jyovajggtxf 4Volxw 8Kcxrdforg 12Bwqtamgzfecms 3Qwzp 6Rulefqp ");
					logger.warn("Time for log - warn 5Yubrmm 5Yfnfic 8Ojektbxvq 9Jyurxckcme 7Hzxsopaf 9Wjtpiugvsd 11Nrmtqkidqaza 9Uulwybkngi 11Vqdsowwhknvq 7Rkggchdw 12Zrfywexvqesab 11Gmrdozonxska 8Wgpiqsigv 6Ljeizfs 10Skwfuytraty 8Mlpdjnttn 5Vpsrqc 9Nsnoqnfivm 7Libelbqs 6Lskorzj 6Qyzwldt 3Mspt 7Gezurhhy 10Zrryvxkrjue 7Wgmzsufs 3Iezt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Yalvohbutuxsm 8Pbwtcubhy 5Mqddbc 11Ljyqncxkldyy 9Ltqmqjkarg 11Ojbqnppifvsm 6Neconrc 4Rwnmq 8Xtjctrwnx 9Jquhzxwhqk 10Acaemdwhayl 4Rhmsn 8Zyuevlswe 5Glmklr 10Pfnzastudyv 12Afltlpmtqbqqh 4Oknap 9Xezbddmqxm 5Zenhgq 11Rszyqwkoeqms 5Fwujzw 3Dklk 5Qyuoel 5Cmhxhb 5Nxiozj 3Pmnh 7Rfwogpqp 10Dgqnrtiznis 8Bhogluekw 7Ueerzcxh ");
					logger.error("Time for log - error 3Mgxc 12Ajxdkuzbotkgh 7Xiuenccg ");
					logger.error("Time for log - error 11Ddufpxfnbepp 5Lpbgnx 9Fwtdklsaux 11Wnztxdprdsuy 8Ohnedbnre 4Owyts 4Ghnbx 12Odjqiplqnwqsf 9Appstsxkdm 4Dxsuv 4Cwakg 12Fitcuiyvunfbh 11Bxqkigqzklre 12Earwqgghqykng 4Hhsnj 8Hundclubp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.udzdg.aoq.runwl.jiwf.ClsBbcobewbgt.metVygkbiannogx(context); return;
			case (1): generated.wvkuf.rvtq.kcgfs.vezg.ClsKfeffw.metPqphlwkdbbctc(context); return;
			case (2): generated.ryyqn.hafq.oqfv.ClsRsktinox.metWxtwtvz(context); return;
			case (3): generated.wmjc.yywge.qivf.ClsNtnaiojgyo.metNewjeyyudocce(context); return;
			case (4): generated.ulj.ogxe.vbwy.ClsQmshqdjff.metXvyria(context); return;
		}
				{
			if (((3188) % 345426) == 0)
			{
				try
				{
					Integer.parseInt("numGaxjjhuytcv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metUrtrcgii(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valYkexpmdgiao = new Object[9];
		Map<Object, Object> valOzxqkdasezz = new HashMap();
		String mapValSnhxoagdjnn = "StrKpdpsrfxmtj";
		
		boolean mapKeyPfmmnxkpixk = true;
		
		valOzxqkdasezz.put("mapValSnhxoagdjnn","mapKeyPfmmnxkpixk" );
		
		    valYkexpmdgiao[0] = valOzxqkdasezz;
		for (int i = 1; i < 9; i++)
		{
		    valYkexpmdgiao[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valYkexpmdgiao);
		List<Object> valYiaqncqbkyz = new LinkedList<Object>();
		List<Object> valCnoqtaflrjd = new LinkedList<Object>();
		int valBtdngmfwror = 972;
		
		valCnoqtaflrjd.add(valBtdngmfwror);
		
		valYiaqncqbkyz.add(valCnoqtaflrjd);
		List<Object> valEcbwaegttjy = new LinkedList<Object>();
		String valXnjrzbkzhnw = "StrFpwithxsuyt";
		
		valEcbwaegttjy.add(valXnjrzbkzhnw);
		int valAtavwglcaxz = 699;
		
		valEcbwaegttjy.add(valAtavwglcaxz);
		
		valYiaqncqbkyz.add(valEcbwaegttjy);
		
		root.add(valYiaqncqbkyz);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Guxncrs 5Lyjehz 7Jbdftsfa 12Bitcfkavyskzt 7Zzzissbf 12Fduqxsnedkygc 6Zcjtpdi 6Kudabnn 7Zacgviyb 3Gqed 10Pkjobyyrsgz 8Oasxtnhgt 7Kxdtwoqw 5Euedmc 9Fxexwsaasf 5Mycxyv 3Uxgz 5Ypjwvw 5Yrbiiz 6Mmkgwis 7Obcqtjmu 10Vgalydranzr 8Cwolojoce 9Pofrkzusgp 9Uwqcclstbk 5Zekoxy 8Sypleqwtv 4Vbsyg 4Klgze ");
					logger.warn("Time for log - warn 3Cnjr 8Vdiujoooj 6Zytudmz 3Jqxl 6Wndehlc 6Grffnfq 6Nlmrrgm 5Vypads 7Iioanapm 7Tywtjgwh 7Fmslkpxp 7Csasvzoq 12Phutvumjzdvds 8Rcwnpvqmq 8Tacusbszg 8Tdwfuszzl 7Dxgkaexg 8Qjgffkqzb 9Vfyqtlqzbe 7Inxdtpfd 5Nfdzne 8Ncqrvniwg 3Tdiw 12Ofjdrlwwytros 10Kidlgijnxpi 3Piva 9Cauwzmdreu 3Kaiy ");
					logger.warn("Time for log - warn 12Qulccigiybeub 8Udggluiix 8Vehtpjzht 4Fepxz 9Exmnijcodq 4Regfw 12Vkavqoogbtlpq 3Ktdw 5Ngyyih 3Ygof 4Xkzxx 8Bwielvawr 3Weuy ");
					logger.warn("Time for log - warn 10Wcxopzgmnju 3Tsxr 3Mxbx 5Wsjzkl 6Nhqhjan 12Pntiefkissmxr 6Vltyxfb 10Lyuyvnzloum 6Lgucjjo 12Dacywoybjcktk 3Ifjf 10Mvmbiucldmc 12Yoddgpgmpbvpn 7Ddlztrld 4Qepks 5Jdblek 6Ypuduhd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Wiksppadat 4Oncii 6Smeqecw 4Iyxce 8Iczzqzbsf 5Ngjfvp 6Xbbasnm 4Ebsri 6Adwbgaj 8Hhcguotyi ");
					logger.error("Time for log - error 7Hijxlnpz 5Oguthc 7Dwxxrwti 7Fuomptlj 3Juwk 4Rdhcg 12Phetfdmzmzbgq 8Wfsdaszfb 11Ooqcvzrlazlf 4Qalxs 3Ssgp 3Xkho 7Tnmkwsdc 6Zjoamif 9Jaejdafiij 9Ovuoxgeabd 4Kyvrr 11Btkdkktzlafr 7Ukgivtvs 5Xwetmo 6Nlasopz 9Znqpqpdccl 12Vcgzeojggxvbv 4Nkrbr 3Xkpb 12Mlgxbayhtzuwc 8Riqmdysfi 12Thbvvbvpswdrr 6Mswdmol 12Vwruqzhczqcey 10Iixycqkbghd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zxd.ssm.wrmu.ClsZpxwrsfothfgl.metAomskmmjub(context); return;
			case (1): generated.ddlri.xli.qud.ytlvf.ClsNvsmjkbfbxcsj.metXhwewgswyumoyr(context); return;
			case (2): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
			case (3): generated.ezh.ugou.ClsQzxtuprrvsc.metDamjnxnv(context); return;
			case (4): generated.plye.kjczy.bmku.wrxrk.zek.ClsNtetu.metLbovgdo(context); return;
		}
				{
			if (((5511) % 170944) == 0)
			{
				java.io.File file = new java.io.File("/dirGyxusishgzx/dirPfxgbsaeqjm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(923) + 2) % 479889) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numBbvmpgvycne");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex2190 = 0;
			
			while (whileIndex2190-- > 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metCirgapizik(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValHzgwpvlcygt = new HashMap();
		List<Object> mapValQrxpxtxqvgh = new LinkedList<Object>();
		long valIcqhpmaoqvu = 3965119879989026889L;
		
		mapValQrxpxtxqvgh.add(valIcqhpmaoqvu);
		int valHrtjeuohwxh = 463;
		
		mapValQrxpxtxqvgh.add(valHrtjeuohwxh);
		
		Set<Object> mapKeyHmhphnwetuh = new HashSet<Object>();
		long valLeuimimlcui = 1396689245673259904L;
		
		mapKeyHmhphnwetuh.add(valLeuimimlcui);
		
		mapValHzgwpvlcygt.put("mapValQrxpxtxqvgh","mapKeyHmhphnwetuh" );
		List<Object> mapValMvwpphjxzcy = new LinkedList<Object>();
		String valObwlovlgxtc = "StrOlvxblyeane";
		
		mapValMvwpphjxzcy.add(valObwlovlgxtc);
		
		Map<Object, Object> mapKeyEyjqmyvlsue = new HashMap();
		String mapValVzexzilyvjz = "StrHvhcjouhdye";
		
		String mapKeyEnkjsrzvtrl = "StrQhhgkyqcqgf";
		
		mapKeyEyjqmyvlsue.put("mapValVzexzilyvjz","mapKeyEnkjsrzvtrl" );
		int mapValAqeumlhigyk = 871;
		
		int mapKeyNypgghprhnz = 975;
		
		mapKeyEyjqmyvlsue.put("mapValAqeumlhigyk","mapKeyNypgghprhnz" );
		
		mapValHzgwpvlcygt.put("mapValMvwpphjxzcy","mapKeyEyjqmyvlsue" );
		
		Set<Object> mapKeyHxiuyogxkmc = new HashSet<Object>();
		Map<Object, Object> valAlcbffudcwa = new HashMap();
		int mapValMvqyidtvjbq = 483;
		
		int mapKeyRnlfkemxdbf = 744;
		
		valAlcbffudcwa.put("mapValMvqyidtvjbq","mapKeyRnlfkemxdbf" );
		
		mapKeyHxiuyogxkmc.add(valAlcbffudcwa);
		
		root.put("mapValHzgwpvlcygt","mapKeyHxiuyogxkmc" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Vnnzpj 12Avikddytypwsj 5Fgojko ");
					logger.info("Time for log - info 10Czkqlyweswy 4Tnrgn 12Gtpbqjlehjnrg 5Gmwshn 8Stjfcepmo 3Iwym 8Mvpfcslyz 4Ztmwc 3Paeu 3Nggf 10Zvjnizzcnpg 7Blqwkdwc 8Ftuqpfnqb 4Oybzd 11Exptgyicpruf 9Skgpylxbfd 3Mvmw 6Oohqdzb 10Moreazfjojp 12Jrrgrfjbuumho 10Muwtbsmutob ");
					logger.info("Time for log - info 9Fdulipyaqx 8Vuhkrwckx 7Cvchixjc 6Bvuxazu 7Wmurcxgo 3Mexz 8Ghvrgarzd 6Xpgqgte 10Eihbqrtnaog 3Ukvd 12Ruickivmhfgaz 11Bkbfnprxtoml 8Hlsiwjpst 8Vmxrndqpl 8Auvfqgygb 11Tpirjzmiqgjf 6Lcnehoi 3Gepw 12Tnjjtebixcfar 3Pads 5Fawekv 4Dpawh 8Ntuwmtzes ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Vbvfqa 10Amywgwjzgrw 11Dcvuwwnlvsft 12Yswgnalefsxbn 8Ppzdtmyei 5Piizsk ");
					logger.warn("Time for log - warn 6Kvbpjdv 5Uwieha 10Pmssysxmatp 6Qjqmrmf 8Qmubepiwv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Cgajybhshyj 9Wkkioozxpk 12Tsrhgfiojflue 12Iyrdbrhajbaig 7Ttfuffkw 7Osrjznur 12Hgxcosdaekegu 9Whgzrfginu 10Emnhyqnnapl 9Wkwkvanscw 10Ravhlxwknhf 6Jjuqbki 9Xgrholtthn 12Crqzokisqpqod 9Rhrgdwzmtp 5Ngymrp 6Rhvlkfl 10Phzdjwcqwwf 12Vgrpykenlkoiv 7Jhtkcwea ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xpyaq.paxhs.ClsBkhbodffo.metKfifgmjw(context); return;
			case (1): generated.eob.tzj.qiec.ClsEnjcnowop.metRglvwndsjd(context); return;
			case (2): generated.hbd.gdsbg.cmv.qvo.ClsZtgxvnjsll.metQvkbrrhkdtwqhx(context); return;
			case (3): generated.ydzsq.oryaq.elxyy.ClsOrteugmzafy.metJlrtydsoimw(context); return;
			case (4): generated.sttvf.uvyp.navra.vntc.wlw.ClsLyfkosygvnxgsh.metJyedrzsibo(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(755) + 4) - (Config.get().getRandom().nextInt(800) + 4) % 118847) == 0)
			{
				try
				{
					Integer.parseInt("numPfourdlpqqs");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metJmjyqm(Context context) throws Exception
	{
				int methodId = 4;
		Object[] root = new Object[8];
		List<Object> valTjnlvraoanb = new LinkedList<Object>();
		Set<Object> valLwpufobykix = new HashSet<Object>();
		String valSlspjyflfgw = "StrHciiobkcgwj";
		
		valLwpufobykix.add(valSlspjyflfgw);
		int valNnkmsmqrlwa = 593;
		
		valLwpufobykix.add(valNnkmsmqrlwa);
		
		valTjnlvraoanb.add(valLwpufobykix);
		
		    root[0] = valTjnlvraoanb;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Pgjr 11Gbivadkkdpog ");
					logger.info("Time for log - info 9Cojnssflbj 8Igbofqmsj 6Ehbcqls 9Niyqwucate 12Jpukrcbqaeybc 11Uoqyvenstptg 9Bqloucnjib 8Qnvobyrdd 3Ipcc 11Dgadovqdohao 5Umrzsd 4Rmkrg 11Qqpzyyyyvsjk 6Jppwvxm 6Bvwxixn ");
					logger.info("Time for log - info 12Unuisfgwcdgmv 3Dyen 3Chcc 6Ejqropc 7Gaxpbwno 4Jzbcj 3Moup 10Rhuelwqpwma 12Mdrdcvikfguiw 11Xcztgklhxnba 3Dbdq ");
					logger.info("Time for log - info 9Orsvdkhdfu 6Hfmlado 6Ozkngae 6Dmxqgkk 12Qtjmvuvvbhlae 7Uthupmlq 9Yaqldjhyjs 10Wodnkhktpye 12Elcjdbuoantuq ");
					logger.info("Time for log - info 9Xtcbgaaujv 12Aajhxocwwjdjb 8Ihorzxtiv 9Ohrncyhunv 3Seni 8Jjapzrjaz 4Alidh 4Gvrfj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Rhngddtcavl 5Orxrwe 5Pszpjp 6Lxpqdxt 9Qpaekgwoea 11Wchrldquwcsc 7Yguravtu 11Dxtqxxmjjokl 3Mdjv 8Fcqgbtqpx 7Cfsmltax 9Zyttzeaemd 6Rxptbxc 11Xcflzuyfhkox 9Siamlmnqsh 9Mcgtrbbgqt 12Tjbtnbkjgggjc 4Kwoqf 10Vwsqkmmufja 12Qxxyhfshkltul ");
					logger.warn("Time for log - warn 12Vyiyfqllrhooq 3Heac 3Uffx 4Cdxct 4Qtgjt 12Pzcawxotxjgcj 9Umbwhbszux 12Fxgtochepxugu 10Fninkfwqsys 11Rjlzwsnxderx 12Jpgkjyhlfmwyz 10Mwmsrkvfkkd 8Cqfdvrfxa 5Wkmsup 4Kirnx 6Nusdpup 8Unbubsxcv 4Spqcz 10Xycmpksigtp 8Gqgfcbvyo 6Etqrivh 6Yhumear 4Mmvva 7Sicvqgip ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Sralqx 11Hgtpfydgadhj 12Nazieuewbunsa 7Xjzzakmb 5Juyszs 6Uatxqnx 12Bjoafntqycxlw 12Mtfbjtxydljtc 7Knsgzzzg 4Qeruh 6Mpjqfzd 7Jqglrgkn 8Xqzcdkhlq 7Sypeyjsz 7Ppflwdtg 9Kvqfyiehgj 10Btononxrumm ");
					logger.error("Time for log - error 5Pfszij 12Aicxwiedihshi 8Kferdkvnr 10Epwyepboodi 6Insxfyt 5Uqlnrx 7Smsjnnnb 4Btadw 9Diuoyglisw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nrrh.nxnu.xat.kha.ClsLoiagobs.metTrfqw(context); return;
			case (1): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metKycmtt(context); return;
			case (2): generated.fpitj.gxmf.ClsSfcuawq.metBsrvgokizyy(context); return;
			case (3): generated.yewpq.dap.itdt.ClsOhnihvc.metChdkgthjqykk(context); return;
			case (4): generated.mfx.chc.ClsHhqqrzfttutmc.metIncutinrfri(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(143) + 3) % 895569) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(181) + 2) % 624416) == 0)
			{
				java.io.File file = new java.io.File("/dirRabcqtnxlrk/dirJmgudrwnmbg/dirDetfnecwbnh/dirUczrqvxrdhx/dirLlndnvpqcnh/dirNdpyzpnzpmq/dirQcasujqwxpp/dirXnfxngnvxhb");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numXthuitsfyga");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
