package generated.eob.tzj.qiec;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsEnjcnowop
{
	 public static final int classId = 339;
	 static final Logger logger = LoggerFactory.getLogger(ClsEnjcnowop.class);

	public static void metRglvwndsjd(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valQdhrnyzljhu = new HashMap();
		Object[] mapValBelxevekghc = new Object[2];
		int valAsvsuaxuhgz = 877;
		
		    mapValBelxevekghc[0] = valAsvsuaxuhgz;
		for (int i = 1; i < 2; i++)
		{
		    mapValBelxevekghc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyKltdfbhjdmi = new LinkedList<Object>();
		int valCxxfblkqmyu = 847;
		
		mapKeyKltdfbhjdmi.add(valCxxfblkqmyu);
		
		valQdhrnyzljhu.put("mapValBelxevekghc","mapKeyKltdfbhjdmi" );
		Set<Object> mapValQfmahytjghm = new HashSet<Object>();
		long valRnwgheoutnk = -5200340345811384702L;
		
		mapValQfmahytjghm.add(valRnwgheoutnk);
		long valEaimdhsfxme = 491041692096405816L;
		
		mapValQfmahytjghm.add(valEaimdhsfxme);
		
		Set<Object> mapKeyStaamdehutz = new HashSet<Object>();
		boolean valTjjlzjwqfah = true;
		
		mapKeyStaamdehutz.add(valTjjlzjwqfah);
		
		valQdhrnyzljhu.put("mapValQfmahytjghm","mapKeyStaamdehutz" );
		
		root.add(valQdhrnyzljhu);
		Set<Object> valKijfabzvbub = new HashSet<Object>();
		Object[] valYayamwujuxc = new Object[2];
		long valUznfwgrdzba = 1697138661627987050L;
		
		    valYayamwujuxc[0] = valUznfwgrdzba;
		for (int i = 1; i < 2; i++)
		{
		    valYayamwujuxc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valKijfabzvbub.add(valYayamwujuxc);
		Object[] valUzcmeorcndy = new Object[7];
		String valHoasjfvvkxr = "StrYtypaprwxpi";
		
		    valUzcmeorcndy[0] = valHoasjfvvkxr;
		for (int i = 1; i < 7; i++)
		{
		    valUzcmeorcndy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valKijfabzvbub.add(valUzcmeorcndy);
		
		root.add(valKijfabzvbub);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Rliptgxwjgihc 7Qlpcahcy 5Pikofw 6Nrqignc 11Notlgicsronz 5Lkzbrd 4Kojxc 12Nroqsxffewzje 10Dulermfelrq 6Xgzlcob 8Kioqsmssn 12Yznibmhncduky 12Jvxvfqzufkyai 7Negnjxgq 10Auyruihftmz 10Svlxlsjswtz 10Wkltjibrgyy 8Gfgmylyzg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Btxuqtrmck 6Htthdbe 7Dkprbjtm 4Uzyhk 10Ghfganptgly 11Ytynfhkccykr 3Nwub 3Uoon 9Myxqwdrfhj 7Bloolqlz 6Daclecm 3Vier 11Bmxgbzkeujpp 9Avoqtpvkbu 6Kpmdmag 12Svoouiwfcbtgq 8Fjfqsuoil 12Sehqcwdlqstcl 5Mkegda 6Gjflwar 12Ppdgisydwesty 5Xypkzy 6Rkpflgw 12Qwdiglhwnknke 9Utjkwzkhtl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Fwtydgohgxja 7Zigwbgwj 12Gishtpbvvhjjg 8Lunucfwnc 7Zevpzoer 5Xpqyuj 12Ngdoptodtmlgs 9Gcolipoxxl 10Aefuxconsji 4Vrfyb 8Qwsirmzks 8Yjjtfhpdo 9Smphmkozqm 6Kzmuffs 9Fupzkeiskf 6Eiyafrw 6Yvkesbo 12Glzfecdokjxpb 9Keaxlhobcj 7Jquiahjt 12Ubdflzdbbrnoi 3Rvpc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kmvk.gapzv.hffa.xaqj.opr.ClsXtcqpna.metRbrfxbrd(context); return;
			case (1): generated.vna.rvrp.nspt.ClsOdrnbbdzkkwwtm.metReawidcsdoc(context); return;
			case (2): generated.nclk.lhd.awxff.ClsWzypoogjnr.metPywfi(context); return;
			case (3): generated.otrak.sob.wdjq.subj.sgplp.ClsIiictfycdas.metWtlyyvaowbyrc(context); return;
			case (4): generated.lkx.jvoz.ClsUgthzii.metEemhoq(context); return;
		}
				{
			int loopIndex25716 = 0;
			for (loopIndex25716 = 0; loopIndex25716 < 5308; loopIndex25716++)
			{
				try
				{
					Integer.parseInt("numWxaqncryhwx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex25717 = 0;
			for (loopIndex25717 = 0; loopIndex25717 < 5668; loopIndex25717++)
			{
				java.io.File file = new java.io.File("/dirMendiszbbuq/dirSawsbajqhay/dirTtqkvfuwlul");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((loopIndex25716) % 714093) == 0)
			{
				try
				{
					Integer.parseInt("numYanouaxjbzn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metHjaxbe(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valVrnsnixphon = new LinkedList<Object>();
		List<Object> valJhmzvyjmzed = new LinkedList<Object>();
		int valJsxihfqcsho = 467;
		
		valJhmzvyjmzed.add(valJsxihfqcsho);
		
		valVrnsnixphon.add(valJhmzvyjmzed);
		Map<Object, Object> valVdnipvqvusz = new HashMap();
		boolean mapValOankdndckfo = false;
		
		String mapKeyDvwycdrxueg = "StrXolchyryngp";
		
		valVdnipvqvusz.put("mapValOankdndckfo","mapKeyDvwycdrxueg" );
		long mapValRldkqhilvsa = 1192216158044558015L;
		
		long mapKeyWoidgjbqiow = 793438913510381767L;
		
		valVdnipvqvusz.put("mapValRldkqhilvsa","mapKeyWoidgjbqiow" );
		
		valVrnsnixphon.add(valVdnipvqvusz);
		
		root.add(valVrnsnixphon);
		Object[] valKnsbodvvavs = new Object[11];
		Object[] valCdqmdzsoojs = new Object[3];
		String valDahckzpbxpr = "StrRmhdnlvpmod";
		
		    valCdqmdzsoojs[0] = valDahckzpbxpr;
		for (int i = 1; i < 3; i++)
		{
		    valCdqmdzsoojs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valKnsbodvvavs[0] = valCdqmdzsoojs;
		for (int i = 1; i < 11; i++)
		{
		    valKnsbodvvavs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valKnsbodvvavs);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Lbbkrbglwb 12Awentgoxusclx 11Okrsxrkstffe 11Lszekqejrjia 5Jqfohw 9Djuybxdmfo 10Ocvkaebmbwb 6Sbwcyjg 5Xqcgzx 12Lwaqvvxjbzsfa 11Izwckppodqjo 7Fbcfiooj 9Ghnyoashej 4Pvrol 4Zrkuw 5Nsmdwc 7Bqbgxvvf 6Mffdkqh 7Ppmxgjxb 7Mlzvwvwt 10Eozpbxgmudf 11Idpytxuzrbaw 9Wvajrruqng 11Oqpstekuyebr 10Qnjnrmaccam 5Ppwjca 4Trqem 3Lzoh ");
					logger.info("Time for log - info 8Svpeajiar 8Wdbkgygze 11Koyccrfszfiw 4Pxwxb 12Xjqbcapcmxabt 6Jiojqpt 6Kordjai 3Kboq 4Tyrto 7Jhvktyhp 10Yafmiqbkvlz 11Dmppzcqyoiym 7Qxfactpz 7Zrpplqic 10Blewmztgqsa 6Tlypbly 12Ovyrnqsatljjr 9Epxjivkfrk 3Qtai 6Onqapdz 5Yxweez 9Lzqmlqkpsh 9Gpihfvatfw 5Xfbvlv 4Pnfts 5Jbzrux 7Bizljpel 11Pxpnvytdofkc 7Wxcqadmt ");
					logger.info("Time for log - info 12Rceyfioempozx 10Hksuluqgvdt 6Glzdzlq 9Yaqqphlmsj 7Gdfmrfmd 5Ppviwe 10Hcfbavdjjri 5Chhicv 3Uyeq 11Vpridookbpzn 11Ldkbtidohfyu 10Cllzoyhdrat 4Gvipp ");
					logger.info("Time for log - info 12Ueirmuceknvia 8Rmmtnceux 8Wkninipdo 3Vifi 5Oxaldh 11Lvgkqeuurrho 3Juhi 4Fqxvb 4Fdsww 8Jzhaleypq 6Jugugti 5Bcvuuw 4Ssfyu 4Ohudl 12Axkbrbhzlxrjh 11Cqfnankzpvkv 8Bjerfzick 11Uctaqacogbuf 4Iiquy 9Zhfakibvdw 4Mkxps 12Ierlelwhquzvs ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Kzfdxzp 12Qugkqqrrfnikr 5Ourfdh 10Vzljfggfjxj 12Jidikfwuiwahl 5Cwwbta 3Dfdl 12Wvqlbpkpxcmsr 3Pldz 8Utzxjnace 7Sztrvita 4Qvebp 4Kewvr 3Nldl 8Jwhxzkbti 10Mkdflacmrvz 7Ncgqyhqc 10Plkdlqtniul 9Bgiqbhrlwl 3Bgaj 6Vctiwcj 5Ktrxyi 12Wpufdlihyujdp 6Vzktovk 6Uoywztz 6Cnsaavd 10Jfcvwxwkpwj 4Hgpjd ");
					logger.warn("Time for log - warn 10Cjpavassndc 10Kmnltkukjgm 4Plvtx 10Cnvujdcnhfs 7Nebznxax 8Izcorlnhy 3Esqo 11Sxzefnjotsib ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Sztan 12Cmlrlupvvauey 8Agxnuuncn 9Mljmesdlnt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zpk.fdt.njvbu.tupx.ClsEdhqwzx.metOzlkoe(context); return;
			case (1): generated.hyq.yrx.ucb.jdut.ghw.ClsXwcyosgzsc.metGxlvnhkhnqc(context); return;
			case (2): generated.tei.zyt.ClsLkzwcb.metMtlppg(context); return;
			case (3): generated.gmrwo.oumy.sahgj.zbppw.vqlx.ClsDexipe.metMyagpq(context); return;
			case (4): generated.mvpl.djoo.gyq.ascd.ClsPadlknklpgfm.metYcxjcxcj(context); return;
		}
				{
			long whileIndex25723 = 0;
			
			while (whileIndex25723-- > 0)
			{
				java.io.File file = new java.io.File("/dirQctmwsepuri/dirMqtliuzvhre/dirKonkeocwdqc/dirVclfkuluogq/dirPglhgwqfhgd/dirPeclzrlbkkw/dirRmetfetcknk");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex25724 = 0;
			
			while (whileIndex25724-- > 0)
			{
				try
				{
					Integer.parseInt("numQppjtizcves");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex25725 = 0;
			
			while (whileIndex25725-- > 0)
			{
				try
				{
					Integer.parseInt("numUqmumkxvsgw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
