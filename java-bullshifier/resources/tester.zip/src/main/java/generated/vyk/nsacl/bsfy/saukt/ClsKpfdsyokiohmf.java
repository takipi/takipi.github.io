package generated.vyk.nsacl.bsfy.saukt;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsKpfdsyokiohmf
{
	 public static final int classId = 105;
	 static final Logger logger = LoggerFactory.getLogger(ClsKpfdsyokiohmf.class);

	public static void metUuxyceyipy(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[11];
		Object[] valSjdzqbhvqpw = new Object[8];
		List<Object> valBqreoacoeyn = new LinkedList<Object>();
		int valHmrhxvemmmy = 593;
		
		valBqreoacoeyn.add(valHmrhxvemmmy);
		boolean valLhzigampqno = false;
		
		valBqreoacoeyn.add(valLhzigampqno);
		
		    valSjdzqbhvqpw[0] = valBqreoacoeyn;
		for (int i = 1; i < 8; i++)
		{
		    valSjdzqbhvqpw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valSjdzqbhvqpw;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Swrtei 12Shrtuprwsngjv 6Tgkjosd 8Gusmorvdh 11Zcufevmuykii 11Ylylhbbimzxa 4Isuds 6Dmxyxbs 9Uzwzqeyocr 7Gwhwuxeb 9Wnqldodrpz 3Iubr 9Jhqgonfohw 9Wepjgdbqux 9Kehlxuvhnf 12Petuegsdxfumn 7Vrxaayze 7Yqovtief 11Cveixvijatdp 7Izrjelrg 11Cudlgmfeglcm ");
					logger.info("Time for log - info 7Fdxkshgj 12Udrnginsqpqbv 6Gvoczkj 7Durhrewy 5Trvkla 7Vochotbx 4Xqlta 9Dvxstqohhi 8Kaqjuwiuk 11Puhhphpdemmf 6Hzzpgbg 9Bzcasislkt 10Kbbxyddykxs 12Kjoqldbmzvzjy 7Knpoocny 12Eatixcizxwyad 5Ilhwbt 11Ucuenatwtqef 11Wjgynoacyfsi 3Hqoh 3Rufu 12Swkhmtjourbhp 9Zlkuthweoy 5Cxyfec 10Pjarkjaormv 6Zagqtsn 5Qkttba 11Opuhvdnlaxkk 11Eysytjcwtkkf 6Jacebhv 4Mjbwg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Dxwpnuro 5Ilhodj 7Xifjubwe 6Aepmwsg 6Frdurxu 12Tyrlqeapzdcrs 9Divkggbuwq 11Xhrlvnxspbis 3Mrae 11Hzvdmxchzhzj 3Hpjk 12Nwynxyloqgtal 7Iujmojyy 10Mrexykivcft 6Ezwfuev 3Bamm 6Ugklfhg 11Sblnxhukhfbw 9Hkfxypaowo 6Aqkzzss 6Ytgwjij 4Dqciz 11Ullyouxmhahk 7Abbbiyoy 3Qtjf ");
					logger.warn("Time for log - warn 11Vtjikwsbokmp 6Byczyrr 8Wukosdkyh 11Wzdivumknxdb 11Mgkuppovttzk 12Gkmlbetdinpvo 12Tjxrylrctzlqd 9Dhdvteiozs 12Uyseiwupmlkgo 6Xufxgpo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fnpk.eklwq.jyphj.bbvwd.ClsWcvzyhijzwo.metCihby(context); return;
			case (1): generated.hrks.gbo.qgg.fgvtm.ClsHtrpxdwwowcxea.metPehjfqnxxnd(context); return;
			case (2): generated.laaxy.myh.ClsSglobn.metWaahty(context); return;
			case (3): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
			case (4): generated.krka.pbdp.kxfhk.gqt.tfv.ClsAdvwmtrn.metDvriulzpcrhbb(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex21905)
			{
			}
			
		}
	}


	public static void metYmoozuxldwzan(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[11];
		Map<Object, Object> valUohnopseloa = new HashMap();
		List<Object> mapValMputmlikrdj = new LinkedList<Object>();
		String valAqqjdnbrhrh = "StrNnyseeivgse";
		
		mapValMputmlikrdj.add(valAqqjdnbrhrh);
		long valCduzzozfxkx = 8028148336784710864L;
		
		mapValMputmlikrdj.add(valCduzzozfxkx);
		
		Map<Object, Object> mapKeyOjjnvimaoww = new HashMap();
		String mapValYtwxfekfvwu = "StrBbcppdpmboh";
		
		long mapKeyStijqjpuvpl = 1569405766880486957L;
		
		mapKeyOjjnvimaoww.put("mapValYtwxfekfvwu","mapKeyStijqjpuvpl" );
		
		valUohnopseloa.put("mapValMputmlikrdj","mapKeyOjjnvimaoww" );
		
		    root[0] = valUohnopseloa;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Dmglade 3Hrfs 3Enza 8Qlguqzyxm 10Ihgpqilthnl 8Switkdrhl 11Deljrxebzhkc 10Hpjltoaaglw 8Lfjopbkul 7Kdqauedi 10Zofkwbuamln 7Lsabrmcl 9Wpsibreerh 12Ligtwzgamtblo 4Pnjzh 6Jdrejuw 9Dhccpyqcqr 4Rszfs 3Flsh 8Kfjgusniv 12Kfgekalqdcodp 7Uyiwkvrz 5Fhpwsm 12Ixpxvvdvvetjf 9Svylyknkyq 6Jyxnjcx 10Qmhuwsjtalo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Ucki 10Ebwmyfdriep 4Rxnwu 7Zvscmxbd 3Ebvb 3Pipu 10Hdpnobatuhw 5Wylsxq 3Ncvp 7Nllrguty 8Ybmerxcsb 10Oqzzpecdtto 11Smrrtuppxaww 5Ymuiqv 7Wjhzkfvd 5Fqbmso 12Mzufchtvayxht 5Guwgfx 12Qxcwzceammsvf 11Wqrutxoxnacw 10Avmyaumfpoi 9Comzembwqd 4Vxizu 11Emkotjegawnh 11Zlbysyrqmguw ");
					logger.warn("Time for log - warn 11Mgrruywflzft 6Puclylz 12Dunncgazukxzr 3Dlrt 8Ypbfpzqka 11Oojpyzumtrta 12Pvqhardynbken 8Cqslfapot 8Ocqrmexne 5Qyxxoa 7Eydogwos 11Rhhllwcnyzxq 12Lcpvqztoqmxai 5Ojfrtx 7Cmjfjqlw 7Aerdbiru 12Nfwrufdljecli 12Wfzhkbcazcpsd 3Fadk 4Wixhi 7Hitxlzuv 12Jnuzpdfcgbopn 10Yiaeimlxdao ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Pqqpaxl 11Ynbmdphiozbo 12Ielvrfxiegygy 7Dzzeobjs 6Hfhtodp 12Iyctglcyicwku 4Ezfdl 5Kbenli 8Ifyqlcytn 12Xcfwddavzkxuk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vrd.lunc.tgbks.iqcsu.cjgc.ClsExboagkfroi.metYhrfp(context); return;
			case (1): generated.xajsm.xnlym.ClsUmfzchfskds.metYensggsobl(context); return;
			case (2): generated.bcbrr.mrpx.ClsJcswauwrr.metIydcpeyrd(context); return;
			case (3): generated.zyq.cql.abcyr.bxocy.ClsPzdxphao.metTogar(context); return;
			case (4): generated.vjo.evnlb.amjq.ngqoa.vwvp.ClsMhozytfqjununa.metFuruxahf(context); return;
		}
				{
			int loopIndex21907 = 0;
			for (loopIndex21907 = 0; loopIndex21907 < 9786; loopIndex21907++)
			{
				java.io.File file = new java.io.File("/dirUibzbumzxeb/dirPjthxxtrnqi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varDfklwvtpvoi = (2073) - (Config.get().getRandom().nextInt(919) + 8);
		}
	}


	public static void metQwjpvac(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valNetgcebglsv = new HashMap();
		List<Object> mapValWqsnribyhip = new LinkedList<Object>();
		boolean valGlgfjmtwptb = true;
		
		mapValWqsnribyhip.add(valGlgfjmtwptb);
		String valYpbiunvdzso = "StrAnslzruearw";
		
		mapValWqsnribyhip.add(valYpbiunvdzso);
		
		Set<Object> mapKeyFeuvpybtnxk = new HashSet<Object>();
		int valGsaxhuwdnlh = 268;
		
		mapKeyFeuvpybtnxk.add(valGsaxhuwdnlh);
		String valCkjxjlzmfpi = "StrEofcdikxeku";
		
		mapKeyFeuvpybtnxk.add(valCkjxjlzmfpi);
		
		valNetgcebglsv.put("mapValWqsnribyhip","mapKeyFeuvpybtnxk" );
		Object[] mapValAbbtwjidpmz = new Object[4];
		int valGlmcqcohmjx = 827;
		
		    mapValAbbtwjidpmz[0] = valGlmcqcohmjx;
		for (int i = 1; i < 4; i++)
		{
		    mapValAbbtwjidpmz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyXkbntijjvdq = new Object[11];
		boolean valOzwydjzvyaw = false;
		
		    mapKeyXkbntijjvdq[0] = valOzwydjzvyaw;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyXkbntijjvdq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valNetgcebglsv.put("mapValAbbtwjidpmz","mapKeyXkbntijjvdq" );
		
		root.add(valNetgcebglsv);
		List<Object> valHiyjgkhveyi = new LinkedList<Object>();
		Map<Object, Object> valAgwbyhfecsr = new HashMap();
		long mapValBhgowkwmody = 3061637654453578034L;
		
		int mapKeyQulertyqxwt = 621;
		
		valAgwbyhfecsr.put("mapValBhgowkwmody","mapKeyQulertyqxwt" );
		String mapValYsqucdtemje = "StrNmnnququvcr";
		
		boolean mapKeyFmojhmdvrrk = true;
		
		valAgwbyhfecsr.put("mapValYsqucdtemje","mapKeyFmojhmdvrrk" );
		
		valHiyjgkhveyi.add(valAgwbyhfecsr);
		List<Object> valVvhrfauzrel = new LinkedList<Object>();
		long valIgyemxqaoem = 3765568999629406699L;
		
		valVvhrfauzrel.add(valIgyemxqaoem);
		String valGgzkedmuioi = "StrDkbevsoodch";
		
		valVvhrfauzrel.add(valGgzkedmuioi);
		
		valHiyjgkhveyi.add(valVvhrfauzrel);
		
		root.add(valHiyjgkhveyi);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Zklnmorp 9Xuxubdilar 9Gfcpsdumln 5Mdwbur 3Cuqy 12Dqdhyfuyndubk 5Neceeh 7Piubegsa 9Woxsinlemb 3Bmfx 9Pnidvuanht 9Zppynewzyj 10Xbtduqsadvc 10Yjwtojzvhkr 7Cgmaxtjx 3Wuvq 11Jcmnbtvmvauc 6Pbpwunk 10Tkiranzyava 6Wdneght 12Gknktejrjwsdf ");
					logger.info("Time for log - info 3Oyyn 8Yakwgcpsh 3Elbi 5Fvmhuh 10Jsilzvaqzcq 5Fcllxi 8Ozbvhsuye 10Uhhkxrxfyhw 3Iesy 3Ynbt 3Oypn 7Kmwpaupt 5Qrbxdk 3Xetu 11Afrojokhrqgo 12Hxggrkalixgsp 9Vojwopyvkb 6Ubzswev 11Hpgzkauetgay 9Nkxctydojs 3Rjuz 5Mhoptn 10Biceniphxkv 6Vyfglme 7Yxedsqsq 6Cfbiliq 5Wfyqqd 5Hwktdm 11Kdrdiftlnrpg 3Bilp 5Muzhpu ");
					logger.info("Time for log - info 7Lynfhhzw 7Qfpmenac 6Rfpzpdr 5Kxmcnh 3Dhts 12Cunpopqqfvbep 4Fdzga 10Kpjeouilgmp 7Duohoeop 8Bvuifoxyt 10Gvavvclcgkk 4Nqmag 5Ygryxm 8Xfywvoxhd 8Oblvhnxdh 8Aalcaqnta 8Xqiiexggw 7Oiwbbery 6Udvclbb 10Xmvhnrpukrb 8Xidjxfugy 3Oqjc 10Hfemgpxnuru 10Mvlbcxghgcm 12Loanbrnyyplbu 9Balqggkdxq 12Teoibkhofklqx 7Sxuppnht 5Adkyze 5Rrsszu ");
					logger.info("Time for log - info 4Mbpkz 12Mmlmdiexccfuh 10Jaufwyjddec 7Zkmgwacq 9Trzdqyxseb 4Qcyla 12Nyadvcfrlquha 10Kfosoyikpzm 7Lbtgnqab 4Epkrq 9Jrirmtdbvh 5Jbmheq 12Czrllinlctszl 4Kijyk 8Xswwdjouh 6Dmzvovw 11Mlfwxbrycslk 5Zclvcy 4Mlder ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Btlsoawghj 3Behj 6Flgwnxr 9Vatkttexau 5Vxxnld 4Yhlza 3Xxfv 5Ykrywq 3Wbom 6Cbluojn 12Peyrdgyvtbmka 12Eofarazvdbmhc 5Ljihcw 5Fqlyhk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Dryshjvgotbx 4Uowzo 11Kwznbotmireb 12Layzlfrpmjnev 8Fjjecjqkl 10Cakbsprdbci 10Bxbcrgmlfbq 12Mjputhxkbpfij 11Rebyupjujtbd 11Idrsjeeeyvle 7Wztwnjex 3Tgtl 10Ukxprgntrud 5Mrqvke 7Iuzkzlsm 12Hvcqfcojuhwqg 7Dubfnpxp 8Pytmcvijf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ezh.ugou.ClsQzxtuprrvsc.metPwweyllheinay(context); return;
			case (1): generated.qdt.cqf.kkjo.xjulh.ClsLodna.metIqrkzgr(context); return;
			case (2): generated.yfo.dls.qwny.cqaxf.ClsDosmbrrv.metNtnwha(context); return;
			case (3): generated.hor.ymu.xve.ClsFtiqqajkdixb.metBmlepaig(context); return;
			case (4): generated.ebl.tdhe.hblqj.plazc.otajb.ClsEihhumwr.metTdhkrrekocmlh(context); return;
		}
				{
			int loopIndex21911 = 0;
			for (loopIndex21911 = 0; loopIndex21911 < 9450; loopIndex21911++)
			{
				java.io.File file = new java.io.File("/dirVlnqezvvilu/dirJhnqcgohlum/dirXwgmpukdphn/dirVmoalaifluj/dirKqasulivpkj/dirRebgaihmdvz/dirZqhttyuojqn/dirUheannivvku");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex21912 = 0;
			
			while (whileIndex21912-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metOfxfjxkcir(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValHpourueukqx = new HashMap();
		Object[] mapValCfsacailfmn = new Object[7];
		boolean valImqpwnyhbbb = true;
		
		    mapValCfsacailfmn[0] = valImqpwnyhbbb;
		for (int i = 1; i < 7; i++)
		{
		    mapValCfsacailfmn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyIpnmjjdyzel = new HashSet<Object>();
		boolean valQpjsypkziwo = false;
		
		mapKeyIpnmjjdyzel.add(valQpjsypkziwo);
		
		mapValHpourueukqx.put("mapValCfsacailfmn","mapKeyIpnmjjdyzel" );
		
		Object[] mapKeyTwxuxqqqftn = new Object[6];
		Set<Object> valZupuibuzwkf = new HashSet<Object>();
		int valLqmazsxhquz = 934;
		
		valZupuibuzwkf.add(valLqmazsxhquz);
		
		    mapKeyTwxuxqqqftn[0] = valZupuibuzwkf;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyTwxuxqqqftn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValHpourueukqx","mapKeyTwxuxqqqftn" );
		Object[] mapValNtqgdbxzqsu = new Object[2];
		Object[] valRzsnvgxqjqh = new Object[11];
		boolean valQxfndngjiyq = true;
		
		    valRzsnvgxqjqh[0] = valQxfndngjiyq;
		for (int i = 1; i < 11; i++)
		{
		    valRzsnvgxqjqh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValNtqgdbxzqsu[0] = valRzsnvgxqjqh;
		for (int i = 1; i < 2; i++)
		{
		    mapValNtqgdbxzqsu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyKuxwpcexoan = new LinkedList<Object>();
		List<Object> valXgkweredndf = new LinkedList<Object>();
		boolean valUmgwepbaizl = false;
		
		valXgkweredndf.add(valUmgwepbaizl);
		
		mapKeyKuxwpcexoan.add(valXgkweredndf);
		List<Object> valQuyqdmzzqvu = new LinkedList<Object>();
		int valThhehvocnml = 218;
		
		valQuyqdmzzqvu.add(valThhehvocnml);
		
		mapKeyKuxwpcexoan.add(valQuyqdmzzqvu);
		
		root.put("mapValNtqgdbxzqsu","mapKeyKuxwpcexoan" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Oimgorznvy 7Vzqktvhy 7Yljxirfn 12Qhqliimbiiiyi 12Ciuazobkzkfcw 11Okjxbzhfcogl 3Wjnc 8Obsjvspgb 11Zjrxveirlwtz 3Qdng 4Wumkd 12Oslngclrnpddz 12Brkdpzoaqblrl 8Orkzzwkjx 3Evat 4Cefzj 4Draua ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Pgfke 9Olazsmdfwc 10Myvetptnpzw 10Fdjevjvymda 10Mdvzcmbeeze ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Lqqxqckcchpw 10Zrbfcmuhsfv 5Xhepmi 10Tbquslmizkf 10Hlflyjxhokh 10Bfvdvyjfvaj 4Mjhil 11Bavpvwfwntgc 8Ijhimkxnn 9Acnddsoqhu 8Cqyfwpzbc 4Otdfh 7Dpikurer 3Flhx 3Dhxj 4Lxiyf 10Fldjngnazcw 12Urhvhusmkdybe 11Jcacehbtrzsv 7Eanjxonk 4Mtsid 10Rnhcsvibmwm 7Dnjsgoob 11Ygmydxgsweeq 10Qypeetrxywc 4Iuniv 5Tdzwvv 5Pntbdn ");
					logger.error("Time for log - error 5Nqoxjy 5Cacjqi 7Cdhsqkde 7Gcviojzg 10Hbpazmejmar ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ogy.ayf.aijxy.ClsNdoxmvj.metWhdwh(context); return;
			case (1): generated.xajsm.xnlym.ClsUmfzchfskds.metYensggsobl(context); return;
			case (2): generated.cfolx.abg.ClsZqloaugvusc.metIetjxtz(context); return;
			case (3): generated.rnt.ihen.ClsUnbfdq.metAtneflmvgcprd(context); return;
			case (4): generated.ocklj.sbz.ClsVzertfboftzd.metMglljtzxhvd(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirLoaetsaqnop/dirKgcnobvqqem/dirAszpjxszmwf/dirCygpesxxlhh/dirXrcfsaolsbd/dirQwkdrlibavp/dirGwuqlafrdsl/dirTkgvybuhgws/dirOpkleqwmobm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex21919)
			{
			}
			
		}
	}


	public static void metHsxtpfnfagp(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		Object[] valAbqwyzqynej = new Object[10];
		Object[] valAmyxbgvowos = new Object[11];
		int valMnimhcluqdf = 212;
		
		    valAmyxbgvowos[0] = valMnimhcluqdf;
		for (int i = 1; i < 11; i++)
		{
		    valAmyxbgvowos[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valAbqwyzqynej[0] = valAmyxbgvowos;
		for (int i = 1; i < 10; i++)
		{
		    valAbqwyzqynej[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valAbqwyzqynej);
		Map<Object, Object> valPbuwveotncb = new HashMap();
		List<Object> mapValStzgkotvdrv = new LinkedList<Object>();
		long valBncqcowezev = 296967789548523246L;
		
		mapValStzgkotvdrv.add(valBncqcowezev);
		boolean valRddwgvnhhmi = false;
		
		mapValStzgkotvdrv.add(valRddwgvnhhmi);
		
		Map<Object, Object> mapKeyTndpilswrtf = new HashMap();
		String mapValLtubqjdrhvo = "StrIdbapriesbs";
		
		String mapKeyNzoxzvlullu = "StrXodrnggkisz";
		
		mapKeyTndpilswrtf.put("mapValLtubqjdrhvo","mapKeyNzoxzvlullu" );
		String mapValXoaeeawwbpk = "StrZmnifleexvu";
		
		boolean mapKeyKxxqzntmqhy = false;
		
		mapKeyTndpilswrtf.put("mapValXoaeeawwbpk","mapKeyKxxqzntmqhy" );
		
		valPbuwveotncb.put("mapValStzgkotvdrv","mapKeyTndpilswrtf" );
		List<Object> mapValPwqdrbynxhu = new LinkedList<Object>();
		long valGkoomvwgrbf = -6977125022128596913L;
		
		mapValPwqdrbynxhu.add(valGkoomvwgrbf);
		
		Map<Object, Object> mapKeyPvuhugrqcpi = new HashMap();
		long mapValNzroelyjsuo = -574249000044166257L;
		
		int mapKeyVawhkaryvuh = 626;
		
		mapKeyPvuhugrqcpi.put("mapValNzroelyjsuo","mapKeyVawhkaryvuh" );
		
		valPbuwveotncb.put("mapValPwqdrbynxhu","mapKeyPvuhugrqcpi" );
		
		root.add(valPbuwveotncb);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Xejipr 12Xvzbafpntpsnz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Abvwtuaak 12Eqomckaozmlbm 6Qdvngfh 10Prbjwduvoaa 3Qthi 7Bimicuwk 10Gdzcwgpupcy 8Jjekcdfuz 11Yppqmdimitrt 4Mlits 7Mdazelhc 3Cnro 8Citqoqhov 4Syhwj 5Ucrqyh 8Ibrixyfsd 6Jabsqbl 9Felxnxrkge 3Lege 6Ggqbzsr 6Jwylwua ");
					logger.error("Time for log - error 9Mrlgoagmdv 6Euqxtdq 5Gwariy 12Jhisugheuusmn 11Gouvyaqcosto 8Qaspxbymd 10Xlowttyaqrk 4Tlyht 11Xuccuvwyykkg 6Yywvusp 11Yrlatnumuwbr 11Pmdyrpevbddu 9Mjomejytda ");
					logger.error("Time for log - error 12Ltstjexvfrssp 5Cnpxjn 4Glvso 6Uqmobgw 4Cghhf 4Dsquf 10Sicffghkegv 11Qtivuhlbqwfr 3Wvhb 8Zlouwbwcj 5Hbrdiu 5Gwsitx 10Qirgwiswchv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lkd.eckd.hdtbd.unse.scvn.ClsCjccpmy.metBnujb(context); return;
			case (1): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metZfqpeqqdiyyj(context); return;
			case (2): generated.spdv.axe.ClsZyjdutdtmcu.metPttnuruqdrm(context); return;
			case (3): generated.lkx.jvoz.ClsUgthzii.metEemhoq(context); return;
			case (4): generated.cxoq.hzjj.hhxu.ClsXfvidhbawjojdu.metGjokxistgrq(context); return;
		}
				{
			int loopIndex21921 = 0;
			for (loopIndex21921 = 0; loopIndex21921 < 7723; loopIndex21921++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
