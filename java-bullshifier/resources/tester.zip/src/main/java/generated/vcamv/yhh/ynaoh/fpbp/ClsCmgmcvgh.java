package generated.vcamv.yhh.ynaoh.fpbp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsCmgmcvgh
{
	 public static final int classId = 1;
	 static final Logger logger = LoggerFactory.getLogger(ClsCmgmcvgh.class);

	public static void metUzxdq(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValNxhlnzugwem = new LinkedList<Object>();
		Object[] valXvnvxpacjes = new Object[6];
		boolean valLzoidcenoej = false;
		
		    valXvnvxpacjes[0] = valLzoidcenoej;
		for (int i = 1; i < 6; i++)
		{
		    valXvnvxpacjes[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValNxhlnzugwem.add(valXvnvxpacjes);
		Set<Object> valPtlxabvqxdm = new HashSet<Object>();
		boolean valVsseebszjoe = true;
		
		valPtlxabvqxdm.add(valVsseebszjoe);
		
		mapValNxhlnzugwem.add(valPtlxabvqxdm);
		
		Map<Object, Object> mapKeyKisqcdrxiss = new HashMap();
		Object[] mapValGnxzsbipljb = new Object[11];
		int valCyhounqzqgn = 169;
		
		    mapValGnxzsbipljb[0] = valCyhounqzqgn;
		for (int i = 1; i < 11; i++)
		{
		    mapValGnxzsbipljb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyNrnzhlgvvwq = new HashSet<Object>();
		String valHqhkcxbswwv = "StrBvlzztqswgn";
		
		mapKeyNrnzhlgvvwq.add(valHqhkcxbswwv);
		
		mapKeyKisqcdrxiss.put("mapValGnxzsbipljb","mapKeyNrnzhlgvvwq" );
		
		root.put("mapValNxhlnzugwem","mapKeyKisqcdrxiss" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Flqdwzolfvpm 6Yrbvrlm 11Jppluoemunjr 5Iqkjyj ");
					logger.info("Time for log - info 9Wusxsrvtoq 9Bxpcucqvoc ");
					logger.info("Time for log - info 11Njpgqdqirmyh 11Nusybrgregay 3Vqjh 5Lpbvng 5Ylfady 3Ocjo 6Mexeyha 5Cdbmdm 4Giuxk 7Qjvybify 9Jovmstttlf 11Yafddnfzvjhs 7Orfnuooh 5Ukcexq 4Judfy 8Mbqsuslci 10Dpmvshqywep 6Yfvpddg 11Jhkfysguxocc 4Sskmg 10Zuweggiaecf 11Sbzwdpyilphs 6Wyhmqol 3Gleu 3Cain 7Kzvnltxy 8Tyleujltw 6Eebxodt 10Jgpdbszjgda 11Bpnlgxpbyaez 3Fqqv ");
					logger.info("Time for log - info 10Yxvnuvpbwvz 8Ystgtluja 10Xymivwavdcj 5Epgqat 4Kqstn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Zsbbr 11Hnueyqgugigq 5Bfvkzr ");
					logger.warn("Time for log - warn 7Oxsboryj 12Fcnfqakmnrwdd 11Tpjkuwwczctm 10Fyedvurqdho 7Lhckjqbj 5Edtieg 11Ormlecbeijsc 5Udtkmj 3Kvph 11Shcbtujldarv 9Hdmebkrini 7Lgrvbawy 8Jvopcigoo 11Kefmyrxugkrq 11Werhodfkntnl 3Vhkx 7Puaqaxab 5Gsabsr 9Lwjzgqycbn 6Kombyup 12Auyfdqjbghzsp 4Jvxcb 6Djuhpfz 10Ebadgfkdhph 12Cdxlyfnezenys 8Qqpowxwar 6Eraowfu 7Akxjgwqr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Vntotbkssdjox 3Xoee 11Ogxzqjatdnde 7Edtnxkgk 3Jeeg 7Rhrxbbbz 7Maxmntgr 10Mwizhlpfkct 9Daxzeqzoua 12Rvflarsxabamk 11Umnkrrescfjw 8Wjirtrqac 6Clvefvv 4Zohzp 3Ummy 11Hfngtrwffyxb 6Cizbagj 11Oxrbdtygstev 8Wpzpqgfdr 9Wimnlepgqk 12Uzmpveqamnvoh 6Lubdmpp 4Lxtnz 4Kzepd 8Pabnpioxq 3Oeyc 8Bxkcdpgjs 6Wnxiegd 6Gsjhblu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nlkyt.zasi.ClsQaxysyqic.metUadhackqygx(context); return;
			case (1): generated.yudi.kwckr.ClsDwmxwqmygi.metNppyrlnbpx(context); return;
			case (2): generated.wzzy.rguqw.bfm.ClsCumedne.metQxnbuwx(context); return;
			case (3): generated.tmohp.pbwu.gfhxq.zdkm.ijx.ClsDimqu.metSwhvdjgcvud(context); return;
			case (4): generated.wier.vwsz.frtoe.zpo.ClsRwhkekxcsmjus.metDnxwcgye(context); return;
		}
				{
			int loopIndex21 = 0;
			for (loopIndex21 = 0; loopIndex21 < 3737; loopIndex21++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metEomzpcisih(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValNwyuqwhaksc = new HashMap();
		Map<Object, Object> mapValKxwekiuvobn = new HashMap();
		String mapValGaosvscnubn = "StrHzclpgffjjq";
		
		String mapKeyGhsifxgvohg = "StrLxnvovcefcf";
		
		mapValKxwekiuvobn.put("mapValGaosvscnubn","mapKeyGhsifxgvohg" );
		
		Set<Object> mapKeyFdmwyzqlkiv = new HashSet<Object>();
		long valTmwevswsnce = 6676441621480253942L;
		
		mapKeyFdmwyzqlkiv.add(valTmwevswsnce);
		long valVtavcqmdxna = -2804979182119662161L;
		
		mapKeyFdmwyzqlkiv.add(valVtavcqmdxna);
		
		mapValNwyuqwhaksc.put("mapValKxwekiuvobn","mapKeyFdmwyzqlkiv" );
		
		Map<Object, Object> mapKeyKswwjghvava = new HashMap();
		Set<Object> mapValNbhxtcfifci = new HashSet<Object>();
		int valHwtojaplvgk = 946;
		
		mapValNbhxtcfifci.add(valHwtojaplvgk);
		
		Set<Object> mapKeyQsmfousrywm = new HashSet<Object>();
		int valBlweffgxoip = 737;
		
		mapKeyQsmfousrywm.add(valBlweffgxoip);
		long valTqjeiahosva = 4593046899088140673L;
		
		mapKeyQsmfousrywm.add(valTqjeiahosva);
		
		mapKeyKswwjghvava.put("mapValNbhxtcfifci","mapKeyQsmfousrywm" );
		List<Object> mapValDwtdklpxlip = new LinkedList<Object>();
		int valBbxzqlmotop = 316;
		
		mapValDwtdklpxlip.add(valBbxzqlmotop);
		
		Map<Object, Object> mapKeyBeoupfvmucn = new HashMap();
		boolean mapValSitqxrlikbv = true;
		
		int mapKeyRcjixklmyyq = 448;
		
		mapKeyBeoupfvmucn.put("mapValSitqxrlikbv","mapKeyRcjixklmyyq" );
		
		mapKeyKswwjghvava.put("mapValDwtdklpxlip","mapKeyBeoupfvmucn" );
		
		root.put("mapValNwyuqwhaksc","mapKeyKswwjghvava" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Gfuw 11Rpoucydmdlkb 9Zylkuiyqtz 11Nqmbzevfkxqs ");
					logger.info("Time for log - info 6Isyhlzp 3Ypua 8Errlulnhn 3Truh 10Twocvevmeit 5Abiqtl 10Vlquleimlkr 10Yqqmnczecsc 12Keejmhikeykph 3Exna 9Yforfobull 11Wjarusxzzbbo 7Sgynjnlk 12Xnrkiibhmbsap 12Wekjonlfoqmuy ");
					logger.info("Time for log - info 11Tzbynennmnhy 7Qbfcyphq 11Bbhfwgsqrnxe 6Wodipdk 5Ilhdsy 12Jskoqhuronnsh 5Nawkta 4Iehgz 11Pnmvtjaruhll 10Fiabbhjlfpm 9Fpvdfglpyn 11Qjuzrbtqbfhk 7Vcccwuhl 4Ylhoq 5Kglvzp 6Qsxrybp 7Zbxbdepz 3Wmhw 7Oufxwcus 4Ogofp 10Gvavncgrqab 3Gbnu 5Tfgcrv 11Ahjlbauagxfp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Rhasteanztroi 7Xbvlvaqs 10Ptvwtwxswbs 6Gdaknst 12Wadjlzmnaixub 8Dayuxpirn 11Tijymumxwgqa 6Gullmxs 8Bvqptfpmf 9Dcxphznxhn 4Emjrr 5Sfunzb 7Rgryptum 9Vxmcddrpgv 4Ejahj 4Ycixz 7Lyzypnni 10Hvojlatubwu 12Pazaxuuiyvkua 5Aikwvl 3Sggn 5Cvvzwy 4Vvmpx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wkonu.vce.nspm.ClsXupklxzgrjs.metIwgyl(context); return;
			case (1): generated.budq.anwwr.qie.tcx.ClsAvdrojvr.metLuptxqtdejpomf(context); return;
			case (2): generated.kklo.eog.twpb.eja.vmrt.ClsCtkkdlrnk.metMzowgzzffz(context); return;
			case (3): generated.rnt.ihen.ClsUnbfdq.metAtneflmvgcprd(context); return;
			case (4): generated.ymhs.ivq.mlr.cezkl.gzyiv.ClsKvdrph.metIszbhwn(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(132) + 1) % 526953) == 0)
			{
				try
				{
					Integer.parseInt("numSknggpbreux");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirYzhlyvladld/dirDdrkxwyxqaw");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varTrqllhdxxnz = (Config.get().getRandom().nextInt(140) + 6);
			varTrqllhdxxnz = (varTrqllhdxxnz) * (9739);
		}
	}

}
