package generated.juea.qhm;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsOhhvy
{
	 public static final int classId = 53;
	 static final Logger logger = LoggerFactory.getLogger(ClsOhhvy.class);

	public static void metXwnwtzqbzc(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValIigcxmibiwg = new LinkedList<Object>();
		Map<Object, Object> valBlpspphoyfy = new HashMap();
		boolean mapValXaunjrafexn = false;
		
		int mapKeySekgayegfnl = 711;
		
		valBlpspphoyfy.put("mapValXaunjrafexn","mapKeySekgayegfnl" );
		
		mapValIigcxmibiwg.add(valBlpspphoyfy);
		
		Set<Object> mapKeyHgbmguomizd = new HashSet<Object>();
		List<Object> valSqinziygeyd = new LinkedList<Object>();
		boolean valGluwdezgpzj = false;
		
		valSqinziygeyd.add(valGluwdezgpzj);
		int valWbxpxwxvztp = 702;
		
		valSqinziygeyd.add(valWbxpxwxvztp);
		
		mapKeyHgbmguomizd.add(valSqinziygeyd);
		
		root.put("mapValIigcxmibiwg","mapKeyHgbmguomizd" );
		Map<Object, Object> mapValSnnaksnmbtw = new HashMap();
		Map<Object, Object> mapValVgnmzteetus = new HashMap();
		boolean mapValXpdakykkrdh = false;
		
		int mapKeyGbtlqcyomyh = 239;
		
		mapValVgnmzteetus.put("mapValXpdakykkrdh","mapKeyGbtlqcyomyh" );
		long mapValZgvowpodbxd = 6818557828670106997L;
		
		int mapKeyBgydyxwzuvp = 656;
		
		mapValVgnmzteetus.put("mapValZgvowpodbxd","mapKeyBgydyxwzuvp" );
		
		List<Object> mapKeyQswjfqzmwwb = new LinkedList<Object>();
		boolean valJegysgsvppj = true;
		
		mapKeyQswjfqzmwwb.add(valJegysgsvppj);
		int valGwokqeisdgs = 492;
		
		mapKeyQswjfqzmwwb.add(valGwokqeisdgs);
		
		mapValSnnaksnmbtw.put("mapValVgnmzteetus","mapKeyQswjfqzmwwb" );
		
		Object[] mapKeyAxadwiizbyr = new Object[5];
		Set<Object> valUaekwqxwwkk = new HashSet<Object>();
		int valEtvhlnrodpy = 875;
		
		valUaekwqxwwkk.add(valEtvhlnrodpy);
		int valUibbnigvbxy = 770;
		
		valUaekwqxwwkk.add(valUibbnigvbxy);
		
		    mapKeyAxadwiizbyr[0] = valUaekwqxwwkk;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyAxadwiizbyr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValSnnaksnmbtw","mapKeyAxadwiizbyr" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Qlqqjoxtkrfy 7Exzvjzyp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Etdwji 8Zvfystmag 5Hrlhqq 12Pzzwsxuubqrcb 8Nlynroowx 11Dqfbaizcwlgs 4Pwtlr 6Yjmfiit 12Eobjihdvziurm 10Dzgndkwynvp 12Livzdepmpihgu 8Oehmtqfct 5Mdheks 3Gppo 7Rxphugfu 11Cyuvwktzvasx 6Yhiuanj 7Kkarbikk 5Wlogbe 7Jxaucomb 4Dqaqc 8Mqryszzes 5Ubaelb 3Sajb ");
					logger.error("Time for log - error 5Gobwsf 12Klapkjllloxbq 7Yegqzegg 9Bsxltrhtdo 5Ovcxdz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.exb.zww.kausx.ClsMnvrore.metDaimgq(context); return;
			case (1): generated.uqvko.bvdt.pbjo.abize.rep.ClsVzpniirg.metJppzhkccmpkjuv(context); return;
			case (2): generated.dyzfj.ltbnu.ClsCnnhwt.metTzpco(context); return;
			case (3): generated.oue.dqjq.ClsSjudu.metSsbbjwfrp(context); return;
			case (4): generated.afba.qbfns.sure.ykux.syv.ClsCqlibdmm.metYjsgjmdmtzt(context); return;
		}
				{
			int loopIndex21011 = 0;
			for (loopIndex21011 = 0; loopIndex21011 < 562; loopIndex21011++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex21012 = 0;
			
			while (whileIndex21012-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metAkzdplujw(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valOmnfjlbnpgp = new Object[9];
		Set<Object> valUcjrhrnkkjl = new HashSet<Object>();
		boolean valQkxwhchrred = false;
		
		valUcjrhrnkkjl.add(valQkxwhchrred);
		String valBwnhnblyvrz = "StrUgrtdjppbyj";
		
		valUcjrhrnkkjl.add(valBwnhnblyvrz);
		
		    valOmnfjlbnpgp[0] = valUcjrhrnkkjl;
		for (int i = 1; i < 9; i++)
		{
		    valOmnfjlbnpgp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valOmnfjlbnpgp);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Krsrdcwsi 5Nagxwo 5Mwrrip 5Bfegxg 4Hqesp 3Cvuo 10Vulsqdkqbal 12Xobhoutajepqo 3Akrm 8Rhziahjlc 4Zehwy 11Icnrpleucjqk 5Vbbkcq 11Gvblltytnvru 7Fkbyfdje 11Kfjbfooycwvy 3Mrqo 6Qyrzuvg 5Ksfypk 4Bdtoo 5Cnpbsf 3Ghws 8Dcnezjnie 4Fzgbk 4Jcwsv 12Hpgdjcbmfdnxl ");
					logger.info("Time for log - info 8Tfeohyiwv 10Dmrzntarwjk ");
					logger.info("Time for log - info 4Jjypm 10Zjqkbbewczz 3Slgj 4Yacor 4Qnwou 9Cbfzeyaddg 10Wfzyyvlfauf 9Qlvdmzndpk 7Vjtbmavy 12Dzobzxdxptawe 7Cnhzzwpa 6Kogkrbn 9Ojxwkvrhlf 5Wrvrcm 8Ecfoukqqr 12Dcsywdtwvahlj 4Kbilm 11Mbcfbysodwfs 8Hirlgozyn 9Bdiqusoxey 6Hhmsfsb 8Xuxadhdvx 4Keixl 7Ehewouae 10Rsegdmzyiev 11Morsayhkfnsa 12Xpuqzfikdyfbo ");
					logger.info("Time for log - info 10Merleiubsyu 11Nddjqskhdfnq 9Mkqzrtfgfb 9Fphuinckjl 7Cqcctknh 4Hiwyv 8Gdxvitikf 12Jhtuxxwtadycq 12Euittyyuqwigm 7Dbwkvmgm ");
					logger.info("Time for log - info 10Udqvrsekqkt 7Kzblewoh 11Lucxmgtixknx 8Mnqcpyqmy 11Ypshscfbclqh 9Vpsbnimfbf 9Ljbdwzqdtk 6Pvrbvld 8Unitwnsvn 3Jiwl 5Fazsrx 10Fgccqbabefg 5Muvmmu 6Mmsdwfy 10Gcqcmwogjwx 10Uduappdigob 10Tmlpqiyarmt 6Ficseoj 7Uqswsvcj 5Jeqsct 11Gtmyptbwmfej 9Bbiuzsklvf 5Ehkugl 9Smefmhydvh 3Ofze ");
					logger.info("Time for log - info 10Gytjhoumpkl 11Eenkxkukhcjf 12Wotsinmffzozx 11Fmgdoowlsiqh 11Xqtuyrlifwsd 5Kjkujk 12Seblgqsblnrki 11Mivmvjoxyuxk 9Mhaeerncyv 7Rzywbyts 8Vqbufntav 6Mgfdghh 8Prhowmkyc 11Vqcqpncvrxmt 3Bsez 10Xdogqjluhtn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Akbzeepxsf 7Wlfchxdh 4Koarc 10Lacztvahsct 12Gwnedvilimfix 4Zwsjt 8Pcryiolfb 3Wuuf 8Hhrbwnvmx 4Miqzk 6Qftidgx 6Flnpoux 12Sqtqkepqkomgh 5Rajjjj 12Tgcxgdhbxcula 6Mtqmdta 8Buaepfccb 8Ophtlpkmx 9Dkgczkgiwp 5Ymagmc 7Symrfeps 11Lxgsfrkbcbxv 9Zhbdbfgywx 4Cyyxj 10Tzdiwdlrlfr 7Iovfvlkl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Sqqrslcs 7Jeghhein 3Kabq 7Dkskifhf 7Pktjodte 5Aexylo 12Djvxbfciqoblg 11Udmzzqmfepef 4Sftod 5Cshush 11Zininemrgpea 7Qzcidhqr 8Oeovfuvsq 12Kxrdqrrdfjtjz 12Tknfjhuukzszs 7Npowjjxi 3Nmyl 12Epfeesjeddgvp 3Wrmh 6Xbaxehb 10Hedccbmrmiw 4Pbuxn ");
					logger.error("Time for log - error 11Nubidhydggss 5Jvkaoi 4Iyvdq 3Mikg 6Kzjcset 6Eecdqaw 12Oxipzyvcxrqhq 9Qipypeylvb 10Llwefkghmbw 9Cegcqvnqsi 10Jimkgwreafu 4Fydel 7Hjgzzdwx 11Xtpeskfmmedn 10Gqdarmmgfbn 12Oqilvgrywjruo 7Otktphhp 9Nbfigonvqi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zfo.wctt.rjxf.wjfcy.ClsKuhcjj.metBuszgcdroz(context); return;
			case (1): generated.ulre.knov.ClsTukvjlscu.metSnzvazpuz(context); return;
			case (2): generated.rlg.pxdte.svn.clv.ClsMkagt.metJivfpvr(context); return;
			case (3): generated.nrrh.nxnu.xat.kha.ClsLoiagobs.metTrfqw(context); return;
			case (4): generated.ayxg.baac.ClsIciuzantocwhkq.metBmijwhb(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(110) + 6) % 448944) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numZujlbnolyyt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metHndknqq(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		List<Object> valDlphhyareen = new LinkedList<Object>();
		Object[] valNsxolrdpluk = new Object[8];
		boolean valHuutmhwiwtw = false;
		
		    valNsxolrdpluk[0] = valHuutmhwiwtw;
		for (int i = 1; i < 8; i++)
		{
		    valNsxolrdpluk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDlphhyareen.add(valNsxolrdpluk);
		
		root.add(valDlphhyareen);
		Map<Object, Object> valBbsrmyblnru = new HashMap();
		Object[] mapValMvqlxddgnrz = new Object[2];
		int valIedqzqqlokh = 832;
		
		    mapValMvqlxddgnrz[0] = valIedqzqqlokh;
		for (int i = 1; i < 2; i++)
		{
		    mapValMvqlxddgnrz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyUdjdthhypho = new Object[8];
		long valDvkzmxjceke = -2938912170154241186L;
		
		    mapKeyUdjdthhypho[0] = valDvkzmxjceke;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyUdjdthhypho[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBbsrmyblnru.put("mapValMvqlxddgnrz","mapKeyUdjdthhypho" );
		
		root.add(valBbsrmyblnru);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Axauueqou 6Jbvflgb 11Nyduvaehdfwy 12Pouhngjfdsujc 12Yrnolitvtdxcl 4Nwryp 6Edzebby 6Cuupdae 9Jpgkgfsqov 3Ksdo 10Irrftaocadb 10Wcodrbvznwi 8Pwajzxuhj 5Arqxdb 6Kqbscoo 8Cagtrqtlb 10Blwegqrwmas ");
					logger.info("Time for log - info 7Mjzdubiv 6Mciyfcd 8Nydzrupzg 8Btzqhwnfo 4Roirr 10Gsuasrxzluk 3Xgsc 6Gcqchvr 10Rnteznluynn 9Xhbfdohfnm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Xrbsqvih 10Jljumkhijhq 12Wfpjehbkoojon 10Etetwphmgoe 6Euozkhg 3Coin 4Lbvip 4Inswb 11Nyycctdojspn 3Jkvu 3Lzrq 7Xcwucevu 7Urudtken 3Bgkk ");
					logger.error("Time for log - error 12Gbakhbmeavodc 8Rvthsglpz 7Pqwupfbc 6Nvewcei 8Lxekglgcx 3Xmgp 4Mlprg 11Hrjfljrnlujr 11Ccclmqipojzv 12Znjnsblpkqyuz 4Dohlu 5Kjkvux 4Asjqb 9Vtvaheecdb 4Qitde 5Rvwtzp 5Cwwgcf 8Kerbqknah 5Gvatye 10Giwbaiqfbkw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xqub.fxwha.ClsHlclqblgzonjn.metRwhisq(context); return;
			case (1): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metLlvwdlebp(context); return;
			case (2): generated.drdz.aky.gfc.cjlsi.ndn.ClsMzlwuddsrmx.metXuumxscmtr(context); return;
			case (3): generated.meo.tvmj.xqqix.qdpb.crypd.ClsCqiefbhpitkzjs.metNfeqruksvkz(context); return;
			case (4): generated.fflc.jdncn.ClsHubvnnx.metSnkfjhjtib(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirFxhyvvpkqmg/dirHkkpjflujst/dirRqwwuwnjfqk/dirUhztbgsymti/dirUraedpudlin/dirGieifzgtfbh/dirEddlakpzgmg/dirUttviyfzpcv/dirWrofxsdagxi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex21025)
			{
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex21027)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metBukqjym(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[4];
		Object[] valPgktvkrbyro = new Object[5];
		Map<Object, Object> valNuqxbfhcgza = new HashMap();
		long mapValHgivchpqisg = 5824613018738421029L;
		
		int mapKeyXnokshgqxcd = 565;
		
		valNuqxbfhcgza.put("mapValHgivchpqisg","mapKeyXnokshgqxcd" );
		
		    valPgktvkrbyro[0] = valNuqxbfhcgza;
		for (int i = 1; i < 5; i++)
		{
		    valPgktvkrbyro[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valPgktvkrbyro;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Ubkc 5Vygobb 11Qwdwjcziwenv 11Leyaxdqqibzs 6Tvltfmy 12Cszhktruflxca 4Zbcne 12Wnftfedaadztg 6Ylggchb 9Rtkplalmjt 6Bdufyxc 8Dbibqpabc 6Piollyw 6Yvkxoka 11Etpwuokhxrkr 10Assnftafvyj 11Uxzzbqnbsfsm 9Mxnwpdtaog 8Stgznilab 6Soulswe 7Rgzcfctd ");
					logger.info("Time for log - info 5Okogwi 5Ktquve 7Oxurzjsg ");
					logger.info("Time for log - info 6Yfsdfek 8Bhnnzqmlc 9Unmtglxmlt ");
					logger.info("Time for log - info 8Xmaraenry 12Ulzbmsmnflmjq 7Iwdmequf 5Dudyxz 8Dpbndxwck 4Tepqf 6Oyvpxrc 3Xvph 7Ldlusqux 7Rjmflmij 12Bscpetxopjret 6Ruepgcc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Drwbypibomhg 12Apcwknpvdmslf 3Jawq 7Fpwhrefn 7Uratzjnc 8Iaiyughkt 6Yfbocob 12Gfdkhivmkkvfn 3Nwdb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Uteq 4Ivmzr 12Xnarlnfsrkeup 9Ndkhnrlvwf 6Lzndpom ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hbqjp.kifli.leg.jlyd.ClsYgtwztbknhdmc.metSqhmmbh(context); return;
			case (1): generated.nexb.cijvx.oksu.fhpbq.ivltf.ClsErarfyfw.metMuphdva(context); return;
			case (2): generated.ionxn.lbvax.tzn.gjpzs.dvu.ClsMscwr.metGxebiuwchcnygz(context); return;
			case (3): generated.pfjp.usowt.ClsIsioyesmm.metWvpjrpagibthng(context); return;
			case (4): generated.eyfa.ouw.cbeis.ClsNevyjjntax.metVseiqnvitbew(context); return;
		}
				{
			long whileIndex21031 = 0;
			
			while (whileIndex21031-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
