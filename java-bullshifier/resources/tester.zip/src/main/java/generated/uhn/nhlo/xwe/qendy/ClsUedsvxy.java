package generated.uhn.nhlo.xwe.qendy;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsUedsvxy
{
	 public static final int classId = 232;
	 static final Logger logger = LoggerFactory.getLogger(ClsUedsvxy.class);

	public static void metTxsoh(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valRiudgfybjde = new HashMap();
		Object[] mapValOfckcgqpqrl = new Object[2];
		int valDabhpiglifx = 955;
		
		    mapValOfckcgqpqrl[0] = valDabhpiglifx;
		for (int i = 1; i < 2; i++)
		{
		    mapValOfckcgqpqrl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyGupbfojxkfs = new HashSet<Object>();
		long valNspgotrrbea = 5810449164555948798L;
		
		mapKeyGupbfojxkfs.add(valNspgotrrbea);
		
		valRiudgfybjde.put("mapValOfckcgqpqrl","mapKeyGupbfojxkfs" );
		
		root.add(valRiudgfybjde);
		Map<Object, Object> valYjzgfljdjjb = new HashMap();
		Set<Object> mapValZcpqyvriqnq = new HashSet<Object>();
		String valVdtaduwaduk = "StrVicrxsestty";
		
		mapValZcpqyvriqnq.add(valVdtaduwaduk);
		
		Object[] mapKeyWetcinzblue = new Object[5];
		String valMdlrihrffij = "StrTchqmkzcxny";
		
		    mapKeyWetcinzblue[0] = valMdlrihrffij;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyWetcinzblue[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYjzgfljdjjb.put("mapValZcpqyvriqnq","mapKeyWetcinzblue" );
		
		root.add(valYjzgfljdjjb);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Fnwk 6Jlmdfcs 3Vbvs 8Idpzoduvj 12Algaabhwzhwjo 7Mrwefcnd 7Pfpitdfm 10Orwlbkorgfh 3Vpcr 8Ipobfwyff 12Cgmyprpzbehgo 6Stdyvnf 5Dxdoub 10Opaujzctepq 7Tonoqsdy 7Tpcwzkqi 5Eypxnd 12Zjyrvtiwfwwkl ");
					logger.info("Time for log - info 5Ltyqos 4Hpiuf 11Usnjvjbpkwhh 3Olyj 4Qwrwq 7Yyptnqjw 11Tzccitsrbaqz 12Avsyhqjvmfqsm 4Xeecq 8Cpxlqyebf 4Rwscy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Wpumtbli 12Axiuxeriwqwye 6Hcmnvyj 4Tavtx 12Pabybuyuqaozx 11Piucgnxozyhw 12Bksnskvrpggfn 3Ozsm 9Kybfcxkztx 3Tzzf 11Vbvvbdjvnxxo 5Pknnww 10Zswhqvskijm ");
					logger.warn("Time for log - warn 7Ymbxvukv 10Lgskwycldgs 11Mielthkgwmdc 12Zzlrnjsxkbppw 8Ncsblqtnv 11Nxgxvjrgscjy ");
					logger.warn("Time for log - warn 5Tayvlx 6Gfqpike 3Omct 12Npioppxgpwoxb 11Nqvkcnmwlgpl 12Irzspsdqdehho 4Ixxvl 7Vpgslgqx 6Taqlkbb 5Rwwaly 5Gamasq 5Knegok 12Bfituhlqojboe 3Ppuz 4Iajeo 12Bpafsgnucnxov ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Ngbowqahcx 6Wduffru 11Ynqkbnxuhojk 9Dodjjhjcsr 6Tbkhpum 4Fzlfv ");
					logger.error("Time for log - error 5Grrxyo 12Tdyvldibqjuut 7Facpgltb 8Efajtwygc 9Svzqphsvql 4Vhzjl 7Gxpjiyjv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pli.sac.lcrkw.ery.xwlo.ClsIghyijbnkvoubq.metYyzhlpcd(context); return;
			case (1): generated.ghn.esb.odxb.wtax.ClsJgsbwdqv.metPazubjuncrdr(context); return;
			case (2): generated.vvl.eygsr.pmv.fzat.xuhvb.ClsRspudgdgeelrz.metSbvadqifcqj(context); return;
			case (3): generated.afz.qen.lrlj.ClsTvxlbccvg.metBrsibddpey(context); return;
			case (4): generated.obqk.bihpl.ehwd.ClsWcpejgvq.metUrpeeajbj(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirMgpanalaunk/dirCazmdiamvvl/dirSdhvyqonnkz/dirIzhzgkuoxtp/dirOwrwbjsutbt/dirPmpamswqtuq/dirIznboubnica/dirWofttzvrwts/dirVsjumoglkrf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex24142)
			{
			}
			
			long varXceuyekxtcv = (7644);
		}
	}


	public static void metDrmqzdoluerxn(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[10];
		Object[] valFozioikwtzg = new Object[4];
		Map<Object, Object> valBdclwnthove = new HashMap();
		int mapValIuvcppsaimb = 935;
		
		String mapKeyMkdmxaqmkjw = "StrWikgdimtljp";
		
		valBdclwnthove.put("mapValIuvcppsaimb","mapKeyMkdmxaqmkjw" );
		
		    valFozioikwtzg[0] = valBdclwnthove;
		for (int i = 1; i < 4; i++)
		{
		    valFozioikwtzg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valFozioikwtzg;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Ypxfxvhacu 10Knhrvzrdkuk 9Oqbepqhejw 6Nqicdbo ");
					logger.info("Time for log - info 10Uuhaykfjcpw 6Ewnolmg 3Mmxw 11Oruxektaitgc 8Mvftgmzdn 9Itnjyvdpgv 6Rctoziu 3Irnb 6Eqqlvfi 5Swwqrf 3Qptq 9Ytguhlodoq 3Sjlk 12Nzhujfdwuzeio 3Ucdb 4Xwvlt 10Ujhjayofsro ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Hkrqo 5Dsache 9Bqcosvmjoi 6Gidjwwe 4Zfrls 7Iwnjzgfr 6Cnhzzyc 11Qgkopkmurbqa 8Cowikrmky 6Loyllcy 7Ptghemog 11Zdrkbkqjevqw 11Pkorztergyxg 10Kfwgjztnixt 6Qfajjdb 10Kyqechukvcn 8Yzkvtjzcs 12Cdiuhslgbvawc 6Hitdpld 3Ljvk 4Ecrto 4Elvzz 4Ibavd 11Qlvpctevuouk 9Jjceaxmrvj 5Sydaqg 12Ffzbcekdtlmlt 7Rgpjccdq 9Svhgwqesok 7Gdesljtt 9Fvxqxqoasc ");
					logger.warn("Time for log - warn 3Duks 4Fnjkm 7Hiyrjpev 5Laybfo 10Ilgycdapvls 3Cnhw 11Pbyyxquqfvfb 4Rcatd 11Mjzqtsdpidgp 10Yfnxetnxecd 6Qonzbkh 5Meclys 11Zdvfslryaycj 7Rualnvrp 3Kerj 6Qweqvzr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Yzlwkpssx 11Bvtbocdqwecb 3Ymhh 11Ivbhbuiyhdyq 5Pebife 5Laxjyx 9Wnitcaaxtq 10Pocfsijitpu 11Zxsuaazzaxsn 11Fdaxgsnhrzyo 10Rdgjtaxacbg 8Oqwqhxlsx 7Onwqoqcg 12Xsilmrwprsrmv 4Qidgd 9Wsyhhbagmi 7Mfheduik 11Yjkgazauxkmx 11Krigflwmdbgg 6Xxpyypz 5Gobsjc 4Iqmtx 7Tqarrvsi ");
					logger.error("Time for log - error 8Wtevxoelo 12Iekkcfomcjidk 6Dtyrjtm 11Kjftfpknyddd 9Cclwcikilc 10Tieehfsjplm ");
					logger.error("Time for log - error 5Akqajh 9Mrngcrqpzc 5Pzqdyy 6Pzgdwxm 9Fuluwftxxl 11Vhwbuuzmigog 11Tjllbrarmiva 9Rxrmjgnptk 4Uhbgx 6Lsexmwg 5Hfolgp 10Jlbcttutdpw 10Kdmkgesjxjq 4Cwpwg 7Jdsekoqu 11Ttwycwjichuy 6Btejouy 8Xpzlhoine 12Kkdkzyxnololu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ncx.nab.ijte.fihzp.ClsYfnojfmzyj.metDgypcmpwyxb(context); return;
			case (1): generated.wvctc.whp.ftjy.ClsPwdcftvpjt.metAukww(context); return;
			case (2): generated.bywcf.xycgt.wqguo.ClsDsjomnr.metDdfotoep(context); return;
			case (3): generated.aqdnu.puvg.gdad.ClsIxzvdsuksw.metWaxopqbol(context); return;
			case (4): generated.ionxn.lbvax.tzn.gjpzs.dvu.ClsMscwr.metOajkgn(context); return;
		}
				{
			int loopIndex24144 = 0;
			for (loopIndex24144 = 0; loopIndex24144 < 6482; loopIndex24144++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex24145 = 0;
			for (loopIndex24145 = 0; loopIndex24145 < 3214; loopIndex24145++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metDgnkkfe(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Object[] valWsjcrcuooyt = new Object[10];
		Map<Object, Object> valQegfnjcyjlt = new HashMap();
		int mapValToawyafykws = 403;
		
		long mapKeyMkskkikztkm = -6302202562733143988L;
		
		valQegfnjcyjlt.put("mapValToawyafykws","mapKeyMkskkikztkm" );
		
		    valWsjcrcuooyt[0] = valQegfnjcyjlt;
		for (int i = 1; i < 10; i++)
		{
		    valWsjcrcuooyt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valWsjcrcuooyt);
		Set<Object> valBomdxtevmbg = new HashSet<Object>();
		List<Object> valXcdlhpgsnfo = new LinkedList<Object>();
		boolean valOufhyvbsnqp = false;
		
		valXcdlhpgsnfo.add(valOufhyvbsnqp);
		
		valBomdxtevmbg.add(valXcdlhpgsnfo);
		
		root.add(valBomdxtevmbg);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Wxfilustax 11Xopntqtsrlhj 12Ggvvhvgvrqpaj 4Pjtel 10Khrrjojvjli 11Ckfcjvyxxjxu 9Aqypcrvxdl 5Cwbkvl 11Hbuzddlguxfz 7Tfkuixzw 8Qaluiurow 4Ercvo 7Gptdwtje 12Zibcjomoufetk 9Maliprdvda 4Pqqte 6Abtxwht 5Kaycdy 9Twqwhqjkhu 10Mheffaezfdl 9Isflubnzrm 3Kgcm 8Rnkhxsrwy 5Bzayip 3Ajrk 5Unhrxi 10Qqykdetkuhw ");
					logger.info("Time for log - info 4Onobs 3Cdfz 6Hjzwlqm 4Xgvtv 10Tqkxevtnpuw 11Pxrqnpipkyon 12Kobyqvnscbdfj 10Eneczgvdngx 3Aedm 7Bspxvpqk 4Hwwqz 3Gvhi 10Xdzzzuxezfx 11Afjgckmuwujz 3Jxqv 5Bjerwl 4Ksqov 4Makqx 11Secvqfizumfg 12Qlbrcwboebxlu 3Tevw 6Gjlyrep 12Iogbpiashcyrr 11Zrpendrocdjh 5Dqbwtn 4Awjov 8Nomddzogh ");
					logger.info("Time for log - info 9Ossplmzrey 10Kuhakarfgoo 10Onivamccxyt 10Sgytafajlni 11Doybwyzyryqs 3Odcr 11Huisbgzwpgzy 9Ndkefnghyj 5Rpbfxc 7Tbzpyuoz 9Upxresqzqe 8Ghlsamovo 9Fyljxtiizm 9Mtvbsnmdga 4Wbuif 8Lotrxvwhu 8Ihuemcbnz 6Ppbtnov 10Ehvvefsiyrh 3Kgbs 6Wqhfgag 3Cmjn 3Bxpc 10Khoyheadnki 6Nmbpuyd 7Zoeqxxdm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Fdphij 12Dtchavkvywuqg 5Gocjnl 9Exynwsvpso 9Ojbqswqhoe 5Llfnkv 5Ilegtt 3Sytf 7Fyytgykj 11Oaxbejjlmxgz 11Ixgpohqbdslg ");
					logger.warn("Time for log - warn 8Ztqyqazfg 3Dcdl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rsu.hmuld.jzssz.bjyy.fod.ClsQixayqsiydaxm.metIpckuqrkv(context); return;
			case (1): generated.epi.quvm.dwt.ClsQoovjnirkdxzq.metKbxmlzjrkdplxk(context); return;
			case (2): generated.wspiu.cmqv.pvdxy.isdgi.ljwn.ClsZpnvzubxm.metXtcjjfosrwkks(context); return;
			case (3): generated.uhn.nhlo.xwe.qendy.ClsUedsvxy.metDgnkkfe(context); return;
			case (4): generated.lfb.pwad.aey.ClsGmnfes.metGiyldxwq(context); return;
		}
				{
			long varIpuofvctooq = (Config.get().getRandom().nextInt(432) + 7);
			int loopIndex24150 = 0;
			for (loopIndex24150 = 0; loopIndex24150 < 3036; loopIndex24150++)
			{
				try
				{
					Integer.parseInt("numTfufgyhgwhf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
