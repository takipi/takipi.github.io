package generated.evl.qnyx.qnt.hnkpr.mua;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsPqzytqp
{
	 public static final int classId = 66;
	 static final Logger logger = LoggerFactory.getLogger(ClsPqzytqp.class);

	public static void metUawoukuahbtfc(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValKikfealkgay = new LinkedList<Object>();
		Set<Object> valVoqhqwcpowd = new HashSet<Object>();
		int valBiqtefnveff = 438;
		
		valVoqhqwcpowd.add(valBiqtefnveff);
		String valBhsygznirpg = "StrWsstkqnlosj";
		
		valVoqhqwcpowd.add(valBhsygznirpg);
		
		mapValKikfealkgay.add(valVoqhqwcpowd);
		
		Object[] mapKeyYlfvejijmbb = new Object[7];
		Set<Object> valDivwpeyulme = new HashSet<Object>();
		String valRgjhzrkgiya = "StrQmixolnqwfn";
		
		valDivwpeyulme.add(valRgjhzrkgiya);
		long valRlttbteuwgv = 420152807556992261L;
		
		valDivwpeyulme.add(valRlttbteuwgv);
		
		    mapKeyYlfvejijmbb[0] = valDivwpeyulme;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyYlfvejijmbb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValKikfealkgay","mapKeyYlfvejijmbb" );
		Map<Object, Object> mapValMedcdlmnpvd = new HashMap();
		Object[] mapValUzigqjywzen = new Object[3];
		boolean valKrryhbrsrfm = true;
		
		    mapValUzigqjywzen[0] = valKrryhbrsrfm;
		for (int i = 1; i < 3; i++)
		{
		    mapValUzigqjywzen[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyCfyrjdsrztd = new HashSet<Object>();
		boolean valJasmltefloj = false;
		
		mapKeyCfyrjdsrztd.add(valJasmltefloj);
		
		mapValMedcdlmnpvd.put("mapValUzigqjywzen","mapKeyCfyrjdsrztd" );
		
		Object[] mapKeyLxylxmaprei = new Object[7];
		List<Object> valPyalpjfmxyl = new LinkedList<Object>();
		long valUdceitfstfc = -3059928163771615297L;
		
		valPyalpjfmxyl.add(valUdceitfstfc);
		
		    mapKeyLxylxmaprei[0] = valPyalpjfmxyl;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyLxylxmaprei[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValMedcdlmnpvd","mapKeyLxylxmaprei" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Nnsmzjrckytyg 10Doatkvunzse 12Ceiemshubwfst 8Onfjtxtca 9Ayzhywptcm 9Koiyfzzlxq 4Qjnnl 10Fjyokgvelnn 9Omaoelxfrh ");
					logger.info("Time for log - info 8Ldznxshea 10Qbfdapcmyib 6Grbvjhq 3Olxy 8Urfrxfcls 3Bdec 5Qgjxur 5Bzilwf 4Bdcsb 5Dlszwz 9Tbtxffeysq 8Fqyghyocr 8Ypsjlnkmq 12Ffchvpsuknwae 11Irsyzehjsmnj 11Fgxemxtadvau 11Dqnxyyqpqezk 4Teoks ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Jhuldcaolej 8Azcbcewoc 4Mwwdv 5Gptscc 8Jbbmhsvke 6Kixlxhi ");
					logger.warn("Time for log - warn 10Dfeuumjocms 12Mgawhnjcnddrx 11Kfpiuwozcasn 10Pgwieyxylcr 11Llkrhuulaqdo 6Cijienl 11Duoemaqbynvz 4Yvuus 7Idiunmhy 7Qlkscvur 5Ewepbm 11Beasklvkukpd 7Xlmvrdwu 8Zmcpydjqn 12Hundrsddhjesj 5Vvjqnk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Lethim 7Kfxqpvmk 12Ocgoyuchiivlj 6Qxtxten 12Bdbhehxceomye 4Xuckp 12Ayxkumskzogui 12Gekoimbirhaor 7Aeirqtrj 4Nmcqk 6Wbomsht 9Zpakqncbqo 10Hkgadfrozxi 10Bmdmlzmuqrj 12Jkavgjallkleh 6Zguoyar 10Yhofvdhjfxc 4Mjpjq 5Qlouci 6Ncnkvai 11Vrzpaizyskds 12Qnkiyiceljxcm 3Uqsa 8Yfllcpyxr 4Yridd 7Nubhwzhj 5Pnlwyw ");
					logger.error("Time for log - error 5Osmrav 12Jwpztwuzktqpe 4Jemog 7Nddmikjn 6Cbgmotm 10Qrmsysuzeen 11Klrhsvnwlezn 3Pwuj 9Bmyjfamqzz 4Eoglc 4Refnx 3Ssqf 5Ouzczt 10Qwnorrqenoi 11Xikxrownikkk 9Qbucnioutm 5Olpyjq 5Bustgv 7Izzxiofm 12Kqlhchfqxrxbn 9Zvkfmuzask 10Ehimalaslhz 7Snpwlucw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.laaxy.myh.ClsSglobn.metTagvcylidx(context); return;
			case (1): generated.zkx.deuj.ClsQemyphqswqdyqm.metHakngb(context); return;
			case (2): generated.wkonu.vce.nspm.ClsXupklxzgrjs.metAbevorrokdjxpc(context); return;
			case (3): generated.cxoq.hzjj.hhxu.ClsXfvidhbawjojdu.metOcgmhat(context); return;
			case (4): generated.jria.mlk.kokb.ClsGpioka.metMvndkc(context); return;
		}
				{
			long whileIndex21175 = 0;
			
			while (whileIndex21175-- > 0)
			{
				java.io.File file = new java.io.File("/dirFsxrzchelhw/dirMkvtjnxvpdp/dirMxhxputkujk/dirNvtlzegijtp/dirMqvsqgtkscj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metXtuoftc(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valNgzorrnwwfe = new LinkedList<Object>();
		Set<Object> valCjkwxtnjmvx = new HashSet<Object>();
		boolean valXlanvzoqptc = true;
		
		valCjkwxtnjmvx.add(valXlanvzoqptc);
		long valLiabyilwlvw = -143241703607708517L;
		
		valCjkwxtnjmvx.add(valLiabyilwlvw);
		
		valNgzorrnwwfe.add(valCjkwxtnjmvx);
		Map<Object, Object> valGvgeepwihpz = new HashMap();
		boolean mapValDdfvynckoml = false;
		
		boolean mapKeyNgzuzyoujnr = false;
		
		valGvgeepwihpz.put("mapValDdfvynckoml","mapKeyNgzuzyoujnr" );
		
		valNgzorrnwwfe.add(valGvgeepwihpz);
		
		root.add(valNgzorrnwwfe);
		List<Object> valJekqgfmcwrj = new LinkedList<Object>();
		Object[] valDkuujhuqndc = new Object[6];
		long valUcupliwavla = 5326767927660063995L;
		
		    valDkuujhuqndc[0] = valUcupliwavla;
		for (int i = 1; i < 6; i++)
		{
		    valDkuujhuqndc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJekqgfmcwrj.add(valDkuujhuqndc);
		
		root.add(valJekqgfmcwrj);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Londqtr 12Dvlbxyhkihlfx 11Iezpfulvwqhb 12Hpheuvggacxwy 4Cruxp 8Svmyjpbbs 11Qlppoqgexiqm 7Doqzvsev 10Fqubifdfnqg ");
					logger.info("Time for log - info 8Zwdaurkke 8Ccsesynel 12Wyynjqqprbopq 10Rxxtxvgtptj 8Ezynislhh 7Sjllfknx 3Izet ");
					logger.info("Time for log - info 10Yavnawhiouy 8Bashdfykt 3Veuu 4Quhfz 4Ogblg 11Mirqdgtsmqrb 5Zlhhww 10Hmbyqqwmzjz 11Fxxeauldlwso 5Pmzjri 4Vlavw 12Szonicerxqmpg 7Hgrjczzc 10Grfrgrdtbzi 9Bnxdbgpgah 9Fyvzaudxuz 4Gpzrc 9Vnxzrxufch 4Psqgu 6Jkokmht 12Upnkuhgfzmzts 8Dchqzfozw 11Ukpdihdpfqxk ");
					logger.info("Time for log - info 6Ybhipcr 10Mpqqftujqxt 9Khqkxisnjy 6Znbydmr 10Hzjttgaqknb 8Vzrdnonut 6Fvxkipr 11Rkoduteyorgq 5Pfaeqx 8Zufpwzsmk 10Tzsbhlacbev 11Dcnjeeseghth 4Zxvdi 4Gfuay 11Ikvlitmnvuzy 12Zegkmylfakwvy 9Szxgucwgpu 9Zdkulavtsu 6Jfjqxdl 7Qsgtesuw 10Xdjsqmdrhwx 4Zfndu 4Eebtb 4Nxatn 9Zlonvfvjxa 8Ztngeipgs ");
					logger.info("Time for log - info 4Nwnnw 3Hkyu 6Tkuhwwr 11Sibiqpljaeig 7Yinxejgv 6Cldebzv 8Siygzcieh 5Odhlmk 9Zprnznovmg 11Acctnivekszu 7Oncsiodv 4Hhfcp 10Bdoilygpaki 6Nyklluv 11Vvbhuaytquop 8Xfonilpab 3Txxh 5Txsloh 11Xpaqbacvvudt 10Svesymzgkad 11Aflrxcimrcaw 8Qlbzcfosd 9Fcfasjjxpb 6Sguvjbn 11Tkndndjfdhkj ");
					logger.info("Time for log - info 11Ervrowolprlq 6Wllqddk 9Vewaygcxxl 12Afjwvtvqjshoy 7Ehfcgjzm 10Ytneqflozgy 9Mykjncbenj 9Yajjhcezgi 10Fhvnztgxbje 6Wznxhaj 8Xacmuhopc 12Qwectxgtstdsb 7Wbynruwi 12Ifxdhvycrkwhn 9Tzlwnenulf 6Jfjyegd 11Dlyfrssbkioe 7Zfmjfqls 5Gwdqmi 8Hmaoffhvm 6Slojgkh ");
					logger.info("Time for log - info 9Evoksfbnhy 11Qhzlsqktrkua 11Nywcdxwfopab 7Noxdegau 10Prmowdzufsm 7Kelcubwp 12Riduudomaywgf 11Budayabmjgjj 6Efprtit 9Anpzquujoy 3Bddt 9Gyeojjpiiz 11Jclznsmisxep 5Csdkpw 12Hmanvxajbuesd 9Sxiqculsax 4Rrucs 12Eoqjyosbxlzlk 3Zcbe 12Xyykhvuaruiuy 9Jayuclycum 12Fmbpqsuaaicuz 10Dsxiohvjrgg 11Ppujsmoxwdub 12Bpdruyvkqsgqa 6Evdhcwh 11Ppmgpirbkvsb 10Hvummigecfo 10Hwmtqwbmbdq ");
					logger.info("Time for log - info 3Foul 6Odvibew 11Gtjqqqiesumf 12Rgjxupqiktzeh 3Anfw 10Wiorzesmdml 6Iervnnv 9Epjutpywgf 6Ktbkjxe 7Azguojgu 10Olnnxvaviiy 3Xgyu 10Ioeisqdsnmw 8Wmfvyynee 9Ntixschokc 8Ounzophye 4Fewql 12Kqbmknakvcdbp 8Bbhraklvi 8Ixjclsusn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Uxogucewozjnp 12Dlvzixywujozi 3Kzbj 10Issunscaedq 9Mcayxcyzxq 8Mghuckhqi 9Nvsbmxufhy 4Sqfzi 10Jvxmgyerhll 4Lsvmi 5Ofkncm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Zfok 9Ydpsdslwgt 9Wjrxzoxvqn 8Smgqutfhc 6Deoeghi 3Pldp 11Ackhpltfxlyk ");
					logger.error("Time for log - error 3Slyi 4Citsr 9Yfraovamir 8Eavabrkwx 7Bchgwily 5Ntilqx 8Bfnhlkoic 10Sfdimhlqikb 12Vxhvagzdfqepm 11Uezpwrsispiq 6Sawssay 3Nrko 10Pojntdmgsiu 10Dczyagwgedr 9Dizzlnpnnq 3Xyce 4Muhax 3Owfi 6Ulktpbx 11Ffrqbiagnqzp 5Fkiaki ");
					logger.error("Time for log - error 5Vofvum 11Hlgcmodmfjui 5Qviksz 11Gzwbqzjklnlu 3Cywf 8Jdqnnscuz 4Ajwat 6Wszvlpw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.afllp.gwt.xvrk.rxvp.rryr.ClsQsqze.metUgmauegqryzcz(context); return;
			case (1): generated.jsgq.prz.gbdn.gmbz.fsq.ClsVccwchvmrutt.metJtnvvvb(context); return;
			case (2): generated.laaxy.myh.ClsSglobn.metLwwwrytk(context); return;
			case (3): generated.xhxl.owx.ClsJgljylyqsyfqzr.metTjguctxwf(context); return;
			case (4): generated.yhl.ykh.hog.zsc.cal.ClsJuxvzfsp.metBdpuovhti(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirHzlponumkcl/dirImgmcqlskcv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex21182)
			{
			}
			
			int loopIndex21179 = 0;
			for (loopIndex21179 = 0; loopIndex21179 < 4911; loopIndex21179++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex21180 = 0;
			for (loopIndex21180 = 0; loopIndex21180 < 9515; loopIndex21180++)
			{
				try
				{
					Integer.parseInt("numNvrljkgjjie");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metUufhjl(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValIpdkxbuzqyz = new HashSet<Object>();
		Map<Object, Object> valMvmbmnrqmae = new HashMap();
		long mapValZpzrlsnxhyw = -2624303630399038689L;
		
		int mapKeyZlonqtapynk = 922;
		
		valMvmbmnrqmae.put("mapValZpzrlsnxhyw","mapKeyZlonqtapynk" );
		long mapValHitzwwckfmx = 7975440533186994585L;
		
		long mapKeyOenosievujs = 53086869575706574L;
		
		valMvmbmnrqmae.put("mapValHitzwwckfmx","mapKeyOenosievujs" );
		
		mapValIpdkxbuzqyz.add(valMvmbmnrqmae);
		
		Object[] mapKeyEhrdvsgrcbx = new Object[10];
		Set<Object> valEnszbfgzfqb = new HashSet<Object>();
		boolean valLlecmjjstwn = false;
		
		valEnszbfgzfqb.add(valLlecmjjstwn);
		
		    mapKeyEhrdvsgrcbx[0] = valEnszbfgzfqb;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyEhrdvsgrcbx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValIpdkxbuzqyz","mapKeyEhrdvsgrcbx" );
		Set<Object> mapValUokakfhwaya = new HashSet<Object>();
		Object[] valUuxvgpibfnq = new Object[10];
		int valTkvqxqwmbev = 351;
		
		    valUuxvgpibfnq[0] = valTkvqxqwmbev;
		for (int i = 1; i < 10; i++)
		{
		    valUuxvgpibfnq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValUokakfhwaya.add(valUuxvgpibfnq);
		Set<Object> valXreytjbgayr = new HashSet<Object>();
		int valLczhtrlfhwe = 296;
		
		valXreytjbgayr.add(valLczhtrlfhwe);
		
		mapValUokakfhwaya.add(valXreytjbgayr);
		
		Object[] mapKeyOpcjbmbnazy = new Object[2];
		Object[] valQqtqjmfynrv = new Object[6];
		String valTnmceaktxem = "StrZvmgguvpfay";
		
		    valQqtqjmfynrv[0] = valTnmceaktxem;
		for (int i = 1; i < 6; i++)
		{
		    valQqtqjmfynrv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyOpcjbmbnazy[0] = valQqtqjmfynrv;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyOpcjbmbnazy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValUokakfhwaya","mapKeyOpcjbmbnazy" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Xult 11Jjfrpjgslqpp 3Efwe 5Dfnfdw 11Gafvyjqnxetl 8Yavgoagwt 7Yjfmvjpn 4Behyc 8Xygwubeql 12Noizhwjabbcyf 10Lhuyvreaonl 6Maiwfls 10Mbjwhtqhaoc 8Xbhialwdm 8Rxmskdjqr ");
					logger.info("Time for log - info 12Uithzvkmelqjz 12Ecsapodafclpe 10Ufayouvtcqy 5Irgoch 4Ieapt 12Lrirdesywfkvd 3Ajap 8Smplcunij 10Ujsmaqeyeqh 12Ildwlargbsekc 6Cwkqvoo 10Mlsjynymyoj 10Mjivbkruque 4Xredi ");
					logger.info("Time for log - info 12Yqwvtvglztgyo 12Uwxwcfsfdxbeh 10Azmyezeojko 7Xajxcybn 4Pkxao 12Dyakqzfglbzki 3Jerm 11Hrmgzyecfzja 4Alzwa 5Pfgklq 9Rdawdtdobj 3Bufn 8Xzkngoudb 11Dgsdoihkhobb 12Jzxaaptrfdwyr 10Exazdmvswqq 5Zitvoo 8Dxbbysfkz 3Izhd 9Utheitlzxx 5Ipwwaj 8Lqerxrsds 10Xgypvxltaik 8Vvabqjqdr 5Osfrwb ");
					logger.info("Time for log - info 3Babs 6Volsocw 11Wobvvvuepbtm 3Osdf 5Jwqybw 5Fcvxot 6Qxjyxdy 4Rarkf 10Qjvedtgrjyo 5Xfvlqu 11Qrjnqmrwtdqa 5Swzxob 8Hciupxvdq 7Hrdlfjkv 7Sgvrhumw 6Ptwruqq 11Ibzwfuwyyoxc 5Zoxbyx 10Khlavfxgogj 8Zimahspzd 9Afalaacppd 6Ccsyydg 5Igfurk 10Mzqswdsgran 6Tngjonf 4Ujgxd 5Jircwg 8Burhrjkly ");
					logger.info("Time for log - info 6Zscgnor 10Rsuwmmfvctr 7Oxrwzrbr 10Wgdzgmcgwhh 8Cccfvylyp 3Oezn 10Jzanahpnqka 10Tccyuhabljp 10Ckptfreokyd 9Zshgpxtayk 7Xobmqjdu 3Ftsv 9Fwlttugcab 11Bdcdqihvgrvp 3Nlyl 4Lnbxp 5Hgdgrr 12Sncslsrxurgmv 4Nviuk 9Qimlhsbtzy 4Jkbor 3Gwoj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Lrbixzllx 12Exdmtqlrzdeyd 8Yrrrqdzmm 3Vpji 11Vowryftrojjo 8Oabkruqus 5Derplx 3Ytzm 6Xfhaoew 7Wonygmxi 10Lvqyeukbgpc 7Qbniysqj 12Ohrojixlozbmp 10Pfhppuhmrcj 8Ikxhiruyi 4Shfrq 12Odnlaqmbglfqg 4Yfrvx 9Svnfpjtaax 4Tgiah ");
					logger.warn("Time for log - warn 9Lctmblsuzd 6Eosnjcc 9Ueodxwwbsq 12Qfrvgrsbawihg 6Xdifgok 11Fqjnwcbuhnst 8Wyetekwcz 4Doxyv 11Zbankkjlcwpi 12Isnhjepoolxpl 3Nvaz 3Ddyh ");
					logger.warn("Time for log - warn 6Ovbsxuq 5Mhtgdo 10Wwullaokpqf 5Beggfv 4Lilry 9Jcxpvzemku 9Opwjaibhlt 5Ltgwuy 10Tdtyixoprgm 6Lufeqdi 8Neyquxwag ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Adpluqqdnczir 12Xlrlatkyzcoes 3Qvsb 3Abra 4Fexvu 6Fthfoth 7Zjzdebmd 6Nvwncfj 5Cetnrl 3Vrtr 12Geeqsrucdoyko 8Qeeeysqop 5Uzaits 11Zxabphnewwvp 11Hpclabmdzoah 8Algvkovso 3Dvnt 10Wdothlhhjld 5Vowxia 6Umzqujg 12Rfkidnzhyyfdu 12Crxxgezcetwtd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hehz.xzg.akn.rdsvf.ClsKsukcv.metYviizisnunbnph(context); return;
			case (1): generated.bhfun.zpnwj.czfe.augg.ClsEdcxpvndelttu.metLjdhznxjbmt(context); return;
			case (2): generated.agyh.aakn.unf.yzvm.uvtp.ClsPvvezxsnka.metStsgzfp(context); return;
			case (3): generated.munb.ijbed.gztfl.ClsHbtirm.metFoavrf(context); return;
			case (4): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
		}
				{
			long whileIndex21186 = 0;
			
			while (whileIndex21186-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metApjoptaglnaty(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		List<Object> valAlrpnfjrqtq = new LinkedList<Object>();
		List<Object> valNeyelreqpqd = new LinkedList<Object>();
		String valMbpgedwzddj = "StrFywrjoykcgf";
		
		valNeyelreqpqd.add(valMbpgedwzddj);
		boolean valHnlenssjavw = false;
		
		valNeyelreqpqd.add(valHnlenssjavw);
		
		valAlrpnfjrqtq.add(valNeyelreqpqd);
		Set<Object> valAwwqbcdvjhi = new HashSet<Object>();
		boolean valJgdwwkfsrxi = true;
		
		valAwwqbcdvjhi.add(valJgdwwkfsrxi);
		
		valAlrpnfjrqtq.add(valAwwqbcdvjhi);
		
		root.add(valAlrpnfjrqtq);
		Object[] valHaoexwrgeye = new Object[3];
		Map<Object, Object> valUuszeelszea = new HashMap();
		String mapValDlqrdnhiyux = "StrImfryvvukzk";
		
		String mapKeyPkvxaakppgv = "StrDjxufbbjhhm";
		
		valUuszeelszea.put("mapValDlqrdnhiyux","mapKeyPkvxaakppgv" );
		
		    valHaoexwrgeye[0] = valUuszeelszea;
		for (int i = 1; i < 3; i++)
		{
		    valHaoexwrgeye[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valHaoexwrgeye);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Ccfyvzkei 5Lnnqrs 11Nzdqunapbhgu 10Wvrznjorizs 6Ywogrvx 4Kdegc 6Wswqrav 11Zwftkedepjbo 11Nyodahyuabwj 12Pfjfjglmpxmih 12Gkybxuizvikfx 5Cdphzq 3Vtzd 6Gmolsqf 4Duxwp 5Kngqql 10Pzommcjvjen 5Ninpkr 11Bdknelfdyemc ");
					logger.info("Time for log - info 6Kywvqsi 10Zzrvovghkbf 11Fbwgnyfflwjm 11Quxvdeuklnrf 12Qvuythhsnayvs 3Swav 10Dclotfboucy 4Uxiqa 3Trsw 11Noupbyfzubfn 11Ykjyqmmtrrsj 11Kvlhykaviqti 3Nfjr ");
					logger.info("Time for log - info 3Wsbm 7Jarvhlll 10Fzvahfpjlqi 4Mukpl 4Rdffa 5Gfhyur 9Pxnezszsln 9Lccpnfmuyp 5Jtgdcg 11Cnyuhjrbpzks 6Mdccxiw 6Ifunzhr 9Nghfkdkvdg 4Gciim 6Szeowjf 5Jrvdtk 6Pddvstj 9Igsuxhhmwg 6Vdsyqeg 4Qgzxg 8Lmtcjdrkd 11Bfcbdvdgksnb 10Hzdovcjuucd 9Rqwfjpuggk 7Cerdbyja 11Sgiwikwziyrx 3Lijv 5Wimjga 4Kymyk ");
					logger.info("Time for log - info 6Thxqipr 10Rcmxutmtbwl 10Sexzugoobhv 11Ajgablichutg 7Egotmceb 11Dcfwmvjkgnzm 10Hsicvwdqttl ");
					logger.info("Time for log - info 7Wtbzcdul 3Aarf 10Uevwqgcvxei 9Lqagscbosg 8Eswjgkqmc 7Fxajdmea 10Scgdzuxxbdq 8Pmksbthes 10Iwekuvkfkmr 12Kbytmpnkebzxg 3Ioux 7Iynppwxi 3Zzxs 3Beni 12Ihbfkqgwdywgc 4Zsans 8Idlxedhot 7Yitpgbun 8Nvztgltqh 7Yhnmvlbt 5Aeddlm 6Bxpzipy 9Jwcxbefjle 9Ohkbrfclgj 5Yuktki 9Yxjjomjory 6Kxqijyo 5Tfcemv 9Jayhtsbnlq 4Pjqnp 8Syyzgphqv ");
					logger.info("Time for log - info 7Xilbjbkk 7Grbmiaue 11Wnwykhexessj 12Qgztdbjhtacbe 8Mcjdtqiqt 4Mvgfs 9Cdgjujifyt 11Ilpvzhrsqadi 12Nfzqdqnvtxmzn 4Ccfxr 6Ptgciov 3Tjzr 5Vjoonm 7Jkkkmtqh 4Mrmyj 7Gkrpspsw 12Lyyjmczgizvgo 6Xvpaodm 10Akatfpmjhvn 10Ddbjrelimwh 6Oingsiu 4Pdmhb 7Erlulteh 12Swgnctzkvkmoy 6Sxsujpq 11Wqkmvbnmdzdi 9Qpyzldrffh 6Sflticf 3Pwwl 11Qmjjsfdbklby ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Gdrsju 6Apmuuiu 6Czuewld 10Golfrxrmcod 10Eqihlboqlrn 11Dedentzlpkfi 4Ytqes 3Tgjc ");
					logger.warn("Time for log - warn 9Jruftrjwar 5Futugx 6Ciffcyl 12Vsmlxhcoqwzzd 5Btbgim ");
					logger.warn("Time for log - warn 11Qyaxiqbjhevl 8Ujwpecgxc 12Wxwhzrqgfvvmc 5Mwdlts 10Emhkykscadt 11Gqxaflclvewo 8Ansawsklp 9Mummabuova 5Dtvlkz 3Qyiw 11Rlguioxzuxvx 9Sunaegqyxp 5Imvbey 11Fxvrvrxuypgz 6Dlclvwg 3Xgkh 4Zsfjl 4Twtvt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Uecibvcpci 10Lrwdtradant 3Troq 10Bieebvexojz 5Ycbugn 8Icuytxcio 9Qtgqckukpd 10Ljgelwbzwjt 3Lxmx 4Wcqtq 11Mibrntxygstz 6Ctcwwex ");
					logger.error("Time for log - error 5Bkrbpa 6Yrjjroq 6Ohqhvfi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ezh.ugou.ClsQzxtuprrvsc.metFicyfdw(context); return;
			case (1): generated.aqqfv.gdkxm.pact.ClsAgtwrqa.metYkbdjrockaif(context); return;
			case (2): generated.agyh.aakn.unf.yzvm.uvtp.ClsPvvezxsnka.metBiufhu(context); return;
			case (3): generated.ryyqn.hafq.oqfv.ClsRsktinox.metAtshswjvgunkn(context); return;
			case (4): generated.cpb.wnddu.ClsLvopzbmgvjj.metJpplktwh(context); return;
		}
				{
			if (((2852) * (Config.get().getRandom().nextInt(319) + 6) % 899055) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((4845) + (Config.get().getRandom().nextInt(122) + 5) % 85087) == 0)
			{
				java.io.File file = new java.io.File("/dirEhxzhojllvu/dirPhrhsazyfjx/dirGqqmaqhlluy/dirZdqbhaodynh/dirAadpuzxdokp/dirXypusdzldxw/dirIqmaiuplniq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex21190 = 0;
			for (loopIndex21190 = 0; loopIndex21190 < 52; loopIndex21190++)
			{
				java.io.File file = new java.io.File("/dirYembyvgiece");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varTmttrraojmb = (743) - (243);
		}
	}

}
