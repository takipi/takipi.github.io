package generated.htfwc.kxkr.hjcg.ofg.qaif;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsGjqugtpsjo
{
	 public static final int classId = 231;
	 static final Logger logger = LoggerFactory.getLogger(ClsGjqugtpsjo.class);

	public static void metIuperibrlehft(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[9];
		Set<Object> valWojhyuiyoyi = new HashSet<Object>();
		Map<Object, Object> valGdtuudctezp = new HashMap();
		boolean mapValVptvjczgbsr = false;
		
		long mapKeyUkpckywjhyr = 1521326979644539218L;
		
		valGdtuudctezp.put("mapValVptvjczgbsr","mapKeyUkpckywjhyr" );
		String mapValRkvnludxkjz = "StrRbkcebfxyiy";
		
		int mapKeyIqndpkljubl = 585;
		
		valGdtuudctezp.put("mapValRkvnludxkjz","mapKeyIqndpkljubl" );
		
		valWojhyuiyoyi.add(valGdtuudctezp);
		
		    root[0] = valWojhyuiyoyi;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Nchflr 3Iwtv 5Ttoaeb 4Wtqpr 8Bgqxxoccy 12Voubkkdnarvzo 9Uoqmeekrbf 11Arahbedxcves 11Ejxjwqlxuxph ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Kqjzlpjgayom 12Jlyeupbhtsfzn 3Hdfd 12Ywoqurdtlwmgw 10Rtqlhzhquhb 8Fgxshqwqr 12Ioikkqbemiadr 8Nkvplwecn 11Erntrkcignrk 4Ugkpj 4Sxxbf 5Vysstm 3Qemz 3Bsvq 11Fanvhxbmxcvg 9Edsmfvrbwq 11Mzsjeiuifwjz 11Etocxczxnsly 5Snhztv 10Nfeiwxpoqwj 8Lozzdydmz 10Dverqqkazhg 5Rhvpgu 4Yfeeo 8Vjazqztqs 9Obofvwgtfo 4Nglgc 8Fxeoereld 12Hmlimqtcsksxi 4Dsnqs 4Ixaaa ");
					logger.warn("Time for log - warn 9Knayhvlrwi 7Ctrlizpn 8Gpxxdvkaq 7Djpzqtak 9Yxczsvytkn 6Zqkemvj 4Hnydr 5Xmybkz 9Myjectycut 9Egdwrxbbkz 7Oumsdexv 4Jpamy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Qxvfqi 8Qhscqmttj 5Kdvlcc 4Ipivg 8Qurdvlphf 6Rwnzocx 3Nycr 8Aiihxoomr 9Clgepwecqj 6Fvgnksm 8Yncvfkvzy 7Xoabshbl 10Swhkmfveskb 3Nktu 8Shwiswbde 8Ionpngysg 9Zjawaxjmtq 12Wlxmozukuvlzu 5Ecgahg 6Htkoofa 7Ivrzkhwz 5Wuubvc 3Rgms 5Angyko 9Ihgzxfurip 5Wcrdxk 11Psplrlxiqgje 12Kdzxxnzuopack 7Mqvrzdli 7Gtvbmjry ");
					logger.error("Time for log - error 10Xlvdifqtyhz 3Tfdy 3Zrjx 6Ljctdts 11Dsehofzgsomq 3Doab 4Aswtz 8Ddeuvrkeq 12Lvmkuxzzqvsqe 8Wpwrginhp 6Ziqqvfj 9Wyrtnuxdaa 8Lebqiygdb 9Mynyeopvua 4Nxepn 7Ufutjmhu 8Ekknjbpfz 9Booinriqkg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zdmfw.qfic.ClsQmanwrctuzecr.metEvpjjip(context); return;
			case (1): generated.rorl.wuo.lqgdf.ClsUltodfmiuq.metLlgpt(context); return;
			case (2): generated.lxrj.lts.csk.iew.ClsCagmzsja.metOondcg(context); return;
			case (3): generated.inao.viw.ClsZkxazvlqxnvyzx.metDbsezno(context); return;
			case (4): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metOcmdwdvovlzu(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex24122)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metOyrdlzxaj(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valYdmfhrygkdh = new Object[6];
		Object[] valLojgvwoleck = new Object[7];
		long valByjlfuialgb = 4841046783294872134L;
		
		    valLojgvwoleck[0] = valByjlfuialgb;
		for (int i = 1; i < 7; i++)
		{
		    valLojgvwoleck[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valYdmfhrygkdh[0] = valLojgvwoleck;
		for (int i = 1; i < 6; i++)
		{
		    valYdmfhrygkdh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valYdmfhrygkdh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Ftzyeqmfsls 11Pjdjkzbwgkok 7Wkuvqwuv 12Ocvgltgirpcce 11Rxusjjtextjl 10Mzhzqmjxtpt 9Wrlwjwxced 12Yxkzfydquprhk 3Xvzn 9Bucrdxyxsd 8Njlbjkeqz 3Easa 8Kddqdunjv 9Nbprkbbdfn 4Cccgu 12Hbukurrzwtfdq 10Qtudmmtquzk 8Lhganjheh 6Kkflzzb 4Khghk 10Qghxpdlgukj 8Xhwlbeaxc 12Soemdymzxthzs 8Zfdotipwl 3Xlbq 5Yqbcaa 11Pkgrhpwptybp 12Fywsomiqybnsb 10Kzwtgzizmkp 4Gipnm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Tajqfkqnzj 5Bzefra 6Rsxnvhx 12Kehxuzbqngjww 4Qmvyp 9Lqmfyfgqqf 6Oshegmd 11Dosycejdguyt 9Ekplpgtwrq 9Pkjbidcrvn 10Kowplcospcg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qdt.cqf.kkjo.xjulh.ClsLodna.metTabsne(context); return;
			case (1): generated.deuz.rvz.jsq.ClsHbyckyeswad.metNsroqeuzcfbif(context); return;
			case (2): generated.cwxj.lmfzj.egfdm.ClsTwbdwdairow.metGgcimwxhpnbnnq(context); return;
			case (3): generated.dpe.jvo.jwdtk.ClsKqcmvv.metZebfzdcdmlw(context); return;
			case (4): generated.zadtu.owlhb.qsd.bfzb.ClsWgiwrqnvyw.metJmapoligglq(context); return;
		}
				{
			int loopIndex24126 = 0;
			for (loopIndex24126 = 0; loopIndex24126 < 4779; loopIndex24126++)
			{
				try
				{
					Integer.parseInt("numZjjmwydgktr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((Config.get().getRandom().nextInt(100) + 5) - (Config.get().getRandom().nextInt(247) + 6) % 337075) == 0)
			{
				try
				{
					Integer.parseInt("numRqxzeualuig");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(445) + 5) * (Config.get().getRandom().nextInt(138) + 4) % 790392) == 0)
			{
				try
				{
					Integer.parseInt("numQgsrrpaqbgv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metVfpgcml(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValHudpmuitmgw = new LinkedList<Object>();
		Map<Object, Object> valGebedfawwdr = new HashMap();
		String mapValZmevmimmozu = "StrXgafguvgdwj";
		
		long mapKeyQcndnljbvyk = 4646665344731846188L;
		
		valGebedfawwdr.put("mapValZmevmimmozu","mapKeyQcndnljbvyk" );
		
		mapValHudpmuitmgw.add(valGebedfawwdr);
		Object[] valTvmxjrezmdl = new Object[11];
		int valVluuavqcejo = 941;
		
		    valTvmxjrezmdl[0] = valVluuavqcejo;
		for (int i = 1; i < 11; i++)
		{
		    valTvmxjrezmdl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValHudpmuitmgw.add(valTvmxjrezmdl);
		
		Map<Object, Object> mapKeyTgaqbmbcafs = new HashMap();
		Object[] mapValZoigblooclw = new Object[2];
		boolean valEzdicdwzzdn = false;
		
		    mapValZoigblooclw[0] = valEzdicdwzzdn;
		for (int i = 1; i < 2; i++)
		{
		    mapValZoigblooclw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyZsqtxfvrhzn = new LinkedList<Object>();
		int valBphqdcbsbhm = 475;
		
		mapKeyZsqtxfvrhzn.add(valBphqdcbsbhm);
		long valAkuclldcsew = -2559311684935183383L;
		
		mapKeyZsqtxfvrhzn.add(valAkuclldcsew);
		
		mapKeyTgaqbmbcafs.put("mapValZoigblooclw","mapKeyZsqtxfvrhzn" );
		Object[] mapValYmrbhhughxp = new Object[8];
		String valMnwmtczufig = "StrWpvzzrwobun";
		
		    mapValYmrbhhughxp[0] = valMnwmtczufig;
		for (int i = 1; i < 8; i++)
		{
		    mapValYmrbhhughxp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyOhsidnalevt = new Object[7];
		int valWxvimovhrfx = 394;
		
		    mapKeyOhsidnalevt[0] = valWxvimovhrfx;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyOhsidnalevt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyTgaqbmbcafs.put("mapValYmrbhhughxp","mapKeyOhsidnalevt" );
		
		root.put("mapValHudpmuitmgw","mapKeyTgaqbmbcafs" );
		Map<Object, Object> mapValBqycpxdhnno = new HashMap();
		Set<Object> mapValOamgoplgvcv = new HashSet<Object>();
		long valOnlppnzgcuo = 3189240597293671403L;
		
		mapValOamgoplgvcv.add(valOnlppnzgcuo);
		
		Object[] mapKeyGrmuervbpkn = new Object[11];
		boolean valRpxvtiflvfn = false;
		
		    mapKeyGrmuervbpkn[0] = valRpxvtiflvfn;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyGrmuervbpkn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValBqycpxdhnno.put("mapValOamgoplgvcv","mapKeyGrmuervbpkn" );
		List<Object> mapValJrjbxavldtj = new LinkedList<Object>();
		boolean valDilteomjhwu = false;
		
		mapValJrjbxavldtj.add(valDilteomjhwu);
		String valNtonpyacrmr = "StrVsntygkbqtg";
		
		mapValJrjbxavldtj.add(valNtonpyacrmr);
		
		Set<Object> mapKeyRvaqywqmtam = new HashSet<Object>();
		String valIrrntyelckp = "StrSsvmpjmijua";
		
		mapKeyRvaqywqmtam.add(valIrrntyelckp);
		
		mapValBqycpxdhnno.put("mapValJrjbxavldtj","mapKeyRvaqywqmtam" );
		
		Object[] mapKeyMbynbumrwff = new Object[3];
		Set<Object> valUrnppfducll = new HashSet<Object>();
		long valRaeocdexfrr = 2544769531126548156L;
		
		valUrnppfducll.add(valRaeocdexfrr);
		long valJutowdyqbia = 4018266058558505016L;
		
		valUrnppfducll.add(valJutowdyqbia);
		
		    mapKeyMbynbumrwff[0] = valUrnppfducll;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyMbynbumrwff[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValBqycpxdhnno","mapKeyMbynbumrwff" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Exnwcbrlxbdfx 9Rivfzdasat 10Lnrhwnrpgsb 3Dmjc 11Dhljiihvmckx 3Kdju 11Fhnbmitvwwvq 8Hpfgoedht 4Qvfxj 10Phwyjqhvakx 5Ushkam 5Kwzrzb 5Nzzqmm 12Yxshedlvhtdyu 6Ukklxma 10Zpbzmizrihj 7Ficqhasq 11Vkbiaubdagrq 4Caygj 8Cegscpuij 6Dtdjpva 10Bmvqelgczzn 9Uwogzgaitr 10Cgfczceqmjz 11Lxrtmogqdrmc ");
					logger.info("Time for log - info 6Fqdjsra 4Wmkmn 5Qrhhyl 3Foyt 6Ctnqrly 11Zksykbgjmvnq 11Frkwjkoywjji 10Uucdqonxneu 3Mknu 5Cletqx 7Pbwjpsrk 8Enylvwcnb 6Pbqqbxe 7Wmtjmdfz 10Jannuaqtrmy 10Krfzsgpxjvc ");
					logger.info("Time for log - info 6Bpjktpc 6Fawxhdv 8Ocirvftqv 12Crjkypzzpojre 3Rjdc 9Qodflcfdmq 12Sxshuecwjcwdv 10Pfhstfnbwdo 7Emmiapzb 7Licuiohf 6Gnljgpd 9Xmfjuqkswu 7Nowwpdqg 5Iwtdui 11Qnzkhglmewhy 12Xvqtooawsdgqq 10Rntmwwmwqan 3Cphx 10Yntfffjywdx 8Rbssqjbaa 5Itwftq 8Xgepckmjf 4Mjupc 3Wrjy 9Khbnfqdkpc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Gyhdode 9Jtgovzhhpe 11Wzgnrobiucnq 6Djwixtk 11Alefrwyvgvrd 4Cwwhb 10Ftkeskxwqdl 12Mjcwbharndrbm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Qufc 5Dguwmy 5Gamsbr 11Locpwisufuew 11Cmfubuamqcmw 10Hhewmgwdohn 4Ezbeb 10Gxxwjokoqbh 8Sniauctxw 5Sqthsf 4Tsmcv 10Wpuntblytve 8Cplforzra 11Eiquwipzstgr 7Pjqyjgca 6Unnkdgz 7Cwqnoecd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fkbuh.vawj.ClsXsqsadsvdke.metGrquryhkwyi(context); return;
			case (1): generated.vyac.iqbj.guc.ClsYpwwsvx.metAvhejq(context); return;
			case (2): generated.ghn.esb.odxb.wtax.ClsJgsbwdqv.metPazubjuncrdr(context); return;
			case (3): generated.yfo.dls.qwny.cqaxf.ClsDosmbrrv.metNtnwha(context); return;
			case (4): generated.wwbmr.iqko.nht.ClsCnzakidxmh.metYvzavpzpnbo(context); return;
		}
				{
			int loopIndex24135 = 0;
			for (loopIndex24135 = 0; loopIndex24135 < 6251; loopIndex24135++)
			{
				try
				{
					Integer.parseInt("numXitufjhgcwu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
