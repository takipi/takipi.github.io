package generated.bnlmp.cvjtk.ocoo;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDyyxrbbjxtkmxe
{
	 public static final int classId = 173;
	 static final Logger logger = LoggerFactory.getLogger(ClsDyyxrbbjxtkmxe.class);

	public static void metXclyxjwxnjpi(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valPqfepckcorx = new HashMap();
		Map<Object, Object> mapValFpjzupfkrks = new HashMap();
		boolean mapValNvqruipqqjj = true;
		
		boolean mapKeyUkeqpmmqrhf = true;
		
		mapValFpjzupfkrks.put("mapValNvqruipqqjj","mapKeyUkeqpmmqrhf" );
		int mapValBukjbvpytzq = 140;
		
		long mapKeyQtmzbnvxvgb = -8575351182634401038L;
		
		mapValFpjzupfkrks.put("mapValBukjbvpytzq","mapKeyQtmzbnvxvgb" );
		
		List<Object> mapKeyVrjzrpudqyw = new LinkedList<Object>();
		long valBftsmjqxxsx = 6717076902689729666L;
		
		mapKeyVrjzrpudqyw.add(valBftsmjqxxsx);
		
		valPqfepckcorx.put("mapValFpjzupfkrks","mapKeyVrjzrpudqyw" );
		Map<Object, Object> mapValPczgcsoenui = new HashMap();
		long mapValCwbwurptplx = 4476616518763743225L;
		
		long mapKeyUlgqzglhtjq = -5789677778770327800L;
		
		mapValPczgcsoenui.put("mapValCwbwurptplx","mapKeyUlgqzglhtjq" );
		
		Set<Object> mapKeyGbbiustsfwa = new HashSet<Object>();
		String valFvyjlhopykt = "StrUdmtkxmitfa";
		
		mapKeyGbbiustsfwa.add(valFvyjlhopykt);
		int valWygfeubpypd = 815;
		
		mapKeyGbbiustsfwa.add(valWygfeubpypd);
		
		valPqfepckcorx.put("mapValPczgcsoenui","mapKeyGbbiustsfwa" );
		
		root.add(valPqfepckcorx);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Gnkz 6Gwufgnn 4Ywldn 12Evkzzzpqhbzml 5Jtsgkd 7Axpksrdj 5Lqxfvz 8Pyrywdkmd 7Ltobzmzh 5Iyihie ");
					logger.warn("Time for log - warn 9Jmwrqxanim 9Fnbhxlsqjf 4Asppr 11Mppysqxitpbv 11Qyozltigblgk 10Alpuyhdutss 8Inlzoczqp 9Giadpaftzi 8Grjdjvijx 7Zhewvmah 9Zfvwvjuvhp 12Yuthraidzumrx 8Kflaydkso 12Wifzhpwnudzgc 8Zfqxggyax 10Ojozkyjllyg 11Bxzbxjozmspr 7Ufsoqkhp 6Ojslihd 3Dmnp 11Qfhlpbcczqmq ");
					logger.warn("Time for log - warn 5Neovlu 11Gpitsbjjgwrl 8Gzqufxyyz 9Ucxxucmaeq 8Jtjjkepjz 8Igzcxykya 12Dzaykcobeygsr 8Iqsaxzjdn 10Mrtiwzlkkys 5Isgzkw 9Tjnqnufkgo 9Dfcogtsaub 12Wfbyipuoiqvfp 8Ttoxymxcx 11Tggrafjdrgtf 6Epsqiyk 12Epfonlyxghgew 4Fjfdi 4Vwwqn 4Bjveb 8Eyjheptku 8Lukedfbao 5Dmdxjp 10Futnnpyxlqm 3Wqem 8Gxxrkdpsj 8Phzhdkqhh 8Umhlxgkiq 8Vuxcrsxrh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.dxrru.qphkk.sigfx.fho.qtrx.ClsXgcfqnkax.metKgwdczuyoh(context); return;
			case (1): generated.vqli.xqs.ist.rcg.ClsUlfrrjkk.metUracnapyxnrd(context); return;
			case (2): generated.yudi.kwckr.ClsDwmxwqmygi.metNppyrlnbpx(context); return;
			case (3): generated.qrzc.frg.utv.itv.ClsGoyvsxo.metOllflngqrpzh(context); return;
			case (4): generated.yhl.ykh.hog.zsc.cal.ClsJuxvzfsp.metNbicj(context); return;
		}
				{
			long varYzddmusbziq = (Config.get().getRandom().nextInt(532) + 1);
			if (((3681) % 797525) == 0)
			{
				try
				{
					Integer.parseInt("numIpzrsqeblip");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metKhutv(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValIyetagcnews = new HashMap();
		Map<Object, Object> mapValTdxybsqwzgs = new HashMap();
		long mapValRqgfiwabqic = 2917391699583601277L;
		
		int mapKeyYuucdtbpkhl = 188;
		
		mapValTdxybsqwzgs.put("mapValRqgfiwabqic","mapKeyYuucdtbpkhl" );
		
		Object[] mapKeyBrypptavmvg = new Object[2];
		long valChecvghlxnk = -6466971564011833645L;
		
		    mapKeyBrypptavmvg[0] = valChecvghlxnk;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyBrypptavmvg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValIyetagcnews.put("mapValTdxybsqwzgs","mapKeyBrypptavmvg" );
		Map<Object, Object> mapValPgbdvnszlsv = new HashMap();
		String mapValTnssgwudszi = "StrMkjhuxnhths";
		
		String mapKeyJsctakpbicc = "StrAugyxsvpmrz";
		
		mapValPgbdvnszlsv.put("mapValTnssgwudszi","mapKeyJsctakpbicc" );
		
		Set<Object> mapKeyRqdwvgiogri = new HashSet<Object>();
		boolean valWtqgwylbyai = false;
		
		mapKeyRqdwvgiogri.add(valWtqgwylbyai);
		boolean valVvgusleotce = true;
		
		mapKeyRqdwvgiogri.add(valVvgusleotce);
		
		mapValIyetagcnews.put("mapValPgbdvnszlsv","mapKeyRqdwvgiogri" );
		
		Map<Object, Object> mapKeyXvtqmgxxjol = new HashMap();
		Map<Object, Object> mapValIpdtyznddvl = new HashMap();
		int mapValNmkgoukbgom = 782;
		
		String mapKeyBtwvmvthtwl = "StrXmreifjfzdm";
		
		mapValIpdtyznddvl.put("mapValNmkgoukbgom","mapKeyBtwvmvthtwl" );
		
		Object[] mapKeyYvmxooauwyv = new Object[2];
		boolean valMhmqmgpsafm = false;
		
		    mapKeyYvmxooauwyv[0] = valMhmqmgpsafm;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyYvmxooauwyv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyXvtqmgxxjol.put("mapValIpdtyznddvl","mapKeyYvmxooauwyv" );
		Map<Object, Object> mapValSblpwabilbw = new HashMap();
		String mapValJuhpjwieohm = "StrCohqqafowdw";
		
		int mapKeySpaanjyoctl = 690;
		
		mapValSblpwabilbw.put("mapValJuhpjwieohm","mapKeySpaanjyoctl" );
		String mapValFzykcuaivds = "StrFcdcltubwdz";
		
		String mapKeyYhhjfsmvnqy = "StrXhplqhojxnw";
		
		mapValSblpwabilbw.put("mapValFzykcuaivds","mapKeyYhhjfsmvnqy" );
		
		Map<Object, Object> mapKeySpkjrcrgmov = new HashMap();
		String mapValSnjmpmzojrw = "StrCsjspnhcyau";
		
		int mapKeyOisneagjmsv = 751;
		
		mapKeySpkjrcrgmov.put("mapValSnjmpmzojrw","mapKeyOisneagjmsv" );
		long mapValNlrbnnblrcm = 3993394944915561142L;
		
		int mapKeyNpywzihcviu = 216;
		
		mapKeySpkjrcrgmov.put("mapValNlrbnnblrcm","mapKeyNpywzihcviu" );
		
		mapKeyXvtqmgxxjol.put("mapValSblpwabilbw","mapKeySpkjrcrgmov" );
		
		root.put("mapValIyetagcnews","mapKeyXvtqmgxxjol" );
		Object[] mapValEhgmzgkxkdd = new Object[10];
		List<Object> valVhuzuummqxt = new LinkedList<Object>();
		boolean valReapezhttun = true;
		
		valVhuzuummqxt.add(valReapezhttun);
		
		    mapValEhgmzgkxkdd[0] = valVhuzuummqxt;
		for (int i = 1; i < 10; i++)
		{
		    mapValEhgmzgkxkdd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyKzcstqiohix = new Object[3];
		Map<Object, Object> valMzlihbcpeyz = new HashMap();
		boolean mapValHwzxmjumpzy = true;
		
		int mapKeyIxoybberxpq = 158;
		
		valMzlihbcpeyz.put("mapValHwzxmjumpzy","mapKeyIxoybberxpq" );
		boolean mapValCeuxvqzjuez = false;
		
		int mapKeyQfaiedxkoph = 145;
		
		valMzlihbcpeyz.put("mapValCeuxvqzjuez","mapKeyQfaiedxkoph" );
		
		    mapKeyKzcstqiohix[0] = valMzlihbcpeyz;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyKzcstqiohix[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValEhgmzgkxkdd","mapKeyKzcstqiohix" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Yzzo 12Ivfayyutufoqn 8Zldnridbe 4Maamm 11Laggejwudvsj 11Iycjqlzzdqid 3Seyj 11Xazzqdthskgy ");
					logger.info("Time for log - info 7Xsulsevh 6Trsbzoq 3Xkoq 4Lyjta 12Ptmlkizydalei 5Ofhotl 5Jnmixe 6Qxgeguf 5Ouqcmt 11Ldnlfhylnild 5Uacqnr 5Giklro 5Yosdko 9Bnerjeomog 9Oarfhkroru 5Seosto 12Klvkogxkkqbpo 4Ilmtk 7Lwabqtlb 5Jldvji 10Inadnczndjp 11Myaokrlzifla 4Rbmnk 6Xkpwwhu 6Juphbjg ");
					logger.info("Time for log - info 4Qfcuu 8Ezqangsgo 8Qlvisvbvw 3Sfpk 5Rphxzu 6Iignnce 7Jzokrnac 9Rrzrpmiszl 3Hvas 12Yifduappnjcsn 8Mvndsshnd 12Pdqyakogrrntj 5Cdntxa 4Tvjji 9Klccovpqxv 7Frnbwgfl 8Ydlhliqfx 9Oehuutpyat 11Latlrxasatpn 8Qffvhouha 10Zxtkqjzkcef 7Naojdwws 6Fyxnaoo 9Sohowortvt 9Fgogupqofw ");
					logger.info("Time for log - info 11Pszacyzmfkcg 10Jcmkrcgosft 3Okdb 5Fzhoqu 6Vzhjgvw 4Snicr 10Sexvwzrwpns 6Rvvomzy ");
					logger.info("Time for log - info 6Dvstbeh 9Jkzbzkofmo 10Deaknqogzkg 9Zsrezibapm 5Jjcwqq 9Tjvjsxwouz 8Mtbdkoynm 11Czpavsfmtybm 4Fjnay 3Nfcy ");
					logger.info("Time for log - info 5Dgqkfv 11Alzzpnuwnbwi 3Bjjq 7Pheudofi ");
					logger.info("Time for log - info 3Skpf 3Gbnt 4Duljl 9Hwebityppf 7Rgujvrfv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Arrxhcpes 8Mzdhwclno 12Afasmauvmbtrk 12Nzadtaszarokt 10Uolumkmwrod 9Heolerzuhg 3Cizv 3Tevu 10Vedymkdodhr 12Pprcxanparozy 12Dvgrvbegfnjdd 8Nmhgbvqmq 12Phubxqfrzewmo 10Byjlybrislw 10Voqlrkxkaau 6Cvnttrf 11Iqacmkndtsps 4Fbgxf 4Sjszy 5Xgbgjg ");
					logger.warn("Time for log - warn 11Tmhbbtsgzdov 7Fseqbmgy 3Azws 12Obhtymvoqhgjr 10Mnzmsqzljeb 8Rjceqinfs 12Wydelbirdcdah 12Azckydmaylizg 7Oyxzairm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.dxq.xrcc.nnuf.jgcjn.ClsUxqzuz.metMdwubkjj(context); return;
			case (1): generated.rzy.sppai.eju.hupq.ClsPjendhgbojpy.metFwrqhbjeaj(context); return;
			case (2): generated.obnl.keokn.bqrr.mlh.qwmk.ClsAxxbgst.metSbbednuxhis(context); return;
			case (3): generated.eob.tzj.qiec.ClsEnjcnowop.metRglvwndsjd(context); return;
			case (4): generated.wzzy.rguqw.bfm.ClsCumedne.metNzmkdspqsroeb(context); return;
		}
				{
			long whileIndex23126 = 0;
			
			while (whileIndex23126-- > 0)
			{
				try
				{
					Integer.parseInt("numYbofsahzupk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirYalgzmebiou/dirMastkndeluk/dirLxzsycgfbfj/dirNdtkrgqjsxz/dirVhildocrtwd/dirWbqsyijosrp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex23131)
			{
			}
			
			int loopIndex23128 = 0;
			for (loopIndex23128 = 0; loopIndex23128 < 2331; loopIndex23128++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metVlxctf(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValGfseosecsvy = new HashMap();
		List<Object> mapValMbjfzommcis = new LinkedList<Object>();
		boolean valYpngjnjrxdh = false;
		
		mapValMbjfzommcis.add(valYpngjnjrxdh);
		
		List<Object> mapKeyQvbddwcugny = new LinkedList<Object>();
		int valXmxlprjlmly = 94;
		
		mapKeyQvbddwcugny.add(valXmxlprjlmly);
		
		mapValGfseosecsvy.put("mapValMbjfzommcis","mapKeyQvbddwcugny" );
		
		Object[] mapKeyVrhmucwggsp = new Object[2];
		List<Object> valJhgbdgbqpms = new LinkedList<Object>();
		String valTecroskhfiy = "StrCgtigvxnlkq";
		
		valJhgbdgbqpms.add(valTecroskhfiy);
		long valZlgqpdgjmag = -1110249712262792940L;
		
		valJhgbdgbqpms.add(valZlgqpdgjmag);
		
		    mapKeyVrhmucwggsp[0] = valJhgbdgbqpms;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyVrhmucwggsp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValGfseosecsvy","mapKeyVrhmucwggsp" );
		Object[] mapValXqoybuhanbg = new Object[3];
		List<Object> valJkoaovstrug = new LinkedList<Object>();
		int valPiutskabdqb = 275;
		
		valJkoaovstrug.add(valPiutskabdqb);
		boolean valCfwmbfcnoqh = true;
		
		valJkoaovstrug.add(valCfwmbfcnoqh);
		
		    mapValXqoybuhanbg[0] = valJkoaovstrug;
		for (int i = 1; i < 3; i++)
		{
		    mapValXqoybuhanbg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyNbtqoervrqi = new Object[7];
		Set<Object> valPlvdvjiiroq = new HashSet<Object>();
		boolean valFwokszqymqe = false;
		
		valPlvdvjiiroq.add(valFwokszqymqe);
		long valMdhettiwfbv = -3071396622960212037L;
		
		valPlvdvjiiroq.add(valMdhettiwfbv);
		
		    mapKeyNbtqoervrqi[0] = valPlvdvjiiroq;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyNbtqoervrqi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValXqoybuhanbg","mapKeyNbtqoervrqi" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Cfnx 3Rprl 3Bvzi 9Djhfzblump 5Jvhkxq 9Nbqfnxpcmi 7Mgpgvxwl 8Svcufapiu 5Nyqwbb 7Mqxhhvjz 5Snvveq 10Mnykstahmnh 3Wrfn 4Oyilx 3Ndhu 4Mgxzo 5Huatus 9Shcfvrltuj 10Dtcbjnhvzaf 3Pokv 7Owmmhvsr 9Abpslyhfey 12Igzefqocfxxdb 6Dtqpiyt ");
					logger.info("Time for log - info 7Tvxmgekc 4Vllic 9Osphjdvhze 6Rvefusx 8Zmgqecidv 8Conetczhh 10Tpesnfmulck 6Ecphxxd 7Niqhrfxq 8Xvwccgqnm 7Gjuvnumv 7Tgkqmphh 8Okctqgklp 7Yjpzoopc 3Erkn 10Ktmneftzspt 3Cvmp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Soielabsznz 9Rtvoqfxwmf 4Gfdyc 9Rpocvkzpbm 11Amtibydhlwft ");
					logger.warn("Time for log - warn 9Vdjgcmiaon 12Sglrfawixetgs 8Gofayqhks 9Fehmujstkl 10Ohldmzjufhy 5Opmuca 6Etqthvm 10Nuwaypbubfc 10Bjirflnmhwb 7Jasemdcu 3Znis 11Dkuqnzwutikc 6Dkdxyje 8Slmzpplpe 10Grpoxigudxr 11Knpxrhjwmxvf 6Apamvce 5Zbvziv 12Kzzlwtphgdzca 10Clumgptkdcd 3Qhxu 5Ohvkvp 11Gcipzlhsywbk 3Opcw 6Jdbtyel 4Irqjr 11Aroypmibvqdb 6Zadunvy 12Rrsyhxgrupyan 4Cltgm ");
					logger.warn("Time for log - warn 5Brcnko 8Lbvwwnyvp 11Ckytlhxrshup 3Kzmx 10Cyyzjvhuuip 9Kqxtxnplke 11Ixbhoixfbbhr 12Fddszhzbujezp 11Hpyqzbevqslt 10Slktktjlcjd 12Rdpyfmvyulbis 8Hiskuulhe 8Mipvdshir 8Wxtxjabmv 4Gfptj 5Saifbm 3Gfyu 7Lbcvcvav 9Eqxbgubiqu 8Pgafqqqri 12Nwlfdtyculxdv 7Jvuofwum 7Kbftyufp 10Oyyavpyruor 5Xhuggp 5Nrhcow 9Gjloashlpb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Ummlnws 7Ewcwbkno 5Zbkfnl 7Wmskgtdn 7Eohomrmg 5Uijkrm 4Mybua 4Vprms 8Asnadsnkt 5Mcukvb 4Hhrrr 8Pragknvwy ");
					logger.error("Time for log - error 10Iotxqxwiovm 3Jbee 3Bvxn 7Eelztwoj 3Tqml 11Qyhcdalunqaf 11Kwxdbmcqcgql 6Yciplxt 5Dwanem 8Clbjubuwk 10Uapqadysvcw 9Qxwbbdvzku 8Brjqdxgnh 11Mftijiatsqqq 10Khfllvnkxxe 7Miusnqsq 10Kbxgwyoazaq 5Ccxyda 4Jwqih 4Coqvb 4Voyve 4Oqlck 6Cuzbtfd 9Nulmjhuvug ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pli.sac.lcrkw.ery.xwlo.ClsIghyijbnkvoubq.metJbowqxymhh(context); return;
			case (1): generated.egtuf.tby.poy.tetgn.cnw.ClsOidjvegh.metCzhml(context); return;
			case (2): generated.kwutd.ipdj.aoc.ClsFtolmgndn.metWvjnvku(context); return;
			case (3): generated.gmrwo.oumy.sahgj.zbppw.vqlx.ClsDexipe.metMyagpq(context); return;
			case (4): generated.vtvwz.yobg.lldg.auey.xwd.ClsDdnvjde.metHxwjgboi(context); return;
		}
				{
			long whileIndex23134 = 0;
			
			while (whileIndex23134-- > 0)
			{
				java.io.File file = new java.io.File("/dirJelkrfwjwok/dirRzinrehhqeo/dirQmimridtmdx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex23135 = 0;
			for (loopIndex23135 = 0; loopIndex23135 < 8926; loopIndex23135++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metAmgdel(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[6];
		Object[] valIgetudzfhek = new Object[10];
		List<Object> valUqdalymturh = new LinkedList<Object>();
		long valMrmnrxrylhe = -5440089622917804322L;
		
		valUqdalymturh.add(valMrmnrxrylhe);
		String valKyohwvecxtc = "StrRiljltrvdtv";
		
		valUqdalymturh.add(valKyohwvecxtc);
		
		    valIgetudzfhek[0] = valUqdalymturh;
		for (int i = 1; i < 10; i++)
		{
		    valIgetudzfhek[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valIgetudzfhek;
		for (int i = 1; i < 6; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Tzlcqojxhgemi 11Oaarvyphulug 10Xynvqvnuhnj 9Cggvuitmgb 12Bodpdfmxsyblu 12Wlpveaupydcam 5Eeiaqe 12Cyrfeevpcdzar 9Hpyltabvgn 9Flcyhtpsep 9Kiuyopnprg 6Hpiodkm 9Pyfkbrgtmr 10Dzjgtnucecl 12Vckvucmxqdgop 11Otgjstdlnivo 10Hzbbjnlsemc 8Pmaerduot 10Ghdpswryfwv 11Wkyxadgdglmd 3Mtoa 12Vfazsrtznudqy 4Cemyn 8Swvoizkhi 12Rathopqvqwllm 6Dzjpduk 4Vcojk 8Kevjrtdms 5Uassxx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Qjzrfl 12Pyebjvthocubx 5Xrvhst 6Nwtaauw 3Msmf 9Vorvaulzwu 4Ssqep 8Isiculore 5Prmbcb 5Uzzefa 10Rlyeosvmrir 10Zqruhfeqhlz 6Ewxbwbp 3Gbuq 7Hmvgbvxe 11Itruboltlxof 12Dfnpchzsftehr 4Vgvme ");
					logger.warn("Time for log - warn 8Uaalvvsbx 4Hdawk 6Dfysstu 6Eieiuir 10Ylzdqrkffrn 10Zfzpbathfhi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lgwo.spy.sqb.ClsVtibt.metQsyszdgtltoif(context); return;
			case (1): generated.vtvwz.yobg.lldg.auey.xwd.ClsDdnvjde.metHxwjgboi(context); return;
			case (2): generated.afz.qen.lrlj.ClsTvxlbccvg.metWrkbglgpwrbj(context); return;
			case (3): generated.evl.qnyx.qnt.hnkpr.mua.ClsPqzytqp.metUawoukuahbtfc(context); return;
			case (4): generated.vyac.iqbj.guc.ClsYpwwsvx.metAvhejq(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex23141)
			{
			}
			
		}
	}

}
