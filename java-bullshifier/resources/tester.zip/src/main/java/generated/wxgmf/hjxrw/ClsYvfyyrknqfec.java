package generated.wxgmf.hjxrw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsYvfyyrknqfec
{
	 public static final int classId = 160;
	 static final Logger logger = LoggerFactory.getLogger(ClsYvfyyrknqfec.class);

	public static void metRjzexmwk(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Object[] valUcpstsprdga = new Object[5];
		List<Object> valJsfklvvocmg = new LinkedList<Object>();
		long valFqqcglfrreq = -4205355952147714454L;
		
		valJsfklvvocmg.add(valFqqcglfrreq);
		
		    valUcpstsprdga[0] = valJsfklvvocmg;
		for (int i = 1; i < 5; i++)
		{
		    valUcpstsprdga[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valUcpstsprdga);
		List<Object> valZcmiupiliqz = new LinkedList<Object>();
		Object[] valWgrbvcfenyi = new Object[11];
		boolean valArvjjchxolf = false;
		
		    valWgrbvcfenyi[0] = valArvjjchxolf;
		for (int i = 1; i < 11; i++)
		{
		    valWgrbvcfenyi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZcmiupiliqz.add(valWgrbvcfenyi);
		
		root.add(valZcmiupiliqz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Qknaugmlpx 6Skygjnv 3Ztqs 12Jjvbnojlccbtr 8Shgojerbx 4Yeoxy 7Rznspbss 3Sfpm 4Erlel 8Tlykquyhs 10Ydddhyzslre 10Ybdfllpyhly ");
					logger.info("Time for log - info 12Hwsdtfmiwtkbf 12Jhujsxzpwaqpw 10Vfbskjclxzj 9Gxtvrjsvbg 9Ameuqefrpu 11Ayxghjtoptqd 6Hkvveym 5Wzntvb 5Xbvvmo 11Vynwwsjgrcun 7Myzazqzf 8Sgpycviuu 5Xbuali 6Grletuz ");
					logger.info("Time for log - info 3Zqnp 3Pyjv 12Xbnellpriixie 12Behsxkrpawmsi 7Tgkeydbn 8Hggppfayk 3Vlqu 12Qwgzgnbcftgph 4Rorwo 10Nxytscddlzh 8Sjtctrzgu 7Zaoxbzbn 5Zruojk 9Mcmvbccyee ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Sgjl 7Xdeikfro 8Cjveonoda 3Vrjl 12Alsmnzoykjwct 4Vuuiw 7Rfnlaeux 6Lhelpfi 3Hyuf 4Dzyok 7Uggmdrmf 10Cyentubiodk 10Aanbaxzpojl ");
					logger.warn("Time for log - warn 6Nsqhdte 8Qyveralyj 5Imromb 5Ygknvn 5Bytzwh 9Esnwbxdqhl 12Bwjtrvfrjvduw 7Qhykhiec 4Qbaws 7Fpimksop 11Wsrfgyglwfcy 3Daqw 4Zbyfl 5Ltngie 3Fapy 6Lihtwcw 7Qjutlqjj 7Buwxyhkf 4Lorby 6Uxbmvir 10Avdnaewnfyr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mvh.wsi.ClsXxvtrnameonpg.metGcmnvyet(context); return;
			case (1): generated.ythhn.vxvz.yizb.ClsLckdkkeapmss.metHwwjfniyy(context); return;
			case (2): generated.tmohp.pbwu.gfhxq.zdkm.ijx.ClsDimqu.metSwhvdjgcvud(context); return;
			case (3): generated.rnivz.zhh.uhei.req.ClsPtwayhomjjn.metIvavionsx(context); return;
			case (4): generated.tei.zyt.ClsLkzwcb.metYgqywxliqwprfr(context); return;
		}
				{
			if (((6462) * (2656) % 750169) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((9069) - (Config.get().getRandom().nextInt(401) + 2) % 486277) == 0)
			{
				try
				{
					Integer.parseInt("numPjqinenfbxv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((241) % 613085) == 0)
			{
				try
				{
					Integer.parseInt("numDmrffzadlxd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metWssrrvk(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValDkdrdlfnwwg = new Object[6];
		List<Object> valKdunsbooipn = new LinkedList<Object>();
		String valXqmkhholcsr = "StrFqxxligupva";
		
		valKdunsbooipn.add(valXqmkhholcsr);
		
		    mapValDkdrdlfnwwg[0] = valKdunsbooipn;
		for (int i = 1; i < 6; i++)
		{
		    mapValDkdrdlfnwwg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeySlmdqqdwusc = new Object[2];
		List<Object> valXcgluoehuqu = new LinkedList<Object>();
		boolean valLtxrcriizyx = true;
		
		valXcgluoehuqu.add(valLtxrcriizyx);
		
		    mapKeySlmdqqdwusc[0] = valXcgluoehuqu;
		for (int i = 1; i < 2; i++)
		{
		    mapKeySlmdqqdwusc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValDkdrdlfnwwg","mapKeySlmdqqdwusc" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Pomokqg 4Rmnlr ");
					logger.warn("Time for log - warn 4Zwrbw 10Vftypmkogdi 7Jlljctyt 4Mlnlb 5Sghqrg 12Xiknprqazznco 3Ydxb 12Foqlciogcipgw 10Lrbmauqojos 9Yogweegflg 3Rtai 3Rpyd 10Afjqfndpnms 11Ummmjshiswrn 9Wbwouhkibl 8Wywfxrpah 4Gznjb 9Vgsavfonfl 10Gkpzrfwapoj 8Mxaxnvzzt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Qhmpbh 8Hhgstfbgh 8Yxxxbbmzu 6Srdyume 5Oleybq 12Qazluvydagybk 5Iozvgm 6Bsrovsv 6Wyqsnxr 3Dnto 11Rywutrqlntzt 3Dgxh 4Muovn 12Znffrmiwgkmgl 5Skskmq 4Fdvka 8Zufhmtfqh 8Ibmogbxdd 6Pikyfkj 11Vsqssrfeuryh 8Zijkjwctm 12Qsmvmnmdukbiv 6Mcxmaxl 4Wxfdc 12Jpebqagqkwciw 3Jitf 10Eunewdivpyi 9Esvuziwtxi 8Rbwwuksen 12Tgzzgkfxecffv 3Hofp ");
					logger.error("Time for log - error 8Ffmuzwrij 5Mstdbi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hadv.dozj.puo.ClsVowitvkgtx.metQjsinz(context); return;
			case (1): generated.seews.usvhz.ClsBpkgpi.metKhnlgsy(context); return;
			case (2): generated.jrx.knq.qgl.klpmp.wqhuy.ClsPrfpvgkjefvagy.metFzjcvfpdxrxcop(context); return;
			case (3): generated.livfd.xzg.uuzce.mske.ClsRchbllfcclbcum.metKxxmloahvtx(context); return;
			case (4): generated.eddt.homo.syk.wqll.dyeuq.ClsYzlmjqrjjp.metWfbnvwlbefalsd(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirBinobszvloc/dirEqslsprvuju/dirKgnygdseskg/dirIfaijkskmgp/dirIbuwdepnbrw/dirNomrbkubrpy/dirEwxkzbgbieg/dirOraimtkrjqa/dirFavvbmylblh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metIuqusbvrsb(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[4];
		Map<Object, Object> valXpmepyfrurm = new HashMap();
		Object[] mapValHbfhnuroipl = new Object[3];
		boolean valApqyaqaoltx = true;
		
		    mapValHbfhnuroipl[0] = valApqyaqaoltx;
		for (int i = 1; i < 3; i++)
		{
		    mapValHbfhnuroipl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyEcxvidppnig = new HashSet<Object>();
		int valUhyaufqjbxj = 288;
		
		mapKeyEcxvidppnig.add(valUhyaufqjbxj);
		
		valXpmepyfrurm.put("mapValHbfhnuroipl","mapKeyEcxvidppnig" );
		
		    root[0] = valXpmepyfrurm;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Mxhtzgbda 7Quzdpmod 12Scwlhyscskofj 12Jbpsihpjmxovu 6Yibgvzj 8Csezuehhh 9Skcckrkykh 12Poxmxjnpnfzkp 3Dpzi 8Mcmeyjvfg 11Iqjnkogbqmir 6Jzacwmt 10Qdewkzhrchc 5Gdcvfl 8Sollsbgmo 12Btrbkzyrosbzs 9Syloraqvuy 7Saauifli 4Hlisj 7Ihiqgfxd 10Qvjyhkmjmhu 4Tpeki 9Qyctumqpbo 9Nrsshndgcc 9Ljaoiysjcr 9Fxeeeiclze 9Lqmlxuiena ");
					logger.info("Time for log - info 4Uxwcx 3Wehg ");
					logger.info("Time for log - info 5Vaxpau 4Drluq 8Boyusbjnj 3Fnkp 6Hotodti 4Bgjmz 12Apudttkgbsejk 10Rqxszndkbnk 11Bgqfzktmoqcv 6Enmlhgp 9Xuiuaghdij 11Wvcodcylmgxg 4Tkiqh 5Zcwnyt 12Psailxomuaraa 12Xhzmxhqiexxtd 3Duma 9Xuwucnnefz 12Htimrytomrrtk 6Bhnxifw 11Naidcqitrcfu 9Bpngelusli 6Igzkbhw 12Jlcamslsoqznx 7Lgapzppq 3Ehmv 11Ucfcvqgtqzyp 3Pkyq 8Slhxvtvwm 6Lwayykq ");
					logger.info("Time for log - info 3Difl 6Baaixnq 11Oifjgrlozanz 9Uiqjueijyw 3Rkws 6Vlzlnih 4Clxth 10Clnlspnqvij 7Uvuohrwg 6Uxwgmds 12Gblrvopjlkjwh 4Zjpzx 10Aneyqdfzhlx 9Zeemhozyng 5Wkfewf 8Xsfobcivg 8Ofqntnwlk 5Lmvenq 6Gdomxxr 11Iznjxzkenfcj 7Gmyxffqo 8Ygaighgwr 9Pdajzbkewa ");
					logger.info("Time for log - info 10Gihjwtgwejl 4Dcnsx 11Imguolpvbirs 6Obwxuqn 6Uvqtugq 5Mlzaeg 7Udrvrsxz 9Zhksrazuqa 8Lrquidyxr 9Uzwliyizws 9Klgnopphfr ");
					logger.info("Time for log - info 11Fidrxuitikbw 7Zhomvyps 5Hnqikm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Drnohibyq 8Qhjuuhjbs 7Oyxmiasb 3Kmiu 6Lchcdkl 3Lqfs 10Fdfyzievitd 10Nncuqwplxcz 4Khkaa 5Mwpawq 11Jrcheinlwxhh 9Llywhxbqwn 7Xknaqnqp 5Knhpmt 12Ycgfixocsvevy 11Xkkvqxorbyib 11Pgbfakfareca 8Jqttrgsxg ");
					logger.warn("Time for log - warn 4Wwshj 9Skhxfouszi 3Xyam 3Qjrr 9Juqclapflu 11Wlrvdrjetoyu 3Ewbw 9Mdkgnshepa 3Yjsj 4Sigxi 5Xcrncd 3Qyeh 11Misbqhvjhxyd 12Jheubsmqgaxhg 12Yqoylcpbjrzqr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Iutzd 12Gbfotsbzhdfux 6Kopvgze 9Ocakmtxaem 3Otrb 5Qmrzwq 6Mvdhibs 6Thtqzij 7Ldejlsyf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xam.emsw.ClsNwmpfankaxgqb.metLpglptuq(context); return;
			case (1): generated.kdtwm.lzen.mpr.ClsNfgcbhcbckej.metRvvjmdhdx(context); return;
			case (2): generated.exnrv.npnx.zyxb.ClsLffziac.metKrjqsyrbe(context); return;
			case (3): generated.rludj.zqn.tuc.ClsSdrvvvm.metOhtuehbexx(context); return;
			case (4): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metUooas(context); return;
		}
				{
			long whileIndex22909 = 0;
			
			while (whileIndex22909-- > 0)
			{
				try
				{
					Integer.parseInt("numAwcaqjifbbq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
