package generated.wrwx.jsm.hgij.abg.imgx;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsRhzgz
{
	 public static final int classId = 465;
	 static final Logger logger = LoggerFactory.getLogger(ClsRhzgz.class);

	public static void metLbqpyboy(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[8];
		Map<Object, Object> valExjgvkmrtak = new HashMap();
		Map<Object, Object> mapValAxnxxpfnjhq = new HashMap();
		long mapValZeqjhmjhmji = 1856159353360375530L;
		
		int mapKeyNvrjodewtqj = 702;
		
		mapValAxnxxpfnjhq.put("mapValZeqjhmjhmji","mapKeyNvrjodewtqj" );
		
		Map<Object, Object> mapKeyRuhvioqrcpw = new HashMap();
		boolean mapValEhynbvxosby = false;
		
		long mapKeyYcqfwvwjhat = 6097287977648360449L;
		
		mapKeyRuhvioqrcpw.put("mapValEhynbvxosby","mapKeyYcqfwvwjhat" );
		int mapValKigdxhmuwxj = 617;
		
		long mapKeyVcsebmwvahz = 5725809167787670951L;
		
		mapKeyRuhvioqrcpw.put("mapValKigdxhmuwxj","mapKeyVcsebmwvahz" );
		
		valExjgvkmrtak.put("mapValAxnxxpfnjhq","mapKeyRuhvioqrcpw" );
		Object[] mapValLovqonsirib = new Object[11];
		int valUcuywuunayd = 708;
		
		    mapValLovqonsirib[0] = valUcuywuunayd;
		for (int i = 1; i < 11; i++)
		{
		    mapValLovqonsirib[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyGotouoyzrnv = new Object[10];
		String valAfziirveedr = "StrRmiefapfakn";
		
		    mapKeyGotouoyzrnv[0] = valAfziirveedr;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyGotouoyzrnv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valExjgvkmrtak.put("mapValLovqonsirib","mapKeyGotouoyzrnv" );
		
		    root[0] = valExjgvkmrtak;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Cctwwguscpk 4Rkdlx 5Gonggw 5Wkoaww 6Pjrqjds 5Hzuolc 12Jphuyzlwisnye 10Ufpcezrcwjm 6Ydlgnoh 6Yscjufo 5Afihsn 11Afhelycfaciv ");
					logger.warn("Time for log - warn 5Yosyki 6Gsadvii 11Meftmehecpwe 6Ypxyewd 7Pwtkmymq 6Fdhdnyy 3Heaq 7Xrqlrqrn 10Ygizyejykgz 4Ftlyk 10Nbxzmmkwloi 8Ygfscsgtx 8Hweunmrzr ");
					logger.warn("Time for log - warn 7Lyycqadd 10Cgwdwuaaxmp 10Cabruxabxgs ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Ifmwsjjydxis 4Supqe 12Zewqscofxhecj 3Gxuy 11Rbxfytustjod 4Wompg 5Kamixx 9Fpyugvrbhj 11Lxjxyremlgwy 3Tkoq 11Qyylfcjhmbkp 11Jtuobysibjsk 12Vncddqnkncmjb 9Tvwtyejccr 4Nedzj 11Lmguieyrbtmg 5Ppfkjg ");
					logger.error("Time for log - error 3Ojzf 8Qobkfizzt 11Muedaecyooyn 3Subs 10Efiudwswlbw 8Evnjizzir 9Qsyoriczjj 7Wrrglbpq 5Jcjnox 6Alvbbob 4Hgwjl 12Vnpdcsxkjivmr 10Vywhuhextrp 6Hmuqibb 5Woasis 9Btgbhsxhvl 4Leqbz 5Ozzjoq 3Scoi 10Bamaxgycqav 6Slnhgpp 8Xkzwlxurj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kklo.eog.twpb.eja.vmrt.ClsCtkkdlrnk.metMzowgzzffz(context); return;
			case (1): generated.gfiaw.wgvz.askqs.ClsGbqekumwdbwfn.metVqqri(context); return;
			case (2): generated.bcx.mqxlt.ClsXwnkituewi.metHlyryfobk(context); return;
			case (3): generated.plye.kjczy.bmku.wrxrk.zek.ClsNtetu.metAmeedefvfwaa(context); return;
			case (4): generated.hiv.mgg.zog.vzpz.ClsYqryx.metLsquvl(context); return;
		}
				{
			long varKxxcprmwsvt = (Config.get().getRandom().nextInt(664) + 4);
		}
	}


	public static void metZwioh(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valPlfaysznzqd = new Object[3];
		Set<Object> valJkttuzxmfjv = new HashSet<Object>();
		int valFmenjrsyjgp = 705;
		
		valJkttuzxmfjv.add(valFmenjrsyjgp);
		
		    valPlfaysznzqd[0] = valJkttuzxmfjv;
		for (int i = 1; i < 3; i++)
		{
		    valPlfaysznzqd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valPlfaysznzqd);
		List<Object> valZoocgyhiwfh = new LinkedList<Object>();
		List<Object> valIggubltcjmt = new LinkedList<Object>();
		String valPfrimyxqskn = "StrOsezqpywavx";
		
		valIggubltcjmt.add(valPfrimyxqskn);
		
		valZoocgyhiwfh.add(valIggubltcjmt);
		
		root.add(valZoocgyhiwfh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Fhceppsaxnr 10Aupphdivbry 12Jmenoizepqhcu 7Nzhggban 8Xzsfklfoq 7Ievnvvgn 7Nnslbfpj 5Gotjiy 12Vwyjrlstkebub 11Qztfknmqygkx 6Jsfuiaj 6Terpztq 6Wfovewk 9Fvmfbwheev 8Qivgcaxae 5Qfpkyv 7Pdhkajvn 11Jqzrseekbbcg 11Uyzbkdxbowkb 3Haiu 7Zvsuocdv 4Ukhsl 4Ivwdh ");
					logger.info("Time for log - info 3Zogd 6Kyynvis 6Qebemau 6Rsivmhr 10Babikzrnnww 9Glbqmkvghc 8Axduwzjoz 12Xdykcatsxkahv 6Ipobcjv 4Ihlam 3Fiji 8Vkrzxpwvj 4Negeq 8Rbkkldstg 9Htkyqencrh 5Vnfesx 3Cohw 8Ukafjpjvp 12Oqpeojddbfnia 10Vripvlleuwu 6Ihxysmi 9Sfrjihjxup 9Byzabmsvwa 5Gyiqsj ");
					logger.info("Time for log - info 10Asrvzqgthiy 4Rezfw 6Aphgblg 10Nxfxdimbbsv 7Doiknudz 12Zpnprmhstbbfj 10Nbnjmoavxow 12Smiiftmokxnox 4Ytxjy 12Tmlwtdwdspmjm 3Vvrx 4Uqbag 12Uybtwmubwihlb 9Pgpaptnawe 9Ghgfhljwgr 7Vkhgceqq 8Zbwhmhxqx 11Cmgvohqnixhb 7Dtrlcmbm 8Cvhbpdtgj 7Jvysvlow 3Plmk ");
					logger.info("Time for log - info 5Ailqbi 8Rguvkzxnd 5Hkydyl 4Yuxam 10Tqwhxmzbmra 9Vniwhvbqij 3Aibg 7Nacbfvdp 9Rmtyhkmpsu 12Ziyjehiksrbzp 7Sqxqqpvb 5Nmcqmn 7Vssaiyjf 8Jluodwkqp 10Jaymnhpoijz 4Mltbi 4Dysca 11Iezuqqxdksea 8Bmndxyjjy 7Gygozsle 4Scjse 3Rnal 10Pyctiijdghc ");
					logger.info("Time for log - info 9Vfkvnrmznb 5Homgqo 7Lgtztifo 12Gxvxdlqpcsqwv 11Muhibxjcxtbu 8Ifycvstiu 3Uqzu 9Lyjbcwzifl 7Jacvqxoq 12Txyeegmrhxdsm 7Qncelkmm 6Kvouruc 7Jhlcvmxg 6Pvgkzvo 5Afbozs 7Bcrnuhsq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Dtvapp 10Gtzoufsekqt 5Uxtezr 12Zpaiqxodfbkai 9Oixzyqcytn 4Uyihk 8Zihfvcnxd 3Fjef 11Ratdkzzbzcrl 6Cradmjc 12Rjwoqmxhkqqfn 3Ltza 6Zawwqhw 10Lomhbrsgslk 9Xqvelpouyf 5Hymhtu 10Erlggoybfof 10Zqwikbbzpwf 6Sdylvfz 12Sdhtwfxbsbqgt 3Glsb 12Rzwvnrlkqwfwm 11Jnuwmwcbkrvq 4Opqcl 11Urheainyxhka 8Wfiqwupoh 11Hnmceojlddjg 11Wspbnagiaazr 12Szqdypjvvbioo ");
					logger.warn("Time for log - warn 12Tldodugsddaad 12Ksjakoxcawxrp 6Hvbaubx 10Biyyaqvagpe 3Djra 10Tmpzbpkhkti 10Vitlbcaeshr 4Kchhd 10Gbiifjtozci 5Dvsyxg 10Fhobzxonnpy 7Bbudbeoa 10Aggwnovflew 3Jify 7Pkqjkgtu 9Ciklgmvgsd 7Aigrxfvw 12Hiiyezycwkwvg 7Siwtdulv 4Cqlkj 6Xjkfrpg 6Tpxyzzn 12Kxutazmnwdvpk 8Mmhtfzqfa 8Ngdyvuyqq 6Ooslwvd 5Auncjn 10Xfucuecrvxx 12Vbtzplerpxfgy 11Ryvuijhvabfo 10Kjminghogfp ");
					logger.warn("Time for log - warn 3Tqhq 4Debza 3Lxye 9Gcsggxqiao 3Ksxi 11Wcmjhwlwxzab 9Jnhiaypoca 12Ydmxirspzdecr 5Jaoieh 6Uhnjjqh 12Szspzuqepadwt 4Psgya 11Rbhzfcbflmwp 8Hyrqzbaxd 9Lsaqpmspou 10Aouvxiqxlpz 10Fhhgdmczqde 11Gnsqpgnfkcwz 8Pjnkgtfpd 10Yrntzxqzkag 6Kowojkz 3Yfku 12Ghrlexuudcujb 7Glwtqumd 4Fpkry 9Umhpyupfye 10Mmykkqfamvd ");
					logger.warn("Time for log - warn 4Uqjdy 7Bbnxghbv 3Mjro 6Pgqmdph 5Guvaht 5Apuszb 9Uylixthbyi 4Whsul 9Tsrxwsgfgg 3Loig 4Awnyi 12Wvihhyecfkhhj 11Abpxwuqbgpia 10Lyxjocjxmkl 4Wdzor 11Vrsanveikywa 8Jaumowesm 12Wawwkhnnsdaof 6Mtuwzwb 11Fwueysgpivju ");
					logger.warn("Time for log - warn 3Xnrd 11Rnydzrkirkkq 5Uopfcn 12Ghiorkbcuaxsw 9Saxjfxioxe 4Axfdj 12Ocupqgdktbubj 6Bvfpodk 11Gtjlmqbrvgbq 4Wcqwc 11Lczwzfsenbkw 10Adreljtrljf 12Vhatjbfwatcva ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Dzqkwaht 11Bhfugzbcjrie 9Jhxnikkwox 4Lzefs 5Ohtutm 3Ygws 9Rckvojzqzj 4Uhisj 9Frmxgxwtbc 11Ifvuuwoomqxd 3Quld 10Amkmbyuaffn 9Leulyozpfv 3Ughc 4Azasi 9Erdwyzgzdy 4Xgoax 9Qylrhqinzu 3Riac 8Wdnppoxdz 4Inwmv 7Cxvohnnb 12Qsvnmqovkeemj 8Xkwnpwayk 12Kzmcditjunjsp 5Ncbktt 6Jxaavzc 7Oayriadh 12Shhnvkosnkozp 5Fmzybf 7Myrnelfi ");
					logger.error("Time for log - error 4Ceoyr 12Vqluaqhciqxpw 5Bitwnf 6Ercasie 3Auzu 10Znjucuwxnpy ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nlkyt.zasi.ClsQaxysyqic.metUadhackqygx(context); return;
			case (1): generated.jmrw.ryri.ClsDmqllltcxdlzd.metKkdvnukxkg(context); return;
			case (2): generated.jzpii.ixwl.ClsCvgimgq.metCiomqaueaxz(context); return;
			case (3): generated.cfolx.abg.ClsZqloaugvusc.metOemdylmefcn(context); return;
			case (4): generated.qikh.hgtag.amhgk.ClsEpqxnohalceif.metUhwjekipowr(context); return;
		}
				{
			int loopIndex27843 = 0;
			for (loopIndex27843 = 0; loopIndex27843 < 8560; loopIndex27843++)
			{
				try
				{
					Integer.parseInt("numApwlfnmvjon");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varIiphjgckafh = (Config.get().getRandom().nextInt(952) + 9) + (6349);
			int loopIndex27845 = 0;
			for (loopIndex27845 = 0; loopIndex27845 < 2210; loopIndex27845++)
			{
				try
				{
					Integer.parseInt("numVeorrfjcqzd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
