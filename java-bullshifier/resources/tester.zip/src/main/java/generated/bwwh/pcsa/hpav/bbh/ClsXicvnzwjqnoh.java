package generated.bwwh.pcsa.hpav.bbh;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsXicvnzwjqnoh
{
	 public static final int classId = 455;
	 static final Logger logger = LoggerFactory.getLogger(ClsXicvnzwjqnoh.class);

	public static void metTwqbt(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValNgyefhllhzh = new HashMap();
		Object[] mapValMroonekpdth = new Object[9];
		int valAeemtrgajmu = 61;
		
		    mapValMroonekpdth[0] = valAeemtrgajmu;
		for (int i = 1; i < 9; i++)
		{
		    mapValMroonekpdth[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyPsctxijujra = new Object[8];
		int valZysprwemwkp = 14;
		
		    mapKeyPsctxijujra[0] = valZysprwemwkp;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyPsctxijujra[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValNgyefhllhzh.put("mapValMroonekpdth","mapKeyPsctxijujra" );
		
		Set<Object> mapKeyWzpzavicdhc = new HashSet<Object>();
		List<Object> valHkzjbvvkntr = new LinkedList<Object>();
		int valYuukbdyzluv = 541;
		
		valHkzjbvvkntr.add(valYuukbdyzluv);
		
		mapKeyWzpzavicdhc.add(valHkzjbvvkntr);
		List<Object> valLpjmfapcxhr = new LinkedList<Object>();
		int valQxjkohwuqmg = 667;
		
		valLpjmfapcxhr.add(valQxjkohwuqmg);
		long valBrrwziixtld = -1328488809052738484L;
		
		valLpjmfapcxhr.add(valBrrwziixtld);
		
		mapKeyWzpzavicdhc.add(valLpjmfapcxhr);
		
		root.put("mapValNgyefhllhzh","mapKeyWzpzavicdhc" );
		Set<Object> mapValFrlanffqkgo = new HashSet<Object>();
		Set<Object> valAmhdrbhoxhd = new HashSet<Object>();
		String valGlxoifqhhhr = "StrIsqfmneeysm";
		
		valAmhdrbhoxhd.add(valGlxoifqhhhr);
		boolean valFisaokdydmf = false;
		
		valAmhdrbhoxhd.add(valFisaokdydmf);
		
		mapValFrlanffqkgo.add(valAmhdrbhoxhd);
		List<Object> valRmwsapiaakg = new LinkedList<Object>();
		String valZfajycejsfn = "StrWhugsgvayhk";
		
		valRmwsapiaakg.add(valZfajycejsfn);
		
		mapValFrlanffqkgo.add(valRmwsapiaakg);
		
		Map<Object, Object> mapKeyWlvtsjbnvyb = new HashMap();
		List<Object> mapValKoftfvwwgfa = new LinkedList<Object>();
		boolean valEfigelzmmtw = false;
		
		mapValKoftfvwwgfa.add(valEfigelzmmtw);
		int valWbkkbbyuxzg = 593;
		
		mapValKoftfvwwgfa.add(valWbkkbbyuxzg);
		
		List<Object> mapKeyPczhsjtkzys = new LinkedList<Object>();
		boolean valGlvenxztkci = false;
		
		mapKeyPczhsjtkzys.add(valGlvenxztkci);
		int valReivyxpvssw = 277;
		
		mapKeyPczhsjtkzys.add(valReivyxpvssw);
		
		mapKeyWlvtsjbnvyb.put("mapValKoftfvwwgfa","mapKeyPczhsjtkzys" );
		List<Object> mapValIzxeecfyeoh = new LinkedList<Object>();
		boolean valHybedaeotaa = false;
		
		mapValIzxeecfyeoh.add(valHybedaeotaa);
		
		Object[] mapKeyFwvqqtrscxi = new Object[8];
		String valUxzzgeoprky = "StrSpeixkhhflz";
		
		    mapKeyFwvqqtrscxi[0] = valUxzzgeoprky;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyFwvqqtrscxi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyWlvtsjbnvyb.put("mapValIzxeecfyeoh","mapKeyFwvqqtrscxi" );
		
		root.put("mapValFrlanffqkgo","mapKeyWlvtsjbnvyb" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Hdgnrusk 3Bsrx 4Egwal 6Adqizfu 8Gobbupuji 9Zvcgwdvgdc 4Ywqxl 9Ouefxndsez 6Frdzuvg ");
					logger.info("Time for log - info 9Ydveyjspos 5Pbsewf 12Elbxyraqojiry 3Imbz 8Napkgrwmw 11Dybtpnnxbzum 3Jxhc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Vwnla 9Tluomaxtgt 3Fxnc 7Zobhuejt 4Akobf 5Ntuxkr 6Mnodkxl 7Vkrqinco 12Npojkgnixftdg 12Dlrazinsdcdor 6Uirixlg 8Osswcpdty 6Qcitqoq 8Ermlzdlcb 7Znrtebea 8Ohbpjkzjd 3Fotf 9Enlvkucdao 5Wsojhm ");
					logger.warn("Time for log - warn 9Dlbmsmnbjh 3Louk 9Crplekplil 6Gqyaoum 11Lpajfoghcqyt 9Tpkujolnqq 9Dqaqeazvch 7Ohbphuzt 11Padxclvdecae 4Dahsn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Fsybcbffbkij 4Xfrzr 11Tkxkmqjtitee 5Snkcgw 9Iciyjvervh 11Ufkwhfftynpv 12Nbrairexuhwoz 11Cigazaamigtv 3Sikp 7Awardbbz 6Izqaulv 12Umexyhsfgaqhs 8Wnndcinpo 7Oszhaeqb 12Otkxprfqkdast 6Nadmxod 7Letbknqa 3Aofh 9Tfehleuzni 4Roelo 11Pgydtepcjdcr 6Gdaeijr 7Bpgyejnt 3Dpzx 4Vfpoa ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zmpxh.humct.jpc.zcr.uswj.ClsMmunby.metPsfhf(context); return;
			case (1): generated.aqdnu.puvg.gdad.ClsIxzvdsuksw.metUndfk(context); return;
			case (2): generated.lnvho.rhfct.ClsGgdasahuvsgcd.metEhvvpiwjzqivv(context); return;
			case (3): generated.lmq.wwll.mcjoz.ClsBqjxdpu.metLzmwjdeakzh(context); return;
			case (4): generated.exhp.ngeqz.saycv.ClsTbfjaj.metOqtzak(context); return;
		}
				{
			long varQdtayttdmxa = (701) - (5304);
		}
	}


	public static void metQfgugo(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valOfnwliryrrb = new LinkedList<Object>();
		List<Object> valTgcxrmmeher = new LinkedList<Object>();
		String valSrinehvcwpo = "StrQkkanqapmzh";
		
		valTgcxrmmeher.add(valSrinehvcwpo);
		
		valOfnwliryrrb.add(valTgcxrmmeher);
		Map<Object, Object> valKpwawkjsgjw = new HashMap();
		boolean mapValColxmhdsczn = true;
		
		int mapKeyJesvdwualks = 646;
		
		valKpwawkjsgjw.put("mapValColxmhdsczn","mapKeyJesvdwualks" );
		int mapValAjikglvnoxf = 575;
		
		String mapKeyWtqcxfqlkyn = "StrUkyrfjfpeqn";
		
		valKpwawkjsgjw.put("mapValAjikglvnoxf","mapKeyWtqcxfqlkyn" );
		
		valOfnwliryrrb.add(valKpwawkjsgjw);
		
		root.add(valOfnwliryrrb);
		Set<Object> valUfycgsqxhaa = new HashSet<Object>();
		Set<Object> valSvabcqzyfzt = new HashSet<Object>();
		String valUyqeidagsvh = "StrIgtxvgtdnnp";
		
		valSvabcqzyfzt.add(valUyqeidagsvh);
		int valUpjqhgsvlwe = 153;
		
		valSvabcqzyfzt.add(valUpjqhgsvlwe);
		
		valUfycgsqxhaa.add(valSvabcqzyfzt);
		
		root.add(valUfycgsqxhaa);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Xemivv 10Hskcethofis 10Lobsuxbqimg 3Meaq 3Qvrk 5Kziksh 4Enheo 12Gudyfbnrpvynx 8Kzphuarnm 10Fgendtmpsmp 6Jmpjzjs 10Zkgeknwgunu 8Bgmephzkx 5Ijmcmj 8Gntlffpae 3Jkls 12Kqirfujwcdlda 5Wrmmaj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Odntmwp 3Navu 10Fqcgtsdlaxl 10Oytmfxueymy 11Lkovfjpfvjtg 3Sjzf 6Hgauujs 12Ntndsbztkfehp 4Bnvva ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Ayai 5Olsjbt 4Wrfql 8Ocawxiyxs 4Xexyf 3Aqgr 7Rputsnsm 10Spzqxotrcpu 3Pkqs ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.psl.vgj.rgm.ikl.ClsWqomoi.metLwbkg(context); return;
			case (1): generated.pema.ddj.ssuh.ClsIlinaijnkxxo.metCsqjaayw(context); return;
			case (2): generated.lkd.eckd.hdtbd.unse.scvn.ClsCjccpmy.metBnujb(context); return;
			case (3): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metCxqaycr(context); return;
			case (4): generated.fur.dagce.oeqx.ClsTsqthfwvzszch.metJmxhhbj(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex27653)
			{
			}
			
			int loopIndex27650 = 0;
			for (loopIndex27650 = 0; loopIndex27650 < 6189; loopIndex27650++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varOqgmzuhjfhu = (2527) + (9541);
		}
	}


	public static void metNnybhkcr(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValIdbwgnkznfx = new HashMap();
		Map<Object, Object> mapValAfegcpxykyx = new HashMap();
		String mapValCfdzubjthfr = "StrNzusatsezwc";
		
		boolean mapKeyJlaotqriqvp = false;
		
		mapValAfegcpxykyx.put("mapValCfdzubjthfr","mapKeyJlaotqriqvp" );
		int mapValDnflyacdajj = 747;
		
		long mapKeyLajybznxegg = -6122753160385757720L;
		
		mapValAfegcpxykyx.put("mapValDnflyacdajj","mapKeyLajybznxegg" );
		
		List<Object> mapKeyEramqrbszao = new LinkedList<Object>();
		boolean valEbmbjkvyzuq = false;
		
		mapKeyEramqrbszao.add(valEbmbjkvyzuq);
		
		mapValIdbwgnkznfx.put("mapValAfegcpxykyx","mapKeyEramqrbszao" );
		Object[] mapValXeqtcudojev = new Object[9];
		int valFzvbxyiuoxd = 565;
		
		    mapValXeqtcudojev[0] = valFzvbxyiuoxd;
		for (int i = 1; i < 9; i++)
		{
		    mapValXeqtcudojev[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyNvxqlbcgwck = new HashSet<Object>();
		int valQktpniicrqk = 121;
		
		mapKeyNvxqlbcgwck.add(valQktpniicrqk);
		int valSrybxbgvxht = 155;
		
		mapKeyNvxqlbcgwck.add(valSrybxbgvxht);
		
		mapValIdbwgnkznfx.put("mapValXeqtcudojev","mapKeyNvxqlbcgwck" );
		
		Set<Object> mapKeyThonpfnhpsb = new HashSet<Object>();
		Set<Object> valBajkdstwjxb = new HashSet<Object>();
		long valSwegsilxpct = 3591393878803739214L;
		
		valBajkdstwjxb.add(valSwegsilxpct);
		int valAfopwsvynqv = 800;
		
		valBajkdstwjxb.add(valAfopwsvynqv);
		
		mapKeyThonpfnhpsb.add(valBajkdstwjxb);
		
		root.put("mapValIdbwgnkznfx","mapKeyThonpfnhpsb" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Ystk 12Cucmjeghxdgxc 4Mskoz 3Gcis 9Crzkkeycuu 8Mtarbufga 5Opprlm 10Knbmrdffomo 7Ghehxxam 3Zsfc 12Sbzcgiiuldypu 8Zfzoaczrd 10Ejnhxvkgjfp 6Xjifvgb 6Smsdzdc 10Xyxqdaaidig 10Qkmmwwpydgb 10Wotblpfybtn 6Islpfmd 6Rvkhhcw 10Emaovyxzelx 11Yuensycowvzv 11Ptdqlinxlwps ");
					logger.info("Time for log - info 10Llvlgwsmrgn 6Mxlrubh 7Yquaewbo 8Lbwpywblp 11Wizydwybjlhc ");
					logger.info("Time for log - info 9Gvcujbqrmn 11Trnpwrudvzzt 7Tozhytkp 10Jerbolsjzpv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Ebnlxfebe 8Xmhqbdkmx 5Bmilvg 10Hkazutobyqh 4Jcwma 9Oauyhcvfcq 5Hgwsft 4Rvzul 5Bceeuw 9Jniugsbxpe 7Oekkzqho 5Igknwu 10Gecmrsmvbln 11Yvquxtxupthi 12Mkczpvrtievnj 10Vvdoutzuado 9Qhrcvgfkhc 10Wsdzugxqfsc 6Rumyjga 5Lycvaf 8Qbnuxbcrf 10Fbedzckobhu 11Wlsowprifotb 6Ulpspve 8Snaucxeqb 12Xpqouomecxiuc ");
					logger.warn("Time for log - warn 4Qmghl 10Bvldfnqdzau 4Axcaa 9Kllabjhiem 6Urjzixv 4Ebkom 7Gaxqufyd 7Kwgsvanp 11Nxcxegynjzmj 12Apamcsgqxezgg 12Pstluajpomkma 10Mfpqambhxih 4Ryjvm 4Tdyog 5Jqriul 5Mqhrjw 12Uzucdybmggukq 8Ifkamabcd 3Mbsw 12Taftcxglhbuzl 12Oecaqmlrejozq 9Cdhrqrxkev 8Ceuqpgdvu 8Zdgwoilqo 3Icmb 9Jmcdxhnbed 11Atzipgkmmqmj 5Faeixc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Siuzeragzms 8Uyhqmuyzc 3Xuqy 3Lhoy 11Ckmnxrovgpxw 7Sgssmwbw 11Lbcmafyeaiay 12Gfsrxtfthwgvi 4Hduhu 7Ltwtqjzz 5Zqzlcn 5Ccodyj 8Kunwceupd 11Yaajapnktxcy 4Ptqzo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yfo.dls.qwny.cqaxf.ClsDosmbrrv.metZhoqh(context); return;
			case (1): generated.zeo.tykl.bkniu.uhs.uwxh.ClsUegpnzqhmar.metNitnfqpe(context); return;
			case (2): generated.gucbl.hxhv.qux.siytf.ClsVpdrty.metBpjjua(context); return;
			case (3): generated.qivmb.wlyy.vhwlw.ClsJhewvjqlcuh.metAouqfagpakd(context); return;
			case (4): generated.zadtu.owlhb.qsd.bfzb.ClsWgiwrqnvyw.metBigqrgygmlibp(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numXriwrrkacvu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numCxednfewbbl");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex27657 = 0;
			
			while (whileIndex27657-- > 0)
			{
				try
				{
					Integer.parseInt("numPeqtvqzammp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((Config.get().getRandom().nextInt(213) + 0) - (whileIndex27657) % 349586) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metXmvss(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valVgvrfzjairs = new HashSet<Object>();
		Map<Object, Object> valDfdqljgxxjs = new HashMap();
		String mapValCclvdppohrg = "StrXrmpkpumcqu";
		
		boolean mapKeyEcnjccwxgti = false;
		
		valDfdqljgxxjs.put("mapValCclvdppohrg","mapKeyEcnjccwxgti" );
		int mapValUiyhpiabuvk = 356;
		
		String mapKeyJfvrafnfslm = "StrFerjxmzdupk";
		
		valDfdqljgxxjs.put("mapValUiyhpiabuvk","mapKeyJfvrafnfslm" );
		
		valVgvrfzjairs.add(valDfdqljgxxjs);
		Object[] valVwqtggqtvyr = new Object[7];
		int valLwyacmagylv = 302;
		
		    valVwqtggqtvyr[0] = valLwyacmagylv;
		for (int i = 1; i < 7; i++)
		{
		    valVwqtggqtvyr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valVgvrfzjairs.add(valVwqtggqtvyr);
		
		root.add(valVgvrfzjairs);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Ijlghdctxk 10Bhyumlansit 11Rqzplaavejez 5Zfgtpa 5Tmiffo 12Aemarbmtxvdyz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Sjfuavmpt 10Zsehogilbpb 6Xsjcbum ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Odtn 10Idggrfgxrup 11Torukatyfupq 3Cxkt 6Mgvrnpu ");
					logger.error("Time for log - error 12Wbznistwkyopd 7Mxbwtlvg 3Fsfu 8Pmpgocxqy 11Apwqudrdyajs 7Shzejafs 10Gzhaquzjkci 3Dzdm 4Raoch 11Jskmkxknpbcd 12Dlszkhufsetjh 12Mqlihscydggen 8Bjiieiuvq 8Dmsuabten 10Reaeztlmmfi 3Wkxf 12Bsfvfaovisqis 11Fdsdhawkxzhu ");
					logger.error("Time for log - error 9Hpdxairdzw 4Txuru 11Stfjobhpdwzq 9Nbgnfilmwz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.crkmz.uuny.smq.vvmxn.khxb.ClsQbvzuhroxdituh.metJqalviosof(context); return;
			case (1): generated.ndkx.exo.qju.brvd.ClsMxlcse.metFbamruj(context); return;
			case (2): generated.rayp.ekfg.uust.ClsQhtttdalkvmcth.metYhiqkxerxikn(context); return;
			case (3): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metWpheeqsxvjk(context); return;
			case (4): generated.yewpq.dap.itdt.ClsOhnihvc.metVezpyfhkrdq(context); return;
		}
				{
			int loopIndex27665 = 0;
			for (loopIndex27665 = 0; loopIndex27665 < 8474; loopIndex27665++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metNzoosciaibwmu(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valLazqumbkozc = new HashMap();
		Set<Object> mapValKlnhpgxbjhj = new HashSet<Object>();
		long valZsqudcufype = 9199605644544696268L;
		
		mapValKlnhpgxbjhj.add(valZsqudcufype);
		String valWxksroofwpd = "StrDtdtqyfsmbz";
		
		mapValKlnhpgxbjhj.add(valWxksroofwpd);
		
		List<Object> mapKeyWflfugvwkey = new LinkedList<Object>();
		long valDoctzanxhqj = -6622031046705093202L;
		
		mapKeyWflfugvwkey.add(valDoctzanxhqj);
		boolean valXtobmaoltnp = false;
		
		mapKeyWflfugvwkey.add(valXtobmaoltnp);
		
		valLazqumbkozc.put("mapValKlnhpgxbjhj","mapKeyWflfugvwkey" );
		List<Object> mapValUkpykmkutcx = new LinkedList<Object>();
		long valNnsyjcrlbhi = 4471681001841771386L;
		
		mapValUkpykmkutcx.add(valNnsyjcrlbhi);
		long valTzevrnppwco = 326549618438719510L;
		
		mapValUkpykmkutcx.add(valTzevrnppwco);
		
		Set<Object> mapKeyVlunwclhfgh = new HashSet<Object>();
		String valShrqshzvopg = "StrVvermxhvjtd";
		
		mapKeyVlunwclhfgh.add(valShrqshzvopg);
		
		valLazqumbkozc.put("mapValUkpykmkutcx","mapKeyVlunwclhfgh" );
		
		root.add(valLazqumbkozc);
		Map<Object, Object> valZyvpnmebgvu = new HashMap();
		Object[] mapValTgesolhqsfn = new Object[2];
		long valVtdjeqzcuzq = -8448512753519071752L;
		
		    mapValTgesolhqsfn[0] = valVtdjeqzcuzq;
		for (int i = 1; i < 2; i++)
		{
		    mapValTgesolhqsfn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyNzykrehfdcl = new HashSet<Object>();
		String valErrptrevwww = "StrPzegmjckwbz";
		
		mapKeyNzykrehfdcl.add(valErrptrevwww);
		
		valZyvpnmebgvu.put("mapValTgesolhqsfn","mapKeyNzykrehfdcl" );
		
		root.add(valZyvpnmebgvu);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Azkbfnqtzfk 6Kzcjqja 12Hxsbclynqaxen 4Yudxj 6Jcvpqyu 9Ksqkvdvock 12Xjqtpjptkbhpp 5Ydehby 8Cslsqazpt 4Hbsdc 11Ixljyacamayx ");
					logger.info("Time for log - info 3Fdxz 7Bizopemk 6Vzkrafg 7Hvzqotju 11Buftnvmswrdd 10Kemljtavzud 7Gyssoxyf 12Sbtsodjvoeegf ");
					logger.info("Time for log - info 5Jjyruq 11Cwdevnxzmxrq 4Kbicm 10Cnhyowaeynq 4Lzvbx 4Izulz 9Cretrgftjp 7Fkehzjxj 3Chwc 9Bvidmqiffs 9Ldrmahfnhz 5Ydkoyr 7Psxksgek 9Lrxvdmnffa 5Pdcpoj 9Zgsbscxwtz 11Zxwiguaeyvao ");
					logger.info("Time for log - info 5Zhfrsu 10Rixioidhgkv 8Mrcchnyjc 8Lnzeubdsv 10Dzoqtmkkxcf 7Jsoaryse 3Fmru 10Axnokovyzuc 6Dncrokj 6Yopsndg 3Kypn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Loybasfol 7Mtqinvnx 4Tvqol 3Ehye 7Gdslthoh 5Voaoeg 6Uzgfjah 10Dtgzbmuuwgk 7Gljtckzz 11Jhlqinybtvbr 10Xcfsrncsmbi 3Psyr 7Fubuiyzd 6Ouobrgc 7Uthxbmux ");
					logger.error("Time for log - error 11Biqpuktqemkb 5Hxqfsi 7Crqmmvmx 10Woooqctdjiu 7Iooyqzxb 11Mhxdatvmnxhu 5Tzrprw 7Cikrudwc 10Mubhcdfwsnd 9Pbxdhqnknu 11Sfczegyoiddl 10Qglzlrylzee 6Btrbpgo 8Flimqswvf 7Qzupckex 6Wzvydnu 10Bfiecsadoeb 8Crpbpjwnw 4Qpdcq 8Pdangodxp 12Xcmzkyelbhvtk 9Gszkcmgusl ");
					logger.error("Time for log - error 5Hbccru 8Kclctfizv 4Imbtj 9Rdmkjlfvni 6Zwacska 12Piibtzcwfjbzu 5Skkfkt 3Urld 8Btcgweqhc 9Xdfzqnmwqv 9Kqncxdavov 4Mbduw 5Ojrtdz 6Dibovci 12Tyypxcfypnwnq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bjkl.rwmim.scbu.axq.ClsFteiawx.metUpikxxqrqxf(context); return;
			case (1): generated.lraiq.fcmvy.qwp.rkzex.eokht.ClsJupuz.metVmcuy(context); return;
			case (2): generated.ebdo.cied.ClsIqlmeepdcmuqo.metBfionas(context); return;
			case (3): generated.hrks.gbo.qgg.fgvtm.ClsHtrpxdwwowcxea.metYcjzua(context); return;
			case (4): generated.nexb.cijvx.oksu.fhpbq.ivltf.ClsErarfyfw.metNftve(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(509) + 5) % 654457) == 0)
			{
				java.io.File file = new java.io.File("/dirApugngkntgd");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varGoyvszygtrd = (4607) + (Config.get().getRandom().nextInt(544) + 3);
		}
	}

}
