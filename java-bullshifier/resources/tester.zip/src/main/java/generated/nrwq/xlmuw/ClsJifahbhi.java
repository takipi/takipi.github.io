package generated.nrwq.xlmuw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJifahbhi
{
	 public static final int classId = 460;
	 static final Logger logger = LoggerFactory.getLogger(ClsJifahbhi.class);

	public static void metWahxogsbzqn(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[2];
		List<Object> valYmttgjewrej = new LinkedList<Object>();
		List<Object> valVxaymmcouar = new LinkedList<Object>();
		boolean valSdbghpavafz = true;
		
		valVxaymmcouar.add(valSdbghpavafz);
		int valFkxwdoihblm = 824;
		
		valVxaymmcouar.add(valFkxwdoihblm);
		
		valYmttgjewrej.add(valVxaymmcouar);
		
		    root[0] = valYmttgjewrej;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Hphcifg 6Btspjov 3Skwh 6Iptzahe 6Ugrxqif 11Zyggbyxvedpa 4Lpzgd 9Jphavpiwgf 7Lybrydvw 9Mwgfrezcai 12Lrifzaynkorae 7Figwhate 4Enodu 9Iawqanoyjl 3Gnti 9Chmwdodxiz 9Mfumoclbwg 8Rpgggvxol 4Szyiu 4Khajj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Eisdyask 11Vtbvdqrfxrwo 4Piksi 9Hhbfueclok 11Znvtessaxpul 12Twyodzacpfble 9Manxozuiqe 8Byubxresf 5Cxzdnj 5Tlnvyn ");
					logger.warn("Time for log - warn 9Wrwrsnyfaf 7Rsyrotlu 6Acrenqm 3Gozz 9Shozmupdqj 4Egmtx 3Pedb 5Hktyoa 7Mrtckxjz 3Rrgm 7Gsevwwsq 11Wmhobzfgxnxx 11Nethszkjilfu 3Kocl 4Bngqy 7Uomlutsj 5Ircjjh 3Cqam 4Nswxj 7Ucrpaqpn 3Icpw 3Fhqa 9Gcjesxgbqe 9Cardonwrff 9Iraizojiba 10Qxrsgftuzud 4Akuem 4Cshff ");
					logger.warn("Time for log - warn 12Hlllhnxeceidz 11Spryahwzpqcy 5Lnugje 7Bzoofonl 8Vymtsioin 8Lncuttnkj 8Tgagrkluq 10Opdojapjvip 6Ssuwody 6Zifxmlu 5Nepuqo 5Spmwsa 3Pnnv 8Fbflpuaii 8Htrkzaikk 10Okbudqfiyjv 6Vfdylqt 5Cpfxhi 7Xphtnrip ");
					logger.warn("Time for log - warn 7Gbxogngr 4Nppun 6Zferojq 4Eaksb 6Kkrclrt 5Kgmewd 8Unmexbpno 10Uxjuqzcpfuj 11Vywjpvzjeebd 5Vofojc 11Wrfamqiugghg 12Egsrksfqflcnf 6Qapoqxt 10Qxnbvtttfnv 10Pbegrlcyjvx 4Bcism 12Ldqasjkuymcdj 12Unmynhnnseues 9Imedcwocrx 9Vaanrpeimh 3Gfaw 7Cgeinizg 8Qsbmhgtwf 8Omvbbyqeq 10Bdmtcydjxtu 9Tamrfgogek 7Bbnrhobu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Xldtbrqcadza 5Dtbdlc 3Lfev 9Pwvyqhktyb 9Ainfiihxpk 9Aeyvditcfr 11Lgpwuowuklny 12Tgfuqtgoafiwg 8Vyrhkpsxn 5Ukftrd 6Uetqhme 11Vvauwbeyyexz ");
					logger.error("Time for log - error 10Hjdgwppbseb 5Edxnwx 6Eyllyow 5Vjjpsh 10Suuodcpqsvy 11Ocjtevyptnsv 10Afbpjnzlqyj 4Lsasw 8Bkmwzvykf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bde.vdlp.frn.zsrjp.eqwxd.ClsMvedn.metBrdejrtmmvqjyb(context); return;
			case (1): generated.zxd.ssm.wrmu.ClsZpxwrsfothfgl.metAomskmmjub(context); return;
			case (2): generated.lgws.kxkr.zse.myye.ClsAnryfbudqi.metTjuhcirugyoro(context); return;
			case (3): generated.oue.dqjq.ClsSjudu.metOcoveezijltpk(context); return;
			case (4): generated.hkyc.tzi.ClsYwknearnl.metPahqec(context); return;
		}
				{
			int loopIndex27752 = 0;
			for (loopIndex27752 = 0; loopIndex27752 < 5025; loopIndex27752++)
			{
				try
				{
					Integer.parseInt("numIhfjvnplidn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex27753 = 0;
			
			while (whileIndex27753-- > 0)
			{
				java.io.File file = new java.io.File("/dirIglfyanktcw/dirNzisfrjzrvh/dirZueegqdqtkq/dirJsqvfomacfo/dirQvnajhlrobt/dirCroewkzpkmm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varVqrqscfynzq = (Config.get().getRandom().nextInt(961) + 4);
		}
	}


	public static void metRjvyz(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valWqhipewihks = new HashMap();
		Map<Object, Object> mapValQogctdiexrh = new HashMap();
		long mapValBcnwkdqynap = 8580896612190630955L;
		
		boolean mapKeyQllpmxlbant = false;
		
		mapValQogctdiexrh.put("mapValBcnwkdqynap","mapKeyQllpmxlbant" );
		int mapValSlcikstvrht = 116;
		
		int mapKeyZyrpcysbqod = 454;
		
		mapValQogctdiexrh.put("mapValSlcikstvrht","mapKeyZyrpcysbqod" );
		
		Map<Object, Object> mapKeyQpnoczvlnjj = new HashMap();
		String mapValWxfmisjwmmc = "StrMkhzuvkhpyu";
		
		int mapKeyQuicilvgjay = 672;
		
		mapKeyQpnoczvlnjj.put("mapValWxfmisjwmmc","mapKeyQuicilvgjay" );
		
		valWqhipewihks.put("mapValQogctdiexrh","mapKeyQpnoczvlnjj" );
		Map<Object, Object> mapValDcgzjctsagk = new HashMap();
		int mapValJxrguzicsyw = 375;
		
		int mapKeyHhqjijszqvs = 632;
		
		mapValDcgzjctsagk.put("mapValJxrguzicsyw","mapKeyHhqjijszqvs" );
		String mapValIufdartlqie = "StrCuccpacgoho";
		
		int mapKeyLhbdplzvbzn = 934;
		
		mapValDcgzjctsagk.put("mapValIufdartlqie","mapKeyLhbdplzvbzn" );
		
		List<Object> mapKeyBpopucecprm = new LinkedList<Object>();
		String valYpujedwlbcl = "StrVmvcdueioby";
		
		mapKeyBpopucecprm.add(valYpujedwlbcl);
		
		valWqhipewihks.put("mapValDcgzjctsagk","mapKeyBpopucecprm" );
		
		root.add(valWqhipewihks);
		Set<Object> valKxxoiadabxk = new HashSet<Object>();
		Object[] valFphvdtgylao = new Object[7];
		String valUvcpswqjmuu = "StrXehgvsdtinf";
		
		    valFphvdtgylao[0] = valUvcpswqjmuu;
		for (int i = 1; i < 7; i++)
		{
		    valFphvdtgylao[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valKxxoiadabxk.add(valFphvdtgylao);
		
		root.add(valKxxoiadabxk);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Pvcswvf 12Masubyoybgqko 11Tblzdmuomffd 8Yqwlmkwwr 6Wiwutaj 5Pfrekn 12Tpjnabrjdasmc 8Aakhfbcxz 5Iushrd ");
					logger.info("Time for log - info 5Rmlvpe 3Uxca 11Oryrffepjlld 9Zknwdjqtas 11Wstszqndlcjv 9Ssodfbvkjg 4Bbxid 9Knbgpfsfok 5Tcxfbs 9Iaiaqabpta 3Vvrs 9Yjeksfghag 11Yrmvhfzyunxi 5Cihlap 7Rtjomajg 6Mebltxg 8Agtvgctqg 8Mplgogpfz 11Tseayhenjfaf 8Ftqfyspeb 10Ghcnvhwznxm 6Zucuqhn 4Zccib 9Ecgvkyummr 10Bfeskujkxtf 12Ituvcdozcsyff 10Hqyamivaqda 8Fmzwtndyx ");
					logger.info("Time for log - info 10Fpqvthsfeye 9Lmjfzbnync 9Ccgvjpdwjn 8Iyufhmhcl 10Vnaogrrsgol 6Ajuhmng 10Xcoowegsqun 5Ybrwjc 12Fmajjlwehvjiz 6Abfetln 8Gmgmlqphn 9Lcngmxeufb 5Hlmrac 5Cltopj 7Czbfajaz 5Xgpijv 8Huofcdnmy 11Zfprtmerjruu 10Ahyhesffyvt 8Qcwbhftfj 11Tiaupjjyxlnm 7Gxwbwfvh 8Ywlhsvvjf 4Chxfv 8Bgneuuzsj 3Zbvo 11Ipnitmamiobx 4Wradm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Yfxa 10Nhlvtucoywd 10Jqcmdqytipg 9Woipmlejiw 12Oculjwcqqgawn 3Iypj 9Rrctiuljll 6Hqxtoof 8Dkokwedls 3Lxtg 7Wzlnggez 11Xtlcjixmxlqw 7Einbncca 12Jfueopserxwcv 9Hzhhwadtfu 8Dlgmpbuoy 10Yifzwpecnoh 9Dtloickugp 7Xdfoafhr 4Xzzrw 5Eqneql 4Shkmq 10Vheyqxgxepk 6Horppao 11Vyqwvnhkvcgb 7Kaymjmqy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Lvqoywyzwkcyz 9Ztubaebljf 6Cfmiyev 4Viatn 3Hltf 7Sdyggaeh 7Xempjydc 9Tcxuubibpk 6Tbgcmgu 8Yaslmkcgv 9Lqlvthjqeo 6Rwkrdaf 5Ufjamd 7Sotgmvij ");
					logger.error("Time for log - error 7Rrddttfb 9Sjsyxprsrj 3Iawg 9Bnhjtldrdi 7Vhqcfflh 12Wcrtimcdfzyky 5Ecdcvr 11Zxezcstnfeqr 10Yhtvnczgfox 3Wocd 6Heokyli ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pfu.znq.ClsGxncns.metXbdeur(context); return;
			case (1): generated.jbipj.zrsb.daypv.qszx.ewk.ClsVnncvmwdx.metBqqpsfdskrnrd(context); return;
			case (2): generated.ghn.esb.odxb.wtax.ClsJgsbwdqv.metPazubjuncrdr(context); return;
			case (3): generated.fpitj.gxmf.ClsSfcuawq.metDngtubno(context); return;
			case (4): generated.nrqfo.bwabb.mnp.ClsTzkbgaawvon.metKhackx(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirCfjmepzffhv/dirCtvgbxtbpfm/dirMrtwcycnqav/dirOcucgvalemy/dirHgjlefjocbi/dirSnmrawwgmqo/dirGhrboymfvgn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metXwcdbms(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValAftqimsfdma = new Object[11];
		Object[] valQylccylldcc = new Object[2];
		int valNwpkcihhgmo = 822;
		
		    valQylccylldcc[0] = valNwpkcihhgmo;
		for (int i = 1; i < 2; i++)
		{
		    valQylccylldcc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValAftqimsfdma[0] = valQylccylldcc;
		for (int i = 1; i < 11; i++)
		{
		    mapValAftqimsfdma[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyNjkzujrogve = new Object[2];
		Set<Object> valJtpiiwyhilf = new HashSet<Object>();
		String valEpjwjqysker = "StrKydggyudsgn";
		
		valJtpiiwyhilf.add(valEpjwjqysker);
		String valSntxbjxuzvb = "StrYncymlssvtz";
		
		valJtpiiwyhilf.add(valSntxbjxuzvb);
		
		    mapKeyNjkzujrogve[0] = valJtpiiwyhilf;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyNjkzujrogve[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValAftqimsfdma","mapKeyNjkzujrogve" );
		Object[] mapValOewamtnaohb = new Object[11];
		List<Object> valLfeffalssiq = new LinkedList<Object>();
		long valSnxcehiiygx = 663993938298528658L;
		
		valLfeffalssiq.add(valSnxcehiiygx);
		int valNyrwnnzetsz = 928;
		
		valLfeffalssiq.add(valNyrwnnzetsz);
		
		    mapValOewamtnaohb[0] = valLfeffalssiq;
		for (int i = 1; i < 11; i++)
		{
		    mapValOewamtnaohb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyFgtlcuoxjic = new HashMap();
		Map<Object, Object> mapValFtgroyqybir = new HashMap();
		boolean mapValDundaszehyu = false;
		
		boolean mapKeyOidtxoownkb = true;
		
		mapValFtgroyqybir.put("mapValDundaszehyu","mapKeyOidtxoownkb" );
		String mapValNqskurvebic = "StrDscfldddmqj";
		
		String mapKeyDhdvwpdbeci = "StrMqeoosghvyu";
		
		mapValFtgroyqybir.put("mapValNqskurvebic","mapKeyDhdvwpdbeci" );
		
		Object[] mapKeyLurgwjpyjkk = new Object[6];
		long valBiqphkxrscu = 3483177049309846695L;
		
		    mapKeyLurgwjpyjkk[0] = valBiqphkxrscu;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyLurgwjpyjkk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyFgtlcuoxjic.put("mapValFtgroyqybir","mapKeyLurgwjpyjkk" );
		List<Object> mapValKvgqvhxduwh = new LinkedList<Object>();
		boolean valJmsdpifdznt = true;
		
		mapValKvgqvhxduwh.add(valJmsdpifdznt);
		int valRfgwnpiwpfi = 552;
		
		mapValKvgqvhxduwh.add(valRfgwnpiwpfi);
		
		List<Object> mapKeyOjrjalnruuq = new LinkedList<Object>();
		String valVrywptqpfip = "StrXagvzqynxgj";
		
		mapKeyOjrjalnruuq.add(valVrywptqpfip);
		
		mapKeyFgtlcuoxjic.put("mapValKvgqvhxduwh","mapKeyOjrjalnruuq" );
		
		root.put("mapValOewamtnaohb","mapKeyFgtlcuoxjic" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Cwwdle 7Zgpabpaa 10Mjikpgltwiw 12Zcyqcdkfnekgn 11Jkcqsywcbfpq 12Nrlnarwalsrce 9Toceadwqio 11Ydppntwiofjb ");
					logger.info("Time for log - info 11Dysmlshurchl 11Tpwjyesnbyke 10Iefzsaoqkoz 9Fanetlymak 11Xbtkgsanyqvh 9Xczdzjgxjw 7Wqofggyo 10Absdotyaazp 12Nkvxjdwfbkcmh 11Orwumqzdprht 12Vcczaytgvcxwz 5Jrkkdt 11Mfhpghenizwf 6Eukdict 7Unwqzgeo 5Iefbkg 12Gyhylcvxutjir 5Jixbub 3Brvo 3Nxyh 6Vgfendt 12Zqihrtylrrcgs 6Apmfdah 9Opgtwoayjd 4Wsljt 9Dpepdmbswd 5Mqzfji 4Xgula 12Gozewrbrsxdhn 3Qgpn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Pcmi 4Jxdiw 11Jlunkkioetel 6Vocvwdq 5Dbnevn 8Idrbwjqlh 7Tisjrkho 11Jvrogedyjxgz 12Tzrqtdhyascya 7Dfefijhm 6Tqtwbus 7Mdgypkcq 10Gxekkaewbnl 11Znpghvpkkrmx 10Fwurtjilozv 7Asuuwesz 6Zawvdgr 9Egwmvnuagk 11Jizefcatktwn 10Vvwygvdhnul 8Plnqwwwdz 3Qmvu 6Vgojqra 3Mxfm 4Xapsj 7Dnaejyeu 9Qdrstskcbm 9Rxhuiggqxn 10Qjrrusyumyl 6Cpqsnny 6Amhshdt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Nopsjg 4Hzume 5Nmqmzg 9Aigahxhfvm 12Kgeuaeqaroaqy 11Zlumuowahoim 3Ycyj 8Thxtmhfqv 7Jqoxzpye 12Tdcuwwxowlnfy 10Mbcyhuobbzw 4Qjesd 9Cqgxlatvgj 6Hbolkmd ");
					logger.error("Time for log - error 10Bfmdimiimqz 8Cwhnepnbn 9Poqqotqlhu 6Gzvybnm 6Jgttfnn 12Tkzwqemoqxxwh ");
					logger.error("Time for log - error 10Vwbvpshdgug 3Utvo 6Zfxepty 7Gqysaawp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kdf.pknx.zlwl.ClsKeeubrxremfhhw.metSoxbamiezrzd(context); return;
			case (1): generated.rlg.pxdte.svn.clv.ClsMkagt.metStdtlmnbk(context); return;
			case (2): generated.zxd.ssm.wrmu.ClsZpxwrsfothfgl.metAomskmmjub(context); return;
			case (3): generated.npa.tuyd.ClsLxzuwxfsi.metVaqynjo(context); return;
			case (4): generated.dxrru.qphkk.sigfx.fho.qtrx.ClsXgcfqnkax.metBpzoot(context); return;
		}
				{
			int loopIndex27765 = 0;
			for (loopIndex27765 = 0; loopIndex27765 < 479; loopIndex27765++)
			{
				java.io.File file = new java.io.File("/dirNeefqozgljm/dirFoyuwrhqcwf/dirCarggqygmph/dirRvqvongebch");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metKjzfoqdoi(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValBijoyipiyoh = new HashSet<Object>();
		List<Object> valImqiatevqis = new LinkedList<Object>();
		long valAnlwakkzoyb = 4319171952360661661L;
		
		valImqiatevqis.add(valAnlwakkzoyb);
		boolean valKmcobetpfek = true;
		
		valImqiatevqis.add(valKmcobetpfek);
		
		mapValBijoyipiyoh.add(valImqiatevqis);
		
		List<Object> mapKeyDshlzvfdeae = new LinkedList<Object>();
		List<Object> valAcmkijijifk = new LinkedList<Object>();
		int valMrjgfgkasuv = 455;
		
		valAcmkijijifk.add(valMrjgfgkasuv);
		
		mapKeyDshlzvfdeae.add(valAcmkijijifk);
		List<Object> valZgcsjsmccmx = new LinkedList<Object>();
		long valAlnmmnohpek = 5408928175627430435L;
		
		valZgcsjsmccmx.add(valAlnmmnohpek);
		
		mapKeyDshlzvfdeae.add(valZgcsjsmccmx);
		
		root.put("mapValBijoyipiyoh","mapKeyDshlzvfdeae" );
		Map<Object, Object> mapValNxbpkcpcnld = new HashMap();
		Set<Object> mapValEtcpbmsxvan = new HashSet<Object>();
		boolean valGaplchusmhu = false;
		
		mapValEtcpbmsxvan.add(valGaplchusmhu);
		
		Map<Object, Object> mapKeyCsqhlcinmsw = new HashMap();
		boolean mapValPoeltuiyand = false;
		
		int mapKeyUhwfkeyqhqk = 136;
		
		mapKeyCsqhlcinmsw.put("mapValPoeltuiyand","mapKeyUhwfkeyqhqk" );
		int mapValVfguwaezrjw = 951;
		
		String mapKeyAilxpucpvvp = "StrDtcoyhnyhnf";
		
		mapKeyCsqhlcinmsw.put("mapValVfguwaezrjw","mapKeyAilxpucpvvp" );
		
		mapValNxbpkcpcnld.put("mapValEtcpbmsxvan","mapKeyCsqhlcinmsw" );
		Set<Object> mapValPanxxabaecm = new HashSet<Object>();
		long valDqagytafodd = 7950577586852462410L;
		
		mapValPanxxabaecm.add(valDqagytafodd);
		
		Map<Object, Object> mapKeyOaqmszbhogh = new HashMap();
		int mapValHfjtqiispzo = 148;
		
		String mapKeyPbjdjtjzvoq = "StrPrjzlvsqzij";
		
		mapKeyOaqmszbhogh.put("mapValHfjtqiispzo","mapKeyPbjdjtjzvoq" );
		int mapValKqvndpwktwz = 813;
		
		int mapKeyKtjbyusddkh = 513;
		
		mapKeyOaqmszbhogh.put("mapValKqvndpwktwz","mapKeyKtjbyusddkh" );
		
		mapValNxbpkcpcnld.put("mapValPanxxabaecm","mapKeyOaqmszbhogh" );
		
		Set<Object> mapKeyAtsonxowybk = new HashSet<Object>();
		List<Object> valFzmugjfdyvl = new LinkedList<Object>();
		long valVjnhdoktyxm = -7469135728273924060L;
		
		valFzmugjfdyvl.add(valVjnhdoktyxm);
		String valYmshpxoneix = "StrCciwzdhduob";
		
		valFzmugjfdyvl.add(valYmshpxoneix);
		
		mapKeyAtsonxowybk.add(valFzmugjfdyvl);
		
		root.put("mapValNxbpkcpcnld","mapKeyAtsonxowybk" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Kctdeti 5Dpmtzf 4Tukut 7Fzggffno 4Scrhs ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Vczai 12Altjsoxjdvsbg 3Mrjh 3Ccon 8Fxznchrep 8Ywqfydmpx 7Fgrdzznd 5Snjgej 11Wurowccqhwxu 8Pjtzrkcvk 6Rvziuhw 12Ipgelrunxuaux 4Kyvla 12Xfjxkqfmfisap 11Aqoxkaquceas 11Iybzozawhvio ");
					logger.error("Time for log - error 7Rafnhklz 8Tppqeyhzs 3Entn 12Jpuunfhppvyeg 6Rhnqngi 11Ugkupalmycjw 7Brykbogo 6Mafusgg 10Jpyfornizjg 9Uydybmbttr 10Rbekoexvwgs 8Cjtoclgzs 10Ratdobiacrs 7Lyzupsrs 3Tktk 9Ambyqjxgpr 7Oujnkdmc 4Kjtnu 6Jtlxfdp 6Fyfbpzy 5Etmjqk 4Tqqdp 12Osvgwtpadfcuu 10Wpzsjryyjkx 6Zpyrwrj ");
					logger.error("Time for log - error 7Jsmtkxws 7Bnzmxfia 3Dsno 4Fezqi 9Gufpsqwilc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.opcr.jgy.rftd.rkx.ClsJjouwg.metKtdrtpazip(context); return;
			case (1): generated.mmr.nvta.lkrp.mhnjv.sey.ClsClqnjloclxx.metHlkppashfhooce(context); return;
			case (2): generated.uyus.ruq.fow.dvnw.ClsCysblmgtiyuxcr.metExmmbm(context); return;
			case (3): generated.qdml.hmlho.ClsQuiharvpvfv.metXrurj(context); return;
			case (4): generated.xajsm.xnlym.ClsUmfzchfskds.metUrtrcgii(context); return;
		}
				{
			long whileIndex27768 = 0;
			
			while (whileIndex27768-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirWwktlqkgpec/dirOtgvgzxipiz/dirTerssmulkhk");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numThdsgfiojoz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex27776)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
