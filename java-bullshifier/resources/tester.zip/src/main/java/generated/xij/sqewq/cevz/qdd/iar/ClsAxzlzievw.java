package generated.xij.sqewq.cevz.qdd.iar;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsAxzlzievw
{
	 public static final int classId = 428;
	 static final Logger logger = LoggerFactory.getLogger(ClsAxzlzievw.class);

	public static void metUvgcknurz(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValUwblurvgpkg = new HashMap();
		Map<Object, Object> mapValYzxoqhhnnqm = new HashMap();
		String mapValXuuhwtstqoa = "StrCzhwiqiepjd";
		
		String mapKeyHbxuytsxtpv = "StrZonburjpbbe";
		
		mapValYzxoqhhnnqm.put("mapValXuuhwtstqoa","mapKeyHbxuytsxtpv" );
		
		Object[] mapKeyNlznmbrnajl = new Object[6];
		boolean valTrsuxngehtj = true;
		
		    mapKeyNlznmbrnajl[0] = valTrsuxngehtj;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyNlznmbrnajl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValUwblurvgpkg.put("mapValYzxoqhhnnqm","mapKeyNlznmbrnajl" );
		
		List<Object> mapKeySqymuindtjr = new LinkedList<Object>();
		Map<Object, Object> valKpgupdxqtsm = new HashMap();
		int mapValSrdrsjomcnt = 562;
		
		int mapKeyZwhnzdipavo = 167;
		
		valKpgupdxqtsm.put("mapValSrdrsjomcnt","mapKeyZwhnzdipavo" );
		long mapValVorjmtkqxdi = -5804977088062646442L;
		
		String mapKeyUzukuzumgev = "StrThscnzhgnsx";
		
		valKpgupdxqtsm.put("mapValVorjmtkqxdi","mapKeyUzukuzumgev" );
		
		mapKeySqymuindtjr.add(valKpgupdxqtsm);
		
		root.put("mapValUwblurvgpkg","mapKeySqymuindtjr" );
		List<Object> mapValJikgwlvamaq = new LinkedList<Object>();
		Map<Object, Object> valWwcerpgigkp = new HashMap();
		long mapValAozidvofgrf = -4851927366877108388L;
		
		long mapKeySwerkclxycu = -4573512366626484534L;
		
		valWwcerpgigkp.put("mapValAozidvofgrf","mapKeySwerkclxycu" );
		
		mapValJikgwlvamaq.add(valWwcerpgigkp);
		
		List<Object> mapKeyYnpgnnxaamr = new LinkedList<Object>();
		List<Object> valUifzeejidfb = new LinkedList<Object>();
		boolean valZysvrfnioie = false;
		
		valUifzeejidfb.add(valZysvrfnioie);
		
		mapKeyYnpgnnxaamr.add(valUifzeejidfb);
		
		root.put("mapValJikgwlvamaq","mapKeyYnpgnnxaamr" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Yndctupowjy 4Kirha 6Yvyhudt 3Rdai 10Hysqoucakve 11Sueuuxkoimyr 8Kbqtfotqj 10Ducareyqvid 5Vchqzv 8Mgpszaegq 10Nmbrltazlcf 7Jhesmdav 3Tdbi 9Amqltzxvub 4Bokhb 10Spadrurtmfc 9Ipikbiypsm 9Ddialbddvh 4Lgjua 12Kdcikpuijwvzk 5Yhtfnp ");
					logger.info("Time for log - info 12Ztdzutxhbtajs 3Qtom ");
					logger.info("Time for log - info 4Qbaab 3Wled 12Rgneqnsmltoqh 11Doqwtvdpknyi 7Kzdaqtpi 3Hkoe 11Ikfgabdqgzsu 10Zkulvxzshzn 5Mftsxt 3Gypj 8Isuzorbag 4Ukpbi 9Mboxrnxmyv 5Bggrej 3Pxeo 9Xcomjaaenc 5Douzuz 9Btugobinvf 3Edxp 3Uufk 4Mshrm 12Bsqbjeazjqdzg 4Yzpko 8Ruykqayvp 11Ieqmwmgbauui 7Nlrgpigj 8Mbgalslev 11Oeescjszvist ");
					logger.info("Time for log - info 8Dzqjrwzhj 9Cneammuqjr 7Zxwpkefa 4Kucrg 9Ssitxfxgmd 9Bcbdvpxywc 10Wmbcfjwfbrx 4Bnmzy 5Epfrse ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Jkbe 9Uacsxmbubb 11Urfayzerbwlr 4Nzzfh 12Rsnnfdyolwlmg 10Lgvrgceipxe 4Tjcqb 10Wpxoeovftzo 5Eyanhz 12Qdimezfepgawu 9Cqpgstgjhg 4Jpsba 9Jkbzipqvkd 12Iqqtjuuykseez 6Iqyvnfu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Mmubpziba 9Tmclfvvqgm 6Iranemk 3Wtbw 5Tgzngl 6Cayxcom 10Fzywxjekloe 3Zylz 8Runljpcfu 7Fmkvdkxv 6Vdemjji 5Unmcgo 8Fxoslboyk 3Xozw 11Hqjheftajoxi 6Oztzhxk 9Dtgcasuzos 12Pnobxpxmuorym ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
			case (1): generated.afllp.gwt.xvrk.rxvp.rryr.ClsQsqze.metUgmauegqryzcz(context); return;
			case (2): generated.dxrru.qphkk.sigfx.fho.qtrx.ClsXgcfqnkax.metBpzoot(context); return;
			case (3): generated.hcl.ivd.nxcam.ClsQkvrtnftml.metUkmqfsqzjz(context); return;
			case (4): generated.xluq.wys.lexvj.ClsEsonclfnnvbg.metAvsgvixigx(context); return;
		}
				{
			int loopIndex27172 = 0;
			for (loopIndex27172 = 0; loopIndex27172 < 4831; loopIndex27172++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metNunaxfbnokb(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValKlvcjnmewhk = new Object[4];
		List<Object> valSubdckhojyd = new LinkedList<Object>();
		String valSpcakqgkegj = "StrPvvcweuvtdm";
		
		valSubdckhojyd.add(valSpcakqgkegj);
		
		    mapValKlvcjnmewhk[0] = valSubdckhojyd;
		for (int i = 1; i < 4; i++)
		{
		    mapValKlvcjnmewhk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyAeebjzwtgoi = new Object[3];
		Object[] valUmpqnewlmzz = new Object[8];
		String valPfafxcoubnh = "StrSmhdbpctlln";
		
		    valUmpqnewlmzz[0] = valPfafxcoubnh;
		for (int i = 1; i < 8; i++)
		{
		    valUmpqnewlmzz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyAeebjzwtgoi[0] = valUmpqnewlmzz;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyAeebjzwtgoi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValKlvcjnmewhk","mapKeyAeebjzwtgoi" );
		Set<Object> mapValYsvzmehzrbc = new HashSet<Object>();
		Object[] valWjozkyuzvwl = new Object[5];
		int valPnbxmmyjipc = 821;
		
		    valWjozkyuzvwl[0] = valPnbxmmyjipc;
		for (int i = 1; i < 5; i++)
		{
		    valWjozkyuzvwl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValYsvzmehzrbc.add(valWjozkyuzvwl);
		Set<Object> valDaeolpwrlai = new HashSet<Object>();
		long valDvmhwltliqj = 5097048494698472982L;
		
		valDaeolpwrlai.add(valDvmhwltliqj);
		boolean valSndsnxyfvjo = false;
		
		valDaeolpwrlai.add(valSndsnxyfvjo);
		
		mapValYsvzmehzrbc.add(valDaeolpwrlai);
		
		Object[] mapKeyKpdqksonooh = new Object[11];
		Set<Object> valLgswhkumieq = new HashSet<Object>();
		boolean valWuidyaxaaph = false;
		
		valLgswhkumieq.add(valWuidyaxaaph);
		
		    mapKeyKpdqksonooh[0] = valLgswhkumieq;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyKpdqksonooh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValYsvzmehzrbc","mapKeyKpdqksonooh" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Gxsnezrhxu 6Vtdjdhq 11Vpjsgfrytrng 8Xniocfgms 3Jurx 8Emnndaqtu 5Nssjcg 5Niyefb 3Qkwe 10Jguheqkzcrf 3Vnjb 12Brzrubhuozrpe 6Gutknpb 8Mbygpwvzx ");
					logger.info("Time for log - info 6Eplpphn 6Oempdoe 8Auemfrghq 5Oilfrc 10Opjzddrstbx 4Ygzsl 9Ydqffsxrsv 5Mpurca 9Rvtnowibqj 5Mwxtii 11Ioruyqthojdm 7Ifimdrxt 4Phvus 9Cmbwxxncjv 11Yuyolgkcrady 12Gzyhoqhfootsy 6Bpzowgg 8Aixuvbnle 9Iyxktfpovn 5Rsrvvy 4Tnesi 7Qyoyaywk 5Hmjgkn 8Wzgwpndph 6Bwadane 7Ynxdmwms 4Vndjp 7Xpcmrwjo 10Zzpywipowbb ");
					logger.info("Time for log - info 7Jiglvajy 11Cwkkxiikfhtp 7Wtietvpj 11Zrynwooyhdkt 8Jipckbvxc 4Yyxkr 6Seavlkx 9Uamxetmipx ");
					logger.info("Time for log - info 7Uvwqhhqq 9Scbbrqtxaz 8Ejiqmawfo 12Jfdkwlxyzgccs 9Rlgtnmmfkk 4Fqedz 7Kmqpttri 10Ccpcuehcdyc 9Conxlqzuwk 4Wamgn 5Ueuhof 11Btnxfkavufxa 7Qnxbnxzn 5Oauznt 3Rbqc 6Ucvgpfo 3Slex 6Oxhbhtj 4Hssie 12Kghsojeberfff 10Wdeeimjtbzy ");
					logger.info("Time for log - info 12Rrwkceqaidxse 10Gsfxpnjwitt 5Rfpwcj 10Silapujugpc 8Ijqzgeoaa 3Sejv 7Vjwseqcb 10Kmbuketnqon 4Yuqjx 9Vasvgzmirr 3Rknk 5Jkdsev 10Ajctqeytlbn 4Moruq 12Ggctbmkvubsrz 5Axcufr ");
					logger.info("Time for log - info 11Vtcoaiashpyy 5Qsbqcb 6Jeoairc 3Fppi ");
					logger.info("Time for log - info 9Lrkeufajxh 4Uoilz 4Xpmjb 10Pwtgpgdtpgu 10Yyckpjfltys 8Gofssahdt 11Ryxafcdfzuzi 3Fpwk 9Ckysyeuiis 7Rlztcfft 4Ataaa 12Zyrjpbvspatdd 3Bjqv 9Wsxlmlwqef ");
					logger.info("Time for log - info 3Gvry 12Tcvlpcwezsrmn 3Jmnk 8Bupiwbfxf 11Mfolbyzebbxu 12Bvzjgkvjfcton 8Ebnqgrvts 3Fgtx 4Jgzka 7Tkgwquee 4Tijba ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Zopnfg 6Grkijbq 6Fyfvhqy 3Dbfp ");
					logger.warn("Time for log - warn 10Bwychtxdlwl 7Kbpfwiad 6Jwnukua 5Tbcpyc 12Zrvujszhpaurk 12Shtsfnhuuqfks 9Gyhilwyhhr 4Avvnc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Qerrvfa 4Sjzxr 11Zyzrlgwqkxml 3Wmty 3Kbzt 5Hscupk 10Gpxnoszksiu 10Coowxkkfhrg 10Kgpcahqbhfi 3Doyr 5Amabnw 7Qwpigmtt 6Hlpqubh 4Kklvi 6Xxjimxd 10Wnyttmfwxrs 4Pawhf 7Kwqogado 7Rdbemiki 4Fzulb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kjubh.rgz.earxz.ypjc.pmupv.ClsUctrmkk.metKedywb(context); return;
			case (1): generated.rub.wtuur.cpewn.fdq.jektc.ClsLiscwkily.metWcbvsgslh(context); return;
			case (2): generated.kfvy.ymxa.end.hazk.nwqfn.ClsXakhsfoyrlse.metJcgkp(context); return;
			case (3): generated.gmrwo.oumy.sahgj.zbppw.vqlx.ClsDexipe.metElwawj(context); return;
			case (4): generated.hvqh.qdnb.tawyn.ClsAaddylg.metCsnugb(context); return;
		}
				{
			if (((1801) % 200366) == 0)
			{
				try
				{
					Integer.parseInt("numHlbuprmruja");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numRipmyxokwzy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
