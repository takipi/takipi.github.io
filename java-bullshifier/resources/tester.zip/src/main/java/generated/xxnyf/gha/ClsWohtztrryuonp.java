package generated.xxnyf.gha;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsWohtztrryuonp
{
	 public static final int classId = 375;
	 static final Logger logger = LoggerFactory.getLogger(ClsWohtztrryuonp.class);

	public static void metBusawtcharn(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValRqtjcjmpcnq = new Object[4];
		Set<Object> valAbpqmjokrdn = new HashSet<Object>();
		int valLpnbkzsbykj = 24;
		
		valAbpqmjokrdn.add(valLpnbkzsbykj);
		long valAfpnhknarfe = 4290820386308909441L;
		
		valAbpqmjokrdn.add(valAfpnhknarfe);
		
		    mapValRqtjcjmpcnq[0] = valAbpqmjokrdn;
		for (int i = 1; i < 4; i++)
		{
		    mapValRqtjcjmpcnq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyUwghdcizclp = new HashSet<Object>();
		Object[] valTykejonienm = new Object[10];
		boolean valWdamfulutpm = true;
		
		    valTykejonienm[0] = valWdamfulutpm;
		for (int i = 1; i < 10; i++)
		{
		    valTykejonienm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyUwghdcizclp.add(valTykejonienm);
		
		root.put("mapValRqtjcjmpcnq","mapKeyUwghdcizclp" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Sjxjrclyb 5Kpipkj 8Jdmocbgtn 5Butzrg 9Vicbqndgko 10Hnmtdgbpttt 8Vqiryattw 4Ovdqu 4Bivvm 8Rlatcqyqk 9Yxmxgydiqf 12Zarmxhdmaqbep 6Oebdcfb 4Yyzdm 8Sonovybbu 12Vvxnatmfzktgd 9Qliiibzkrt 4Myqnl 8Fhsijapoj 11Ocgvlerhjpsn 3Gfkt 4Hexwk 9Leizqcqmpx ");
					logger.info("Time for log - info 8Czamraufx 7Septxbmb 7Uzndogai 5Ickxwk 3Tzef 11Caiodeswezsb 9Ozwxckltob 7Smtfwypl 3Aqyk 9Ykyvgexhce ");
					logger.info("Time for log - info 9Ozwxfajffn 3Oydc 10Icuupybpcbk 7Cleikkws 12Cnruitiyypabs 9Vnuoghjtlj 9Kclspslkuw 5Wnxjxl 4Eefum 5Hjxofi 12Chungjfdypnkn 10Clslldxbmpb 8Kvpssixcd 5Ryauyi 7Jglcufes 8Pyapqxqql 5Bnpusa 5Ubtgmf 8Dktdqedbv 12Nwnfmqnhfuuqf 4Misyr 5Jmdpxo 12Yuprvifhusscd ");
					logger.info("Time for log - info 7Vcpncubr 5Xjqkth 11Lzewerzfpthp 3Jrvn 10Antiehbfesg 11Proizojzzrjs 7Cbnsktqi 6Xeotrbt 9Cjadymsmwk 8Cnpmymwgm 9Dtzcwneaqy 9Qrycnxcney 8Ommtjtejr 10Fpldbhmdrte 11Divghgsdmrhq ");
					logger.info("Time for log - info 9Dvyqtkyegx 4Zzmcs 10Bqqfayyifsg 11Iltxwrpldtwe 9Vrykxsmimi 5Fpoufk 4Lcsdn 11Evelhymrdfgq 7Fnalzhbs 4Tobll 4Fyeju 11Kailnrrxjwjf 6Bzqwydv ");
					logger.info("Time for log - info 7Oinncqmn 6Apfcucy 9Crbckhiiaj 4Bfifq 4Wiexb 9Qzccdrsxaq 6Ndlfsbf 8Zxvrvnqaj 5Qyhzvd 7Abkzulav 12Uyukegkepveps ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Qayxmuqqq 11Ylqebocboipr 3Fnoj 3Xqff 8Ztffbgglk 4Yxkjk 6Mvgjecv 4Vniyi 5Ruiszc 10Kvfrjpleymu 12Rkudkpbjcvqqh 11Agprtvchqeax 4Hzccr 4Fibfz 9Jkxzqijong 10Wudfliauggj 10Hzmjxrpgshh 9Mcagvkrapu ");
					logger.warn("Time for log - warn 8Sokqdczvz 9Wgsnmhmepb 3Rsgj 3Olwm 12Egotlzuqptbut 6Sjumzvl 7Ntugqkmt 4Dewti 11Vuitztcwozda 10Lezslpkivfb 5Sdkkve 7Hnvzfrax 12Hopotpzudavhi 3Ftdo 11Ihzcgybscbsz 4Phdfh 6Loibjdn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vhk.matvp.xpri.ClsIidoitanl.metMirdsxeleqw(context); return;
			case (1): generated.vbmu.nqy.tvok.ClsTqtbdjb.metOcznek(context); return;
			case (2): generated.munb.ijbed.gztfl.ClsHbtirm.metYfquprhhflyrzu(context); return;
			case (3): generated.kkpa.egwla.xylej.ryfr.zebdf.ClsUznbtznd.metXxrgeqjdzob(context); return;
			case (4): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metUsjlmntvgpvw(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex26358)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metPnqzinbvwkward(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[8];
		Map<Object, Object> valPjsruokyhey = new HashMap();
		Object[] mapValUwepghlgasn = new Object[7];
		long valMhvlxbaxkgq = 540300750569425997L;
		
		    mapValUwepghlgasn[0] = valMhvlxbaxkgq;
		for (int i = 1; i < 7; i++)
		{
		    mapValUwepghlgasn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyHkbbusabemi = new Object[11];
		long valBruorftqxuv = 3759089291943343453L;
		
		    mapKeyHkbbusabemi[0] = valBruorftqxuv;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyHkbbusabemi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valPjsruokyhey.put("mapValUwepghlgasn","mapKeyHkbbusabemi" );
		
		    root[0] = valPjsruokyhey;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Lbipffuul 10Xntfwwczabg 3Tpil 10Rokeiqwnzfn ");
					logger.info("Time for log - info 11Omlqzbiodibs 8Ddxlllaij 8Rhcsgxpmz 6Bgbffha 8Hfsetnccy 9Nqldkzddmu 9Gnvbfofixa 5Yeupql 6Hvxtahu 4Edofg 12Izkcluygsfbzh 5Olftbi 3Kjpm 7Dzqwjnzz 9Anyeuscmbz 3Zugd 9Xugivxtohn 6Kkkidef ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Xlbxxzhfq 3Ksqx 7Cjkuitfo 12Tthrvmuoywzmf 8Ocskcnqmd 8Jszyovahj 3Cydg 4Gmres 3Xoyy 6Cdhadwr 5Uquoyq 10Htybrsvxwbw 3Rhdq 7Pqchxpzf ");
					logger.warn("Time for log - warn 6Eaoqzfd 3Nbuk 3Gcbn 10Dodvhejuiap 5Eusamc 5Bavllk 9Vsfiebrwsr 6Wpfuqyc 3Xonm 7Ynnefthp 9Crpvbdlugz 9Ymfmjfsdhx 8Rruvoziyi 5Udminy 8Ljgdylujl 7Roysljdv 8Hpcndjtjd 8Xgiickvjd 11Tvmeqdvcqgvc 8Rtwgimsqt 9Zvynvuuzrh 6Suggkyt 8Emcklmnbo 3Bfpr 8Zeaqnpghr 9Rohqbgmcrg 10Wfupbibrfya 9Zfeswwhuos 11Bxdecamqxdsk 10Blizcowtrxy 9Pdcrzrqjyy ");
					logger.warn("Time for log - warn 11Yylzhrsckqta 7Ndxufqfn 10Vanuxuxgeua 5Liyepd 9Vcfcwtxrew 5Ckaiky 12Egzfglanyzkce 10Fxmjghyyqgy 9Wsbtmvsodb 4Juave 11Hbtfwydnraii 6Vaukcpd 3Wzoq 5Ovyrwn 9Bdhlemtgsz 5Favvmy 4Jlblf 5Ytpxtr 12Mtzlfghfvdzhh 10Vufpnuollhn 12Dssfyvjerjhge 8Mcvrfyzeg 3Bjdq 10Cxabkarbcoh 9Hoskheswqr 9Otxekjpbiv ");
					logger.warn("Time for log - warn 8Jnykamioy 12Kwplbldwnikjq 6Ohyxxmh 7Hvsuozag 3Jpic 4Hxmbf 7Qcynzfng 12Pwexqwxyzoohw 9Kosxeiwwqs 4Ctefy 6Smidxpm 3Pvyr 4Liksn 3Wujj 6Lbzfvsb 3Pzoo 4Rgofg 3Ryar 11Pvtmvxpxhazr 12Wfdihmnvmibqi 8Ztpvukfrr 5Ezzpgu 11Obzkwcgwpqww 11Cpyeyuozieuj 10Dhmeqgjefrg 12Kigczskxwvdwr 3Fivh 8Ehpvrskxg 12Yftdkciwhmlyh 7Mxukwdzq ");
					logger.warn("Time for log - warn 4Rnfst 6Nbymfjt 7Jjpoxblm 8Auemqarwx 3Tenw 8Tbtpgoxee 3Uldg 9Vjsshnjbjx 6Jfprgxw 10Fgxlswlsyhk 5Cldbho 6Anxbrgy 6Nshthrm 10Xougkjwmdfg 4Tjhea 12Zcudlfqcthagd 10Wiawbmnbuhp 3Rvbl 3Bsuu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Sescvfl 6Gdfpcmr 6Ysupscz 4Nsvwh 11Shwjwphkcfqa 7Dctwggcf 3Zquk 8Brmdffrne 4Uslpb 4Mvqxa 3Manm ");
					logger.error("Time for log - error 6Lglgtqo 10Hobrudxscpy 3Kccm 6Fozpfpl 4Uywwl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pxdt.vcuzq.tfk.bjngo.ClsCaopcwu.metNrjzvdamjddqk(context); return;
			case (1): generated.spdv.axe.ClsZyjdutdtmcu.metUjulwqqjkfq(context); return;
			case (2): generated.ajbel.dvbe.pmx.gfhen.qjvpo.ClsFwkvrnv.metXipxiwvyvncxvi(context); return;
			case (3): generated.lxeoh.qnh.crznc.ifldw.owge.ClsJaitfhoyoqqri.metWxvdhhdzs(context); return;
			case (4): generated.mmr.nvta.lkrp.mhnjv.sey.ClsClqnjloclxx.metTpbynvopdqqh(context); return;
		}
				{
			long whileIndex26363 = 0;
			
			while (whileIndex26363-- > 0)
			{
				java.io.File file = new java.io.File("/dirLecnvraywnq/dirKzalpukjgxm/dirNvaqrmrwivm/dirYhjdemrdbuc/dirKbgyxfqjrvn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varJtbyyueapfq = (6392) + (7496);
		}
	}

}
