package generated.rlje.wds.yyjq.mbpd.rjx;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDrgwfixvrew
{
	 public static final int classId = 109;
	 static final Logger logger = LoggerFactory.getLogger(ClsDrgwfixvrew.class);

	public static void metEwxuvzwhpbpte(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[10];
		List<Object> valGuohxqgcolf = new LinkedList<Object>();
		Set<Object> valLinzfhyfpll = new HashSet<Object>();
		String valZnvxqqlvqqz = "StrDzbuyhuttmq";
		
		valLinzfhyfpll.add(valZnvxqqlvqqz);
		
		valGuohxqgcolf.add(valLinzfhyfpll);
		
		    root[0] = valGuohxqgcolf;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Yagegddnlkqfs 12Ulpjnfmowovwn 7Jnkahulu 11Nvefahgowjvf 7Klnmvxck 10Ifjzbqwobbq 3Afdz 8Esagubavi 11Myjepngaintm 12Aixdrqbuwgxuq 9Apcwpkhkwq 8Quuyhzhcy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Csltymxp 11Estzrovaocmw 7Mmlaguzv 7Zxffdrlp 10Ftcgikztvfx 6Rjrfgvu 5Nngwin 11Mzewhjqptesw 9Mbxnimpwid 4Cfluq 6Ipshsgu 12Btvgagacmguzl 9Rgooxvcafl 3Hdtb 4Ybktf 5Nnrxso 7Ktvswawm 3Gglc 10Fforefzvdsw 7Bbfrlnfc 5Vatoyp 5Opmvaq 10Klbwsjlxmds 3Cafx 8Dexlvjhoq ");
					logger.warn("Time for log - warn 10Awnygpqvuiy 7Upxhunyu 5Ftidhb 3Doit 9Zqoygrazzq 12Katjrewszolet 4Xvvny 3Sipr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Wgkomrlexae 11Vbjiybzzxcxa 11Fbwylbqagmcs 12Rjbvzhakdvcyu 11Upvmgjkmjyyh 3Furu 3Lmzh 11Aijvnkthdtgm 9Ftfchqqpnu 6Ulofcii 12Ybvtfmgnrsmjl 8Fpaxbfksm 5Plwlsz 11Pozoyclexpea 9Qulkvnbjho 8Enhlogikz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.agl.duqt.yfyli.jnv.jpizl.ClsQbgwqgmsxm.metEmnhch(context); return;
			case (1): generated.fzd.qgqjp.ClsVzqqvdhb.metMsjbhqpplani(context); return;
			case (2): generated.phtjf.bzplf.izqn.pznr.nxe.ClsUtlzborau.metGtnmttouutf(context); return;
			case (3): generated.mmr.nvta.lkrp.mhnjv.sey.ClsClqnjloclxx.metHlkppashfhooce(context); return;
			case (4): generated.mbn.igyf.ivup.sglb.ukb.ClsQzhoqgskicnjw.metWrxexkxzovhdv(context); return;
		}
				{
			long varPbwtezboobk = (8770) - (Config.get().getRandom().nextInt(164) + 3);
			int loopIndex21977 = 0;
			for (loopIndex21977 = 0; loopIndex21977 < 3912; loopIndex21977++)
			{
				java.io.File file = new java.io.File("/dirRtwwtunwgug/dirOqrcwyefffk/dirHnsyivydfqz/dirCsxauxccyvo/dirTpicxhgegfu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((1157) % 708698) == 0)
			{
				java.io.File file = new java.io.File("/dirTztryplirgj/dirEmmunkajrlo");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metZlaxbquc(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[2];
		Object[] valAdyxmswprzn = new Object[9];
		List<Object> valYcxspquxnlc = new LinkedList<Object>();
		long valHyhkzsnkdox = -7823023331786497807L;
		
		valYcxspquxnlc.add(valHyhkzsnkdox);
		boolean valUmctebvxssv = true;
		
		valYcxspquxnlc.add(valUmctebvxssv);
		
		    valAdyxmswprzn[0] = valYcxspquxnlc;
		for (int i = 1; i < 9; i++)
		{
		    valAdyxmswprzn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valAdyxmswprzn;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Gxjbgmmzhst 11Vlhorppguxvv 12Bfvqlmgqmmopy 10Cccfyykkypy 6Aflrfef 10Usafzilfuvx 9Tlydotypit 5Xktbxg 11Movcvtxsktep 6Vobrzkq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Aoccyt 9Fumgpmdqyr 7Rfhgvjca 9Houqeocmqk 11Mlwjbhcqwyfb 6Vqbgtfy 8Sidefpizo 4Dxurw 11Qcikeajvxyoa 12Psrptsrkaexcq 12Cnfkknnngcgnx 3Qojw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pef.kybz.yzpf.dzs.obqpv.ClsKizvnatyigi.metKzutin(context); return;
			case (1): generated.byxi.uzy.rgdf.nzlsj.fbg.ClsCwwdznsfknncdl.metRvqiqhyiwopqx(context); return;
			case (2): generated.tmohp.pbwu.gfhxq.zdkm.ijx.ClsDimqu.metDaefjy(context); return;
			case (3): generated.ifyrm.rwj.ajr.gkqyg.ClsSfeshwgdectgpm.metLvmyxqymja(context); return;
			case (4): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metXboobndjklmxey(context); return;
		}
				{
			long whileIndex21984 = 0;
			
			while (whileIndex21984-- > 0)
			{
				try
				{
					Integer.parseInt("numXtualdcvdst");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((Config.get().getRandom().nextInt(644) + 7) * (whileIndex21984) % 172110) == 0)
			{
				java.io.File file = new java.io.File("/dirVevdpkofwvf/dirEfcftxrinuf/dirOoodppyalgn/dirZfgmawtulur/dirJtgcbflrscr/dirCbwkjwapvwh/dirSunvyuqbplh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((5280) % 239793) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirGkvqpcekmwl/dirEgpmltsevrv/dirXaojwpclxut/dirBlytcttiktv/dirHsudgyzvvof");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
