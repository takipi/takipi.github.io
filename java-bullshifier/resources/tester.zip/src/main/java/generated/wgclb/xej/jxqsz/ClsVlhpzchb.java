package generated.wgclb.xej.jxqsz;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsVlhpzchb
{
	 public static final int classId = 378;
	 static final Logger logger = LoggerFactory.getLogger(ClsVlhpzchb.class);

	public static void metWmoop(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Object[] valSyqzyqredjh = new Object[2];
		List<Object> valRajpyetsphw = new LinkedList<Object>();
		String valEashlrdvvxr = "StrNvmouyuztwm";
		
		valRajpyetsphw.add(valEashlrdvvxr);
		
		    valSyqzyqredjh[0] = valRajpyetsphw;
		for (int i = 1; i < 2; i++)
		{
		    valSyqzyqredjh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valSyqzyqredjh);
		List<Object> valPukanniqowz = new LinkedList<Object>();
		Set<Object> valExmmrqfvzht = new HashSet<Object>();
		int valLtgkstqukpd = 368;
		
		valExmmrqfvzht.add(valLtgkstqukpd);
		
		valPukanniqowz.add(valExmmrqfvzht);
		
		root.add(valPukanniqowz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Eusay 8Draqgxgwd 10Vullblnjtxl 12Pkbssxdaezpsn 12Mtbooxbtgbasg 4Nfqcc 3Mmki 5Aqbalr 5Oswgou 10Wunlcrcxcwo 8Mqpqlehdz 4Mkxvs 4Srxef 10Duamwmtwbqk 11Rbfhaergrhzn 10Jzxaquzecpm 6Kngyusc 4Tgfla 9Jzedgmaorb 3Nntb 8Wsvafegvo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Ikybwenulfk 4Itovy 4Kgrzm 12Gtxaxnwbilwur 12Ruidglhkkkzza 4Mozcn 9Nhmgxqyfei 10Nhlsmayvjdk 7Gzxonoab 3Nhcb 5Wrgosi 4Npmik 4Jnkjo 3Sada 3Dbfp 9Zwpfsnvjen 6Vreyldq 9Ezqdixseus 12Vjltpxaajnzqq 4Calth 8Qfvzkcuvn 9Tbngkllvtl 11Gfjjskjdqtgs 9Frbiislyql 10Tezgjusvuta ");
					logger.error("Time for log - error 5Inzjfo 11Ouzulzkkcxgp 4Jgjjv 5Hjitqt 5Rqvtfm 5Jxjzph 11Yotkjcdolnuu 9Yltakzfbpo 6Pkprdzg 7Vhbgizgt 11Umxutpmkihoh 8Nustzsnhq 4Lwlwi 8Klrtlxtcw 8Idldniuvf 11Cbkgqvokhcpn 6Pvzgiyi 9Dgnscqjnwc 4Ysafq 11Nzlsqihnzfis 8Othrsptyp 3Ckap 10Opdbwbkzycz ");
					logger.error("Time for log - error 7Zqzowaje 4Runha 12Fnfivqjrnynzs 7Inezwrtw 10Dgwgwifhabq 5Kfvvax 10Acfugrgouba 3Udmt 5Xczals 9Cqowifqknj 9Kvligcfuut 9Fpqhiqluig 7Xnqmxjfg 3Gzjw 6Pwdckkn 9Ruzbgtkaym 5Xuauug 8Ndfdydrhl 5Szxsii 11Ojtjnyqwnggi 8Flnigcihp 5Pvzwwg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rxif.wckg.ncsqv.pmlox.ClsRkhayrnqgfzod.metVuvkwlczu(context); return;
			case (1): generated.exb.zww.kausx.ClsMnvrore.metBgumsxik(context); return;
			case (2): generated.sxepk.qoxr.ClsOlkemveail.metSoyjjijmnpnjwu(context); return;
			case (3): generated.lraiq.fcmvy.qwp.rkzex.eokht.ClsJupuz.metVmcuy(context); return;
			case (4): generated.ucgs.cys.qrt.ClsGwmfnzjfaj.metAenqjcf(context); return;
		}
				{
			int loopIndex26402 = 0;
			for (loopIndex26402 = 0; loopIndex26402 < 6852; loopIndex26402++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((Config.get().getRandom().nextInt(146) + 9) % 512251) == 0)
			{
				try
				{
					Integer.parseInt("numPzqdsceaflw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
