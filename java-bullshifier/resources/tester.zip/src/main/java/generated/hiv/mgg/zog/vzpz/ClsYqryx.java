package generated.hiv.mgg.zog.vzpz;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsYqryx
{
	 public static final int classId = 162;
	 static final Logger logger = LoggerFactory.getLogger(ClsYqryx.class);

	public static void metCoemu(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValGamwtjepadt = new LinkedList<Object>();
		List<Object> valTcfxtelckil = new LinkedList<Object>();
		String valFjezzerdprk = "StrBernfpgjoxz";
		
		valTcfxtelckil.add(valFjezzerdprk);
		
		mapValGamwtjepadt.add(valTcfxtelckil);
		
		Set<Object> mapKeyWyqwuexshrr = new HashSet<Object>();
		Object[] valSpwnyhnrdea = new Object[9];
		String valZtbxwqzwcpv = "StrUwlwxazeaow";
		
		    valSpwnyhnrdea[0] = valZtbxwqzwcpv;
		for (int i = 1; i < 9; i++)
		{
		    valSpwnyhnrdea[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyWyqwuexshrr.add(valSpwnyhnrdea);
		
		root.put("mapValGamwtjepadt","mapKeyWyqwuexshrr" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Trzmyzwoyonz 7Yngzldjr 3Acbk ");
					logger.info("Time for log - info 12Znmoazzpngzca 7Pmwedcny ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Zhlkcjtobtcj 5Cpkeru 6Ewaluyi 7Ofbiemsq 6Edtozkn 11Ivrccvgwdmoq 6Nymiyms 6Mnuyift 10Xeerhnzkeal 9Gfdqrcojcy 6Kwnetmu 10Sdbfpmifemy 9Fcvahojsed 5Leolmt 8Wuzqxsklr 11Rhqfxosdeusy 6Kpmcykc 3Ejft 10Omuaqcikhgn 9Scuwtbusnk 10Xsbsdbvenfz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ntoe.pshsx.ClsKjqouchrqothb.metMqidtlggwab(context); return;
			case (1): generated.ukp.wkgj.kys.bbj.whcvs.ClsShqgniemg.metRrbombfiz(context); return;
			case (2): generated.otrak.sob.wdjq.subj.sgplp.ClsIiictfycdas.metBiiorgnidrplu(context); return;
			case (3): generated.xqub.fxwha.ClsHlclqblgzonjn.metQwtvbhpti(context); return;
			case (4): generated.ryyqn.hafq.oqfv.ClsRsktinox.metWxtwtvz(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(376) + 4) + (Config.get().getRandom().nextInt(265) + 1) % 155483) == 0)
			{
				try
				{
					Integer.parseInt("numPeovqdfloeo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numIwbpjpjicaw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex22922 = 0;
			for (loopIndex22922 = 0; loopIndex22922 < 2921; loopIndex22922++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metXcirnzx(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValKnthftryefo = new LinkedList<Object>();
		List<Object> valKkzrxmjpvcs = new LinkedList<Object>();
		int valZnxoprislzm = 932;
		
		valKkzrxmjpvcs.add(valZnxoprislzm);
		
		mapValKnthftryefo.add(valKkzrxmjpvcs);
		Set<Object> valBbamygfcegv = new HashSet<Object>();
		String valJuxljpkkmcb = "StrGcwnoggwaeh";
		
		valBbamygfcegv.add(valJuxljpkkmcb);
		
		mapValKnthftryefo.add(valBbamygfcegv);
		
		Map<Object, Object> mapKeyXwwvstqonhz = new HashMap();
		List<Object> mapValPiyykeclcgh = new LinkedList<Object>();
		boolean valYzbdwjhmcyu = true;
		
		mapValPiyykeclcgh.add(valYzbdwjhmcyu);
		boolean valLhslprssbha = true;
		
		mapValPiyykeclcgh.add(valLhslprssbha);
		
		List<Object> mapKeyWmjcoqugqvu = new LinkedList<Object>();
		long valZgnrskgdlvb = -4317133629370409824L;
		
		mapKeyWmjcoqugqvu.add(valZgnrskgdlvb);
		
		mapKeyXwwvstqonhz.put("mapValPiyykeclcgh","mapKeyWmjcoqugqvu" );
		List<Object> mapValCrmpmgzogvq = new LinkedList<Object>();
		boolean valToiujjzimcy = false;
		
		mapValCrmpmgzogvq.add(valToiujjzimcy);
		
		Set<Object> mapKeyKmkfvdfyfnl = new HashSet<Object>();
		int valJndxjwkhanz = 941;
		
		mapKeyKmkfvdfyfnl.add(valJndxjwkhanz);
		
		mapKeyXwwvstqonhz.put("mapValCrmpmgzogvq","mapKeyKmkfvdfyfnl" );
		
		root.put("mapValKnthftryefo","mapKeyXwwvstqonhz" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Qylyxt 4Bhbla ");
					logger.info("Time for log - info 5Yeocot 5Rndozk 8Lbgkkwdhn 10Mznjxyfjpnt 10Ulziezkdzul 6Hklhxcy 12Ynqxcmlonnomt 3Cmih 8Vxwimkekb 5Nvjhyv 11Nzkzapwqlnvv 11Exazolzsrlow 5Abqsvo 3Bpfn 12Igepcqjjxrslf 7Kacfzhfg 7Ogcgwjzz 5Djqtby 4Xafyx 12Motrovjtcilla 12Kohjcbuvwfzps 12Jaozsruiokekc ");
					logger.info("Time for log - info 4Fkxaa 4Hymdt 8Sgemuwhpo 7Gpzshlfb 9Avertbqtlu 10Hxbxjvvmebt 7Otuaoydv 10Dviyfgpndfv 8Aebivqmww 9Ukpvmblvar 12Cfuvljupqhctw 5Kcleuw 4Wxvdw 12Catunhnddavrk 4Kidxd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Tvsluetphdgbn 4Chdcv 7Fmulgekz 4Pbhoq 9Arimnlheqh 9Dnsejxcuus 4Glnrp ");
					logger.warn("Time for log - warn 11Lmiywzebdpzk 10Vjfrbkxfryg 6Meomoei 3Qcyn 4Sepjb 5Ahtsax 11Ydoxjcbkgsch 8Wfyarrlep 9Zecpvdlnqi 7Geqhiamf 10Cybyjohobob 6Mrwpqvu 4Agrjj 4Ilydv ");
					logger.warn("Time for log - warn 4Rlepc 8Kqxbfnics 8Xsfaqmdkg 6Ikwmurn 10Ekvalcgebnl 4Zvcip 4Ptpul 9Arwexwvdgr 4Aczwl 11Sexlvgbepkvb 4Wrmyr 7Eurfgyij 12Vahqgbgywkemg 12Fnqfmnfzybofy 12Gyoqhoilhzvjk 5Xpcuua 6Ffpsqkx 6Yauwabf 7Cjakfemj 7Vsrxrpqh 12Fnuocraduwfzv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Whqzg 11Qzzywkmciynq 8Wghterqmc 12Sknnezwuyqfvo 4Yfyty 5Dkvjcw 8Skdwhydbz 8Mfnxltmzz 10Wrluxvsfybu 3Pliz 12Ekonbcxlfjydx 9Waqibvbmxn 5Trciqk 3Tnba 6Uunwony 8Mzonggavf 6Rglbesm 12Uykbpnrvzbkwj 5Ipfidq 6Srzbzgr ");
					logger.error("Time for log - error 4Tpnnu 11Hydqizugcmhk 3Jmwr 6Vbzmzid 7Fbawdvos ");
					logger.error("Time for log - error 11Mmseldvscrjt 11Rjpxcopwnxqv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lfkk.ncy.gpf.ClsMafxzncfnwvsdj.metSxjirq(context); return;
			case (1): generated.gbss.lmi.dvqsw.ClsLptludgibvpvw.metJevsr(context); return;
			case (2): generated.tgr.kelz.siz.xfels.ClsKydjl.metQmhajcedjutgex(context); return;
			case (3): generated.ebdo.cied.ClsIqlmeepdcmuqo.metKtzhn(context); return;
			case (4): generated.ulj.ogxe.vbwy.ClsQmshqdjff.metNngxyjxf(context); return;
		}
				{
			int loopIndex22928 = 0;
			for (loopIndex22928 = 0; loopIndex22928 < 6866; loopIndex22928++)
			{
				try
				{
					Integer.parseInt("numZqfdzkfchmt");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex22929 = 0;
			for (loopIndex22929 = 0; loopIndex22929 < 4355; loopIndex22929++)
			{
				try
				{
					Integer.parseInt("numKtnpabcmomn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((loopIndex22929) * (7706) % 214934) == 0)
			{
				try
				{
					Integer.parseInt("numVpezgqizabx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirAcabpmbhijk/dirKnohjoagxoo/dirFmfbnlpjhda/dirNdigonsipsa");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metBzxrvpucrzn(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[11];
		List<Object> valEpxsjnkkdzy = new LinkedList<Object>();
		Set<Object> valOxrlziicnvn = new HashSet<Object>();
		String valZakgkdvjirk = "StrBoucznnlvfv";
		
		valOxrlziicnvn.add(valZakgkdvjirk);
		
		valEpxsjnkkdzy.add(valOxrlziicnvn);
		
		    root[0] = valEpxsjnkkdzy;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Ekmsorkek 5Ihtfjg 3Jocp 9Znajzdglvp 7Vincoinc 11Zeccckawhcxj 6Qbefqmd 9Ufasrvclvc 12Ljeomcwinbzmx 11Hsculwvxhwvg 4Gdcqa 10Kqiyxglwfon 8Vutxcnqec 5Naygoo 5Nseopk 11Wzarafijafnb 6Dxdyegg 10Wygqnjhjbch 9Uqilvnjirc 6Djlxkza 3Uurf 5Mnjwas 5Qfrkiv 7Tqpajjoy 11Pbmqrvzxxkns 11Jalwieswajdv 12Ljfstfeflhyjy 4Nslpe ");
					logger.info("Time for log - info 12Lwexawkisnfqu 4Wsrsl 6Jcegbdx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Oyshkbio 11Tlnbcycizmqd 7Rcckayed 9Xienkmayue 8Pgvyajrqr 10Bguumkjdhzk 11Vqfielgwmrlm 8Nrltivdco 6Iymuskb 11Rzsofvnncvnc 5Uprwel 11Vusdhoicqhru 3Vlzs 5Chzvto 9Popsypaazs 8Hvcywkfzq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Ygnhbksv 11Prizjekmkhzz 9Puqglxlvgb 11Pqxastupcjjp 6Kipjlpj 3Vndo 3Jvrc 7Aeytgkhb 6Ncxmozj 11Dictvmgdvmbc 11Tgljbllvjhuk 4Cmhiz 11Vqhhzlithflm 6Vklabaf 11Dbnfmspslckz 11Hvnhgyibwlgs 5Hvtock 4Qamvh 6Gtvedpc ");
					logger.error("Time for log - error 11Qkbkefkfbpqn 4Wxffy 12Auzpkymyrarte 9Zpdzoixoik 6Tbanmtp 3Kjdi 6Hfciqhi 12Yevbbucffcxlw 7Nrecwtyg 10Uzumgusnivz 4Ksnyr 12Ilfkxklesgcca 12Hycykefnwadyp 7Uzuplrhf 3Lsep 8Egoyytjwr 9Xpugwpvoox 10Wygugnbkphb 9Wuvdsewruj 5Ypnwic 7Gjrjaksz 9Nkbqifhpuk 8Yyxhghwrk 7Jcvvjzxb 4Eiyoz 10Ccibndzeahg 6Ptwdpol 9Gjoapokpce 8Ambknssbk 9Vcifecjfnk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vjo.evnlb.amjq.ngqoa.vwvp.ClsMhozytfqjununa.metVmtamhroqwi(context); return;
			case (1): generated.svrd.bbp.ClsZenal.metIcwqskzzdn(context); return;
			case (2): generated.afz.qen.lrlj.ClsTvxlbccvg.metWrkbglgpwrbj(context); return;
			case (3): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metVduhhhsluhwuv(context); return;
			case (4): generated.zsia.unbq.ozcif.caj.yiysy.ClsRbxlkiybibs.metDqudcundmaawbl(context); return;
		}
				{
			long varBrlkwwzhojq = (Config.get().getRandom().nextInt(180) + 7);
		}
	}


	public static void metLsquvl(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valWpcoubdvmye = new Object[5];
		Set<Object> valLmoeyesrcfr = new HashSet<Object>();
		String valSsfdpuieboh = "StrJlwibevzhnf";
		
		valLmoeyesrcfr.add(valSsfdpuieboh);
		boolean valSzvmfkabser = true;
		
		valLmoeyesrcfr.add(valSzvmfkabser);
		
		    valWpcoubdvmye[0] = valLmoeyesrcfr;
		for (int i = 1; i < 5; i++)
		{
		    valWpcoubdvmye[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valWpcoubdvmye);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Hqymo 12Juejcrymwrdyj 4Kdmcq 7Jjiitsvm 4Kqask 9Wfcvriszrr 11Ofzonowmnscv 10Slwqmyztatj 7Khlbxpoc 5Idqbvw 4Qnplr 10Rjtczkauufx 7Olidjzad 5Onmxcy 10Pzwvclbfhzq 12Rtorbmzajxczi 3Ryuu 5Drjicd 3Czrx 3Cngd 12Xrmavsopbwbtf 5Oszuww 3Ayti 12Hvbkasfviduqu ");
					logger.info("Time for log - info 4Cjrvh 12Gizhybxwrbiqv 11Rcwmpfygwdee 8Hnhwsvvql 8Knrwarumm 4Rkhqg 6Ssyjbaz 8Mzmkgvsvx 11Judsxiuebpdx 7Gunshhsv 4Qvcmy 11Gzawltgyilkf 12Qibqrpbwxhvvb 10Ujisoumkhrx 7Asewenyx 12Ucnbbzjivgudo 3Ubqy ");
					logger.info("Time for log - info 11Ridaxbccabsi 3Ejjn 7Gbhnahmd 6Qbmnhso 6Zlizvqy 6Eezlzft 5Bchitj 9Lhwzzmprvv 9Tnzerpopqn 5Nivpti 12Sihvgieejiyhl 11Ubpdhfzihurn 3Wotk 6Ybbmjku 9Pfzohgfrla 3Efdh 5Nwuoio ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Xdjjhgyvbuf 10Wagzlneccml 9Gfbabyfaud 9Ebwxxnimdg 9Dohyaduzjm 12Bgbtxvgeqmdyc 4Kmjoi 4Nxusg 8Etfyxaxht 7Zrdhkwia 3Wqlk 5Hhhtaf 4Zosyk ");
					logger.warn("Time for log - warn 6Oekosbo 11Kxwetxyujidz 10Cbmhnjydreb 12Ojijyfhtczooe 4Mjcjv 3Xsvl 4Kbrto 5Avffse 7Mmfpgmgt 6Ifkwzyn 8Zhchxzyoz 10Ujyhpqhwgul 4Lspfo 3Vfnk 6Gvmvnxu 9Kvhjblbiwy 11Ndoeqvzxrabf 8Mwuftwbyk 9Xtjvnyfhwl 8Cohmxvnuq 11Mxpnfduaxuic 9Tgbpnusros 10Awotkcswkje 9Hqospktuii 7Mdrlytoz 6Ztxjxil 5Rdvgct 5Ctqdcy ");
					logger.warn("Time for log - warn 6Gsmgxov 12Qmbsrjudfocbk 6Axuplcy 9Jmiecbdvjr 10Zqznresskwe 7Wxgcqvfb ");
					logger.warn("Time for log - warn 9Tjplmboexu 5Ohmqst 4Zrrqr 9Qlhykdfvod 5Tsylaq 5Ltgarg 5Ouzank 9Witjszazxh 10Umbwwucbsuq 4Lbina 5Kmbsbq 5Kbpzmk 9Wphktmolbj 10Oyobethigod 8Gduwyvrwz 9Qayyzyxapm 8Dlvgsuyhi 8Bxipbhtyj 11Jwzsgnpwreww 12Xylngvgpxzoda 11Mygmedgngmrz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Nsubzyu 12Lukhpcmcgptsw 11Gihfpcjncukz 9Nktzyxvjks 5Mlhvjq 11Yrgxmpycnyhg 5Zwxssc 10Rrthswvzlqj 6Jigymqn ");
					logger.error("Time for log - error 11Nmajgmfhexgs 3Xupl 8Hkkirnbau 5Qytubj 11Yejebjitldnf 3Aifi 10Cekltfxaryz 12Prmmthvkvxycb 11Edsqknpfwjvj 8Eygtopbuk 7Vdzmhjet 4Uwakq 5Rdvyrj 3Xius 9Oqiymineey 9Ehfoptrekg 5Wcmhjj 9Erxqvyiezi 12Wbampelfscqlh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ghn.esb.odxb.wtax.ClsJgsbwdqv.metQiohjypb(context); return;
			case (1): generated.dyv.vxo.ClsWrwpfswr.metTpeyljwzklrtjz(context); return;
			case (2): generated.lkx.jvoz.ClsUgthzii.metEemhoq(context); return;
			case (3): generated.zsia.unbq.ozcif.caj.yiysy.ClsRbxlkiybibs.metJyirgusdstee(context); return;
			case (4): generated.hiv.mgg.zog.vzpz.ClsYqryx.metKmqjahpkjfw(context); return;
		}
				{
			int loopIndex22939 = 0;
			for (loopIndex22939 = 0; loopIndex22939 < 7812; loopIndex22939++)
			{
				try
				{
					Integer.parseInt("numExdbjohxcee");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metKmqjahpkjfw(Context context) throws Exception
	{
				int methodId = 4;
		Object[] root = new Object[3];
		Map<Object, Object> valLgjmphwrvix = new HashMap();
		Map<Object, Object> mapValYqcyvgbogze = new HashMap();
		String mapValJvzscxseueo = "StrFusmttjcsin";
		
		long mapKeyZosqomjaqhz = 287383025658453551L;
		
		mapValYqcyvgbogze.put("mapValJvzscxseueo","mapKeyZosqomjaqhz" );
		int mapValOltaihiifmx = 405;
		
		int mapKeyEisverwihys = 136;
		
		mapValYqcyvgbogze.put("mapValOltaihiifmx","mapKeyEisverwihys" );
		
		Object[] mapKeyXioncjrlhrg = new Object[2];
		String valYscvkbihvhi = "StrLfckuxjfjtv";
		
		    mapKeyXioncjrlhrg[0] = valYscvkbihvhi;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyXioncjrlhrg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valLgjmphwrvix.put("mapValYqcyvgbogze","mapKeyXioncjrlhrg" );
		Object[] mapValBayqlaxhvnp = new Object[6];
		int valMljpnwnbstp = 263;
		
		    mapValBayqlaxhvnp[0] = valMljpnwnbstp;
		for (int i = 1; i < 6; i++)
		{
		    mapValBayqlaxhvnp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyPxtzmdncyzs = new Object[6];
		boolean valMoemzdycqgx = true;
		
		    mapKeyPxtzmdncyzs[0] = valMoemzdycqgx;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyPxtzmdncyzs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valLgjmphwrvix.put("mapValBayqlaxhvnp","mapKeyPxtzmdncyzs" );
		
		    root[0] = valLgjmphwrvix;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Cvlkd 3Iqbx 4Wltzp 10Hgotboqeyjq 8Bvseogwru 5Frglja 8Iztmbtlhe 9Sninsutaoj 5Agluyy ");
					logger.info("Time for log - info 11Vbmlthvjihmi 5Ksyelq 10Buguoxlbjae 7Zlqbdyst 8Vwzfnrura 5Zpvmbg 9Sxjbjnldcn 6Rcpuinr 7Nmsnygnu 5Pdttza 11Vzavifdmolge 3Atbe 7Pecltlzu 4Yurlk 9Qoezbcevij 11Njvhpsjlvzfc 9Gupxendypn 6Rlfvcla 6Uzvhile 10Jkmtayguewc 6Lnbmnem 8Hdzxvqwxf 8Expdoowgi 6Nngztff 7Tceqajzz ");
					logger.info("Time for log - info 5Tdfybm 12Dsgnkrbnduycs 7Hcjaqwec 12Gokksbklejwjm 12Amywfoswumnvn 12Cnwomdqbnobwp 9Usivguvqev ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Xpuiqjajcntej 4Ktygk 12Gbuoepreufwre 4Mfqsz 12Wkxnasmlglizf ");
					logger.warn("Time for log - warn 12Xhkyadtaniuhc 12Tfcaumzpqtpie 3Vwyk 8Zqlwqzreg 6Qagnkxu 8Mgqjgwsse 10Msxrdaymxbo 3Fvsx 11Gruxhpznpnwm 4Biodv 10Xlnxjdgzssx 4Cwdpt 6Eodgopf 9Zaqpjuupcj 11Wlzoqngsurba 8Qnaehpipq 8Bbagpamns 8Iyflohcbw 7Srlhfilx 12Geusuxfmkdgsd 9Bnnurptxzk ");
					logger.warn("Time for log - warn 7Pivxzhnt 3Tbej 11Iglmoepkjcyn 3Qtme 6Cieaopt 4Zbotx 9Pgofpqvhbe 8Emifpvjph 9Iceajtwinb 11Iuzvuoooyfhv 6Gznrhek 5Tyygfh 4Xzzrj 5Aaufgf 3Gzys 7Vesuvcyj ");
					logger.warn("Time for log - warn 10Wspvrztuzud 7Lprlufip 9Nmcsmdqxjk 10Mtuvjwebsmt 8Polovrkbz 3Blkn 3Reyu 10Jmlqosmtrle ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Vpcctj 5Evxaaf 3Kqlq 12Htolmkjjnufbm 6Zrlucqf 10Bolmpshwing 11Lkozvkdnvxmk 6Ihbsues 12Aqvbndejxjshr 9Yovqcnzdnn 9Xdvcgotfgx 9Gswwprfcur 6Lkzbybh 7Zoippdjg 3Pmxr 7Pgqzasyp 6Dpqnfmu 12Vcmdkswhuieyi 11Asegofzkejuy 9Rgigeuygtr 8Jdgvkdirr 9Gjzfbwlhpz 7Zrhzlkeh 9Zayhhumfbk 10Dskiieabhpt 10Ijsesqxenpf 3Dtlj 4Ivylm 12Ctqrwagbrevxl 4Kwtft ");
					logger.error("Time for log - error 5Trwavz 10Yarwlsksxlq 8Iuuxbgvos 12Hqormyoiqagwb 11Wxbmihujfhur 7Dhwgethv 6Cttimpu 7Cmrijmzq 9Wllgawamgi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.twx.gyla.ClsYuzgeqywoqmok.metZrjgdmb(context); return;
			case (1): generated.bftm.jkb.lcr.ctpvk.ClsYfbhukzct.metRefjrhfmiyvoq(context); return;
			case (2): generated.rxif.wckg.ncsqv.pmlox.ClsRkhayrnqgfzod.metOqicwb(context); return;
			case (3): generated.fnpk.eklwq.jyphj.bbvwd.ClsWcvzyhijzwo.metCihby(context); return;
			case (4): generated.kkru.kkr.eff.wedv.ClsTciibuckxmwxc.metEofuqsp(context); return;
		}
				{
			long varTvxzxvgvvlq = (Config.get().getRandom().nextInt(796) + 6) * (9707);
			varTvxzxvgvvlq = (4195);
			try
			{
				try
				{
					Integer.parseInt("numXeaagafowiw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numSodwayjzuso");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
