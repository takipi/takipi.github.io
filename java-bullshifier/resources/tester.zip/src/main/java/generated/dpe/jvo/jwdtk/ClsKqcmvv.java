package generated.dpe.jvo.jwdtk;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsKqcmvv
{
	 public static final int classId = 176;
	 static final Logger logger = LoggerFactory.getLogger(ClsKqcmvv.class);

	public static void metZebfzdcdmlw(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valUxyxinldmiz = new Object[6];
		Set<Object> valAixvujscbih = new HashSet<Object>();
		String valNasparijdtc = "StrZahhqcnggwo";
		
		valAixvujscbih.add(valNasparijdtc);
		long valBswrdavltfd = 3671412558642801974L;
		
		valAixvujscbih.add(valBswrdavltfd);
		
		    valUxyxinldmiz[0] = valAixvujscbih;
		for (int i = 1; i < 6; i++)
		{
		    valUxyxinldmiz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valUxyxinldmiz);
		Map<Object, Object> valYpzxocwsqmr = new HashMap();
		Object[] mapValKeojrnygitu = new Object[11];
		int valKtizqbhgpdb = 643;
		
		    mapValKeojrnygitu[0] = valKtizqbhgpdb;
		for (int i = 1; i < 11; i++)
		{
		    mapValKeojrnygitu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyBhgnfzcxblo = new LinkedList<Object>();
		String valUjilonezrjm = "StrIlbaecfdodj";
		
		mapKeyBhgnfzcxblo.add(valUjilonezrjm);
		
		valYpzxocwsqmr.put("mapValKeojrnygitu","mapKeyBhgnfzcxblo" );
		List<Object> mapValDypnqwskzcv = new LinkedList<Object>();
		boolean valUlsthoqkrir = false;
		
		mapValDypnqwskzcv.add(valUlsthoqkrir);
		
		Object[] mapKeyRisldtmgeri = new Object[8];
		long valHuxhaukypfg = 8550713405717691604L;
		
		    mapKeyRisldtmgeri[0] = valHuxhaukypfg;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyRisldtmgeri[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYpzxocwsqmr.put("mapValDypnqwskzcv","mapKeyRisldtmgeri" );
		
		root.add(valYpzxocwsqmr);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Excwdopijua 9Ckepidjkmd 7Jrplwvlk 4Bzeyh 7Cgqumdli 6Rurekha 8Ommxaeami 12Jffykxgbghnnx 12Wmozykbixroxf 4Fntdw 10Umajbxocbhn 5Lynoky 3Ksta 10Indkclvcsxe 12Lgtbfxxphdbla ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Aevifwk 8Jgblkoeeh 8Cnhriafnm 10Pswqdjnfiqq 3Whhz 8Cjieetvmx 9Wsaaserucf ");
					logger.warn("Time for log - warn 6Yxdtwxe 7Pgdzqhil 11Bhgewzzswgam 3Knva 9Qpztqoqqvs 5Itbrwr 7Yvakdxnx ");
					logger.warn("Time for log - warn 9Vadatuisqw 6Rmmxafb 9Phugqtiemx 10Hgajdsqvggg 6Gtxndan 4Zbkxm 5Fqepxs 6Hprxuaz 10Yasloiqsdnx 11Wnxccemzadiy 12Ijjadlktibypu 8Dxldmcblw 7Scydmglf 4Gzfnn 3Uwhg 11Pjkhqfqbbqoi 4Fcrba 7Gbqayolv 8Slmwgboiu 4Lgmle 8Mpldgvsgu 5Sseezg 8Tbdkcyefx 10Ikpkcrejwgf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Whrqz 8Eckjfnewk 5Vnljuv 6Vzostrm 3Frrj 9Iltgoioxqa 8Irylqfquu 8Xkfjdhvjv 5Oklsli 3Wnty 11Wxnirfswgujv 11Vqpznwilcdvt 5Lxadje 12Praxcvhllwisf 9Qmwuedfqwu 10Uwhyebdpblr 7Rfzachtu ");
					logger.error("Time for log - error 3Haan 12Eewykkbodzvah 9Clprmqepuh 3Lene 3Wbxn 6Sfilrya 5Gwfmku 3Ksix 8Ggnuvctxb 7Rrkkkpmu 4Ugscg 4Yyzll 3Wotd 3Ckyx 11Xfiiykiznwlj 6Wgkntxo 5Ygkqcs 7Sqfixxgr 11Csjflfpoejzi 10Pqnwmsxmcma 10Odcsniddabt 8Kzqplkqyp 9Fxakunuviu 4Mowlc 9Hyouqabfyx 3Dxgm ");
					logger.error("Time for log - error 7Aenkbkkd 8Mxjmikhhc 6Rcezyht 8Sjthvaxsq 6Cptamvb 7Vdwihohq 9Knjfobmpdh 8Lfqvlwabh 3Sjjz 7Otjstjeu 7Pbapwycr 4Yhybm 7Wuxoaeru 10Hsbuhuhajpj 6Mnzkppt 9Xiqxxnkago 4Jstpz 4Xlqad 6Oydyart 8Bmogzkwkw 4Cgvih 11Cuyhhdnxmtbk 7Zupquafk 8Egzebmjzt 4Invfl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jlzkx.vlyxg.uui.ClsYmzeuds.metOsbppb(context); return;
			case (1): generated.xajsm.xnlym.ClsUmfzchfskds.metJmjyqm(context); return;
			case (2): generated.hcdv.yknh.ClsEeaftdg.metJplvyoentoi(context); return;
			case (3): generated.xnl.gdx.dmkh.hpyan.ClsNxgzyqd.metRbhfzkkxtnc(context); return;
			case (4): generated.ydzsq.oryaq.elxyy.ClsOrteugmzafy.metJlrtydsoimw(context); return;
		}
				{
			long whileIndex23165 = 0;
			
			while (whileIndex23165-- > 0)
			{
				java.io.File file = new java.io.File("/dirPsnbxrpbnaa/dirAmicklukklp/dirApxhtpmykte/dirQluepjntezz/dirOrtagdangek");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metOqhxfxoow(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valTcleihsgeum = new HashMap();
		Set<Object> mapValFglfukabfuu = new HashSet<Object>();
		long valInctatbpton = -2776356098968715334L;
		
		mapValFglfukabfuu.add(valInctatbpton);
		int valZjsmzvzqizl = 905;
		
		mapValFglfukabfuu.add(valZjsmzvzqizl);
		
		List<Object> mapKeyHxxywshcaeh = new LinkedList<Object>();
		boolean valFzfakoniggg = false;
		
		mapKeyHxxywshcaeh.add(valFzfakoniggg);
		int valFhmqrbjowlo = 830;
		
		mapKeyHxxywshcaeh.add(valFhmqrbjowlo);
		
		valTcleihsgeum.put("mapValFglfukabfuu","mapKeyHxxywshcaeh" );
		List<Object> mapValWraywxwiefr = new LinkedList<Object>();
		boolean valZsdladbnbxv = true;
		
		mapValWraywxwiefr.add(valZsdladbnbxv);
		boolean valAnfschhboje = true;
		
		mapValWraywxwiefr.add(valAnfschhboje);
		
		List<Object> mapKeyIieeglzoaju = new LinkedList<Object>();
		long valBtglgcjcddj = -3563966824443791196L;
		
		mapKeyIieeglzoaju.add(valBtglgcjcddj);
		
		valTcleihsgeum.put("mapValWraywxwiefr","mapKeyIieeglzoaju" );
		
		root.add(valTcleihsgeum);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Ksgaj 12Rjfmojmslouyr ");
					logger.info("Time for log - info 5Dixkpq 4Prghy 7Hpqqkegu 3Ckue 9Wgdnjhulrh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Cehn 11Frrhpozanpnw 8Vqlswsnvs 10Seojztikfne 6Bsttzsq 9Nwxktytixq 6Hkzqmfj 6Riqlyzp 5Xudfrg 6Vflzyyv 4Fmnqn 12Mxvucpfpoylih 12Fjoxsesloisgq 3Udfo 4Remto 11Hsvdhczmbqst 6Ehxwbhn 3Aelf 12Btuffeoqdxppv ");
					logger.warn("Time for log - warn 3Qfxj 7Cippdcrg 9Wsatbgtuet 4Fdops 12Xrculctcvjkjf 12Gosdqwokelali 7Dnthcbdl 9Rcmxwyfprn 5Jynrvt 9Jgfhpkoaut 11Xmycvsusdvhc 8Ywkjqbath 6Sknawga 4Ieein 7Yflbkxuo 4Sypqh 12Xwojcenisioht 3Qeqt 3Akth 4Hztok 4Rpwwn ");
					logger.warn("Time for log - warn 6Tvbowpr 12Etyllynktrkfv 3Wvdi 9Kosewdoqhb 12Essmurrfqrrra 12Rdflpdyzxgpur 11Cfjftagrunsk 4Uiehu 4Akzbl 9Hwugfdukcb 7Jejsayti 10Hivlesjkaic 5Doblmj 7Tcrjqxtj 7Crjnrxxy 8Rlgpkwxzh ");
					logger.warn("Time for log - warn 5Biofsk 4Iamvi 11Jbtwjgnqvpzh 4Dnmfl 5Rjuzrj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Xzzrcgy 10Skydlqjiadq ");
					logger.error("Time for log - error 3Runk 4Rulpq 8Zuunfzkfm 11Jnqyztplfcqq 10Doldrelcppp 9Bjayphtckm 4Jwqyz 4Nggbt 12Lvnrtjefnuihb 9Jebknunnah 4Rarxr 10Mudydzsutgs 10Owgaaohknab 3Gtlw 6Nmuxvjg 6Rytfgrr 10Jllojuogpux 5Hligjk 7Dqmpjghi 7Jozxjyms 8Xlrpcxwvv 9Phbyrbbyli 10Obwzjiwvulf 3Lxmw 12Izumsrdwlnirc 6Wfjkvis 11Nnaxpnumuxfw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.uffsk.vmiw.dvm.uejb.ClsHwejuhoirpcucb.metTioel(context); return;
			case (1): generated.tgr.kelz.siz.xfels.ClsKydjl.metQmhajcedjutgex(context); return;
			case (2): generated.fflc.jdncn.ClsHubvnnx.metSnkfjhjtib(context); return;
			case (3): generated.ndkx.exo.qju.brvd.ClsMxlcse.metDczdeozbrswoav(context); return;
			case (4): generated.oue.dqjq.ClsSjudu.metOcoveezijltpk(context); return;
		}
				{
			int loopIndex23170 = 0;
			for (loopIndex23170 = 0; loopIndex23170 < 2168; loopIndex23170++)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metOzjobj(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valBjhdbsgtxea = new Object[4];
		Object[] valAsgqqlewrec = new Object[11];
		long valXutevtzrkmf = 8264118386122014331L;
		
		    valAsgqqlewrec[0] = valXutevtzrkmf;
		for (int i = 1; i < 11; i++)
		{
		    valAsgqqlewrec[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valBjhdbsgtxea[0] = valAsgqqlewrec;
		for (int i = 1; i < 4; i++)
		{
		    valBjhdbsgtxea[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valBjhdbsgtxea);
		Map<Object, Object> valYjbjvjdnvxu = new HashMap();
		Object[] mapValCxpthtwmkhw = new Object[6];
		int valUddxwkphftp = 341;
		
		    mapValCxpthtwmkhw[0] = valUddxwkphftp;
		for (int i = 1; i < 6; i++)
		{
		    mapValCxpthtwmkhw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyMnclpxvtynm = new HashMap();
		String mapValLqmkaqqskfs = "StrYkgizseuzvf";
		
		int mapKeyCheqhmkqiwt = 999;
		
		mapKeyMnclpxvtynm.put("mapValLqmkaqqskfs","mapKeyCheqhmkqiwt" );
		
		valYjbjvjdnvxu.put("mapValCxpthtwmkhw","mapKeyMnclpxvtynm" );
		List<Object> mapValVhifdmdsdez = new LinkedList<Object>();
		long valVzrisvjqcxn = 5123195117195467438L;
		
		mapValVhifdmdsdez.add(valVzrisvjqcxn);
		
		List<Object> mapKeyVwwadmxmmmt = new LinkedList<Object>();
		String valFlagdktfyeh = "StrAkvbanslugp";
		
		mapKeyVwwadmxmmmt.add(valFlagdktfyeh);
		long valDlbcvlpyafn = -2085736387292880363L;
		
		mapKeyVwwadmxmmmt.add(valDlbcvlpyafn);
		
		valYjbjvjdnvxu.put("mapValVhifdmdsdez","mapKeyVwwadmxmmmt" );
		
		root.add(valYjbjvjdnvxu);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Ihanz 5Misoki 5Blinpa 7Zyfmfnvz 8Pxkaavtoy 12Srwatjbhzcbdu 7Efhtxdjm 7Zotvsoxm 9Pqibwmnnyt 4Cgzsu 8Uhvlukofa 6Mruvgyt 4Lqoen 5Uvqqki 3Xrxb 12Xtkzgtadhluyn 11Xzggeasqnloz ");
					logger.info("Time for log - info 7Nprndmad 5Gmfpkt 6Aspbnxn 7Zfdfjssy 9Ndcqfrenzw 9Qyvctbxztu 10Vbcwtbwyuqt 9Emmvcedrum ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Pxpckbhp 11Twvqsnrtcfrm 8Natitsfkt 6Kpayyzu 5Hvutei 3Walh 12Cvelzkadbqrld 3Udni 4Ofkmh 8Sfcmbzymh 3Eefp 12Mfdmmtnfwroxt 5Dxbyyu 8Yjcfdirfu 3Idgb 4Pqnia 9Djvbqfheqd 7Ylrweazo 6Gexulgj 12Kviiwqfasnugu 9Qaejkxkgzs 4Bczga 9Fbqwgafcqk 6Hedutid 9Enalxukibe 6Lhekupq 11Rerxdvoypcqz 8Lylwintej 9Fepamvwgvz 9Ykfwfbsjgi ");
					logger.warn("Time for log - warn 5Bywqgh 5Fbokyv 4Zvtja ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Johsltwpxsk 4Ddmjn 12Ykvntlxnnmowm 12Pohuelgwnvtnq 11Sgbfhildxols 11Wesgnsyolfma 7Ijamiktg 3Aawo 12Hfcmydhzkygbx 9Nnnrtnugqj 5Xvcgil 8Pwowqpcja 7Lwwowxmw 6Wauuwzt 3Jcmm 8Mbqjtnpfp 3Eraz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bxw.hza.cjj.bpzns.qzgt.ClsQbxnaxsj.metCcillrjcyusqec(context); return;
			case (1): generated.qku.vho.jtvuy.nvgy.zmvk.ClsVjaehh.metEpucadc(context); return;
			case (2): generated.sik.dyw.jmm.xdu.omh.ClsVarjcvcyur.metFesaihfuowja(context); return;
			case (3): generated.gww.spuw.jrq.nmv.xowli.ClsKosigq.metKcjzvalu(context); return;
			case (4): generated.idk.jvavb.vjuwp.iuzf.fawz.ClsRtwkffyfhbvpjl.metJglxxxadpzz(context); return;
		}
				{
			if (((107) % 869306) == 0)
			{
				try
				{
					Integer.parseInt("numCorrhphjoou");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(568) + 9) % 819233) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex23174 = 0;
			for (loopIndex23174 = 0; loopIndex23174 < 8477; loopIndex23174++)
			{
				java.io.File file = new java.io.File("/dirOibwfgovnbd/dirAreumlboxsh/dirUgvhglpdlbs/dirWtbfchetmed/dirRvhiywhismg/dirAwdmrragpjj/dirPiztkkbjdhx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metUhipoko(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valFlmkgozmeaj = new HashSet<Object>();
		List<Object> valXakgkbbxtnh = new LinkedList<Object>();
		long valImrdjerhrmn = -8699716782269707213L;
		
		valXakgkbbxtnh.add(valImrdjerhrmn);
		boolean valTzfbqdvzpvp = false;
		
		valXakgkbbxtnh.add(valTzfbqdvzpvp);
		
		valFlmkgozmeaj.add(valXakgkbbxtnh);
		
		root.add(valFlmkgozmeaj);
		List<Object> valCuugeqhpuko = new LinkedList<Object>();
		Object[] valOdolysdejub = new Object[3];
		int valIgmxzftgejd = 638;
		
		    valOdolysdejub[0] = valIgmxzftgejd;
		for (int i = 1; i < 3; i++)
		{
		    valOdolysdejub[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valCuugeqhpuko.add(valOdolysdejub);
		List<Object> valUilintwgzda = new LinkedList<Object>();
		int valQupwnkilowf = 4;
		
		valUilintwgzda.add(valQupwnkilowf);
		String valSkhnlsgrckw = "StrChiwzsekcms";
		
		valUilintwgzda.add(valSkhnlsgrckw);
		
		valCuugeqhpuko.add(valUilintwgzda);
		
		root.add(valCuugeqhpuko);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Cmvdebi 5Ccvzyi 7Zbwbmpib 5Jrxewx 7Obxnenlb 4Pzfvs 11Wfvcupsuvlsj 9Gqyfvcvjky 10Blabulasxij 10Gvnbuqwcjej 10Frtgpixxvuq 10Rrmgcgxjrxf 8Opwybmifn 9Sodetkfslk 3Cvns 4Vnzwd 8Pouvplmwd 11Iufubrwwzyve 9Eatrdorbmf 4Jzncr 8Shotxbioq 6Hgoyvdb 11Ppovzfphtccf 10Skscuxlmmyv 10Juerfjrjavr 6Cncakbb 10Clfifbnpkdp 8Ilmpgmctk ");
					logger.info("Time for log - info 6Azktaew 3Ampv 10Zsoomfmdcqn 4Voevn 9Xsyvyhuwmy 12Tjdmwolysdajb 8Jsgfdcjcr 11Tykpymcseaha 9Nosqstbxkh 3Jjzk 3Cxyr 8Ahvqygjxz 3Liav 11Fbeptabbvber 3Ykzz 12Ehxsqsvzgoypa 12Jlyskuypqbatd 9Jxlryomcym 3Znih 10Antmxrggttm 5Oevkhp 3Oicr 12Abumhareagast 5Kclqce 4Pfepx 11Ugjgpddwedkf 4Ljdcw 3Qtbx 5Nrrheo 9Tpxdwgzmwq 11Hiifvpfmxwsw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Fbxtkav 5Nyzkji ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Dvqsjjjntjmx 4Tvfeh 9Vdrzmrpafw 4Ajxfj 5Itowrb 11Lgrsrvlrjrxg 6Wmcalzq 11Psfimcmhhdgt 5Vyhfqy ");
					logger.error("Time for log - error 3Qete 5Hvcyeq 11Enjqyuomannp 8Hnhaoyqfb 4Idciy 3Tgot 7Kcyegzyr 10Dxfqfnkolre 10Lmgmbwuedny 8Etgqdospm 8Htdmblcgm 6Jrxzouo 4Kqmpv 7Uxpdrfon 7Ecnxebew 9Tbymeghjdi 9Ujclzhvsru 10Oymiadjcgvz 9Qedtmfmtgu 12Tavaijeecydcm 4Elzdw 5Cabsrb 5Qvnqhe ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metKlgcwsafmqppr(context); return;
			case (1): generated.gmrwo.oumy.sahgj.zbppw.vqlx.ClsDexipe.metBsktjpxjygwoz(context); return;
			case (2): generated.nlkyt.zasi.ClsQaxysyqic.metUadhackqygx(context); return;
			case (3): generated.vtvwz.yobg.lldg.auey.xwd.ClsDdnvjde.metHxwjgboi(context); return;
			case (4): generated.hfhsc.dtsm.exj.akcxm.ClsEggbq.metGkdrqysenzt(context); return;
		}
				{
			int loopIndex23180 = 0;
			for (loopIndex23180 = 0; loopIndex23180 < 232; loopIndex23180++)
			{
				java.io.File file = new java.io.File("/dirBnqorymbtkk/dirBipnihglmfy/dirSatnyyccjhg/dirXgpwtrowhmo/dirOygnqxsurdq/dirRmyqgepdfkm/dirZtsnhrzitdl/dirEsyjotmnwsq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metJoosxkzgqj(Context context) throws Exception
	{
				int methodId = 4;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValEqyvqbylibj = new HashSet<Object>();
		Map<Object, Object> valVfwnxpfgozb = new HashMap();
		int mapValBccrxtvusuk = 741;
		
		int mapKeyGlmsmfqadjf = 146;
		
		valVfwnxpfgozb.put("mapValBccrxtvusuk","mapKeyGlmsmfqadjf" );
		String mapValBtmsckdzffa = "StrXyzhyijctyc";
		
		int mapKeyAedaufyrzfa = 494;
		
		valVfwnxpfgozb.put("mapValBtmsckdzffa","mapKeyAedaufyrzfa" );
		
		mapValEqyvqbylibj.add(valVfwnxpfgozb);
		
		Set<Object> mapKeyMscphuuwftn = new HashSet<Object>();
		List<Object> valSkfiipgsdlc = new LinkedList<Object>();
		long valThsldgknbdo = 772394230744564264L;
		
		valSkfiipgsdlc.add(valThsldgknbdo);
		
		mapKeyMscphuuwftn.add(valSkfiipgsdlc);
		
		root.put("mapValEqyvqbylibj","mapKeyMscphuuwftn" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Gmebuyncu 3Setw 12Fpdoiiyltwuqh 3Idql 5Irsokg 5Tlhydw 6Xuseoif 8Nnlitxgpz ");
					logger.info("Time for log - info 3Hcxy 8Ujgoagfth 3Flgi 9Gaibcleohj 10Whoxoypqsvv 3Rblq 9Tpzyiuojtl 11Tpzvaydpuakk 8Zlyasyigo 4Ijdex 4Wvdec 4Veopc 7Tprmnzvb 11Dclkwpvgyrei 6Jglwltl 5Lawipc 8Zbmcwnftw 5Koykbf 7Jmubbpfi 4Kuwws 11Rcyqkldfepox 3Gngj 11Uakhupycxkhw 9Avhdxhsytv 10Nyqbcqekbji 4Jdjqh 10Wzcfqaiqbhv 6Zevuuet 7Xzzmnxbv 6Ttioplt 4Vnhuv ");
					logger.info("Time for log - info 3Hpyb 11Grgbypxffzxp 10Mxuwfquzbfp ");
					logger.info("Time for log - info 10Axtxxgtycie 11Duxzltxcustd 9Uncqdledwu 12Ohrcpyqcznola 5Kwwuuz 6Qqvquqr 4Qvutg 8Spktvjpsq 5Wybkug 11Tnnmnbethkpm 12Hhouvlebwnizw 8Bqehkppwy 3Jzhk 7Rcxwbzfx 10Obqlujvcjjb 7Azckkotd 6Tgwinag 11Xckshcadwtqo 7Ohxgyfls 3Qbpm 10Hcswnliysef 3Nvwg 5Nwqtiz 4Vndby 12Ekwpnvyxmvigg 11Gegrprjzmjha 9Flkekuqwzu ");
					logger.info("Time for log - info 6Exuvfiy 10Vcapiutbair 6Pfutcoe 8Ialhtpliv 7Cztgmivd 4Cwcnk 9Gryibghwrt 11Xeqmbokgshrd 7Kadzyxqh ");
					logger.info("Time for log - info 10Oeonujjuiok 4Kumiq 9Iigmieobnu 12Tqikowaioppaj 9Ocxcoluybb 10Ikjwvblmqow 10Ptbtqkoopal 12Cquihtrjczdkw 12Bmoomcvtkpzbc 12Wceswwexylfek 6Ligdqrm 6Mwjjqky 3Xagp 3Wvbl 8Jeiclplma 11Cbghrywltjta 11Pnpyfdxkhkbj 7Dxohhgwk 5Uxluku 8Irzzayryo 5Zarmty 3Fvan 5Opkcbz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Ylkc 9Nzpdrhxawu 7Krupljze 11Wafcoukwdxrl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Syhr 5Ywpjtt 10Rctfgyukzcz 11Zgplnbjnzjcx 9Wlbkscmreg 4Aufhh 12Fkbrjrydkgtgp 8Dehhftdrs 9Hohfvgbbns 4Qbugp 11Dyljnyqpbeim 5Eljfnl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zoaxa.yfbb.ClsTybiqkipwo.metQnlswcnqbxmqgz(context); return;
			case (1): generated.ydzsq.oryaq.elxyy.ClsOrteugmzafy.metJlrtydsoimw(context); return;
			case (2): generated.nclk.lhd.awxff.ClsWzypoogjnr.metXvtfzticubdsik(context); return;
			case (3): generated.dyv.vxo.ClsWrwpfswr.metTpeyljwzklrtjz(context); return;
			case (4): generated.liyl.sfhr.ClsNilzqakfd.metIodijouzvnszdm(context); return;
		}
				{
			long varRcrqrejhciu = (Config.get().getRandom().nextInt(296) + 5);
		}
	}

}
