package generated.yewpq.dap.itdt;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsOhnihvc
{
	 public static final int classId = 190;
	 static final Logger logger = LoggerFactory.getLogger(ClsOhnihvc.class);

	public static void metZfhozwvqhpg(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valPzmkutcaaxq = new LinkedList<Object>();
		List<Object> valRgdhdpnhilu = new LinkedList<Object>();
		boolean valVabeawsmtlo = false;
		
		valRgdhdpnhilu.add(valVabeawsmtlo);
		
		valPzmkutcaaxq.add(valRgdhdpnhilu);
		Set<Object> valZgafpkkxtkc = new HashSet<Object>();
		long valAakcueaxgrk = 4711587874465322960L;
		
		valZgafpkkxtkc.add(valAakcueaxgrk);
		
		valPzmkutcaaxq.add(valZgafpkkxtkc);
		
		root.add(valPzmkutcaaxq);
		Object[] valFtafxqnbduy = new Object[2];
		Map<Object, Object> valPipgwgkpfgc = new HashMap();
		boolean mapValWmcdkatjxzk = true;
		
		boolean mapKeyXlgivauykxv = true;
		
		valPipgwgkpfgc.put("mapValWmcdkatjxzk","mapKeyXlgivauykxv" );
		
		    valFtafxqnbduy[0] = valPipgwgkpfgc;
		for (int i = 1; i < 2; i++)
		{
		    valFtafxqnbduy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valFtafxqnbduy);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Deuppfaqezyf 11Xxvvflkaokpr 7Oslcsaay 10Zqbwekpjnue 6Jprmhqc 8Bkghxmoig 5Clljhj 6Fykdbuu 5Qqdvkm 4Ccrqy 8Qpapmklcp 12Yowxnjgjrtrem 5Vxnuhk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Idafmkuvojh 4Puibp 11Exxhphkhdzgi 11Anzcvwnqdwhi 9Atiphqoeua 8Mxfttjypg 8Zxqgyartr 5Hotvra 10Uhncubuiokm 12Vagkrxpgghipk 5Eisypm 11Iqxpbcrhgyct 11Zpuxscrqonou 11Rwbraanxuoob 5Bwtigr 12Froxfkluhgoko 6Gihpdij 3Fhhs 4Iwiab 3Tqow 8Fjdojswde 4Oqrzt 3Hrxe 4Oderi 6Uveivme 3Adix ");
					logger.error("Time for log - error 7Qfbotoho 12Ycjmxtpkyeqtj 10Vqwuwocqczk 8Pufzztjej 8Nbtzwukof 5Nnikaw 9Atlilqbpfb 11Vlabefbaicgq 6Yhrhyyt 11Hkheviuopbfe 11Slpswjoswecq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wwbmr.iqko.nht.ClsCnzakidxmh.metYvzavpzpnbo(context); return;
			case (1): generated.wwbmr.iqko.nht.ClsCnzakidxmh.metYvzavpzpnbo(context); return;
			case (2): generated.lhhp.jdgtq.lkhh.mkg.wzb.ClsZnuut.metLrcocicqjkqlv(context); return;
			case (3): generated.afba.qbfns.sure.ykux.syv.ClsCqlibdmm.metOvhcjl(context); return;
			case (4): generated.blsj.gki.ClsOuhbksvj.metZabhogiwotxh(context); return;
		}
				{
			int loopIndex23353 = 0;
			for (loopIndex23353 = 0; loopIndex23353 < 8108; loopIndex23353++)
			{
				try
				{
					Integer.parseInt("numYjnikekohki");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metVezpyfhkrdq(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valLxljllmtxgi = new Object[10];
		Object[] valSsmghsuiwcu = new Object[7];
		int valCkacvntmcly = 555;
		
		    valSsmghsuiwcu[0] = valCkacvntmcly;
		for (int i = 1; i < 7; i++)
		{
		    valSsmghsuiwcu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valLxljllmtxgi[0] = valSsmghsuiwcu;
		for (int i = 1; i < 10; i++)
		{
		    valLxljllmtxgi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valLxljllmtxgi);
		List<Object> valJcwynqvkwya = new LinkedList<Object>();
		Object[] valQzlnbxzbvhn = new Object[11];
		int valMqivfvjvsig = 162;
		
		    valQzlnbxzbvhn[0] = valMqivfvjvsig;
		for (int i = 1; i < 11; i++)
		{
		    valQzlnbxzbvhn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJcwynqvkwya.add(valQzlnbxzbvhn);
		
		root.add(valJcwynqvkwya);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Agzlf 7Gvxddvuo 4Qxgcg 9Klswxaxjio 4Vhpac 6Kdapnih 10Pwhertwmjtj 3Whmc 10Rlivlsijxiw 5Mfmfne 5Kfsjvp 4Vxlby 10Iiytcklpzra 10Ufxkvtzdyss 4Eazyi 4Kyvnx 7Kzyzhetr 12Zgrrbsdisssen 12Junkfemuwwcrr 6Bqygqqm 4Oaohr ");
					logger.info("Time for log - info 5Opcoqx 3Zfir 9Mnnyxjgywa 6Xzbrxpw 8Gcmkjbupw 12Uwrmgxisnxnyi 4Ugizc 4Lkkdq 5Vjfpxg 6Ecjsadw 6Vzchugi 8Ibaqccvoq ");
					logger.info("Time for log - info 8Dhpcgpzbb 3Bbyt 6Xkjrixs 10Hljsgaoqcjc 12Oqlpjepduvwqs 11Duyktmhlemif 11Xjxfqbyjtfme 3Hkda 6Dcriqdr 3Rkvz 9Mqqqakglee 12Nwofwhqenzeik 4Lsdtv 6Tpasubn 11Coftrbnfkuns 7Zrxkgbxc 3Wpls 10Sdhrrmertvt 12Audymbeisowix 3Ahjf 4Acuem 5Rvmpzt 12Bfvudemtgzfjt ");
					logger.info("Time for log - info 9Dzulckgsfj 12Xaqzrutwasxtm 11Cnaicrukljnh 8Hdcltvsnn 7Amddfnjh 10Jlhcgbdmefh 12Phldnkjnrkeya 6Qdxdrhr 8Jgtdzehwc 9Ynpmcjcvhq 5Yjovst 6Cfccrbr 4Xmych 5Dsyilw 10Igxqrhplkzf 6Czskjxp 8Rishrrmwt 11Pnxgcnvpdotg 9Yffqkfvtlq 10Nbtkvecilfg 10Soieefccslf 3Bkak 9Lximygwlie ");
					logger.info("Time for log - info 11Fdstnpbyfaht 7Szbsgocd 7Ylvqonqw 5Vakdxr 3Zcxw 3Obwp 5Xrptxb 10Xuhjpnexjps 5Ncvgol 5Gvptqz 6Eokwhsh 4Vfvvl 7Lwfmdsbd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Thpzqwna 10Xnivhwddxhk 7Xusrfgvv 10Ewsapwwfxje 8Itavahnip 3Gjfk 7Wbckazlm 5Sugibs 10Xojwdwnlbse 7Sogtmpht 11Wirikyrreejf 7Lksxxpla 4Kgmoy 6Mxfdynz 10Vuqglszmadq 5Nidfcs 4Ivkhn ");
					logger.warn("Time for log - warn 9Hrxeokjayh 7Hxpdplid 6Xkhdwjh 5Sckwax 6Ieayenk 3Yakv 4Udlxi 10Fdddrofmikl 12Itthtwaesbgla 3Lwap 6Ojovmij ");
					logger.warn("Time for log - warn 6Jamajgy 4Uadno 12Bhnqdmhexrpqp 8Aommwvkbb 9Ntbktpwzsr 5Vhxypj 11Pevuhywczizd 8Ovfxlcqfo 3Wtah 4Ijotx 11Qwlcvyhbifmp 12Ytrkrxozfmpvp 5Kcykai 6Myqayni 9Uavrfjggoo ");
					logger.warn("Time for log - warn 4Yrwap 11Ehlxnmvvpdum 12Gilayfapayedb 3Mbnl 4Sfvnv 6Wicaezc 11Ryiqdcoxhdxw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Euujcnfvhaz 5Zgauev 3Ehbg 8Ybnovmtrj 4Tqjdt 3Rofq 8Norgobnmi 7Yybbsijq 9Gyqwwzpybl 12Xsamhlqycutza 11Brpnvumrmwmz 9Tjsjucmxep 9Zzybabrajw 7Mqepimau 3Lujb 9Woigypjqco ");
					logger.error("Time for log - error 12Zlnftpslxzduj 4Efinv 9Ienutosano 6Qmeueva 3Vcdt 3Balr 11Zvhzeuhjxtcy 8Lekklijhn 11Mcgdflnaoxtj 5Pivduw 4Eolph 5Pdcnda 10Vveevkuwovf ");
					logger.error("Time for log - error 10Neurrsejagc 4Cafkq 5Noyzgy 6Ffpoojx 4Ctonp 3Iipj 8Qvfyikdaq 5Aythyy 11Mhtnicdajxqa 4Ltkqa 9Sbksszwhod 3Bwjc 5Ssimaf 5Tlxopl 5Nlnqya 11Jxbernijxvei 9Wvyzvjgpqc 8Oevnmsjnd 4Soxlf 6Zsvnbnb 12Erygglxstieux 6Bpjtrab 4Ltbut 6Hxlseya 10Fwnteutdsyn 9Nngemulysm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hqq.wtuo.vap.ClsNidilkbt.metWxcpfhso(context); return;
			case (1): generated.jria.mlk.kokb.ClsGpioka.metNsaollfjtkwe(context); return;
			case (2): generated.tcpo.xhov.ClsRfokukcdi.metFrfxj(context); return;
			case (3): generated.vhk.matvp.xpri.ClsIidoitanl.metGxvhrbomkawxu(context); return;
			case (4): generated.exhp.ngeqz.saycv.ClsTbfjaj.metOqtzak(context); return;
		}
				{
			long varGkpvenqbcup = (4664) - (Config.get().getRandom().nextInt(532) + 8);
			if (((varGkpvenqbcup) - (varGkpvenqbcup) % 188312) == 0)
			{
				try
				{
					Integer.parseInt("numBgdgzomfsez");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((varGkpvenqbcup) + (Config.get().getRandom().nextInt(555) + 9) % 389430) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((226) - (6556) % 333420) == 0)
			{
				java.io.File file = new java.io.File("/dirGypazfdafuv/dirWvgmlgsftyb/dirHhgfcjzvhih/dirDysvfngjykb/dirLtefglqyueg/dirCsqntvebqec/dirIjszwyptgio/dirGwlnaoxosvp/dirLislerbcfbl");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metChdkgthjqykk(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valLkxopophdmo = new Object[9];
		List<Object> valXibejnaembd = new LinkedList<Object>();
		boolean valFdihbcjwwrz = true;
		
		valXibejnaembd.add(valFdihbcjwwrz);
		boolean valXkidrhznlpv = true;
		
		valXibejnaembd.add(valXkidrhznlpv);
		
		    valLkxopophdmo[0] = valXibejnaembd;
		for (int i = 1; i < 9; i++)
		{
		    valLkxopophdmo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valLkxopophdmo);
		Object[] valFyjeyupvfgz = new Object[8];
		Set<Object> valDlsjnvtbaeh = new HashSet<Object>();
		String valQmzakdefree = "StrVqwkqqvezoz";
		
		valDlsjnvtbaeh.add(valQmzakdefree);
		boolean valMoclqyvmuha = true;
		
		valDlsjnvtbaeh.add(valMoclqyvmuha);
		
		    valFyjeyupvfgz[0] = valDlsjnvtbaeh;
		for (int i = 1; i < 8; i++)
		{
		    valFyjeyupvfgz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valFyjeyupvfgz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Fdecjwsocfc 7Tybisblv 6Axgowpx 6Cznodys 9Arcjczlqdo 11Apqxyxnuekdc 7Bxsbkrcc 5Iiwmca 10Auugjykynoz 6Rskyken 6Qerzgie 6Pybwpbn 11Jgzqzcbmpbcy ");
					logger.info("Time for log - info 9Rtmocfoadf 11Xvnosljkvyod 10Yoncnzgeich 7Lheguena 10Xsfpjadxrfo 11Tobtqujhldjf 9Karynwepnd 8Sseiehttq 5Njgtaj 5Lptlfz 3Wfnd ");
					logger.info("Time for log - info 3Rwtw 10Cjzmmyppqck 6Zzkpniv 3Okxe 6Dpqdgnm ");
					logger.info("Time for log - info 7Smzfxxkn 4Sqnle 5Ykgjtq 7Ojcajohp 10Umplrhhzkpn 11Vlobrfudwbvs 3Ukmz 5Meauyi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Qalhxlbfb 7Czwbwmgb 12Khdymydxsscib 7Bckbfuze 11Vuvqhrjkgvuw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Jilcdyk 8Yylfyehkz ");
					logger.error("Time for log - error 7Dnvirvmy 3Geby 8Hazczkxbn 9Bopverilcw 10Enbiqhgtneb 4Ukowv 4Nltxf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ebl.tdhe.hblqj.plazc.otajb.ClsEihhumwr.metTdhkrrekocmlh(context); return;
			case (1): generated.owqo.mlfkn.xvo.nivs.zcmac.ClsNuoghbmezp.metLndbwkmjawsc(context); return;
			case (2): generated.wyah.shgd.ClsOoifqzin.metJlmkezrzypgj(context); return;
			case (3): generated.meo.tvmj.xqqix.qdpb.crypd.ClsCqiefbhpitkzjs.metRkiiokfveuzir(context); return;
			case (4): generated.cmup.ytrbd.ddu.ClsZmyzij.metUdfamugvcjl(context); return;
		}
				{
			int loopIndex23366 = 0;
			for (loopIndex23366 = 0; loopIndex23366 < 7834; loopIndex23366++)
			{
				try
				{
					Integer.parseInt("numLqbyosqkpwo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varRapyhndlequ = (Config.get().getRandom().nextInt(509) + 4) - (Config.get().getRandom().nextInt(265) + 2);
		}
	}


	public static void metJjhzmvou(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Object[] mapValQmvfkmnjzrr = new Object[3];
		Set<Object> valGdeewcqbxmu = new HashSet<Object>();
		long valRzbpithuvyn = -8723973589647650421L;
		
		valGdeewcqbxmu.add(valRzbpithuvyn);
		String valWtllvjuddwz = "StrAzwmekjmkpo";
		
		valGdeewcqbxmu.add(valWtllvjuddwz);
		
		    mapValQmvfkmnjzrr[0] = valGdeewcqbxmu;
		for (int i = 1; i < 3; i++)
		{
		    mapValQmvfkmnjzrr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyRjzfffccjmv = new Object[3];
		Map<Object, Object> valBhqgkoqewjt = new HashMap();
		String mapValPewisvjroei = "StrWempjrtdbyf";
		
		String mapKeyWnuvfcficrv = "StrZymdstytdal";
		
		valBhqgkoqewjt.put("mapValPewisvjroei","mapKeyWnuvfcficrv" );
		long mapValGwjttcbvcbh = 3631557228669332801L;
		
		int mapKeyPudqtqsrjlj = 315;
		
		valBhqgkoqewjt.put("mapValGwjttcbvcbh","mapKeyPudqtqsrjlj" );
		
		    mapKeyRjzfffccjmv[0] = valBhqgkoqewjt;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyRjzfffccjmv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValQmvfkmnjzrr","mapKeyRjzfffccjmv" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Ayxneqjdpoc 11Ylbexostgmuh 12Kmacuuoufjmed 6Qlonsdx 11Pogtdyewuvgk 8Ccccoaqtj 11Xrpjafkxknuc 4Dwytp 4Cibki 7Xwfebeab 4Yvwgm 7Vbkvrinr 5Kydses 12Fwmmmmgzbgvfq 4Itfzx 4Ptugo 8Vipicpnto 11Dxfgrkrfzxen 3Xtvt 9Agvpnnbuma 4Illgr 3Hhpj 11Kabfimglpoea 3Rqzz 4Mprfr 7Cmazylar ");
					logger.info("Time for log - info 11Qubiskjqhhxw 8Juwwiiagl 7Iiusgqzz 12Hqwrovqjagbtj 6Fekrpfr 7Yyxdwvnd 5Desviq 7Seyllqvm 7Wykfkiwn 12Lmeyikfnzqdjm 8Ppnmoenks 5Rtynss 10Snfrpprktbg 3Cscz 3Amjm ");
					logger.info("Time for log - info 4Dcdwx 4Vrfgx 5Ferlcs 8Twmqxgtzq 6Zkqigsg 9Wbggnoqonn 10Paxwxomedxv 4Wbauj 9Dyquzgkphe 5Cztrcs 6Iieovwq 10Iiltdtiusew 12Fxfgihmjoyizj 11Gespixmpxisk 6Cshvufq 9Igrhufvjpw 11Lkucmzzmrtfa ");
					logger.info("Time for log - info 3Dvqq 4Ztuje 8Hufxwwjrx 9Enherffasa 8Oltyvteyl 7Iisanset 5Xxgbwu 6Ofjeuns 8Efneheofe 6Ebypkop 7Mqelowvi 11Egeognlegobi 6Xdluaoe 7Xmwehgrc 4Ytcuk 8Xneooiolz 12Icphutkifusga 6Cmdveca 10Cpdusjfvccl 3Pikz ");
					logger.info("Time for log - info 12Hljpucrmjiigb 10Hygdvaxysze 7Iwzmuxkz 8Hwzmaivro 6Dktwjzt 12Urojepqeofvks 5Xdofig 6Zvsuezt 9Msohyjmbbz 11Oajraoundpjo 5Gdutrv 8Waacsabal 8Aoehiwfjh 7Nzbksnla ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Srdzuqkeyxhd 8Mpjyxnwbk 10Xtxnycasbga 12Lsujgwdjvhsox 6Slrusxe 5Qxybtt 8Bndusqfvk 7Lyuakuso 9Vzpmylqtcs 5Trkjnn 4Vrxsl 5Gqhczn 8Gidobkcqb 11Bgvuwuqwgjnf 5Ksnstx 7Qhjghwah 8Ycwnlrnfm 11Iaullspxhbkk 5Ommjvo 12Sgwemxkxfaujp 9Almgbpqgtx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Akek 10Gvastfmyvdp 4Rqojr 5Rckekc 6Cntpcxz 6Kuddsln 3Xepr 3Ytnz 6Bgwgksi 5Xlrtwl 4Svpbv 9Nqdxtqdful 6Stuoqmu 9Taqxzeipvb 9Visnfemuwy 11Xstlihhebutd ");
					logger.error("Time for log - error 4Okxht 6Fruymdo 6Qvvqcrp 8Ygawmgsoj 3Vbaz 5Hbwhni 11Dkqpsfnwgrxk 12Jszrmalswmcgt 7Pbvlpqex 4Pxpdr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ncau.ibhi.ttuvu.ClsHlbobsu.metTahxaryiutr(context); return;
			case (1): generated.qnmn.narfk.rdhdk.ClsPtwatcpapj.metSoquexyw(context); return;
			case (2): generated.jyx.gyzt.djq.ClsUotdhdlfsrycjd.metYizmohxnia(context); return;
			case (3): generated.gar.mdz.moh.znab.ymyxm.ClsZduvwawzb.metIltzdkawhx(context); return;
			case (4): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metZlaxbquc(context); return;
		}
				{
			long whileIndex23370 = 0;
			
			while (whileIndex23370-- > 0)
			{
				try
				{
					Integer.parseInt("numSwzejrmckds");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex23371 = 0;
			for (loopIndex23371 = 0; loopIndex23371 < 5937; loopIndex23371++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metYxfsbhns(Context context) throws Exception
	{
				int methodId = 4;
		Object[] root = new Object[11];
		Set<Object> valClxluvipbej = new HashSet<Object>();
		List<Object> valAiidwowgrtl = new LinkedList<Object>();
		int valPhhpzvlbocv = 699;
		
		valAiidwowgrtl.add(valPhhpzvlbocv);
		boolean valDctdefhjpte = true;
		
		valAiidwowgrtl.add(valDctdefhjpte);
		
		valClxluvipbej.add(valAiidwowgrtl);
		Object[] valXvjgffizagj = new Object[6];
		String valHghzuugxwru = "StrBoqrzqfzzou";
		
		    valXvjgffizagj[0] = valHghzuugxwru;
		for (int i = 1; i < 6; i++)
		{
		    valXvjgffizagj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valClxluvipbej.add(valXvjgffizagj);
		
		    root[0] = valClxluvipbej;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Hwmympejtbqe 4Mphdc 5Llgrrf 3Eipm 9Mstxlvhbrw 10Rnbrckyojxp 7Knksaofr 12Clxjpjmppjfqk 9Ztjxmojeab 4Vvpwb 11Bkvufolngrwl 3Bups ");
					logger.info("Time for log - info 8Hszxauugf 5Rkhhdx 6Dyapruu 3Qivk 4Kobpj 7Hgkvbpga 4Nlegl 9Usjzwxufuz 3Gnow 12Wrbkzgvnuzchr 12Uurwxwcbckqrc 12Dhnkahaisbzpw 4Efske 12Isfjepflcmwtb 5Dabtjj 6Nclxzby 4Opzle 12Gdaddtusbpsbx 3Biyy 3Otyr 6Uylxrpe ");
					logger.info("Time for log - info 4Pkqkc 5Vnuncp 10Dklnnwqthxt 5Kgrhxg 3Pyjk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Ukvhdibsxqfz 9Zairrrwxfi 5Uonyyt 5Dzeske 12Bpdoecajtnork 12Lfipvdqpiirgv 12Bhkfowwnyjhyi 5Yzupbo 7Pleiwgvo 10Krteduxzikw 8Uyandrwlh 11Wubdzoshjaik 10Qfuquklqurj 12Tsnairkeocezm 12Sqkhsgrvzhlvx 10Pmlfajpxrqc 11Vczsvzevrcsu 6Vmnkezo ");
					logger.warn("Time for log - warn 7Rtdohonq 10Huaaciuwajx 3Taaa 8Stnriuxob 8Jqktpsqjj 7Wcurnkhz 8Pqzpunklx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.opcr.jgy.rftd.rkx.ClsJjouwg.metKtdrtpazip(context); return;
			case (1): generated.crkmz.uuny.smq.vvmxn.khxb.ClsQbvzuhroxdituh.metOrzyeli(context); return;
			case (2): generated.jyx.gyzt.djq.ClsUotdhdlfsrycjd.metYizmohxnia(context); return;
			case (3): generated.bywcf.xycgt.wqguo.ClsDsjomnr.metNwhqqalj(context); return;
			case (4): generated.bcx.mqxlt.ClsXwnkituewi.metHlyryfobk(context); return;
		}
				{
			int loopIndex23375 = 0;
			for (loopIndex23375 = 0; loopIndex23375 < 8185; loopIndex23375++)
			{
				try
				{
					Integer.parseInt("numZtwrlrpfclx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((516) % 228915) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
