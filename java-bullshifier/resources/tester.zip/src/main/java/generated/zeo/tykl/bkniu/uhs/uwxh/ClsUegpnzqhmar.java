package generated.zeo.tykl.bkniu.uhs.uwxh;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsUegpnzqhmar
{
	 public static final int classId = 222;
	 static final Logger logger = LoggerFactory.getLogger(ClsUegpnzqhmar.class);

	public static void metNitnfqpe(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valQbaosaftbvu = new LinkedList<Object>();
		Object[] valNzcnvxpclml = new Object[4];
		boolean valJwrlcdtatvj = false;
		
		    valNzcnvxpclml[0] = valJwrlcdtatvj;
		for (int i = 1; i < 4; i++)
		{
		    valNzcnvxpclml[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valQbaosaftbvu.add(valNzcnvxpclml);
		Object[] valBictmdgzdus = new Object[10];
		String valFgkxaywxeve = "StrTwttidjadut";
		
		    valBictmdgzdus[0] = valFgkxaywxeve;
		for (int i = 1; i < 10; i++)
		{
		    valBictmdgzdus[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valQbaosaftbvu.add(valBictmdgzdus);
		
		root.add(valQbaosaftbvu);
		List<Object> valZvhyxakflos = new LinkedList<Object>();
		List<Object> valBqniwyjedjw = new LinkedList<Object>();
		long valZivuhnixuty = 4230506832952757887L;
		
		valBqniwyjedjw.add(valZivuhnixuty);
		long valDezwqgtjyrn = 4344930350673026798L;
		
		valBqniwyjedjw.add(valDezwqgtjyrn);
		
		valZvhyxakflos.add(valBqniwyjedjw);
		
		root.add(valZvhyxakflos);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Ljoeeztlzj 10Gvwstcftfcw 11Lxuiotbjewbz 8Pdrkyriek 11Nywvgyjomemd 5Nxpjej 4Kyikr 7Deahasku 6Bncvozw 5Pxyyef ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Fjjj 7Oyaabhgz 10Djflczjuuye 4Tvtzu 4Vnfzn 10Jhfcebdoevf 4Emjeg 6Iuhaisi 9Rdjbzvxotw 12Zjkuvxufzfgvf ");
					logger.warn("Time for log - warn 7Ndxcyycn 7Ehwgeove 8Hlkmbioko 4Xqqay 12Xibmwvgdgygag 7Llyjfoxa ");
					logger.warn("Time for log - warn 9Wqtrmyqfeo 10Wiwgypmzexk 11Ptrtrzotlsrg 10Vkgtwfehrdc 4Htjyu 6Vqkngry 12Oezxfzucejoau 6Pixdpcw 12Wuwsehqfmoght 12Syokkguctdrpx 4Fsnvj 6Pbliugo 6Fegfayj 5Mlumfg 4Fpgme 3Aiph 6Mtetmnn 6Nusrdir 11Iyfwxqdjsfwn 8Baxwzcbfg 6Cihvwjv 9Qqhyiynayu 4Mvvfn 8Zjjhdcdso 9Jbgbnwrysz 6Rrbenqz 6Ywfiyqr 6Rzvpecw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Lsonruq 5Dgfgwk 8Younvazoz 3Rxfc 5Cfpezn 5Jfhksa 3Bexq 4Msgdl 6Npwpmso 6Cjnbapx 3Fftn 10Zqtnyjzvpfi ");
					logger.error("Time for log - error 12Jejuqywvqfvyu 12Naocfldgnyqpy ");
					logger.error("Time for log - error 12Lcdjzuvaybxgp 9Oadnccacbf 9Obtgdcmpgj 12Feeyeizqbfksh 6Cefkams ");
					logger.error("Time for log - error 8Klshtbjph 11Yurvmxbhotdj 3Lecy 5Bsnccc 3Rkhk 11Dtkrlxjoixzh 12Hfbieixqujrem 9Mnhpmuswrm 4Peklt 12Nutzprkhhmliz 4Mniux 9Nhgsqtatvf 9Smayqohkym 6Jezvbar 7Ljphplty 7Frrnrjli 9Fadtlrvglm 11Uktdlfgvazpw 3Iwnc 11Rvvrmcwwnrus 6Ddkmnnd 10Mvsmrsdsgdq 7Dkfddjhn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wunj.xtrc.rfx.aikz.yopv.ClsTejixmzc.metAhxfdsezzruvtx(context); return;
			case (1): generated.pfjp.usowt.ClsIsioyesmm.metWvpjrpagibthng(context); return;
			case (2): generated.qpe.ifudp.xgatn.jzg.qau.ClsJymdeqopgpbo.metZmvopmy(context); return;
			case (3): generated.rzy.sppai.eju.hupq.ClsPjendhgbojpy.metExrdz(context); return;
			case (4): generated.hwl.fctgz.mzax.ClsSzkfy.metZexvyznlkwgy(context); return;
		}
				{
			long whileIndex23948 = 0;
			
			while (whileIndex23948-- > 0)
			{
				java.io.File file = new java.io.File("/dirNbclqnzehhz/dirYiogspczgmq/dirVjrtwsxdxec/dirQbkynkpvrjx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metVjrdqy(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valAsuojicgryj = new LinkedList<Object>();
		Object[] valHpzyjhecqma = new Object[10];
		boolean valWjqijpettfy = false;
		
		    valHpzyjhecqma[0] = valWjqijpettfy;
		for (int i = 1; i < 10; i++)
		{
		    valHpzyjhecqma[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valAsuojicgryj.add(valHpzyjhecqma);
		
		root.add(valAsuojicgryj);
		Map<Object, Object> valZpjjlfhpxre = new HashMap();
		Map<Object, Object> mapValCpupaiishnb = new HashMap();
		boolean mapValXrkiwqwqcil = false;
		
		boolean mapKeyXrqtnmzotvz = true;
		
		mapValCpupaiishnb.put("mapValXrkiwqwqcil","mapKeyXrqtnmzotvz" );
		String mapValTfemrwyhoqx = "StrXqheqofsact";
		
		String mapKeyZszgikkaiov = "StrCjvfrvvgghd";
		
		mapValCpupaiishnb.put("mapValTfemrwyhoqx","mapKeyZszgikkaiov" );
		
		Set<Object> mapKeyIgainrokclf = new HashSet<Object>();
		String valEledzzztzps = "StrFsxpjgdkzpq";
		
		mapKeyIgainrokclf.add(valEledzzztzps);
		
		valZpjjlfhpxre.put("mapValCpupaiishnb","mapKeyIgainrokclf" );
		
		root.add(valZpjjlfhpxre);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Nbqfmsdzrcvg 8Xuvqumtbf 9Kprrtidruq 3Udgq 6Rfwgwil 7Tjhpolrj 4Iwvgu 5Euvhqn 11Rtuswluqqwyx 7Nzgtvcrx 8Ykhgpfmom 12Zkfxgxujvshwq 10Eionllhujbb 7Qwlunrgc 11Cbftexmfdhal ");
					logger.info("Time for log - info 8Wvalynsxh 12Ehyuwcqsbhycz 12Frxbnqpepccom 4Jrosx 10Lpsqxsmrwjs 9Zjxnsbphex 8Bgzftqcus 9Gvyktqqkqo 8Kqkzsqzqv 5Zlirjm 9Zxmhsnbvkz 11Noqwqfawqzkr 7Mgkmkuch 5Djreua 7Qelgxjbk 8Mnuvjfbwd 12Mawnufehfwzid 3Bkei 10Mxvepejczep 7Zdiugxps 9Icwtxouhoz 4Hxoma 12Twxztbbwltyze 5Vmuyvr 12Tiiupzwijalfr 9Uocbojkdjh 8Npkyiafcz ");
					logger.info("Time for log - info 7Jehxkuzs 8Gznjxfeup 12Zzxwoeetiqzue 10Vmvqdzhoykt 12Ngvumprmxmfln 9Xznhiraveo 11Gitqvqlqyolt 9Dxylxiirjm 12Cbrmofdnxibzm 3Kyjm 10Qzvsrkwznee 5Hfpbit 12Xbszdxtryyxex 3Dofu 10Ozqekedklxq 4Ugyig 10Trregmrswze 8Bbdzzyzjt 4Oylej ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Wqupomf 4Awcvl 7Pglgbnap 5Dbueot 7Uhpbifsj 6Xonafvs 6Ngbafws 8Lshcrekxz 11Jwdljoczmwgf 6Cfmsazb 10Uendpusizbp 3Njmh 12Rldeqozovndkj 5Eydtby 7Icmsbynb 4Tbjyd 4Fiblk 6Mdqrxri ");
					logger.warn("Time for log - warn 9Lplajtwnaa 4Ixhzj 5Nnhhud 3Amuw 8Umogbbsrr 4Xtuoj 3Pvtd 9Rogeqyrktt 3Wvpi 9Iafaercjis ");
					logger.warn("Time for log - warn 7Bimtbcuf 3Rptr 6Bfsivrb 10Rscqtzroszl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Wrgnicwstyvy 6Swvwald ");
					logger.error("Time for log - error 8Avcpodpnp 8Wdioghswm 6Hfzlqyv 10Jsqmxplonar 10Wmzrdryuzzj 10Qdhpmtjblza 6Kxondor 11Opcijufbtrhs 12Tpesbhdakthzz 6Hphigzd 6Iunexef 6Rbphwuo 4Rxrlo 9Lkkcxajhpl 9Lezkafelkm 10Mdldpnkbyhx 3Dpdv 5Umpxgj 3Cbez 5Jggerw 9Bjymbqnegi 4Uwyto 4Cidtz 5Gpvecq 7Ylviwuzt 9Cqnxoocgox 9Uiswtvdhvl 6Jywjfyv 8Oadvtplkg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lmq.wwll.mcjoz.ClsBqjxdpu.metGccfwaiyfrrux(context); return;
			case (1): generated.flvo.tuwfx.wlpxx.jysnd.tuk.ClsFuuvt.metYllionx(context); return;
			case (2): generated.zsia.unbq.ozcif.caj.yiysy.ClsRbxlkiybibs.metYfrggz(context); return;
			case (3): generated.yha.jonx.xbh.ClsSzqha.metXghecpfgsh(context); return;
			case (4): generated.exa.yssf.ClsHuxmu.metLxxkvqloasqtd(context); return;
		}
				{
			if (((4825) + (4507) % 448492) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(819) + 6) % 218762) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
