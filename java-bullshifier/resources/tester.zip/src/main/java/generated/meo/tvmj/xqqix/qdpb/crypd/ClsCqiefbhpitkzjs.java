package generated.meo.tvmj.xqqix.qdpb.crypd;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsCqiefbhpitkzjs
{
	 public static final int classId = 315;
	 static final Logger logger = LoggerFactory.getLogger(ClsCqiefbhpitkzjs.class);

	public static void metRkiiokfveuzir(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValMaxmytofxxf = new HashSet<Object>();
		Object[] valRdgyltfbknb = new Object[8];
		boolean valOopwxmickjf = false;
		
		    valRdgyltfbknb[0] = valOopwxmickjf;
		for (int i = 1; i < 8; i++)
		{
		    valRdgyltfbknb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValMaxmytofxxf.add(valRdgyltfbknb);
		Object[] valFzkmtsrmzfz = new Object[10];
		int valHlswlinrkma = 107;
		
		    valFzkmtsrmzfz[0] = valHlswlinrkma;
		for (int i = 1; i < 10; i++)
		{
		    valFzkmtsrmzfz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValMaxmytofxxf.add(valFzkmtsrmzfz);
		
		Object[] mapKeyQyiwjynibvi = new Object[3];
		Set<Object> valHkfuijdgklo = new HashSet<Object>();
		String valAjrygqbjmye = "StrYknjtmaziwy";
		
		valHkfuijdgklo.add(valAjrygqbjmye);
		boolean valIisidhaqdmn = false;
		
		valHkfuijdgklo.add(valIisidhaqdmn);
		
		    mapKeyQyiwjynibvi[0] = valHkfuijdgklo;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyQyiwjynibvi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValMaxmytofxxf","mapKeyQyiwjynibvi" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Baib 5Xyxwqo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Vvtvhfgy 12Vukdvjdhqwyoq 6Reujtqu 3Fphy 3Odex 6Gpxsliy 11Hyhuapnkxhjo 6Dybqjzs 11Edxqyovxitnj 9Epiaksieag 11Xnutqgzuockm 9Nculfiuhyf 7Krbqbxxt 10Cfoiobfkdvh 10Xzixflkklqa 9Uaoedybzeu 4Uhmdf 7Zonfevlv 7Mrslbyxh 8Xnbgmeqdu 5Jmsinw 3Jigm 11Phrtvpmcyzee 9Pfqrppjndf 7Tcqojpwd ");
					logger.warn("Time for log - warn 7Odnvxqfv 8Pqrfsuiao ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Rqibnkuffx 7Tjsgupvk 5Sdoqhh 7Qsbjccsr 12Fdumbyjzltktq 7Woentalf 3Fhat 5Mgwbxe 6Bycizwg 3Wwkx 7Oueftvsd 9Jthmgljhmz 5Isnasp 11Dmnnvayaludo 12Vpqdlejaxkqzk 3Anmb 3Fhlv 12Mlgtfvrdagavi 7Szbcyymm 9Rvlmdsntqe 8Egixndpbz 9Waqjhfnrmh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metNjrouzbt(context); return;
			case (1): generated.gfhvs.nuhuq.qbk.rwbku.erqpl.ClsOuzdnnqrt.metHwnbcj(context); return;
			case (2): generated.budq.anwwr.qie.tcx.ClsAvdrojvr.metVuphivdf(context); return;
			case (3): generated.lzrmm.bjgfs.ClsQdamrbuivuq.metUnbxmbilwl(context); return;
			case (4): generated.vqvzb.mlzv.dxgr.ClsUgxxgr.metEqbgkl(context); return;
		}
				{
			long varYtmuugsaqrp = (Config.get().getRandom().nextInt(866) + 2) * (1711);
			int loopIndex25353 = 0;
			for (loopIndex25353 = 0; loopIndex25353 < 1273; loopIndex25353++)
			{
				java.io.File file = new java.io.File("/dirWuqbieqadqk/dirWbxmwfxnhad/dirOmlymoztzdy/dirAeidmdkhrrd/dirXoxmqgkgiho/dirBuxermhopwh/dirNkfhdzccgon/dirNcgqifdbmgf/dirPckfrmoeybp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((Config.get().getRandom().nextInt(283) + 3) % 975043) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(308) + 3) % 646793) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirUfojrdgemdg/dirMqrrxtotmbw/dirVcqkuqskwej");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metNfeqruksvkz(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valNqcnouuccob = new Object[7];
		List<Object> valRxwpkkxfzvt = new LinkedList<Object>();
		int valPgmapcrlmlk = 775;
		
		valRxwpkkxfzvt.add(valPgmapcrlmlk);
		boolean valNkxabtchtlw = false;
		
		valRxwpkkxfzvt.add(valNkxabtchtlw);
		
		    valNqcnouuccob[0] = valRxwpkkxfzvt;
		for (int i = 1; i < 7; i++)
		{
		    valNqcnouuccob[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valNqcnouuccob);
		Map<Object, Object> valAfautqrsppn = new HashMap();
		List<Object> mapValHvkculksnac = new LinkedList<Object>();
		boolean valSqwchymtnnr = false;
		
		mapValHvkculksnac.add(valSqwchymtnnr);
		boolean valFkinvxzpeau = false;
		
		mapValHvkculksnac.add(valFkinvxzpeau);
		
		Object[] mapKeyFolzagkdtwd = new Object[6];
		boolean valVobrhyvhtft = false;
		
		    mapKeyFolzagkdtwd[0] = valVobrhyvhtft;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyFolzagkdtwd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valAfautqrsppn.put("mapValHvkculksnac","mapKeyFolzagkdtwd" );
		Object[] mapValMragczdoxmj = new Object[11];
		String valDjyfofnjemb = "StrUsfbuywemit";
		
		    mapValMragczdoxmj[0] = valDjyfofnjemb;
		for (int i = 1; i < 11; i++)
		{
		    mapValMragczdoxmj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyNagfnuuriyn = new HashMap();
		boolean mapValZpfmxqajakm = true;
		
		long mapKeyOmmvqhsrbjn = 1911668672460844636L;
		
		mapKeyNagfnuuriyn.put("mapValZpfmxqajakm","mapKeyOmmvqhsrbjn" );
		
		valAfautqrsppn.put("mapValMragczdoxmj","mapKeyNagfnuuriyn" );
		
		root.add(valAfautqrsppn);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Mnpeohbcfxsmk 5Zruqek 9Biebrrsqet 10Zpftpmeyurr 5Icaxlj 7Dobnlfaj 8Zjckdfpvm 5Ptmshx 9Fnpcetkbxg 3Qpzn 5Cbfxtx 12Mhpcbqmurktlj 7Dexoyyaq 6Iqhlbds 8Ujidylmqo 5Ckagte 8Apmzjdilm 10Shxpjjekxph 6Sesuftq 10Wgnkwwfuamo 10Abgwjthlvoq 5Cysbmg 4Ttayn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Xraeqmryveq 5Cpafhb 3Teeu 8Ekwrhjbxa 3Vsrm 11Qlxrmhkjghoc 5Gtengr 5Fdnbel 5Ssevzh 4Voqfw 11Ndcirpxwgtzc 11Shkitlfbrzrv 11Zxysnxuhktfq 10Taghhbrxdkp 6Efxxmcg 5Nkjymq 10Fidirsbeexg 10Pgmlmovxvds 11Yvpdussnvsea ");
					logger.warn("Time for log - warn 11Frzomfxytaco 11Cucqirsdravo 10Ngmjcvepkxn 4Kldey ");
					logger.warn("Time for log - warn 10Zwfflqbvmvr 11Dxgwtwvuiceh 11Znudoqttuvsz 3Jfga 10Vvkjbxwqzlc 9Kycflmjkzz 12Swbiinfqddapf 6Dxxjqvo 5Ahzwxa 4Bjjyz 8Xthxezwzu 3Ajxm 6Yxnfawv 11Uhkmhyzqmkxb 9Ldbujlkzgn 5Zgpzpr ");
					logger.warn("Time for log - warn 11Tswcljyzlnnc 3Jpxr 5Juxcis 11Baqbeywxavya 11Oojivtjwjbvg 8Zmrmfhath 11Znmvkrkdkxxn 10Amcrufwmqmf 7Vntlcomk 6Tuffopl 4Cfmoa 6Crhwtbr 6Lqzoezx 3Yoyy 12Fuekrxutnedmq 10Cusvqcsdavk 8Mdongjxdo 5Zmfrhx 9Zosbgjcsqc 5Tjfdik 10Knsvltlpyyw 11Relanxgetobe 3Bpgd 7Dmyivvri 11Xrstrkivyjff 10Myaptiyufph 6Mmquixk 10Muosxwvpowe ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zxd.ssm.wrmu.ClsZpxwrsfothfgl.metAomskmmjub(context); return;
			case (1): generated.xqnb.haff.rrb.lurge.ygwj.ClsNrgsacrzyefzg.metXouqbpti(context); return;
			case (2): generated.ecksk.wvb.ClsNtqfbmlui.metOzgvgztdgxgwck(context); return;
			case (3): generated.ajbel.dvbe.pmx.gfhen.qjvpo.ClsFwkvrnv.metJxbxbolmcyk(context); return;
			case (4): generated.phtjf.bzplf.izqn.pznr.nxe.ClsUtlzborau.metFkmmdnkjyn(context); return;
		}
				{
			int loopIndex25362 = 0;
			for (loopIndex25362 = 0; loopIndex25362 < 4926; loopIndex25362++)
			{
				java.io.File file = new java.io.File("/dirGfomefkoeyd/dirSenefgmqjuw/dirCgxbpwmcgve/dirCqtnowvvcig/dirRhpyfwuscuu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex25366)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metPmgbkkg(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValTjxdhdtphhg = new LinkedList<Object>();
		Object[] valWlmylriiehs = new Object[7];
		long valYgjzqpxueqo = -4426267181174471589L;
		
		    valWlmylriiehs[0] = valYgjzqpxueqo;
		for (int i = 1; i < 7; i++)
		{
		    valWlmylriiehs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValTjxdhdtphhg.add(valWlmylriiehs);
		Map<Object, Object> valMcfmazjsrnw = new HashMap();
		boolean mapValSjgxuiujlvh = false;
		
		int mapKeyUqskumaeddw = 405;
		
		valMcfmazjsrnw.put("mapValSjgxuiujlvh","mapKeyUqskumaeddw" );
		
		mapValTjxdhdtphhg.add(valMcfmazjsrnw);
		
		Map<Object, Object> mapKeyWuutlxfrnjh = new HashMap();
		List<Object> mapValXtwzblhtcny = new LinkedList<Object>();
		boolean valAyaukgughgx = false;
		
		mapValXtwzblhtcny.add(valAyaukgughgx);
		long valTmrxnfueozj = -2764750115022818573L;
		
		mapValXtwzblhtcny.add(valTmrxnfueozj);
		
		Object[] mapKeyBdudntfqwig = new Object[8];
		long valYpuzykxsotw = 5527526840906545214L;
		
		    mapKeyBdudntfqwig[0] = valYpuzykxsotw;
		for (int i = 1; i < 8; i++)
		{
		    mapKeyBdudntfqwig[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyWuutlxfrnjh.put("mapValXtwzblhtcny","mapKeyBdudntfqwig" );
		Object[] mapValKbhcajfnqdu = new Object[7];
		long valIkiwpaqpeur = -1787809069523990232L;
		
		    mapValKbhcajfnqdu[0] = valIkiwpaqpeur;
		for (int i = 1; i < 7; i++)
		{
		    mapValKbhcajfnqdu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyEcernzrunpj = new HashSet<Object>();
		String valAtvrizeoevp = "StrZxezcsrgjie";
		
		mapKeyEcernzrunpj.add(valAtvrizeoevp);
		
		mapKeyWuutlxfrnjh.put("mapValKbhcajfnqdu","mapKeyEcernzrunpj" );
		
		root.put("mapValTjxdhdtphhg","mapKeyWuutlxfrnjh" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Ktxlgpqsbi 5Yyxkhb 4Dcypg 4Rbgzv 10Ickasgngkwh 3Rjlh 4Vlhef 5Ubnhbl 5Lbehga 11Wdukhixmiqga 4Molnm 8Rqtzbnkam 4Pezxk 8Hpbiegbyj 10Unfppexkewc 7Dyiebpnk 3Coyz 6Iqwijlo 4Puawo 4Rdnsj 5Aqdxit 4Zntfw 6Bnrcbdk 4Hacsd 4Grtny 3Jdwn 8Iteargrmi 12Szvrntdkxzvnn ");
					logger.info("Time for log - info 3Ycaj 5Ucxjyq 3Lsqg 12Ddwuwswarttnz 3Atek 11Exdfslxrksfs 9Ddddppthwg 10Ozskkjfgdtp 6Seqjyan 11Myiufsowicbd 10Bvaciagchwb 8Teuaruuis 11Jdwwfzmfeamd 8Okdagggsf 6Fdprcuw 3Bwdn 8Ogczvqnwp 8Xuptpemnh 12Pbtxgxqieaukf 9Bcmqzyqmco 10Ghupvzzgfhi 7Mdzotryv 4Ifbaz 11Pwhqrmnwtpvq 7Agtchvfu 7Dmjjhybr 10Wsagmwuuucw ");
					logger.info("Time for log - info 8Ccexexump 7Lplstzoy 11Rikiswgiqcsu 6Kdrzwac 9Npvronsnpe 8Yerujbado 6Rhqbgki 9Awyezvvous 10Dcnxnszkesd 5Whilrq 3Npfc 3Mfzs 11Kvkrohibhsib 12Wyzfkzrybiyfx 8Pcvhxwqfo 6Zunshjz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Vaoi 10Jleuhqrrtwa 5Svslqd 8Howbrdbse 8Wjiunmynr 3Lkmv 10Iwebxvrmwdn 8Awvplvbcw 8Kreukusze 11Hojbaotnvzya 4Qnslj 11Hxrwdubfkspt 6Supgypl 12Shjoizzaiamtm 6Hwkspcf 6Bbzlxrw 10Yqqtkovdlrg 6Ylvuftn 4Sswxm 11Fsgbwsdlpoox 11Jpobjtryxtza ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Einj 4Cfkxq 9Geocfhbrym 3Uyij 9Wuxjfowung 3Upaj 6Eraevpm 12Dyqgcjdpljhhm 4Uewev 4Irapc 9Dwslyujrvc 7Nkwcvibf 11Ytuuhjfrjmde 9Fcsvgvtvuv 9Qufiroqion 11Cjhxjfzmwjvh 12Stvabzbetxabo 12Xjpkaqicetwni 7Xnfoltmx 9Mmojmuepal 10Csubutzjlkd 5Dbbesi 4Udazn 5Hgcple 4Gzlqe 3Asaq 5Rcabtq 7Xansivdk ");
					logger.error("Time for log - error 10Vsdldtlxqgk 12Vyigpdtfltwyx 5Uflroq 8Psoerrqhc 4Rtlqy 4Pddjo 9Xqwhqksiwc 10Ywrdznqywmo 5Hjgltf 6Zjjodeq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ongb.lkxvg.dfa.pkoz.kbky.ClsZpuulcqafhvqyy.metOzbahhdicun(context); return;
			case (1): generated.cwxj.lmfzj.egfdm.ClsTwbdwdairow.metIdcqnnmam(context); return;
			case (2): generated.wvkuf.rvtq.kcgfs.vezg.ClsKfeffw.metVcvew(context); return;
			case (3): generated.bcx.mqxlt.ClsXwnkituewi.metHlyryfobk(context); return;
			case (4): generated.zadtu.owlhb.qsd.bfzb.ClsWgiwrqnvyw.metYrmyjlzzyyu(context); return;
		}
				{
			long varTxzurtupuyo = (4331);
			long varDxsopdqbswq = (2316) + (Config.get().getRandom().nextInt(599) + 1);
		}
	}

}
