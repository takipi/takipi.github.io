package generated.ldtgt.vdfx.cdz.lkx;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsLvvwnymti
{
	 public static final int classId = 483;
	 static final Logger logger = LoggerFactory.getLogger(ClsLvvwnymti.class);

	public static void metFkrjypkkw(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[7];
		Object[] valClfksqecjuk = new Object[10];
		Object[] valLslhlichjis = new Object[4];
		String valQfrukhcsqnj = "StrVqwnkbpeult";
		
		    valLslhlichjis[0] = valQfrukhcsqnj;
		for (int i = 1; i < 4; i++)
		{
		    valLslhlichjis[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valClfksqecjuk[0] = valLslhlichjis;
		for (int i = 1; i < 10; i++)
		{
		    valClfksqecjuk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valClfksqecjuk;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Boomntq 12Klvxjdddyxtiw 7Tmnhzjbg 10Zmdnnpmltfw 3Iozt 11Jegnulexumgm 5Nmdtan 10Lfrhkddlsat 12Vdtjlcnvqobuv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Olscgidaxonzp 5Vqglvf 12Oeajmdbjkynli 8Psuzpkkgi 10Beclosktjkc 8Ulqxrqsqn 4Ivvaz 11Adlhvdfghaic 11Whprpwmkqweh 6Gakcppx 5Owtomw ");
					logger.warn("Time for log - warn 6Iaxrdmj 3Ijti ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nrqfo.bwabb.mnp.ClsTzkbgaawvon.metUvsqh(context); return;
			case (1): generated.aea.iom.ClsOvjtnlwnmq.metKwdullewrqcq(context); return;
			case (2): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metSqibhmdisq(context); return;
			case (3): generated.jzpii.ixwl.ClsCvgimgq.metSxvhwbhsdlyr(context); return;
			case (4): generated.wkucr.ukst.umm.xsqx.ClsEjxfeypurpufwd.metWmlpl(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(444) + 9) % 865473) == 0)
			{
				try
				{
					Integer.parseInt("numZicuujfrsnr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metSmshnclxqxhvn(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValYvhnuibbvso = new LinkedList<Object>();
		List<Object> valLbgyoohgiqy = new LinkedList<Object>();
		int valQkzqfkwvvgq = 202;
		
		valLbgyoohgiqy.add(valQkzqfkwvvgq);
		
		mapValYvhnuibbvso.add(valLbgyoohgiqy);
		Object[] valUkxayjwbhtq = new Object[10];
		long valFcakskzexyj = 3198634010380984941L;
		
		    valUkxayjwbhtq[0] = valFcakskzexyj;
		for (int i = 1; i < 10; i++)
		{
		    valUkxayjwbhtq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValYvhnuibbvso.add(valUkxayjwbhtq);
		
		List<Object> mapKeyBzxwylcrkuq = new LinkedList<Object>();
		Map<Object, Object> valJlwjpmezoow = new HashMap();
		boolean mapValTvyvkmcvzgx = false;
		
		long mapKeyVjboyjbkxwy = 7690505258877671182L;
		
		valJlwjpmezoow.put("mapValTvyvkmcvzgx","mapKeyVjboyjbkxwy" );
		long mapValGcbvocrzilr = -1469011414162110420L;
		
		boolean mapKeyYudpdclpsno = true;
		
		valJlwjpmezoow.put("mapValGcbvocrzilr","mapKeyYudpdclpsno" );
		
		mapKeyBzxwylcrkuq.add(valJlwjpmezoow);
		Set<Object> valOkhdycsmgnb = new HashSet<Object>();
		boolean valHgiginpwszg = false;
		
		valOkhdycsmgnb.add(valHgiginpwszg);
		String valWlbohuarxvo = "StrHbsgdjwqbqw";
		
		valOkhdycsmgnb.add(valWlbohuarxvo);
		
		mapKeyBzxwylcrkuq.add(valOkhdycsmgnb);
		
		root.put("mapValYvhnuibbvso","mapKeyBzxwylcrkuq" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Skwkgdoq 4Qzkvj 10Vqevujvjuhs 7Wrrcyeub 11Mzyulhxbzuae 11Vugkzypnezst 5Zfnsnr 11Lugsocvxkgdf 5Ydpbhq 7Xulxjsno 8Oukrxvaja 10Mmweympxmkj ");
					logger.info("Time for log - info 9Updyvieuyy 11Fpbdxkfpgkyw 5Ufrizv 11Avmpgztxiegr 3Fevc 5Qyprsy 8Bivnxkyuz 6Yiabiie 6Zkqngvg 11Ldagfgpiuhgw 5Pseaon 12Ozstsoypxbgno 9Zufrrtrprj 5Dcupxg 6Bbqdzus 7Ohrsjvrv 3Rysg ");
					logger.info("Time for log - info 4Bfiqa 10Jzyyqfmgjnz 9Vvqstqpwdf 8Efjijgllg 6Eyixftr 11Wbtcpysqbfsk 5Banwlx 11Cueobrzfqzne 10Bpytehbzxee 3Yyss 4Mweah ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Yuqbqsbubhsr 3Keyx 11Iwnfdgasttix 11Csuwuvjwporu 3Mokk 12Onwrqonaxpwbf 12Wnznwzgvakxuq 6Bupfkro ");
					logger.warn("Time for log - warn 9Cnatsrhoic 6Kvpjlmz 9Hfjxlqftby 8Wholfjfwl 3Hdyd 6Ksknwvp 10Isbszragcmh 7Otttyqar 10Mwuuprykqqd 3Guav 12Yeqofzdrxastb 12Rkgyozzfhznrc 4Xfdgz 11Htjqvkzwvcfx 3Extm 11Ijcyqeqrqevm 10Wzkruypiojh 11Yrwmnuzlmzgn 9Ljzjzjwqhe 5Nbntao ");
					logger.warn("Time for log - warn 8Kqlandntz 7Uzubmrgl 12Wnhrgijajxrlz 5Owjsqo 10Roowkezeqrg 7Bhxjxatp 9Fvphshndqb 8Ylthujitr 4Zqefp 10Ptaplyhctvm 5Rmpsyj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Xnbzlbdt 8Sosbxxeud 8Fwnbzcpww 8Bhvkmnbiz 3Mcnr 3Vfqy 4Rtwbo 9Jljmzxherv 6Tbqxjdr 11Rntxllujwjck 4Zhnmq 3Drhy 9Ylmcoksyxn 6Hmvcufo 12Bvmdmukmzlrnx 12Etayelpazrxoj 5Tkhyyc 3Zxeb 4Bkmvv 12Gaoubrmcdlbmz 6Zxowhhf 5Bntllx 10Cfrjlhcqyks 7Xlehvbfn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bkbep.bjvph.skry.qijli.gfl.ClsFlycqobnxjszt.metGocmomhxeq(context); return;
			case (1): generated.reb.nzlh.ClsFjrtwsmg.metBqnzzj(context); return;
			case (2): generated.ukp.wkgj.kys.bbj.whcvs.ClsShqgniemg.metRrbombfiz(context); return;
			case (3): generated.wvkuf.rvtq.kcgfs.vezg.ClsKfeffw.metPqphlwkdbbctc(context); return;
			case (4): generated.afz.qen.lrlj.ClsTvxlbccvg.metWrkbglgpwrbj(context); return;
		}
				{
			int loopIndex28144 = 0;
			for (loopIndex28144 = 0; loopIndex28144 < 8313; loopIndex28144++)
			{
				java.io.File file = new java.io.File("/dirSdccqqdrhnu/dirTgsupmblypd/dirQwzxziwhgwj/dirLleyhyzwgop/dirLvciadjlvcm/dirOeactiomoft/dirRlhdwizwlzj/dirUetlxeweflj/dirRdpywdlpkqi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metOdzdjwutrxtvu(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[11];
		Set<Object> valWulmbecuayc = new HashSet<Object>();
		List<Object> valZrhtcqoqahe = new LinkedList<Object>();
		int valThypuukjpfo = 863;
		
		valZrhtcqoqahe.add(valThypuukjpfo);
		boolean valQzjlawioqnp = true;
		
		valZrhtcqoqahe.add(valQzjlawioqnp);
		
		valWulmbecuayc.add(valZrhtcqoqahe);
		
		    root[0] = valWulmbecuayc;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Jasrjvd 7Yhpzngun 4Lopab 5Ibcrjd 7Mbgxkeob 5Yuyefn 10Oyodlesrpic 11Swuufhevxnha 4Nkhkb 8Coaoqyjra 8Ownnumbbv 7Gqyzjpin 11Ubblntpaggvo 9Aaexrodaqn 4Iqpyj 12Ymzlsfzziwxlh 7Wzsydqxn 5Hhvvmu 11Jwdstnamnudk 8Lkbxqblel 5Vkqlle 4Vwfds 11Cpyljljjhxpk 10Buymbnhndxq 5Unhxdp 8Ejqcxsare 3Uszi 10Glxpdzkvutr 12Gwggzvfnxknfm ");
					logger.info("Time for log - info 9Vwxefkpari 12Dkldchfuhnhcg 8Bjrkualev 5Cjcapq 3Hvld 6Kdkgapx 12Wqwoewfeonpki 4Onvey 5Vqcboy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Aceuhasgn 3Euxl 9Hytmdrlfym 9Yyfugqwixr 12Mlbimtvlzyesu ");
					logger.warn("Time for log - warn 4Yhrqv 12Iryyezncxsejo 12Pdbrbgdbloqir 6Ajydvpb 7Qpokukcp 3Fafg 3Fnpi 8Lchmbxvat 6Vyuuguc 11Evipgfdpbnzc 10Yzvczveayqt ");
					logger.warn("Time for log - warn 4Hkoig 8Zegtrhncu 10Bkjvqzzltbk 12Lmbdkomrqbove 6Jgphwvg 9Zilhxloxbd 11Nrtddtliqwhw 9Hywzhozmcv 9Ftcsuctcei 6Xjuhwzu 10Zikaaggcsvh 12Irfknzrkmjhab 3Jxac 5Vsubga 3Jxkb 10Lxfjkwaxxnv 6Weefozp 9Etpfxggqvr 5Smlwxi 9Trdrgrdvnl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Azhefklui 8Zvzkbidxi 7Luchbmjm 9Qrhugqinqr 12Ifjtlyuizshmm 6Rncmxqk 9Wquivrmpsj 4Okwbh ");
					logger.error("Time for log - error 5Uehckz 10Cvplhnbdopp 7Rvrhbsmf 8Dreisrdoz 3Obvw 5Coswsu 10Fdwmjydzbsh 5Sufmvm 3Qkvs 6Xghtjwc 10Efscpmzvlqv 5Lnylfh 6Jxmegie 11Kfkojuudrfnj 5Tgxwft 7Dvnsfcrm 11Bvllkifgynkr 6Hwhzibr 3Ufkq 12Hifecvqokfgqq ");
					logger.error("Time for log - error 12Kdcpehjrrpcbk 10Zwloiyfzlzw 7Uyihstpi 6Bjyqosc 6Jghhnqe 6Niisrlg 11Upwfwoyceiyk 3Kkyi 5Eziygr 7Keuqvksz 5Qmgwjn 3Fdzy 6Ikzvczj 4Yuzip 9Ziffnuwwut 7Munjofhn 12Bbsdxvvmrycbi 3Ztfg 9Yqypbyricc 5Jtotty 6Hiefzcz 9Vgcvfdvzsu 6Vxrwufs 3Vevi 11Ntsvwynncyyu 12Wwbditcyabuqj 9Grzxbnavpq 9Uutsxcjfbn 10Qntnsdrtzyj 8Mtejplxno 4Tuxqw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yhl.ykh.hog.zsc.cal.ClsJuxvzfsp.metRcwieirx(context); return;
			case (1): generated.eyfa.ouw.cbeis.ClsNevyjjntax.metCphaxrmwdbbg(context); return;
			case (2): generated.gfiaw.wgvz.askqs.ClsGbqekumwdbwfn.metRznpltfgjhr(context); return;
			case (3): generated.npa.tuyd.ClsLxzuwxfsi.metVaqynjo(context); return;
			case (4): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metChpajwh(context); return;
		}
				{
			int loopIndex28148 = 0;
			for (loopIndex28148 = 0; loopIndex28148 < 7136; loopIndex28148++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
