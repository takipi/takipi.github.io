package generated.kfjp.bzn.mda.sfyxf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsAguszlzt
{
	 public static final int classId = 474;
	 static final Logger logger = LoggerFactory.getLogger(ClsAguszlzt.class);

	public static void metWsvlopnliexx(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valPzkivtqjxqq = new Object[9];
		Object[] valNistaddikzh = new Object[6];
		int valEtemjdbosfp = 876;
		
		    valNistaddikzh[0] = valEtemjdbosfp;
		for (int i = 1; i < 6; i++)
		{
		    valNistaddikzh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valPzkivtqjxqq[0] = valNistaddikzh;
		for (int i = 1; i < 9; i++)
		{
		    valPzkivtqjxqq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valPzkivtqjxqq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Cwgdpo 3Xhig 7Tsbzxpar 10Gadfapabzqq 9Ydcsuqsaxw 3Xxnk 3Ryfu 9Uyfjzpjtjg 9Gepjjaevug 7Ytndumrm ");
					logger.info("Time for log - info 4Tgerc 6Xbamvpo 7Iyijxxmp 9Dxxtyzmjdv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Kjyzywjxorbaw 12Uztcvdprmnuph 8Fquhmlwim 6Krmytfu 4Viohj 6Hmbygsx 4Afbhz 11Hgcapauqekpi 6Doopqsl 7Llruqyhp 6Qvukxkd 9Yrjjhsklci 4Pehjv 3Cxul 11Bgrryxycfzmd 9Liihunutrc 10Pqlhyzxjujm 4Bfchs 6Dxomurk 4Ziajv 12Yfkvyrwnnuyco 12Bybztjqaftoiy 4Aaldf 8Xawonlbgm 4Tijtf ");
					logger.warn("Time for log - warn 6Wqnxtay 5Yshage 10Qotukleadnz 12Drjonivnsqeoj 12Qjheypogwmuyi 9Bufxhcpnng 6Ntrajsf 4Ddjxp 5Ewudhm 8Rdmcziuzo 9Mcihwxinut 6Ufnusqy 3Jutl 7Fbxpcbvg 9Jzpbghekzf 5Fpwwyb 12Ladafhgcckfaw 3Ggwa 12Hojfegnepwlkw 6Zjuytsq 8Tlbyvrpvx 12Grsavvfrqoaff 7Jruhsbfh 3Euqr 4Vtvku 6Bkcyzsw 11Mwldmcssmztr 9Gdjerfxlik 11Ycwkmufhuibr 9Esfkzcxjxv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Mrxsuxzwcqd 3Qtwi 3Duua 11Mqwatkniamrm 7Kxqjqfcn 7Fimmtkpu 8Erzofserf 9Mkgabectbz 6Nhvvsia 8Fzwmcdsgu 9Yteimqjxsn 5Exqflc 6Jnceuco 11Hwttjagyfdzz 8Dzwuzbkoi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qer.bwl.ClsCbeyhqqy.metYolltwvxohl(context); return;
			case (1): generated.dvks.jsbpi.ClsXlatniflz.metIhawpoyjsfgfom(context); return;
			case (2): generated.qnmn.narfk.rdhdk.ClsPtwatcpapj.metNosih(context); return;
			case (3): generated.qzl.yonxw.xanna.lsvx.pese.ClsHtvngej.metFwbebfwdtycuk(context); return;
			case (4): generated.tcpo.xhov.ClsRfokukcdi.metFyxdxe(context); return;
		}
				{
			long varZwhxhamshmt = (Config.get().getRandom().nextInt(873) + 5) - (2404);
			try
			{
				java.io.File file = new java.io.File("/dirZheluqqurlj/dirCmgkdhbwiir/dirWubmljvttze/dirXmufqidrmye");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex27991)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numUqkbwqnqvbp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
