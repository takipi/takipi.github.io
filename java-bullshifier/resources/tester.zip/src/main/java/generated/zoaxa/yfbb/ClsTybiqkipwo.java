package generated.zoaxa.yfbb;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsTybiqkipwo
{
	 public static final int classId = 444;
	 static final Logger logger = LoggerFactory.getLogger(ClsTybiqkipwo.class);

	public static void metQnlswcnqbxmqgz(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[7];
		Object[] valIvtyaimgfvr = new Object[2];
		Set<Object> valHznjwrxepne = new HashSet<Object>();
		int valMompnkjuahp = 786;
		
		valHznjwrxepne.add(valMompnkjuahp);
		long valIjsdjxgajsd = 8944383162798769619L;
		
		valHznjwrxepne.add(valIjsdjxgajsd);
		
		    valIvtyaimgfvr[0] = valHznjwrxepne;
		for (int i = 1; i < 2; i++)
		{
		    valIvtyaimgfvr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valIvtyaimgfvr;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Vlknkvb 3Odpn 5Obiazb 12Htxudvduygkpk 6Nrhitha 6Xnfsjqt 6Tonsbjl 7Qbtxsflv ");
					logger.info("Time for log - info 3Xhvm 3Vyme 10Xbamokgborw 10Ghpiynfyefs 11Lcchamokxbgr 4Raysx 9Insnqjakwt 8Avnecnpxc 10Zxyzlzwpkna 8Shkrfkkbd 4Plucs 7Xqnnpisn 3Savh 4Qjrxk 9Xupididudk 3Ggbh 4Qelzp 8Zcjfliext 9Okskvduavl 4Ucypt 3Ofjy 6Ejustrn 9Oxzqgyywzk 3Qfsb 12Ezozqeufwpdcq 7Qqimzgzm 5Sklyxz 5Lwqotn 3Elmb 7Nprllmhi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Kanw 9Jjkfwndiwz 10Qvhphfidufo 8Hifuefsff 8Huwnclyry 11Bybhtyfkgwmm 7Adelggri 6Yfcamnm 7Abvyyggs 7Wzabkazl 10Kwafusdoqoj 12Rhswxoypoarxw 12Eorhcklyxvlta 6Yiaykcn 10Tpfdfiaulen 7Gglckkna 12Wlnwfinqjzcfq 10Uqakbbkevyl 5Hxtujv ");
					logger.warn("Time for log - warn 6Inlwbui 7Bzclzuba 11Cbcwtfzcaupi 3Uwht 6Reglcjp 7Tkwhiyfk 4Cqvah 6Zsnbbmx 5Dddvma 8Johsblbjr 6Zwzkbef 8Uilmllzgm 10Pbevcxlgtzp 4Pxohe 5Nyplgq 11Xjbxcqeykqej 9Xpuxwwkylg 5Vvoilu 6Clrtbuh 4Wowbi 10Nmqqdcxplxb 6Fgviwcx 4Vnbrf 11Wgdomqstxtrf 10Nmkoybtxvib 12Xrysposyecoux 7Cqhqrmuk 3Cghi 10Wefzbuazscn 5Vaztnn 9Lrgxxbkejp ");
					logger.warn("Time for log - warn 10Bkffusgildi 9Ztmyfgrrbn 11Bradfporqjmu 6Swclxhe 11Axjvwixtrruz 7Shdujult 3Xnzq 11Vqgaotadhyad 3Fbeq 11Lroyaykcidpu 4Hcncd 4Vridp 12Lvpbdxcgreelp 3Wglu 7Yhhcsqte 8Cgprckqrd 12Xzokumorzgqsv 3Rhzu 11Wovlruadaqkx 3Xxgy 9Flgwkjrlra 3Aajm 3Hhzw 4Zjruv 12Fvmhnzfxeuifh 10Gjddytazgdq 4Gugbb 6Xnbpnji 5Dsewhx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Raaxkzafypuq 6Ejgezcc 10Kdpddvrdbvh 12Pnnhmzwqdxhhd 10Nkseqidkhoc 7Jtkiptai 5Pteslv 6Elovdcw 10Noksypanekh 6Hobrtkw 8Wglzeztbv 10Bzdhvtnvqwd ");
					logger.error("Time for log - error 4Qsowc 3Gpjs 12Fhbkufgyrnvqm 8Unpjvwilk 5Mdkmof 12Rtfrpxbuvvswq 9Wxizdjtpwl 6Roovgzt 4Ikffl 7Fsddbvtl 5Lymifz 10Owxnnwnufyv 4Dmolt 10Ukoqhzavvxh 4Stsqx 4Tqhko 5Elpfut 6Yqlgtib 9Mylxkucmag 9Zaiodrnjiz 5Rpxfix ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.enb.ktdil.ClsEqcfzlhpy.metEbqhhysso(context); return;
			case (1): generated.gar.mdz.moh.znab.ymyxm.ClsZduvwawzb.metKctokpxapm(context); return;
			case (2): generated.jzpii.ixwl.ClsCvgimgq.metOrwgnhxbufju(context); return;
			case (3): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metSkbraqotkaceil(context); return;
			case (4): generated.blsj.gki.ClsOuhbksvj.metEkzrb(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(782) + 4) % 207149) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
