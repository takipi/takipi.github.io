package generated.obfi.prawn.asr;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsHvlzhrjejvoom
{
	 public static final int classId = 127;
	 static final Logger logger = LoggerFactory.getLogger(ClsHvlzhrjejvoom.class);

	public static void metTssprbwiuo(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valBthhohcceph = new HashSet<Object>();
		List<Object> valYshjcclrskc = new LinkedList<Object>();
		String valOxtsilerbtp = "StrWajambyffvx";
		
		valYshjcclrskc.add(valOxtsilerbtp);
		long valUgaoxipvzuf = -5675664760028758818L;
		
		valYshjcclrskc.add(valUgaoxipvzuf);
		
		valBthhohcceph.add(valYshjcclrskc);
		
		root.add(valBthhohcceph);
		Map<Object, Object> valKddkfrxlvqj = new HashMap();
		Object[] mapValTgdxvegxcfz = new Object[2];
		boolean valZoofnqapvav = false;
		
		    mapValTgdxvegxcfz[0] = valZoofnqapvav;
		for (int i = 1; i < 2; i++)
		{
		    mapValTgdxvegxcfz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyObeukzpzabh = new HashMap();
		String mapValOfmusporiit = "StrKmeqagwyrzy";
		
		String mapKeyKnmhwlggezb = "StrAphwrhrbfhb";
		
		mapKeyObeukzpzabh.put("mapValOfmusporiit","mapKeyKnmhwlggezb" );
		
		valKddkfrxlvqj.put("mapValTgdxvegxcfz","mapKeyObeukzpzabh" );
		
		root.add(valKddkfrxlvqj);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Kqfaoepu 8Hvueqskvn 10Xnzsfyjwona 11Qtrlyuohhorp 6Plyakdz 7Ywyhoode 7Sbkeiqcl 6Bormiek 11Jbbzddgtdajv 11Opmdgnyulwnn 12Ypvwkjvtpkraj ");
					logger.info("Time for log - info 3Xixb 5Ouiqpy 12Szofpyxcqqkki 12Mkaalzxydirco 9Fnnmhjukbz 12Vakokpbfjutcq 3Gnaj 4Kypjv 8Mddwmxwvx 4Urjzd 7Pxjdhego 7Cieaqrwh 12Iytzgibsswbll 3Jnvj 10Rwkibmuvnmf 9Qlimfzhgtg 3Otpg 5Omrnqq 8Hqpctcwxo 10Ctqqwvkmpxa ");
					logger.info("Time for log - info 4Akohx 12Jhfuxdltkwnce 5Ohmvte 4Qgcaw 7Xwgsbffw 6Cfshbnu 5Xnkckk 10Mwtnozwyect 12Obxdsivypagit 8Wbndbzgsp 7Uhuojnsj 9Auunfsixtp 7Drxqjfnd 3Gaya 4Xghzn 10Hqzrkycjzlb 10Zzsifaezbff 4Ldfwo 3Qjvi 10Iseicdfibud 4Uvbsa 12Giayohxwezaap 9Pmjlqhhunc 4Arhae 4Hjpyf 6Jjibknp 11Svupjhjzerlo 12Ksdsqliowjoig 8Kzprzaeqq ");
					logger.info("Time for log - info 11Snhmeofnwbyf 4Lfgqm 11Vitlabxejmiq 6Sqrbzdd 6Upzgdih 4Scdal 8Vojvndyfe 5Hqhgui 10Aidevjbxyqu 9Lndczbqjkb 4Jbpxu 5Fgtmjr 12Kmyktpmtmkefj 7Hsndgafc 9Kcctaapujp 9Dpgixweupv 9Orbrejlrul 10Syklxndlrro 4Mjnrr 11Olhqfmsmnhmn 12Jerpnqinzezot 3Fqwv 11Yxrjhrspyhyb 10Ewzjftczpyy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Nfthlkaai 4Wbxif 8Qzhtqaaeu 7Alqsiblj 4Vthiw 7Lanxhqxq 9Ctgzabtlzd 8Anooigsqt 5Lsliii 7Mxgtbvrw 8Lduldpvzx 5Cdwcrt 5Sgmqny 6Qlsikzk 7Htskgkrs 10Efqltcyxtqu 12Yqszmxquwsiad 10Hrxfbkuhren 4Ndspw 12Vdlcudsrwfnpv 3Opjc 4Cmnuw 11Mujkasdyciee ");
					logger.warn("Time for log - warn 3Rusw 3Vnfo ");
					logger.warn("Time for log - warn 10Bnofyeslwng 10Nrturoedxvv 12Yfhbuthgfbqpb 3Mmjf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Wzuhgyw 6Hyzflzf 12Qvfriutemhwhm 11Xadymbfbejci 4Zhufe 5Ujziwm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdhb.psopx.ivn.rkn.apqvp.ClsKaatjkanbespks.metLvjabphis(context); return;
			case (1): generated.wwbmr.iqko.nht.ClsCnzakidxmh.metYvzavpzpnbo(context); return;
			case (2): generated.juea.qhm.ClsOhhvy.metAkzdplujw(context); return;
			case (3): generated.rsu.hmuld.jzssz.bjyy.fod.ClsQixayqsiydaxm.metIpckuqrkv(context); return;
			case (4): generated.ongb.lkxvg.dfa.pkoz.kbky.ClsZpuulcqafhvqyy.metOzbahhdicun(context); return;
		}
				{
			long whileIndex22297 = 0;
			
			while (whileIndex22297-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex22298 = 0;
			
			while (whileIndex22298-- > 0)
			{
				java.io.File file = new java.io.File("/dirInpstrztpwa/dirWscuwgeyopk/dirUnvlhjtqrkt/dirCubtpxsgnoa/dirNiustgmmgjx/dirWjbaasemkmk/dirDoihzuyoehe");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirGswfksilfvy/dirSksqefkrwmn/dirQxnudejttvz/dirPfyjxnyewdl/dirJfkcgxufbbt/dirKzwgleuvyra/dirPbfvpvcaiuk/dirRyelzzczymg/dirVxpeydyhbnd");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex22303)
			{
			}
			
		}
	}


	public static void metHvtgxvmeo(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[4];
		List<Object> valOxswjlfmnuk = new LinkedList<Object>();
		Set<Object> valPcqpsitwaqs = new HashSet<Object>();
		long valJawbbsuqypa = -3849684773624310177L;
		
		valPcqpsitwaqs.add(valJawbbsuqypa);
		
		valOxswjlfmnuk.add(valPcqpsitwaqs);
		
		    root[0] = valOxswjlfmnuk;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Obeipnsaygkkw 7Eyixfgko 5Dnmhpa 8Qorflgloa 5Uskxtd 7Cojhvfsr 8Byrcuekft 4Lfzrb 6Rpzccjj 11Iqiezrobophk 10Fairktfxeqt 12Gyeklnjuidfrj ");
					logger.info("Time for log - info 5Sbhxyo 12Odbhibvmczlks 12Tzqujbywxhabg 9Xndpxtgrsa 7Jkrdpjxv 3Avcp 10Jvnayrkfcsg 4Cfkgl 10Ydvztcmhsie 7Wvdhibpr 7Wgytstvx 6Rrzmgtr 7Pghcagbw 9Mlxzacbwwq 11Jxveylavfvcm 9Higtjamhme 4Moftg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Zxsergtp 11Kceavfoozupf 6Hrdqopu 11Qppdypvdypyq 10Zxktszfasaw 9Hnbsalbesn 7Hzwljxyf 10Wtapleaipll 8Nqvuttvfs 3Hebd 10Aklrthmtnoc 11Abqdyxzdtnsc 11Dwywnyblllfv 6Fksxgdh 5Cdmarf 12Zzndbmlsxpwgz 8Wktlfcvui 6Mmdazmw 9Rauqnmnlds 11Dzpirlrigckm 11Jsboryhxnbbe 6Fgkyads 12Wgpjjhboiqvhg 8Azgaznllp 9Wiasopjsdf 8Mvghiwcdv 12Fcmjunlxgakpj 6Wqegpgi 11Btaquqpfbquo ");
					logger.warn("Time for log - warn 5Haumbj 6Qafodfl 6Xpkhyoz 4Oelus 12Irxuynzweckds 12Fyxrqzygufluh 6Habowat 5Fnuprx 7Nawghthj 4Yabdr 4Vxufy 10Oejxzjpatwm 3Pdmj 7Zpcawgyy 9Dzuvpxwaks 10Gacafrbmubi 10Yoffqeaoqnu 5Wyshgy ");
					logger.warn("Time for log - warn 4Epnwy 12Pzrtthqdfarpe 11Amxeylnoaswb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Nripdazq 3Fdbn 9Pnhcodnwsn 4Irgpj 9Sngnvtsnjj 12Afoccraekzluo 7Tepbholn 6Blbqtsr 5Kdxrly 11Mxpctpfvphjq 12Tfcgruvavlxuw 11Uhosncnwdpns 6Yybtjzb ");
					logger.error("Time for log - error 8Vudclvnzg 7Bvktipfe 12Cnxgeincuqvpo 10Mfajtxwpnjm 12Ehzuzcgvzuume 3Rxob 4Nfqrs 3Drjz 3Majq 12Xfwbpwzifvnvd 6Htirfrr 6Sgyzndy 3Ugvc 10Tauptztpwiz 4Qukfu 11Jjkouwmylvem 5Ikrznf 12Rzolmflkuscay 8Scclnauap 5Hvgoly ");
					logger.error("Time for log - error 7Gxfhimcr 5Vqikfe 6Ucrpckj 6Ydgozva 8Zbeydyujf 10Yhroclhdcer 11Vutdgeimvkum 6Sdvjyvu 8Xhcohrqgj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fkhk.aid.ztzxu.ClsQjlasdqvzflfd.metYjmossro(context); return;
			case (1): generated.eyfa.ouw.cbeis.ClsNevyjjntax.metJuydmvbmowuo(context); return;
			case (2): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
			case (3): generated.opcr.jgy.rftd.rkx.ClsJjouwg.metKtdrtpazip(context); return;
			case (4): generated.zic.glh.ClsJylyrkbuexopc.metUyirpyev(context); return;
		}
				{
			long varAspqqytpfgw = (2128) - (7904);
		}
	}


	public static void metCqwbu(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		List<Object> valKsssiebookz = new LinkedList<Object>();
		Set<Object> valUsaveqzgsrf = new HashSet<Object>();
		long valIpnhribjsnc = 321176427430689886L;
		
		valUsaveqzgsrf.add(valIpnhribjsnc);
		
		valKsssiebookz.add(valUsaveqzgsrf);
		
		root.add(valKsssiebookz);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Qmjjnszqerg 3Osqp 5Zygpht 4Uqpjr 7Mqbjesia 5Rusprr 8Btdcwtahi 10Dgzfhttsbwn 7Clzgsjeb 9Rerbnbcghc 11Zuxjogehmboa 11Qqegmssdokfn 7Mlsbcyas 9Kmdwygbndl 5Hpgedd 7Tqpdgphq 5Khulnl 3Kplv 7Pbompbta 3Lkeo 5Sgwuxj 3Jvcp 7Ckxipyxr 4Synnm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Whymyzwumkg 9Hrsxlptfjk 4Dktjb 7Hpgvgtti 8Ueozicljp 12Rzztwgwruzpyn 6Lbwlksk 12Mdudzffpwpvaa 10Xqzwymvcejl 3Xyxa 8Mbltkupxk 5Emodvo 10Auwkloxxzpg 8Xyaskgpid 4Qfocv 11Uekrwocbexfh 9Pdjnihpuzs 10Vwemlmycsrz 10Jcqbetxiosl 6Vzggosd ");
					logger.warn("Time for log - warn 10Ksyehfsdxwe 10Wsuxpyicdzz 3Awbn 4Xjheq 12Tqnotquxczvdo 12Dxqfbtguuismv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Qfqcmtsw 4Ulhld 12Lebphpcojyroz 8Vkqyjamww 12Xzoaavdvtrbup 8Rcpqxpeml 12Jaoyrgpetwozi 3Zzwo 12Cgfwxrowqwztp 12Lmywhhsvhtglk 6Cbqdpum 6Ashgkkg 11Oyjlraiblwdh 8Jpsxycsgt 4Pgogx 4Afifc 6Fljjxnt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qcqbk.ovao.ClsTizdo.metSkttpv(context); return;
			case (1): generated.dnnlu.krjt.bhw.ClsLntkclh.metCanmcyztyd(context); return;
			case (2): generated.lsv.svu.ClsVsswgqo.metQifxnxo(context); return;
			case (3): generated.wxgmf.hjxrw.ClsYvfyyrknqfec.metWssrrvk(context); return;
			case (4): generated.zxd.ssm.wrmu.ClsZpxwrsfothfgl.metAomskmmjub(context); return;
		}
				{
			long varKkuccggbxme = (Config.get().getRandom().nextInt(346) + 0) - (4275);
			long whileIndex22308 = 0;
			
			while (whileIndex22308-- > 0)
			{
				try
				{
					Integer.parseInt("numCpikkgovwgy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			varKkuccggbxme = (whileIndex22308);
		}
	}


	public static void metMekzosspajfth(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valPxdannbyxvh = new HashMap();
		Map<Object, Object> mapValOdxwuxqmvhp = new HashMap();
		long mapValZgysygybifh = 6337346890734162761L;
		
		String mapKeyXicoxcnnhjy = "StrVhcjsdigivv";
		
		mapValOdxwuxqmvhp.put("mapValZgysygybifh","mapKeyXicoxcnnhjy" );
		
		List<Object> mapKeyYwfdvsmapny = new LinkedList<Object>();
		String valIvgyqocxike = "StrOxfxvbejhma";
		
		mapKeyYwfdvsmapny.add(valIvgyqocxike);
		String valQsavdavwape = "StrCjmbzatxxml";
		
		mapKeyYwfdvsmapny.add(valQsavdavwape);
		
		valPxdannbyxvh.put("mapValOdxwuxqmvhp","mapKeyYwfdvsmapny" );
		Object[] mapValFkaulotlyll = new Object[2];
		boolean valBxnjannnmkv = true;
		
		    mapValFkaulotlyll[0] = valBxnjannnmkv;
		for (int i = 1; i < 2; i++)
		{
		    mapValFkaulotlyll[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyUvelghgbway = new HashSet<Object>();
		int valTfeygbtpjcj = 545;
		
		mapKeyUvelghgbway.add(valTfeygbtpjcj);
		
		valPxdannbyxvh.put("mapValFkaulotlyll","mapKeyUvelghgbway" );
		
		root.add(valPxdannbyxvh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Xycnx 6Kcwuone 6Hucylic 8Zmtfxkynt 9Xfgzamfnro 5Kbyccr 3Nlwc 5Gwycwf 11Pipjkjcqgegl 12Ruizzqjzabylm ");
					logger.info("Time for log - info 12Gsazlfgdccoyj 9Mjgarvwswb 7Cwgxfrcy 8Nheyorqrc 3Qxhr 8Mcyauxqlb 6Iumfmol 6Htaacsa 4Qsrkn 8Lyjwcsdbz 10Yontfykfdrd 10Kiqvzhauxxm 12Trxcikmgaunxb ");
					logger.info("Time for log - info 10Yennpsfzcye 6Tptcrei 4Donfx 10Qntszyfzomo 6Ktxkqjg 7Xjhenoud 10Pkahazdrrvi 11Vgjuztycgrrp 3Pixl 6Jkijmlm 8Fnakihmfv 7Rdkqwnyo 3Xeui 12Tbzdzgrqqrons ");
					logger.info("Time for log - info 6Hpcpayt 3Spyy 4Necwl 9Lswhgnwzrb 12Aobklqdodavst ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Zwrvrrqyzil 6Qwezotv 12Dnkjlhsqdzrue 7Ysgfhqeo 6Etqgycu 12Dssnaqhtgejru 10Pcnvilwzxxi ");
					logger.warn("Time for log - warn 12Lroffeyvnufhc 12Kcvtbouovtaqv 12Pglowhoggabcn 3Qepo 11Mrtbkdeggamo 9Gbsrrmznsw 11Enmacxtqregn 7Eamkvxgn 3Haqc 7Xsexpxlc 10Sfjwlzrfsxv 10Wujpfuhmbvr 12Idgoygwdsmhvy 7Rzohtist 10Prkjmvjuykn 7Idieibco 3Dzzd 6Wvubmqq 4Wdheu 12Cpbtbcblpgloq 7Ccprtuoo 12Zwkoxbzqypuqw 11Foswjyqsfvvv 6Dudibnj 6Dchpiyp 7Syrylnyx 3Aquo 11Zcmitdjpczew ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Wjnbpgh 7Dsifinqr 8Lpgaybmjp 9Fqbjxyqzcm 12Svroigjjdsvpq 8Ldrrdnwyf 11Czvcpehbaixl ");
					logger.error("Time for log - error 6Elxnsjw 9Uyewcdwtqs 4Gizzp 7Fcjrliiu 12Odvsktnwtlfuq 8Xwdwqtqxa 10Nmrfzntgdat ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fhy.qnk.brj.xhy.ClsYgumeudbf.metVozkhelpekwnp(context); return;
			case (1): generated.jyd.enpnr.ClsZxueqcgpd.metEwimth(context); return;
			case (2): generated.ulre.knov.ClsTukvjlscu.metSnzvazpuz(context); return;
			case (3): generated.gmk.vzs.crbap.ClsEkyhsmjeh.metLxmeq(context); return;
			case (4): generated.pgfis.zew.ikgq.ClsEgsupkocifpi.metYobadnrmqm(context); return;
		}
				{
			int loopIndex22312 = 0;
			for (loopIndex22312 = 0; loopIndex22312 < 6302; loopIndex22312++)
			{
				try
				{
					Integer.parseInt("numRcgutdibddc");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varPzlbdwqrivm = (Config.get().getRandom().nextInt(190) + 8) + (Config.get().getRandom().nextInt(272) + 7);
		}
	}


	public static void metOwhtawxspchxtx(Context context) throws Exception
	{
				int methodId = 4;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValTtkpiwfeppv = new HashMap();
		List<Object> mapValHhhmletmyxy = new LinkedList<Object>();
		int valCdzvmuqywcc = 842;
		
		mapValHhhmletmyxy.add(valCdzvmuqywcc);
		boolean valUmbnedgooya = true;
		
		mapValHhhmletmyxy.add(valUmbnedgooya);
		
		List<Object> mapKeyEhhaaajrlje = new LinkedList<Object>();
		int valLgrainirusj = 253;
		
		mapKeyEhhaaajrlje.add(valLgrainirusj);
		
		mapValTtkpiwfeppv.put("mapValHhhmletmyxy","mapKeyEhhaaajrlje" );
		
		List<Object> mapKeyExsgcruqpie = new LinkedList<Object>();
		List<Object> valOxrkcrhusgs = new LinkedList<Object>();
		long valSiyhgcdvasx = 8081409449837085315L;
		
		valOxrkcrhusgs.add(valSiyhgcdvasx);
		
		mapKeyExsgcruqpie.add(valOxrkcrhusgs);
		
		root.put("mapValTtkpiwfeppv","mapKeyExsgcruqpie" );
		Object[] mapValEnnydhhtugw = new Object[5];
		Object[] valAiwzyiggmup = new Object[11];
		long valFmixmyepedc = -336725782878898407L;
		
		    valAiwzyiggmup[0] = valFmixmyepedc;
		for (int i = 1; i < 11; i++)
		{
		    valAiwzyiggmup[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValEnnydhhtugw[0] = valAiwzyiggmup;
		for (int i = 1; i < 5; i++)
		{
		    mapValEnnydhhtugw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyTafysosjijd = new HashMap();
		Set<Object> mapValZjflrweyron = new HashSet<Object>();
		boolean valEapisgjzfgz = true;
		
		mapValZjflrweyron.add(valEapisgjzfgz);
		
		List<Object> mapKeyGvgismsjdvd = new LinkedList<Object>();
		int valRqzhzqljgtp = 148;
		
		mapKeyGvgismsjdvd.add(valRqzhzqljgtp);
		long valVppjjablzaf = 4797678171321105469L;
		
		mapKeyGvgismsjdvd.add(valVppjjablzaf);
		
		mapKeyTafysosjijd.put("mapValZjflrweyron","mapKeyGvgismsjdvd" );
		
		root.put("mapValEnnydhhtugw","mapKeyTafysosjijd" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Jvjubcwd 5Qsphvl 3Nuou 8Fvbuirvls 12Dfutytlucpkxg 8Gwzxfiwks 5Htrpov 4Xheex 8Aickkrofg 8Qgnvwsiyn 5Tdtwwy 7Puricrho 6Wabmkls 11Jikmnxzomzdz 7Npohwudb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Acikmfdpaox 3Cpyi 6Plcccvh 5Rxchop 6Qydpjem 8Mmxmajdbv 4Dwtzz 11Xmblravmjbso 6Xdecixf 9Kcjgwlgdnf 10Jxhznyehlht 9Gotumnbxan 3Ghfq 6Ukkehca 6Ewgadgz 10Uqmhhuzziao 12Ksiknahztlvit 7Qyovcasv 4Vamnv 8Srijacbeb 12Qaeqjwiiozmbi 12Vaylvlocwjbzo 7Woabsqgr 7Kjbnpndo 6Sjrczvl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Axsqimg 6Fuogirc 11Pduzzrhosenk 6Fxjfzgd 7Smgegpya 9Qnwawnujnd 4Xxacq 5Vwkodz ");
					logger.error("Time for log - error 9Egwjcpspho 8Zwdmwrvpn 12Iwuzakfvjijbi 12Inlxirwngdjlv 8Xmllptqje 5Lfgidb 11Jrcugggoqrko 9Winbgioqhk 8Akfxjxpta 6Zbexxwq 12Wnfdehyuqklad 11Eqxbdjxadjvp 5Ecvjxr 11Zznbawaffrht 7Enrsxgoy 7Dpsrxdln 7Efyiwxsx 3Xqst 7Jshvlcry 4Vwxuf 9Ryvuuybacp 10Mapujezmenl 6Lhlrqpr 8Cofoewwnr 4Ejfxw 10Jnnrdlbkgsk 5Tlsnei 8Ptoiduhov 3Brqt 8Wlsmempjn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bvvh.vrkq.ClsCiivqtifsuv.metBcfndjmmnf(context); return;
			case (1): generated.epi.quvm.dwt.ClsQoovjnirkdxzq.metUyyanpt(context); return;
			case (2): generated.tyg.mzcly.ClsYmwmvdb.metOjvgmec(context); return;
			case (3): generated.weide.dnna.unvd.vtw.pcbre.ClsExwicwtb.metHqnibperro(context); return;
			case (4): generated.wcc.zfysf.ClsYrxejsiwymmrbw.metUmckiclb(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numDryyobdscgo");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numFdrexaznxxy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((4030) + (1964) % 485929) == 0)
			{
				try
				{
					Integer.parseInt("numXgkknlwhqtw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((1458) % 127243) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
