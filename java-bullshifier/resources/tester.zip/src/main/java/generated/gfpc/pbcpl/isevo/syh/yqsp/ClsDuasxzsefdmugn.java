package generated.gfpc.pbcpl.isevo.syh.yqsp;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDuasxzsefdmugn
{
	 public static final int classId = 396;
	 static final Logger logger = LoggerFactory.getLogger(ClsDuasxzsefdmugn.class);

	public static void metLfljogrsdcdny(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[4];
		Map<Object, Object> valBhiuiofbdti = new HashMap();
		Object[] mapValSnzjahgpzvq = new Object[5];
		String valIpweafkblqw = "StrLqtnawnfwko";
		
		    mapValSnzjahgpzvq[0] = valIpweafkblqw;
		for (int i = 1; i < 5; i++)
		{
		    mapValSnzjahgpzvq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyPjhwvmkbezl = new Object[5];
		long valAxcjdktwhhe = 419804496767061941L;
		
		    mapKeyPjhwvmkbezl[0] = valAxcjdktwhhe;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyPjhwvmkbezl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBhiuiofbdti.put("mapValSnzjahgpzvq","mapKeyPjhwvmkbezl" );
		Map<Object, Object> mapValYgzplstfcae = new HashMap();
		long mapValCgyojaylpbf = 6466078778099022964L;
		
		int mapKeyIveubaquywh = 770;
		
		mapValYgzplstfcae.put("mapValCgyojaylpbf","mapKeyIveubaquywh" );
		String mapValInpfvnrtnva = "StrMjluxpieadn";
		
		int mapKeyHvwrprzissp = 996;
		
		mapValYgzplstfcae.put("mapValInpfvnrtnva","mapKeyHvwrprzissp" );
		
		Object[] mapKeyPxtccvxcyyr = new Object[7];
		int valWljmbvhsbub = 83;
		
		    mapKeyPxtccvxcyyr[0] = valWljmbvhsbub;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyPxtccvxcyyr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBhiuiofbdti.put("mapValYgzplstfcae","mapKeyPxtccvxcyyr" );
		
		    root[0] = valBhiuiofbdti;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Clebin 11Wjbiusmzvnwy 9Hbsxglfpmt 6Esllrkj 4Qkheq 3Czuy 11Xqlvvyoaitbu 4Oobem 3Nwfa 12Cgtaxsfmjgwkz 5Thkmen 8Tgaatqjpb 8Euthrtqtt 8Sgcoamqjq 7Qavdezmi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Ximscsf 12Qsslwaovmurtn 11Fwvermkmmxbz 4Ahcdi 6Mpomizj 7Fylqtdeu 5Pyqvxs 4Eynig ");
					logger.warn("Time for log - warn 7Qawkzgcz 11Qddgjeajxbxr 6Grfmxoy 5Gozgbf 12Nsjtkbclrhbmi 8Rdotnblpn 5Mlwrpu 5Wdhcfz 5Hobdqh 12Uidulyinpdbhp 4Tixlu 9Vtfitggtxi 8Vhqcqhoby 4Ftftr 8Rhiziflse 10Jxxgprbtkws 3Gxna 9Citmacckoj 4Pkmjp 8Zkaqxwwfr 9Xvifucxvbd 7Rtntwjgf 6Gtvgfxp 12Abltbldqjqnsn 8Ttxhflptr 9Exxkaqomzu 7Qpslyrqw 8Qzfhxqvto ");
					logger.warn("Time for log - warn 5Yphejj 10Rfnnlfndxtu 12Oajhuwqmbfbpp 4Kobur 6Piviwne 11Nendjqkywkwz 10Aiepfeqetoi 7Lqdvsihf 5Xkavzb 3Luqs 10Qshwpkbvcvr 4Ygtjg 6Fxednvi 12Ykwzxvmxvkxoi 12Xvbarqcjevyom 7Qpxasfsa 11Pvremwttyino 3Nmtg 4Czcuv 7Ejamlbmu 6Jpnzlht 11Izwmhqloqlud 8Zwqogwinu 8Ezplfncbt ");
					logger.warn("Time for log - warn 3Jbwx 4Rmxzm 7Inyqjmke 7Rktxuwgf 10Uqensihxzyh 5Ljpqtc 12Mjajqwebzyshf 4Aqice ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Shwyaoozshu 8Grwtiqjto 9Glghptwvcg 5Ljttxi 12Gplyffdjadrzw 8Xykkuiroc 12Xorgaywhlsrbv 8Adtihergf 7Gpjrmqsr 12Gvjkogdijgpwh 5Xbrqbg 6Nxxtafq 9Nvwksabdnl 10Yebrmrdjigj 4Mjwhj 12Vfmbqdsacvjuc 7Eclzztkl 6Tyjfgra 8Gvsktseib 4Olzyt 6Astgrwz 12Jhkolbozsqydi 12Zunsfkbhefuqr ");
					logger.error("Time for log - error 12Dxgpvemthjeci 9Ugqkqbwupw 12Bydkhrstwiktd 9Houldpiwcv 7Dswxwune 6Jdfbrex 3Pewa 11Lduvmdbcxwps 9Gatwglhnhq 10Elzmvkqwkcq 11Bxdhgkpbxijf 5Pkzbia 10Lwzqotvpfxm 9Jnhhyqlerg 12Vfinonaaqnpsj 12Cwsadhnrcokza 12Kxevbhximislg 3Swoa 9Qogzhrasmf 12Crddipnvkvryn 11Vanqxthzmtpe 9Nrygcfxljl 4Avujc 12Baqzxcqdhgzyp 10Qszhipbbyke 11Ifcmdmevawmm 10Gxeacbmfuum 8Uyfsxgjgl ");
					logger.error("Time for log - error 4Gdwqt 6Zyxznkk 7Svwktqdh 11Tuxfkhowgtvy 4Ignjj 11Sktbfolgazwn 11Fsnqdapcuauv 4Onuej 12Jvpavcwdtjjax 7Qhhhgjmh 3Zoks 8Oziinuzzs 7Jvncnaea 4Knxii 9Eymujizckg 3Cipl 7Qrssuslz 7Cyiarthz 8Svzxtlqyv 11Vzpabzwyukau 10Mftbgbxrymw 8Jvmtnobio 8Pecpidhgq 8Lolznwqbr 11Wvlaxsqkcbyp 8Fvxxkzlln ");
					logger.error("Time for log - error 10Jdixbxedelk 6Fwlcdkb 9Jbzqwttlnk 10Jaucmgztmmg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zmpxh.humct.jpc.zcr.uswj.ClsMmunby.metRokhpzyzafegb(context); return;
			case (1): generated.flwv.kjeus.ClsAhjobcsyb.metWdbwrxqdjbtpud(context); return;
			case (2): generated.lnvho.rhfct.ClsGgdasahuvsgcd.metJmlhfumq(context); return;
			case (3): generated.cmup.ytrbd.ddu.ClsZmyzij.metQjouwsgplnp(context); return;
			case (4): generated.wkucr.ukst.umm.xsqx.ClsEjxfeypurpufwd.metOatblxssahe(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(574) + 6) % 368862) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metAprvs(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[3];
		Map<Object, Object> valZhhyckttnwi = new HashMap();
		Object[] mapValYuxxgpyslcv = new Object[11];
		int valIsndftqnkxo = 179;
		
		    mapValYuxxgpyslcv[0] = valIsndftqnkxo;
		for (int i = 1; i < 11; i++)
		{
		    mapValYuxxgpyslcv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyWhxfvqlnjcp = new HashMap();
		long mapValOatuuwxjnqj = -8929209215436008959L;
		
		long mapKeyNsrclfmykzj = 8052015200654364740L;
		
		mapKeyWhxfvqlnjcp.put("mapValOatuuwxjnqj","mapKeyNsrclfmykzj" );
		
		valZhhyckttnwi.put("mapValYuxxgpyslcv","mapKeyWhxfvqlnjcp" );
		List<Object> mapValVaebxlztvhu = new LinkedList<Object>();
		long valUolgobqzkbu = -3240138512183466224L;
		
		mapValVaebxlztvhu.add(valUolgobqzkbu);
		
		Object[] mapKeyYotvysrdvtv = new Object[5];
		String valIobnuxsuafb = "StrJozchdyofxc";
		
		    mapKeyYotvysrdvtv[0] = valIobnuxsuafb;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyYotvysrdvtv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZhhyckttnwi.put("mapValVaebxlztvhu","mapKeyYotvysrdvtv" );
		
		    root[0] = valZhhyckttnwi;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Pneqlg 5Nlvxhh 5Qtpzgz 11Euhngcgqfayv 3Amxe 6Ebxyaqh 7Ixurokxv 6Gidtcbl 12Iqhbpkjukzzei 5Ptufwv 4Tvwgg 10Htidmfmbfkg 10Nauktqfyxza 10Pvmvojwkjoh 6Zylxspd 6Aecqzvf 5Eqkkax 7Htpmtjdw 5Vytyvz 11Qrgdntmbnair 6Prafymq 11Olkqoudtnpon 10Qhrdujijiqm 3Axuk 7Rvobkoxg 6Ouaxnes ");
					logger.info("Time for log - info 7Dmyvvkim 9Bvlkkddgml 7Sxyiglrd 4Mtcgm 4Jyhlv 6Qvcbtvz 8Muczyccoj 6Pxpdrso 10Mfpewspfbtw 5Pidaqr 11Qhzenluidkql 6Dnajbxb 12Pxmsvighjkyur 3Ygys 4Shdmr 10Ylmmkuvvglq 11Ibjsycvbjhch 6Mejwslz 3Osjg 8Qgunnwzzn 9Nuwclitoem 10Rpjjffbxcif 6Eygjosw 7Ohxbqasr 12Naqtjpnusizog 3Dyhq 8Qwrxpcmgg 5Lxgget 9Nqsrzzunlq 8Obbyosbxg 8Rlajimrra ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Axnuliayrqa 12Naakacecugygr 8Acygrwxif 3Gawx 11Xcwkaqvkmxox 4Dzgvx 4Idesg 3Ipff 5Hvzhkb 7Wooxxlmz 12Zgkkyxckaiyjj 10Rllymqvdahv 11Afooxgbqwybv 10Ayhgwdcqkyk 8Xvqsvdqvb 8Dfhwkspqn 6Lseaeze 5Fcwrap 11Ynxihsiiffas 3Zacv 9Psyhtkrfng 10Xjrnyejhcgj 4Yqpdj 7Qrpgvmpw 5Rrirsn 4Pcfay 11Voidtzhxnuwm 6Tidabqm 6Wciqued 10Zysaelyljcb ");
					logger.warn("Time for log - warn 10Pbtstbsvinh 12Ulnebnazwjsse 4Gdkcq 11Eomgqgdfjuop 3Joia 6Eiuqnwc 11Fxbdnxytzbpf 4Kpgor ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Pcwcrjhoesl 5Hneypk 8Zumlqfqfv 9Ydmqrczaaa 7Gygfzxtp 8Okkullcjx 10Acgcemekuor 10Ayaagkbyjvq 4Hhtdu 5Jzbfow 10Xueeiuhktcs 5Rkqdfv 3Zqsw 9Araaeoulxf 8Fceewdufa 10Ivcuovrzaun 5Eeaoyr 7Kypcqdyb 8Cogjxzcqw 6Ivhdnsl 12Qoyvgszcyvxwn 11Jfnumeidmdmt 4Aaytw 8Zzujtqgqr 8Upypasgzm ");
					logger.error("Time for log - error 3Umqa 5Novynk 4Xppey 11Gxynbvigemyb 7Pyjruvmm 3Tiwe 7Vepiexcb 8Howdqpvoq 11Bfdwrfuygkes 7Dkebmexy 3Irxo 12Caiqfmqzklbec 11Yzndrxfnnagf 3Wqhc 4Bqpkj 11Fcifmcjtqsgl 9Mqrjnfqnjc 9Ljozkvheyf 10Vkqokwsvfvv 9Kknjqvvvtk 10Svxbwmhvmcc 3Hxzw 12Jnrdkvxilasjd ");
					logger.error("Time for log - error 8Dhefmutdf 11Elwkjdmcgqkh 4Hcthy 7Hajvyrdb 8Djmciwhyh 3Xfrd 9Lxnlnjpcah ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zfv.ypwo.wuncq.ClsFveqnpanl.metApyyqiuohqp(context); return;
			case (1): generated.cbscy.vax.ifmv.uvjll.ClsXprhoql.metUsqqbascqyi(context); return;
			case (2): generated.bftm.jkb.lcr.ctpvk.ClsYfbhukzct.metRefjrhfmiyvoq(context); return;
			case (3): generated.gfhvs.nuhuq.qbk.rwbku.erqpl.ClsOuzdnnqrt.metYemauozpyth(context); return;
			case (4): generated.pxy.vesv.fuz.ClsEaskwlgtcshts.metCnqxpzkxiqea(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numUnhkwisvhgv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirVywsgskdeck/dirClvzsbvtjvh/dirYpqfkmbhmpi/dirCendfjpezqy/dirYkcuiqmjybx/dirAsafibirxym");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex26724 = 0;
			
			while (whileIndex26724-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metSkowruz(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[2];
		List<Object> valWikgpmpckjc = new LinkedList<Object>();
		Set<Object> valBsgrwhcueot = new HashSet<Object>();
		int valHipfwtcbyqr = 719;
		
		valBsgrwhcueot.add(valHipfwtcbyqr);
		
		valWikgpmpckjc.add(valBsgrwhcueot);
		
		    root[0] = valWikgpmpckjc;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Jnraddfs 11Bjhevvbkknyn 8Enahqwaew 4Lymqh 3Miec 8Cibomodnl 7Eojldbse 7Pahyuxmv 7Woajacyk 11Bitztypwigyn 6Zfpiuae 10Dxayhfcuhsu 6Vuryeco 6Zszkeyq 4Yjggx 11Bmsgvtfglptp 5Cqkrzw 11Ohzgljzrsomy 11Zyggddtarchc 4Lraor 12Cvjeqnromzfin 3Wfxe 5Laeedh 5Eehrhz 12Yxvbyehannihm 8Aoopxhzxf 10Dessniwbkmj 5Nyscse 7Hinirhqm 3Prrj ");
					logger.info("Time for log - info 4Ohbwg 8Byyeqvjbt 4Wzxpk 6Goejjrx 10Qtokrkbqiat 7Edsdbwln 4Pkyis 8Urrpatfxh 5Dkhklj 4Ulceu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Fkbwm 8Hnhkrskvj 3Yjvc 8Hesppsdrn 11Snoilarnjrmw 7Cdpwgzmz 8Ansxtturt 6Cekysvn 4Nmfjo 8Scosbkewl 12Xcijfrviatqng 11Bckkjazggksv 3Rtky 8Wczthqkqj 9Odkzvpuxvv 8Gaxkkwqdz 10Epkiyxwxvvt 10Vvnpuvglmrr 4Cwgaf 11Rapjlrwbzeua 7Phqzpedm 8Ussihuixb 9Emvwelwcux ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xcud.xbp.eztj.gexk.ClsTupoxajhjshtec.metEsfpmpnsdd(context); return;
			case (1): generated.jzpii.ixwl.ClsCvgimgq.metCiomqaueaxz(context); return;
			case (2): generated.axdim.stv.ClsSaegiqo.metVwtuv(context); return;
			case (3): generated.zuj.yzx.nga.pvup.ClsJyskqhfglgbk.metUwrvr(context); return;
			case (4): generated.rkfhx.ntcs.qoe.lasd.nzzym.ClsDftkqmvmp.metVydzwrio(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varHrwnsiavthm = (5260);
		}
	}

}
