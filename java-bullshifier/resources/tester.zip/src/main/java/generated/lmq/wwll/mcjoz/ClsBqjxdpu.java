package generated.lmq.wwll.mcjoz;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBqjxdpu
{
	 public static final int classId = 199;
	 static final Logger logger = LoggerFactory.getLogger(ClsBqjxdpu.class);

	public static void metYpiqwjcggcaa(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValAfaoooaxpkd = new HashSet<Object>();
		Object[] valBocsfpnxuap = new Object[8];
		long valVqnnjobvjny = -2931740260119732321L;
		
		    valBocsfpnxuap[0] = valVqnnjobvjny;
		for (int i = 1; i < 8; i++)
		{
		    valBocsfpnxuap[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValAfaoooaxpkd.add(valBocsfpnxuap);
		List<Object> valBzgempohgoc = new LinkedList<Object>();
		long valIrsiplbbpom = 7439715259494437120L;
		
		valBzgempohgoc.add(valIrsiplbbpom);
		
		mapValAfaoooaxpkd.add(valBzgempohgoc);
		
		List<Object> mapKeyAkvdozluzse = new LinkedList<Object>();
		List<Object> valPzwmimrcjqo = new LinkedList<Object>();
		int valDiisnoboqce = 693;
		
		valPzwmimrcjqo.add(valDiisnoboqce);
		long valMqxbkgybwlz = 5113014930203175382L;
		
		valPzwmimrcjqo.add(valMqxbkgybwlz);
		
		mapKeyAkvdozluzse.add(valPzwmimrcjqo);
		
		root.put("mapValAfaoooaxpkd","mapKeyAkvdozluzse" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Ntfs 10Szodtwcfmln 9Fhjqbsfpbt 6Ztyxdti 5Zphtlq 11Zvqnnabpofmw 4Lpmjo 8Gpzvjvkcw 11Sgjxpuzrlzsu ");
					logger.info("Time for log - info 11Nwkglftcttab 6Leekkab 10Aqagezvntiz 12Onvkdfjdsuuyz 10Debiiqewnaj 10Rvlioirxfuh 10Tdapuczpekj 7Jmivndog 8Fgdvrayto 5Hvwrpg ");
					logger.info("Time for log - info 3Ifhj 12Rragcvvmblwdr 10Gsomfatjcob 9Afnpebdptj 10Yenmofzpoya 7Mbascyjw 8Rizbfngzb 8Pvdnawdoy 6Ozilswf 6Avldukl 10Uuwxwelixgz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Efenlqrx 7Ecvmeitq 4Djhph 7Kcrhjgiq 8Wnbnjpeei 11Driputkgsjvz 10Mnnjtdxpezp 4Ylepm 10Zsrfhocvars 9Oheupgnvbt 8Cbdaychpk ");
					logger.error("Time for log - error 7Ownhgpku 10Gepieemtamy 4Bsguu 7Syfpqlqx 7Juykthgp 11Nokkqqctdnhg 3Dpfd 8Hjfkgdayp 7Gkqkwdnk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
			case (1): generated.ydzsq.oryaq.elxyy.ClsOrteugmzafy.metJlrtydsoimw(context); return;
			case (2): generated.kqywo.pil.grw.dvt.ClsJduhsebfba.metAclgutvkyttl(context); return;
			case (3): generated.deuz.rvz.jsq.ClsHbyckyeswad.metJegrkbyqxodbpi(context); return;
			case (4): generated.vntk.clexr.ClsYpzzbhceuihjz.metHptaqt(context); return;
		}
				{
			int loopIndex23478 = 0;
			for (loopIndex23478 = 0; loopIndex23478 < 9379; loopIndex23478++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metGccfwaiyfrrux(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValBttambzpgrr = new HashMap();
		Set<Object> mapValUvqzswrwcun = new HashSet<Object>();
		int valYeqkbnzzjyy = 345;
		
		mapValUvqzswrwcun.add(valYeqkbnzzjyy);
		boolean valHeukxuzgkre = false;
		
		mapValUvqzswrwcun.add(valHeukxuzgkre);
		
		Map<Object, Object> mapKeyIagpagbgyzd = new HashMap();
		String mapValWeojomtryku = "StrZsrrmswzvdp";
		
		int mapKeyLvavyvvsonv = 372;
		
		mapKeyIagpagbgyzd.put("mapValWeojomtryku","mapKeyLvavyvvsonv" );
		String mapValOheneyrwgaj = "StrTkhjviwptsw";
		
		boolean mapKeyXlenlzohjjb = false;
		
		mapKeyIagpagbgyzd.put("mapValOheneyrwgaj","mapKeyXlenlzohjjb" );
		
		mapValBttambzpgrr.put("mapValUvqzswrwcun","mapKeyIagpagbgyzd" );
		
		Set<Object> mapKeyLpbkirgospo = new HashSet<Object>();
		Object[] valJzultvzkqan = new Object[7];
		long valOcvkbtbfdog = 8211333662467302921L;
		
		    valJzultvzkqan[0] = valOcvkbtbfdog;
		for (int i = 1; i < 7; i++)
		{
		    valJzultvzkqan[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyLpbkirgospo.add(valJzultvzkqan);
		
		root.put("mapValBttambzpgrr","mapKeyLpbkirgospo" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Uepym 7Afnvjazc 4Zmear 3Bevu 3Ineg 10Bpsrwlsqzmk 5Ofaquo 12Lzhiwshjkoxul 12Oottdxazmgnqm 9Tlcntlkrex 10Lqwikaeepfg ");
					logger.info("Time for log - info 9Iyossvhaqw 12Kkiyhprjilyol 12Zjpfmugzmkwhi 4Mfcbo 8Rmvhvrllb 6Ifniltk 5Yxpcod ");
					logger.info("Time for log - info 7Ngspqzqo 10Salqiiwuazv 3Crgp 7Rlpmhgew 7Qyekzefq 3Meoi 11Ueadjhsqbvwh 6Dnscxvf 3Oxgc 10Ckwtqilolwy 4Inaxu 4Ngmyw 5Ljgvhm 10Namftpgrxqg 5Rkvyty 5Slxffh 7Tyqoyrxm 4Sxmrb 4Lxcoo 8Ypoavkxjf 8Kbmnujqko 12Uwoiljexaracg 9Acxsduufhm 9Fxfymjfpqb ");
					logger.info("Time for log - info 3Nupg 7Xvgrecci 6Gtfkreg 6Hehlewj 12Asjuqtsptyshz 7Qsxjidld 3Xzen 10Osiqexehctm 12Laxlwujvwhibn 6Mqugthr 11Fhawotyprjpq 10Axbptxsmakc 8Buvdpoaaf 6Tgqellm 11Qxykgvcktvtr 8Vnkttjcon 12Vxecnakcngqzt 12Fptyrchwvdepz 12Sonmeoftgptkm 10Ynhpvwiluyi 6Uycdqhv 10Jzherwaihgz 7Peiccslo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Klxtydawq 8Uwyrorkbh 7Fkbtpjru 4Nsvqk 8Xcjqwzqrb 5Behtyw 5Nxztxq 3Eszl 6Nihbahb 8Olctjsplt 5Ignope 12Uowhrwajjjkul 5Zbcjyg 8Sxnujwbok 5Rsaali 11Fpalntdwhtqe 6Aymswnj 8Cfwguzpbb 10Zayndbbokuj 8Lcjoitsaq 6Aaatwwn ");
					logger.warn("Time for log - warn 3Fqcb 7Ckylwcsv 11Fszybgyczvtt 5Ujjtoo 10Aocboaffzhu 10Mqfbgeyjvjg 8Vuvuvwqbx 10Wpurzyajapo 7Hpphcipq 9Ypvhlqeeef 7Wtwxcmew 9Jwocvaqapa 10Jitdgjegsmz 11Yokrfrmbbnea 6Ddvjsvq 5Zwhcfx 11Froqtxlodeaj ");
					logger.warn("Time for log - warn 8Gjpznqrsj 7Chljvsco 3Udhf 8Gmubvdvbc 3Wtov 7Tmmcqqtr 4Gegsw 9Nuffnwmpbq 11Dpizddmfrjkq 9Sugqnrwoqc 4Fnftq 8Jcdpsqudk 7Houigfad 9Xuqdwuszpr 10Uierzicuerw 12Hqcidubnrietj 11Bygqpayeteiu 4Rakbe ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Cnlzt 9Dsymrbvsvs 6Dojbwbt 9Rhvbrydzml 4Gxhfv 7Eyozmqdr 4Vavlv 4Lkhvf 8Tkgjkwgtx 7Riqgapci 7Vyyostmy 3Ctel 11Tgvixygsdyvj 7Aamfkdkc 12Ergpblzotzzyj 5Svzdur 7Qyygftpb 6Mgieeyw 11Kywlwwsizlzq 8Mbfmymrso 10Grcdzsnarzs ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.psehw.ylq.mvtup.ClsZvqertch.metDwzjtryendoov(context); return;
			case (1): generated.yewpq.dap.itdt.ClsOhnihvc.metVezpyfhkrdq(context); return;
			case (2): generated.pli.sac.lcrkw.ery.xwlo.ClsIghyijbnkvoubq.metAbfxcknztmtxd(context); return;
			case (3): generated.eyfa.ouw.cbeis.ClsNevyjjntax.metQvyozodgmv(context); return;
			case (4): generated.agyh.aakn.unf.yzvm.uvtp.ClsPvvezxsnka.metBiufhu(context); return;
		}
				{
		}
	}


	public static void metLzmwjdeakzh(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValCdkunuqjfkk = new HashSet<Object>();
		Object[] valZbdyznvvbkw = new Object[10];
		long valVaczqvmckth = 3302095147584085175L;
		
		    valZbdyznvvbkw[0] = valVaczqvmckth;
		for (int i = 1; i < 10; i++)
		{
		    valZbdyznvvbkw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValCdkunuqjfkk.add(valZbdyznvvbkw);
		
		Set<Object> mapKeyFrdxtvpdcbr = new HashSet<Object>();
		Object[] valXebilgrgyid = new Object[6];
		long valVahlnfioruu = -4932868870356646283L;
		
		    valXebilgrgyid[0] = valVahlnfioruu;
		for (int i = 1; i < 6; i++)
		{
		    valXebilgrgyid[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyFrdxtvpdcbr.add(valXebilgrgyid);
		Map<Object, Object> valMxmpkwtvbyd = new HashMap();
		long mapValCiypffjxqua = -6666581930020033431L;
		
		String mapKeyMirammhrwic = "StrMctmrnjclto";
		
		valMxmpkwtvbyd.put("mapValCiypffjxqua","mapKeyMirammhrwic" );
		
		mapKeyFrdxtvpdcbr.add(valMxmpkwtvbyd);
		
		root.put("mapValCdkunuqjfkk","mapKeyFrdxtvpdcbr" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Afjhipav 9Rytfxswcwr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Fvnl 8Gzxpfvnla 9Pjodcxqkgh 5Ylnzsh 8Ovnrljahb 9Sufjvcqtdr 6Izkypxz 8Hugzaksbn 8Ekqrfxnzt 12Jdvrkvecfyhvr 11Acgslxserksb 3Tzxa 6Ztdmtax 6Gziqdgu 9Ronysjpfyz 3Qdvn 7Dkbvghjz 5Llwhnb 10Zmspqxgipxg 5Zrlmvo 6Twwvumz 10Reovgavfebm 9Clieoijezr 7Lmspvwyn 7Utnwfmpb 10Uqkfwxmsoeo 3Pwwh 6Gojdeae ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Reitlfsq 4Gbrpc 3Hsjw 4Xjbcr 4Tyvys 8Wnqbwbawe 5Tsgvgy 5Zexzay 11Vlhdwyjayooy 9Pveuhnwdbw 9Yohzpwlxrt 11Ztmvmprpfsom 11Sbcibfcjqhbx 9Zedjubexsc 9Qfeeeujgiz 7Eidqonqc 5Myykht 10Nbpporvneiz 5Eqyifl 10Gnlyxtamcgr 3Mnqq 8Rclgllzph 11Qkbcxdwxvjzn 7Oclyaxrt 5Alvsge 10Hzyhtvcjbxw 10Izwiqoxyuae 9Wqdjqakfpg 3Lcwi 12Emalllwtntbsf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ajbel.dvbe.pmx.gfhen.qjvpo.ClsFwkvrnv.metMgmvesnfqhsp(context); return;
			case (1): generated.tcf.quma.ClsZzrrflp.metZjejbmakhczdx(context); return;
			case (2): generated.gww.spuw.jrq.nmv.xowli.ClsKosigq.metKvjjegqp(context); return;
			case (3): generated.aisq.ykt.yfxh.ClsRqviupmemczv.metFawupdwqkldp(context); return;
			case (4): generated.weide.dnna.unvd.vtw.pcbre.ClsExwicwtb.metGhpnegncduu(context); return;
		}
				{
			long varNcoehrgfxqx = (6715) * (7533);
		}
	}

}
