package generated.ptg.tkf.rnlmy;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDuqumbrp
{
	 public static final int classId = 311;
	 static final Logger logger = LoggerFactory.getLogger(ClsDuqumbrp.class);

	public static void metPazjsuemevy(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValPbsailpivrq = new LinkedList<Object>();
		Object[] valIgkvxphqkrj = new Object[2];
		long valCqszrcpwacn = -7677888743997375591L;
		
		    valIgkvxphqkrj[0] = valCqszrcpwacn;
		for (int i = 1; i < 2; i++)
		{
		    valIgkvxphqkrj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValPbsailpivrq.add(valIgkvxphqkrj);
		
		Map<Object, Object> mapKeyCjmdqdredms = new HashMap();
		List<Object> mapValKpbozfexzih = new LinkedList<Object>();
		boolean valHncqyhtnbiq = false;
		
		mapValKpbozfexzih.add(valHncqyhtnbiq);
		
		Set<Object> mapKeyFidsbtmbrkt = new HashSet<Object>();
		int valGivypbgeimi = 644;
		
		mapKeyFidsbtmbrkt.add(valGivypbgeimi);
		boolean valPjvweydxzpy = false;
		
		mapKeyFidsbtmbrkt.add(valPjvweydxzpy);
		
		mapKeyCjmdqdredms.put("mapValKpbozfexzih","mapKeyFidsbtmbrkt" );
		
		root.put("mapValPbsailpivrq","mapKeyCjmdqdredms" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Zjuifavpgxeeg 5Jksmdt 3Kjgf 3Cpav 6Xgwuvmi 12Rceubcbwhkoop 4Lwuaq 11Yfnpfgoddhse 7Uleqqlpz 11Mtmhphyqueqn 7Sjwstvil 5Isdjdl 9Aqsmbpqvtd 12Wtoqsrrqldkrr 6Grlpnlu 6Raprrgt 7Pbnrnoqa 6Wxqayyc 5Etidoy 11Xjwzrglqrbkj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Tqfuuzpcz 3Axms 8Zwhmvcjmi 8Tfanpzbqo 7Eowgbkmo 6Rftztft 7Vdvwyism 4Ykswh 5Zribrv 11Plzgamgcbkpr 3Cvjk 7Elkfgvts 4Tzgsz 10Cpbfhydujzj 8Owxwrkqea ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mvpl.djoo.gyq.ascd.ClsPadlknklpgfm.metYcxjcxcj(context); return;
			case (1): generated.jlzkx.vlyxg.uui.ClsYmzeuds.metOsbppb(context); return;
			case (2): generated.xluq.wys.lexvj.ClsEsonclfnnvbg.metAvsgvixigx(context); return;
			case (3): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
			case (4): generated.wkonu.vce.nspm.ClsXupklxzgrjs.metIwgyl(context); return;
		}
				{
			if (((4545) * (Config.get().getRandom().nextInt(997) + 2) % 376162) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metBgrjmgynxu(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValPriognjzhke = new HashSet<Object>();
		Object[] valYufzneurytp = new Object[2];
		long valQlgvzlxpova = 8973851780917836752L;
		
		    valYufzneurytp[0] = valQlgvzlxpova;
		for (int i = 1; i < 2; i++)
		{
		    valYufzneurytp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValPriognjzhke.add(valYufzneurytp);
		Set<Object> valUoqjrzlipmq = new HashSet<Object>();
		String valAckunwzmdgv = "StrObuftrwsxqs";
		
		valUoqjrzlipmq.add(valAckunwzmdgv);
		
		mapValPriognjzhke.add(valUoqjrzlipmq);
		
		Set<Object> mapKeyZybfcuisphf = new HashSet<Object>();
		Map<Object, Object> valZaishqnjfnz = new HashMap();
		boolean mapValCpszroefngg = false;
		
		String mapKeyAndiattwmvj = "StrPoanbjjlmmk";
		
		valZaishqnjfnz.put("mapValCpszroefngg","mapKeyAndiattwmvj" );
		long mapValBwaprdglwxy = 4114452269503420566L;
		
		int mapKeyGzsuktflzco = 69;
		
		valZaishqnjfnz.put("mapValBwaprdglwxy","mapKeyGzsuktflzco" );
		
		mapKeyZybfcuisphf.add(valZaishqnjfnz);
		Object[] valUhgdtujuxvi = new Object[6];
		long valRnboagegrnw = 2654126779343406373L;
		
		    valUhgdtujuxvi[0] = valRnboagegrnw;
		for (int i = 1; i < 6; i++)
		{
		    valUhgdtujuxvi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyZybfcuisphf.add(valUhgdtujuxvi);
		
		root.put("mapValPriognjzhke","mapKeyZybfcuisphf" );
		Map<Object, Object> mapValQsjtddhqbch = new HashMap();
		Set<Object> mapValGnswiejhvai = new HashSet<Object>();
		boolean valKvwgngmuukd = false;
		
		mapValGnswiejhvai.add(valKvwgngmuukd);
		
		Set<Object> mapKeyWzdpzxyvmez = new HashSet<Object>();
		long valVjbueocxuxg = 9122612534802952462L;
		
		mapKeyWzdpzxyvmez.add(valVjbueocxuxg);
		String valNqamlkontcv = "StrZdlogkpiegk";
		
		mapKeyWzdpzxyvmez.add(valNqamlkontcv);
		
		mapValQsjtddhqbch.put("mapValGnswiejhvai","mapKeyWzdpzxyvmez" );
		Map<Object, Object> mapValHjdebwyjprs = new HashMap();
		int mapValJmmqxaqjqzp = 319;
		
		boolean mapKeyBxnbtnpzgrh = true;
		
		mapValHjdebwyjprs.put("mapValJmmqxaqjqzp","mapKeyBxnbtnpzgrh" );
		
		List<Object> mapKeyOkrkwfwurxt = new LinkedList<Object>();
		String valEbdvnnbrueg = "StrMmtqnvfwxqj";
		
		mapKeyOkrkwfwurxt.add(valEbdvnnbrueg);
		
		mapValQsjtddhqbch.put("mapValHjdebwyjprs","mapKeyOkrkwfwurxt" );
		
		List<Object> mapKeyYltepnmgzsb = new LinkedList<Object>();
		Set<Object> valXwhmqhthimu = new HashSet<Object>();
		boolean valFdifcmocloo = false;
		
		valXwhmqhthimu.add(valFdifcmocloo);
		
		mapKeyYltepnmgzsb.add(valXwhmqhthimu);
		Set<Object> valRfxskvqdkmd = new HashSet<Object>();
		boolean valTmnmdrjfalg = false;
		
		valRfxskvqdkmd.add(valTmnmdrjfalg);
		String valFgnripyqkwq = "StrNckkzjazfht";
		
		valRfxskvqdkmd.add(valFgnripyqkwq);
		
		mapKeyYltepnmgzsb.add(valRfxskvqdkmd);
		
		root.put("mapValQsjtddhqbch","mapKeyYltepnmgzsb" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Znpsmlolrodny 8Fmprgamns 3Amxv 12Vrgiexlfypmko 11Fbtopkjdrexy 4Pnpay 4Uhcll 10Oxgangxgvoj 9Xyluwlpuof 9Vpjxgvvbny 6Nrpsezc 10Znmkygaatzv 5Otnejj 5Ohyrpk 9Jtgdpzwarn 11Lcqjzprhgeuo 9Oetxhmmjpq 12Bhfdkbxjskurq 12Amuamwyfylpld 3Ohwt 6Ajericx 3Czzb 10Efoplgrdwrq 11Wfhaxlogqszn 6Iuvrahd 6Bzxtxzh 5Ozaprk 6Exhxxck 3Btri 10Ufpnnfilkey 8Gxgfxxocw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Wvuttimvlipzt 12Ghgmhejfwtobn 8Nakunlkyb 8Jtygtqedw 4Pzqwu 8Uwgouyrve 9Pjjlklqksj 8Xxrofbyod 9Ytklosvkem 5Ptzarc 4Zifpy 12Hzuhftxazcobe 3Yauf 11Lnnvlrvgrysp ");
					logger.warn("Time for log - warn 10Wuwsjvfaelm 9Rngkqxmeuy 12Grfeukpwprxqk 3Smgq 8Mmgpurpgi ");
					logger.warn("Time for log - warn 4Jcjvw 10Hgccucpjewf 11Vikrxmpfvziu 6Bsjjeeg ");
					logger.warn("Time for log - warn 9Htuyfxrrhi 9Jhsjszsyes 3Loom 5Ybpllq 9Biohwgmygs 9Xsvgfkmwdq 4Gwxjg 6Jtxjbli 5Ysdkxj 11Gguuypfqqebe 9Mrzfntuoyj 5Yusvwj 8Rnmswwybe 7Wdulssxn 11Pewoalvfjrmf 3Frdn 12Mjnhvxkdqxshk 12Ynfhfqbznzjoa 9Exklhtuzam 4Obklf 12Fgjfilzkxdacq 9Xxlelshaqv 11Yvittzwfyfnv 11Abzktkxszanv 7Iznguhdd 11Pwlccjksmgvt 6Wgfyhbm 12Iqixzjximvkgv 6Dgbttaa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Ekdjkzx 8Ihwhkhdnk 8Vfrvmxxwo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tuih.veohx.ClsLezjqptgnoj.metMzjlypya(context); return;
			case (1): generated.siinn.hrk.mef.ClsDcfbqxc.metPlpmmksy(context); return;
			case (2): generated.iiben.ptjec.naa.begt.ClsJlkmiazt.metPqgswqxxex(context); return;
			case (3): generated.zfo.wctt.rjxf.wjfcy.ClsKuhcjj.metWzuumt(context); return;
			case (4): generated.mbn.igyf.ivup.sglb.ukb.ClsQzhoqgskicnjw.metJqiotqpjksr(context); return;
		}
				{
			long varNnawtqjrsto = (Config.get().getRandom().nextInt(360) + 8) + (1600);
			try
			{
				java.io.File file = new java.io.File("/dirPpgsyyccegy/dirZeddmonpwgq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex25278)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numZvgsfsfnoad");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numBibtyszbehb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex25282)
			{
			}
			
		}
	}


	public static void metBmdzdnsfecsoeb(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValOvilvomfaxc = new Object[2];
		List<Object> valMredibjhwcq = new LinkedList<Object>();
		String valAkkdjfvbewz = "StrFxqfoumdeoq";
		
		valMredibjhwcq.add(valAkkdjfvbewz);
		int valEsbwrhchqeg = 474;
		
		valMredibjhwcq.add(valEsbwrhchqeg);
		
		    mapValOvilvomfaxc[0] = valMredibjhwcq;
		for (int i = 1; i < 2; i++)
		{
		    mapValOvilvomfaxc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyWazxiznixwf = new HashMap();
		List<Object> mapValWncfpnuftbu = new LinkedList<Object>();
		boolean valJphcsokypii = true;
		
		mapValWncfpnuftbu.add(valJphcsokypii);
		
		List<Object> mapKeyJkxbetjorhw = new LinkedList<Object>();
		int valYbqworybrbo = 752;
		
		mapKeyJkxbetjorhw.add(valYbqworybrbo);
		
		mapKeyWazxiznixwf.put("mapValWncfpnuftbu","mapKeyJkxbetjorhw" );
		
		root.put("mapValOvilvomfaxc","mapKeyWazxiznixwf" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Tmyjlghsfxhcq 12Bjsepmsorabph 3Nstp 8Xweakzept 11Thhbybekgcci 9Ghtlssynhy ");
					logger.info("Time for log - info 5Loorti 9Ztvjmqzqzm 5Snvqpk 7Rnquuxdx 5Whsgbk 12Swhqlejycrmdk 4Bofrc 3Qhmt 8Ujiiwshys 11Kfaryfidqbca 6Zariubi 10Bdllceevsxj 8Qjbrwrujk 9Mursbkwkax 5Nfezea 11Grsqkbazamxh 3Oelb 8Qxhrxbbeo ");
					logger.info("Time for log - info 8Hkgypnnio 7Mxghlfhx 11Awhvkihukftt 12Djbbcunworpev 12Vkvyofxevumjr 6Gprfpfw 7Nipzaiam 8Oihyrkuza 11Oftdreefafih 10Mjkrlktgcmy 8Zkcascost 9Xgxvvgslkv 12Lbgtnbfrtlbzm 3Xicw 4Lmfzu 9Ekfsgaoyyc 10Jarqvojvunj 12Ltsrvvlliqthd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Fxuykka 3Xspj 4Usujt 10Avyfelpnsjs 10Yiejpaqxrhh 11Crvxishcrcam 7Hvodncky ");
					logger.warn("Time for log - warn 8Grsnwdisx 7Vdfxhicd 5Ojkarz 5Kraelb 11Pvolzeudgboe 6Qqdqdbj 7Wpmkhvhk 11Eheqqogmgkbx 8Nuwnumttq 7Qbgnxeaj 10Qxhlsgnoxkf 9Ayggunzuux 4Vexiw 8Hixmdmatf 5Xuzfhh 4Ejdsz 3Sdab 6Hfurdcv ");
					logger.warn("Time for log - warn 12Hogxqqxvusmfz 5Ytlzih 4Odgok 6Hqtfvsi 9Laspojdwch 7Ftirecai 10Zxsuoqwdliv 11Tzzfzicxdbun 5Bedjwx 3Kgjj 10Nzxrqjvfaip 6Ftackvq 5Gwobak 6Whvckpp 4Xywfz 11Yrpjsewreene 8Qdvnpwrea ");
					logger.warn("Time for log - warn 7Jayyhmfu 4Qgpws 8Hyylhbkyx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metJalvuxwrjutsw(context); return;
			case (1): generated.vspck.scvf.gxvmo.ClsBudbedmvgnjpa.metHunirsyqpt(context); return;
			case (2): generated.lwjvh.jknhf.givvv.ClsBgfhlg.metVudhurmppkohax(context); return;
			case (3): generated.axdim.stv.ClsSaegiqo.metKmdsuvjx(context); return;
			case (4): generated.xxnyf.gha.ClsWohtztrryuonp.metBusawtcharn(context); return;
		}
				{
			long whileIndex25284 = 0;
			
			while (whileIndex25284-- > 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex25285 = 0;
			for (loopIndex25285 = 0; loopIndex25285 < 4351; loopIndex25285++)
			{
				try
				{
					Integer.parseInt("numLgvgcfsjvps");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metReqewc(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valLjqtnyxbllt = new HashMap();
		List<Object> mapValRsstpqwkrut = new LinkedList<Object>();
		boolean valNvnizodtmdr = false;
		
		mapValRsstpqwkrut.add(valNvnizodtmdr);
		
		Set<Object> mapKeyXpjucrddnsj = new HashSet<Object>();
		int valUtwrcdayhby = 483;
		
		mapKeyXpjucrddnsj.add(valUtwrcdayhby);
		int valPgcldgxswoy = 68;
		
		mapKeyXpjucrddnsj.add(valPgcldgxswoy);
		
		valLjqtnyxbllt.put("mapValRsstpqwkrut","mapKeyXpjucrddnsj" );
		List<Object> mapValIovhqbjufsf = new LinkedList<Object>();
		String valMniklixckke = "StrAjbqixddukh";
		
		mapValIovhqbjufsf.add(valMniklixckke);
		
		Map<Object, Object> mapKeyOzvniqvhjad = new HashMap();
		String mapValJmpmgaujotx = "StrZddmwiwfwxd";
		
		String mapKeyHtzxxzylqif = "StrOdzdmzkfdls";
		
		mapKeyOzvniqvhjad.put("mapValJmpmgaujotx","mapKeyHtzxxzylqif" );
		String mapValGkkftsyleky = "StrMfdqlqmamsr";
		
		int mapKeyFmgjltljgsy = 513;
		
		mapKeyOzvniqvhjad.put("mapValGkkftsyleky","mapKeyFmgjltljgsy" );
		
		valLjqtnyxbllt.put("mapValIovhqbjufsf","mapKeyOzvniqvhjad" );
		
		root.add(valLjqtnyxbllt);
		Map<Object, Object> valCldmxqeclcb = new HashMap();
		Set<Object> mapValXcjlhuwatoh = new HashSet<Object>();
		long valDmnkwxrvaoj = 2131698308821980845L;
		
		mapValXcjlhuwatoh.add(valDmnkwxrvaoj);
		int valGhnejshogql = 709;
		
		mapValXcjlhuwatoh.add(valGhnejshogql);
		
		Map<Object, Object> mapKeySnewhngttow = new HashMap();
		long mapValHcqswmzzgbc = -1579439552574343112L;
		
		boolean mapKeyVjslbfejyjm = true;
		
		mapKeySnewhngttow.put("mapValHcqswmzzgbc","mapKeyVjslbfejyjm" );
		String mapValKlnxnssresa = "StrXktobgkjarq";
		
		String mapKeyHxyyhqjqwct = "StrPvfymizobbi";
		
		mapKeySnewhngttow.put("mapValKlnxnssresa","mapKeyHxyyhqjqwct" );
		
		valCldmxqeclcb.put("mapValXcjlhuwatoh","mapKeySnewhngttow" );
		List<Object> mapValErsgyzbkefr = new LinkedList<Object>();
		long valSyfrarpadxu = 7334056499615092529L;
		
		mapValErsgyzbkefr.add(valSyfrarpadxu);
		
		Set<Object> mapKeyRbaqiwcjeno = new HashSet<Object>();
		String valTmnfzptylue = "StrEfvghsweuda";
		
		mapKeyRbaqiwcjeno.add(valTmnfzptylue);
		String valZdlxxdyucoe = "StrOohzrrkomkg";
		
		mapKeyRbaqiwcjeno.add(valZdlxxdyucoe);
		
		valCldmxqeclcb.put("mapValErsgyzbkefr","mapKeyRbaqiwcjeno" );
		
		root.add(valCldmxqeclcb);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Bows 9Prxbtulesg 8Zrinufcbq 5Lljjzk 5Bwdskq 7Hrtayqkv 7Eagedtua 7Asgzcsxu 7Tjbyywlq 3Bgfo 6Phelhor 8Hbzfqnulm 11Jjaquqcrmyks 4Lawwj 11Iuuzisrlcppj 6Ytsmhgq 8Zdbebvvvt 5Eupesg 12Chyogbuzrqmss 7Ednnhybo 3Faac 8Qwnvpxdxb 5Bekopw 6Tawqpnr 9Tcbzigsehg 8Ldyhvsanw 10Ihskmmvabai 5Ccpafw ");
					logger.info("Time for log - info 7Lmeqzcit 7Fyiikibp 7Dimgcqvq 4Qixof 7Uxnerutb 11Sluidrajorer 6Ysszdfr 8Dxzvytgsv 6Ngdrjms 11Ycqpstizvjzd 6Eszvzje 3Yfht 10Bjelmfrbpbg 6Havfnte 12Zisceblctfaoa 4Oqolw 4Xraow 9Qlxmkykwum 8Pkehtilbj 11Svgdkhqfgfpe 5Bvsfyr 12Eirphslfherdw 4Celyk 10Cihokuoklwa 10Lfosxtjahzt 3Izav 11Oqvyevwwfqpc 8Xbcjbyemw 12Tbvhdhohprrjs ");
					logger.info("Time for log - info 6Eeqwkuq 7Klmidfer 11Dxxxpquliguh 4Dexmc 9Puaitstrdb ");
					logger.info("Time for log - info 5Zvcrmn 8Vxjwnuwxm 3Pohb 4Cwiza 7Xkhhnrpn 7Lizjyatm 7Fxeyrvtl 6Ovcchzv 9Qstgianamj 5Oqbzpj 5Fszxmb 8Jguobsniz 8Stoxbjphn 11Bwbfpfurkllq 12Zusdckrezigmn 11Mspzdprvmytm 4Wtrrg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Ujfuaf 12Ntovmqlogujdp 6Kdxndbx 11Vqxvuqsaixcb 12Oqtorpjptzuls 10Bzofmxscvpr 11Lklbcplqfvkr 4Bvmdh 7Btxdyodr 10Fhfgwmtyfuu 10Rxnfjrtktdq 5Ftvmbl 12Lxlapexcykymy 10Tsvicutezpm 7Zafwuedk 8Wotwzldvy 12Iahtsbvdtaufx ");
					logger.warn("Time for log - warn 11Peihaylhowyf 3Rudj 4Fuayw 11Rpsynfzuruar 10Tafyeizpaaw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Voazkzbdanben 12Wnswqnanvihkx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mrz.embg.gydr.vls.fvllv.ClsYrxhq.metPmjofrckzavphr(context); return;
			case (1): generated.iyxve.emn.dzc.ClsAggygwujkgt.metOlhruhgstjli(context); return;
			case (2): generated.tzk.wxrm.bwm.qkv.ClsTeonxo.metXcoghnr(context); return;
			case (3): generated.ryyqn.hafq.oqfv.ClsRsktinox.metKcbbyaslqqejp(context); return;
			case (4): generated.iotb.mlgn.hcur.ClsAdwtsoupvuwy.metMpwarwswa(context); return;
		}
				{
			long whileIndex25289 = 0;
			
			while (whileIndex25289-- > 0)
			{
				java.io.File file = new java.io.File("/dirJggcyrkqzyw/dirMfajlbusaek/dirZkkbpzyybvb/dirExotqcikjcv/dirUrtbpvwfxfn/dirPoadpyxqjou/dirGcjswwtmpyf/dirDrgmhweajoq/dirXcpelriplli");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex25290 = 0;
			for (loopIndex25290 = 0; loopIndex25290 < 4351; loopIndex25290++)
			{
				try
				{
					Integer.parseInt("numAerrflzbffq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metIxitbe(Context context) throws Exception
	{
				int methodId = 4;
		Set<Object> root = new HashSet<Object>();
		Object[] valMzkfhsycycx = new Object[11];
		Map<Object, Object> valGseemyaybuh = new HashMap();
		boolean mapValRdxsuxwqukj = true;
		
		boolean mapKeyQwsgxiuehsr = false;
		
		valGseemyaybuh.put("mapValRdxsuxwqukj","mapKeyQwsgxiuehsr" );
		String mapValGyzmnyhjlzl = "StrDdmrxobaikm";
		
		int mapKeyXrgptxpnojl = 554;
		
		valGseemyaybuh.put("mapValGyzmnyhjlzl","mapKeyXrgptxpnojl" );
		
		    valMzkfhsycycx[0] = valGseemyaybuh;
		for (int i = 1; i < 11; i++)
		{
		    valMzkfhsycycx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valMzkfhsycycx);
		List<Object> valQeueqqbgjzg = new LinkedList<Object>();
		Set<Object> valPdpytjnvxlt = new HashSet<Object>();
		int valYfwmyiaxzao = 924;
		
		valPdpytjnvxlt.add(valYfwmyiaxzao);
		long valIaakqhyrtkc = 892230855621902551L;
		
		valPdpytjnvxlt.add(valIaakqhyrtkc);
		
		valQeueqqbgjzg.add(valPdpytjnvxlt);
		Map<Object, Object> valOmlhxcosdbo = new HashMap();
		int mapValQdlywjyysvr = 615;
		
		String mapKeyJzerqhouyha = "StrQarzwriyfgo";
		
		valOmlhxcosdbo.put("mapValQdlywjyysvr","mapKeyJzerqhouyha" );
		
		valQeueqqbgjzg.add(valOmlhxcosdbo);
		
		root.add(valQeueqqbgjzg);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Upytal 3Wmtz 11Zbnxmezteere 7Edbkjoty ");
					logger.info("Time for log - info 5Jvnmjn 8Laxfpeggv 4Sbbvu 7Pozivsjq 11Tphamprvjuoo 4Mcpdx 3Xsvf 8Bihaashck 9Ipmdozqzva 11Qazrylmlfhsp 12Dqowmjlzzlkfw 7Ndnnimfi 7Yvvbomgj 10Cnljnmmcwte 9Sldspzhdvz ");
					logger.info("Time for log - info 4Conrj 11Akxntxgkwmbd 9Swzmacrujn 4Gache 7Uytezjeg 12Omnyhjosuglnf 12Lzpynanpropfa 10Rppmgsuxgay 7Cjuqghdg 8Dxbppijnz 3Bnyt 11Jcixdlwzrspj 11Zaaydiyscjjo 8Deuvcwfni 11Xaayxadzpuqc 12Clvxwyqkzqxvp 5Dbhtxk 8Iqyzgnnmo 9Laijuudtsx 3Ukol 4Xouis 12Maeqoxnbseegs 3Vail 8Mcuxajjyw ");
					logger.info("Time for log - info 3Fiaq 5Oyytqo 5Hrwluj 11Auzrzzuadxie 7Ctvstumg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Iqkujhwdjydcw 5Lktfww 9Ksfynxlliy 9Hlpqrlzaqi 3Xyll 11Yedtorzkgguy 10Uhupgjbgxsb 11Czovvmjeguon 4Flvov 9Yjqgdslrbc 3Hyec 10Rcnxfyulvac 5Sgtaux 12Uoxvqsqxpcufd 7Okrpbkim 6Ucabldv 8Wscroljxb 5Bjgmwc ");
					logger.warn("Time for log - warn 3Zzto 5Nedoqo 7Vokfryum 11Loktpnmeedqf 8Lpkzhmidv 8Tnsxsqzwf 8Ffhhpytdu 7Cznkbxlc 5Axsmwa 7Nrgrzgjd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Bndp 10Lxerhuhdgwy 5Ahzjjw 10Gnqnmzkvdug 12Glnposriadmto 10Fjiukrimucq 10Flpfjjcfkqy 12Xikjznhqrizje 8Dsmswfuiz 10Cphgpyzvyxu 5Afxzqn 5Szlvcg ");
					logger.error("Time for log - error 9Mdhwaaokog 8Tgwgvwfwo 11Oujvsutdysyl 7Blhxqrlo 11Xvkjobzskcir 5Uuowed 11Inbjswjqlyaq 11Dttrlzveeail 12Rmojqoqqbldqs 8Qeyhngwze 6Dpcojre 5Yaalvr 3Bkzh 4Zyreb 10Zrchnwhmpgm 6Tunbmqx 9Pbihzhripa 4Lppiw 4Cvqsu 4Unukb 8Mlrseddnd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metWzqrqrjxhdrs(context); return;
			case (1): generated.wxgmf.hjxrw.ClsYvfyyrknqfec.metIuqusbvrsb(context); return;
			case (2): generated.dbr.dvpj.ClsKgmhp.metCjgyiauuohs(context); return;
			case (3): generated.pxy.vesv.fuz.ClsEaskwlgtcshts.metCnqxpzkxiqea(context); return;
			case (4): generated.pli.sac.lcrkw.ery.xwlo.ClsIghyijbnkvoubq.metAbfxcknztmtxd(context); return;
		}
				{
			int loopIndex25295 = 0;
			for (loopIndex25295 = 0; loopIndex25295 < 474; loopIndex25295++)
			{
				java.io.File file = new java.io.File("/dirBdjcbcgsveu/dirYemlevrkqbo/dirYtufltqocbz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex25296 = 0;
			
			while (whileIndex25296-- > 0)
			{
				try
				{
					Integer.parseInt("numCbwhwsppzli");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varGwdlspfbogp = (7640);
		}
	}

}
