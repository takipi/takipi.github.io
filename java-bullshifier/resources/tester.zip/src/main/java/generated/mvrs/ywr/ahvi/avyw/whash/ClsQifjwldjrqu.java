package generated.mvrs.ywr.ahvi.avyw.whash;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQifjwldjrqu
{
	 public static final int classId = 157;
	 static final Logger logger = LoggerFactory.getLogger(ClsQifjwldjrqu.class);

	public static void metVglylwmvni(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValJuqzxlcrnzo = new LinkedList<Object>();
		Set<Object> valBzxtvcgaswa = new HashSet<Object>();
		boolean valZxfwsyletjx = true;
		
		valBzxtvcgaswa.add(valZxfwsyletjx);
		int valFqfffblpoje = 74;
		
		valBzxtvcgaswa.add(valFqfffblpoje);
		
		mapValJuqzxlcrnzo.add(valBzxtvcgaswa);
		
		Object[] mapKeyBnkalxjxfpq = new Object[9];
		List<Object> valYkjdkmrimzp = new LinkedList<Object>();
		int valJhzwqrwpcdb = 267;
		
		valYkjdkmrimzp.add(valJhzwqrwpcdb);
		String valUbweeujquzt = "StrAseeftvmpzv";
		
		valYkjdkmrimzp.add(valUbweeujquzt);
		
		    mapKeyBnkalxjxfpq[0] = valYkjdkmrimzp;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyBnkalxjxfpq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValJuqzxlcrnzo","mapKeyBnkalxjxfpq" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Fmsutrygcbt 8Vogukacpk 6Jqzxeqm 5Blhpsg 12Ullqtooibxvxa 5Smywdj 10Tmklfzwrwbq 5Adeomn 10Nbjwcymhacx 11Ygldqoltvvba 8Pzipribxq 4Evnvu 5Tdniuz 10Riugdemulwy 5Bzkyqk 5Tfupqw 6Xxcftai 8Cjjakjour 10Nzxsdtbcxhy 9Vslmkynktt 10Fpanhzfvvty 6Nctuhyz 8Xovlshblt 10Wntcbicjuap ");
					logger.info("Time for log - info 3Vrwg 8Xsuykbhiw 6Njjeqdn 5Rigfdk 5Toocia 12Ydzjjycrokrgt 4Dexgi 7Qvnublur 7Sjzuqfyj 7Knyhmspm 11Qyeuhfsfspen 3Rgqx 3Yhfm 11Uvksmzptmvdt 8Vjdzwmenj 4Pxskc 8Sbrfqehfg 10Zwpxykyzesu 8Sxjbjhjxp 11Nyvqebzbfaud 11Gdppfjogjgqw 4Pfcaq 7Slhiekwy ");
					logger.info("Time for log - info 12Ccfrahfedkorm 5Xfikze 8Unkzkmexk 8Mnupkzqkn 12Qtlkwcwxrvgjj 11Qkiadoiuotpm 4Vcwzr 4Jlplq 4Yvtzh 12Csucmhbsdkrur 9Shocfottpt 6Qaolwtx 10Ascvjewbkrv 10Oxisnchlsmg 7Dndmuhfu 9Hqszdqyake 11Qskudquecylx 5Tdzifl 5Jtzbzg 4Gkosr 8Dzumzljkj 12Yhotnandxnpem 3Beli 5Bvzpbg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Xqybio 5Izozwl 7Jyvdjzuy 9Loqhzjprdc 8Kbhyietmf 3Vzip 4Ogfkg 5Nnekyb 4Rdggy 10Ogkozfmszrt 10Igwxzlhpfza 4Uejay 10Malbyqvhkdp 3Ayfi 9Ccpglipxeo 10Zmhjoydifqw 11Zkfdnazwsejt 10Suwvfxlnrgi 12Qlhasswtctzbh 10Detvvfaecli 8Ilxolofzv 12Khsbvcdallpci ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Fsmmgjrexjzhg 9Jwceejkcvs 4Ebhfb 11Wsqircltbcts 5Obqwmc 3Swlj 7Swuyayty 6Iraedad 10Yvixcgociiw 7Dghjexdq ");
					logger.error("Time for log - error 9Vcupwocgxs 6Jtxbmhm 3Ooih 8Daizjydxk 5Nudvsz 7Czuhjveq 12Cdlxbvtdyellc 8Hvgenivmb 5Rcbkee 9Fljzvsnfdx 3Yodc 11Juwrcrgsubdg 3Lgvs 10Qbigdvkheip 12Dqualnytwjwse 5Aralkx 9Spioqpfwvp 6Pmmgizx ");
					logger.error("Time for log - error 8Lrejvrcxl 7Jettljmy 6Fcgxfvg 5Lksvbx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xnl.gdx.dmkh.hpyan.ClsNxgzyqd.metRbhfzkkxtnc(context); return;
			case (1): generated.zvc.zkqw.sqxhe.ClsQioplriwzgyw.metHhzxayn(context); return;
			case (2): generated.ewz.kir.rqdl.wup.ClsTcnbjngxap.metXatmnfjmhsznde(context); return;
			case (3): generated.naf.suq.ClsSzodbxxywsfz.metXvowxmginonzs(context); return;
			case (4): generated.zdmfw.qfic.ClsQmanwrctuzecr.metEvpjjip(context); return;
		}
				{
			if (((6393) % 775027) == 0)
			{
				java.io.File file = new java.io.File("/dirUurtfmxpqna/dirUqgsmjalvhq/dirKobunkhzhzj/dirBrsqoakdeef/dirDasnhtrjpyx/dirMiwtavccfra/dirSzhkldkozda");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((Config.get().getRandom().nextInt(910) + 1) % 450232) == 0)
			{
				java.io.File file = new java.io.File("/dirAmeqpahzkan/dirXpegyxzpqbt/dirLwrvovslagp/dirGnxfilhdrgm/dirChrzeexmxwc/dirEotffifiafv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirNzlduijwedl/dirLpfxrbqyvqj/dirLrkftclfwqa/dirBfmzyeaxjvh/dirGuksgzdxryf/dirQkvxhfcacqn/dirOczbcgxlblv/dirEynegmladpj/dirTphhalastpm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metHcdtsg(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valQtgvghfsuhn = new HashSet<Object>();
		Set<Object> valIlrclviociu = new HashSet<Object>();
		String valVqgervrtyja = "StrTqmomzdqqsl";
		
		valIlrclviociu.add(valVqgervrtyja);
		boolean valWkyhupsczqg = false;
		
		valIlrclviociu.add(valWkyhupsczqg);
		
		valQtgvghfsuhn.add(valIlrclviociu);
		Set<Object> valRhtlvskbjva = new HashSet<Object>();
		long valUyxrylrzybi = 7517806672632984282L;
		
		valRhtlvskbjva.add(valUyxrylrzybi);
		
		valQtgvghfsuhn.add(valRhtlvskbjva);
		
		root.add(valQtgvghfsuhn);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Rbhghkrmkwqor 7Tnsgrzhm 5Jxjzcx 5Glfher 10Nuvaucmwoky 8Rtexzptni 10Hxavvkpwgdd 11Coiamxkujplb 3Bfev 6Ptwtoqc 9Bqjwkbymxl 8Tpjzmstex 4Jvmao 3Gywu 5Bmathj 8Pklspadaf 11Pcgktbuchdjf 3Lotd 6Wgbhhjp 6Vsnixet 5Lniuas 4Jniwk 5Lbbocn 4Wbnby 3Pauj ");
					logger.info("Time for log - info 9Tscdchlcsr 12Hdbegvtqfrspz 4Ytgxm 5Unttfr ");
					logger.info("Time for log - info 4Vuqhx 3Rmgt 10Yppjkqrdbtg 5Iultwj 9Qzpvpdzgrl 7Vvhoyvsv 3Odea 6Icbciap 9Uzyqfauaca 12Ucuycsflrnedt 4Ukenz 11Obaehayhnlbk 9Ofihgqvhns 8Boeegayqv 4Isofs 3Bdqa 12Phvubuqrpenuj 11Emioxoixyrly 7Mjinztcm 7Eekuqngg 8Xwurfjjra 12Eydeefjhrfgda 4Ynrsj 12Mlhbdevlqjkbn 9Bhegcyjfjt 9Dexojxxwue 4Ewkmw 6Wtcqefz ");
					logger.info("Time for log - info 4Wnnuo 4Ncbqt 8Jyxjbeiiy 6Wfgqkvb 4Ngqcg 11Ticagbtgmutu 7Khvophsf 7Rwchbrze 7Bowyarcp 11Allariixrrpp 4Dxodv 4Ewjdp 4Qgsqu 12Iyxevpclduupy 10Mkapbqlnytn 7Hzipfrjy 12Leddlopmhrkwk 11Yggofrkjczcv 6Vdjesjb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Shqpckbg 10Fryyuviuftf 9Ypnykiabum 8Yyrallnll 12Qnomaxkvwjwth 8Xchlkfyaa 3Lybe 7Gmdghczw 6Bqkzwba 4Rnykm 3Wfuk 7Jrsddlry 12Xjlvavxtnfcod 6Splplbf 4Qvcpv 5Cttglt 11Lnehfzhabqxx 9Rtehwhbwal 9Lhiwuobnyn 8Fgelqyeoo 3Eylh 4Ajafq 10Bsdusphuxid 6Icdxjnv 6Xywsssj 12Ucsonnncekxhd ");
					logger.warn("Time for log - warn 7Scijwomf 12Dilpsdkaasxje 10Jhcnqfbarqt 10Poqcwtvindk 8Lejqypklw 4Qmjrl 11Vebbkuxcjgog 4Ncghv ");
					logger.warn("Time for log - warn 9Vcikvnjkie 10Dreccwemtmc 9Wukgtakfpu 3Btwo 5Ttdfoj 6Iluesrm 8Ffqjoznvv 11Rguowmxqvxjz 11Nltfxjsmycma 5Rsnjxt 9Esxnmkhzyo 12Qxdmfttdpfirr 3Twyg 10Ofiuwrzhwjm 8Tpgfoqxmp 4Obgmf 7Lyonvvqc 3Qkby 9Xwibfzhcma 10Puegadnmmel 4Ivlnp 12Jrhjvducbnayp 7Mckpzlsz 5Cvcypm 4Khqwz 5Awxwgq ");
					logger.warn("Time for log - warn 6Isevmqa 12Iyywvtfjvrcab ");
					logger.warn("Time for log - warn 11Dclajtmqetev 12Qncuseromklay 9Lnfnbphtmf ");
					logger.warn("Time for log - warn 7Gazwheon 3Qkgn 8Qzjuupioe 10Yqigueqcrup 7Kjdodcwt 6Tqhxvxx 3Bsbh 6Lgntpcx 6Useedfs 3Uokp 4Wllzg 6Ztexbdb 7Usszidxj 12Kgkbptpuzncoe 12Fxlpewgnzhwvt 4Bnfpl 7Uzahhzod 10Klewaibvyza 10Wuwfhmpwxtj 5Caowmh 5Xucpws 10Uyhgiofilac 3Eouq 8Lqmhjsrwo 10Tqdmsrelzdn 3Ppoj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Jvlgzshgaxl 6Dlfbgzg 4Feimr 10Bxmwbekmvmd 4Efake 8Tbiqiwdtk 9Ljhylqtxqy 7Gtiezgqu 10Uadrcgmrujj 6Smcxewb 5Oaemiq 12Evbjujmbhlvpi 5Lsdfgu 5Rsekfr 5Lqsnqj 12Byyqothunwofh 3Iiud 9Mxnoyqyabk 10Ivxkkqwxfei 3Koya 12Nyptcippvdhgs 11Momstcpvzxke 7Pclorzcl 4Wepdd 9Jnzwpcvyip 9Wuedlwpdfc 11Nuklsulwdpfu 12Wkrlqbkgsiwqj 3Dbpg 8Uivkgeppc 12Tyfsyvccmkfxz ");
					logger.error("Time for log - error 12Wvyyfujuaykey 3Fimu 8Bdvbemsov 3Alwk 5Wylohr 6Abcmxvy 4Lygbb 8Wtzzzbizh 7Gmqltuqh 3Hbjg 11Lvmxngptglya 12Uuicwkcrzafdc 7Aqgoxowt 7Mfokwawr 9Kypvksgeti 8Kojbrbwhs 7Zhkfsuzr 3Ckps 7Trfqydtx 6Nlmusav 7Yqyjjacc 4Vgtne 7Gvomavgc 9Cwkatmwnnh 10Bdcjrppxkjy 7Rcofzykm 4Yvlzb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.idk.jvavb.vjuwp.iuzf.fawz.ClsRtwkffyfhbvpjl.metFydywnh(context); return;
			case (1): generated.ocklj.sbz.ClsVzertfboftzd.metOvqborsb(context); return;
			case (2): generated.ayxg.baac.ClsIciuzantocwhkq.metGfdmrrakz(context); return;
			case (3): generated.rnr.pwsrq.cbi.tat.ClsQsqavl.metNujgqvqobxeyw(context); return;
			case (4): generated.qer.bwl.ClsCbeyhqqy.metMimivk(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numKicrlpqrsbl");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varNvgxuvutxia = (895);
			if (((2824) % 774757) == 0)
			{
				java.io.File file = new java.io.File("/dirEkvulwftges");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numFkdwpethzdr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metEqwmtkny(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[8];
		Object[] valQgcjcqteedr = new Object[4];
		List<Object> valUvasmrdclkm = new LinkedList<Object>();
		int valWaydjlsyfqq = 546;
		
		valUvasmrdclkm.add(valWaydjlsyfqq);
		long valRlanipoqoiz = -953366777213731248L;
		
		valUvasmrdclkm.add(valRlanipoqoiz);
		
		    valQgcjcqteedr[0] = valUvasmrdclkm;
		for (int i = 1; i < 4; i++)
		{
		    valQgcjcqteedr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valQgcjcqteedr;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Axelgparx 10Tvjzdciijju 4Xoupj 3Rbqj 10Tzgzmkzwwvo ");
					logger.info("Time for log - info 7Fvmksycs 11Uigviwlszbkr 6Yyaiojm 4Fvyqo 8Euyxkkkoc 10Ymlvqzgwftd 4Czzhv 9Nmxvssuufs 11Alpvipbwsxxl 8Jgnbwitnf 11Csnjifibqrem ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Wukagjxx 7Hyfmyhjm 4Erxzg 7Lgmogstp 5Hqnewx 11Hvbwggxiwwmg 10Wqpwjniruxn 9Xezkfzlhgi 7Urwljboz 10Jypsfugnkuz 12Mkikdckgwliek 11Ursjcvaqvaqn ");
					logger.warn("Time for log - warn 6Nhkgdex 10Pdttmjesyqz 4Khssa 12Pignlrweuctou 6Gkafmxk 11Xtfxlpzqlusg 3Pgjl 8Ctqxfsnpw 10Nydxxhcotwk 11Ericcaoeeilx 12Eqzxotvoqxtow 11Hmiujcwkjgdd 6Nzcqgmb 8Phgrxazpn ");
					logger.warn("Time for log - warn 4Iwysz 9Vamkmvehlg 7Evnvmnra 11Gknfzjgaywfk 11Cnrzgaiewvvl 6Wkbtimc 6Ohazssw 11Jbrmznuliqae 8Iqidldtff 8Hzzprreof 5Zxcpml 12Cjxnjdvfonuly 12Xulcaiqjuxxqw 4Hagzk 9Qncyylpnna 3Mgzw 6Abfzrhi 4Hdrfb 7Ogdsazfl 8Ahshjitey 11Zeuwbvikowks 7Guplzymv 12Mlhdkblguetlt 8Hvpwokfny 9Aeriqusbma 5Mbvwla 11Pfadxhitlyau 4Phtih 6Argjnvv 12Ixhkzyderchxu ");
					logger.warn("Time for log - warn 5Jefcjj 6Nydfisj 10Oyqzlscxbxr 6Uxbfjyq 8Bhgelptoi ");
					logger.warn("Time for log - warn 9Gvgzskztbo 4Ybdcs 10Nykldoczzpv 12Tlodwokllkpcu 8Fqzfutzfo 12Fxakoyzfabayl 5Bbylcg 12Wfhequxizskti 3Eqhv 12Regtnwahjynkz 4Kedol 6Tqdyror 6Xjlupqq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Llbueuy 3Pubv 7Rodviniq 9Vyvcbvcrnx 7Uczxegio 6Huokiqn 4Zxhbe 5Hfvmns 10Xxjzbpjknzd 3Hjxs 10Hdpwmjcnaga 10Prqlntcrktr 4Csygr 4Vjnbh 10Bdalxacevyp 3Etej 4Sqakq 10Ldwuqlsxzkd 9Ygwxmptyyz 9Htyczsviwj 12Mwkyglxwkysyr 9Wpykwtzrrj 6Jhjkfxd ");
					logger.error("Time for log - error 9Zuztmisvyg 8Sihnpufqg 9Hztvnkturb 10Bhlbnlttspy 3Uuzl 12Narakaxozepkc 8Jioxzsbsc 11Eohtbqnwceex 3Tiwo 7Qectdplg 3Eksj 3Ajpk 7Hruycrjc 5Qcdcqc 4Salti 4Gxkuw 6Ykdjqhd 4Ypnky 8Dszkmxvok 3Nyva ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.njly.vbegw.ClsZmoko.metYqrfdvqsyetp(context); return;
			case (1): generated.opcr.jgy.rftd.rkx.ClsJjouwg.metKtdrtpazip(context); return;
			case (2): generated.ocg.pnhd.assci.ClsEkxxqpavkqxkay.metDpnizequfd(context); return;
			case (3): generated.ajbel.dvbe.pmx.gfhen.qjvpo.ClsFwkvrnv.metXipxiwvyvncxvi(context); return;
			case (4): generated.jlzkx.vlyxg.uui.ClsYmzeuds.metMjkebsmedso(context); return;
		}
				{
		}
	}


	public static void metZuirhqgb(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[3];
		Object[] valUgfhfgicxbe = new Object[6];
		Object[] valTlkyfjipnzx = new Object[10];
		int valCkavoiidpno = 168;
		
		    valTlkyfjipnzx[0] = valCkavoiidpno;
		for (int i = 1; i < 10; i++)
		{
		    valTlkyfjipnzx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valUgfhfgicxbe[0] = valTlkyfjipnzx;
		for (int i = 1; i < 6; i++)
		{
		    valUgfhfgicxbe[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valUgfhfgicxbe;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Xqlvm 10Jrkvvxkmhdm 3Mmix 7Khpcujrc 3Qxvu 4Rvwfw 8Jssahqwji 9Clkbkgzpiy 3Rual 5Ociouk 12Ejsevwgonnclm 11Ltwffxeyudvj 3Ywmd 5Dhntgq 5Xskttz 8Ipgrzmrhv 5Tnrenw 6Cfenauc 12Vqjucggdrndki 6Mgtpvny 6Tnbtxgh 11Hpbcdhfzlfss ");
					logger.info("Time for log - info 3Zezy 9Wdbqmnsewa 12Qfumeudmttnxy 8Zzjxwxrlr 11Otikwqhqxjfy 9Hgnarlkafq 9Zguegdvntl 6Rqlsbkt 11Pdimzshqzdxz 3Phyj 3Lvsp 6Hvdcvmn 7Molbtxsn 10Xpucaldqaom ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Vaehotc 11Tosdnpijdfxh 8Lfoiwkqnd 11Fhwvxxnyhjbc 5Xxertt 12Kexxpnywmzbrp 3Jkrk 12Ynbooevaijyxu 7Kleujsnm 7Lmzjizks 8Btfefsvex 8Fmxbxvkdk 9Pjwtnqbkhr 8Xkuylqtrn 8Kmfuyjfcc 10Oihvkslxjqp 12Weucnxydwqfgp 9Pgoejiuiro 4Dmbzc 10Maqhulrcjof 3Gqmf 7Zwekwbll 11Xyesgsawiqbq 4Vmdws 3Cpip 9Wxfvpvkpew 6Sdpgegk 6Cfaydaw 12Ydgnbkwyjiitc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Akqwfjpewdr 8Podppqthv 5Mdgyyi 9Bbkpofndba 7Dhhyzvcw 11Lnkufxedlnye 8Psvpqfzst 10Ktuimdgdmmh 5Vuiylq 9Ejeaztqidp 12Xiacjdqknkqic 3Ajqo 3Uxor ");
					logger.error("Time for log - error 10Frzcrghvkui 7Ycemtguz 6Vyhzund 11Ejuspwwyxhcn 7Bzqjpglb 6Tcktpwj 11Dbwtylkdxyzm 5Zdgkls 10Yxtvwsheozx 5Wyjqpd 5Tnxkxm ");
					logger.error("Time for log - error 10Kthbmuswtnf 11Ltfyhffhwoub 8Lnjeuyovw 11Cxvlkawuhdxp 11Pqicrqhrcwyr 10Msixvjlqmxv 8Bmoqzcicx 3Mfsu 7Eljnjknz 5Spedxj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zfo.wctt.rjxf.wjfcy.ClsKuhcjj.metXghvhmjkczsxr(context); return;
			case (1): generated.ebl.tdhe.hblqj.plazc.otajb.ClsEihhumwr.metTdhkrrekocmlh(context); return;
			case (2): generated.tgr.kelz.siz.xfels.ClsKydjl.metQmhajcedjutgex(context); return;
			case (3): generated.gmk.vzs.crbap.ClsEkyhsmjeh.metLuteowlbyyvlf(context); return;
			case (4): generated.kcrh.cmo.yws.ClsBlekldezyl.metZrfrenur(context); return;
		}
				{
			long varCgoshcqjuyj = (Config.get().getRandom().nextInt(207) + 4);
			int loopIndex22859 = 0;
			for (loopIndex22859 = 0; loopIndex22859 < 3227; loopIndex22859++)
			{
				java.io.File file = new java.io.File("/dirGliinyjjher/dirBmrsckfyqng/dirWyfpzlojuol/dirWwsvmsmxhqe/dirBdyadqtjkmf/dirHbucfcuiuqs/dirVvzztjbtqjn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex22860 = 0;
			
			while (whileIndex22860-- > 0)
			{
				try
				{
					Integer.parseInt("numGvgchbsavbd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metOmmhlelmwob(Context context) throws Exception
	{
				int methodId = 4;
		Object[] root = new Object[2];
		List<Object> valRhnalfxaaqf = new LinkedList<Object>();
		Object[] valJzpiposzymt = new Object[9];
		long valEgwceemvtvu = -1516397969570749457L;
		
		    valJzpiposzymt[0] = valEgwceemvtvu;
		for (int i = 1; i < 9; i++)
		{
		    valJzpiposzymt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valRhnalfxaaqf.add(valJzpiposzymt);
		
		    root[0] = valRhnalfxaaqf;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Ipupn 4Kywvr 6Cpawswj 5Mjljvm 3Vkdu 3Wgpa 11Uiedyvcueuvt 11Ywqmrlygtmhh 10Ixgkngifbuj 10Jzfcuuxlvkw 8Rdkkfgxok 9Koygjxjznx 9Vvqggseuuv 10Zwmavjdgzak 7Wlraxdlm 10Vgqkkkcbiuf 12Vjptbhqajvlvz 10Mglpjyhuzbe 10Hdrvlzqfomv 9Wvoskvsdzl 12Kmptcsuffahcs 10Ufvbekolxbd 10Pwbbvvhxbes 10Wqzvlmebojt 10Attadvnwjsa ");
					logger.info("Time for log - info 4Kdwxj 12Qtfnywzjngzuo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Qkmgvaavduts 3Tucf 8Zjbxhrbhh 5Kdzxtp 8Jjlumpwat ");
					logger.warn("Time for log - warn 6Dapksxu 5Tdinex 3Mgdp 8Ekxrbwkgx 11Iiicxdbpkyng 4Rlwho 7Cdhbbxpw 3Bkzu 6Syfdldp 9Wuhgebpjia 8Cxbyyrhcu 3Lysp 5Jpbdxz 3Pruj 3Cuqp 5Wuaxnv 8Rhtnsvvee 12Kdmybvegjgswj 11Hqrgnepkhnpt 5Nkpnif 11Mvzkcusfigha 12Kfnpwajbtnrjm 11Mlugkewdxkvk 10Kqiqtxmtpgc ");
					logger.warn("Time for log - warn 7Qnqafbjb 9Uvxgivgeor 9Soqckwjsuw 7Mrqvqbjv 9Lguzujrikn 10Zvdsnsfwkct 6Lxuqoii 6Swdqxdt 7Nkkyvsep 8Fmccyayhr 8Fscfrjxic 7Nthsldzo 6Zunsuao 5Djbasv 3Rwiu 10Dgqidhgtpib 8Dwecovfgr 10Nfgttsqnmsm 9Hwmwhjcuqm 10Amzvahuhzfd 8Fbjsjmvoc 6Tdvwexe 12Eygmtponghlse 5Rmpkpc 11Fcbohlyrxyog 6Ufbaafv 3Mhsz 7Venflsdg ");
					logger.warn("Time for log - warn 4Cpxog 11Mxzpmtebbjsb 9Gzmvetwemg 6Tqfefsw 5Npgddf 7Gvvkliku 12Qkzhpgjoisgia 5Rfulnk 11Pmmffdhyztpg 5Qhmzxe 5Ifdhkb 8Faqauyqvs 3Xuri 3Kyal 10Oxudrjegrma 9Pluipgsnwu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Ykcpnu 7Vdicqlcn 9Qyzxgjteqr 11Kbyljcwmwiql 4Yppiy 7Ywhazrkh 4Mpntp 6Xabuwic 5Zgnduk 4Umdqd 8Zpdxxyvzn 11Gppzeuegusdg 3Grwq 6Vlxsxcm 7Rfuofopq 6Xyqodxs 10Jpxeoaswtva 12Trhotsmchvyjl 4Xwuoc 5Swfhyy 10Lchaelggbqk 8Sgynurcfq 12Tzjwkewpihoig ");
					logger.error("Time for log - error 10Wnxodonpyrl 12Jayrudkphqdha 10Ijuoszsybtj 10Jamqxjbjpxi 8Udjgmbyph 11Rymcgmvbzauf 8Ansgczfci 7Pylhpdeo 10Ffuzfpyufon 3Zxmc 3Ahws 3Brtb 11Djlagaxklqhy 6Dppkzvw 6Yzbqgkt 12Nwhjjemhkllpv 8Owylixpqo 4Ypwnd 8Exkimpwcv 9Hltluqvxfg 12Yiiewfykyybfv 4Zdeok 3Psox 7Upwmefpu 4Zrhjm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nrrh.nxnu.xat.kha.ClsLoiagobs.metImjogkxzrsynw(context); return;
			case (1): generated.vna.rvrp.nspt.ClsOdrnbbdzkkwwtm.metAigotoanishmlc(context); return;
			case (2): generated.zoaxa.yfbb.ClsTybiqkipwo.metQnlswcnqbxmqgz(context); return;
			case (3): generated.kdu.bhxiw.zym.ClsZlzcdqn.metFbnoxeuhjmavi(context); return;
			case (4): generated.cqy.ffep.ClsWvinhicphnl.metWwbnpyd(context); return;
		}
				{
			if (((5022) % 549146) == 0)
			{
				java.io.File file = new java.io.File("/dirCfgwsuhqada/dirMrlflkwbmat/dirKqggnnaqxxs/dirMwnjoektany/dirYpvvzraqcrb/dirFqfwhqcovhx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(603) + 5) + (1484) % 255655) == 0)
			{
				try
				{
					Integer.parseInt("numDpydcolsejl");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
