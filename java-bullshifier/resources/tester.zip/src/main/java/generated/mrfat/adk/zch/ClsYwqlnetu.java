package generated.mrfat.adk.zch;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsYwqlnetu
{
	 public static final int classId = 263;
	 static final Logger logger = LoggerFactory.getLogger(ClsYwqlnetu.class);

	public static void metCadvvicigiy(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValDkakymbrzbw = new Object[6];
		List<Object> valRzcrphytfoa = new LinkedList<Object>();
		long valNhslbumwkwi = 2848002929691183225L;
		
		valRzcrphytfoa.add(valNhslbumwkwi);
		
		    mapValDkakymbrzbw[0] = valRzcrphytfoa;
		for (int i = 1; i < 6; i++)
		{
		    mapValDkakymbrzbw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyZzlgwedovjw = new LinkedList<Object>();
		Map<Object, Object> valOdfgsquoror = new HashMap();
		String mapValYumxmjrtgdm = "StrDjqfcfynzuz";
		
		boolean mapKeyVwnmayuxmzv = true;
		
		valOdfgsquoror.put("mapValYumxmjrtgdm","mapKeyVwnmayuxmzv" );
		
		mapKeyZzlgwedovjw.add(valOdfgsquoror);
		
		root.put("mapValDkakymbrzbw","mapKeyZzlgwedovjw" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Xkeahyjupave 12Fxusjavfhhgmk 7Lxajheqc 3Raae 7Ukpivkcy 12Mymqikvfnjtkv 5Zfvuyh 12Ajjdzohizjtza 10Oagcpwieymz 7Gkkddoxl 10Fitwymtxqlm 12Mmppyntexnbho 3Eyow 5Hojozy 12Ialdixwpgoyql 11Yrqlawzkcgaa 10Mhqtvjouoyr 5Yaithz 7Wtndhosg 7Avfotipd 5Tpamuz 11Aioqkcyjrhdn 7Ofesnoyi 11Niwkljwghgks 7Vxsseaxv 6Caukfcj ");
					logger.error("Time for log - error 5Rgajxz 5Zdupkf 6Jctvqzw ");
					logger.error("Time for log - error 3Xsax 3Flyy 11Yjmbavwmabuc 11Irenzewducrq 8Qiusdpbsx 9Auulzkvjag 4Dglps 9Rryeyjworp 6Zmwjenx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qpya.todk.woo.rrzxr.ClsQlmcomguvtqu.metVbgwaaycr(context); return;
			case (1): generated.afba.qbfns.sure.ykux.syv.ClsCqlibdmm.metYjsgjmdmtzt(context); return;
			case (2): generated.fpa.lsm.ClsOulug.metQkxwhcwddo(context); return;
			case (3): generated.wkonu.vce.nspm.ClsXupklxzgrjs.metGhpwtlnnq(context); return;
			case (4): generated.fzd.qgqjp.ClsVzqqvdhb.metMsjbhqpplani(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(114) + 0) + (Config.get().getRandom().nextInt(767) + 0) % 466818) == 0)
			{
				java.io.File file = new java.io.File("/dirMvvlineepyy/dirTsxzlghqiju/dirNahzzhuhwtx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(529) + 3) % 771631) == 0)
			{
				java.io.File file = new java.io.File("/dirUvxggskitan/dirDctwohhntih/dirUrfwvhsnwbi/dirGltjkdpinzz/dirSuldxfkcitj/dirKmqatecynqa/dirShrepdfpzqg/dirTapciomjzak/dirOfwgjvrekjd");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numLtlavikpglp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex24572 = 0;
			for (loopIndex24572 = 0; loopIndex24572 < 3264; loopIndex24572++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
