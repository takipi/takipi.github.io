package generated.jugrx.qsp.hjtfe;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsIaayunfezbzpm
{
	 public static final int classId = 453;
	 static final Logger logger = LoggerFactory.getLogger(ClsIaayunfezbzpm.class);

	public static void metHcquj(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valYvpwtjveegc = new HashSet<Object>();
		List<Object> valFuwcxfbeyhr = new LinkedList<Object>();
		boolean valOzdpwutanmp = true;
		
		valFuwcxfbeyhr.add(valOzdpwutanmp);
		long valFgehxrheyul = 8554327904604539432L;
		
		valFuwcxfbeyhr.add(valFgehxrheyul);
		
		valYvpwtjveegc.add(valFuwcxfbeyhr);
		Map<Object, Object> valFgjlrjdwrng = new HashMap();
		long mapValYmxojpazbrp = -5944682089221951468L;
		
		long mapKeyVlyzshojhdc = -7896355898649813620L;
		
		valFgjlrjdwrng.put("mapValYmxojpazbrp","mapKeyVlyzshojhdc" );
		String mapValUakfkdrqogx = "StrNtymiznohor";
		
		String mapKeyJzqvvtuqggp = "StrYltvbqxahdp";
		
		valFgjlrjdwrng.put("mapValUakfkdrqogx","mapKeyJzqvvtuqggp" );
		
		valYvpwtjveegc.add(valFgjlrjdwrng);
		
		root.add(valYvpwtjveegc);
		Set<Object> valSnmviyphgkm = new HashSet<Object>();
		Object[] valQthxujvidvz = new Object[10];
		String valNzcgcaxthej = "StrOdrpcskwivt";
		
		    valQthxujvidvz[0] = valNzcgcaxthej;
		for (int i = 1; i < 10; i++)
		{
		    valQthxujvidvz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valSnmviyphgkm.add(valQthxujvidvz);
		Object[] valCbsxywpdpoi = new Object[3];
		long valAxzdtvytldf = 5006749521529972367L;
		
		    valCbsxywpdpoi[0] = valAxzdtvytldf;
		for (int i = 1; i < 3; i++)
		{
		    valCbsxywpdpoi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valSnmviyphgkm.add(valCbsxywpdpoi);
		
		root.add(valSnmviyphgkm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Zxridmanp 4Tevvn 7Tvsfubem 12Yssdvrfjwocqp 5Etffca 4Sxlis 6Jmaweby 4Hfjzw 9Xeocghshhp 6Yxlxfxv 11Rdhkuzakceey 7Sioehlwe 8Pzggzfegv 5Ahshda 6Wyacjja 8Kmzhnkrmv 5Ojntpl 7Mwqgalig 5Jtumfw 8Sfahsthmf 7Bqjubqsf 8Tfqbsxzyd ");
					logger.info("Time for log - info 6Kvclocl 10Tnomuprmpmg 11Rccdqmequpfl 3Utwr 11Kyrhxlzrksvp 8Fnefswrwy 12Anhqvtcohirsk 5Lhdcdc 4Wnlry 6Oojkauf 12Qsghnzczaezsg 3Aiog 8Vhylctvpc 12Qrangisalguhd 12Fhuunhcocitzl 10Iyafhcgsoij 12Aobmqnwozwxsf 10Hzwdpnjkcst 11Jggvjpgecdop 9Rquujlkwis 5Cqtifg 3Jvgt 11Wijymxhozgse 5Xhobkt 9Pgyzkxpqgf 11Ufyzkhllruft 4Xtedf ");
					logger.info("Time for log - info 10Pcnnclwrewz 12Grhoqyhvulntx ");
					logger.info("Time for log - info 4Oosoi 8Fzevvcbfg 11Omoprbglewlc 3Tipe 10Qrugatfxxsh 12Qyuziuuxzvlhz 6Ainwudh 7Xivkdfhn 3Luhh 12Bftcudgfagxwk 3Eveo 6Mixvrvv 11Lefyblssjpeu 10Yqooasltxqs 6Nrotjtp 5Sncrrm 12Bjleolprfeldt 3Jwdu 10Dsizadtvwxu 5Kirtxa 11Vfglqqyfivjf 8Syclbvidc 9Ukfvazzkno ");
					logger.info("Time for log - info 5Tjiqcb 9Cbwhvlxvvn 12Odpeegjqkjscz 8Hettmvfwy 12Boogsntzxymsf 10Jxqjwaquvhj 5Pgtwrs 11Ahfjlvvjogpr 10Uqfnhaqpbti 5Pukbri 10Zhmsbrvutbo 6Rdnlxdv 8Hixgbqkjb ");
					logger.info("Time for log - info 4Nwzms 6Ushfdhl 8Cbjiexhrz 10Poopyntarfc 5Gpygqu 12Dnpeussjzqwba 12Nnfsyxkxngrtv 9Unjuljtxrp 8Uboiyzryl 11Whstgqsibnmw 8Yfiianzik 8Gtyiwtvno 8Alucsihmw 8Mexhzavty 4Rqzsm 10Rlgvqaxoxfe 9Jucgsctcew 5Arlvvs 11Loizovtuhpro 10Hfcdircsydm 11Fgogwweefsfp 8Glmbgyrww ");
					logger.info("Time for log - info 11Jpgfjkvjpmyi 7Actfvydo 12Oygjujpdcxexm 6Wwwxqoc 11Xabodkndbaxj 3Juum 11Lmysaiylwoml 7Yytwpafe 8Abbvphlxo 7Uqdomcmd 10Zrlkvooqsnr 8Xknclfrlt 7Xqumwrbs 5Jnomas 9Jfiufgdgpo 10Vmowzxwixxb 12Junsedajiiuek 3Fvlp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Ltyhjzel 9Znubvqkptv 7Glegyait 10Gotosjknldc 3Mxbz 7Nsayeszw 12Eokvnftgisqpe 3Zgns 9Syeynejucp 9Wogqedfwnk 11Rfcnnhmukaup 12Xzmypiruglyww 8Lmlbnttol 10Wcraumcacrg 4Vymzv 4Hmjpm 3Mbpu 7Zwniulvo 3Sobn 5Wrhbwa 9Brdjayjkny 3Jmmb 9Ldfkgmmlte 6Ifmymnn 10Oivervildmo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mbn.igyf.ivup.sglb.ukb.ClsQzhoqgskicnjw.metWrxexkxzovhdv(context); return;
			case (1): generated.vere.yue.xag.ClsLhubirlwqfrd.metAabwmhtdfmzhx(context); return;
			case (2): generated.ueynf.ovqsn.bjpnz.bhq.ClsPrqva.metCctuwbvdsnzuo(context); return;
			case (3): generated.hgr.jgeh.ast.ClsBwtgykt.metGnslwfxjnxwudj(context); return;
			case (4): generated.psl.vgj.rgm.ikl.ClsWqomoi.metIuvjevfw(context); return;
		}
				{
			if (((6383) + (4453) % 198131) == 0)
			{
				java.io.File file = new java.io.File("/dirQiljvjsdwza/dirZmcdwrkffdj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((7248) - (467) % 823519) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numYydxzsowumb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metEilzljhjnznyt(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValOojtkxewbsr = new HashMap();
		Object[] mapValAbwtutzndkj = new Object[10];
		int valRrhrsgvcxoq = 965;
		
		    mapValAbwtutzndkj[0] = valRrhrsgvcxoq;
		for (int i = 1; i < 10; i++)
		{
		    mapValAbwtutzndkj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyLxzatrmpivq = new LinkedList<Object>();
		boolean valXgmsfklecwp = false;
		
		mapKeyLxzatrmpivq.add(valXgmsfklecwp);
		
		mapValOojtkxewbsr.put("mapValAbwtutzndkj","mapKeyLxzatrmpivq" );
		Map<Object, Object> mapValMaroskhlpif = new HashMap();
		long mapValDavrzkrrmnp = -2559074458856685002L;
		
		String mapKeyZkrwslxiuqw = "StrZhztgsfwywb";
		
		mapValMaroskhlpif.put("mapValDavrzkrrmnp","mapKeyZkrwslxiuqw" );
		
		Map<Object, Object> mapKeyHmxvctqsegr = new HashMap();
		long mapValUjurzigfhcp = 4990068878809380757L;
		
		String mapKeyRvqwmdaroeb = "StrWzhoubziken";
		
		mapKeyHmxvctqsegr.put("mapValUjurzigfhcp","mapKeyRvqwmdaroeb" );
		boolean mapValAcbklwsiiyl = true;
		
		int mapKeyInvtqshqzvg = 845;
		
		mapKeyHmxvctqsegr.put("mapValAcbklwsiiyl","mapKeyInvtqshqzvg" );
		
		mapValOojtkxewbsr.put("mapValMaroskhlpif","mapKeyHmxvctqsegr" );
		
		Object[] mapKeyDztnlptekjs = new Object[2];
		List<Object> valEkegrrkmoqq = new LinkedList<Object>();
		long valSejwvsujmpf = 1364280975485199661L;
		
		valEkegrrkmoqq.add(valSejwvsujmpf);
		long valNkezvscmsaf = -2581162191163727343L;
		
		valEkegrrkmoqq.add(valNkezvscmsaf);
		
		    mapKeyDztnlptekjs[0] = valEkegrrkmoqq;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyDztnlptekjs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValOojtkxewbsr","mapKeyDztnlptekjs" );
		Object[] mapValXrswwpdmmdr = new Object[10];
		Object[] valAvlyssnypac = new Object[3];
		boolean valQwcwyxdvgew = false;
		
		    valAvlyssnypac[0] = valQwcwyxdvgew;
		for (int i = 1; i < 3; i++)
		{
		    valAvlyssnypac[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValXrswwpdmmdr[0] = valAvlyssnypac;
		for (int i = 1; i < 10; i++)
		{
		    mapValXrswwpdmmdr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyCewygntanhh = new LinkedList<Object>();
		List<Object> valMyrpfgizycf = new LinkedList<Object>();
		String valPuzsqjwnlzx = "StrFaiaejbyaif";
		
		valMyrpfgizycf.add(valPuzsqjwnlzx);
		boolean valXdpuoputjjy = false;
		
		valMyrpfgizycf.add(valXdpuoputjjy);
		
		mapKeyCewygntanhh.add(valMyrpfgizycf);
		
		root.put("mapValXrswwpdmmdr","mapKeyCewygntanhh" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Lkamrusd 11Mmaycapsvqlm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Nyhoi 12Ipnmyawhtxtnl 4Eefsi 7Tyunwpyl 6Vnulfrw 7Uktmqcug 5Fsovgp 5Eeshjy 3Riki 6Msfzvuq 11Jnefbkxkkavy 3Vsjr 5Jyjrjt 6Gxwigkr ");
					logger.error("Time for log - error 7Bwisqjfp 12Xrdizjvatmekp 8Pphmjcptp 3Ullr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdhb.psopx.ivn.rkn.apqvp.ClsKaatjkanbespks.metLvjabphis(context); return;
			case (1): generated.lfkk.ncy.gpf.ClsMafxzncfnwvsdj.metSxjirq(context); return;
			case (2): generated.hnmnf.dxh.laih.zpf.ClsDfldwucgkze.metGuskuyiavglhbb(context); return;
			case (3): generated.maoc.ohm.nwzbx.efqn.ClsOzonhytosc.metIeedbzcj(context); return;
			case (4): generated.obfi.prawn.asr.ClsHvlzhrjejvoom.metCqwbu(context); return;
		}
				{
		}
	}

}
