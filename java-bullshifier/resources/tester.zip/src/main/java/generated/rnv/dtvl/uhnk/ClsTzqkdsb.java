package generated.rnv.dtvl.uhnk;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsTzqkdsb
{
	 public static final int classId = 442;
	 static final Logger logger = LoggerFactory.getLogger(ClsTzqkdsb.class);

	public static void metSeczfqzvcdesmp(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[11];
		Map<Object, Object> valJkqvvpqhfwx = new HashMap();
		List<Object> mapValVvbiqmatmby = new LinkedList<Object>();
		boolean valLhebvfwwbyi = true;
		
		mapValVvbiqmatmby.add(valLhebvfwwbyi);
		
		Object[] mapKeyJjsnermvwgv = new Object[7];
		String valBzbovpdzlsj = "StrBryfjoazbpl";
		
		    mapKeyJjsnermvwgv[0] = valBzbovpdzlsj;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyJjsnermvwgv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJkqvvpqhfwx.put("mapValVvbiqmatmby","mapKeyJjsnermvwgv" );
		
		    root[0] = valJkqvvpqhfwx;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Iqwctbuxtzzmu 7Anxqoccv ");
					logger.warn("Time for log - warn 6Dizybas 7Kpgqztpk 6Ihgmpzu 8Zqxtcupsu 11Ajkbafvsgrzw 3Picq 11Dfkhwuufsipl 4Sisqk ");
					logger.warn("Time for log - warn 11Azstibanvmhn 11Vuvgpsplwoht 6Lhmwdjq 7Ukzhazjl 8Vynrmckvt 5Knqzdb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kdtwm.lzen.mpr.ClsNfgcbhcbckej.metRvvjmdhdx(context); return;
			case (1): generated.epi.quvm.dwt.ClsQoovjnirkdxzq.metDdmuknlewzs(context); return;
			case (2): generated.maoc.ohm.nwzbx.efqn.ClsOzonhytosc.metIeedbzcj(context); return;
			case (3): generated.ymhs.ivq.mlr.cezkl.gzyiv.ClsKvdrph.metXevuffadmfcuxi(context); return;
			case (4): generated.dyv.vxo.ClsWrwpfswr.metWnivtvbltsfqlg(context); return;
		}
				{
			if (((6749) % 219658) == 0)
			{
				try
				{
					Integer.parseInt("numRhzlryphwvd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(179) + 9) + (Config.get().getRandom().nextInt(246) + 5) % 164824) == 0)
			{
				java.io.File file = new java.io.File("/dirDflslhqblwy/dirLphboxhombn/dirJqouerzxazd/dirIynebcreqoi/dirDcmxjhtjncn/dirBrbmvscyqqm/dirGjdpqzauqqu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varXyzoxzukguy = (503);
		}
	}


	public static void metKrrjeushc(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValCbjkcsuofpo = new Object[5];
		Map<Object, Object> valYrlliduygmk = new HashMap();
		int mapValGkfttdoowog = 291;
		
		boolean mapKeyYefmyrbznkt = false;
		
		valYrlliduygmk.put("mapValGkfttdoowog","mapKeyYefmyrbznkt" );
		String mapValAldlbbucqfd = "StrDocgrjperup";
		
		int mapKeyOeaebanhavf = 816;
		
		valYrlliduygmk.put("mapValAldlbbucqfd","mapKeyOeaebanhavf" );
		
		    mapValCbjkcsuofpo[0] = valYrlliduygmk;
		for (int i = 1; i < 5; i++)
		{
		    mapValCbjkcsuofpo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyImoftehyxem = new HashSet<Object>();
		Set<Object> valEuqxxrvmxen = new HashSet<Object>();
		long valNabmonjabew = -3243483212711668692L;
		
		valEuqxxrvmxen.add(valNabmonjabew);
		
		mapKeyImoftehyxem.add(valEuqxxrvmxen);
		
		root.put("mapValCbjkcsuofpo","mapKeyImoftehyxem" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Taxuwkahtamuf 7Avcnznxj 7Ggkvljqj 6Loigjdn 6Bosgkir 7Soajzclm 6Uuwrxhk 5Ygtbpp 8Krbpgnvkp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Pldbstkf 11Gaofhhdiesfi 8Tsxzsituv 5Cizzwe 3Lkve 7Tzjowcan 7Cnabceyc 11Lbuigfzijtjs 9Kniyaypups ");
					logger.error("Time for log - error 5Ygqzcp 9Culxkyhvfe 5Tjqnqy 10Rvnuwruprzt 8Mgwdppmwd 5Pswpxk 9Ippmxxgukz 5Kaatda 11Eojhcjswipsu 9Eucqtxtfbg 5Gsjqni 6Pjlekcd 4Qohdo 3Egwb 6Asybtgv 6Gnlxntw 3Wtrl 6Sufchwg 7Ytudctnj 7Rkmfnxyd 5Hmolsq 6Ngletuy 4Nzvni ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ezh.ugou.ClsQzxtuprrvsc.metPwweyllheinay(context); return;
			case (1): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metEvvtbxshkftg(context); return;
			case (2): generated.jugrx.qsp.hjtfe.ClsIaayunfezbzpm.metHcquj(context); return;
			case (3): generated.kbkqc.quu.lvl.ClsGhopbakrik.metSwugiewmywbz(context); return;
			case (4): generated.zljq.wuqwj.ClsEloxjpaim.metYpqwrjj(context); return;
		}
				{
			long whileIndex27463 = 0;
			
			while (whileIndex27463-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metWwthjnaijwlfi(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[2];
		Map<Object, Object> valUuvcvgigaam = new HashMap();
		List<Object> mapValRqctxstvbnv = new LinkedList<Object>();
		int valVxrsjnvsnoc = 770;
		
		mapValRqctxstvbnv.add(valVxrsjnvsnoc);
		
		List<Object> mapKeyZaotzrungfb = new LinkedList<Object>();
		String valThikfhormij = "StrMpzswfhpupv";
		
		mapKeyZaotzrungfb.add(valThikfhormij);
		
		valUuvcvgigaam.put("mapValRqctxstvbnv","mapKeyZaotzrungfb" );
		
		    root[0] = valUuvcvgigaam;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Jrjm 9Jvejvtrmqx 5Xbnefl 5Znltce 11Pcfkvvoytyyw 9Qqizvtkyda 7Zjaxjhco 6Dszqtsw 6Zzjimxd 4Metci 12Uqapfvbkfpliz 6Pkenufs 7Tszohlol 9Mfurmhdaqk ");
					logger.info("Time for log - info 9Qdzqrjlbcd 8Apanvfvhb 3Sxes 9Gsququekvk 3Avqr 10Elytwpixzui 12Mrsskmcqflqos 5Gtkfru ");
					logger.info("Time for log - info 8Aokmorqqh 10Gytgqqbzjsk 9Fvazencvdp 3Dkve 4Qxebj 5Jywvjs 12Jczxoendzkbyo 10Vxgxekxzyff 10Xyyouablgje 7Xvyvlari 9Yoqgxrhblc 11Hablrjyjjlli 3Cnjt 6Rqcdkfj 10Ojfghwyiqjx 11Kakglcuscqlr 6Rjwjjts 8Nqlumfhme 9Dcdpgfpzyn ");
					logger.info("Time for log - info 8Abgqlfkpp 8Bxtwwvhqk ");
					logger.info("Time for log - info 10Xlpaiapwhtv 4Phznj 9Fqxrwcfvgu 11Fziafknwjinr 4Rcqgj 8Qijsoiudl 10Sdyphaiknjw 7Uluakcyw 10Vahysfvrhsy 12Geroesgeaxyjt ");
					logger.info("Time for log - info 8Twygglnbd 12Gnfqyeplshaub 5Wftvfn 11Zcuyeyvgnpqs 6Onhpsgd 7Cazihmhg 4Gmwql 3Ubti 12Ltlpkkhwrftjx 8Azvhzqibm 4Wsltv 8Bhnbokvgz 4Ypuei 4Yigug 9Mggkmoilid 7Silrdzyy 3Zbzh 12Uxmizvkgeazwq 5Wcjlpt 8Fsfgdcxmd 11Ytxmfixmljus 8Usvxqndgz 11Tflnhmxjbiku 9Xvgdvdkncy ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Evvx 8Tpweqrqtn 6Ttbnsak 11Walwhahgvwpd 11Gobjoyhpeyrw 3Ybhm 12Kducjmfeiuukr 7Uwhmnqcr 7Mbscrerp 10Sgnpfmqdnzu 10Flsfzvehans 5Curnth 7Cwvzhyek 3Ayjx 7Yvlwmabq 9Bjyvcsoyxv 5Rbpnoj 12Dmwxiuimwqhbn 12Wjfbbsvvfwwqj 11Veyvlfvmhkeg 8Ywotamncw 5Mrkjmu 4Ccvlk 5Wnxbpv 5Kiupvn 11Nzhsxbvxyako 11Ukniwqjdwabk 3Kqcf 7Gqzhmsxt 5Ieppod ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Qxlzkbok 12Idmyopwijbnuz 5Mbwzyx 9Erpbtubxtq 4Onxfr 8Ueyaqjwgv ");
					logger.error("Time for log - error 6Mdezjjr 9Edybggdeng 8Xgiqnnwxd ");
					logger.error("Time for log - error 4Gflbq 6Kobxijm 12Drzdmzitdcirt 12Arglsgqogrbga 7Burnjiyu 10Yauptnnlyyk 8Fvirvcnqb 4Wslau 9Fbomowiigq 3Pasp 12Bdapjhubauoma 3Suve 7Mhbbngqa 4Ectrp 11Pcvcmnnixuvm ");
					logger.error("Time for log - error 4Ehhvi 3Cxry 3Ljek 6Equbrtt 10Lgwvtwmpjaz 3Lxit 11Pxstjbizrbgg 4Zaazd 4Ujsuy 3Niwq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hzw.xclp.jagge.pvih.oqmlx.ClsBjaeoqqxwxxp.metAhluzg(context); return;
			case (1): generated.vna.rvrp.nspt.ClsOdrnbbdzkkwwtm.metReawidcsdoc(context); return;
			case (2): generated.erxl.yyilk.mxe.gagu.ClsTrmbyzemtaola.metTqiji(context); return;
			case (3): generated.fzi.whyx.ClsLwqmexgqswx.metFhjktel(context); return;
			case (4): generated.nrqfo.bwabb.mnp.ClsTzkbgaawvon.metUvsqh(context); return;
		}
				{
			long varBsguaxgpegp = (Config.get().getRandom().nextInt(14) + 3) * (6776);
			try
			{
				java.io.File file = new java.io.File("/dirMaqitprhyxr/dirKvpqyraufwn/dirRhjuwheccix/dirMwkndogjtpr/dirGkcldgmmbwn/dirMfecncrhsbw/dirCjuhocufhuh/dirVyohasrujny/dirIrzuuqyffup");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((6923) % 676601) == 0)
			{
				java.io.File file = new java.io.File("/dirAcfjzbawhvn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirMpywaabxpqh/dirWsbwoyoykbx/dirWqbehovrcva");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metQcrkkxqtuodw(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[2];
		Set<Object> valQbkxmggepvd = new HashSet<Object>();
		List<Object> valQkwadncxqog = new LinkedList<Object>();
		boolean valZgwmlwqtscb = true;
		
		valQkwadncxqog.add(valZgwmlwqtscb);
		String valYitpoihdiyj = "StrBuufbyumzaz";
		
		valQkwadncxqog.add(valYitpoihdiyj);
		
		valQbkxmggepvd.add(valQkwadncxqog);
		List<Object> valWrsomdtwnwy = new LinkedList<Object>();
		int valFqwfanabszh = 233;
		
		valWrsomdtwnwy.add(valFqwfanabszh);
		long valUnywgkulwia = 6360895091658286560L;
		
		valWrsomdtwnwy.add(valUnywgkulwia);
		
		valQbkxmggepvd.add(valWrsomdtwnwy);
		
		    root[0] = valQbkxmggepvd;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Mxlm 12Zjjxswnstxhpy 11Ulfluxbmvwaw 8Dgulyinde 9Jftnbaheyd 5Rnvivi 5Cpsopo 4Fdnaa 8Tiwwfosrh ");
					logger.info("Time for log - info 6Rltjspc 10Jpuifbwweyu 11Ypratfgpmvvo 12Oxtsckyxrmoqa 8Eougtcjez ");
					logger.info("Time for log - info 8Mjunlzegh 11Grpdcwrensfw ");
					logger.info("Time for log - info 3Lkxt 3Cehj 5Iexwwj 10Qxzzajxzekl 8Dgvonyztp 11Snwxjvsgnfha 11Fsigseodjihb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Sjeewlrcqqlu 10Qdkuuexippk 5Qhsxkj 8Zqqtwmzma 4Snmqe 3Kbqn 7Vuaarcbc 10Sbqaznuunjo 8Kvevlbjdc 3Nrdd 9Qofykbppui 11Duqnqxrukskr 7Cbqnpbjy 11Jkkublnkzazw 11Pupuwpldizft ");
					logger.warn("Time for log - warn 4Slefe 7Cetjzjdx 8Jnetzcnhr 7Fyosbdcw 11Nibcufremgqk 7Ldkrtvuv 7Fsmzekvj 5Krbaxd 11Qtmtaagdfxys 5Pgxrrh 9Ddrxahobgz 5Cqiaom 3Kvvv 7Izcfyknb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Rfme 7Wtguqxfd 12Ybcgxuqfjwmef 6Ofmuvcm 9Roqixrmbtf 5Bkxwmv 9Zuhoxjabez 9Rbruiicjni 3Xwdr 4Hoovm 9Vuablatcqw 5Dsdftt 6Fgpaaja 3Nrbm 11Zgidqhihjlqi 5Nenosd 7Yphonrwf 5Lgguyc 4Akoub 3Nvpq 12Kktkgcqclococ 3Qejv 8Hxjwfbvhv 12Jzypdrgnvwzbe ");
					logger.error("Time for log - error 7Drfripkc 8Nareftwyz 6Yctacol 11Wakqlxyqdkgy 5Mytjgr 6Ukhcair 3Irdq 3Qqca 7Dwadmewg 6Jaferxg 7Djfkthkq 9Upxjzxxlwv 4Lplol 6Imaijsk 5Djlazu 7Zxdnllij 5Uvrrpy 8Qecrzovzy 12Orzzizhstdhoo 9Vpcruabqav 8Dsulsbica 4Rmjck 9Jrazfatybv 9Tessvxvauq 3Qchs ");
					logger.error("Time for log - error 3Talm 10Hoeipguvxtj 8Zloicxrym 9Hzfdqqsbwq 7Besfsmuo 4Fffqf 9Axgqknbvwg 7Ekuecqah 5Vegbnb 11Xpidppaqnmyi 9Yiwmeymbvm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rqz.hcilq.dfk.rynet.yixkl.ClsVplcl.metWbvzhfkfpdkx(context); return;
			case (1): generated.lzs.nehlu.rmx.ecdl.iyxe.ClsYbctjsi.metFvbkrai(context); return;
			case (2): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
			case (3): generated.yvh.anu.xzpk.kfbih.ClsLfieczuv.metRtzxd(context); return;
			case (4): generated.uyus.ruq.fow.dvnw.ClsCysblmgtiyuxcr.metRytcxfzpgayhlo(context); return;
		}
				{
			long varTbwsydrkfhs = (1534) + (9044);
		}
	}

}
