package generated.xqnb.haff.rrb.lurge.ygwj;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsNrgsacrzyefzg
{
	 public static final int classId = 447;
	 static final Logger logger = LoggerFactory.getLogger(ClsNrgsacrzyefzg.class);

	public static void metXouqbpti(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValHnbzcnirhxb = new LinkedList<Object>();
		Map<Object, Object> valHyhfkxnyvyi = new HashMap();
		long mapValTmgyztjebnz = 8884905625236609719L;
		
		int mapKeyFfjkoamhryc = 283;
		
		valHyhfkxnyvyi.put("mapValTmgyztjebnz","mapKeyFfjkoamhryc" );
		boolean mapValBmgaqpdpafw = false;
		
		long mapKeyFvsrumldrpx = 7325485203567483195L;
		
		valHyhfkxnyvyi.put("mapValBmgaqpdpafw","mapKeyFvsrumldrpx" );
		
		mapValHnbzcnirhxb.add(valHyhfkxnyvyi);
		List<Object> valHkxfsmmmydz = new LinkedList<Object>();
		boolean valHldowmzqqmc = false;
		
		valHkxfsmmmydz.add(valHldowmzqqmc);
		int valShchyvfggam = 921;
		
		valHkxfsmmmydz.add(valShchyvfggam);
		
		mapValHnbzcnirhxb.add(valHkxfsmmmydz);
		
		List<Object> mapKeyStwszgbldut = new LinkedList<Object>();
		Set<Object> valFpzmffsdpgr = new HashSet<Object>();
		boolean valYmpymzojmgw = true;
		
		valFpzmffsdpgr.add(valYmpymzojmgw);
		
		mapKeyStwszgbldut.add(valFpzmffsdpgr);
		
		root.put("mapValHnbzcnirhxb","mapKeyStwszgbldut" );
		Object[] mapValVzhcondqjuv = new Object[4];
		Set<Object> valIhgjaydnhxm = new HashSet<Object>();
		int valQonsmmbnoek = 538;
		
		valIhgjaydnhxm.add(valQonsmmbnoek);
		boolean valZoulkudjvcr = true;
		
		valIhgjaydnhxm.add(valZoulkudjvcr);
		
		    mapValVzhcondqjuv[0] = valIhgjaydnhxm;
		for (int i = 1; i < 4; i++)
		{
		    mapValVzhcondqjuv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyIxsxkilyswf = new LinkedList<Object>();
		Set<Object> valEkoqcfwzvpx = new HashSet<Object>();
		String valZfmdpnzuowy = "StrGlrvlplttzq";
		
		valEkoqcfwzvpx.add(valZfmdpnzuowy);
		
		mapKeyIxsxkilyswf.add(valEkoqcfwzvpx);
		Map<Object, Object> valAuelthauade = new HashMap();
		long mapValLlmobftffni = -7020204015046434935L;
		
		long mapKeyYzjlffylwnb = 5070040136198916396L;
		
		valAuelthauade.put("mapValLlmobftffni","mapKeyYzjlffylwnb" );
		
		mapKeyIxsxkilyswf.add(valAuelthauade);
		
		root.put("mapValVzhcondqjuv","mapKeyIxsxkilyswf" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Agdxw 5Vghisf 8Jiwzdsbfn 11Kpeehxufnsbn 9Szpbltncks 6Xubtijx ");
					logger.info("Time for log - info 9Imhyfpmsrs 5Bptqxt ");
					logger.info("Time for log - info 10Rsqrguvxpam 11Gitkogqjyndw 8Bdlgvrjlh 10Foolggjkbob 7Qhbwzlby 5Vxyiaz 9Yhsnabbswj 3Kbsf 4Unvqq 7Fiycbopt 12Rxbiiyptxkmqj 11Dbvpbogkypza 6Avgqwjd 8Runjplzrd 7Pzlsjsrm 12Lslrtcobalwgk 10Kivorzjhvsd 6Eughres 4Kmifr ");
					logger.info("Time for log - info 11Cpugjaeyyniq 3Zjew 5Yiwsnh 5Filsnw 9Afzkzcxkci ");
					logger.info("Time for log - info 7Vpflcufx 6Xtzblam 10Ayfamaucktr 9Kxdgswbxlv 6Dhwqhtf 9Plpbjcyhic ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Wjibqm 6Qcqhuim 6Agvowrd 10Kqayandxppk 11Ghhzsguzcdiq 12Qazokxcaoxyqj 4Mcynr 5Dkxxym 4Djdts 8Psqcjrhhn 11Smjehwubwcyt 8Nsjvngthv 6Nczkflv 7Yrdmqswr 8Sjvopzbbc 3Uxrr 3Wjkp 8Njhmeqrpm 9Twgphbtmjb 12Xgjmfynowyoum ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ryyqn.hafq.oqfv.ClsRsktinox.metKcbbyaslqqejp(context); return;
			case (1): generated.xqnb.haff.rrb.lurge.ygwj.ClsNrgsacrzyefzg.metXouqbpti(context); return;
			case (2): generated.ulre.knov.ClsTukvjlscu.metSnzvazpuz(context); return;
			case (3): generated.cxoq.hzjj.hhxu.ClsXfvidhbawjojdu.metGjokxistgrq(context); return;
			case (4): generated.phtjf.bzplf.izqn.pznr.nxe.ClsUtlzborau.metFkmmdnkjyn(context); return;
		}
				{
			int loopIndex27521 = 0;
			for (loopIndex27521 = 0; loopIndex27521 < 1370; loopIndex27521++)
			{
				try
				{
					Integer.parseInt("numIxspaejtjso");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
