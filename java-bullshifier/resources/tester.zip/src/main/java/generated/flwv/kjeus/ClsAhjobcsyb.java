package generated.flwv.kjeus;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsAhjobcsyb
{
	 public static final int classId = 171;
	 static final Logger logger = LoggerFactory.getLogger(ClsAhjobcsyb.class);

	public static void metLggklmi(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValKmcfuhgemeh = new Object[6];
		Set<Object> valDvoperddyos = new HashSet<Object>();
		long valXichjjfepok = 8760108723019527884L;
		
		valDvoperddyos.add(valXichjjfepok);
		
		    mapValKmcfuhgemeh[0] = valDvoperddyos;
		for (int i = 1; i < 6; i++)
		{
		    mapValKmcfuhgemeh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyUlxfbscpvkg = new HashMap();
		Object[] mapValSxqldsoytfr = new Object[9];
		int valDhbqdmuzafl = 248;
		
		    mapValSxqldsoytfr[0] = valDhbqdmuzafl;
		for (int i = 1; i < 9; i++)
		{
		    mapValSxqldsoytfr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyAfyakuhobjb = new Object[9];
		boolean valPkjrpunnacm = false;
		
		    mapKeyAfyakuhobjb[0] = valPkjrpunnacm;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyAfyakuhobjb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyUlxfbscpvkg.put("mapValSxqldsoytfr","mapKeyAfyakuhobjb" );
		Map<Object, Object> mapValNdokkhoccsf = new HashMap();
		boolean mapValZwhxlngjyby = false;
		
		long mapKeyNovqkqjhxtw = -4557125122761969279L;
		
		mapValNdokkhoccsf.put("mapValZwhxlngjyby","mapKeyNovqkqjhxtw" );
		
		List<Object> mapKeySoguatljzie = new LinkedList<Object>();
		boolean valVvsxotdviln = true;
		
		mapKeySoguatljzie.add(valVvsxotdviln);
		int valDsjzjuhquiu = 209;
		
		mapKeySoguatljzie.add(valDsjzjuhquiu);
		
		mapKeyUlxfbscpvkg.put("mapValNdokkhoccsf","mapKeySoguatljzie" );
		
		root.put("mapValKmcfuhgemeh","mapKeyUlxfbscpvkg" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Mwoxasanaq 12Bjegiuodkomap 5Tnohog 10Hppzgjiakgh 10Lswbfejbxfs 7Nsakmmzk 12Yijpujcynyvqe 10Uzdmddjugsu 11Luusxyiisfql 9Xhthdkcqpl 7Yjtalukf 8Wybuogxmq 12Kjwxatfhhltdr 9Azsqrpjgtj 9Ogseclpzln 6Ztfqmdd 7Mlbprfwy 12Jmsmnblwoekqo 4Unpyf 6Gxokfpl 7Irvmvbhx 3Zovc 6Wyqmvth 3Uwix 11Vfzyjvftubdm 7Plddzfch ");
					logger.warn("Time for log - warn 8Xvvpngapt 7Qyahwajs ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Fejysk 8Obhgbdsef 9Kvkfcuogii 5Glpdgi 7Llqxsvft 4Iwjla 7Yexzcgdz 3Xkfp 5Ivwjjo 9Twuarlnesp 11Linwkwvfooys 5Uaafvl 9Kssnifbpty 10Zwncoggofkr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qwlax.zei.ClsAdxloruwrrth.metHsjxayjzgkwe(context); return;
			case (1): generated.aqqfv.gdkxm.pact.ClsAgtwrqa.metYkbdjrockaif(context); return;
			case (2): generated.wkucr.ukst.umm.xsqx.ClsEjxfeypurpufwd.metOatblxssahe(context); return;
			case (3): generated.ifyrm.rwj.ajr.gkqyg.ClsSfeshwgdectgpm.metUdqxpeng(context); return;
			case (4): generated.vntk.clexr.ClsYpzzbhceuihjz.metZikaf(context); return;
		}
				{
			long whileIndex23087 = 0;
			
			while (whileIndex23087-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex23088 = 0;
			for (loopIndex23088 = 0; loopIndex23088 < 6894; loopIndex23088++)
			{
				try
				{
					Integer.parseInt("numLlpxlfuxhnx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex23089 = 0;
			for (loopIndex23089 = 0; loopIndex23089 < 2262; loopIndex23089++)
			{
				try
				{
					Integer.parseInt("numGmfmkjxzumk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metMaqmdna(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValUwbjpavxmwe = new Object[3];
		List<Object> valUgoyqholnuk = new LinkedList<Object>();
		int valYoojxkqzvgt = 999;
		
		valUgoyqholnuk.add(valYoojxkqzvgt);
		String valTopkrawylkt = "StrBkegifutjof";
		
		valUgoyqholnuk.add(valTopkrawylkt);
		
		    mapValUwbjpavxmwe[0] = valUgoyqholnuk;
		for (int i = 1; i < 3; i++)
		{
		    mapValUwbjpavxmwe[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyDpowynjvell = new HashSet<Object>();
		List<Object> valNhmvmcutlsj = new LinkedList<Object>();
		String valWxenyaykdrf = "StrQlcdmuinsuv";
		
		valNhmvmcutlsj.add(valWxenyaykdrf);
		
		mapKeyDpowynjvell.add(valNhmvmcutlsj);
		
		root.put("mapValUwbjpavxmwe","mapKeyDpowynjvell" );
		Set<Object> mapValGqcibbibsaj = new HashSet<Object>();
		Set<Object> valGirjfptgifq = new HashSet<Object>();
		long valWqksuezfccz = -8993728933061701419L;
		
		valGirjfptgifq.add(valWqksuezfccz);
		int valZhodngoipkl = 491;
		
		valGirjfptgifq.add(valZhodngoipkl);
		
		mapValGqcibbibsaj.add(valGirjfptgifq);
		
		Set<Object> mapKeyZjfynhhoyqj = new HashSet<Object>();
		Map<Object, Object> valXlpbguhsjtj = new HashMap();
		String mapValTnkwcbfrkud = "StrGzdkqbbcyvo";
		
		String mapKeyNinrvbzdleb = "StrLhomlnifjud";
		
		valXlpbguhsjtj.put("mapValTnkwcbfrkud","mapKeyNinrvbzdleb" );
		long mapValUfzgavjyuhb = -6709562093553918401L;
		
		int mapKeyYpaoglzuetl = 723;
		
		valXlpbguhsjtj.put("mapValUfzgavjyuhb","mapKeyYpaoglzuetl" );
		
		mapKeyZjfynhhoyqj.add(valXlpbguhsjtj);
		
		root.put("mapValGqcibbibsaj","mapKeyZjfynhhoyqj" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Gayvxj 8Ryochflsg 9Nkecrmhshi 12Zwbbahysqlrig 9Bggzrukigw 7Rcnozoxx 7Cwyqjhhg 3Sqvy 9Jtungzzdxm 12Fweauevyqugna 8Srobemcfd 4Lsddx 4Uxfya 3Jscn 9Acgdrndzzd 4Uylis 6Sbqxstc 6Tcsjbey 6Btwlsna 8Ghleqidwg 10Qgdsgfmucqk 11Hhcunewtwbal 12Sjlgpcbqrzapi 12Bjcmbfihtdmno 12Ztjnikbnfopdv 5Amdija 12Lcpmerkfkaqsv 12Xugtthejvmvju 8Omdcyehhd 9Fdmopunqwj ");
					logger.info("Time for log - info 12Pfgtdfhqesvxs 5Bgfyuu 4Znzym 3Dlad 9Smkcfuhdbm 5Rutuqp ");
					logger.info("Time for log - info 5Rpbejr 8Kngxngdsy 10Zkdmgbdzkyo 8Atzmdbfzd 5Hllwoo 9Ocednubajp 9Ndetgvqgmk 4Motck 3Hyhy 11Aymsrbjcjtji 12Plmwlipzxyazv 6Glytjaq 11Uuygypflwoxn 11Zickqaxtowys 3Jqds 12Gonwballnpkaa 4Thbwd 12Blpwweopvkkop 9Fvkqhglkao 10Tqplqnurohl 5Ubeouo 9Pzefuqgrkq 4Vpsis 7Mdpxeprj 11Ueseszhereup 6Cbqurkx 8Zrtgobonm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Tigsyxaashicq 5Qunvtb 12Ofwkgssygozcy 7Ssxdeiqa 5Etguog 3Ggjv 4Btbyd 8Ybmzgorbj 9Wtxrmyowti 5Fjlavc 4Kcfue 4Hlczg 12Qkvweaanvozxy 4Vrvup 7Yhrodxva 8Kaaskkjte 9Hfgrzdnkbq 3Ushk 4Fmjyf 12Uzhchvsjbbhjp 12Almkicgkxnsre ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Bhtgnh 3Ckyo 4Jwpbb 8Cnbycsqmo 9Iuzjvyrgzg 5Xgqvoc 12Yhpybwaqkxjqw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wcc.zfysf.ClsYrxejsiwymmrbw.metUmckiclb(context); return;
			case (1): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metJpighvrrkvmknf(context); return;
			case (2): generated.pli.sac.lcrkw.ery.xwlo.ClsIghyijbnkvoubq.metJbowqxymhh(context); return;
			case (3): generated.cmup.ytrbd.ddu.ClsZmyzij.metBciomoo(context); return;
			case (4): generated.miye.jljz.lus.ClsMvdumbmsqtl.metJmaluuekf(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirHrfrwdkrcqj/dirOjszgtdczai/dirElggurrmpvp/dirZdzsqaitkei/dirQevwpsgcbww/dirVdiocknyivx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metPpltlaigoqfyf(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValKuqcitovnfw = new HashSet<Object>();
		Map<Object, Object> valVwbgirohbyp = new HashMap();
		boolean mapValGgoxgnbjeme = true;
		
		int mapKeyTkqcwudsnmb = 61;
		
		valVwbgirohbyp.put("mapValGgoxgnbjeme","mapKeyTkqcwudsnmb" );
		
		mapValKuqcitovnfw.add(valVwbgirohbyp);
		
		Set<Object> mapKeyEgufqdmwkic = new HashSet<Object>();
		Map<Object, Object> valMnjmzxbzzeg = new HashMap();
		String mapValBprsrccdpoi = "StrRgxsiazrmqn";
		
		String mapKeyCxitxwpqvpo = "StrQaaimjhoxke";
		
		valMnjmzxbzzeg.put("mapValBprsrccdpoi","mapKeyCxitxwpqvpo" );
		String mapValOjyiviurzgc = "StrCesjukwuvsd";
		
		int mapKeyTzmemuptctg = 981;
		
		valMnjmzxbzzeg.put("mapValOjyiviurzgc","mapKeyTzmemuptctg" );
		
		mapKeyEgufqdmwkic.add(valMnjmzxbzzeg);
		List<Object> valMiiaunzfyuc = new LinkedList<Object>();
		boolean valTegpdznicvf = false;
		
		valMiiaunzfyuc.add(valTegpdznicvf);
		
		mapKeyEgufqdmwkic.add(valMiiaunzfyuc);
		
		root.put("mapValKuqcitovnfw","mapKeyEgufqdmwkic" );
		Set<Object> mapValGkyljshfflo = new HashSet<Object>();
		Object[] valIrpfkwxtqjo = new Object[6];
		long valIbwtuvvisuv = -7406406385467006982L;
		
		    valIrpfkwxtqjo[0] = valIbwtuvvisuv;
		for (int i = 1; i < 6; i++)
		{
		    valIrpfkwxtqjo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValGkyljshfflo.add(valIrpfkwxtqjo);
		
		Object[] mapKeyZlvkdgoksew = new Object[7];
		Object[] valQgowjzcxpnz = new Object[3];
		long valVrvcqtzmsjx = 2841474264889196202L;
		
		    valQgowjzcxpnz[0] = valVrvcqtzmsjx;
		for (int i = 1; i < 3; i++)
		{
		    valQgowjzcxpnz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyZlvkdgoksew[0] = valQgowjzcxpnz;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyZlvkdgoksew[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValGkyljshfflo","mapKeyZlvkdgoksew" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Yinhbxugr 5Rgbtha 10Qukrwrvlvto 6Jzqwsep 6Vnhzdsr 12Kugirmmqyqwdj 5Weamnl 12Uknljbixwaloy 4Jchnn 11Yepsnmblbcsx 4Dkagq 8Upolpodkx 12Iadabncizvyky 3Qbzj 11Zignqzznapaa 7Fpmelfli 8Oqxvqnyey 5Hxlumm 11Mrnrhgnhioib 9Brmihasica 10Lxmbhlqllmn 6Ntvznbz 10Walsnfijxrj 7Xbxldtcl 9Dtrpdpbwga 12Dzfdspqmqhisd 7Anggruzr 10Diucpqpvlly 9Hjdbiadgii 10Prksncloicy 8Scdktwmkt ");
					logger.info("Time for log - info 9Hnprntnxsg 12Clmloqzjernjg 6Emtmfaj 6Rhglznm 3Whdk 8Eyfqvkgst 6Trsmqxq 4Fmtqp 9Gupihpeznx 4Vctey 6Pwekngi 10Qvajkjesmtd 11Hoaiskgishsr 6Kiowdjy 8Kefsupmqg 9Agmtsqfatz 9Kvlolxdovv 5Aqyxrv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Nstnxitrulgh 12Mczppaaneitwe 5Vuwmet 9Jgkhifhtkr 11Qjscupuyjlvt 10Iwuekjoiibk 3Ysib 6Ceaspjf 3Yvsa 7Qkgaxjmi 6Gdvrije 3Tasp 7Bblvqzxr 9Ltjnlhlyeb 12Ycqukrfbplcvo 9Jmsnsqxwos 11Cvygnzlwawvn 11Fnlfcmianyrx 9Yeuthlktxj 3Rvlu ");
					logger.warn("Time for log - warn 12Hvlxbdwdoetle 10Otinifkfelj 9Htvmdmsblo 5Gquwkn 8Wfhawmjsc 12Mssvbbnbhwcdo 6Uqdkkok 6Xlyhgqy 3Wurg 5Orjtip 9Jyrevroiqw 9Jwsvsowkox 12Ypcrdacnctdwy 7Vywfairb 11Xkazauduntpm ");
					logger.warn("Time for log - warn 7Oncbehig 7Eudofvzd 7Mxhbqpzm 12Omyicflxpcceb 5Ichlre 9Ygstjtthml 10Nfmodkdorlr 5Qmjprf 3Ysiu ");
					logger.warn("Time for log - warn 5Wjsgxo 9Fziroakmbq 8Qvdnpuoue 8Ljcboqxma 8Vyzavrfkk 12Jlwboznikkjpd 10Yvxajmxvxjz 3Urnr 7Kroaqrhh 5Djvjwt 11Dcszpxnkxshb 8Qqdfqqult 7Qbolrkwu 9Jpizukyicj 8Bmumlhodq 12Lmsvthcehyklx 6Gvrbvas 10Fzdiyxshnfm 6Jnjlvzy 3Okyz 10Hbkhqxequun 8Hkypzuodz 12Tzmixvjkqvawx 9Iwcchpryyc 3Nzwr 7Bhlvslyb ");
					logger.warn("Time for log - warn 9Haldgqufyb 7Zrebbemr 7Zqbfwsas 7Xiepvjgi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Hydcbzv 10Bdmqefzcepc 5Kwcshn 7Ayfghukm 12Qwsjmosvyvxqs 4Pbsen 12Cepcbrenataqv 12Eyydiaeqrltla 7Onbdxiao 9Mvtnxejtep 12Twmtuunjmamyw 12Cbtzzkoophund 10Kbewblxzrsp 4Mjufw 3Grce 5Dpwgoq 7Cicmznsm 4Oacfd 10Wnchnskwkmt ");
					logger.error("Time for log - error 6Zdawofg 12Mejoyxedaxbdi 10Ayjggagestk 10Uufnulsbkdf 5Ztwkrb 4Yzjbt 11Pwvfofhxfhln 6Jslujob 3Zpwt 11Srgbezchplne 5Kwvixm 12Kwacvyamdouad 9Libosccuek 3Pqvd 7Buabrdkk 7Bpzkrxmw ");
					logger.error("Time for log - error 8Ghtjecwew 8Akymsujyr 5Pyougj 7Ytyqlbha 9Dqbmjdoclk 7Fvrcozwa 9Xciogrqlcx 6Ziqlnqo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lbx.ujwf.wayq.ClsEtipntwjjs.metYkgppbepgd(context); return;
			case (1): generated.rlg.pxdte.svn.clv.ClsMkagt.metEsbkjtdvlylqyw(context); return;
			case (2): generated.hyq.yrx.ucb.jdut.ghw.ClsXwcyosgzsc.metMysukbgfyiodpv(context); return;
			case (3): generated.hcdlq.enxjq.kqzt.pmk.vuc.ClsMdkbzdmkjxcf.metOfbbjymp(context); return;
			case (4): generated.gfhvs.nuhuq.qbk.rwbku.erqpl.ClsOuzdnnqrt.metHwnbcj(context); return;
		}
				{
			int loopIndex23099 = 0;
			for (loopIndex23099 = 0; loopIndex23099 < 2459; loopIndex23099++)
			{
				try
				{
					Integer.parseInt("numVeuyxojakob");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metWdbwrxqdjbtpud(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valCfgxvbgyzoc = new HashMap();
		Set<Object> mapValZftcpnwtman = new HashSet<Object>();
		String valQfvgtmmtcat = "StrRyfqettoceh";
		
		mapValZftcpnwtman.add(valQfvgtmmtcat);
		
		Map<Object, Object> mapKeyAcufogcfehm = new HashMap();
		boolean mapValLyaoiirgftu = true;
		
		int mapKeyVuinikwhuye = 530;
		
		mapKeyAcufogcfehm.put("mapValLyaoiirgftu","mapKeyVuinikwhuye" );
		String mapValPdqyvcrcbds = "StrXhjjjdowkyi";
		
		boolean mapKeyTupvbsnruef = true;
		
		mapKeyAcufogcfehm.put("mapValPdqyvcrcbds","mapKeyTupvbsnruef" );
		
		valCfgxvbgyzoc.put("mapValZftcpnwtman","mapKeyAcufogcfehm" );
		
		root.add(valCfgxvbgyzoc);
		List<Object> valMkkbtavxzcp = new LinkedList<Object>();
		Set<Object> valUkzzpzwqavr = new HashSet<Object>();
		int valXjugyeaixhy = 209;
		
		valUkzzpzwqavr.add(valXjugyeaixhy);
		int valChoyfjkvprd = 678;
		
		valUkzzpzwqavr.add(valChoyfjkvprd);
		
		valMkkbtavxzcp.add(valUkzzpzwqavr);
		
		root.add(valMkkbtavxzcp);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Vlyksr 12Imuvqgwfabojh 3Laft 3Viqi 3Tcvc 11Dpppxrquhouj 3Beya 5Smwpvu 11Ifvgaksgjyub 9Pbmzkfmlhw 10Jfupotjpmom 12Yekhbxuylwtam 11Xbddsasxrklo 9Blagoatuhn 8Zhoxfrueo 12Pymlnfbdykccw 3Buhq 10Qnhjxupqglz 3Bhjr 4Rgqzs 3Pnir 5Zinddx 4Aaxul 7Ujshwqux 9Jasltcjywt 4Xtibh 11Vynpxpsrpvqz 4Zxthi 4Rmksu 3Jcxa 9Zuilemcdaj ");
					logger.warn("Time for log - warn 4Alrgu 9Ajrgdxqffp 8Xfblcwmeh 8Mysfyghus 7Lubfhjlm 3Uflw 7Bsgqotjm 10Mcqnmihmqws 8Jlobkpmkv 12Ypdzrtjhgkefr 3Fvos 8Yoyvvcips 10Qpjaisezfyw 3Tpgt 8Cxtrmqakn 9Salgsebbkn 7Zjyfobem 12Snpizevoktxxf 6Thiutci 7Chcylabc 11Qayitzyjjbfl 12Bbfvtczlrmhwg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lxab.bkb.mqw.ClsMiouvnamcvsap.metKsjeyneapvdv(context); return;
			case (1): generated.qikh.hgtag.amhgk.ClsEpqxnohalceif.metUhwjekipowr(context); return;
			case (2): generated.awuu.yuf.ClsCvioceqcbkiz.metCmrtwohtptwpox(context); return;
			case (3): generated.yudi.kwckr.ClsDwmxwqmygi.metPjfjihqsvyfx(context); return;
			case (4): generated.pacx.kivel.ClsQdjis.metBmxeectlxmnjne(context); return;
		}
				{
		}
	}


	public static void metAoolbbckfm(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		Object[] valMyrvsrgtvrn = new Object[9];
		Map<Object, Object> valGyfxnrtcxya = new HashMap();
		long mapValMotvrrbulfa = 6262967337409878005L;
		
		String mapKeyWddupjxskax = "StrXuloeyvsrsb";
		
		valGyfxnrtcxya.put("mapValMotvrrbulfa","mapKeyWddupjxskax" );
		long mapValCbgrwkbclxo = -2424709883029982317L;
		
		String mapKeyMrksvcctngi = "StrQulqjxiungi";
		
		valGyfxnrtcxya.put("mapValCbgrwkbclxo","mapKeyMrksvcctngi" );
		
		    valMyrvsrgtvrn[0] = valGyfxnrtcxya;
		for (int i = 1; i < 9; i++)
		{
		    valMyrvsrgtvrn[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valMyrvsrgtvrn);
		Object[] valScbvpjtsgzo = new Object[7];
		Set<Object> valMmhcunkjvhz = new HashSet<Object>();
		int valCyamcpnqbai = 141;
		
		valMmhcunkjvhz.add(valCyamcpnqbai);
		String valMmsyxrhawoi = "StrTmjscoregva";
		
		valMmhcunkjvhz.add(valMmsyxrhawoi);
		
		    valScbvpjtsgzo[0] = valMmhcunkjvhz;
		for (int i = 1; i < 7; i++)
		{
		    valScbvpjtsgzo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valScbvpjtsgzo);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Apmrrnbrhpu 3Xerf 7Uehkpqrp 4Emdvg 8Zmwruvrqt 6Loodwjv 4Pdvmz 4Klzqz 11Zgsajzsmnwlk 11Bhjrlzkkjevh 9Jsaehwpbqj 4Rngvg 10Pwuytwugjfh 11Nihocwcastot 11Bluwnoympexe ");
					logger.info("Time for log - info 4Tncmx 4Yeojs 8Fjqpahnul 5Ssxrxm 3Upaj 7Zyhpgpvm 9Hpcrilpdzx 3Erxr 10Exynmvkchpg ");
					logger.info("Time for log - info 8Noklvecby 10Vqzcjsncwiv 5Viiawm 12Besamjqcjyhsa 3Qydi 5Nmeiit 7Icojzdba 10Iafciwuhvzp 10Otqmoiuprtk 10Ocxwmriumwv 8Mgwjssdvt 7Unahfwlx 6Grxstcn 3Njjc 11Kloqdigfihmv 12Jxsjazfvjafck 11Ckbqozlajsxg 7Sjuinhvf 6Axbsltt 5Rwnwrq 6Slasxbo 5Genljo 3Dkgi 3Jjbn 10Jaqihwcjkhf 10Cgfndyzrear 10Bouewpennpt ");
					logger.info("Time for log - info 9Rnipdecded 11Ntnauyoamexi 6Loqnsyg 7Mztcbsoc 11Ppjgqcfssdup 8Zwqrvwlxo 5Hhswkg 3Zszh 11Rymmjabnjitn ");
					logger.info("Time for log - info 3Aamz 4Sodrx 5Jxgyly 11Ysgupobqmebx 11Cxbhjxpnaoxm 5Lozcon 9Pcavzlvasd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Drfzodkhylrg 8Mlyymxjyj 12Qualzcvirwpcm 8Wvaibvnua 12Fbwjhystqyure ");
					logger.warn("Time for log - warn 10Taegfaputau 9Llifuuydlo 3Yfxy 8Tpnrvckls 11Rhoxhqvbdsgh 8Funwdifpx 6Ahychzt 3Ropu 5Altchp 5Rnelsb 12Jrbqtgpwzhtyv 9Laxytzmmrd 5Wlilwf 7Iwgqllce ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Zerzcakljpuft 11Dsojnntwphyj 11Cugfpuhrvwwe ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cjexh.ehrl.mtwqa.ClsVshethruisurxt.metGryimbv(context); return;
			case (1): generated.fdf.qdha.fywc.gjubl.dtsb.ClsBinezgxhqjfe.metSxeoz(context); return;
			case (2): generated.xcud.xbp.eztj.gexk.ClsTupoxajhjshtec.metEsfpmpnsdd(context); return;
			case (3): generated.svs.oxvq.ClsHqpfa.metBgvjclpbm(context); return;
			case (4): generated.uym.yiu.voiig.deif.ClsUwvuontynja.metDshagtzyscmkfi(context); return;
		}
				{
			int loopIndex23104 = 0;
			for (loopIndex23104 = 0; loopIndex23104 < 9963; loopIndex23104++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
