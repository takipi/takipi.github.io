package generated.fnpk.eklwq.jyphj.bbvwd;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsWcvzyhijzwo
{
	 public static final int classId = 384;
	 static final Logger logger = LoggerFactory.getLogger(ClsWcvzyhijzwo.class);

	public static void metYtzvhtwejljz(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValIfjxtgworsk = new LinkedList<Object>();
		Map<Object, Object> valRsrfoyyxeik = new HashMap();
		int mapValPpinaumzkeu = 288;
		
		boolean mapKeyNvgypctizbx = true;
		
		valRsrfoyyxeik.put("mapValPpinaumzkeu","mapKeyNvgypctizbx" );
		
		mapValIfjxtgworsk.add(valRsrfoyyxeik);
		
		Map<Object, Object> mapKeyPfibazwpdqs = new HashMap();
		List<Object> mapValYqrqhfpryau = new LinkedList<Object>();
		long valGlwnvlcdtyv = 763227717525394193L;
		
		mapValYqrqhfpryau.add(valGlwnvlcdtyv);
		
		List<Object> mapKeyMtxxmktwwhc = new LinkedList<Object>();
		boolean valDgyaorznfmj = false;
		
		mapKeyMtxxmktwwhc.add(valDgyaorznfmj);
		
		mapKeyPfibazwpdqs.put("mapValYqrqhfpryau","mapKeyMtxxmktwwhc" );
		Object[] mapValMcdbkwjdpng = new Object[5];
		long valQzabyyibnef = -7257336284827466166L;
		
		    mapValMcdbkwjdpng[0] = valQzabyyibnef;
		for (int i = 1; i < 5; i++)
		{
		    mapValMcdbkwjdpng[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyGnvmwekbmet = new HashSet<Object>();
		boolean valOcchqzyqqdl = false;
		
		mapKeyGnvmwekbmet.add(valOcchqzyqqdl);
		
		mapKeyPfibazwpdqs.put("mapValMcdbkwjdpng","mapKeyGnvmwekbmet" );
		
		root.put("mapValIfjxtgworsk","mapKeyPfibazwpdqs" );
		Object[] mapValFdstlumyarf = new Object[7];
		List<Object> valGjdsnnofhbu = new LinkedList<Object>();
		long valVnxnkgypqwm = -6508671757342742662L;
		
		valGjdsnnofhbu.add(valVnxnkgypqwm);
		boolean valRckmbscpcwl = true;
		
		valGjdsnnofhbu.add(valRckmbscpcwl);
		
		    mapValFdstlumyarf[0] = valGjdsnnofhbu;
		for (int i = 1; i < 7; i++)
		{
		    mapValFdstlumyarf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyWjsbbbiyxgz = new HashSet<Object>();
		List<Object> valAdbbgohfwge = new LinkedList<Object>();
		boolean valOanxkgsegqj = true;
		
		valAdbbgohfwge.add(valOanxkgsegqj);
		
		mapKeyWjsbbbiyxgz.add(valAdbbgohfwge);
		Map<Object, Object> valTkviqxtjkwi = new HashMap();
		long mapValTezarcsqftx = -8691929030247018391L;
		
		long mapKeyXghknvaymcg = -8610188108388553023L;
		
		valTkviqxtjkwi.put("mapValTezarcsqftx","mapKeyXghknvaymcg" );
		
		mapKeyWjsbbbiyxgz.add(valTkviqxtjkwi);
		
		root.put("mapValFdstlumyarf","mapKeyWjsbbbiyxgz" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Cvemzl 4Ebgsp 3Mtyz 6Ncstamd 11Cqifhciycvya 3Xxfd 4Dishl 8Sqhpsdfjr 7Kvfbonqd 10Uvwhfojhsaz 6Wwumwaw 12Kypvzsesquhtd 11Hnfcrjrtnhbw 10Xgxklwcjbjr ");
					logger.info("Time for log - info 6Clamxow 7Bqrgylhp 7Fmiynroy 3Tgrk 12Msihgplmpbwsf 9Wiychetxat ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Tmvxjksbhvdfd 7Zdvcjwmj 12Lnjezuurkalms 3Bisr 12Hsrwnkjdfnnbj 5Nnohjc 10Phpfevrptla 3Utmg 9Xzctgqhatd 11Pghgtjkzxklf 11Azxvajecvrka 8Ztxngmubt 5Bnfwdi 12Btardkyftpiki ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tvv.ioy.ClsEqfmidfypp.metObdbtlzhg(context); return;
			case (1): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metZlaxbquc(context); return;
			case (2): generated.qnzm.livr.ClsPutzsgygioejxl.metRdflajddlt(context); return;
			case (3): generated.gapuh.cesf.ClsXyxpazfgwk.metLiarcmz(context); return;
			case (4): generated.axdim.stv.ClsSaegiqo.metVwtuv(context); return;
		}
				{
			long whileIndex26513 = 0;
			
			while (whileIndex26513-- > 0)
			{
				java.io.File file = new java.io.File("/dirQdxtnvpbxvu/dirVnsypjenyhg/dirFshtsnffyzl/dirPtiklqbnmql");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varLmeagccbwji = (7912) - (Config.get().getRandom().nextInt(647) + 6);
		}
	}


	public static void metCihby(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValFjncpnqptcd = new HashMap();
		Object[] mapValQhtomtyqbaw = new Object[2];
		int valQxbzdzojstx = 699;
		
		    mapValQhtomtyqbaw[0] = valQxbzdzojstx;
		for (int i = 1; i < 2; i++)
		{
		    mapValQhtomtyqbaw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyTbwbsizmphn = new HashMap();
		boolean mapValBznihejcjax = true;
		
		long mapKeyFgmxkvtczhe = 3834172541933456553L;
		
		mapKeyTbwbsizmphn.put("mapValBznihejcjax","mapKeyFgmxkvtczhe" );
		
		mapValFjncpnqptcd.put("mapValQhtomtyqbaw","mapKeyTbwbsizmphn" );
		
		List<Object> mapKeyRndtvgbuauv = new LinkedList<Object>();
		Object[] valInvuhqbuxbi = new Object[2];
		long valSabtsjjbyyk = -6199133196313385338L;
		
		    valInvuhqbuxbi[0] = valSabtsjjbyyk;
		for (int i = 1; i < 2; i++)
		{
		    valInvuhqbuxbi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyRndtvgbuauv.add(valInvuhqbuxbi);
		Map<Object, Object> valDtwmlafgvwf = new HashMap();
		long mapValPbwixhowxqo = -3941569981549319721L;
		
		long mapKeyUisypeafwia = 2656749033066820306L;
		
		valDtwmlafgvwf.put("mapValPbwixhowxqo","mapKeyUisypeafwia" );
		int mapValJwkrhwhlgzp = 873;
		
		boolean mapKeyDvfpxjdiufo = true;
		
		valDtwmlafgvwf.put("mapValJwkrhwhlgzp","mapKeyDvfpxjdiufo" );
		
		mapKeyRndtvgbuauv.add(valDtwmlafgvwf);
		
		root.put("mapValFjncpnqptcd","mapKeyRndtvgbuauv" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Saehtcor 7Bbhumseh 3Zspa 9Vtwfefezjs 9Efiljfixjb 4Ehvwd 3Bwre 5Szohtw 5Phbqbf 4Cufcp 3Zusk 3Uymt 9Thutjnqddv 5Tcgedr 8Qiwnaiebd 11Zhouysfyunwe 11Xjmwrxnzzusf 8Erujywlta 7Ovpauhqq 9Ciuolbuyxl 6Oqjzigu ");
					logger.info("Time for log - info 11Uqsurfcserzk 9Lksrfvmxly 9Gyuyxoeamz 10Fspwdrclkju 5Rmqkmh 12Iexttmyzxlyae 10Sersiohasyi 8Kyfareeas 4Depcn 5Ctwebk 9Qltnrivcpn 7Bcurloml 3Rigx 8Ulgkouprj ");
					logger.info("Time for log - info 3Tfii 9Euqoiljuxl 7Urodsdpz 6Fzhuwir 10Skhsrskpjpl 4Sdteo 11Phnpvdaqzcvf 11Ipmqnywtwqhp 9Trysjgefop 6Faomdgp 7Dszuybnn 3Embu 9Vgeeycdvbd 6Hnybkpm 10Dzkwhkvzecw 11Qyvpudeegffz 10Xakvkuwzngv 4Kqprx 10Hojlfftomaq 12Fkwzpinbasawp 9Dbrrrandhi 3Vjkq 9Slwaawjyud 6Cwxngyt 12Takzthytuhysv ");
					logger.info("Time for log - info 7Ppmfbexg 8Cdyfhglow 3Dqqn 12Eheaycuvhpcbg 8Fkgjrmjrx 3Gddy 6Ubqwtpw 10Merxuaxsaor 8Vazvaglhl 5Dornad 10Xuucjabsvfe ");
					logger.info("Time for log - info 11Imxifdlqfgyw 4Tvzof 6Qungipv 9Ecjuzygjkr 5Xtapwg 5Avukhu 7Eeyuirav 9Mlklriniqy 4Fiece 12Essbdkpsluhyg 12Epjwykrojjvgq 11Lymjifzdxqot 9Unrrmbaupz 9Durejikjwa 12Demslaxdsxqom 4Cnmes 3Valt 9Akntthtnaj 8Nvfcdozvm 6Pignvvs 10Xjoertdxfjb 5Ekurrm 8Qyzeqbftf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Pxifn 12Cnmuqoikdmgkn 4Moyml 3Caof 3Cekm 7Bzbggabl 12Siyzbanvtrtvq 3Ghwj ");
					logger.error("Time for log - error 11Czzpimeorqpk 7Nkwkqhae 8Amowybbav 3Sutw 8Udbdtrtmc 6Cpkrbtc 9Saszzxxxfk 5Azrscn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.duzy.rxrsw.ClsQbnde.metHjjrnpbeaq(context); return;
			case (1): generated.laaxy.myh.ClsSglobn.metAitclnupcqte(context); return;
			case (2): generated.vuj.qjcvs.phb.poi.ueh.ClsHxaaaxntrhq.metHrwdn(context); return;
			case (3): generated.lxrj.lts.csk.iew.ClsCagmzsja.metOondcg(context); return;
			case (4): generated.pli.sac.lcrkw.ery.xwlo.ClsIghyijbnkvoubq.metYyzhlpcd(context); return;
		}
				{
			if (((5148) - (Config.get().getRandom().nextInt(220) + 6) % 394985) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex26519 = 0;
			
			while (whileIndex26519-- > 0)
			{
				try
				{
					Integer.parseInt("numPxhwzaoqlja");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
