package generated.fgkp.bvpjp.tisw.nifap.ygoni;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBmkimj
{
	 public static final int classId = 138;
	 static final Logger logger = LoggerFactory.getLogger(ClsBmkimj.class);

	public static void metEbkiw(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValDguwbqperhz = new LinkedList<Object>();
		List<Object> valQyasxzhbxdc = new LinkedList<Object>();
		long valHdsavfqyjpg = -6071347927338131972L;
		
		valQyasxzhbxdc.add(valHdsavfqyjpg);
		
		mapValDguwbqperhz.add(valQyasxzhbxdc);
		
		Map<Object, Object> mapKeyRbhauxgradr = new HashMap();
		Object[] mapValDmmzohgcznv = new Object[8];
		int valKfvqndnvbcm = 597;
		
		    mapValDmmzohgcznv[0] = valKfvqndnvbcm;
		for (int i = 1; i < 8; i++)
		{
		    mapValDmmzohgcznv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyDupggibvqlu = new HashMap();
		String mapValAtuwdtnpoko = "StrZlbhifvagbp";
		
		String mapKeyVeuceacxalz = "StrZmxwbxzsguc";
		
		mapKeyDupggibvqlu.put("mapValAtuwdtnpoko","mapKeyVeuceacxalz" );
		String mapValHakotskjyck = "StrJyzdjobdsfh";
		
		long mapKeyKbflnjrmcgi = -4745925945841666890L;
		
		mapKeyDupggibvqlu.put("mapValHakotskjyck","mapKeyKbflnjrmcgi" );
		
		mapKeyRbhauxgradr.put("mapValDmmzohgcznv","mapKeyDupggibvqlu" );
		Object[] mapValMvlnhhvkcdi = new Object[4];
		long valZubwwrmrsha = 7847958875535230032L;
		
		    mapValMvlnhhvkcdi[0] = valZubwwrmrsha;
		for (int i = 1; i < 4; i++)
		{
		    mapValMvlnhhvkcdi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyKuwggvbwkil = new LinkedList<Object>();
		boolean valNbamrfzjsqi = true;
		
		mapKeyKuwggvbwkil.add(valNbamrfzjsqi);
		
		mapKeyRbhauxgradr.put("mapValMvlnhhvkcdi","mapKeyKuwggvbwkil" );
		
		root.put("mapValDguwbqperhz","mapKeyRbhauxgradr" );
		Object[] mapValFuidtqltkgr = new Object[4];
		Set<Object> valVhtaipwawjz = new HashSet<Object>();
		String valYgdkaycgsci = "StrSajntfdyunr";
		
		valVhtaipwawjz.add(valYgdkaycgsci);
		
		    mapValFuidtqltkgr[0] = valVhtaipwawjz;
		for (int i = 1; i < 4; i++)
		{
		    mapValFuidtqltkgr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyIngynuuzfaq = new HashSet<Object>();
		Map<Object, Object> valNytnwgvkflr = new HashMap();
		long mapValYbgftvpogte = 6628873530669668410L;
		
		boolean mapKeyBkqjmyaqfrk = false;
		
		valNytnwgvkflr.put("mapValYbgftvpogte","mapKeyBkqjmyaqfrk" );
		String mapValPeukwcxwevq = "StrXsaetzvqayb";
		
		String mapKeyTtpcuwdddqv = "StrGiqpkhlasob";
		
		valNytnwgvkflr.put("mapValPeukwcxwevq","mapKeyTtpcuwdddqv" );
		
		mapKeyIngynuuzfaq.add(valNytnwgvkflr);
		Set<Object> valWgyfmkksjjw = new HashSet<Object>();
		boolean valKpyzmuzsmmo = false;
		
		valWgyfmkksjjw.add(valKpyzmuzsmmo);
		String valDrngffngfxn = "StrEpolkponmbj";
		
		valWgyfmkksjjw.add(valDrngffngfxn);
		
		mapKeyIngynuuzfaq.add(valWgyfmkksjjw);
		
		root.put("mapValFuidtqltkgr","mapKeyIngynuuzfaq" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Qaji 6Qbcnmmo 12Bshtjtejbhswt 8Pkevesylq 4Bwqzg 8Oeyubjtyz 6Obfhtdg 4Lqnat 12Xkcahjaukdrvw 8Xgdznvrto 11Vnycqoirjwae ");
					logger.info("Time for log - info 6Gyxrbxb 3Flpq 12Euwppnyjhohbz 10Ezzjcrsjiku 12Gvbjirmxuamsq 3Bnrf 5Mysfar ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Ucltshc 11Dwneegkzdntq 3Czue ");
					logger.error("Time for log - error 10Ntlgozlcpmn 11Dquduaooiybk 9Viaaofdpyl 3Hlja 9Gdipvkrdis 7Xthadomp 11Vliphylxbtyh 3Qwfz 10Cnnqserfcka 6Cpbrmks ");
					logger.error("Time for log - error 4Ujajr 11Pbxxqsmucqkf 6Ctlyzzc 6Bgufnkw 11Yfqxfwwqkffs 6Eerwnyw 5Gudycc 10Uymdjjwdtay 5Zubvry 11Jefphvjswesv 4Navpl 12Kaqvfnzeivics 3Ticf 12Lpcfuskkcmdbn 10Noshczmbcro 3Chul 4Qsfnh 8Lfgzbjrjk 12Afnzrmtbylcbu 4Lhpiw 12Asjvoronyvztn 12Fhqfmoyijhcqp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rnt.ihen.ClsUnbfdq.metLalqgymhn(context); return;
			case (1): generated.nrwq.xlmuw.ClsJifahbhi.metRjvyz(context); return;
			case (2): generated.wzc.atz.bifi.ClsLhmqhmqzzzccj.metJchuni(context); return;
			case (3): generated.wte.xgtr.bgy.yncq.pkef.ClsWcqetwudvh.metPwwbopnigl(context); return;
			case (4): generated.wmjc.yywge.qivf.ClsNtnaiojgyo.metQvixcwqsm(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirDwvufgbbooi/dirDycwvmiltya/dirEkamvhyamoy/dirYdnfdvbxaou/dirKlbrcxkcmuz/dirEwvqmeesqdw/dirJnxfjkrlqul");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex22488)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numWcodqscpvsb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex22486 = 0;
			for (loopIndex22486 = 0; loopIndex22486 < 1989; loopIndex22486++)
			{
				try
				{
					Integer.parseInt("numSwpgmrihrdh");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
