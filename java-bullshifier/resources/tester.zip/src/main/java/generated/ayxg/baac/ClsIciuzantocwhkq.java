package generated.ayxg.baac;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsIciuzantocwhkq
{
	 public static final int classId = 412;
	 static final Logger logger = LoggerFactory.getLogger(ClsIciuzantocwhkq.class);

	public static void metBmijwhb(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valDinwxrobxuy = new LinkedList<Object>();
		Set<Object> valGldlcqpulri = new HashSet<Object>();
		boolean valHwbzgmlyqzx = false;
		
		valGldlcqpulri.add(valHwbzgmlyqzx);
		long valHdcmlporrsv = 794313768405622329L;
		
		valGldlcqpulri.add(valHdcmlporrsv);
		
		valDinwxrobxuy.add(valGldlcqpulri);
		
		root.add(valDinwxrobxuy);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Cooerqwzjtdbo 7Rtoicmzl 12Pwkqjbcikcefb 3Mzek 6Gmrwbyl 10Rpkvtznaymb 11Haojntceybwn 9Hymejpswco 9Cqtezgefbw 8Yuyneodxy 8Wucapzife 4Aryer 7Jzcaliit 9Hixpdnylbh 12Fovzbgvjalhcd 5Jekfzq 6Buuwblo 8Nzxavfeek ");
					logger.warn("Time for log - warn 6Bfmlpkj 10Oseuctvrkdy 7Niehmxkd 9Zqkuttdbqx 10Eqyxuwovrxt 6Vfcwlqq 12Rungrgfjzrwfq 10Vjfpxqwhgxu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Yozywlsqzt 4Xxcle 12Cpnakzlokbuok 5Yizths 9Tftwtzfxyg 10Entctfnhmej 4Vrird 10Anidortquda 6Lrcnaiy 3Pzdo 5Tpmpok 7Ngblddec 11Zdhsbiqwadpw 4Bmduk 8Gplimqjgc 10Uhnfbzfrviz ");
					logger.error("Time for log - error 3Qncc 8Qctnzsjvq 10Zwuvrskomzl 6Jwwuttl 12Ypoygazvvmdkb 7Dcgcpzdx 4Nxkcf 10Loixllwiddh 3Epes 4Luxlx 3Utjz 5Drydzb 6Rzttbjk 10Grkcrrvoljw 6Emjowdb 12Zdrqhdkerdxvd 10Osvefvollwm 3Tooy 3Zprz 7Ogafzmol 9Lxzfukbkhr 3Jfza 9Fzehblddrp 5Teogpp 9Xagpapsucw 4Pykva 12Oecjzcsdejgwy 4Vvmxm ");
					logger.error("Time for log - error 3Ywvy 5Pakxdx 5Vzgvzs 6Qsfnfsx 11Sdehducpissq 3Vqeu 7Alnrxaal 5Uzepvs 10Bvgpfdyjcte 7Elkchcos 9Cymryphvob 7Lmetyolo 7Llidnilr 12Gegukutdvwreh 11Qcnodfxupwfw 4Ygwzo 7Sydgnola 12Fjslnmhmgkmjk 9Gwawvoksrk 7Odmtuteh 11Ppjxvfbwcgwt 7Mqcdvpht 9Zqyoezvbpc 8Erttphyho 7Yqztgutv 9Ekeizdkinu 10Uhgdfqqarbq 3Llvl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jbipj.zrsb.daypv.qszx.ewk.ClsVnncvmwdx.metVpulozzwbnkjf(context); return;
			case (1): generated.bnlmp.cvjtk.ocoo.ClsDyyxrbbjxtkmxe.metAmgdel(context); return;
			case (2): generated.spdv.axe.ClsZyjdutdtmcu.metZnyfnrroyfp(context); return;
			case (3): generated.uwqq.rznca.ubddn.auo.ClsOkthnaihqahfl.metTosevyjfph(context); return;
			case (4): generated.vrd.lunc.tgbks.iqcsu.cjgc.ClsExboagkfroi.metJpxnmgnwfaj(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirLwmowuodffj/dirNhzsbdebjfu/dirPylrqltmwhj/dirNwwhukmoodf/dirAszuwzadvzi/dirKepflwfuemk");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex26940)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirScnhjtwqewl/dirYafsbkiwyke/dirBavsofccgck/dirMnjanyablwl");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metGfdmrrakz(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valOekymjvdzyi = new LinkedList<Object>();
		Object[] valRympwkejpgb = new Object[9];
		boolean valTzoxlskliuy = false;
		
		    valRympwkejpgb[0] = valTzoxlskliuy;
		for (int i = 1; i < 9; i++)
		{
		    valRympwkejpgb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valOekymjvdzyi.add(valRympwkejpgb);
		
		root.add(valOekymjvdzyi);
		Set<Object> valLivjecxbzlo = new HashSet<Object>();
		Map<Object, Object> valAyytpucvsda = new HashMap();
		String mapValDqeosnhmgnv = "StrQatkahcdhje";
		
		int mapKeyFukgxpdjmyp = 848;
		
		valAyytpucvsda.put("mapValDqeosnhmgnv","mapKeyFukgxpdjmyp" );
		
		valLivjecxbzlo.add(valAyytpucvsda);
		List<Object> valZfmxafeuwlx = new LinkedList<Object>();
		long valMnadfsptymc = 4091387178718321559L;
		
		valZfmxafeuwlx.add(valMnadfsptymc);
		
		valLivjecxbzlo.add(valZfmxafeuwlx);
		
		root.add(valLivjecxbzlo);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Lxhfcjebulus 3Vxrt 9Dgflwuhhki 8Wjmpcmgjd 4Forqo 6Ezfyoji 9Kxomrmgeeu 9Qxstipoqmz 5Vxadcc 8Gvxkqywfj 10Llrfsizacyj 9Krmbkdxjla ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.evl.qnyx.qnt.hnkpr.mua.ClsPqzytqp.metApjoptaglnaty(context); return;
			case (1): generated.dnnlu.krjt.bhw.ClsLntkclh.metMmocyjfd(context); return;
			case (2): generated.fzi.whyx.ClsLwqmexgqswx.metOkmaagzzibm(context); return;
			case (3): generated.jzpii.ixwl.ClsCvgimgq.metSxvhwbhsdlyr(context); return;
			case (4): generated.cqy.ffep.ClsWvinhicphnl.metWwbnpyd(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numOeauieboypg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex26947)
			{
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirJfwoncwgjuc/dirLxdaqcjjsph/dirYlsuctompgn/dirDupkfhbhzmp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex26949)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirVcsvaecidhn/dirBxfzurzjsju/dirCinfvdnmjcx/dirBdsgvtbhuif/dirCghyvikhoid/dirQckeoqahmbg/dirZuahbcoxkzn/dirJmlogibwpqc/dirCfljyjaqvfw");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
