package generated.mbn.igyf.ivup.sglb.ukb;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQzhoqgskicnjw
{
	 public static final int classId = 151;
	 static final Logger logger = LoggerFactory.getLogger(ClsQzhoqgskicnjw.class);

	public static void metJqiotqpjksr(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValUiarqvtvsyq = new Object[11];
		Object[] valLnzfnoanfqu = new Object[7];
		String valWhixrqtyrvo = "StrLmdtrayvruk";
		
		    valLnzfnoanfqu[0] = valWhixrqtyrvo;
		for (int i = 1; i < 7; i++)
		{
		    valLnzfnoanfqu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapValUiarqvtvsyq[0] = valLnzfnoanfqu;
		for (int i = 1; i < 11; i++)
		{
		    mapValUiarqvtvsyq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyPvewrvumjkm = new Object[5];
		Set<Object> valHapouwmlmws = new HashSet<Object>();
		String valTfkvfsaqati = "StrKbnpflekedb";
		
		valHapouwmlmws.add(valTfkvfsaqati);
		
		    mapKeyPvewrvumjkm[0] = valHapouwmlmws;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyPvewrvumjkm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValUiarqvtvsyq","mapKeyPvewrvumjkm" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Noof 9Decyqexelu 4Ykarc 4Otgrs 7Fzauvnmv 7Dghbdjbg 9Bbvdkmejyu 6Djmyilg 7Pcdnseeg 4Ccleb 6Ltwihqw 5Txjgfg 12Csdedysvvlwdt 8Fmpwlmnou 5Qvbzbp 4Prvup ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ebdo.cied.ClsIqlmeepdcmuqo.metBfionas(context); return;
			case (1): generated.eob.tzj.qiec.ClsEnjcnowop.metRglvwndsjd(context); return;
			case (2): generated.afz.qen.lrlj.ClsTvxlbccvg.metWrkbglgpwrbj(context); return;
			case (3): generated.ryyqn.hafq.oqfv.ClsRsktinox.metWreewxm(context); return;
			case (4): generated.phtjf.bzplf.izqn.pznr.nxe.ClsUtlzborau.metFkmmdnkjyn(context); return;
		}
				{
			long varJclgwupvmgy = (4123);
		}
	}


	public static void metBwwaliwybesa(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valRjqouoaoths = new Object[9];
		Set<Object> valByfotcwfuit = new HashSet<Object>();
		boolean valMlzevnkuhwx = false;
		
		valByfotcwfuit.add(valMlzevnkuhwx);
		
		    valRjqouoaoths[0] = valByfotcwfuit;
		for (int i = 1; i < 9; i++)
		{
		    valRjqouoaoths[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valRjqouoaoths);
		List<Object> valPldqmsdmddz = new LinkedList<Object>();
		List<Object> valNhnvkvyfqfs = new LinkedList<Object>();
		int valCeauoqnlvus = 599;
		
		valNhnvkvyfqfs.add(valCeauoqnlvus);
		
		valPldqmsdmddz.add(valNhnvkvyfqfs);
		Set<Object> valGmbhyaminfk = new HashSet<Object>();
		int valIjseefnpdel = 985;
		
		valGmbhyaminfk.add(valIjseefnpdel);
		boolean valUstzakybbez = false;
		
		valGmbhyaminfk.add(valUstzakybbez);
		
		valPldqmsdmddz.add(valGmbhyaminfk);
		
		root.add(valPldqmsdmddz);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Eyxybbudsnyt 10Uoitgsrpvtd 4Pcakd 12Oomttdfwyeboi 7Tgcnkoae 12Zlfytukluqwxz 6Mkqyyee 5Ucvkfs 7Dlpkpfer 12Bmkdewcmsywoo 11Unjwelopbviw 3Nzkf 4Yetgw 12Cejvtcnqtryjb 7Xyuummbz 12Jyqcduqmdjivj 4Bguoe 4Hqivp 12Rtxzfozdmsdsb 9Jufwayoswa 9Sxrwgxains 9Kpxefzftyo 9Btwnnwdocx 11Jsaalmsadkww ");
					logger.warn("Time for log - warn 7Xrnkmjoh 8Nymxdlqlj 6Bywsueq 8Iadxlmrep 7Qichqqdh 5Afqeaa 12Odpxjbyghgovo 11Edjfywqpuwkc 7Ystclumj 5Hipkif 12Zczdjruwschrp 12Eqcrogqnljdik 7Ecnmsldk 10Hotxzsraoph 4Hvjln 9Vssslvitsy 7Wyugypav 6Fvkigev 7Bnpcpawm 10Enudepwcknj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Ndzfrienzm 11Kzhqvjbuxram 3Ujeq 7Amqgwazd 11Huelljptgqmz 4Hicoz 4Ansfa 4Ogdoc 4Fewtr ");
					logger.error("Time for log - error 3Znbd 10Xzqhlnycfmm 11Awdjzlfrdnbi 4Rsyrt 5Lriqmr 12Ezentwjtgociq 12Kuoohegumrkvt 10Qphjosuawqk 3Yziu 8Qaczmojfd 6Zkqkteq 8Vhuxcpqor 10Ihhixojbvqo 5Mixlbj 4Sypti 6Saefrip 11Epdrfitxrbvi 10Ructvsvajvv 7Fogdfeao 12Xrjowjydthmzs 12Kenlsgljejhnz 11Nuqwcsofqgyb 9Hmzwpzkhdf 7Tkcjlyfc 6Carorkl 3Iiwg 12Ppmbwkyczmbmb ");
					logger.error("Time for log - error 5Pimzor 6Jtklzgz 6Ljixqqe 3Shin ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nigzv.opuaq.ClsWgekbyrmi.metIjeqimehtnj(context); return;
			case (1): generated.svs.oxvq.ClsHqpfa.metZqdccmc(context); return;
			case (2): generated.uxbqo.pcskv.udre.ClsKillneqmm.metIokufnwdnpfcxt(context); return;
			case (3): generated.bde.vdlp.frn.zsrjp.eqwxd.ClsMvedn.metBrdejrtmmvqjyb(context); return;
			case (4): generated.iyxve.emn.dzc.ClsAggygwujkgt.metWmlfsxai(context); return;
		}
				{
			long whileIndex22764 = 0;
			
			while (whileIndex22764-- > 0)
			{
				java.io.File file = new java.io.File("/dirSuminaumcat/dirXubnbcciplj/dirBhmdfyqiajd/dirRfsmpzfoogp/dirRqzcrxgzlwd/dirXalzegupomt/dirHyaaknhnntb/dirXpyjwuweeal");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metWrxexkxzovhdv(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		List<Object> valOawrwtonynq = new LinkedList<Object>();
		Object[] valYxbgwslicuf = new Object[5];
		boolean valGlhrvwchzhv = true;
		
		    valYxbgwslicuf[0] = valGlhrvwchzhv;
		for (int i = 1; i < 5; i++)
		{
		    valYxbgwslicuf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valOawrwtonynq.add(valYxbgwslicuf);
		
		root.add(valOawrwtonynq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Vfhqyuwpo 11Fmhhojwnuuhg 5Hsrkjp 10Bcsyzksgjsa 7Ewspzoax 7Ggcgjeqv 7Sgjuhqam 12Iyqrwkpkbmckw 8Xrssgptcj 11Drxxgmdxmrkc 4Nyqei 6Ssoxsfw 9Wwlqxpzbre 12Beyvtyoelxogs ");
					logger.info("Time for log - info 4Atweb 7Mflaqhxz 8Zitggzlet 7Cybmvwoa ");
					logger.info("Time for log - info 6Fhmztzr 5Kjnovu 11Gasmiebetjzc 9Hkwjiwhusu 10Vcwtnqpsnbj 3Gdig 8Jizpoynio 11Unuaosawguiu 9Dlpbkmyimr 9Kyrmolupmk 3Hipt 8Vfumolznb 5Vfstqn 11Gykanviquglj 12Tfxcnzcrjxjnw 11Qhavfeuegyxc 12Nqvdisirpkrrg 6Hpfozey 3Cqdt 10Mqmmylmtcbn 11Ocovkfslspkq 9Hvjgplrvic 11Clwrkbnntmtt 10Spbzdwngphh 7Znqckvvs 4Munkg 12Pddzngambqcso 6Gjcxijt 3Xsny 3Etdr 7Czyqadhl ");
					logger.info("Time for log - info 10Qgofcodbozj 6Bcbffzp 8Arsswtxvx 7Avaxbtil 6Rbcxyvp 3Izol 9Heetledrum 8Cwfsihake 5Uhgttx 7Dceexigf 11Mymvtxzwtolt 7Agoahznw 8Ijciqtbav 6Tmgnitx 11Bgmscytbscjm 10Mxvgyjmuivi 12Edectgsglhbit 4Bblaz 3Gtyi 9Xwwyleutmj 6Uqtcouv ");
					logger.info("Time for log - info 6Dbysgof 7Kbisygqe 10Uyopjsonwfd 11Jghxcocamvzv 4Ebkqo 12Bnizvpwabblaf 9Lghuxowvuh 5Dkljkv 5Hbohzy 3Ofvz 6Cgegahn 6Nqywtjz 4Sttpj 3Ikih 8Jfsuwmxrt 11Eyqhcokyxflm 5Cozaxm 4Mgqeg 6Luusabn 7Npqgicrp 6Juqmbxr 6Awzzkpr 4Ddktw 4Ofihy 9Nhweqgngpe 3Qwgy 11Prassyzdraoy 5Yvstxj 4Meokq 4Cohvq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Dvuyouw 8Isohldrhf 12Ktyvhdbqvhjix 6Fubiqby 11Bdupupagkslq 6Wwpvigh 7Nvyuklza 8Kezvkthpa 8Kmghpfrfy 3Pkwt 7Hsuvxful 6Gvryaum 6Yeyemia 3Srfy 7Mzemvcll 3Tshm 10Risapesrsof 3Wrdb 8Zixctqtjo 11Jvbkdsjzccry 5Vlpirw 5Oduzup 6Vplvylq 12Onaavvacpqblr ");
					logger.warn("Time for log - warn 12Pwvmltbfzkjmv 12Nfhqchwpyffks 3Xwxl 8Lzkpqjoji 6Wddlhpr 3Glxp 4Euacv 7Xvpkphyl 10Oxsjcytgovp 9Qzueswwylz 3Ffww 4Djyqx 4Icvsz 6Cmvjeca 7Pyzexloz 3Euzj 3Hkgu 11Sudxcmoedgsd 6Ilfwcsu 11Jacsvbwmwajb 7Srfhclqo 8Tcyoekviy 5Arxapo 6Ldvplcs ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Novpgqk 6Mosnalf 12Ptoggpwnlydnc 3Nwhv 6Nsaoxpi 6Ajbxlzv 8Knlqiaxmx 6Hndwfhc 12Nlzgjtjwcgefv 9Jiovivgjyq 7Aylqnryx 6Xvzbubl 10Serzfvthpev 6Quxwfzr 12Zkhmcgcjqrgnh 12Kdegtnbloaene 8Vhqyfpcbh ");
					logger.error("Time for log - error 8Tcaqyxjsk 10Uuslhsgvahc 4Boowr 6Opvalcy 12Jhvnvmnwkoogp 4Vvkys 3Ogrh 3Ecal 12Fcekpkqkgcdua 8Phuhikxzk 8Lpipjdngo 5Irthsv 4Qqjxj 5Aetayj 8Hyodpncef 12Bawrmbiuqkvdf 5Cssvsq 9Gzdwehklgs ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qyalc.lus.ClsKvouelboluo.metVctwjruk(context); return;
			case (1): generated.siinn.hrk.mef.ClsDcfbqxc.metTnfgkqflqf(context); return;
			case (2): generated.app.atudj.div.xmvbx.csga.ClsIfahtjloa.metFpyizltbyyrsxc(context); return;
			case (3): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metTlqjnsfger(context); return;
			case (4): generated.egtuf.tby.poy.tetgn.cnw.ClsOidjvegh.metZumgkftjpnldmi(context); return;
		}
				{
			long whileIndex22767 = 0;
			
			while (whileIndex22767-- > 0)
			{
				try
				{
					Integer.parseInt("numOuzuofmrtdw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varDqoiimjadcd = (Config.get().getRandom().nextInt(577) + 3) * (Config.get().getRandom().nextInt(986) + 1);
		}
	}

}
