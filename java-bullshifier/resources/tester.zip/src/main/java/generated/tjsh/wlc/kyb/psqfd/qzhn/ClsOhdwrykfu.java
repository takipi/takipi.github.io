package generated.tjsh.wlc.kyb.psqfd.qzhn;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsOhdwrykfu
{
	 public static final int classId = 241;
	 static final Logger logger = LoggerFactory.getLogger(ClsOhdwrykfu.class);

	public static void metMgbovkjrbbj(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valIvmpnympcih = new HashSet<Object>();
		Map<Object, Object> valUilrtdpxxkp = new HashMap();
		String mapValAfavnsabkny = "StrTlxlvmxobqs";
		
		int mapKeyBtxvizbibmn = 749;
		
		valUilrtdpxxkp.put("mapValAfavnsabkny","mapKeyBtxvizbibmn" );
		
		valIvmpnympcih.add(valUilrtdpxxkp);
		List<Object> valVloddfzykql = new LinkedList<Object>();
		String valUcmhdlnfusp = "StrSezyeljnszr";
		
		valVloddfzykql.add(valUcmhdlnfusp);
		
		valIvmpnympcih.add(valVloddfzykql);
		
		root.add(valIvmpnympcih);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Vtzfkcpyf 11Twsbjltfquip 11Cvthoopsprky ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Gjisfatvhn 8Zippafoee 7Tsgyypjv 4Xhbvm 4Toixu 8Soxfwilca 3Twtw 6Ihgzett 8Xelirjeba 9Hrwaeediyx 3Tahl 6Eshtdnz ");
					logger.warn("Time for log - warn 7Efwyiasd 12Yxexeacixvcrr 7Khmqixii 10Txzoonzoctg ");
					logger.warn("Time for log - warn 12Uyouygqrmgcwq 12Arwbrjgnwwnyh 4Oorhn 12Hcbqfmqstbnlm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.igif.laylf.mnwo.ClsOgradyyhp.metYneec(context); return;
			case (1): generated.rqz.hcilq.dfk.rynet.yixkl.ClsVplcl.metYzlzhs(context); return;
			case (2): generated.qllkh.klb.qyy.ClsQoiukvt.metLnbnh(context); return;
			case (3): generated.hwl.fctgz.mzax.ClsSzkfy.metDnookyekjgpf(context); return;
			case (4): generated.fhy.qnk.brj.xhy.ClsYgumeudbf.metEcwaz(context); return;
		}
				{
			if (((2623) - (1358) % 345053) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metWxyniyvtapvz(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValLvywswgcrtr = new Object[3];
		Map<Object, Object> valSxpxefholwg = new HashMap();
		int mapValYlfjisrmdaq = 503;
		
		String mapKeyYdpuwijbqdv = "StrSoobhaxnhxu";
		
		valSxpxefholwg.put("mapValYlfjisrmdaq","mapKeyYdpuwijbqdv" );
		int mapValFrecvmqkkhu = 744;
		
		int mapKeyQqtbseqavmg = 41;
		
		valSxpxefholwg.put("mapValFrecvmqkkhu","mapKeyQqtbseqavmg" );
		
		    mapValLvywswgcrtr[0] = valSxpxefholwg;
		for (int i = 1; i < 3; i++)
		{
		    mapValLvywswgcrtr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyZywxbfrwguj = new HashMap();
		Map<Object, Object> mapValHnvflunkvec = new HashMap();
		long mapValJbqxudhqeyf = 5419363630697358295L;
		
		boolean mapKeyClmrwgzulif = true;
		
		mapValHnvflunkvec.put("mapValJbqxudhqeyf","mapKeyClmrwgzulif" );
		
		List<Object> mapKeyBdldomfyzus = new LinkedList<Object>();
		boolean valDrqurbuafwz = true;
		
		mapKeyBdldomfyzus.add(valDrqurbuafwz);
		
		mapKeyZywxbfrwguj.put("mapValHnvflunkvec","mapKeyBdldomfyzus" );
		List<Object> mapValPbpaxsjqdsh = new LinkedList<Object>();
		String valBsxyidcjglu = "StrGjbatibeegx";
		
		mapValPbpaxsjqdsh.add(valBsxyidcjglu);
		int valXkfbpkkjhsn = 884;
		
		mapValPbpaxsjqdsh.add(valXkfbpkkjhsn);
		
		List<Object> mapKeyXuoggxrhspu = new LinkedList<Object>();
		int valAjxzcncwyoo = 531;
		
		mapKeyXuoggxrhspu.add(valAjxzcncwyoo);
		boolean valZcfheitwgdj = true;
		
		mapKeyXuoggxrhspu.add(valZcfheitwgdj);
		
		mapKeyZywxbfrwguj.put("mapValPbpaxsjqdsh","mapKeyXuoggxrhspu" );
		
		root.put("mapValLvywswgcrtr","mapKeyZywxbfrwguj" );
		List<Object> mapValPppkuqlupta = new LinkedList<Object>();
		Set<Object> valOafgylubuey = new HashSet<Object>();
		long valZfctknhjwix = -4474711970157165605L;
		
		valOafgylubuey.add(valZfctknhjwix);
		
		mapValPppkuqlupta.add(valOafgylubuey);
		Set<Object> valZoyzumxmogr = new HashSet<Object>();
		long valYumxlaartws = -7007850929381214561L;
		
		valZoyzumxmogr.add(valYumxlaartws);
		
		mapValPppkuqlupta.add(valZoyzumxmogr);
		
		List<Object> mapKeySofdjsrfvqo = new LinkedList<Object>();
		Map<Object, Object> valUrzwbroidyo = new HashMap();
		String mapValLxaceymydpe = "StrLitntvbpkhu";
		
		boolean mapKeyBnsgmampett = true;
		
		valUrzwbroidyo.put("mapValLxaceymydpe","mapKeyBnsgmampett" );
		
		mapKeySofdjsrfvqo.add(valUrzwbroidyo);
		
		root.put("mapValPppkuqlupta","mapKeySofdjsrfvqo" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Jztdoesztpl 5Fhzrxr 4Xkity 3Nfgv 3Soec 3Wxwp 3Mekd 6Yowpmmj 12Bctajuwofbujk 7Gywqgejd 9Ylutpncegi 7Niknegdg 7Skyvezpd 6Yaobiit 6Zuopugs 5Vioekb 7Pbzykhen 11Wwyjhxoxjuih 4Lsepr 8Omkcckhed 5Yguzcg 4Kkmws 11Eerjwekwopym 6Odkeawj 12Qpmnsdkqhtjgm ");
					logger.info("Time for log - info 11Elfzlrspybkn 4Httxq 7Cmptykng 7Cvhawbht 10Dkugzxxlgxp 6Nutuajw 7Nlwaoqrl 6Ijyznfz ");
					logger.info("Time for log - info 11Ijitsmgzkymd 11Xomwcnzjwntj 12Vmbhvpbyszoci 8Ptybeuqmz 3Jcpr 12Cxyankahpxpjf 5Atzwbx 3Djys 9Nxdtgavpyf 5Zauxxi 5Eiddus 6Jzrdeuu 3Tavo 8Aeofuyxny 6Ydhfndn 12Rvsoplgqrfnoo 10Sfjsnafgeog 7Lbtwrgfr 8Kzgijvqrq 10Ocpvkltaovl 7Xyhfuemd 12Dlsxwcifsugsv 8Ygvzweurp 7Kjdquoho 3Nnmw 4Uaurh 5Pclefq 7Cetyhrpx 4Zrmge 5Pkethj 12Fztoyomlcqioo ");
					logger.info("Time for log - info 8Tpfscwbqa 12Ireelcqnpmqmn 9Zhnnuhvnjk 7Dzoxojpw 4Rzyau 3Kuep ");
					logger.info("Time for log - info 6Eqbbbke 8Mfmabywdi 8Kahuanrti 12Xnhfpvpfhlolm 11Ytiqyobqzsjs 3Jhda 8Yswdfuiwn 11Nftuegewjufd 6Lqdxwoe 8Fxkfuoqwz 10Ebvkulavoxw 8Suwfzyavx 7Plliamgs 8Dpyrqceio 5Kgdmtd 11Etrdpopildxj 6Prodvvd 10Djtzddwgnzm 7Ecsskmkb 6Mhdbkcb 5Feparo 12Wmxupdlchuxpw 11Zyntvgptjutj 5Lifocj 8Lpqazfetk 9Hnreobztcs ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yfo.dls.qwny.cqaxf.ClsDosmbrrv.metEzcdmyjxgzcl(context); return;
			case (1): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
			case (2): generated.obfi.prawn.asr.ClsHvlzhrjejvoom.metCqwbu(context); return;
			case (3): generated.qpya.todk.woo.rrzxr.ClsQlmcomguvtqu.metVbgwaaycr(context); return;
			case (4): generated.fdf.qdha.fywc.gjubl.dtsb.ClsBinezgxhqjfe.metBmbttdastn(context); return;
		}
				{
			int loopIndex24251 = 0;
			for (loopIndex24251 = 0; loopIndex24251 < 3739; loopIndex24251++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirPlbewojxdvx/dirYjcjwqnnicx/dirIxmorohxtfd/dirHkyvbaxorsm/dirLzigctxfghf/dirKuckynoeupa/dirLkvtrwpxnvv/dirDajfvfiptet");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numPewrrjxtuhm");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metDqdnyemypbugl(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valRrpznrfltmf = new HashMap();
		Map<Object, Object> mapValCzexsgptgak = new HashMap();
		String mapValNdyhmipfjpk = "StrGnfwgfpmkmp";
		
		boolean mapKeyXhadfazmhkg = true;
		
		mapValCzexsgptgak.put("mapValNdyhmipfjpk","mapKeyXhadfazmhkg" );
		
		List<Object> mapKeyVgijxoczrdu = new LinkedList<Object>();
		long valQzlpfmvchru = 8510003524077134026L;
		
		mapKeyVgijxoczrdu.add(valQzlpfmvchru);
		long valUksfosjvdxm = -2779595249483840765L;
		
		mapKeyVgijxoczrdu.add(valUksfosjvdxm);
		
		valRrpznrfltmf.put("mapValCzexsgptgak","mapKeyVgijxoczrdu" );
		Map<Object, Object> mapValIgswqjaxhvl = new HashMap();
		String mapValZvhmtuhlhbx = "StrPdohuxrydft";
		
		String mapKeyDstpbdsecey = "StrQuvtdvkkxms";
		
		mapValIgswqjaxhvl.put("mapValZvhmtuhlhbx","mapKeyDstpbdsecey" );
		int mapValFgqqhlpbovi = 974;
		
		int mapKeyRgochijbmdb = 344;
		
		mapValIgswqjaxhvl.put("mapValFgqqhlpbovi","mapKeyRgochijbmdb" );
		
		Map<Object, Object> mapKeyXjkoxqmulgv = new HashMap();
		boolean mapValFdyotezrtht = false;
		
		boolean mapKeyZabzhzhrenh = false;
		
		mapKeyXjkoxqmulgv.put("mapValFdyotezrtht","mapKeyZabzhzhrenh" );
		
		valRrpznrfltmf.put("mapValIgswqjaxhvl","mapKeyXjkoxqmulgv" );
		
		root.add(valRrpznrfltmf);
		Set<Object> valSomehabobrx = new HashSet<Object>();
		List<Object> valDeenuuqiuix = new LinkedList<Object>();
		boolean valCrbtvqsuzod = true;
		
		valDeenuuqiuix.add(valCrbtvqsuzod);
		boolean valFjgrjhfdzvb = false;
		
		valDeenuuqiuix.add(valFjgrjhfdzvb);
		
		valSomehabobrx.add(valDeenuuqiuix);
		
		root.add(valSomehabobrx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Nsxd 12Xqytarldhopox 4Wvivf 12Qihntvbjvwitk 5Pctort 3Cebc 9Dwxbzixqwe 7Iueddgom 7Hxdkcsex 12Rpaifrmuqhaev 9Dujdoitbxm 9Wdwfbammlm 5Tnemoo 11Ycwlhlzvdnoy 7Befqjpmj 7Oynbjmrp 6Cwbxwha 8Wwcqcftau ");
					logger.info("Time for log - info 11Coweqblegrng 5Uuutzo 7Gpjuchee 3Clkl 5Jsyoal 8Yencjxlcv 7Gglkcxob 7Qonrapry 12Ilxtgjrezxvby ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Izxowptgp 8Qeemdeigl 5Hxuvyn 12Cxkzmbssqvnty 4Mfwhh 6Wyrbaiw 7Wfhuzvhf 4Odryf 11Ylluciaddvrb 5Eexiyj 5Qxgcvr 9Baqcyoastp 10Uwskcofgfdj 3Kjyh 12Bdyjxkwbwsxcp 4Rsxsi 5Fhkkzp 8Xhnzarwxc 12Xupsaeoywdpih 3Glpx 11Xfatirueeepd 5Ipgcfe 6Yzbqjng 8Kpfjpdmqm 9Iqgpyafzfu 12Hbpkaxipybmfb 3Vsys 11Pvvamjycczmr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Cidmiyicv 11Kkgexykuwguc 11Kovouxfiootk 4Opuqf 5Flqzzl 4Jdwgg 7Fmeuwbzm 11Vqawktughrrv 3Lnzc 8Gjjvjtxzm 8Zrutqqxnc 3Syzk 8Cszimcgfa 10Fuyzlfnxrto 7Ufbcyfbr 8Ncxesjuvg 10Mehtfzswlxp 4Bfofi 10Mtwndmblubl 3Rwbp 12Pwqxtobwnmtnm 8Fcnwkjtqx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rqcl.nvc.nixtb.fedm.ClsWjomfkmimge.metObbhocdmjeq(context); return;
			case (1): generated.wzzy.rguqw.bfm.ClsCumedne.metJavfokczruv(context); return;
			case (2): generated.nigzv.opuaq.ClsWgekbyrmi.metUuviwodimvy(context); return;
			case (3): generated.qku.vho.jtvuy.nvgy.zmvk.ClsVjaehh.metFofyza(context); return;
			case (4): generated.ojyuy.hdvu.yij.nuf.ClsJtdiu.metUymohzkoe(context); return;
		}
				{
			int loopIndex24259 = 0;
			for (loopIndex24259 = 0; loopIndex24259 < 9980; loopIndex24259++)
			{
				try
				{
					Integer.parseInt("numSypsjyncpqb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirKrlwwehltub/dirJsmhhzuuebg/dirXllefqjmaoo/dirYccmahyijzi/dirJghchluslsm/dirCsihhsxcaag/dirZwveiyebzeu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
