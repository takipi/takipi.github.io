package generated.hehz.xzg.akn.rdsvf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsKsukcv
{
	 public static final int classId = 411;
	 static final Logger logger = LoggerFactory.getLogger(ClsKsukcv.class);

	public static void metYviizisnunbnph(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValTiurfzabebq = new HashMap();
		List<Object> mapValGdbecpwfuca = new LinkedList<Object>();
		int valEetpodsmgqw = 894;
		
		mapValGdbecpwfuca.add(valEetpodsmgqw);
		int valPmtfwpdwlst = 487;
		
		mapValGdbecpwfuca.add(valPmtfwpdwlst);
		
		Set<Object> mapKeyQuantqrovoq = new HashSet<Object>();
		int valUqmgirwwlof = 1;
		
		mapKeyQuantqrovoq.add(valUqmgirwwlof);
		boolean valPqchgrsqnfh = false;
		
		mapKeyQuantqrovoq.add(valPqchgrsqnfh);
		
		mapValTiurfzabebq.put("mapValGdbecpwfuca","mapKeyQuantqrovoq" );
		
		Set<Object> mapKeyXrpxrcktrnu = new HashSet<Object>();
		Map<Object, Object> valStzyuaybkmz = new HashMap();
		long mapValWsqsndpuwci = 2960671246381470039L;
		
		String mapKeyDkhdxidrrzj = "StrUarhfomxrpy";
		
		valStzyuaybkmz.put("mapValWsqsndpuwci","mapKeyDkhdxidrrzj" );
		int mapValRxewpuvabvf = 524;
		
		int mapKeyJsxsmihwqki = 198;
		
		valStzyuaybkmz.put("mapValRxewpuvabvf","mapKeyJsxsmihwqki" );
		
		mapKeyXrpxrcktrnu.add(valStzyuaybkmz);
		
		root.put("mapValTiurfzabebq","mapKeyXrpxrcktrnu" );
		Map<Object, Object> mapValBnpfhmhykub = new HashMap();
		Set<Object> mapValBsjbxkejhwx = new HashSet<Object>();
		long valVkiokjhwtll = -6491920211462956009L;
		
		mapValBsjbxkejhwx.add(valVkiokjhwtll);
		
		List<Object> mapKeyYdkwppcfgub = new LinkedList<Object>();
		boolean valLucndhbqybn = false;
		
		mapKeyYdkwppcfgub.add(valLucndhbqybn);
		boolean valGonjsdgwzdg = true;
		
		mapKeyYdkwppcfgub.add(valGonjsdgwzdg);
		
		mapValBnpfhmhykub.put("mapValBsjbxkejhwx","mapKeyYdkwppcfgub" );
		
		Set<Object> mapKeyQncgtjztfso = new HashSet<Object>();
		Set<Object> valFvafdolawgn = new HashSet<Object>();
		int valGrlszlbgxcs = 603;
		
		valFvafdolawgn.add(valGrlszlbgxcs);
		boolean valSvmsohvlqur = false;
		
		valFvafdolawgn.add(valSvmsohvlqur);
		
		mapKeyQncgtjztfso.add(valFvafdolawgn);
		
		root.put("mapValBnpfhmhykub","mapKeyQncgtjztfso" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Cqjpyahcoffl 10Gbprswtkizv 4Uafzs 9Rojbznicxh 8Cgnuepgmk 8Oivokcbgx 5Auoioq 7Eayjuvih 6Rzygkdq 3Ezro 6Rihcwcb 6Kujbilg 12Opwmxiczhwuij 7Yiwvifeg 4Ibecp 12Xhxhoblpmmaus 4Fwjqd 6Gtzanta 12Zimspfrbfoxgq 12Gvsctdrodtonx 3Zzuo 6Cifwtji 9Wktudeyqmd 4Sgfrq 5Hsukzo 11Tcqsqgceysso 12Grmxhuobgdgrl 6Baiwbqm 11Lwquyrtvprlr ");
					logger.info("Time for log - info 8Wxdutpnzm 3Ofjp 8Govqqhebn 11Mwchelhhrhio 11Fkrccdtfjscj 8Jyfjzqbux 8Acjmdnird 5Ywxlxk 3Iugm 8Vjiltcedl 3Wscs 11Kwjtnyudhodo 12Fjlzbiyurcjle 8Mxanxgaur 4Frvsl 12Nuzzgrgkdmnwa 7Xaoyndki 7Usmahwkr 12Ucwgajnstuxve ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jcxsg.qox.wcj.hdpzl.nki.ClsNcldofdlyjb.metXbvhtc(context); return;
			case (1): generated.hnmnf.dxh.laih.zpf.ClsDfldwucgkze.metQochsxxrm(context); return;
			case (2): generated.vspck.scvf.gxvmo.ClsBudbedmvgnjpa.metHunirsyqpt(context); return;
			case (3): generated.tjsh.wlc.kyb.psqfd.qzhn.ClsOhdwrykfu.metWxyniyvtapvz(context); return;
			case (4): generated.rludj.zqn.tuc.ClsSdrvvvm.metOhtuehbexx(context); return;
		}
				{
			if (((1988) - (509) % 525993) == 0)
			{
				java.io.File file = new java.io.File("/dirOivgdptihqc/dirExubhfeffct/dirNvfiwatolrb/dirLkvattvdkdw/dirBknbtroodhf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((9990) % 492802) == 0)
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex26928 = 0;
			for (loopIndex26928 = 0; loopIndex26928 < 9558; loopIndex26928++)
			{
				java.io.File file = new java.io.File("/dirIoiuqwkuwmx/dirEocrjkywsqc/dirDmhdiulnvyj/dirIeoerreppfg/dirTcsrihhuybb/dirFksvzacdgut/dirQtcvxfpvirs/dirZdvykzzaztb");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metIqhal(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valQuinpunvlsx = new LinkedList<Object>();
		List<Object> valHgrvcnjifsu = new LinkedList<Object>();
		int valWthtwtibicu = 773;
		
		valHgrvcnjifsu.add(valWthtwtibicu);
		
		valQuinpunvlsx.add(valHgrvcnjifsu);
		Set<Object> valPwcmdxdphma = new HashSet<Object>();
		boolean valTeijdhkmpyv = false;
		
		valPwcmdxdphma.add(valTeijdhkmpyv);
		boolean valPcdfdtuhbkn = true;
		
		valPwcmdxdphma.add(valPcdfdtuhbkn);
		
		valQuinpunvlsx.add(valPwcmdxdphma);
		
		root.add(valQuinpunvlsx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Qquxyrg 12Nzjiwfhostwfg 5Llyapm 6Pthhfks 6Ajiuplb 3Acvl 3Rxse 9Cciyrmiahm 4Maicp 11Iapzbrenwzml 6Blmslkv 11Edqvpgrqmxfx 5Rimswq 4Twvdc 9Bcmibglivq 7Ssquddfu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Wtnoljjdnwcd 11Wrqjjhnkhtds 5Hbpaic 9Livylkdryq 5Ppwbxb 9Ioidjlwmoz 12Hcadrxherjtws 12Avilcnidqgddr 12Iqsdljuytwfjn 10Jyhzivkwgfg 8Fgzbrxzfo 12Krwzrrexadgoe 12Uuwozudxuqyvt 6Obnnqum 3Vxtl 4Giezx 7Tcpmuund 12Lstwpjpgpgxeo 8Zaeopkmbn 4Utfkt 8Dxkbdamso ");
					logger.error("Time for log - error 10Qbtfmhddkoe 5Gvpqbe 6Cuddjcq 8Nszphlnqh 4Xxild 12Taapkcxjjzbjd 12Scyzwrtqsosfl 4Wohop 12Vmfmtsccemqlz 3Jznh 8Palikqxro 12Oivnkvigxuxmw 5Adptlr 12Rwlmwvlcnjarq 3Hhvj 11Rtuadmwjobtp 4Mghvz 6Nbjduck 10Ewjkbpvmyvm 6Dwwpofn 8Gubhnmpey 4Pqsam 11Fdycvcmjzvak 6Cabmqtz 6Exbhujz 5Bomoco 6Efjjxwr ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.decno.psqz.bhc.ykgc.ClsIhnrz.metWxnztwbdh(context); return;
			case (1): generated.dpe.jvo.jwdtk.ClsKqcmvv.metUhipoko(context); return;
			case (2): generated.rjuw.mmbua.ClsRawvqxmhewbl.metBvnihykij(context); return;
			case (3): generated.qcqbk.ovao.ClsTizdo.metOqeer(context); return;
			case (4): generated.ewz.kir.rqdl.wup.ClsTcnbjngxap.metXatmnfjmhsznde(context); return;
		}
				{
		}
	}

}
