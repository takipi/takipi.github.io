package generated.vspck.scvf.gxvmo;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBudbedmvgnjpa
{
	 public static final int classId = 345;
	 static final Logger logger = LoggerFactory.getLogger(ClsBudbedmvgnjpa.class);

	public static void metRtbqqjsh(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valSbesrufftdv = new HashMap();
		List<Object> mapValAikknxxcwft = new LinkedList<Object>();
		String valGyiuzmqdmmr = "StrIsatdqiiikr";
		
		mapValAikknxxcwft.add(valGyiuzmqdmmr);
		
		Map<Object, Object> mapKeyVpzmrrjntyu = new HashMap();
		int mapValCbbhfmzlzit = 127;
		
		int mapKeyXetqbqptqwo = 424;
		
		mapKeyVpzmrrjntyu.put("mapValCbbhfmzlzit","mapKeyXetqbqptqwo" );
		
		valSbesrufftdv.put("mapValAikknxxcwft","mapKeyVpzmrrjntyu" );
		
		root.add(valSbesrufftdv);
		Map<Object, Object> valDfjlbjkgdlc = new HashMap();
		Set<Object> mapValLfrcbrzhjuu = new HashSet<Object>();
		String valEhsvigvzzra = "StrFastdxqpivf";
		
		mapValLfrcbrzhjuu.add(valEhsvigvzzra);
		boolean valCdizvizfbuf = true;
		
		mapValLfrcbrzhjuu.add(valCdizvizfbuf);
		
		Map<Object, Object> mapKeyLwllmalnnos = new HashMap();
		boolean mapValLzcnjmuibij = true;
		
		long mapKeyOxdunmjoxqm = -7316847017089366092L;
		
		mapKeyLwllmalnnos.put("mapValLzcnjmuibij","mapKeyOxdunmjoxqm" );
		int mapValEtsffqqlitr = 228;
		
		long mapKeyTzubcdtsvhm = -5653924359338088889L;
		
		mapKeyLwllmalnnos.put("mapValEtsffqqlitr","mapKeyTzubcdtsvhm" );
		
		valDfjlbjkgdlc.put("mapValLfrcbrzhjuu","mapKeyLwllmalnnos" );
		
		root.add(valDfjlbjkgdlc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Sekcopbkw 12Xhgdhjvsprqsi 5Fcjear 10Arhtvytreox 11Ajlzmrkjgdqf 3Dzmi 7Joovfwnu 10Wviriseyvda 5Yhtjmz 10Hklyqojtbpp 5Rgzvto 11Zdayjbyhgjia 4Mgmhb 8Tqwypitux 3Qwxk 12Gpvxuzmcttsvt ");
					logger.info("Time for log - info 12Pgeuysecmvbgk 12Bvzymsfmudlph 6Lfvmiyi 11Kodsigfpmcie 4Xrppd 3Rocc ");
					logger.info("Time for log - info 6Hkbjbxr 5Dvskpd 7Zkrngatj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Ivmiauodufw 4Gklen 5Yhhccd 10Riocuucmcvq 7Optwgzkv 9Tgusezxnzu 10Tkbqwdwnqxr 10Aztnjmqrjcp 7Cebimqqd 4Ewxod 11Cbsddzmyqhqa 3Tvix 10Cszzafjiner 3Quvr 11Iyeisepkrdri 12Ekwrusaovbpne 6Sndqqtf 12Okqthsqluhapy 12Rhqipspuuuxcf 5Yjeoic 8Riitehzxw 5Gkhmvu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tei.zyt.ClsLkzwcb.metYgqywxliqwprfr(context); return;
			case (1): generated.kfvy.ymxa.end.hazk.nwqfn.ClsXakhsfoyrlse.metSihzklw(context); return;
			case (2): generated.qnzm.livr.ClsPutzsgygioejxl.metEdvcgkuyiw(context); return;
			case (3): generated.prq.bplky.nxkb.ClsOpjmpjfimau.metKcvsmcfaqhw(context); return;
			case (4): generated.zadtu.owlhb.qsd.bfzb.ClsWgiwrqnvyw.metYrmyjlzzyyu(context); return;
		}
				{
			long varInmtkbzasir = (Config.get().getRandom().nextInt(550) + 5) - (4965);
			long varPethspqhshs = (Config.get().getRandom().nextInt(919) + 7);
		}
	}


	public static void metHunirsyqpt(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Object[] valQmljdyrjrce = new Object[8];
		Object[] valXytmcyqyaqf = new Object[5];
		int valRohnterfdef = 530;
		
		    valXytmcyqyaqf[0] = valRohnterfdef;
		for (int i = 1; i < 5; i++)
		{
		    valXytmcyqyaqf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valQmljdyrjrce[0] = valXytmcyqyaqf;
		for (int i = 1; i < 8; i++)
		{
		    valQmljdyrjrce[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valQmljdyrjrce);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Kkbhesothupc 4Amdot 5Jgjyuc 12Lbtoevhnfqiav 3Zlqm 4Zgphq 3Nwbs 5Vwolvq 11Wovdfgazqqub 4Ynsoj 11Mukgkmmrpouh 10Fllgilpctpc 4Pqaxq 6Rtnycxg 4Dnbom 6Ipeiboi 3Ahzy 10Cbvfbmxuoay 11Xkmnudrdwmij 4Rofqd 8Cowvfjsci 6Pwyoehi ");
					logger.info("Time for log - info 5Cwvomq 8Geminrktd 11Nqdaylickscp 4Vnbqb 8Zcjppmzmp ");
					logger.info("Time for log - info 7Zmfmltjz 5Empddn 4Jipva 3Fpag 8Rhuriijre 3Rgog 6Efhmmxu 10Cwaisvmudqo 9Fglwmzzzcc 10Fvomqjaewte 7Ufzlyxss 9Ypgjerdpgk 12Cxzdfrgvzutmz 10Anckzscbgnz 12Wtehdknonbsev 4Mxvpo 9Lsizwncync 6Jouyiyo 11Aiuclapfsiuo 9Fayyfnxsuc 6Uptfflc 8Ccnrlbzlc 3Gnet 11Qtqlraylxpxk 10Qfqvjtxlqmp 8Hlmxgemwi 4Yphel 4Yoyqp 7Avmhktrm 10Htrnmgnogpc 12Qgdbmtaqojpaz ");
					logger.info("Time for log - info 6Yctxbpk 5Qizacj 8Xcpgshxmt 7Gamxvqcs 7Uejzxfxb 12Ilguzmqzyyfac 4Ombyn 8Xeeumavkj 5Qwhzxd 5Ewmada 8Dlgmakzhr 8Lqktxutxc 8Rcyqwqyyy 8Uzzkfhxmb 12Hhubzmwvrtnoe 12Baucruybqzvvs 5Vahqrk 12Iycsggfqqcrzf 4Cwzzt 8Pcpiwfgfg 10Jvedtjzwhkd 12Uycmgdvhrngbx 8Ctdqmzlqu 6Bomwxpq 6Ukzyznp 6Hlhknfx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Aztfcdtfim 7Ljvjxrqk 11Iekgyjbaztqh 8Bvopprdyj 7Rfkoksbn 8Ttbnlkmee 9Vvghyibump 6Ulihsnh 5Gbgbey 11Vjlktoulvene 11Aavfsoszfojs 10Kxalrvactsw 10Vbafjtlvbzn 3Qglt 7Yjusphgh 11Oasvxidjgitv 12Kfulqcnwbrcnd 6Kwgsvmt 8Rlxyrkxjf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Jyqewvllrlj 3Hgat 3Srpi 9Shaxkbmtga 3Nxwp 6Lxafpfw 11Rpvqatockdor 10Gixcjiswqzz 8Efnmpxtbh 7Ndslebdz 11Aazxwgajbtwh 8Mrpltlviq 12Bmsgaynfoiavf 6Sebllxj 11Vpngbkkwtvzu 6Hentjho 8Jhgnaxqwu 6Ojrvqpa 6Kuocygn 10Zfcaggxerea 8Xxawbrmna 11Bafmyagjdfzg 5Qdgyxk 10Dlxksntsjcn 9Tggbamaaye 4Cgzsk 7Mtjhgrcp 4Xwiiv 3Ppal 12Aqaphholkkbgh 4Olzwz ");
					logger.error("Time for log - error 10Chieudndmrf 3Aupb 5Ywhivl 6Ysaykbe 12Gxhmfltvgkmoc 9Mnpotlynto 8Hicxdqgau 12Utxakyqvlczae 4Yhcse 7Idiykzwm 11Prnutbawutkr 4Pkwfg 8Rfxnowkov 10Rmrzxpcemzd 10Viyzwekinsu 4Bfbij 11Iykqalfpvnek 8Ebofihaqm 10Yptgupzlfzx 9Llpfjonqfz 12Zobvmzqvkjpvl 3Chau 8Todcxwftj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ebl.tdhe.hblqj.plazc.otajb.ClsEihhumwr.metZzqrbtidxpltas(context); return;
			case (1): generated.evl.qnyx.qnt.hnkpr.mua.ClsPqzytqp.metUufhjl(context); return;
			case (2): generated.dnnlu.krjt.bhw.ClsLntkclh.metQiwtaqmosogc(context); return;
			case (3): generated.qdml.hmlho.ClsQuiharvpvfv.metXrurj(context); return;
			case (4): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metXtcge(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(598) + 2) % 97018) == 0)
			{
				try
				{
					Integer.parseInt("numEkisjvkmxol");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numJihcblgoidk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
