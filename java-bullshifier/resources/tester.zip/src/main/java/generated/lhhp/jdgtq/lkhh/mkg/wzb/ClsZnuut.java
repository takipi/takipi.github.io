package generated.lhhp.jdgtq.lkhh.mkg.wzb;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsZnuut
{
	 public static final int classId = 417;
	 static final Logger logger = LoggerFactory.getLogger(ClsZnuut.class);

	public static void metLrcocicqjkqlv(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valFjekefnzrgt = new HashMap();
		Set<Object> mapValVypqroerwil = new HashSet<Object>();
		boolean valMnjqhyalocu = false;
		
		mapValVypqroerwil.add(valMnjqhyalocu);
		int valKxkilhwjkfm = 970;
		
		mapValVypqroerwil.add(valKxkilhwjkfm);
		
		Set<Object> mapKeyJdaadubrobk = new HashSet<Object>();
		int valXlmcetkyiis = 471;
		
		mapKeyJdaadubrobk.add(valXlmcetkyiis);
		boolean valAundorwpdmo = false;
		
		mapKeyJdaadubrobk.add(valAundorwpdmo);
		
		valFjekefnzrgt.put("mapValVypqroerwil","mapKeyJdaadubrobk" );
		
		root.add(valFjekefnzrgt);
		Object[] valJuohtsuoshf = new Object[11];
		Set<Object> valXkqsdlhgrgj = new HashSet<Object>();
		boolean valRosnekxxjxj = false;
		
		valXkqsdlhgrgj.add(valRosnekxxjxj);
		
		    valJuohtsuoshf[0] = valXkqsdlhgrgj;
		for (int i = 1; i < 11; i++)
		{
		    valJuohtsuoshf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valJuohtsuoshf);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Rfenhjpe 4Swspc 6Ollrhji 6Lcwxjgn 11Kizywjhyfobq 6Obtrasv 6Gckmwjd 3Bwgo 7Bqtlbjgr ");
					logger.info("Time for log - info 5Osklyd 10Gtquhgwcaly 7Gbkdppar 8Zhcbrcjaz 8Weateasih 6Jvkojup 8Gamvhldwc 3Whtg 12Wyigvtibvmgha 9Ejrkowvtxm 5Kprbxp 10Cinhgbexqgj 11Ptvcndfclnjk 11Mmiqxssfmcpi 9Ofmazajffd 8Nwhfvzckv 11Rcxddomsfyya 5Lrboia 6Vxdbfgb 4Rmjeb 12Mulrvkgydsbet 3Yvag ");
					logger.info("Time for log - info 3Qvco 4Qpxqo 5Urjvjr 5Qybhgd 8Tozclivsv 8Aofyalkso 5Uqklrx 9Utpyflvfny 12Qqyylftsqqtla 8Ihgrphdvz 8Brabtivuo 3Oeqi 12Vwudbwcayfkik ");
					logger.info("Time for log - info 3Icku 8Ikqloagfr 11Npbbyntvyxtz 10Amdpgsvckxj 12Qwdnbaianzkjh 6Wuusmaj 9Rpbooojqlh 12Pgrpiueoljsfg 12Egyrzdsmnymqq 5Xygouq 11Lrvntsrjwcsk 11Lxsvsadobfml 11Pzodvdipbcws 4Ezhqj 6Uvqrczi 12Eokgqdldvctjx 9Apqqnuojvi 9Oxbnvmnpjv 8Qogahfshr 11Njpzrtmorhfj 8Nmxhjpnrn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Mvtbhv 9Ezeavexalg 5Kqonpe 12Oyghqrhmumggp 11Zztmfyryorhq 4Vkypv 12Ekkbpuzzurwai 4Qbnxw 3Wntd 3Weap 11Gmpuiskrfdzf 4Whswu 4Numsx 6Zzoshex 10Cxnuvlivvmz 11Jmzoiocjhcst 11Tlneylzkghoe ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Itfnxgheriwb 11Bsmdtjjazcvl 11Argwvfxoacfk 12Kinosmefwaroh 5Hxqkfj 7Dfkrjrdy 6Arbtolg 8Upmcxsyba 6Uvervjk 8Pzjongokl 7Gpzfgnom ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metDcqlrafmtcoxm(context); return;
			case (1): generated.ecksk.wvb.ClsNtqfbmlui.metNnezvlsw(context); return;
			case (2): generated.nrrh.nxnu.xat.kha.ClsLoiagobs.metImjogkxzrsynw(context); return;
			case (3): generated.aea.iom.ClsOvjtnlwnmq.metKwdullewrqcq(context); return;
			case (4): generated.bde.vdlp.frn.zsrjp.eqwxd.ClsMvedn.metBrdejrtmmvqjyb(context); return;
		}
				{
			int loopIndex26995 = 0;
			for (loopIndex26995 = 0; loopIndex26995 < 9042; loopIndex26995++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex26996 = 0;
			
			while (whileIndex26996-- > 0)
			{
				try
				{
					Integer.parseInt("numJdclkuphwba");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
