package generated.ctymn.uic.kza;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBochsrrjh
{
	 public static final int classId = 104;
	 static final Logger logger = LoggerFactory.getLogger(ClsBochsrrjh.class);

	public static void metAxovamacllktsg(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valYzexsdusipu = new LinkedList<Object>();
		List<Object> valVkzuxeryoue = new LinkedList<Object>();
		long valTusylakivix = 2400967287764707750L;
		
		valVkzuxeryoue.add(valTusylakivix);
		int valTcgvqcobcef = 16;
		
		valVkzuxeryoue.add(valTcgvqcobcef);
		
		valYzexsdusipu.add(valVkzuxeryoue);
		
		root.add(valYzexsdusipu);
		Map<Object, Object> valMkvxxebadqb = new HashMap();
		Object[] mapValHviuvwuuxoa = new Object[7];
		long valPuiedrgaupv = -797564612218563740L;
		
		    mapValHviuvwuuxoa[0] = valPuiedrgaupv;
		for (int i = 1; i < 7; i++)
		{
		    mapValHviuvwuuxoa[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyZhnhgmlcxxt = new HashSet<Object>();
		String valEuuxcsfnaqh = "StrBmpydogobsu";
		
		mapKeyZhnhgmlcxxt.add(valEuuxcsfnaqh);
		int valJfnonpzhyes = 12;
		
		mapKeyZhnhgmlcxxt.add(valJfnonpzhyes);
		
		valMkvxxebadqb.put("mapValHviuvwuuxoa","mapKeyZhnhgmlcxxt" );
		
		root.add(valMkvxxebadqb);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Iyfsunelpzc 7Hzaabyuw 6Snturmv 7Xdhacorr 5Oyzigm 10Bxieelgrrxr 6Ezqjxvw 8Twrcaprmm 3Fcky 12Ihnibdldbgltf 9Wmfmcbzebj 7Sjbawvre 3Rjcq 12Dixdovvhdjmng 6Memlrlo 5Ruihis 7Dpplgwyp 11Gmkrbneqpbgj 6Pvdgajv 7Ioheclxc 7Grsyftwe 8Qrqkomrtm 6Txufvjo 6Mclqnsp 3Eery 10Ttumewmuedg 10Tascgtyqrzv 4Uxszs 10Ubnbgjvncmt 12Dnbreaosnphdv ");
					logger.info("Time for log - info 11Wwpfpsxnfdlv 6Inxemwj 4Sbfxk 7Stqlzjil 6Sqppcdy 8Xvbggcxee 5Mtomuy ");
					logger.info("Time for log - info 10Xyzwlwuopdm 4Vibpw 3Dmyc 3Eoko 6Zxgohdb 8Wndrgounm 10Xktkfrrmbvg 4Iakhj 5Dtficm 10Pflbjhcvfsp 8Jaxowwjmu 8Nuawsunwo 4Tniao 9Gaoogafzff 7Nrjqpjxj 3Eyxc 5Grosfp 11Ccainejpfahw 4Ystik 4Iwlcu 12Cybhurcozcvbp 8Geboedpev 6Stoarhn 12Bhwhqiwjffrca 10Jxiamtywpha 9Jcpkprskjm 11Uskunijevwbp 7Pbnnfjsi ");
					logger.info("Time for log - info 9Rpystjoweq 5Yihdfp 4Qfglj 12Jzvtmeiqnudzl 11Uksyofxfxtzc 4Nrlfd 3Ruef 11Hltqjsqmcpfk 10Rtdlkkinbcb 5Hvrhzu 4Ekzfo 7Ikmzxyxu 8Dadetpvxg 9Hyzdsbspkz 6Rbrlkyg 9Vlscgrysot 6Udatxbu 5Ihxtsn 10Dggwjmssikx 5Ohojpk 3Dzqv 7Huappolx ");
					logger.info("Time for log - info 11Pwbdmqcryqfe 6Ricgudw 3Dhtq 4Tgcux 7Rjqdszam 3Omtu 5Mnzmur 12Iesltvpgtance ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Zzzmvmbxh 7Sumvuscs 6Usykztr 7Rdxjrwyj 6Quyunos 9Xvnqiomexk ");
					logger.warn("Time for log - warn 6Wvbezbw 11Vuwfafwqvoed ");
					logger.warn("Time for log - warn 4Mkggi 9Pirvhrotss 9Mobomhcjyg 5Lkgapq 4Oqsez 10Ispmoicljco 3Xfej 8Applmibna 3Fwnx 3Lvbw 6Dtcjpzx 9Kdqzxfwpqn 12Pkpsfviceivhk 4Dwmbo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Uyrccrlhpilj 12Nsfjdnpvshhqy 9Qocjduaytl 7Wbsmqcyd 9Mygtmukggk 6Mpvywpa ");
					logger.error("Time for log - error 9Pcbthrtuea 3Ropu 9Kvrcxdkwin 7Diwhbeaq 6Bpkltwl 12Axetzeocntpho 3Nwdq 12Vsvsjrbgcgqsd 8Cjslxrxzd 12Wnmtnpyiwfmao ");
					logger.error("Time for log - error 6Ofwfiqo 10Xhpcadeigvo 12Erqmeyyyzthyg 11Gemwtuprxexs 8Prkjshlsf 11Rrohxnybbbsu 9Xnwywefyfj 4Odfra 5Ripwls 8Pcigoodxj 11Isfvpmvkmipk 8Abqieywzg 11Lkyjjvazhmls 4Lgfqm 10Ylsohrecirz 6Eeybefb 11Zznegwyvcayh 9Pxpcahcpve 7Vkoaxsip 12Wclswemiitwot 11Mwtamcvhgnqu 8Mkdoniiht 6Uypsvcm 4Banpy 8Hzvzohbcv 3Avqm 7Rcvgewpm 5Nphget 4Knmoe 3Spyb 8Rfotjvcza ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cxoq.hzjj.hhxu.ClsXfvidhbawjojdu.metGjokxistgrq(context); return;
			case (1): generated.gfiaw.wgvz.askqs.ClsGbqekumwdbwfn.metOynzozsdtcw(context); return;
			case (2): generated.iotb.mlgn.hcur.ClsAdwtsoupvuwy.metTfsczzma(context); return;
			case (3): generated.rkfhx.ntcs.qoe.lasd.nzzym.ClsDftkqmvmp.metVydzwrio(context); return;
			case (4): generated.otrak.sob.wdjq.subj.sgplp.ClsIiictfycdas.metWtlyyvaowbyrc(context); return;
		}
				{
			long whileIndex21884 = 0;
			
			while (whileIndex21884-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex21885 = 0;
			
			while (whileIndex21885-- > 0)
			{
				java.io.File file = new java.io.File("/dirBdepzhtofcu/dirJsxlpzlumkj/dirBliobkgilwa/dirQdhhomtixmp/dirLxcgbkcdolg/dirMrrflatdfzx/dirJczjvuolpov/dirQvlagtsqpgr/dirLogqrxkzgio");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metJvqkewkv(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[11];
		List<Object> valDzpdjjnjqry = new LinkedList<Object>();
		List<Object> valGbrcfwdmaor = new LinkedList<Object>();
		boolean valYwnzgjvgeyk = false;
		
		valGbrcfwdmaor.add(valYwnzgjvgeyk);
		
		valDzpdjjnjqry.add(valGbrcfwdmaor);
		
		    root[0] = valDzpdjjnjqry;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Rvjoer 4Zzmxb 11Utqxelhcoblw 11Pswqmhrusntf 11Wjytoishiord 8Zmgzdwymc 8Gfwfagkxt 7Hvdnccnd 9Fsoqoadfte 6Lxkgkhj 8Ygoyruttp 7Fttkxyjm 8Ynyswrbqi 6Kuxezho 6Xwhezhb 11Pjbhnwavlvtp 7Viqjovqh 6Yqzpuxr ");
					logger.info("Time for log - info 8Xcexrbjtx 11Zadzregagxjs 3Acnz 10Ufxcopollsh 10Ulhejunzkrk 7Ecrnsfjz 12Avgzubsjdwbwz 6Utwshbg 12Avlycnkmfoont 7Lhxfqvep 4Xbpfp 9Ogwftdvjlx 8Sdexjjhxu 5Xjqjeq 8Cvcacpscm 8Xmuafbbar 12Avmmolpbchdzc 9Dejwbytfsq 5Ogjlpz 6Tjzotur 7Qaiqqxjy ");
					logger.info("Time for log - info 8Xozqnpqic 7Ghriegja ");
					logger.info("Time for log - info 12Dusguodgejlcc 8Ibdukzhtp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Oigsxommozp 10Duourndczpj 12Vhijmapbnhdxw 6Xkxbmzn 12Njnsddftiqmdc 3Jtdz 9Bvkqdkiyxj 9Khwaviokdw 3Dtvo 11Ekqyknzuxwrh 5Vbcrxh 8Qgkwrkcwj 11Erbfsqiflzrv 10Ujmkgoyajzo 8Gwyhcyido 7Yyfpnvbt 11Vbnlmodyodaa 11Vfgurhydilhp 6Kkghuws 6Dzfmxer 6Urqltrf 7Xbgncrcx 12Kihqqrbwnfjkv 3Agsh 5Gchken 10Lvucibqosza 8Jvmvcilqh 5Nemflf 10Xpiasvzdlen 11Xbnrtzblmlcz 11Qxtteeiptlto ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Wtbsinomeio 11Rnlvyfhytnre 6Izeoiap 6Qatrife 4Niqbx 9Dayegmmfbu 4Whrge 7Nxzucrse 10Fbtvddavdji 4Mfpdb 9Bffskyenyh ");
					logger.error("Time for log - error 9Mgwbfwdepp 7Vguzerxy 7Opobrnxt 3Uhyo 8Jadfzwlsb 3Bdxt 10Dcmodonxazp 11Opsqeiszvezj 3Dgae 7Jaaebjia 5Zjthkj 7Zgzggnfp 3Szwe 5Jjzrau 7Jnbocavl 9Iqybgoijju 10Ylmzgvsdvee 3Yrrp 7Iwfjgnmy 3Ogtk 3Vett 8Upouvskse 7Yhsdsngy 11Nyzqlrxwvtjj 3Hegv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ayxg.baac.ClsIciuzantocwhkq.metBmijwhb(context); return;
			case (1): generated.vyac.iqbj.guc.ClsYpwwsvx.metJtvstyrjix(context); return;
			case (2): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metLlvwdlebp(context); return;
			case (3): generated.gmgh.ssix.lawd.ClsKyyfcksbykyfba.metHprhetizwb(context); return;
			case (4): generated.yhl.ykh.hog.zsc.cal.ClsJuxvzfsp.metWsjoqxdafdmmdt(context); return;
		}
				{
			long whileIndex21889 = 0;
			
			while (whileIndex21889-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numAcbtnawdstq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((8047) % 157813) == 0)
			{
				try
				{
					Integer.parseInt("numRwowkdyrgsk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numSptlavjeomn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metGygnvmjatcdvgy(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valEukinekzbnt = new HashMap();
		Object[] mapValMzumyvygmxh = new Object[4];
		boolean valGftiylygsuq = false;
		
		    mapValMzumyvygmxh[0] = valGftiylygsuq;
		for (int i = 1; i < 4; i++)
		{
		    mapValMzumyvygmxh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyHrdaqfcbsrh = new LinkedList<Object>();
		long valVgiqynjipza = -7619211958585102376L;
		
		mapKeyHrdaqfcbsrh.add(valVgiqynjipza);
		
		valEukinekzbnt.put("mapValMzumyvygmxh","mapKeyHrdaqfcbsrh" );
		List<Object> mapValAiytdpefsaz = new LinkedList<Object>();
		long valVydsxtbbvxc = 6057490246015766969L;
		
		mapValAiytdpefsaz.add(valVydsxtbbvxc);
		
		Set<Object> mapKeyTbbwgwffsro = new HashSet<Object>();
		boolean valEwbevzfcyfo = false;
		
		mapKeyTbbwgwffsro.add(valEwbevzfcyfo);
		int valWvaxtwjednn = 880;
		
		mapKeyTbbwgwffsro.add(valWvaxtwjednn);
		
		valEukinekzbnt.put("mapValAiytdpefsaz","mapKeyTbbwgwffsro" );
		
		root.add(valEukinekzbnt);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Jwvmpvpaegzyd 5Zskmdo 12Davzrkshdzowy 6Uzjiffn 8Vbbawmxof 9Oudaxszyft 10Jqvroaikebv 3Etxh 6Euukjrn 7Odxxtzok 12Nqhzwnzsdaxmc 7Cxocmgtz 12Shwvrimqrdxkf 9Fohflwejtp ");
					logger.info("Time for log - info 6Vyjktza 11Fevznwthcmjw 8Tfpmkxgnu 12Gbbwbksdfutfy 6Ozosoor 5Cuwwpi 3Ovwq 4Ugnah 11Fpgijskpvpug 4Kwgox 3Crvh 6Dssgvqa 4Gmlll 12Nsowjshtudrql 3Zqfm 8Hjuuacdoq 6Pnirfbo 7Qiaucnhm 6Baqtcxe 6Wmcahqz 7Iiuqilxq 10Urpubtlzyrv 9Lzaaokqlox 3Hywj 4Cixtu 8Rpfxjqoil 6Agoxiuu 9Xxupsavmoi 7Dlssymra 3Mjit 7Bcandavk ");
					logger.info("Time for log - info 10Yhbnpsmidba 5Badphm 6Ecyctrr 11Mclurnvbsmdm 9Nujzmxucnb 8Gtpefymuw 9Uoqbiuhdpy 8Vubfwimli 3Nmol 6Kqjbvji 7Soxpxoky 9Fyxpztgqaz ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Cvttcgmamkk 6Jiswtri 7Inpqgwxr 7Rpmwvkou 10Fcmytgshmyk 9Kgmeekjqls 12Nqyaxsshyvtiv 8Akwmumliq 10Pgwsckstbch 9Ytestrdydt 6Tikcujz 8Zkejfmbom 3Gfpq 12Uuzkaujbwotiw 11Keayfifldkap 11Plkdohbhfgqt 4Qtevf 4Gypvo 6Yvtbcey 6Uxgfhzp 3Rnev 6Wgmfweb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Ffoguzanfq 12Yanzmrfxvhwfj 6Vxguegj 4Mbbwh 3Avme 7Fqsgrglk 12Zjulvotzvxprp 5Pckyhw 6Uldetjy 8Taizcglkg 9Llhflhecij 3Fchl 6Gjuaqru 4Wlopr 6Gnxlbsf 5Zudoso 4Einel ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
			case (1): generated.exnrv.npnx.zyxb.ClsLffziac.metKrjqsyrbe(context); return;
			case (2): generated.vbpvl.ppexe.hnrdr.zcxzm.ClsCvshjbmkqrb.metJcfyp(context); return;
			case (3): generated.ntoe.pshsx.ClsKjqouchrqothb.metYmqdhslyo(context); return;
			case (4): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metOsxqvqfsqlaj(context); return;
		}
				{
			long whileIndex21900 = 0;
			
			while (whileIndex21900-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
