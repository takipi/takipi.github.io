package generated.crkmz.uuny.smq.vvmxn.khxb;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQbvzuhroxdituh
{
	 public static final int classId = 326;
	 static final Logger logger = LoggerFactory.getLogger(ClsQbvzuhroxdituh.class);

	public static void metOrzyeli(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valBhnzqsmzjpt = new Object[2];
		Map<Object, Object> valWabsdnnietd = new HashMap();
		String mapValJsljquylcyi = "StrPcmlpblecly";
		
		int mapKeyBittbjvtlbm = 963;
		
		valWabsdnnietd.put("mapValJsljquylcyi","mapKeyBittbjvtlbm" );
		
		    valBhnzqsmzjpt[0] = valWabsdnnietd;
		for (int i = 1; i < 2; i++)
		{
		    valBhnzqsmzjpt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valBhnzqsmzjpt);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Cqayzkfq 4Iwhai 11Zhindbbgeseh 6Lwrrrkv 4Hktvm 6Irlrzyy 12Pgelxvsahsunx 10Emdthbwhsir 6Burhofu 9Omcqxcxzjy 7Qzgvkxdv 12Rbduqooyhysrl 9Ydnrbhvmfc 5Kzkdai 6Pcwvdwt 8Kmtleawod 11Rhpkdxawykkj 5Nbgsrx 12Okqhhhyvxjull 9Xkdcopmfjx 11Hxnluuyfrtwe 12Knyiimbtlitii 8Zvvwlhpnj 10Vjtbljdocpk 7Nvhjppzt 5Gletdt 9Zvidlsmgjt ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Azpltoswmolh 6Botquhj 6Nkowgxi 3Zhcc 4Vhvvc 11Buoqzgbzlzvd 8Kveczxmud 8Spyfezbkw 10Jnhivnatney 11Uarjjwusxpjb 9Fcuvhyakab 10Moafucydoda 9Bgajgwfhdr 12Yurvfuveisjbm 12Jbgvmnotxykxw 6Jcbfwyg 12Vxrohbzwssgka 7Tbbhfkfa 9Matbpdcvtx 12Fcmkgjjjhppws 8Xhsyiqwmr 9Ijzfherene 12Smgkwgcehixdm 7Brjrkjvu 12Buwoyktkeokdm 6Rkvemyd 7Moeootza 4Swalk ");
					logger.warn("Time for log - warn 12Snsrxktyhuyyz 6Koztrtp 9Ysuuldrimu 4Ebkvc 9Djxyigkzwg 9Qadjvhdteo 3Rubs 8Bnohatuav ");
					logger.warn("Time for log - warn 7Ydbgoymb 4Sqtig 10Rseabegodls 6Nvmtaax 7Yrupfqun 3Gato 4Utbay 7Rxksgrgg 9Tceggwxqgw 5Ifdpvt 8Sbfkjruof 12Ezasemmfbxkrw 11Uvlftsrvmuks 4Uukza 6Zdhnbze ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Wsfyvnctcxnhd 5Nvaoql 12Vvbatvnxroxtp 12Adzddpdbqfvut 3Holu 11Rehzgtvivjsu 11Bltbgbcegtcy 4Wekgp 7Drhteoiu 9Qsrnknjopg 3Cjwl 3Ezdm 12Uonfsrictmzkr 7Axjkkahr 7Bbnrhtqe 3Btqk 10Dpdpcxmqqzb 7Ztokrbgu 8Njdilksvh 3Tgyr 6Rdqlzby 7Rdjhcvsq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.uffsk.vmiw.dvm.uejb.ClsHwejuhoirpcucb.metTioel(context); return;
			case (1): generated.nrrh.nxnu.xat.kha.ClsLoiagobs.metTrfqw(context); return;
			case (2): generated.kdf.pknx.zlwl.ClsKeeubrxremfhhw.metOxjieq(context); return;
			case (3): generated.liyl.sfhr.ClsNilzqakfd.metXwuoarwg(context); return;
			case (4): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirYchlfgzdxfd/dirPkpmpdyvtpn/dirWyijzomorjo/dirGmcisaqeilj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex25523)
			{
			}
			
			int loopIndex25520 = 0;
			for (loopIndex25520 = 0; loopIndex25520 < 2496; loopIndex25520++)
			{
				try
				{
					Integer.parseInt("numOomlixtykyr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varKmdayaqvzmu = (3169);
		}
	}


	public static void metJqalviosof(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[6];
		List<Object> valSszffqmxcee = new LinkedList<Object>();
		Set<Object> valFbqrbgbgphv = new HashSet<Object>();
		String valUofybwebhpg = "StrHhyytidnmtl";
		
		valFbqrbgbgphv.add(valUofybwebhpg);
		boolean valIjcurfevzjm = true;
		
		valFbqrbgbgphv.add(valIjcurfevzjm);
		
		valSszffqmxcee.add(valFbqrbgbgphv);
		
		    root[0] = valSszffqmxcee;
		for (int i = 1; i < 6; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Wxfuzlcx 3Bsod 4Bfkeb 11Eqmzqdcalvmf 9Idhvrjhxbq 6Jlqoxtd 12Qeagatmcxgzfk 4Dambo ");
					logger.info("Time for log - info 5Mdvcfd 7Dlknzatv 12Dmdxihptgherx 3Suoc 7Egnbefmh 5Bhzzpk 9Xldleeynkh 7Ihinxjsc 5Timzpz 11Kthkieyjcmdk 7Pkvtxntb 5Desore 6Qhqvlhl 11Phyxguyixmrm 11Asfoxafqlric 12Orwhjdqmgoehs 9Cxxmtnbpul 4Btzgx 6Jlvoifv 11Fdtbdhxkfopr 9Mfpkztelbs 10Tdzexqflexv 5Fsnnki 6Mthgkoc 12Tcdrbmatqguky 7Mczbbulg 4Azjcr 7Ilpgdqzz ");
					logger.info("Time for log - info 4Hjthz 10Qcsmszlkiog 4Txqke 8Bzcqmqmcp 7Mknzjivn 9Rwcoyzrixt 8Ufsxrafad 6Lcswshr 11Prqvzwhectmf 9Hoinbrajuj 10Savyhmwohdc 7Tvvyqnsa 9Hjbosorbdy 11Aoqexwqaueqm 8Akrpcyvhu 5Onhffu 4Zkbom 5Dgdxbo ");
					logger.info("Time for log - info 10Pvbczquiqst 3Hffx 3Ljnr 4Dgcqy 9Gyfcbvblug 5Bxugdr 5Ipgndy 4Pdjnj 3Xlgp 11Ksnqpqyubnba 8Wxjtqbmmd 9Vrmfownwde ");
					logger.info("Time for log - info 6Zkogsod 9Kzaabxzlky 7Xhicyizd 5Qqxtgb 10Frtjhdpdlsg 12Byylgscghthor 11Sziyzuxiloqt 7Myresskg 6Eykpcio 10Wcskdrftfri 11Zvbgrejahpeo 9Lejjybekme 4Imeli 7Gjtdpnrd 8Opkuqoofw 10Aulweuqtxan 8Cchqwahii 7Qisoozqf 5Grhqzu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Ijtfxpc 4Orffj 11Blnsffysgcxv 7Kqccjvql 4Novzx 9Dvdtcyeszi 12Fvvyscdtttavl 5Wofvld 12Cksjtfubxxzdl 12Jgmxevltwvpkh 5Mmythk 12Mdqeyvhkdwnfz 9Euskepqjii 12Aytiinemwxkre 9Oeqqgjxqoh 8Efswtreja 3Zmdd 4Pgtze 4Cpffd 6Tafsdss 10Tjlhrfqlyzh 5Aktnrv 9Yzcwclenfi ");
					logger.warn("Time for log - warn 7Uxnnkgik 8Luetnfgpw 10Bewwglkudoe 5Nmurtw 9Gnwbddukyl 5Ylgsgs 3Uwzo 4Nrcdw 6Zbjhiqx 9Tjgasfegeh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Ydurdrucmcnr 5Demvds 5Wydoyl 4Mmaci 4Afurl 9Mkkphoyseo 7Ctryfbcs 8Pxfzswaau 5Onyfdp 8Ywwzklyxv 7Llwspvju ");
					logger.error("Time for log - error 10Yxgbcslsawa 10Fmxnlasbukz 9Szilnbedqg 4Dwzqk 7Mqafcfzt 7Lwazqcoj 12Kvzevyipwwswb 12Jwzjyvsetwryk 11Auqanoswbrxn 8Uiictcefu 5Kiajul ");
					logger.error("Time for log - error 9Dsmflqhloe 10Nhindrvfujd 7Ooadpgup 5Jfxssj 12Klvylnereuvew 3Smye 10Lkjlmiswiij 3Orqi 4Cssma 6Ikwjdac 9Sngniudzfp 11Ngybpcnucxhi 9Oxqirblmol 4Bxzhg 11Kopascuhxkkw 10Vklbceoxemm 4Uiqyg 5Ideapf 6Nrfybzb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zoaxa.yfbb.ClsTybiqkipwo.metQnlswcnqbxmqgz(context); return;
			case (1): generated.yfo.dls.qwny.cqaxf.ClsDosmbrrv.metNtnwha(context); return;
			case (2): generated.mbf.jauhv.phe.sowu.arz.ClsAtgovrsbvzxguw.metNzrbcudifbng(context); return;
			case (3): generated.zadtu.owlhb.qsd.bfzb.ClsWgiwrqnvyw.metYrmyjlzzyyu(context); return;
			case (4): generated.gmk.vzs.crbap.ClsEkyhsmjeh.metAjrgrsa(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(561) + 3) % 113866) == 0)
			{
				try
				{
					Integer.parseInt("numFkqxtyisdwb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metVqzfw(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Object[] valPqcgfhlmvml = new Object[3];
		Set<Object> valIboxvgrkzah = new HashSet<Object>();
		int valIbgpywbkkvg = 161;
		
		valIboxvgrkzah.add(valIbgpywbkkvg);
		
		    valPqcgfhlmvml[0] = valIboxvgrkzah;
		for (int i = 1; i < 3; i++)
		{
		    valPqcgfhlmvml[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valPqcgfhlmvml);
		List<Object> valZqcynleamzl = new LinkedList<Object>();
		List<Object> valBorulnhzdws = new LinkedList<Object>();
		long valYungkvuyxla = -564433735799921203L;
		
		valBorulnhzdws.add(valYungkvuyxla);
		
		valZqcynleamzl.add(valBorulnhzdws);
		Object[] valKwfhkfiyjuw = new Object[8];
		boolean valDpbicbsaybi = false;
		
		    valKwfhkfiyjuw[0] = valDpbicbsaybi;
		for (int i = 1; i < 8; i++)
		{
		    valKwfhkfiyjuw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZqcynleamzl.add(valKwfhkfiyjuw);
		
		root.add(valZqcynleamzl);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Mlfbawwlv 5Gwktpe 3Gyyt 10Vdlbwwjzpil 9Xnblvxlfmh 12Fshdbwrhvbccp 5Hikuvp 4Ehhnc 12Ipbhcsscvntzv 4Jtlns 10Tecgxyfoyli 10Xwmauqrnnyg 5Tkzdgn 9Wqwbulpwoz 7Pbiersfk 7Drkygeqj 10Gomsebeilgu ");
					logger.info("Time for log - info 8Dlxjntdun 4Lrysd 7Bvowspua 4Uarlp 7Biyazfpj 8Gpwhdvlbt 12Bzbvmnoyocjzh 10Ynqmergrcbk 9Bvootxobkc 3Iolr 12Gpmaiifutayik 11Covhhtqwsgqv 11Aljygvpyqqdd 7Esuhicgf 5Ultsxy 12Cggdqujbsrfty 6Liwjrqd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Msqtk 6Oxyidln 3Wfzd 11Ukhfobqtzeeb 6Qpdnjpa 11Mozswmhzlejo 5Xajimx 11Iatwmrbctgor 7Gxbrbxzf 4Uddqn 7Qvjjrxcb 5Pjrfhq 6Wskvubs 10Ijrhvszakhd 3Qzyh 7Foahurrx 11Cefatzvxjgsr 12Mkthsrniycjgl 8Hkcokapko 12Hujmqicdedzcq 7Rgfgioil 12Rztmmogmwsbgk 6Ejdjenw 3Gpao 4Igkes 5Yzqnpz 6Xhcyugb 3Rwnf 10Gpsyaqjzblu ");
					logger.warn("Time for log - warn 8Gybrfhuho 8Hoprzhaeh 5Qdfbjc 11Seuixeyirokt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Mnznfzznfj 4Oyuys 4Cqxut 11Cxmkgcfwfimz 10Dplkedladep 10Naqmefbljxv 7Iisuuaao 10Cusclhhuzcv ");
					logger.error("Time for log - error 7Rdkqljib 11Watrskbfmhfd 9Jskbhulzlv 8Itgurogam 4Gchog 12Qhavcjgmfeanp 5Yvmjga 6Qeamvuq 7Dmbymqzy 9Gsesedvdjq 3Xkqj 11Etkadbdlvhbt 3Rxmm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wyah.shgd.ClsOoifqzin.metBzqievzkfqt(context); return;
			case (1): generated.kibd.nddr.nknr.pccz.hryio.ClsBgthm.metFrmpvshfvh(context); return;
			case (2): generated.yfo.dls.qwny.cqaxf.ClsDosmbrrv.metEzcdmyjxgzcl(context); return;
			case (3): generated.tzk.wxrm.bwm.qkv.ClsTeonxo.metQpntvyruck(context); return;
			case (4): generated.uxbqo.pcskv.udre.ClsKillneqmm.metIokufnwdnpfcxt(context); return;
		}
				{
			int loopIndex25529 = 0;
			for (loopIndex25529 = 0; loopIndex25529 < 2908; loopIndex25529++)
			{
				try
				{
					Integer.parseInt("numWrhwfrwpstb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metAiybrixueywscr(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valWcrujjpvxdi = new Object[11];
		Map<Object, Object> valTllxvkieglo = new HashMap();
		long mapValFlvxjdistjf = 8926007262408722061L;
		
		boolean mapKeyCuzwsuhyeyd = true;
		
		valTllxvkieglo.put("mapValFlvxjdistjf","mapKeyCuzwsuhyeyd" );
		
		    valWcrujjpvxdi[0] = valTllxvkieglo;
		for (int i = 1; i < 11; i++)
		{
		    valWcrujjpvxdi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valWcrujjpvxdi);
		Map<Object, Object> valEvnjirifdpd = new HashMap();
		Set<Object> mapValNdqtzjtnxqi = new HashSet<Object>();
		int valXpwtbousopa = 440;
		
		mapValNdqtzjtnxqi.add(valXpwtbousopa);
		int valJntpowpvqzn = 321;
		
		mapValNdqtzjtnxqi.add(valJntpowpvqzn);
		
		List<Object> mapKeySlofkuglglm = new LinkedList<Object>();
		boolean valQqsqtbdlwfb = false;
		
		mapKeySlofkuglglm.add(valQqsqtbdlwfb);
		String valCgttmoqfstd = "StrUwlqzqlcmez";
		
		mapKeySlofkuglglm.add(valCgttmoqfstd);
		
		valEvnjirifdpd.put("mapValNdqtzjtnxqi","mapKeySlofkuglglm" );
		List<Object> mapValAbboibuzozk = new LinkedList<Object>();
		boolean valRbgqwkhpqmz = true;
		
		mapValAbboibuzozk.add(valRbgqwkhpqmz);
		int valOtejeaattcr = 804;
		
		mapValAbboibuzozk.add(valOtejeaattcr);
		
		List<Object> mapKeyRscsimdpmvj = new LinkedList<Object>();
		long valYsacgiscrlj = -6469712576297968189L;
		
		mapKeyRscsimdpmvj.add(valYsacgiscrlj);
		long valAesmsmwjewr = -4584926822142233172L;
		
		mapKeyRscsimdpmvj.add(valAesmsmwjewr);
		
		valEvnjirifdpd.put("mapValAbboibuzozk","mapKeyRscsimdpmvj" );
		
		root.add(valEvnjirifdpd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Mcml 3Qpiv 6Zjvicyb 5Xqzkga ");
					logger.info("Time for log - info 8Kpwylyspp 5Iudoba 9Kvqrajqdct 5Xoziwp 4Hhpww 10Fatnjjsbnyl 9Bvdwqgnhzi 6Iowixeo 4Tzduc 6Mvsiaif 11Gcaohsroeauv 8Qguysjfwg 8Aftrghsml 3Olbu 8Rbprecgft 4Mylvf 3Odel 7Quuaaivd 4Dppyl 8Oukcuyefp 6Makpbha 10Ksaklhyvbbi 10Fwokyaknsyz 10Xbljlbkmljl 10Lrwexxfcxop 10Cfntvlphcbo 5Hyilak 7Duvtxbiw ");
					logger.info("Time for log - info 9Asfjmdyibs 4Zbqqo 4Lrjdv 3Vjhp 6Lnkwtow 10Btaohirlfmt 10Sffxivcyqqr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Ljsrlxk 9Xttoryctsh 7Ogmcfykb 6Uxeibok 12Fbxhhrjbtxgod 10Zrprjfncgly 5Tfejpy 10Sijouhfmtab 5Ycvvha 5Brjsac 8Mcecgrfbr 3Stoj 6Rmjecez 8Bfnhoadif 5Xcgzrx 12Tukutcapnbech 11Bjcyzdgeojow 8Strnfvdkz 10Ctcmyslwqgm 6Pfvrjfv 7Ttqqzofw 9Lngsnwaqnc 12Kzmhklednzfkj 11Zxuvmcxtqggg 8Maluponzf 11Ytbljbjigqdc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Xlghanqggynf 11Pxiulwwinwqx 10Dpyqthegzca 5Lgccwq 3Atug 3Cwha 4Sfrbw 8Gyvwdjaut 10Vfjwbghkukx 4Fjiwm 9Knmgvepvfu 10Cwyvogzfpyk 5Icudrv 8Ssjrfziki 6Bnajzjq 10Ruvsuicyxbf 11Ylefkouljsgq 12Bwdnctxtycecz 6Ivzzlab 8Ughsaeazm 9Glvgeoypkm 12Pmpshrttdhlda 6Ytconvf 4Akzwt 5Yikdbk 12Yrrqaibilgzui ");
					logger.error("Time for log - error 8Yznsxbaia 4Ujxiu 6Jyotido 4Avphg 4Odybo 10Nmamyjhxeze 4Tjexu 9Rgbahuscgj 6Ibuzqcw 6Farrboo 12Vadswabyyjbjg 10Usogouulbgl 10Wynamndvzux 10Fsmwtqbpqmq 12Llyvrveyoogsp 7Izivmyqe 7Dxmzodft 11Grqmmzbekpwa 4Qaarn 7Isczpmgh 4Eegvm 12Syotdwbhyipsw 10Srpsmogiytx 11Rtouiqmzqlhi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gmk.vzs.crbap.ClsEkyhsmjeh.metBjlkuzsllrtdeq(context); return;
			case (1): generated.uzhb.dwl.ClsEamgh.metTrwzd(context); return;
			case (2): generated.oue.dqjq.ClsSjudu.metSsbbjwfrp(context); return;
			case (3): generated.gww.spuw.jrq.nmv.xowli.ClsKosigq.metKvjjegqp(context); return;
			case (4): generated.vhkgi.kzbju.ClsAkkdrnlxagwy.metKsomxqgjrt(context); return;
		}
				{
			if (((8428) % 498650) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(784) + 1) % 777533) == 0)
			{
				try
				{
					Integer.parseInt("numVrtnpfgpjle");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numGgjijpoubmy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
