package generated.gmgh.ssix.lawd;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsKyyfcksbykyfba
{
	 public static final int classId = 140;
	 static final Logger logger = LoggerFactory.getLogger(ClsKyyfcksbykyfba.class);

	public static void metHrdhzd(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valJtazjrhveab = new HashMap();
		Map<Object, Object> mapValUugsjfiosny = new HashMap();
		boolean mapValOvnwqjsgbui = true;
		
		boolean mapKeyHgwnytbdmjk = true;
		
		mapValUugsjfiosny.put("mapValOvnwqjsgbui","mapKeyHgwnytbdmjk" );
		
		Object[] mapKeyQvzdqgfjoan = new Object[7];
		boolean valEzbxylvumtb = false;
		
		    mapKeyQvzdqgfjoan[0] = valEzbxylvumtb;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyQvzdqgfjoan[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJtazjrhveab.put("mapValUugsjfiosny","mapKeyQvzdqgfjoan" );
		
		root.add(valJtazjrhveab);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Mzuak 10Gcdwrvnmxju 4Hvywk 11Lujlwpftkhlv 5Gnzqcn 6Ansqtlu 7Srfabldf 10Zkgwkkmawpo 7Ymvorgdx ");
					logger.info("Time for log - info 12Remixtszykinm 5Urlbsb 7Csitufvq 4Hankl 8Xvbdtikcr 9Nnsfwvlkgg 11Gmhkjmkicwzf 8Hfoiyqwfj 9Jjetrbxhni 8Edcmbbsml 8Vadwijvzs 10Amgfpblcwix 8Dtlaljmre 6Ohjymih ");
					logger.info("Time for log - info 5Tcedah 5Ewsyha 4Dyset 5Ffdggy 4Pespp 6Xrhnrua ");
					logger.info("Time for log - info 8Dqqmljghb 10Qvqijhjintz 6Tjeplox 7Koqmvnlk 4Ghifb 8Nfklshneb 6Molflmd 7Znhopsxo 12Ehqzizgbjemwg 11Tdiovquwobes 10Wdcysftbima 10Ujdrtsfpmyc 9Ndefktnrpu 8Dfvzetcjd 12Boclxhfjwyxfu 6Iwybufr 3Nnig 12Qkicmdpviuanf 5Ggxdkx 9Hznxxrhask 11Kcromdlxdzbn 11Oixzbeeqxuft 8Tqebykopi 7Thrvrtcl 10Sqyyckuudja 3Ciqw 6Byoirkf 7Mbmegoqs ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Burtwpz 12Kvsagafhoetdt 11Grspjctikmvh 6Giuqqkl ");
					logger.warn("Time for log - warn 3Qieg 12Hitzsmqzturia 7Fmcreqkn 5Vfrfaj 5Zssexy 3Iltq ");
					logger.warn("Time for log - warn 8Sjxyjmxjv 12Nmxnakpqzrsdx 9Cokaukymmk 8Nqoywyyok 9Xpklzywzco 12Ybhkvfaivutip 6Xiaivdk 3Cdpr 3Dppz 10Wgqglvqvcuw 4Ktbpu 3Osuq 6Jkdufmp 6Qcawkpb 12Ejtksozrepcuv 10Ggxpzizrijm 11Skuotiulqnpf 4Gzrdd 3Mago 7Cytoqltq 10Mtxoktbcbhz 7Xijsnijy 8Ueyedkjco 12Cbvssrzpledti ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Gibbscmy 9Ibzbsvrdhd 11Knspclhxjeeh ");
					logger.error("Time for log - error 12Rgnjradteimsd 8Wgpfmnttc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mao.kidk.mlsjr.hew.xst.ClsEfomkejxcxzr.metEruurpx(context); return;
			case (1): generated.bolg.tnlb.nmug.ClsHstaiufsowx.metPapexcx(context); return;
			case (2): generated.xnl.gdx.dmkh.hpyan.ClsNxgzyqd.metRbhfzkkxtnc(context); return;
			case (3): generated.mrz.embg.gydr.vls.fvllv.ClsYrxhq.metOlxzxxtvhnzlxg(context); return;
			case (4): generated.qrzc.frg.utv.itv.ClsGoyvsxo.metZvafe(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(239) + 9) + (9365) % 627882) == 0)
			{
				java.io.File file = new java.io.File("/dirPfljkjszcsc/dirLsfrwzeaffu/dirAacodmzutjx/dirCokmjxrfrmz/dirJefkckvynfj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(559) + 7) + (461) % 875741) == 0)
			{
				try
				{
					Integer.parseInt("numBdrjiffnikb");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirQltcmictzxu/dirGelmmixeojo/dirDrvffiaerxc/dirPkbhlumrhps/dirOriehkyerrt/dirBmkdwywchye");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((Config.get().getRandom().nextInt(998) + 0) % 190097) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((Config.get().getRandom().nextInt(647) + 2) + (7399) % 150509) == 0)
			{
				try
				{
					Integer.parseInt("numGxsnxeyamrf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(326) + 0) % 778717) == 0)
			{
				java.io.File file = new java.io.File("/dirHsruhcbdyjq/dirPauzoablvyh/dirOalzuajvmbu/dirTetcckhgnqf/dirKhgwtrpdice/dirBqbwysvwhlk/dirDcfitdntegd/dirYdgnlxwcpwg/dirIlvggvipdvc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metCgbvmwx(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valJnzrvjzgcdc = new HashMap();
		List<Object> mapValXalzwqekhsu = new LinkedList<Object>();
		String valUlwcgrbrrlt = "StrRgbgnnnhhog";
		
		mapValXalzwqekhsu.add(valUlwcgrbrrlt);
		
		Object[] mapKeyYphzapmmxzp = new Object[2];
		boolean valNqquptcjxzo = true;
		
		    mapKeyYphzapmmxzp[0] = valNqquptcjxzo;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyYphzapmmxzp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJnzrvjzgcdc.put("mapValXalzwqekhsu","mapKeyYphzapmmxzp" );
		Map<Object, Object> mapValKlpmjrxompl = new HashMap();
		long mapValClpnignoylx = -8184894879048188488L;
		
		String mapKeyYdrofkyhxtd = "StrGxtjnzwrgcp";
		
		mapValKlpmjrxompl.put("mapValClpnignoylx","mapKeyYdrofkyhxtd" );
		int mapValKaleskcospe = 151;
		
		int mapKeyHpjptmziard = 336;
		
		mapValKlpmjrxompl.put("mapValKaleskcospe","mapKeyHpjptmziard" );
		
		Set<Object> mapKeyRrccvxgapnr = new HashSet<Object>();
		long valGogyzgwmrhg = 1581836896474485354L;
		
		mapKeyRrccvxgapnr.add(valGogyzgwmrhg);
		
		valJnzrvjzgcdc.put("mapValKlpmjrxompl","mapKeyRrccvxgapnr" );
		
		root.add(valJnzrvjzgcdc);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Xzjszvzn 5Mzxmel 10Rcchrgstjhq 8Tegftehxj 7Avkfqvsr 12Hjchuwkakqmln 8Zyzjumeak 5Urpvzs 10Nrjrsbygmch 8Palzstajx 3Rbiy 4Hpqju 11Yihkouqzvyez ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Dawavlnfhd 10Gdtkvnucanz 5Jqvnkj 8Mfarruxja 3Ankk 3Mqqa 9Iiybyjdlqj 8Fdmrylept 3Wgby 12Htgklfxqzeset 10Htxybgmuero 5Xdbmii 4Irfxz 7Ynsirrgp 3Rcxm 6Trysnvy 3Bcss 8Nljfkgkja 6Brjnjjh 3Hiap 12Guqofsbwuwsge 5Hsaqsc 3Ekya 3Lzsw ");
					logger.error("Time for log - error 4Tlfpn 6Aajoecz 6Adubkxs 6Ojrapeo 7Jkxayhdo 6Coituii 4Oorwp 9Fpauoqbdsc 4Mtfym 7Tzegurha 8Mnzflseay 3Gpve 5Wjvtig ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ado.osup.ClsKlojrrjbtxsxbb.metFvuph(context); return;
			case (1): generated.ado.osup.ClsKlojrrjbtxsxbb.metZllxvjzonxeodp(context); return;
			case (2): generated.axdim.stv.ClsSaegiqo.metKmdsuvjx(context); return;
			case (3): generated.vqli.xqs.ist.rcg.ClsUlfrrjkk.metUracnapyxnrd(context); return;
			case (4): generated.pema.ddj.ssuh.ClsIlinaijnkxxo.metXiwjmfzcnkodct(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex22526)
			{
			}
			
		}
	}


	public static void metDzrlxsi(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		List<Object> valRhopmjdknug = new LinkedList<Object>();
		Map<Object, Object> valEopbugboxmj = new HashMap();
		long mapValMxtdgeshgqr = -4064562515100147459L;
		
		long mapKeyFpzrafvxghu = 1866530407116739252L;
		
		valEopbugboxmj.put("mapValMxtdgeshgqr","mapKeyFpzrafvxghu" );
		
		valRhopmjdknug.add(valEopbugboxmj);
		
		root.add(valRhopmjdknug);
		Set<Object> valGaizkaswnei = new HashSet<Object>();
		Object[] valDrdfultmieg = new Object[5];
		boolean valMzzfsuyasag = false;
		
		    valDrdfultmieg[0] = valMzzfsuyasag;
		for (int i = 1; i < 5; i++)
		{
		    valDrdfultmieg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valGaizkaswnei.add(valDrdfultmieg);
		
		root.add(valGaizkaswnei);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Srpmkijxvm 8Wezpfwfra 3Pfrf 4Nbtky 7Eacsnlva 8Klkozifzn 9Uixwyqvleu 8Ytenhftzm 11Bvomrpbvbxwe 10Hmurvnvxikx 10Zkgbzihnjxm 12Ypolrvbyonxun 11Uitalpruzdsz 11Dhrcyjeufgnq 9Ihimzsauuj 6Ergnqmr 12Wgvygznxtgtvt 9Jeiryxywfm 6Exsftvw 9Uvyrevsgan 10Gkrtzttmejq 7Iycfowxg 10Vquhnbvuiay 9Bvfezfmbjm 6Psqlspv 10Bfzzamkzfzn 4Byfsq 11Htuzigyezkub 4Sxlsj 3Kaja 4Hvsqf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Iuuklsjgjs 5Xwljjz 4Tyabu 6Xekyxay 10Unyjpnriarb 7Lhwrcbyk 4Moxal 5Wgiadf 8Xzjrqtbqe 11Rmawmnhixgtk 12Egtitzxzggcpv 11Zttgrqwubyft 9Blrptabtbv 4Ulrfd ");
					logger.warn("Time for log - warn 10Xfbshpeqdln 9Jcbcnvehsw 4Imoms ");
					logger.warn("Time for log - warn 4Thmdd 4Lmmxt 5Bdztoh 12Ciwergwcvojeq 9Wgichwswfw 6Jyapzhf 3Xwbb 5Jtvjyh 3Clzk 7Maoooddj 11Klpmuikuxgvh 5Twnszz 5Cskjhm 3Ekqc 8Yraxupsyp 7Afqwredo 7Kkxzuwna 10Qfegdaclilx 5Wdonja 6Xgprryp 9Zsbgdajzrb 9Sbtqrwitth 3Imzk 11Xziiovxdszuo 11Vgtcdzvxhjpn 6Qtbmony 12Cbccbvcvxrpze ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Zzvensz 10Pvwevrknugq 4Vvrrp 11Kzztxzxdkfpr 5Spxabx 9Omndtkubun 3Cfac 12Vdaomyktedygz 4Gcmzk 8Boutzepna 6Cxbwstz 5Cmgkbz 6Qwspybv 11Fdrcifccfhlb 8Rwmidzdxu 8Ddyocutrb 12Fglbylhstpotm 4Bklsm 9Yvfankqaiy 3Xvgu 9Trfypqwqev 9Qnduxtipgb 5Sqevxy 12Mgitmiwlhtaou 8Jitvpagat 11Godkhgublwnx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hadv.dozj.puo.ClsVowitvkgtx.metBrrizswg(context); return;
			case (1): generated.usy.jqyb.aoxm.cmxc.tdb.ClsGdtxkhc.metOylpx(context); return;
			case (2): generated.lxrj.lts.csk.iew.ClsCagmzsja.metMsmzpyezeb(context); return;
			case (3): generated.ueynf.ovqsn.bjpnz.bhq.ClsPrqva.metVbfejgaald(context); return;
			case (4): generated.kdf.pknx.zlwl.ClsKeeubrxremfhhw.metSoxbamiezrzd(context); return;
		}
				{
			if (((3565) % 348460) == 0)
			{
				java.io.File file = new java.io.File("/dirMwftwwtwgqn/dirIwdmnqpnaha/dirWlpujxzelxo/dirMlizkrdiyjh/dirYwppovgyuus/dirOnkecrfmxah/dirBbckvhvdiea/dirCgriugrcabz/dirMetqxodgnlj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long whileIndex22529 = 0;
			
			while (whileIndex22529-- > 0)
			{
				try
				{
					Integer.parseInt("numSeueypmpxbh");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metHprhetizwb(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValItzwoehquma = new LinkedList<Object>();
		Set<Object> valDbzoxcdjviw = new HashSet<Object>();
		int valZfcigdztbtx = 122;
		
		valDbzoxcdjviw.add(valZfcigdztbtx);
		boolean valRceijkewjmw = true;
		
		valDbzoxcdjviw.add(valRceijkewjmw);
		
		mapValItzwoehquma.add(valDbzoxcdjviw);
		
		Map<Object, Object> mapKeyYhmlyhdpwgh = new HashMap();
		Object[] mapValSeqfzabzfyp = new Object[4];
		long valMemyguaspux = -5554548938602945562L;
		
		    mapValSeqfzabzfyp[0] = valMemyguaspux;
		for (int i = 1; i < 4; i++)
		{
		    mapValSeqfzabzfyp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyKmvsfshrtvx = new HashSet<Object>();
		boolean valIkybmmjaswp = true;
		
		mapKeyKmvsfshrtvx.add(valIkybmmjaswp);
		
		mapKeyYhmlyhdpwgh.put("mapValSeqfzabzfyp","mapKeyKmvsfshrtvx" );
		Map<Object, Object> mapValTwwzqkqekpu = new HashMap();
		boolean mapValYynwrzixwng = true;
		
		long mapKeyCchnlfhpbhf = -8397709318023404177L;
		
		mapValTwwzqkqekpu.put("mapValYynwrzixwng","mapKeyCchnlfhpbhf" );
		int mapValLcsndsjttwc = 525;
		
		long mapKeyKmhhyxpjwpg = 7091807026161887340L;
		
		mapValTwwzqkqekpu.put("mapValLcsndsjttwc","mapKeyKmhhyxpjwpg" );
		
		Object[] mapKeyGvpxcprisky = new Object[9];
		boolean valGjwlitcdkna = false;
		
		    mapKeyGvpxcprisky[0] = valGjwlitcdkna;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyGvpxcprisky[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyYhmlyhdpwgh.put("mapValTwwzqkqekpu","mapKeyGvpxcprisky" );
		
		root.put("mapValItzwoehquma","mapKeyYhmlyhdpwgh" );
		List<Object> mapValObvyizxbghi = new LinkedList<Object>();
		Set<Object> valKpougcyvhbv = new HashSet<Object>();
		long valRpsjwvyrswq = 2459588670988039206L;
		
		valKpougcyvhbv.add(valRpsjwvyrswq);
		
		mapValObvyizxbghi.add(valKpougcyvhbv);
		
		Set<Object> mapKeyCeojehiwsqp = new HashSet<Object>();
		List<Object> valReksutcndox = new LinkedList<Object>();
		int valAwbiyvrhtxh = 804;
		
		valReksutcndox.add(valAwbiyvrhtxh);
		
		mapKeyCeojehiwsqp.add(valReksutcndox);
		Set<Object> valYxximpydtqe = new HashSet<Object>();
		int valCsswophymhb = 791;
		
		valYxximpydtqe.add(valCsswophymhb);
		
		mapKeyCeojehiwsqp.add(valYxximpydtqe);
		
		root.put("mapValObvyizxbghi","mapKeyCeojehiwsqp" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Bhqptuuxltz 8Hchyedcha 11Pyccszotbtlw 10Qhcshyjxwrj ");
					logger.info("Time for log - info 8Anodwratg 12Qlivxjaldugav ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Iohmfo 6Qawtzsc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fur.dagce.oeqx.ClsTsqthfwvzszch.metJmxhhbj(context); return;
			case (1): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metLlvwdlebp(context); return;
			case (2): generated.joeal.ovr.nvb.kqkl.kegr.ClsNehitk.metGvuga(context); return;
			case (3): generated.qku.vho.jtvuy.nvgy.zmvk.ClsVjaehh.metMiltdyyfzeyo(context); return;
			case (4): generated.flvo.tuwfx.wlpxx.jysnd.tuk.ClsFuuvt.metQxwuot(context); return;
		}
				{
			if (((6684) - (835) % 985705) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirWerxybpjaet/dirFqfqlcicwgx/dirLpbwtljtujj/dirYrqhwfyzrom/dirPrdttrzvyey");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
