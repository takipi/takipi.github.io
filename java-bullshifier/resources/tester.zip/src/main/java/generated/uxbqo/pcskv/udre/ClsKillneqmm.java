package generated.uxbqo.pcskv.udre;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsKillneqmm
{
	 public static final int classId = 219;
	 static final Logger logger = LoggerFactory.getLogger(ClsKillneqmm.class);

	public static void metIokufnwdnpfcxt(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valXdxsukezpqx = new HashSet<Object>();
		Object[] valIskvooigcsh = new Object[7];
		boolean valSmilksekiif = false;
		
		    valIskvooigcsh[0] = valSmilksekiif;
		for (int i = 1; i < 7; i++)
		{
		    valIskvooigcsh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valXdxsukezpqx.add(valIskvooigcsh);
		Map<Object, Object> valJyfujdbmubd = new HashMap();
		int mapValJvbyxwlzhlc = 890;
		
		String mapKeyDkcosdyscyi = "StrPnkltlxqpwc";
		
		valJyfujdbmubd.put("mapValJvbyxwlzhlc","mapKeyDkcosdyscyi" );
		long mapValMlpibkbeorz = -986095967778248403L;
		
		String mapKeyAtbgrfjvsws = "StrHuvonauhled";
		
		valJyfujdbmubd.put("mapValMlpibkbeorz","mapKeyAtbgrfjvsws" );
		
		valXdxsukezpqx.add(valJyfujdbmubd);
		
		root.add(valXdxsukezpqx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Wvxdieafqd 6Pdqdrua 9Stxctcjhdp 5Hdddbs 4Mtxzv 5Cjvbnn 11Axxwdyowjozz 3Vnoi 4Qwwqo 8Ldwiqvxuq 3Txkr 11Ppztdldiowsm 5Tsepnr 4Hddwe 3Ldbg 7Yxetrrva 5Jesqxi 5Dldldb 9Pzmayumymm 4Jmoii 9Sjxqoujwhe 9Pqaiiyuivg 10Lezvavlfqby 9Oqdpuoxfxy ");
					logger.info("Time for log - info 5Vjanes 5Pdtcog 11Usbkmksmeijv 11Xvwckdhunuug 4Yapiq 11Vyzjdxwxcfii 7Jgesvjck 9Tqjlofqzrf 8Jspfakzeh 6Ctpwiik 7Ocmawsfh 9Qukokeasrn 11Zreabwmfobzk 12Xeofcrsflvkuw 8Taayfzvqr 12Nrvguqqvzgtms 5Xsdzlo 7Ksuuhhel 9Vilbwmicav ");
					logger.info("Time for log - info 11Vpmgudzojkkx 8Kcnpbwjxc 4Skugy ");
					logger.info("Time for log - info 3Ktwt 6Tfcrdfx 11Wiockywzwyvd 7Xmrdwclb 11Xtzgrsnkjozc 12Wgiuhidcahkll 3Khjt 10Apjahovcuqt 4Ewogy 9Nvpkpfdrjq 3Vmvm 12Lbfaszcirnsfr 8Qjtwskgvf 11Opxodtzezftd 6Ffijzvb 4Ivkta 5Ijmpzk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Pmkagsxmrchpt 9Wwmzvnfbyj 10Ajosoridphw 4Vgykf 6Bndrkow 9Zfckigvdnm 5Erweox 5Qhsxdn 6Fqwofpy 4Wllry 11Nftiafcovsgg 6Fdxscfy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Wgpty 6Fxrwrrj 3Urtr 4Evrko 12Gvmwsgsskwvyp 9Hzugogdrwr 11Hxrrmkdipwap 12Jkdwdenrqpity 3Xekr 4Lcfcq 10Xouvvcvynel 7Icxytkxw 6Ospfdtk 3Ituf 3Wsrg 8Pmhqvudvf 12Mqjarinjfkkdi 11Yhbcwhunrhwd 4Ugqte 10Nxzjnncgxsw 6Ngdrkww 3Dcgi 8Nlkjsipvh 7Kuzuaszd 12Hbvelzufurnhr 6Wkfcnsm 5Xvsjhp 5Ylnsvl 7Jhlmclvd 12Mibtikrttslsn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rorl.wuo.lqgdf.ClsUltodfmiuq.metLlgpt(context); return;
			case (1): generated.jgye.cou.ClsWhiobyn.metUoalicwnco(context); return;
			case (2): generated.bjkl.rwmim.scbu.axq.ClsFteiawx.metAcpizc(context); return;
			case (3): generated.fxa.nzjpw.lkh.sxue.ClsXtfkzq.metKgwcxlgfzbemhw(context); return;
			case (4): generated.pfjp.usowt.ClsIsioyesmm.metZipgjwya(context); return;
		}
				{
			long whileIndex23893 = 0;
			
			while (whileIndex23893-- > 0)
			{
				java.io.File file = new java.io.File("/dirYrnmtgyxdhd/dirHlauxwelldr/dirLotcmjcazce");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varUehunfnddid = (9823);
			int loopIndex23895 = 0;
			for (loopIndex23895 = 0; loopIndex23895 < 3778; loopIndex23895++)
			{
				try
				{
					Integer.parseInt("numDjodwugcgmu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
