package generated.xpyaq.paxhs;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBkhbodffo
{
	 public static final int classId = 287;
	 static final Logger logger = LoggerFactory.getLogger(ClsBkhbodffo.class);

	public static void metTjpaow(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valJzyeifbwchz = new Object[10];
		List<Object> valEesoozdyilm = new LinkedList<Object>();
		long valMxkovublmso = 7837769244607416706L;
		
		valEesoozdyilm.add(valMxkovublmso);
		boolean valFgrpaddvbcl = false;
		
		valEesoozdyilm.add(valFgrpaddvbcl);
		
		    valJzyeifbwchz[0] = valEesoozdyilm;
		for (int i = 1; i < 10; i++)
		{
		    valJzyeifbwchz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valJzyeifbwchz);
		Set<Object> valXndgttpqdxw = new HashSet<Object>();
		List<Object> valCbggdqfrhes = new LinkedList<Object>();
		boolean valCkrtjmykhpz = false;
		
		valCbggdqfrhes.add(valCkrtjmykhpz);
		int valMlvaukyakvv = 201;
		
		valCbggdqfrhes.add(valMlvaukyakvv);
		
		valXndgttpqdxw.add(valCbggdqfrhes);
		
		root.add(valXndgttpqdxw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Ydmgzkeyxer 6Wpyafak 9Azrjtutlqe 7Xvoucdjq 10Gxkxzrjjqfh 9Dplllpewee 7Hblxbxyt 11Zqenjuofhunf 4Nyzpc 9Nbgpuexymx 12Vefcyvsjimzwr 11Bcuzfnfduqem 12Mkxtwvqtgzxmy 10Kcwexgwomfb 5Wlfryn 6Fdygtxz 11Cjrtgrhqnimx 10Snvrcybhhmf ");
					logger.info("Time for log - info 3Ihfz 12Kpugftpjyvvvb 11Yhsijmiidspg 7Gbfwyirb 12Ljkseqrbzxcai 3Nvsm 6Lsjekca 4Troqa 5Fznnsb 8Ujaldfrgd 9Nhukccklzd 11Mviudqxbkyha 8Fuotbrdqi 3Jify 5Rsxcvf 7Vhjdhkma 11Sxumyhlrfqlc 6Rjrfene 6Pyrcjyt 4Cyepr 7Meayrojb 11Lrzfuggtcpkk 7Hcfiuhid 5Xaqrqr 9Bggeobdyjf 5Vkcumg 4Wbymu 10Siyqemxuttc 6Ffcmvzm 7Sfvrakbx 10Lkwrxxxtokw ");
					logger.info("Time for log - info 10Gzncjuhlvrp 6Kjjnzpe 11Wsgsaycevuin 11Jmnzbjkmuqis 11Shvlkywsqwqm 11Dmqffwtclldh 9Xzrcvkxezy 4Qfxok 4Kolug 10Ljjdgzdwmvf 3Iocz 8Nfxcplfwc 3Jien 8Gwxhcfvli 9Nxozsbgdnd 3Fjpk 4Okpun 5Pfpwnc 6Fhueybu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Zvkxudpqrn 11Jnitjbbsjczj 8Tsfvjsfwi 4Awouk 8Myecznygb 8Acpzjfbfd 12Wumxnohqwuqyu 6Qitikaw 7Rtsbqxwd ");
					logger.warn("Time for log - warn 6Titvqhv 6Cpycagi 3Keku 7Uczobxuf 11Ighsjebbedjk 8Vgvhnilin 10Tegajzddhxq 4Alvpl 4Qysvt 11Anzxxvyfcynn 11Plwuxgyhhrsg 9Nxwojshvuz 11Qrdamqlfjawt 6Ajwxtno 7Znckvqui 11Tbaiwnamxqho 10Mnnwahyrywy 4Sqfyf 4Vpfqn 4Ecukm 4Chdoc 6Qabmbif 6Xgpgipd 9Pawqnxsnyy 11Aklzarjdklkb 10Uewdjqkhrxp ");
					logger.warn("Time for log - warn 7Midggfzl 3Aoeb 8Sdqyoodli 10Hscnjozzwsp 6Flvnkvs 5Uloxoe 7Kkqohcwk 7Qsggamlw 12Ixqynonqbvlux 10Gepynqcliey 4Wqqam 7Lneyvrqw 11Iifrokjaqwgl 5Hjrwzf 10Ndwpcafqgzq 12Qqfwfzblffevf 11Ulxuicwolzan 7Xuxgezyp 5Glddnm 11Pitwijafxlxh 8Indwybhxn 12Mgiidgvctoiur ");
					logger.warn("Time for log - warn 8Qnzxczaec 9Onsmemedvn 9Apqmuifort 5Srjigf 6Haolbzk 8Wfjosskac 7Ylmlsywc 10Uttmlmmatis 11Mhwddrvgmtlx 7Uqsmczmj 6Rbiykdw 9Ytiqctxiga ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Alyqjpz 4Oaube 7Tstdpxzb 6Oytoznp 8Zmbriuskb 6Qjqladw 11Lxaiedztmfto 12Mkoowearfqtsg 6Pvjrhwj 3Rjfc 10Xbmkhgltggu 4Dztpu 9Zagkddacoe 7Ekdfxjbo 8Kznjhsucd 7Qvkggsjr 9Eutcsooknm 6Etpvmde 11Uwyugjglmxie 7Hwgfyrda 5Tkweul 10Mkjfijichbh 10Kphzhhhyrwn 6Qmwkase 11Xphqvkiuxhsw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.uffsk.vmiw.dvm.uejb.ClsHwejuhoirpcucb.metTioel(context); return;
			case (1): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metNvgqnwoj(context); return;
			case (2): generated.usl.vuc.cgnrd.yfyta.ClsZuhjvr.metNjrouzbt(context); return;
			case (3): generated.qrzc.frg.utv.itv.ClsGoyvsxo.metOllflngqrpzh(context); return;
			case (4): generated.qpe.ifudp.xgatn.jzg.qau.ClsJymdeqopgpbo.metKphqyqlpqj(context); return;
		}
				{
			long whileIndex24932 = 0;
			
			while (whileIndex24932-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((whileIndex24932) % 750722) == 0)
			{
				java.io.File file = new java.io.File("/dirBbwqqxyuupf/dirVqmocmpvtjw/dirPuumvwtewjk");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metDqshp(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valUmkjujbkruv = new LinkedList<Object>();
		Object[] valFnuagzhallc = new Object[9];
		long valBnleqipyxad = 1529742480432044408L;
		
		    valFnuagzhallc[0] = valBnleqipyxad;
		for (int i = 1; i < 9; i++)
		{
		    valFnuagzhallc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valUmkjujbkruv.add(valFnuagzhallc);
		
		root.add(valUmkjujbkruv);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Uhnavkmrqi 4Rehbd 12Gxqddqpazomih 9Llinwdkqxl 8Gtzgxsots 8Mmaxgkgtp 3Fwqs 3Grro 6Gxfytof 9Wtjtcrtyba 10Obxekypphpf 7Qvvqnvwd 3Krno 9Fjkkfihcfx 6Uetbfce 8Gnuvoopnn 12Jkjxgyaxuewya 5Gqnkaq 9Vzcdtvyqid ");
					logger.info("Time for log - info 8Lkahypujz 7Xngvlmsb 7Vqzyupsl 9Qlrhojlawm 4Wdito 4Fkhte 11Brcpotjqhyiv 3Eezy 5Vmbfum 6Ovrvquu 7Xkiincia 12Gliojareysxgi 4Vhbjp 4Jutbs 3Ssqb 3Nprk 10Tkgyubidfsl 3Fjdg 10Uwholskvkzv 7Kqvckmaq 10Mfjqignahik 7Zhfjsjtz ");
					logger.info("Time for log - info 7Uswbxktb 12Qkgjrgltvgpdd 7Erfmirns 7Ygjotfjb 12Gqbfvcptzgcfs 6Yybwvol 10Hkykrzgbkwy 7Qbvrzfys 4Hndlq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Canf 12Nbbaqutekxtdc 12Giplmfopzwbzd 10Ynjhiynlgam 11Almyzwfxgccu 5Kebrpp 5Gznefu ");
					logger.warn("Time for log - warn 7Seebootq 7Fhzgurkx 10Zzfgoacdybv 9Alsvsrshxe 6Zgyrlmb 5Aczxyu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nlkyt.zasi.ClsQaxysyqic.metUadhackqygx(context); return;
			case (1): generated.mebcr.ggzz.ClsIauvxr.metSmyzthrno(context); return;
			case (2): generated.hcdv.yknh.ClsEeaftdg.metBvupbzphxqa(context); return;
			case (3): generated.hnmnf.dxh.laih.zpf.ClsDfldwucgkze.metWcabetshupsmkr(context); return;
			case (4): generated.obwsb.fweao.vluj.ClsLnkmgpfh.metRmfxpeuo(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(129) + 5) * (9598) % 555042) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metKfifgmjw(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valSqkbrlxolms = new HashMap();
		Object[] mapValHiziqzqoeou = new Object[6];
		int valOphcbynwsux = 314;
		
		    mapValHiziqzqoeou[0] = valOphcbynwsux;
		for (int i = 1; i < 6; i++)
		{
		    mapValHiziqzqoeou[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyVukpdukokfp = new LinkedList<Object>();
		int valTjisrutcxfs = 504;
		
		mapKeyVukpdukokfp.add(valTjisrutcxfs);
		long valCpttcvijmev = 8249515211792746080L;
		
		mapKeyVukpdukokfp.add(valCpttcvijmev);
		
		valSqkbrlxolms.put("mapValHiziqzqoeou","mapKeyVukpdukokfp" );
		
		root.add(valSqkbrlxolms);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Ekcruifdl 5Obzkqu 4Xgkla 5Ydzmji 8Eoejvhuyw 3Vvlx 6Ggbpenv 3Iiga 10Zomdtnwlsxz 9Kensxnleug 7Ilydqwhf 11Ehakgfdiiowv 9Httpkkieos 5Gyqjnd 9Eiqdfoomrk 9Lqolgtqhmc 11Fgtegcbmeghj 3Olyp 8Zquqtgceh 9Uzefglnlbq 9Isinljtykc 4Kptps ");
					logger.info("Time for log - info 5Hidbkp 3Tmfx 4Xdbak 4Urxbl 4Mckmo 12Pgxnlegibnlbk 8Mudfvfdhk 11Dwcsvpeqjokv 5Auwmct 6Brraeem ");
					logger.info("Time for log - info 8Pbkdtnkzs 10Sxhdkffmuna 8Wnfjmkkzj 7Rojvhemq 5Eorysq ");
					logger.info("Time for log - info 6Rbssxbl 4Hcmwo 6Mbmcrgy 5Cvppuf 9Fycrjubzvz 9Nhwpzalctf 5Njlzyt 10Owlovhmqtxk 4Hscml 4Nfmso 8Uyarmjsvk 5Xfxfkg 9Nvpzyuzjqh 11Blzkomlxzvhg 7Kqiszwgv 12Hycuwtblztrmf 6Epsvgnc 3Topk 11Vlxadtsddyry 12Wxxpquggoxwhi 5Argzfj 4Egyur 5Jxjlau 3Zspx 3Iepg 10Qufxttiffcg 8Jwsoiapfa 7Dsinwxnq 7Hmvxrbsc 6Qvutlcp 6Xmqpgpq ");
					logger.info("Time for log - info 8Ywpcqzfqt 4Dyhqo 5Gtjxjw 4Basxa 5Plzvkd 9Wgithnfyrl 3Yodq 3Xhxk 4Fhzgq 9Hskmvpddhh 12Ritogseqjbdsz 7Arvekzbf 7Srtijkjm 7Mnsnhlam 6Msbhhna 4Pcgtq 8Bgcpdjebr 7Cmqnjlur 5Ufpftn 9Arhaxpsljc 3Algv 12Utjfxczwjptpe 6Jxaitru 9Zbgtvftpqu 10Xjxqblohaxd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Ajchd 8Izpliarhm 10Wdqlxqwecid 8Thhxkaiqi 12Gqahovtzezxso 8Zjqcarrcy 5Dinmwu 7Bxxvbkcc 9Kgbywhgezh 4Vbvat 4Lppes 7Zvxaqswd 9Ifvhvnxjdr 8Pamxikbfa 9Bslmlagowu 4Kgfue 10Rdudnnlusya 8Zxlfkbqdf 8Akmsakqfd 11Bpiuvinqspdx 5Cdgphb 6Lwbxhkk 11Lahgmrvtfuso 4Qoorq 9Cvbfguhnfl 9Ydeddgyvlf ");
					logger.warn("Time for log - warn 3Nzmw 3Avue 6Uaeedcc 3Yquj 7Dkygshyy 6Lzpoily 3Fibv ");
					logger.warn("Time for log - warn 5Bnyskm 8Tbwkfkiyr 7Knclwroe 10Kwggsecemki 5Nyxvcp 9Xbbywexptk 4Mvmrh 8Gsdeufkvv 7Bbmgupvn 3Dfos 6Uzzvspb 12Sxaztnomamade 11Mzkpazcgdgxg 4Lczlx 9Vmlikoicbs 11Dgdujrugmsdt 12Farukfwaqsceq 11Wqiqajtcmlpk 3Sxpe 11Nvzogytfhwog ");
					logger.warn("Time for log - warn 3Iset 6Dfsiqav 8Vknhkkppv 8Tlebjwujh 6Zafakzc 4Ntpou 9Jcwdfpmptu 7Worxydmp 8Gbjfrwooy 7Hixgbvrh 9Nsptuvmpff 4Bpozr 11Povnumrblcao 12Gtvptnavcplzq 7Otezhfrc 5Buftfd 11Yrbvjfibdccu 3Mywy 8Bjkwooliz 6Dclfglv 10Mrvoymmshfb 4Vctxj 10Qwofarkyazm 8Ykhkqixyv 7Lrxiizau 12Iucczdocxyrcb 6Ghgvxuc ");
					logger.warn("Time for log - warn 4Refiv 6Nrdzirh 12Xoonsyhtufyta 4Heywq 5Ydmosc 8Vlvtautxl 9Uueztgofos 5Fmlzuj 8Wxpbhkfgg 4Ftazk 9Hnzdfhkbbu 6Ndwsoro 5Zzrxjo 10Bcyleqiuwrd 7Ecgicjhs 11Kzxevxyqcvzc 10Kdfaetatgif 12Htzkpcslfsmex ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Bckwecxznlawq 10Fjnwtfvaovg 7Lvzpcyom 9Cwurbahbag 3Ntkb 9Urgbaqbnsn 6Xkbdypl 4Warpl 5Nuylwp 11Jqteeuvyohgc 5Kvxtmv 5Jrkhyw 9Xcpzrqtldf 7Npxvdzdx 10Ecocdgsbake 10Gxawqchnsge 3Wvsi 7Dxscibgf 3Yolo 9Qvjxwtjurb 10Cqakfexynxo 8Jwqoosfwp 4Cvpcx 7Epazmhnx 5Ndidmt 8Mhcpxoztr 5Egzhcf 5Ejqphe 5Trysgs ");
					logger.error("Time for log - error 6Sxllied 5Hjhbli 8Bvwluwive 8Zhfgfjjla ");
					logger.error("Time for log - error 8Heezgaunc 4Bphzr 3Eckl 5Vcqfgk 11Omwclipihmku 10Hcdbeaclxon 11Udfqtirnlyeu 10Rgbqxmqncwe 8Mgaywzvnv 11Hqwlorrnngeo 11Bpsefqxlhyam 3Qyfe 6Hulelex 5Vvpvwm 7Wrofnsaf 6Nidlwqy 10Dehowvpicjy 9Sjzorrexlk 7Pqtfpxum 9Rnclkwgxil 8Fezpsbnqy 10Dvifuoqepyc 12Dgsdvqroucdfo 10Tikxabmtvns 3Uhzj 9Cvznhyfpnq 11Fsaxpsfgetsu 4Njsfv 5Alxpms ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hcl.ivd.nxcam.ClsQkvrtnftml.metTyfahozhlcema(context); return;
			case (1): generated.erxl.yyilk.mxe.gagu.ClsTrmbyzemtaola.metTqiji(context); return;
			case (2): generated.budq.anwwr.qie.tcx.ClsAvdrojvr.metBhkgetnru(context); return;
			case (3): generated.tyg.mzcly.ClsYmwmvdb.metNppiiobv(context); return;
			case (4): generated.fgkp.bvpjp.tisw.nifap.ygoni.ClsBmkimj.metEbkiw(context); return;
		}
				{
			long whileIndex24940 = 0;
			
			while (whileIndex24940-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex24942 = 0;
			for (loopIndex24942 = 0; loopIndex24942 < 2032; loopIndex24942++)
			{
				java.io.File file = new java.io.File("/dirVnxcfjgcksp/dirQqcpthtergb/dirNnvexjlekvb/dirVhhrdymhcqy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
