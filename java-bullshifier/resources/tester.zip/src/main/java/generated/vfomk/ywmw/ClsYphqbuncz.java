package generated.vfomk.ywmw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsYphqbuncz
{
	 public static final int classId = 368;
	 static final Logger logger = LoggerFactory.getLogger(ClsYphqbuncz.class);

	public static void metMivehrooaiow(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valRekkpkkxyyw = new HashSet<Object>();
		Set<Object> valYxlwutdxrla = new HashSet<Object>();
		boolean valDlykanjekgc = true;
		
		valYxlwutdxrla.add(valDlykanjekgc);
		long valUsbivpfmouv = -4410607266071767715L;
		
		valYxlwutdxrla.add(valUsbivpfmouv);
		
		valRekkpkkxyyw.add(valYxlwutdxrla);
		Set<Object> valMighcqmhurk = new HashSet<Object>();
		int valFmjoiifwlwx = 303;
		
		valMighcqmhurk.add(valFmjoiifwlwx);
		int valPngeqsdhfxi = 603;
		
		valMighcqmhurk.add(valPngeqsdhfxi);
		
		valRekkpkkxyyw.add(valMighcqmhurk);
		
		root.add(valRekkpkkxyyw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Xfgyxvh 12Gmmxbvghyyikh 7Rgzxhxpc 9Dhgidbjcep 7Datnoghc 6Rojfttw 8Zmxekcdbb 8Gpqkhjgon 9Honlzwizwu 12Xwjbqaplwbumh 9Hsnedbtqax 6Xvkunsl ");
					logger.info("Time for log - info 5Ibpwzt 6Hdctslx 11Unwznrhpsggb 8Ayrkusobk 11Unlbwtihkrjh 3Bqyx 4Rcveb 3Powz 4Xembl 10Sewsgiolmkg 7Npmixnct 10Giikjfdthuh 4Zajhc 7Cvrwejhs 9Zhlpaaeqxh ");
					logger.info("Time for log - info 12Xkzuqeffjobuq 10Votkxtzmxqk 12Hslpslpqqhgau 5Zssvxs 9Otszuxwoqg 10Pjgiixinysc 11Wxkezyogdqsi 7Wftzrmgy 7Efxeuusx 6Ijecdmq 3Hgxc 8Mpevqkeee 7Jjfafxyu 3Yrsl 5Bebljr 12Hwnvpekqzhmvy 8Atqyxzynz 3Npwa 9Jkizjgoyqw 12Hkacqakebbctd 5Svkrtt 3Mzjt 3Tfkc 8Twezlakbz 5Mzdfby 3Jyxb 6Mzfxzxv 5Heuqjr ");
					logger.info("Time for log - info 9Yqqyqfhtyb 10Ivhacpleisg 7Oihdxdee 6Snjqrpm 11Ponrztotflih 10Dihrntcxsxj 5Aglnkm 7Ydtnymxo 3Hufx 10Qhycucsbqbx 12Bsuikjildfkhn 9Gybzaecnrv 8Ygokaclkn 12Qvdmsuartlbao 10Ivtatiagphf 6Mksgmgp 10Pvcavnvyziv 3Yybc 5Epxhzl 5Egwnke 10Imunzgihtht 10Qxpvqfnsztm 8Ehndekrdr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Nqwod 11Yclsqgbhkyye 5Dngvmw 8Dfiblkozm 10Pygnkeffjnz 5Hbpghj 3Wvkj 3Mojg 4Lpzjo 12Htpddvirnajel 11Vrxojhilblhv 7Tlkrcady 7Tdbmnnsy ");
					logger.warn("Time for log - warn 3Uuch 12Acltptsqnnstg 5Npqyty ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Tszzdp 5Sxuipa 12Vvibqaaabtifx 9Hwgfjgoxoh 9Oxmvianmek 3Gyhx 9Dazclqdayj 9Sjhwkcjaki 4Jfqbj 4Dpvbv 3Qobf 6Fjoyode 12Thagrfcrhahvy 3Gdoi 7Zwltzxzz 8Tgnybkwdx 6Rauzqcv 12Rxlqszuquhvzs 3Cgcf 6Eyaamgo 8Ictdwbzel 5Kdsifz ");
					logger.error("Time for log - error 8Mfinsxkyw 4Kbkrg 12Ktcetngffcioi 4Bvuzv 3Eimk 8Ekygxzubl 9Yjndhhtfmn 9Llpjdeseyo 12Jitwbcpeanyev 5Ntdplc 11Mvwpldmemttm 11Lotndafskvej 10Uuemtdfsgfn 5Qlwihn 5Gwgyys 3Oaje 11Ocsbfmdfrmxh 5Hzzpry 4Uicin 8Vriwtpzod 8Ktedziftv 10Nwmctqzkqxv 8Vjkqyowta 3Ruoq ");
					logger.error("Time for log - error 9Fudorcjbhv 5Osvayl 6Njphczc 8Tiwcfivcf 12Qxjwwrsicfhag 9Dprpoqkbge 7Sjrikhbd 10Ggglzjtrtrw 8Gedmgdyid 4Aohls 12Rimmhqemyxufo 4Psobj 11Pjegjyxucuny ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.atxpc.jfvg.vws.iuk.lgvvw.ClsUvitihtfes.metBcorweqltquej(context); return;
			case (1): generated.dvks.jsbpi.ClsXlatniflz.metIhawpoyjsfgfom(context); return;
			case (2): generated.pef.kybz.yzpf.dzs.obqpv.ClsKizvnatyigi.metKzutin(context); return;
			case (3): generated.fkbuh.vawj.ClsXsqsadsvdke.metGrquryhkwyi(context); return;
			case (4): generated.afz.qen.lrlj.ClsTvxlbccvg.metBrsibddpey(context); return;
		}
				{
			long whileIndex26177 = 0;
			
			while (whileIndex26177-- > 0)
			{
				try
				{
					Integer.parseInt("numWbjlcigvvpp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varKmdoxnyucuj = (Config.get().getRandom().nextInt(196) + 1);
		}
	}


	public static void metSxbxspewfilfwt(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[11];
		Set<Object> valXgdlzxqmmfw = new HashSet<Object>();
		List<Object> valRhipsfhdrkp = new LinkedList<Object>();
		String valDwlgbdnwagm = "StrZswiannehdz";
		
		valRhipsfhdrkp.add(valDwlgbdnwagm);
		
		valXgdlzxqmmfw.add(valRhipsfhdrkp);
		Object[] valHyadocewdau = new Object[10];
		int valVynbfzoqaao = 769;
		
		    valHyadocewdau[0] = valVynbfzoqaao;
		for (int i = 1; i < 10; i++)
		{
		    valHyadocewdau[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valXgdlzxqmmfw.add(valHyadocewdau);
		
		    root[0] = valXgdlzxqmmfw;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Jyyabusm 10Ytevxgbufco 11Htqmvxbbfywa 5Gbpvoy 11Hixwdwmdrroq 7Ejwiaaob 4Ddfjs ");
					logger.info("Time for log - info 10Cdopnfotsxq 7Jsbgsbja 9Aybzmapsol 6Gegboci 12Zglzzclomfmuj 5Nveulg 9Szwhkrngwu 6Hemcfmg 9Fyqyiylmss 5Ylvjbp ");
					logger.info("Time for log - info 12Buznoedvezgog 5Wpjfet 3Aoxh 6Vqfvoio 3Vcqi 10Ohrbdphbuvc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Vcrpqtkhtl 12Ujhcsixlprfit 10Lndwhphdmjr 6Dpzbcnx 9Libadesrcd 4Ybnyl 12Ewuxlnngzuyih 3Irus 11Qlsxpjtsscog 3Odts 8Xcvuakjah 11Ilrynsidbihi 5Xofuti 11Xzwkybpcdlnr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Qlfcgxjx 8Texgeubrk 12Rowftcoxhbtqp 5Eznihc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tjsh.wlc.kyb.psqfd.qzhn.ClsOhdwrykfu.metWxyniyvtapvz(context); return;
			case (1): generated.nclk.lhd.awxff.ClsWzypoogjnr.metXvtfzticubdsik(context); return;
			case (2): generated.pgfis.zew.ikgq.ClsEgsupkocifpi.metYobadnrmqm(context); return;
			case (3): generated.drdz.aky.gfc.cjlsi.ndn.ClsMzlwuddsrmx.metTewxhxspn(context); return;
			case (4): generated.ocmm.ezbtm.vxyei.kuseg.ClsUqzgoaq.metGzyab(context); return;
		}
				{
			long varXmlnfwkbnrd = (Config.get().getRandom().nextInt(82) + 6);
		}
	}


	public static void metCyvjbbsbxbyc(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValBawlbdcgsrx = new HashSet<Object>();
		List<Object> valAlrjpkqqvpa = new LinkedList<Object>();
		String valLluycoouusi = "StrPzcvruistqj";
		
		valAlrjpkqqvpa.add(valLluycoouusi);
		
		mapValBawlbdcgsrx.add(valAlrjpkqqvpa);
		
		Map<Object, Object> mapKeyXoxpvhnpcnm = new HashMap();
		List<Object> mapValUkzwakapuoy = new LinkedList<Object>();
		int valUuvthyenwug = 483;
		
		mapValUkzwakapuoy.add(valUuvthyenwug);
		long valTqttyhqdrjf = -2335932221742487618L;
		
		mapValUkzwakapuoy.add(valTqttyhqdrjf);
		
		Object[] mapKeyCfvwqvevaiz = new Object[3];
		boolean valAyxblugtdzs = true;
		
		    mapKeyCfvwqvevaiz[0] = valAyxblugtdzs;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyCfvwqvevaiz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyXoxpvhnpcnm.put("mapValUkzwakapuoy","mapKeyCfvwqvevaiz" );
		Set<Object> mapValRduxzofcilj = new HashSet<Object>();
		String valFfqxcwmwkxs = "StrSvsykmpuwwt";
		
		mapValRduxzofcilj.add(valFfqxcwmwkxs);
		int valCvrnokiaxzm = 475;
		
		mapValRduxzofcilj.add(valCvrnokiaxzm);
		
		Map<Object, Object> mapKeyUdjhqzxwcqo = new HashMap();
		int mapValOyjyrjlmrbc = 886;
		
		int mapKeyLsjbffehkye = 752;
		
		mapKeyUdjhqzxwcqo.put("mapValOyjyrjlmrbc","mapKeyLsjbffehkye" );
		long mapValXgnjdulcang = -5594597572296201243L;
		
		String mapKeyGninaocgucr = "StrVztnvjszxyf";
		
		mapKeyUdjhqzxwcqo.put("mapValXgnjdulcang","mapKeyGninaocgucr" );
		
		mapKeyXoxpvhnpcnm.put("mapValRduxzofcilj","mapKeyUdjhqzxwcqo" );
		
		root.put("mapValBawlbdcgsrx","mapKeyXoxpvhnpcnm" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Qrwclr 8Xfkzknkrt 3Vbyv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Hytan 6Ildqeoe 6Jtzqnen 5Xbhmkw 4Gwsmi 10Uvemwhlvpng 6Pqsfrex 7Vpzqbpfu 11Wetatkomlfjh 5Amiyze 9Yujdyckpgk 11Lfwblmhkpgcd 8Lvecvmigc 8Crwgvfule 9Rnjnzxbhup 6Ncijfdh 3Sykm 12Qgjithyhdawhq 8Emodfibrw 10Ruzjaplpdqz ");
					logger.error("Time for log - error 10Lfiryllcaey 11Kwwjbufidyvp 12Vjcwzdzfqouhq 8Yetstphys 9Doybjxootb 11Eqwhagbkcbcp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kfvy.ymxa.end.hazk.nwqfn.ClsXakhsfoyrlse.metSihzklw(context); return;
			case (1): generated.wcc.zfysf.ClsYrxejsiwymmrbw.metKnfdaxts(context); return;
			case (2): generated.hioa.tbao.juo.tlh.zgppg.ClsZtwfn.metIybrdbhypesv(context); return;
			case (3): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
			case (4): generated.exb.zww.kausx.ClsMnvrore.metDaimgq(context); return;
		}
				{
			if (((120) + (735) % 533984) == 0)
			{
				try
				{
					Integer.parseInt("numJkcgzurwdwz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metIihtxrmdb(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valViaeonalkvq = new HashMap();
		Map<Object, Object> mapValAyluzqtxvaa = new HashMap();
		String mapValFytfdffoxnx = "StrHadefpgsbzg";
		
		long mapKeyPzgsdlylprj = 4904053755477259643L;
		
		mapValAyluzqtxvaa.put("mapValFytfdffoxnx","mapKeyPzgsdlylprj" );
		boolean mapValTypxjfyxixp = true;
		
		String mapKeyAvzwjahfeqd = "StrIkjpgdnbcgf";
		
		mapValAyluzqtxvaa.put("mapValTypxjfyxixp","mapKeyAvzwjahfeqd" );
		
		Map<Object, Object> mapKeyQswxsmendat = new HashMap();
		long mapValEcycgcdtxit = 4713418440756532311L;
		
		int mapKeySvkhrafokpv = 684;
		
		mapKeyQswxsmendat.put("mapValEcycgcdtxit","mapKeySvkhrafokpv" );
		boolean mapValHlnprnvuqom = false;
		
		long mapKeySnrcswgjrre = 5296585200635569221L;
		
		mapKeyQswxsmendat.put("mapValHlnprnvuqom","mapKeySnrcswgjrre" );
		
		valViaeonalkvq.put("mapValAyluzqtxvaa","mapKeyQswxsmendat" );
		Set<Object> mapValMaggnoqkjdz = new HashSet<Object>();
		long valVpgjsllwhix = 5954332119558406748L;
		
		mapValMaggnoqkjdz.add(valVpgjsllwhix);
		boolean valYsjluhbmjvs = false;
		
		mapValMaggnoqkjdz.add(valYsjluhbmjvs);
		
		Object[] mapKeyQpleryeqelx = new Object[4];
		int valZunyobtvevg = 542;
		
		    mapKeyQpleryeqelx[0] = valZunyobtvevg;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyQpleryeqelx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valViaeonalkvq.put("mapValMaggnoqkjdz","mapKeyQpleryeqelx" );
		
		root.add(valViaeonalkvq);
		Object[] valEhcvoqcdvgm = new Object[11];
		Map<Object, Object> valLecdkwittvq = new HashMap();
		long mapValHzhsmuwqkba = -4188857936172915414L;
		
		long mapKeyGeiqsizuult = -1017664496937232577L;
		
		valLecdkwittvq.put("mapValHzhsmuwqkba","mapKeyGeiqsizuult" );
		
		    valEhcvoqcdvgm[0] = valLecdkwittvq;
		for (int i = 1; i < 11; i++)
		{
		    valEhcvoqcdvgm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valEhcvoqcdvgm);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Cjdwarrebfwvd 8Fcnkgvcch 5Nvefpw ");
					logger.info("Time for log - info 5Eggemi 8Kozstnwfv 5Mkegny 4Hjkqy 4Uswty 11Scopwcxtqfsc 4Lzdsr 6Rxabqtp 9Gumdceobnj 9Dfaunlztfg 6Bqonvha 11Afrmzgvcjeyi 6Aeumoac 8Vhabsrogt 12Kpmdjxkmlmwmo 5Tpgfcb 3Wbwj 12Pcqkdqccswbeq 4Atlgr 3Fhat ");
					logger.info("Time for log - info 9Xtddusouzy 10Xzcjrvklwzs 3Hwif 6Icwypkk 3Ohaw ");
					logger.info("Time for log - info 5Belcry 7Vswrimxh 10Gyvetxvfhda 12Qismlbozkiuxz 11Orzjkwkgpeuz 9Gatabuwffd 12Vljkxscyatcpt 8Ubklngpti 8Pubxnlwal 11Ayylissuquiu 10Ptiadnaxrgc 12Tgagpmowrmmev 3Ljzr 6Qmeofbr 12Cndidxlbwvyoq 9Dqheguqvwv 12Waknpfubbmqgq 12Pljkiusjyqenl 12Aosoenpzruejf 7Qwjqfsbe 9Wibttgtdid 9Iqgxmwedht 4Xpbvv 10Xzfooxsdtej 11Pdydzhbznzat 9Dwzhutoeek 10Mldsedzgwpg 3Krmy 7Hrbfwsus 12Wzajvnflmbthn ");
					logger.info("Time for log - info 3Umra 11Nxljaxqvbcty 7Qlckwzls ");
					logger.info("Time for log - info 9Kwecgpfpyu 6Bkthxgd 4Uusxh 4Ptxxa 9Whfyiwuvqq 5Snekge 12Fefkslvqzvrgv 12Gmqdlfdodxehg 4Hjlve 12Dmtszmjgbpgql 5Dqnopn 12Zybtcizpsyipb 5Cfhnlr 5Jfhtcg 12Lxqsxjvyqqjqy 4Mdgyl 12Jadctvcqhlkyl 8Cwblxdhnt 5Namadp 9Bucrvqzjoh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Bleqsahlsdciv 11Pjqpemnqdvmk 9Jatswhqeia 6Jvzocxb 11Yxbodszzymdg 12Tlgtcncbpndbi 10Ykscffttxck 11Eynkpdonybrk 8Qmmxavolh 7Nxtyiejd 5Yigpta 5Ogatjp 8Lfwczxbmf 3Jdnl ");
					logger.warn("Time for log - warn 8Xsjdhannv 11Pjvbwujkdsau 12Xfybdhutydjzw 5Wcrjzt 4Nbzrf 7Tdikcpal 11Evebvaaoaubd 8Oksnyzzch 9Wgmhapfiop ");
					logger.warn("Time for log - warn 12Mkhmtsqzdacky 3Pdmu 9Corqkzakyh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Xbzhk 10Plfqctofnwo 3Reoh 5Mnzrax 3Amdv 6Hzydelx 4Ldhrz 8Hnwvuaymp 12Tlmzicoxahcvy 9Jnoofxeluc 11Ompdletgsawj 7Jgwsqwmk 8Hfjayoeyt 7Mrhkotvq 7Yjrqqasj 11Yszmerpqjkte 3Mbcq 12Zupdrelhuyxdk 4Myldu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.oucap.zcbrm.jbhm.yte.ClsEpzgpbjqjhr.metTekko(context); return;
			case (1): generated.kdu.bhxiw.zym.ClsZlzcdqn.metSgooce(context); return;
			case (2): generated.yewpq.dap.itdt.ClsOhnihvc.metChdkgthjqykk(context); return;
			case (3): generated.rjuw.mmbua.ClsRawvqxmhewbl.metOsciin(context); return;
			case (4): generated.zfv.ypwo.wuncq.ClsFveqnpanl.metApyyqiuohqp(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((9229) * (7751) % 430384) == 0)
			{
				java.io.File file = new java.io.File("/dirZreekrnmtcx/dirJkaxjontdfb/dirSouqngegtzd/dirQlsghmjssva/dirSydoqdbinam/dirPywfzztzlhb/dirEztgfaudhrx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(167) + 2) % 809746) == 0)
			{
				try
				{
					Integer.parseInt("numQhklsvgblpz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex26190 = 0;
			for (loopIndex26190 = 0; loopIndex26190 < 9362; loopIndex26190++)
			{
				java.io.File file = new java.io.File("/dirAdwfsgxwxrd/dirEeulejxtjdw/dirMvhwafvmrhq/dirIibkbvvomas/dirCpoujjyjyoe/dirAhwbriiqbkv/dirMceipzjrbuc/dirEcwsgxskxer/dirLfidwiwzkor");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
