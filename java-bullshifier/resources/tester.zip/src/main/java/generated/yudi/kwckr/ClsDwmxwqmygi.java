package generated.yudi.kwckr;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDwmxwqmygi
{
	 public static final int classId = 371;
	 static final Logger logger = LoggerFactory.getLogger(ClsDwmxwqmygi.class);

	public static void metXdsnobzzxuxw(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valPukrrdjuppi = new HashSet<Object>();
		Set<Object> valRjrzgpqhajb = new HashSet<Object>();
		boolean valXftgybtmleb = false;
		
		valRjrzgpqhajb.add(valXftgybtmleb);
		
		valPukrrdjuppi.add(valRjrzgpqhajb);
		
		root.add(valPukrrdjuppi);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Wdshbbthyp 12Zifeowxufrpre 4Tndgn 10Fbiorcwgvyf 8Hvhpakmsv 7Pqatcieu 9Qctadkfaac 6Dyxlyge 4Rgxsw 12Rczsvjreoadvi 12Avsexmigzgcuc ");
					logger.info("Time for log - info 10Ntsjaitobdn 10Yuqyndwqnmh 8Rkmwkgsjc 6Lifmxoj 7Vjdtugke 10Ynbeqpbzyfn 7Mmptulky 10Doonakufbyv 10Sttywjovxnt 11Uojfctiielwd 8Jqxvetdee 6Rtcrsww 9Bwevnmehpg 6Umcnpgz 4Mynov 5Bbpmws 12Rdewxddxqhrhq 5Hskpbo 10Istgqnzfkdn ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Bekqfdypm 4Judke 5Dvfgzd 11Wagpqiarfdvc 12Appbhafdjkkjz 12Lldvuytkaqdqt 7Sjpdviap 9Axlamtnfzd 4Eekez 3Mvnz 12Tjhyeethcsuoc 9Gjjkhbgkxj 10Wsplmipruru 5Nxztmb 4Rfttk 8Dzqziwjrf 6Letiybt 4Bkvjn 4Zgriw 11Vpykjvrxvkhu 12Qzlhpoddvufth ");
					logger.warn("Time for log - warn 12Prkrieaktbmuf 11Lmsnajggglyy 12Ztjjnjpfmiuip 7Jemzeuab 8Qoyhzxdwx 10Dtslmfloexy 5Wrgqlf 12Llacvyfervrng 11Kkvlckqrwooq 8Uvwwvwxkq 8Agvswavgc 9Nruxqhecbp 12Xmvhyhzxuvctg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Wtqmbmriau 3Dspv 3Wrvp 10Sjaphfczyyr 4Tafil 5Mbebml 5Jdywrm 12Nfqqlomcoaibx 6Kazwehn 4Vubpm 9Rpcngflewh 11Iqzeaizwvomp 3Fvcg 10Fbrkxlooxjt 8Ksfousylh 4Rowkd 12Whxprmqkwstsv 3Rvzu 12Qwblukasvymtl 6Sapxwnk 10Seedxrabfcj ");
					logger.error("Time for log - error 11Snleitmppkmx 8Jeuspllyn 6Mrvzjmr 8Ayniwywif 12Uxcxbirdsztuz 9Mvgonnwcyy 10Rgghzlszhwo 4Cmmrn 10Kpkrnrwwsut 3Leqs 9Vwwtoyhzdf 12Vjcjpwobjsrpp 8Pysrkhqhf 10Hzhellnpxfg 12Cokyinkmyzykv 10Toizpyudegc 12Erjtgtogugvpj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gmrwo.oumy.sahgj.zbppw.vqlx.ClsDexipe.metElwawj(context); return;
			case (1): generated.bxw.hza.cjj.bpzns.qzgt.ClsQbxnaxsj.metMcvovzzcwbpnsh(context); return;
			case (2): generated.bad.yds.jib.otl.ClsBzgol.metOnfznlwhtrhjye(context); return;
			case (3): generated.ukp.wkgj.kys.bbj.whcvs.ClsShqgniemg.metRrbombfiz(context); return;
			case (4): generated.ojyuy.hdvu.yij.nuf.ClsJtdiu.metUymohzkoe(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(110) + 3) + (Config.get().getRandom().nextInt(698) + 7) % 257435) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(803) + 2) % 116696) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirFbvqobkfmwq/dirGxpkaijtmyt");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metIhnyn(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valJkwrxfhffyo = new Object[3];
		Set<Object> valGsjfjigauye = new HashSet<Object>();
		boolean valRtifumyvxzu = false;
		
		valGsjfjigauye.add(valRtifumyvxzu);
		String valTmyopxgmaio = "StrDelnzbsltuh";
		
		valGsjfjigauye.add(valTmyopxgmaio);
		
		    valJkwrxfhffyo[0] = valGsjfjigauye;
		for (int i = 1; i < 3; i++)
		{
		    valJkwrxfhffyo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valJkwrxfhffyo);
		Object[] valJqzlljkdsqs = new Object[7];
		List<Object> valAsxnfxkfkzh = new LinkedList<Object>();
		String valJdjeemnwxgl = "StrQvfzqonptee";
		
		valAsxnfxkfkzh.add(valJdjeemnwxgl);
		
		    valJqzlljkdsqs[0] = valAsxnfxkfkzh;
		for (int i = 1; i < 7; i++)
		{
		    valJqzlljkdsqs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valJqzlljkdsqs);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Jnpuzgqrr 5Btvqav 8Vjficfbyn 12Qktugfcztwfgy 8Irmjdrdct 5Fdadda 6Tpcxbla 9Xcdsbenlpe 5Ukvpad 8Lyyeptovw 11Vjvovewuoeuh 6Vorfajb 10Feokfrnsivu 12Wbenuvtblbwsp 4Jfgeu 12Pscesnpewpjhe 10Mxlcuywdszg 4Btubp 12Yvhfrtzwkewea ");
					logger.info("Time for log - info 6Bpmehnq 4Royhf 3Plej 6Mtaynsw 10Tqwgkistcas 6Hjyffgc 10Ogotpjcomkx 10Qozhohnmiax 6Wrqgidy 6Cgmycga 4Ljonr 11Wdvibbesvnxf 9Yvnbmoyaxe 12Lzyntsfumgaji 8Ivomplniw 6Dirarne 5Ampmhs 11Ymgkvvacorkr 8Izapypcer 11Ghylflfoxkib 10Osyatakflvw 9Wvuezdpsto 5Awpiri 4Jlwjg 8Uyhsyhdwn 8Jyojxckhf 3Nleo 11Eserteuindkx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Ijbrivw 5Egrets 6Iulzqyd 7Nacpfbcp 9Slsfouetqp 6Fgxuuhq 8Rzbhbsuqw 4Umyot 11Zmmnwpqsxfxu 6Wbgczkv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Ehvja 6Dxyqiak 3Lzzb 10Yfxvaomvqrz 11Btxxkvcsqmmr 4Ohtgt 12Vcevckfywtpsz 10Wobqalkhxey 3Utst 8Xfmvviavd 11Rrwsnixbsydz 11Pagxnswzzfeb 8Ufycdnhhg 10Vqekxripsvy 10Iohwqhxsaix 10Opcmisdvfuj 12Viykyfemhpauw 5Qubrwu 5Xcebxa 3Eoiy 5Aswuny 11Jlmrzldipnoo 9Gxxpkqdtku 3Pnye 7Usoxnrtz 4Qantr 3Dadq ");
					logger.error("Time for log - error 3Vwdx 6Tmmcduq 4Nhoyg 5Imfyqe 4Rjglu 4Fvdhd 8Ebepjlylo 7Iwsphhgy 11Gprymkvugyvz 12Nwowohnmvueef 8Byrkiihwl 4Fjcin 4Eviok 4Vvxfa ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yfwg.zmane.bbbip.wqsm.tbdz.ClsSzekb.metZjimsrct(context); return;
			case (1): generated.rxif.wckg.ncsqv.pmlox.ClsRkhayrnqgfzod.metOqicwb(context); return;
			case (2): generated.vrd.lunc.tgbks.iqcsu.cjgc.ClsExboagkfroi.metYhrfp(context); return;
			case (3): generated.tau.glw.atmw.ClsCedrqvgmxtsj.metVvgmrshtcqbse(context); return;
			case (4): generated.vfomk.ywmw.ClsYphqbuncz.metIihtxrmdb(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirAyevojsedcs/dirQyimyqnzgbv/dirNiylsipqasv/dirPxdgjdeveqx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex26256)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirHsccuowafyw/dirGdhmivzegnf/dirPekeorhsesa/dirOjylwbfweyy/dirCdbiuhgknxk");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex26254 = 0;
			for (loopIndex26254 = 0; loopIndex26254 < 56; loopIndex26254++)
			{
				try
				{
					Integer.parseInt("numPefcdkzsqhy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metNppyrlnbpx(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[4];
		Set<Object> valBwctoxnsknl = new HashSet<Object>();
		Map<Object, Object> valGopjqeekztb = new HashMap();
		String mapValHtcvjvszgdt = "StrXeutmmbejny";
		
		long mapKeyArhstuftapc = 7782213778471001371L;
		
		valGopjqeekztb.put("mapValHtcvjvszgdt","mapKeyArhstuftapc" );
		
		valBwctoxnsknl.add(valGopjqeekztb);
		Object[] valZqxjwanaevx = new Object[7];
		boolean valEiaoxvypmpb = true;
		
		    valZqxjwanaevx[0] = valEiaoxvypmpb;
		for (int i = 1; i < 7; i++)
		{
		    valZqxjwanaevx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valBwctoxnsknl.add(valZqxjwanaevx);
		
		    root[0] = valBwctoxnsknl;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Uikfmmqshmga 9Yjfklkvgny 12Cdkftxrspsijg 6Zrrbueu 9Zxtsvdyvws 3Icov 3Uqyn 4Wnkmp 12Ajjfqvxustbdg 9Bglghmghej 9Affzwzbsmg 10Spqucvipekp 11Ylqrsblmkxiz ");
					logger.info("Time for log - info 10Aufgpaycdle 10Rxeyvcnfhai 11Dlqmqfzfqaoj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Emmsvpfafc 3Oxsl 6Fieovpb 4Fjibi 9Qmakvukirm ");
					logger.warn("Time for log - warn 7Tyrqsqze 12Nswknusxalnox 9Msuzgywkni 10Rrvzinfnvag 10Icmsujnylmw 11Kxafrrvtkzum 8Jcofjzpwb ");
					logger.warn("Time for log - warn 6Uvhnfju 12Vcyntiximceie 11Hhkgiauxjnsw 9Lbokjmbjby 4Szhzt 3Buba 6Nuntiib 9Qzotkfuims 7Birhdqhl 4Woeum 8Loemvdnqe 9Lqfyabdieu 5Zrsiym 6Cgkvyoo 9Cfutepakni 8Bsjzqzwsg 5Sbwmyh 8Gwexvqaok 11Kuittuqojrmp 11Jqascaerpvak 7Iujlctnr 11Luayklsjcznw 6Ojtudog 7Ogzwrkgd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Fjlygzkd 12Onwdihtpsvvec 6Fkhithv 11Fnvmvadlwsoj 12Qwtxdfzamhhvi 9Dhrsertxxp 5Dhphpc 11Yuocymzzuoxw 7Ndckyksd 12Jgjymmwvmuhhk 10Mfijpnadkwb 12Yymmtwhwaxqzz 12Kcgefrxtftutq 6Iravbfy ");
					logger.error("Time for log - error 8Kbwhrfjqo 9Wmyeqbizgc 10Yvjnnidqsny 6Bpfluqu 5Ickfid 8Yugfakjud 7Gxxuymgb 10Ufywkfgedqc 9Aqgacflrpa 8Iopjygsip 12Dwvawieqfepdg 6Ucqmxsj 12Cductshunzowe 5Rizcer 7Czvollqt 11Vscidpgwrdfh 8Mwiurbuzg 7Dhqufgll 12Xuvgfemswophn 9Gdieatzaym 4Aelkh 4Nszfx 9Yfsyaabaii 8Zxcdyegdb 9Mashcuioqy 8Fcyaefynu 9Zpwhtclmfh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.godw.hlszo.mtqbt.shx.tbgwd.ClsMygvrmsqnwlsdw.metAxjcfalqbdxrb(context); return;
			case (1): generated.yvbmb.hnmr.uqxw.ClsYomdrwntzuxawb.metPhyaooa(context); return;
			case (2): generated.tau.glw.atmw.ClsCedrqvgmxtsj.metRecbeoqusgpv(context); return;
			case (3): generated.joeal.ovr.nvb.kqkl.kegr.ClsNehitk.metGvuga(context); return;
			case (4): generated.xpyaq.paxhs.ClsBkhbodffo.metTjpaow(context); return;
		}
				{
			int loopIndex26261 = 0;
			for (loopIndex26261 = 0; loopIndex26261 < 9054; loopIndex26261++)
			{
				try
				{
					Integer.parseInt("numCugimjagaix");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirBprxxawrczb/dirPpounpqljkb/dirIhfscixzzxx/dirAegdkozwgmp/dirVfejsxnbnsi/dirCgxjfisgdcf/dirLulmfmsaran");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirUloygdjshrs/dirOgemdbqjwtp/dirOtdcnxhgsaq/dirFuzuhnnafxy/dirTkqltzdfkor/dirRdpqcrwjcfp/dirFwtwkcrxsxz/dirEtdmqlrzier");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metPjfjihqsvyfx(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValLmozfetqvsx = new HashMap();
		Map<Object, Object> mapValZygtlisxuno = new HashMap();
		long mapValGtckjyzgvpo = -7588250618072095033L;
		
		String mapKeyHpazjromlwy = "StrHklzezutqld";
		
		mapValZygtlisxuno.put("mapValGtckjyzgvpo","mapKeyHpazjromlwy" );
		long mapValBmpvjfveqxf = -4972368496247230188L;
		
		boolean mapKeyDowzysixodx = true;
		
		mapValZygtlisxuno.put("mapValBmpvjfveqxf","mapKeyDowzysixodx" );
		
		List<Object> mapKeyHcnawtvmmck = new LinkedList<Object>();
		int valMuaevvcyuve = 202;
		
		mapKeyHcnawtvmmck.add(valMuaevvcyuve);
		long valSofjorfxgsg = -840518570881054407L;
		
		mapKeyHcnawtvmmck.add(valSofjorfxgsg);
		
		mapValLmozfetqvsx.put("mapValZygtlisxuno","mapKeyHcnawtvmmck" );
		Set<Object> mapValHpmbcpkfunk = new HashSet<Object>();
		String valEcfvlrgnjnu = "StrPcfmignyfif";
		
		mapValHpmbcpkfunk.add(valEcfvlrgnjnu);
		
		Object[] mapKeySccedaxezrq = new Object[8];
		int valOzvniqaohvm = 974;
		
		    mapKeySccedaxezrq[0] = valOzvniqaohvm;
		for (int i = 1; i < 8; i++)
		{
		    mapKeySccedaxezrq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValLmozfetqvsx.put("mapValHpmbcpkfunk","mapKeySccedaxezrq" );
		
		Set<Object> mapKeyXnkzmtbsyjn = new HashSet<Object>();
		Set<Object> valMcjkmnbukfg = new HashSet<Object>();
		boolean valLuqlfapiitr = true;
		
		valMcjkmnbukfg.add(valLuqlfapiitr);
		long valXlboylhlzyh = -506900901889128492L;
		
		valMcjkmnbukfg.add(valXlboylhlzyh);
		
		mapKeyXnkzmtbsyjn.add(valMcjkmnbukfg);
		Map<Object, Object> valHsyzggxcxzd = new HashMap();
		long mapValFwrfppjlgbm = 2950806456018433909L;
		
		int mapKeyFajdcrbjapj = 166;
		
		valHsyzggxcxzd.put("mapValFwrfppjlgbm","mapKeyFajdcrbjapj" );
		long mapValHlaqrfewctt = -7169294441072063897L;
		
		long mapKeyNqwntkaheim = 8518861943882706643L;
		
		valHsyzggxcxzd.put("mapValHlaqrfewctt","mapKeyNqwntkaheim" );
		
		mapKeyXnkzmtbsyjn.add(valHsyzggxcxzd);
		
		root.put("mapValLmozfetqvsx","mapKeyXnkzmtbsyjn" );
		Set<Object> mapValVagtwcjmpte = new HashSet<Object>();
		List<Object> valYrxrodbiczc = new LinkedList<Object>();
		boolean valWofryuyijlp = false;
		
		valYrxrodbiczc.add(valWofryuyijlp);
		boolean valXomvazqmigo = true;
		
		valYrxrodbiczc.add(valXomvazqmigo);
		
		mapValVagtwcjmpte.add(valYrxrodbiczc);
		
		Set<Object> mapKeyYgtjuykxnay = new HashSet<Object>();
		Map<Object, Object> valIejxzyvqtvr = new HashMap();
		int mapValCnkjleaaofi = 898;
		
		int mapKeyTcieljbezvz = 643;
		
		valIejxzyvqtvr.put("mapValCnkjleaaofi","mapKeyTcieljbezvz" );
		
		mapKeyYgtjuykxnay.add(valIejxzyvqtvr);
		Set<Object> valBpnlhirepbu = new HashSet<Object>();
		boolean valNbyquisbugc = true;
		
		valBpnlhirepbu.add(valNbyquisbugc);
		
		mapKeyYgtjuykxnay.add(valBpnlhirepbu);
		
		root.put("mapValVagtwcjmpte","mapKeyYgtjuykxnay" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Tkpcsbzaldoi 6Dbwkrad 11Vmdpwrpqfish 3Qmlr 7Nyigtgdp 11Xvjidzhisbmr 5Vfsslq 8Qkclebolk 4Rghbn 8Lqefmmzmu 11Gvudjmzaxkfb 12Qgdkbcfqjplwt 11Bqgxraufvjjg 3Raif 7Kvqpejzw 3Rtua 8Knxbsemqi 6Ktrxyjz 11Hwjstakwfboa 5Fshhga 7Krkhpzer 12Rbnqpwxjaiabe 11Jahqcwuklvvx 6Iqnzyrj 9Vnywmsbuin 5Sugcgd 8Qkmjewxbq ");
					logger.info("Time for log - info 9Yefliapgal 11Qpkbmwimgpye 12Jaaxuxwklheui 10Ygudeiuycoo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Tgxkdnvanlsq 8Uhuzgnzdt 3Jopf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Bqjggckmu 4Rujhn 5Lxwddh 6Pumwrgr 3Bewk 11Efjuxhnsfvqo 5Uftkby ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.awuu.yuf.ClsCvioceqcbkiz.metCmrtwohtptwpox(context); return;
			case (1): generated.qer.bwl.ClsCbeyhqqy.metFgzkaoqzw(context); return;
			case (2): generated.hdrlt.jxdm.bjqs.pupxs.ClsZoyaigxdyb.metCofpcgjfkt(context); return;
			case (3): generated.gasq.isr.fpndy.jhzr.ClsNxizwkdumgga.metFwsdurntbm(context); return;
			case (4): generated.cwxj.lmfzj.egfdm.ClsTwbdwdairow.metOcaxrekk(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numMgpllgyxcsj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numLsbnyszjioy");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numCvehpdsjzuq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex26275)
			{
			}
			
			if (((1345) % 533035) == 0)
			{
				try
				{
					Integer.parseInt("numSwtvtdhnobx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(472) + 3) - (Config.get().getRandom().nextInt(838) + 4) % 987279) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numAmcymskyfnr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
