package generated.rprz.twb.ozdl;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsMnahuieydv
{
	 public static final int classId = 255;
	 static final Logger logger = LoggerFactory.getLogger(ClsMnahuieydv.class);

	public static void metLsuejvaasjahy(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValBzfajsibieu = new HashSet<Object>();
		Object[] valOfmvodovxpu = new Object[10];
		String valAqdwyygjxsp = "StrWlwwfwvsixt";
		
		    valOfmvodovxpu[0] = valAqdwyygjxsp;
		for (int i = 1; i < 10; i++)
		{
		    valOfmvodovxpu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValBzfajsibieu.add(valOfmvodovxpu);
		Set<Object> valHgjivoghsfe = new HashSet<Object>();
		String valUydewdyghkk = "StrBxjdftkjxbb";
		
		valHgjivoghsfe.add(valUydewdyghkk);
		String valNozjjdcimiv = "StrFwsmrybjazf";
		
		valHgjivoghsfe.add(valNozjjdcimiv);
		
		mapValBzfajsibieu.add(valHgjivoghsfe);
		
		Object[] mapKeyHymlylczqic = new Object[4];
		Object[] valGkfmsksftiv = new Object[4];
		long valTfanghhnuqx = 5449366700447208916L;
		
		    valGkfmsksftiv[0] = valTfanghhnuqx;
		for (int i = 1; i < 4; i++)
		{
		    valGkfmsksftiv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    mapKeyHymlylczqic[0] = valGkfmsksftiv;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyHymlylczqic[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValBzfajsibieu","mapKeyHymlylczqic" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Ueohqeppzkdin 7Ghkaanwj 4Lphtp 5Ogggop 10Hflpvnbwttq 9Rnztrzfzti 11Ppgsdsfzwmzb 6Gisugrf 6Jxwsfkz 12Nfahfsspvtxjs 4Vwjub 6Lmyxcws 10Sgjsyfigzew 9Zmxhrqkeik 9Tulxklxobz 6Ruuyprh 9Ynzrybmcov 9Wkzqxwdgjm 6Cidragb 6Yszycjn 11Gzlfgrytbuas 5Wrndej 8Uupnkkvic 12Zdocgyapkghjz 8Ktuajbacq 8Sfdqmlcva 10Bvfmbsnnuix ");
					logger.info("Time for log - info 9Bqixkugxij 8Wwnvhjape 5Jimkxk 6Lniqvop 12Brfekcnlkucmh 12Xmwvwlulgltke 5Vbbfyh 4Cpcvx 9Noxcgfilkw 6Xyuezez 11Qmmgrwdflrgq 7Xwvtwdil 3Hekx 5Duwmst 5Ggfspf 8Vrppjlagx 9Qvjouiraeq ");
					logger.info("Time for log - info 4Sscvu 3Fjqd 8Hrsrciaad 6Mnptlgj 6Udaxjmy 5Cjypvp 5Kydoyl 3Zffl 3Xsrq 7Jyftpwhw 8Omxzfwnhu 9Nivibxptdf 10Zvavlhtoxft 3Hkac 4Btlvs 11Hbmklxrwargv 7Wcbcvona 12Uheklfvofystf 8Ylpumvcuu 12Tycjqdxuirbin 7Wlfbbeta 5Xhxnov 9Olqwwdumcy 8Tkzykjlao 3Ucuz 8Lypchpgsy 5Hntbpc 5Qtxaqj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Mmyygx 4Ecwee 12Mvsdgnekjtvow 12Jvmgedqinwpbr 9Lgoedenqth 6Xhdeuai 10Owvzasxvzdt 3Oxlr 11Xtqxosizpeas 5Cangon 9Oryyknixos 10Pxjbedrfjbh 8Vpgqbhkek 3Eacl 6Slwjnnk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.coml.jighl.ntkq.ClsXltkjv.metPzsdf(context); return;
			case (1): generated.ythhn.vxvz.yizb.ClsLckdkkeapmss.metUtevjjtyd(context); return;
			case (2): generated.gasq.isr.fpndy.jhzr.ClsNxizwkdumgga.metEyznktcptuql(context); return;
			case (3): generated.bftm.jkb.lcr.ctpvk.ClsYfbhukzct.metRdbrizfs(context); return;
			case (4): generated.vrd.lunc.tgbks.iqcsu.cjgc.ClsExboagkfroi.metYhrfp(context); return;
		}
				{
			long whileIndex24442 = 0;
			
			while (whileIndex24442-- > 0)
			{
				try
				{
					Integer.parseInt("numYvrjnkxubhk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((62) % 956908) == 0)
			{
				java.io.File file = new java.io.File("/dirUnurieerzov/dirZtpnoydczyn/dirPaprukrxoji/dirMezewujysff/dirBhlercurydw/dirTykklsduwdw/dirVivrafgutnc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varJrphqyywwck = (Config.get().getRandom().nextInt(272) + 9);
		}
	}

}
