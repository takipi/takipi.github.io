package generated.amxo.ekvdv;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsShqqngjhvyrxx
{
	 public static final int classId = 39;
	 static final Logger logger = LoggerFactory.getLogger(ClsShqqngjhvyrxx.class);

	public static void metFyiihinzb(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valBsnyzdeqbjb = new LinkedList<Object>();
		List<Object> valBpzoegquuyn = new LinkedList<Object>();
		long valNduklukfepp = -5789805777637860361L;
		
		valBpzoegquuyn.add(valNduklukfepp);
		
		valBsnyzdeqbjb.add(valBpzoegquuyn);
		Set<Object> valPrmcqoaobzq = new HashSet<Object>();
		boolean valDyuggdfsoge = false;
		
		valPrmcqoaobzq.add(valDyuggdfsoge);
		
		valBsnyzdeqbjb.add(valPrmcqoaobzq);
		
		root.add(valBsnyzdeqbjb);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Beckibys 5Cfnthg 7Gtjwsfmt 10Kyzjflsfukr 7Kelzchfn 7Vavjfage 7Qoihzmrv 5Wiqmgn 6Qiwziuq 3Bbjp 11Nkyjphrzdoii 12Aaajyxijwjkdj 11Dbhlvjflutvs 8Zgsejhqub ");
					logger.info("Time for log - info 5Hkcrmn 5Uhiuvm 3Mioe 6Nemzgpy 6Lzifgeg 5Wigmzi 10Iicycqkmmah 12Hgapbebdlbiel 8Fucbmgpoo 9Baulahuspg 12Yrwrxkcimerhe 8Nkrhksrxl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Axoxabgyqxrf 12Dmbwqkmvpinst 7Jfdnvkow 6Wjkwdex 6Tpsfork 10Qoudcewwhty 6Cnmegis 5Hafmov 10Cinvxqwjjhw 8Tdsjklmqr 8Elkskexgh 4Efoqp 6Exhkgnt 5Uvwypo 8Fkqnryqaj 12Atzrufrkxrmcs 9Ujwtovsbpo 8Xymttwlij 12Lqmeuplrgbtio 3Dadn 4Tqnkn 10Lhroyugcfds ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hzldn.tyqka.jujr.chcpl.ClsNxkmsnjozqsvm.metOzhtrhcipg(context); return;
			case (1): generated.juea.qhm.ClsOhhvy.metHndknqq(context); return;
			case (2): generated.vere.yue.xag.ClsLhubirlwqfrd.metNbhkew(context); return;
			case (3): generated.vqli.xqs.ist.rcg.ClsUlfrrjkk.metUracnapyxnrd(context); return;
			case (4): generated.vyac.iqbj.guc.ClsYpwwsvx.metIrcfei(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirBaoircemzeu/dirRldrzddythn/dirWalpthogpyc/dirOtwmhzjhtdw/dirXedqvzqlnbi/dirWnoaujvorxm/dirEjqnvphgotu/dirWgbycapqrbv/dirBvtqfsmsjin");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex2706 = 0;
			for (loopIndex2706 = 0; loopIndex2706 < 4088; loopIndex2706++)
			{
				java.io.File file = new java.io.File("/dirZvbnwndvexy/dirCujqgqtcfup");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metPxdjzije(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValJbnxzedzoxc = new HashMap();
		Set<Object> mapValIjzkwovdznj = new HashSet<Object>();
		long valPvczqlhsbvl = 718590260772254315L;
		
		mapValIjzkwovdznj.add(valPvczqlhsbvl);
		int valKtozagiblqq = 633;
		
		mapValIjzkwovdznj.add(valKtozagiblqq);
		
		Map<Object, Object> mapKeyMkokhzrzylf = new HashMap();
		long mapValBgtfkfkstsz = -6702131980276270619L;
		
		boolean mapKeyFezingqqhec = true;
		
		mapKeyMkokhzrzylf.put("mapValBgtfkfkstsz","mapKeyFezingqqhec" );
		long mapValPtplcrpacfk = 4468784048560332806L;
		
		boolean mapKeySmkixjvqjsm = false;
		
		mapKeyMkokhzrzylf.put("mapValPtplcrpacfk","mapKeySmkixjvqjsm" );
		
		mapValJbnxzedzoxc.put("mapValIjzkwovdznj","mapKeyMkokhzrzylf" );
		
		Map<Object, Object> mapKeyMtbwbgwpmnf = new HashMap();
		List<Object> mapValPhfrmugfzbs = new LinkedList<Object>();
		String valYfmhidasjwq = "StrPsmwvatsfoh";
		
		mapValPhfrmugfzbs.add(valYfmhidasjwq);
		String valGuupfdxysjj = "StrWrwaaveixjx";
		
		mapValPhfrmugfzbs.add(valGuupfdxysjj);
		
		Object[] mapKeyLmkjqoubaqs = new Object[2];
		long valXoglbouuhhd = 6590986262709830433L;
		
		    mapKeyLmkjqoubaqs[0] = valXoglbouuhhd;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyLmkjqoubaqs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyMtbwbgwpmnf.put("mapValPhfrmugfzbs","mapKeyLmkjqoubaqs" );
		Map<Object, Object> mapValHgziuxnnexo = new HashMap();
		int mapValUqxuoipdbja = 636;
		
		int mapKeyYaipcodojqu = 584;
		
		mapValHgziuxnnexo.put("mapValUqxuoipdbja","mapKeyYaipcodojqu" );
		int mapValKdiwidilbgj = 141;
		
		boolean mapKeyLojmkigtuee = false;
		
		mapValHgziuxnnexo.put("mapValKdiwidilbgj","mapKeyLojmkigtuee" );
		
		Object[] mapKeyLbkqzqvgahz = new Object[5];
		long valQkxjlztkzyy = 4731181176202909612L;
		
		    mapKeyLbkqzqvgahz[0] = valQkxjlztkzyy;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyLbkqzqvgahz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyMtbwbgwpmnf.put("mapValHgziuxnnexo","mapKeyLbkqzqvgahz" );
		
		root.put("mapValJbnxzedzoxc","mapKeyMtbwbgwpmnf" );
		List<Object> mapValPjsfpwybbpo = new LinkedList<Object>();
		Object[] valJqzmqhplpiu = new Object[6];
		int valKphxbukyddp = 226;
		
		    valJqzmqhplpiu[0] = valKphxbukyddp;
		for (int i = 1; i < 6; i++)
		{
		    valJqzmqhplpiu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValPjsfpwybbpo.add(valJqzmqhplpiu);
		
		Object[] mapKeyZaitdcpevhh = new Object[2];
		Map<Object, Object> valHsvafwcgaeb = new HashMap();
		boolean mapValGaowcmxgxtn = false;
		
		long mapKeyKwtfcanbebb = 4129767841480471948L;
		
		valHsvafwcgaeb.put("mapValGaowcmxgxtn","mapKeyKwtfcanbebb" );
		long mapValMwgasjhweig = 7529867531514071791L;
		
		String mapKeyDvzhpcdnwbj = "StrHugeenmdarc";
		
		valHsvafwcgaeb.put("mapValMwgasjhweig","mapKeyDvzhpcdnwbj" );
		
		    mapKeyZaitdcpevhh[0] = valHsvafwcgaeb;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyZaitdcpevhh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValPjsfpwybbpo","mapKeyZaitdcpevhh" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Uwnqikw 3Kkqq 7Bsosylto 12Wrjcirwilvjxo 7Tqmwvruw 8Wabrnaawk 6Vptzcsk 3Pgzx 8Kshgnzbnj 8Lqfnkpycr 7Cyjmvlkf 11Izopcjyqdxza 3Tffn 4Rtear 6Tgusdbb 8Anlfwagpu 8Jcnfyoecp 8Hurajqbpb 12Hyodzmtckxemn 8Vijdlieqv 8Iwjtkrxle 12Wykynyussbqft 11Dnyqzuykwatt 3Ujpd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Vimodbsub 12Ntqbapncjygfc 3Nmpq 8Elaeyqshb 5Mprxfn 7Xtcmofyy 9Ghlxuptymx 11Rsdeunthwojy 11Lrvmlfrrgkqb 7Lntgznfq 9Xlefqbmcyr 5Xdhhnn 4Lcboy 5Oxzppm 7Ofhybfil 5Hhgzgg 11Rmqvgoldlaks 10Zhbkmyqnigq 5Jzgkhl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Tbss 10Rdxgvtirkri 6Iljzmaz 11Cmagmijxxapw ");
					logger.error("Time for log - error 10Ewhlbsypwal 10Hpkefgdkuyz 12Opsuqfiqpwydu 5Uxctwe 3Otnp 5Nhdhjx 7Antpspda ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zmpxh.humct.jpc.zcr.uswj.ClsMmunby.metAhzyvaxwwvb(context); return;
			case (1): generated.fdf.qdha.fywc.gjubl.dtsb.ClsBinezgxhqjfe.metBmbttdastn(context); return;
			case (2): generated.ghyrj.islj.cfyq.ivyv.ClsPvvifymh.metAdqqodkkqe(context); return;
			case (3): generated.kjubh.rgz.earxz.ypjc.pmupv.ClsUctrmkk.metKedywb(context); return;
			case (4): generated.rkfhx.ntcs.qoe.lasd.nzzym.ClsDftkqmvmp.metVsewe(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirOmofzeshvpv/dirGhdsopddjlz/dirCrwoovwttqo/dirGvpvyfuzexo/dirLtvsqoqhmri");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex2719)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirFwlxrbzfrgo/dirHbknojsuexi/dirEfvhghvkbtz/dirJrundukinhx/dirIqfhxdgbkgz/dirTfhnmulmssn/dirXngwcjrdzxv/dirNpftlgfguvm/dirDlpammuyndg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numEezwldnszpx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numXlwvccxwsqj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex2717 = 0;
			for (loopIndex2717 = 0; loopIndex2717 < 1658; loopIndex2717++)
			{
				java.io.File file = new java.io.File("/dirEffbcvisrfb/dirEnyvzoxfhgb/dirXevzxpjiyzm/dirVykdpekxdhs");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
