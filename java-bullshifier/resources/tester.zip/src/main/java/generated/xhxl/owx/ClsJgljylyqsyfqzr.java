package generated.xhxl.owx;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJgljylyqsyfqzr
{
	 public static final int classId = 88;
	 static final Logger logger = LoggerFactory.getLogger(ClsJgljylyqsyfqzr.class);

	public static void metTjguctxwf(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valTennrkxdbqs = new HashMap();
		Object[] mapValKnyiyfgepah = new Object[11];
		int valZshizmtibvx = 687;
		
		    mapValKnyiyfgepah[0] = valZshizmtibvx;
		for (int i = 1; i < 11; i++)
		{
		    mapValKnyiyfgepah[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyWtgrujrwwfp = new Object[3];
		long valZtbejmqylqe = -1058876114366257913L;
		
		    mapKeyWtgrujrwwfp[0] = valZtbejmqylqe;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyWtgrujrwwfp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valTennrkxdbqs.put("mapValKnyiyfgepah","mapKeyWtgrujrwwfp" );
		
		root.add(valTennrkxdbqs);
		Map<Object, Object> valKoomadksktk = new HashMap();
		Set<Object> mapValOaaykqcbabm = new HashSet<Object>();
		String valXxdlwqqanlu = "StrXfpaixyrsqq";
		
		mapValOaaykqcbabm.add(valXxdlwqqanlu);
		
		Set<Object> mapKeyJczsibbadlr = new HashSet<Object>();
		int valZrablleviey = 573;
		
		mapKeyJczsibbadlr.add(valZrablleviey);
		
		valKoomadksktk.put("mapValOaaykqcbabm","mapKeyJczsibbadlr" );
		Map<Object, Object> mapValTtuwwmdqewj = new HashMap();
		long mapValZsjnnfihoct = -1195545437184160164L;
		
		long mapKeyPeuschdjwml = -7223893363732792738L;
		
		mapValTtuwwmdqewj.put("mapValZsjnnfihoct","mapKeyPeuschdjwml" );
		
		List<Object> mapKeyAnntjpvzhoh = new LinkedList<Object>();
		boolean valSozxgfzcyrf = false;
		
		mapKeyAnntjpvzhoh.add(valSozxgfzcyrf);
		String valWxknnddabvc = "StrXfgkjwrvcbt";
		
		mapKeyAnntjpvzhoh.add(valWxknnddabvc);
		
		valKoomadksktk.put("mapValTtuwwmdqewj","mapKeyAnntjpvzhoh" );
		
		root.add(valKoomadksktk);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Fzzxtgvjzrh 9Wgfbwbiisn 3Ncje 6Azylyih 10Ixtdxkgzwty 6Bmzegvf 9Vluocklual 11Jyvixxgapvus 12Ycphycsmilgcj 8Yrdwyoyay 10Htyljuemkfe 12Ifzsrxblxeljl 8Rctvqeiuc 6Ifqkqfv 5Qdevvi ");
					logger.info("Time for log - info 9Fbmdwconuv 10Psodkauhrkr 8Aeihwaijk ");
					logger.info("Time for log - info 10Gyqyerlffvd 3Lixc 5Niomfr 4Iwatb 11Ndjprwacfzmo 11Stmgpgiwxwew 11Evpxinckoean ");
					logger.info("Time for log - info 10Lnihtyxtskf 5Lkbskr 7Tldknrce 4Txpex 7Hegirglx 7Yawulyhy 10Cptstgesmiy 4Imasl 10Zslgxssovfb ");
					logger.info("Time for log - info 10Amhrbzeqqwt 12Dxqxscsujonra 9Fjpxqfloax 9Jllurjvxwn 10Nvzeuuqoyge 7Nsntcapz 5Epcsmh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nclk.lhd.awxff.ClsWzypoogjnr.metPywfi(context); return;
			case (1): generated.rnr.pwsrq.cbi.tat.ClsQsqavl.metUzhol(context); return;
			case (2): generated.wunj.xtrc.rfx.aikz.yopv.ClsTejixmzc.metAhxfdsezzruvtx(context); return;
			case (3): generated.lxrj.lts.csk.iew.ClsCagmzsja.metMsmzpyezeb(context); return;
			case (4): generated.mvh.wsi.ClsXxvtrnameonpg.metVrdqdrupoen(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(88) + 6) % 8358) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metOjlwiipyapt(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valObkgvgeppxs = new Object[6];
		List<Object> valEmzhueautri = new LinkedList<Object>();
		long valVkxyvealkjw = 8863671206885545640L;
		
		valEmzhueautri.add(valVkxyvealkjw);
		int valVwydhqvfvku = 21;
		
		valEmzhueautri.add(valVwydhqvfvku);
		
		    valObkgvgeppxs[0] = valEmzhueautri;
		for (int i = 1; i < 6; i++)
		{
		    valObkgvgeppxs[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valObkgvgeppxs);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Bfwdwsovr 5Gyfrhk 9Oieisbubur 12Ubvzzxosswwae 9Maediwtrft 10Fqlqxsaflpn 3Mbmw 10Yumdseyczbi 12Zkkwkgquijyad 6Qqmalcn 3Fcty 11Yfiisjtpwoeo 7Gzcfuwla 8Bonmhxflj 8Vytzpsmud 12Ndkyqhsjtbnyx 3Cvww 8Ilijtvfvx 3Msci 6Aaxppml 5Okhpds 11Zirtrvxkumwf ");
					logger.info("Time for log - info 12Hlotcypyfiwfg 7Heyiqwfd 9Cjjucumxer 5Sndobm 5Zwxmwi 10Tlmbpdtbsyd 5Fwdiww 6Smsmoni 6Ryktziw 11Wtsqdquicngv 6Jpkpcss 12Tpubafoiavvql 6Jqqkswc 8Edphbcevr 11Nqgzkbatzmfx 8Aklrphbhu 5Khgwdi 9Jgpcdoixyh 5Bkznma 12Qgpadvyrpvpaq 12Ohaoewucchhzp 12Lqerqfvaoefvd ");
					logger.info("Time for log - info 3Dtmo 9Qdpwjhxnwv 6Lzbhmhn 9Yxzvgdrjon 9Eybknwbjqo 9Ebfykbxorl 12Lkhnifhvuodub 9Pkqdfdkkhx 6Brckhyx 4Ruwis 12Hxlxvewrqdtkw 10Ukyrugexlnp 6Zjnbalv 8Wnyzupibr 3Evet 5Zdqeoh 9Cbcmpepjxt 4Tkuic 11Xtihjqscofzb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Klib 3Oeul 4Vzsle 3Weio 8Zzavzsckk 10Jicugwhgkse 8Vstpgizjq 3Gazm 5Evdtkf 5Vkcdtp 12Nqbthkqzkxwyq 8Vrayobwlr 6Rghklmw 3Xpzi 9Vdzujdjikq 11Ovhiufyphlwq 8Qdjoxbnfv 3Bqjl 9Haeufbfxpg 5Yjyibh 3Ofxo 12Ltwwroofmvgyf 11Wmmfctckfvjh 12Wuodruukjkkei 8Qmyhoslgo 3Xwxq ");
					logger.warn("Time for log - warn 8Jnctjmaok 10Atiufhmeaio 7Syiwepty 9Ustpmlnufq 3Hnfi 8Isamsuhfh 7Eyddfxan 12Hqhqooelfznbh 6Ldjljam 4Nwask 3Lfmz 9Vrwtzwofqz 12Daqdlaaewzrhs 5Bzjvyh 9Ibnbmutstj 12Axxegtxkqzrze 11Blychpgpushz 4Hjzkf 7Csxwvxth ");
					logger.warn("Time for log - warn 9Gnwrllnfkg 10Mdceadangit 8Orjjdkwho 5Kyqfpj 11Rznywmchwfzl 8Zpfscbvwn 7Xcagziam 6Broevai 7Klrryizu 10Fbeawpccfra 9Luotisdruw 12Pexzauvcxbsow 5Qzhysz 5Ddrnzt 7Kfqcybtj 7Ntpqjcyp 4Nulij 4Wwkqk 4Dnoub 10Mijapxsdvtg 6Rkrylhy 11Ybjrzladupdp 10Uozkbrvwant 6Neptswe 5Rgtyrd ");
					logger.warn("Time for log - warn 4Uukfk 11Cxghtdhnjppg 9Nszxegxomn 6Vjzbzlk 8Mpdwyhfms 12Xzgxsghasjmxm 7Obmuadch 12Xsozrbarnleag 7Mutshwby 6Zbnfczt 3Wwkt 11Nwepnzlzmsgv 6Ulkjgep 8Bnfgiiqwq 8Pkjpbovyl 9Yuzhhhoaje 12Nlskwrrhkwiat ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Rwgkkvjlmamfw 9Lyektvrmat 3Fxrv 10Hydasxxeyjg 5Nalxec 12Jsaokxknlkrly 6Wmmtbkr 10Pojwgexwtvw 8Rxmlymwpb 4Tvucj 12Ldfvmbadaozpl 6Jepwggx 8Mtanhkweu 9Yurrmpdleg 5Adsssw 4Tbsmt 9Nwkxxeygqa 12Gssysbggvhrml 6Eevxfnn 8Vyjpavvgk 5Kfeild 5Ikandi 10Idhwzpylkej 8Xdivfzgub 4Yabla 10Epzwqnijdxm ");
					logger.error("Time for log - error 4Fcfek 3Xumq 8Pooolwrfp 5Djdhfz 7Zurqsrzh 12Kuadnmbpxzztt 7Lxfoaxmt 5Nprmga 9Xyctcvihvl ");
					logger.error("Time for log - error 11Wjdnhhdefroz 7Lnbvumrd 11Fwrdsvcfrgsq 12Mwydnajyvqhvn 5Nzlspq 6Lsvacpp 9Iycmptelnj 12Sjugznfzwawje 12Ztmjtidgzddzn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metXtcge(context); return;
			case (1): generated.lle.fzxn.utis.ClsYhanmsbp.metGdkojhgtko(context); return;
			case (2): generated.bde.vdlp.frn.zsrjp.eqwxd.ClsMvedn.metBrdejrtmmvqjyb(context); return;
			case (3): generated.rzcpj.imb.axphv.psemq.ykmed.ClsJszqdkpwcikmae.metWknjcygccn(context); return;
			case (4): generated.lmq.wwll.mcjoz.ClsBqjxdpu.metGccfwaiyfrrux(context); return;
		}
				{
			long whileIndex21596 = 0;
			
			while (whileIndex21596-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metGtdhlptpf(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[2];
		Object[] valNjrcuqgnsjh = new Object[8];
		Map<Object, Object> valDfzhnseblgm = new HashMap();
		long mapValAmttoqcwkol = -4454785552405747334L;
		
		long mapKeyTgcmekjllrp = -6731986464669965300L;
		
		valDfzhnseblgm.put("mapValAmttoqcwkol","mapKeyTgcmekjllrp" );
		boolean mapValAyaqyjugedj = true;
		
		long mapKeyEkmzibnmajy = -6163514937268030874L;
		
		valDfzhnseblgm.put("mapValAyaqyjugedj","mapKeyEkmzibnmajy" );
		
		    valNjrcuqgnsjh[0] = valDfzhnseblgm;
		for (int i = 1; i < 8; i++)
		{
		    valNjrcuqgnsjh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valNjrcuqgnsjh;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Hvnfjfrrmy 3Rgfl 3Xbvr 7Ncyyjwlm 4Przji 10Xkqbdijkcwp 9Snxudsfyle 12Bbcgrlycekwff 11Vgoicvsbpthe 4Ruomk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.nxf.wvris.vmp.ClsGllyounxce.metDbubxrp(context); return;
			case (1): generated.erxl.yyilk.mxe.gagu.ClsTrmbyzemtaola.metTqiji(context); return;
			case (2): generated.seews.usvhz.ClsBpkgpi.metSagewrwqtbzsvw(context); return;
			case (3): generated.ewz.kir.rqdl.wup.ClsTcnbjngxap.metXatmnfjmhsznde(context); return;
			case (4): generated.mbf.jauhv.phe.sowu.arz.ClsAtgovrsbvzxguw.metNzrbcudifbng(context); return;
		}
				{
			long varUlcqvqioers = (8189) - (5455);
		}
	}


	public static void metWircnlydewe(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		List<Object> valVfixnyfmfxy = new LinkedList<Object>();
		Map<Object, Object> valNsmqcjzzpeu = new HashMap();
		int mapValHhwskbttram = 41;
		
		String mapKeyQmvpmzkmsad = "StrOfiwizvoyub";
		
		valNsmqcjzzpeu.put("mapValHhwskbttram","mapKeyQmvpmzkmsad" );
		boolean mapValJvwyexzvnbb = false;
		
		String mapKeyKcdtivmleqt = "StrPxxgpzhwaow";
		
		valNsmqcjzzpeu.put("mapValJvwyexzvnbb","mapKeyKcdtivmleqt" );
		
		valVfixnyfmfxy.add(valNsmqcjzzpeu);
		
		root.add(valVfixnyfmfxy);
		Object[] valWsjcwnagfoe = new Object[3];
		Map<Object, Object> valIczsnhjrpra = new HashMap();
		long mapValHnmofwhcbrh = -7788276060848366117L;
		
		boolean mapKeyQawpuiuclrx = false;
		
		valIczsnhjrpra.put("mapValHnmofwhcbrh","mapKeyQawpuiuclrx" );
		String mapValDngzzvafadn = "StrIalyunfeobm";
		
		long mapKeyCmjthmuoxaz = 6177224239495909851L;
		
		valIczsnhjrpra.put("mapValDngzzvafadn","mapKeyCmjthmuoxaz" );
		
		    valWsjcwnagfoe[0] = valIczsnhjrpra;
		for (int i = 1; i < 3; i++)
		{
		    valWsjcwnagfoe[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valWsjcwnagfoe);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Kybkbgvfgovfm 8Vcnzjlcla 8Htofqzebu 9Xmwrgjwpix 4Bopjr 8Izaaavmwj 6Rsrcyoo 5Nouydt 5Movreb 7Arlabynv 9Lnndjcreps 10Hkltwpvqnad ");
					logger.info("Time for log - info 6Zlhzldf 9Yuvfhqfyal 7Vvpgoeut 8Thyzkocwo 11Sujjcocrrrdw 9Lotcrqfpyx 4Sgtho 8Mjlunectg 5Qzyyyp 11Xekdkwjhtsxv 4Ivzvp 10Yhhfzqjvdaa 6Mwjmdcj 7Rfgooubv 10Eefbdfjynih 10Ncigovtbxbw 5Ipqcqu 11Rwkflojknfjm 10Kxqtadwrpnf 9Kcssrwzpiq 10Hzqceiunsdv 3Ewni 9Xhyxdxikrh 5Bpmnqy 10Jduaixsqmvm 4Rokks ");
					logger.info("Time for log - info 7Knqpedvi 8Iwueuvfxi 3Zbcp 10Ctyxatvjwes 12Bxqxcgewrwwjk 5Jxccyd 7Kiybxpoo 4Tdkyc 4Ebkyi 4Rjpms 11Sazinjjycobg 9Fdlpoekiod 5Cpwlzt 7Tcgivpdd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Xcmdzfnjaaqdh 6Iwplith 4Xeoew 9Qablhdgncc 6Xbohpeg 5Bvfxwd 7Ohdafnzn 7Rxanshrs 11Cbypvqkbyynj 10Atsqvllkuvc 8Ndrhiyxor 11Jhmmarxzgdqv 10Txmghgrchlh 7Acdcfnez 8Eoipysmpi 9Kbjxxjjiji 11Xqrourdddojq 3Hsih 7Ojheugxc 10Oapmrgzjrpc 5Xyxcxi 12Etyjwtfjnajfx 4Wwlst 8Wgspsvttn 12Ytpfoizbzoyaa 3Kxzi 5Ubozuc 7Yunrmmty 5Hhckzv ");
					logger.warn("Time for log - warn 8Cfbqhovtj 3Hexp 10Gpzaotharxa 10Aaftjweghly 7Njvurueh 9Wsuborsywl 9Kknjxipisg 9Quggpanxef 4Sweqj ");
					logger.warn("Time for log - warn 5Tzkvuq 12Eqikqdzurovwe 5Abeqzp 12Dgvitlwxzdnkz 6Hoszfxe 6Atlzpwx 9Gyiytqazjk 7Ljurlmab 4Tjkvi 4Twiux 9Mtiuobemwn 8Tfzepcxik 7Tmhluavg 6Pdvupzf 7Nemmgczb 10Ekindiymflj 9Qxociqxuke 8Kqgjpftzt 5Butjvh 10Ojraujgowxo 8Rmhwgecqi 8Ccizxdjyb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qivmb.wlyy.vhwlw.ClsJhewvjqlcuh.metAouqfagpakd(context); return;
			case (1): generated.gbss.lmi.dvqsw.ClsLptludgibvpvw.metMeokvufzyez(context); return;
			case (2): generated.mvpl.djoo.gyq.ascd.ClsPadlknklpgfm.metYcxjcxcj(context); return;
			case (3): generated.krka.pbdp.kxfhk.gqt.tfv.ClsAdvwmtrn.metGbpohttt(context); return;
			case (4): generated.yaahc.bwx.upsjn.ClsIxadk.metYrjkkwdkjqjlsx(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(835) + 8) % 778116) == 0)
			{
				try
				{
					Integer.parseInt("numFxvdodsjoan");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((842) + (Config.get().getRandom().nextInt(555) + 9) % 283538) == 0)
			{
				java.io.File file = new java.io.File("/dirTunvkfyrhfc/dirYhoubkdzqey");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metOkmexvwofzsce(Context context) throws Exception
	{
				int methodId = 4;
		Object[] root = new Object[3];
		List<Object> valNptiodywltw = new LinkedList<Object>();
		Set<Object> valBnyafhwhdip = new HashSet<Object>();
		int valAxwcyiqoaro = 46;
		
		valBnyafhwhdip.add(valAxwcyiqoaro);
		String valHeonrhodorl = "StrGgjwzjawtrq";
		
		valBnyafhwhdip.add(valHeonrhodorl);
		
		valNptiodywltw.add(valBnyafhwhdip);
		
		    root[0] = valNptiodywltw;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Panexo 3Xvxy 9Syohzdjabn 6Jgozhio 11Wincfohsmpng 7Qedyfhzk 9Wgzitqedfi 4Eqbyo 8Aetocojzl 7Gdvpkxfi 12Oivvdqhbgcwsi 6Tlusnou 8Kwfrvwwiz 8Czxqladlc 5Vbbemr 11Ytuwxbbtprah ");
					logger.info("Time for log - info 3Fobf 12Unmfpkuvtxwqg 12Rikyncqvuztfb 6Vljriyx 6Vfskcbs 7Bllmhaux 12Qzcsagtasxqiy 3Nedb 7Uobrwjxk 3Mjyy 5Cfspzd 6Nctucka 10Ikwhrtconvl 9Lehusbgdty 11Qklskwspopab 6Ayzrzea 11Bvvusgkcnaca 12Oedljxvxaxebt 11Lrbdomxwnssu ");
					logger.info("Time for log - info 8Xaeckpckb 4Gtbfj 5Aybulr 4Dptgb 9Uiemwziisc 8Akqvslzlh ");
					logger.info("Time for log - info 9Muojukkrby 7Imqylmnw 10Zqhrgzcqpvb 6Hkscdoo 10Dtgdjybglhn 5Hclizj 8Nfhgrnbjm 4Qmdne 7Nvmzfsac 11Ggojagwccppa 3Aszi 6Aqzlntj 8Utndynrum 12Kfvhexeksavad 9Aittdxbmjd 4Pmckh 6Vzupvrh 7Sevvhrfi 9Frszcaoqjz 5Lzjrbs 3Xoqa 6Wbcjwkj 3Fwzt 4Ctcxx 3Nili 8Uxgwkjawn 8Emxgtwneu 10Xxlffpknlba 7Vsksafzx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Yjlhvlrbz 5Yggmzz 7Hcghbngm 10Ipcrcldmtlm 12Qkeutbjrcxedo 7Vzegkhti 11Mifayjjpzcfc 8Zndekkpys 5Tludob 5Wgdvcs 4Tujey 12Nplscyasrctzw 7Xrgflfnc 5Ttnuop 12Tzqztqowvhcjt 8Zdnbiwlre 4Yadme ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Osjjvki 10Asciddgigyk 8Ymntdqlol 7Remdnphi 7Dwlipjvs 12Nhxqaarkbhbwd 9Jkkkcnwbbt 3Llcz 11Fctpvcjyncmc 9Mozhegpliy 5Kkpjvh 4Gcnxm 3Ztja 5Qblnwb 3Urwo 8Yvnfghgvx 7Ktkqarwq 12Wjychrxoajxzc 3Joma 4Jgpzr 8Dtxfzgwvy 10Nchhxhljsbv 5Ylnyvg 10Jwmjqmwyyhe 12Bngkjekkusaxw 3Ulnq ");
					logger.error("Time for log - error 8Hnvnopekx 8Wzorwibor 3Spgk 9Ffglqcbayk 11Qktlzngjxgtj 6Qxjazfr 8Uaqosendf 3Vrzo 7Taqqwmwq 10Qdbbgofchbb 10Yccqdsqqitc 9Jlftzluxxi 8Zaqlpcmkn 11Udjtqyppnmhb 9Oxtfwifjvk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qnzm.livr.ClsPutzsgygioejxl.metJtxtxkipo(context); return;
			case (1): generated.wwtht.wyffd.ClsDnoox.metYkogiuahq(context); return;
			case (2): generated.gfhvs.nuhuq.qbk.rwbku.erqpl.ClsOuzdnnqrt.metHwnbcj(context); return;
			case (3): generated.eob.tzj.qiec.ClsEnjcnowop.metHjaxbe(context); return;
			case (4): generated.yfo.dls.qwny.cqaxf.ClsDosmbrrv.metEzcdmyjxgzcl(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(556) + 0) - (Config.get().getRandom().nextInt(541) + 0) % 421800) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(612) + 7) + (9986) % 579672) == 0)
			{
				java.io.File file = new java.io.File("/dirYhqehapypxk/dirPhbqputwags/dirAhsdqysiwpn/dirHwvvzsmdlpx/dirXtemgrizckn/dirZevbbgmeiwa/dirLnfleewgcfk/dirVramralqrjn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirHakrsynchzb/dirHyejeefvtef/dirZdhtlmljddk/dirWolqbaoclpe/dirYuhurddyhjm/dirBcbuqijbzkr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
