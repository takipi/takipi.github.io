package generated.flvo.tuwfx.wlpxx.jysnd.tuk;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsFuuvt
{
	 public static final int classId = 424;
	 static final Logger logger = LoggerFactory.getLogger(ClsFuuvt.class);

	public static void metYllionx(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValObipykwzulj = new LinkedList<Object>();
		Set<Object> valBrgxdohqsrc = new HashSet<Object>();
		long valXhnsnnprciw = -6810292792438062473L;
		
		valBrgxdohqsrc.add(valXhnsnnprciw);
		long valHxnczzrngbo = -292667252641031715L;
		
		valBrgxdohqsrc.add(valHxnczzrngbo);
		
		mapValObipykwzulj.add(valBrgxdohqsrc);
		Set<Object> valBjyryokdchf = new HashSet<Object>();
		String valOtmrtoxbswe = "StrJwuttxqfzxz";
		
		valBjyryokdchf.add(valOtmrtoxbswe);
		
		mapValObipykwzulj.add(valBjyryokdchf);
		
		List<Object> mapKeyHbrlobegymz = new LinkedList<Object>();
		Set<Object> valAgsboykkqkq = new HashSet<Object>();
		long valUbwgpvujwgo = 6602687076237217878L;
		
		valAgsboykkqkq.add(valUbwgpvujwgo);
		int valLwncnacycku = 50;
		
		valAgsboykkqkq.add(valLwncnacycku);
		
		mapKeyHbrlobegymz.add(valAgsboykkqkq);
		List<Object> valEgqyggmkcor = new LinkedList<Object>();
		String valTsdbawkldjc = "StrDkljzzoiovj";
		
		valEgqyggmkcor.add(valTsdbawkldjc);
		int valVmjcmqorery = 386;
		
		valEgqyggmkcor.add(valVmjcmqorery);
		
		mapKeyHbrlobegymz.add(valEgqyggmkcor);
		
		root.put("mapValObipykwzulj","mapKeyHbrlobegymz" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gfpc.pbcpl.isevo.syh.yqsp.ClsDuasxzsefdmugn.metAprvs(context); return;
			case (1): generated.gfiaw.wgvz.askqs.ClsGbqekumwdbwfn.metVqqri(context); return;
			case (2): generated.ahr.cnut.ztcbc.ClsUicrpogixv.metIynrmqpfnjegr(context); return;
			case (3): generated.vyac.iqbj.guc.ClsYpwwsvx.metByexoqmllnlarc(context); return;
			case (4): generated.aisq.ykt.yfxh.ClsRqviupmemczv.metQirovjexgq(context); return;
		}
				{
			long varBagwqxgofon = (7563);
		}
	}


	public static void metQxwuot(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valDystlhbwmkw = new LinkedList<Object>();
		Object[] valJigbimqauvr = new Object[8];
		long valPyqndxbhkjy = -6699280402921314636L;
		
		    valJigbimqauvr[0] = valPyqndxbhkjy;
		for (int i = 1; i < 8; i++)
		{
		    valJigbimqauvr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDystlhbwmkw.add(valJigbimqauvr);
		
		root.add(valDystlhbwmkw);
		Set<Object> valHljccpqsdaw = new HashSet<Object>();
		List<Object> valFmfxhzteqev = new LinkedList<Object>();
		int valHfarglqyzpp = 279;
		
		valFmfxhzteqev.add(valHfarglqyzpp);
		
		valHljccpqsdaw.add(valFmfxhzteqev);
		Map<Object, Object> valKhebartvsyi = new HashMap();
		boolean mapValUsmdplrklab = false;
		
		long mapKeyKasyncembku = 2410219702311729964L;
		
		valKhebartvsyi.put("mapValUsmdplrklab","mapKeyKasyncembku" );
		
		valHljccpqsdaw.add(valKhebartvsyi);
		
		root.add(valHljccpqsdaw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Fbaijbq 9Ynetpiwjtb 10Nonlnteqdiv 11Accyafheykca 12Umlbdettpwbwm 7Ywxtjido 7Tgujzqbk 9Msdzbsexgj 3Woki 9Ivkaftfcta 5Ikqvim 10Qewcnegyxzb 8Wqvidvcxo 12Afjvzrypesdce 5Scaxmi 7Tpmysoqe 9Hyyhtwfymi 11Oxyjnvpsloxi 9Aniltmsqsz 12Dklicsjfmuzwa 6Nkqjtnp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Evrbwwlhofq 8Ucxfbcohm 7Hspxykqq 11Snyvldlnmocm 8Jxzhhumpx 10Zaumvrfenxv 10Piblmksdehv 11Wxgkmzkiuqxl 4Pmqyd 9Mhtgauprlq 4Takqh 12Yoktpuewvfwpi 6Jhbieej 6Fxcfrtb 9Aznapglhkq 12Tybvlnuvhotkg 3Xdfm 10Fjdnijeverp 11Pyeeyxmaplqh ");
					logger.warn("Time for log - warn 7Gokdonjx 3Wnic 3Ybha ");
					logger.warn("Time for log - warn 9Rrxlfxgjqz 10Ycvbiexkgtn 5Mmnimb 5Pgoitq 10Rrniwnzdpjy 7Bxgzlfzy 5Nvgzvi 12Nawxqfxmaypve 11Yrdeqzjubdvq 8Sndwslqrj 6Pbufbyj 10Fgzgniwsmxh 7Knwjseci 12Kohdzofylsljy 8Emkqpsiep 10Kqkyeksbxsz 5Pdpemn 5Xqapkq 6Zfwtjnd 11Ripvfzfgxaol 4Hyqsl 4Erfpe 10Giozwqrhmii 11Umntmmqmjejo 12Frzwtkneyudts 7Knlxdoyp 7Lzhwpfps 7Wyibhzdf 9Wtcevwypeu ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Osfpb 5Xmasez 9Eiwonkxmph 9Qzagjsbdyi 5Oehtyf 8Refxoxbny 4Uedbg 8Hzrebxypq 12Xrbwuhjontzrh 4Kogvt 11Xmbtjxahzkau 7Nimtlouu 3Vvkg 10Favbymrzzzc 4Scpiz 6Nrjjvjm 6Xjtluoc 3Qojx 5Lvuzhr 3Ffbk 9Eovbhqjrmq 8Llfcurxsn 6Tamaaje 4Exwer ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.elv.qjwox.npj.oxv.jth.ClsNewmedi.metPuqgumqeuym(context); return;
			case (1): generated.fzd.qgqjp.ClsVzqqvdhb.metMsjbhqpplani(context); return;
			case (2): generated.plye.kjczy.bmku.wrxrk.zek.ClsNtetu.metLbovgdo(context); return;
			case (3): generated.uyus.ruq.fow.dvnw.ClsCysblmgtiyuxcr.metExmmbm(context); return;
			case (4): generated.swyg.szfbf.ejprt.ovbj.ClsEqyrgxer.metIorzpghwry(context); return;
		}
				{
			long varQjxmugcdmjo = (7778);
			try
			{
				java.io.File file = new java.io.File("/dirUudyeaaehjt/dirMaocmksjgts/dirJxhzhbamhsc/dirZxfgruuizcg/dirOrqpyfqrzcv/dirRxxjftkbzqt/dirWvowyilhone/dirYsrivblwmjj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex27133)
			{
			}
			
			varQjxmugcdmjo = (9794) * (8685);
		}
	}

}
