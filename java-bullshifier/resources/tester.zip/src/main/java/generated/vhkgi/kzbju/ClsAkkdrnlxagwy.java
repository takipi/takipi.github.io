package generated.vhkgi.kzbju;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsAkkdrnlxagwy
{
	 public static final int classId = 449;
	 static final Logger logger = LoggerFactory.getLogger(ClsAkkdrnlxagwy.class);

	public static void metUkjjzsaxomm(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValJwxgseruucq = new HashMap();
		Set<Object> mapValJkdokmqskfb = new HashSet<Object>();
		boolean valHexkitzwzww = false;
		
		mapValJkdokmqskfb.add(valHexkitzwzww);
		long valUzhgfemcupi = 1673796510815450646L;
		
		mapValJkdokmqskfb.add(valUzhgfemcupi);
		
		Set<Object> mapKeyGnwgntftbjf = new HashSet<Object>();
		long valLvxylkgjmlu = -6879394505253231458L;
		
		mapKeyGnwgntftbjf.add(valLvxylkgjmlu);
		boolean valSkwyfwoqfls = false;
		
		mapKeyGnwgntftbjf.add(valSkwyfwoqfls);
		
		mapValJwxgseruucq.put("mapValJkdokmqskfb","mapKeyGnwgntftbjf" );
		Map<Object, Object> mapValEebnarevfip = new HashMap();
		long mapValTczxkcowzqw = -6776752498901869968L;
		
		long mapKeyLadmxytgrbe = -3171891392058809685L;
		
		mapValEebnarevfip.put("mapValTczxkcowzqw","mapKeyLadmxytgrbe" );
		int mapValBvsgjzevhml = 175;
		
		int mapKeyTmvitmewiuy = 33;
		
		mapValEebnarevfip.put("mapValBvsgjzevhml","mapKeyTmvitmewiuy" );
		
		List<Object> mapKeyTwbpyrqmtly = new LinkedList<Object>();
		long valIethrkfczcr = -1111580769727007785L;
		
		mapKeyTwbpyrqmtly.add(valIethrkfczcr);
		
		mapValJwxgseruucq.put("mapValEebnarevfip","mapKeyTwbpyrqmtly" );
		
		List<Object> mapKeyMpslbhopakl = new LinkedList<Object>();
		Map<Object, Object> valAeeonzdsrtw = new HashMap();
		int mapValXgbqgqxnioy = 207;
		
		int mapKeyAzakijbfmuo = 387;
		
		valAeeonzdsrtw.put("mapValXgbqgqxnioy","mapKeyAzakijbfmuo" );
		
		mapKeyMpslbhopakl.add(valAeeonzdsrtw);
		
		root.put("mapValJwxgseruucq","mapKeyMpslbhopakl" );
		List<Object> mapValYpcbrfwxluy = new LinkedList<Object>();
		Object[] valOdgjcbmfvjc = new Object[9];
		int valScmmqvodssy = 395;
		
		    valOdgjcbmfvjc[0] = valScmmqvodssy;
		for (int i = 1; i < 9; i++)
		{
		    valOdgjcbmfvjc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValYpcbrfwxluy.add(valOdgjcbmfvjc);
		List<Object> valWaufmqyqecz = new LinkedList<Object>();
		long valCgspxpngvzt = -6587508835022531245L;
		
		valWaufmqyqecz.add(valCgspxpngvzt);
		String valYburvconrdj = "StrFluqeplqscj";
		
		valWaufmqyqecz.add(valYburvconrdj);
		
		mapValYpcbrfwxluy.add(valWaufmqyqecz);
		
		Map<Object, Object> mapKeyBwlxtbgtfpg = new HashMap();
		Map<Object, Object> mapValUnvvkupwdfr = new HashMap();
		String mapValRcxhigpzfso = "StrPxctyumgqgm";
		
		String mapKeyLjndgruibrz = "StrDjsvnxpjwvd";
		
		mapValUnvvkupwdfr.put("mapValRcxhigpzfso","mapKeyLjndgruibrz" );
		boolean mapValZobvcpemplw = false;
		
		int mapKeyCmuiyfuehdr = 503;
		
		mapValUnvvkupwdfr.put("mapValZobvcpemplw","mapKeyCmuiyfuehdr" );
		
		Map<Object, Object> mapKeyTttzuxaxksg = new HashMap();
		int mapValDylseaifsjm = 367;
		
		boolean mapKeyQvksdzfvbvb = false;
		
		mapKeyTttzuxaxksg.put("mapValDylseaifsjm","mapKeyQvksdzfvbvb" );
		
		mapKeyBwlxtbgtfpg.put("mapValUnvvkupwdfr","mapKeyTttzuxaxksg" );
		
		root.put("mapValYpcbrfwxluy","mapKeyBwlxtbgtfpg" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Cgvwgr 8Nsmlphfvz 7Ioyzgyeg 4Fmeeh 10Svfwqcfqksb 9Kmcwwipoct 8Jdrbgjlrl 6Kvymtsa 4Rkmon 11Pfpldyxkxpth 5Iyfxhy 8Invbktaxv 3Pwzg 10Jeabkzwgfco 6Yvgnlam 5Xxesqr 4Jmnqv 11Vhphrakouqsp 11Mbuwdnwaqheg 7Hhefgaju 7Ssphbygz 3Suli 10Ruxqdmmayny 5Qcanqt 9Hgkbandgmg 6Zvpetiy 12Hoxblkmjltmqd 10Lgqmqggpaey 4Odlyt 5Ptkjrc 12Itokuyxxdidnr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jgye.cou.ClsWhiobyn.metGldtri(context); return;
			case (1): generated.zvc.zkqw.sqxhe.ClsQioplriwzgyw.metRdrunjnhq(context); return;
			case (2): generated.dpe.jvo.jwdtk.ClsKqcmvv.metJoosxkzgqj(context); return;
			case (3): generated.yfwg.zmane.bbbip.wqsm.tbdz.ClsSzekb.metZjimsrct(context); return;
			case (4): generated.cymhf.zmxu.aqlat.ClsTwlvztmhvdbz.metQxzvxpynrcfku(context); return;
		}
				{
		}
	}


	public static void metAldwmwjbguivdl(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valHrqizivnxhf = new HashMap();
		Map<Object, Object> mapValFjmgvfzfirl = new HashMap();
		boolean mapValKozcxxyggnl = true;
		
		int mapKeyTayrxaqioiw = 623;
		
		mapValFjmgvfzfirl.put("mapValKozcxxyggnl","mapKeyTayrxaqioiw" );
		long mapValMyustgoufjf = -2528380147350204091L;
		
		boolean mapKeyKfqelbbxnzn = true;
		
		mapValFjmgvfzfirl.put("mapValMyustgoufjf","mapKeyKfqelbbxnzn" );
		
		List<Object> mapKeyUixkqkoixjo = new LinkedList<Object>();
		boolean valNyqzicsztwo = true;
		
		mapKeyUixkqkoixjo.add(valNyqzicsztwo);
		int valIoranqqylfk = 518;
		
		mapKeyUixkqkoixjo.add(valIoranqqylfk);
		
		valHrqizivnxhf.put("mapValFjmgvfzfirl","mapKeyUixkqkoixjo" );
		List<Object> mapValLxlccyluaaj = new LinkedList<Object>();
		long valIsqhuwruaci = -4411482268561544717L;
		
		mapValLxlccyluaaj.add(valIsqhuwruaci);
		
		List<Object> mapKeyJcojohgjxeg = new LinkedList<Object>();
		boolean valDxcitzlibsy = true;
		
		mapKeyJcojohgjxeg.add(valDxcitzlibsy);
		int valRmzecyeduue = 694;
		
		mapKeyJcojohgjxeg.add(valRmzecyeduue);
		
		valHrqizivnxhf.put("mapValLxlccyluaaj","mapKeyJcojohgjxeg" );
		
		root.add(valHrqizivnxhf);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Hdsrjrmcm 7Fjaxiwla 4Vapkg 8Sjvseevkf 11Khockqttdhgo 8Hsudxspwj 10Oavorhvcxit 9Jhpxvipsuc 9Pxfhryeiqg 12Otpydurdchsmq 10Qdcrnmjbxgm 9Vtikmopneo 7Islzjvrn 5Uvtbkp 11Pbdrpblrupzt 5Nhlqzl 12Rssvyxscixvzy 8Dvsbcjbls 3Kmrx 12Rzdlvbfkjlgcc ");
					logger.info("Time for log - info 8Qcjqxxkkk 11Elphqkwtmjtg 4Csgkz 3Ztoa 4Ybnks 12Utegvhaiyqqxf 5Qykmfg 5Jskilr 12Rxtdzzohbzvmy 12Krvqcejkwzugh 4Vmzkc 7Hlbvxazs 4Fbhfv 4Lfxjo 8Swuepnrfu 6Kyepqbe ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Vsebpifemoa 3Pnps 12Cgastixygaowy 7Zzpdcsmw 3Vskj 6Csvxuoq 6Hoayivo 9Sresftevyb 3Qynm 7Bjovfnal 12Cyvfgjacxxuwe 10Ejgvueffrkk 10Lfsuunlsbsj 8Iojdwbfvd 12Mueszmyuvlroh 3Gpkb 3Inam 5Rwchhq 4Iovcg 10Lrnhdrzqfdm 10Ksfbrlfijgx 6Jrhidaw 5Hsbsva 6Jfhmzum 8Xgidspuzy 11Bopxxooktorf 10Ldistbksflc 12Zmeqrqfrtwses ");
					logger.warn("Time for log - warn 7Ublwreck 5Dkbnki 5Lylqea 3Lptz 8Egmmmakhm 11Luxljuhcqkxg 7Bggakyms 4Ydtpz 8Dsekgtqps 10Ltajaocghjl 10Wnatuixnhhm 8Yvxibppbc 5Lianbv 12Kgkkyobyskhqu 4Gxaca 12Dxztttrpjsuas 9Poipkvguxs 3Yshy 4Eafbx 8Fmifxatgr 4Viqkc 10Drhhhwemgmm 9Kgjywksjxf 5Zonnzc 6Vqilnix 9Wsplkertwn 6Tqzikbj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Bdkrcwtqa 11Sbeanqcjafqh 5Dwybme 10Vsujsxaitgu 11Ybaiwfcpkycl 5Eyqkyu 6Fntmgxu ");
					logger.error("Time for log - error 9Ihqohlnfbx 6Rezzucj 8Rmfgotvux 6Ytkvjuq 11Fkqhcfthvxte 10Rnjndbecmkf 11Ngxddzljoopf 4Mwvms 11Lioktuyiivhr 7Bzlkhktt 12Xrqbrqrbdrlxi 5Yzmfkw 9Toncpoppgd 8Wcsmpishq 6Nzzeerp 5Rdemvq 7Iwuirtfl 3Fhyl 5Gwrjsy 11Nidrkzuazmjo 6Wyabefb 3Wnop 5Zwnawi ");
					logger.error("Time for log - error 6Lybnfef 10Csuidvqkdln 4Yvcze 3Ytps 12Jagzrqwqowisy 12Pvsyazmasyasy 4Sebjt 11Kraxjifkebza 11Suyertkiklvc 10Byekiohipui 6Uchkiik 6Cxhdrlk 12Tdxyvbpcqmstm 11Fvxibbwgvfcv 7Gkdyqvgu 8Laqpzpnqp 3Yzxi 6Kdttkyu 10Xzjafbgthqh 4Zinbn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qku.vho.jtvuy.nvgy.zmvk.ClsVjaehh.metMiltdyyfzeyo(context); return;
			case (1): generated.qikh.hgtag.amhgk.ClsEpqxnohalceif.metBjfkpwuutlibc(context); return;
			case (2): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metEwxuvzwhpbpte(context); return;
			case (3): generated.hzw.xclp.jagge.pvih.oqmlx.ClsBjaeoqqxwxxp.metAhluzg(context); return;
			case (4): generated.kibd.nddr.nknr.pccz.hryio.ClsBgthm.metFrmpvshfvh(context); return;
		}
				{
		}
	}


	public static void metKsomxqgjrt(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valCcunukdrait = new HashMap();
		Map<Object, Object> mapValWolpcdzzgfa = new HashMap();
		boolean mapValMpacbvqaavc = false;
		
		String mapKeyAfkmckmoark = "StrYotdavmghvk";
		
		mapValWolpcdzzgfa.put("mapValMpacbvqaavc","mapKeyAfkmckmoark" );
		String mapValFdrsiypzhko = "StrIzfnledyfnu";
		
		int mapKeyMkjopdbjwmc = 681;
		
		mapValWolpcdzzgfa.put("mapValFdrsiypzhko","mapKeyMkjopdbjwmc" );
		
		Map<Object, Object> mapKeyRzsacdckhaa = new HashMap();
		long mapValHpibmjixirg = -1577756761343686939L;
		
		boolean mapKeyMglpqvscgat = true;
		
		mapKeyRzsacdckhaa.put("mapValHpibmjixirg","mapKeyMglpqvscgat" );
		
		valCcunukdrait.put("mapValWolpcdzzgfa","mapKeyRzsacdckhaa" );
		
		root.add(valCcunukdrait);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Xeped 4Cpbmz 4Plkcn 6Gbyprap 9Rslxkjeixt 7Gjyjkbjr 9Wbuubxeqql 11Vnqttfkdyueh 5Bjvquu 7Dnjwbvxm 10Ffzewubftht 11Iwypmokhdlio ");
					logger.info("Time for log - info 10Dzdqfqgijkd 6Smilpei 5Bvlrqm 6Vjxqewn 3Cgze 11Vosogjznpgrh 7Mnerptzw 11Bcskycqpycno 3Xjpc 7Fuidghic 4Uldlw 6Tybqosp 11Klkwctbfnexa 3Ruyg 4Awoxj 3Qhpo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Fucphlq 11Vqyamqajzdrt 10Hdqjbfhabqx 11Upnowpzxiknu 12Tjctdvmiwfslp 12Nohqwvmgdehyy 5Acgqxl 12Mjeavgpogzdxd 8Tsvkplftz 7Aioanxxj 6Saxqkba 11Eycctwniplek 6Ticmzqd 10Gaslirzzgei 9Ffpugmierq 9Hedmxuwrjr 5Ixlifh 11Xkzhfpfqrqeh 4Pudgm 3Hjrm 9Npssqoqmio 10Fwdskbzxmip 11Uavalvgictca 9Sactcmvsjt ");
					logger.warn("Time for log - warn 10Okcxknqxwoc 5Qtcvwi 10Wopjykmnyfa 3Alwp 5Ruturk 8Idsgbndhz 5Qddift 6Hwfrofs 10Lfwyezjnati 3Kelu 3Jhdn 7Ozepeqac 4Ykecs 6Qvcwsqx 6Gsmgcxf ");
					logger.warn("Time for log - warn 4Ghxzy 10Ogveetzmztv 10Fcysbdrqcht 12Egxwruqococor 8Jhvhwlrsy 3Qeac 12Bdmsuhvbcnqaq 3Vzov 10Zwndcokocaj 3Arxj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Joszzrzlpqarr 4Cbsjf 7Tjphbnze 10Wmnyiheggpq 10Zrzwitpkqod 8Epkwbelbt 5Mmvlzp 12Jsnnxrdrjqybe 7Jjhgqfgz 12Xuhvehfxwvqkk 11Tqfardtuvxri 11Vnpkvsmzonyk 7Eqrqobrc 10Qqfsepjvplb 4Dfzdq 11Xplfbtxdlsan 11Eljkbbefswbc 9Htovurcuyz 10Fygjjviqsba 11Aoyrvbjmahqv 6Fopiywb 12Rzftegfmxqzge 10Frjdwiadccf 10Buwfqxnkuvj 11Ysroujiphpbh ");
					logger.error("Time for log - error 10Zgvuywcheyq 3Rtrd 6Bvnkdtw 5Jufmqp 4Auhyu 7Vivcpgne 4Qtplv 5Bmzvif 5Gnhsiy 11Lqungzofrjqi 6Pxlpfgg 3Hqqy 3Krng 10Spiemadjaxj 5Qfeoij 7Unbzbogx ");
					logger.error("Time for log - error 7Zeqkryym 11Iawpqsuomnmt 11Rbjifkcdunvm 7Nxxdpaby 12Eoazfxbmcqswb 3Mnmh 12Defmqunssrhhq 3Wyes 10Pfhisfddzuc 7Lxbetbns 10Zotggcqyvzp 5Mfarsi 11Tvweetpizzah 4Buaca 6Jahjtfo 4Tsozg 9Ogvusudlma 9Mxoaftkzqv 12Nbfnljmtaxuuv 8Rnsajsbka ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kkru.kkr.eff.wedv.ClsTciibuckxmwxc.metNteymarzbc(context); return;
			case (1): generated.dnnlu.krjt.bhw.ClsLntkclh.metMmocyjfd(context); return;
			case (2): generated.aisq.ykt.yfxh.ClsRqviupmemczv.metPhknaushrhzh(context); return;
			case (3): generated.qdml.hmlho.ClsQuiharvpvfv.metXrurj(context); return;
			case (4): generated.ocklj.sbz.ClsVzertfboftzd.metOvqborsb(context); return;
		}
				{
			long varSbzqocrujwr = (9619);
			int loopIndex27561 = 0;
			for (loopIndex27561 = 0; loopIndex27561 < 3987; loopIndex27561++)
			{
				java.io.File file = new java.io.File("/dirXjybdeemlaz/dirTgwxpcsxcxe/dirDgpxberuhud/dirAhbgoispnjy/dirLkrphydugpm/dirHmvyggwtjkx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			varSbzqocrujwr = (varSbzqocrujwr);
		}
	}

}
