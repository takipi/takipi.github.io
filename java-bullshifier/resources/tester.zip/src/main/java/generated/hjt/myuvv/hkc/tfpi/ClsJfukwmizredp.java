package generated.hjt.myuvv.hkc.tfpi;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsJfukwmizredp
{
	 public static final int classId = 363;
	 static final Logger logger = LoggerFactory.getLogger(ClsJfukwmizredp.class);

	public static void metYykvllrlskhqw(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValOawyjjfekyo = new Object[4];
		List<Object> valTszolweelrl = new LinkedList<Object>();
		int valBfnggwyhyra = 515;
		
		valTszolweelrl.add(valBfnggwyhyra);
		boolean valJyjprmdnrpi = true;
		
		valTszolweelrl.add(valJyjprmdnrpi);
		
		    mapValOawyjjfekyo[0] = valTszolweelrl;
		for (int i = 1; i < 4; i++)
		{
		    mapValOawyjjfekyo[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyCjmhsnzguya = new HashMap();
		Object[] mapValAlzgeefxcvi = new Object[4];
		String valJeogmvunyva = "StrElujkawpntu";
		
		    mapValAlzgeefxcvi[0] = valJeogmvunyva;
		for (int i = 1; i < 4; i++)
		{
		    mapValAlzgeefxcvi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyIrgknphdtpw = new Object[7];
		boolean valQqerfnkblew = true;
		
		    mapKeyIrgknphdtpw[0] = valQqerfnkblew;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyIrgknphdtpw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyCjmhsnzguya.put("mapValAlzgeefxcvi","mapKeyIrgknphdtpw" );
		Object[] mapValMnlyxbrlqjj = new Object[11];
		long valSunczxrebxl = -8799783593517082180L;
		
		    mapValMnlyxbrlqjj[0] = valSunczxrebxl;
		for (int i = 1; i < 11; i++)
		{
		    mapValMnlyxbrlqjj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyLfbjspugkjb = new HashSet<Object>();
		long valWedyrozautf = -7596401149072278704L;
		
		mapKeyLfbjspugkjb.add(valWedyrozautf);
		
		mapKeyCjmhsnzguya.put("mapValMnlyxbrlqjj","mapKeyLfbjspugkjb" );
		
		root.put("mapValOawyjjfekyo","mapKeyCjmhsnzguya" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Oldxxznaqzl 4Xmuca 6Itvhgzt 9Tjcbunwsze 9Hlswtcusyu 9Tnilpkwjzd 9Avjkcpslry 5Fdyowg 4Ihqll 9Hkwwltahyu 3Amuv 10Oqwgtugdlgj ");
					logger.info("Time for log - info 7Isediusv 10Gkuixdumzpb 5Jwgxrg 3Msap 9Esmnxohkbh 8Ptvyyrvpf 4Khroe 3Lcgy 4Ejzzz 10Oaebmpvwjdq 11Jwhjlfgywvdw 12Otjzzfdpuxpsa 9Fmllfdtezd 11Nxhngpxfwoma 10Folwgfgzqzu 5Ocujwx 12Ghnhbfnihzfag 8Tdhzlfyfj 3Kjgb 4Nldwr 3Gkqj 5Jgpxpu 10Aenxvjgoyjo 12Xhmyjjijnichb 9Meordeupqa 5Tfqoxi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Awkvdejrk 4Mudxn 6Nrcruwe ");
					logger.warn("Time for log - warn 10Tvpuusqgadt 3Gwel 10Ngaehayuakl 5Uztfsf 9Arpgjftejr 6Piuwmlv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Yujxd 11Smnaoppxqihh 10Ssdvlwihyju 9Qixfhiuecz 7Aesvhsad 5Hymbno 5Fyqqot ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tvv.ioy.ClsEqfmidfypp.metObdbtlzhg(context); return;
			case (1): generated.exb.zww.kausx.ClsMnvrore.metFiqwflwatibt(context); return;
			case (2): generated.dyn.peov.bqa.fptp.ClsXhblgjpkehiigi.metEiaaqrx(context); return;
			case (3): generated.fgkp.bvpjp.tisw.nifap.ygoni.ClsBmkimj.metEbkiw(context); return;
			case (4): generated.yhl.ykh.hog.zsc.cal.ClsJuxvzfsp.metRcwieirx(context); return;
		}
				{
			int loopIndex26122 = 0;
			for (loopIndex26122 = 0; loopIndex26122 < 4748; loopIndex26122++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((Config.get().getRandom().nextInt(298) + 4) % 66215) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metKzuep(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valZwulexpvlud = new LinkedList<Object>();
		List<Object> valYxcmmpbffst = new LinkedList<Object>();
		long valOzvmzltfawj = 4982682740637167876L;
		
		valYxcmmpbffst.add(valOzvmzltfawj);
		String valKgsksnivqyh = "StrKldsxvqqdll";
		
		valYxcmmpbffst.add(valKgsksnivqyh);
		
		valZwulexpvlud.add(valYxcmmpbffst);
		Map<Object, Object> valQhdclefxvsp = new HashMap();
		int mapValUsvvaweoctn = 772;
		
		boolean mapKeyEirqqusltyg = false;
		
		valQhdclefxvsp.put("mapValUsvvaweoctn","mapKeyEirqqusltyg" );
		int mapValFzonsydptce = 647;
		
		long mapKeyXnjcudxyafq = 7689703107248740964L;
		
		valQhdclefxvsp.put("mapValFzonsydptce","mapKeyXnjcudxyafq" );
		
		valZwulexpvlud.add(valQhdclefxvsp);
		
		root.add(valZwulexpvlud);
		Object[] valPjmtagwuojq = new Object[5];
		Map<Object, Object> valYoyvmlchfbd = new HashMap();
		String mapValLxerabpzlyh = "StrBnlhojphsaf";
		
		int mapKeyZggcbwnkdya = 831;
		
		valYoyvmlchfbd.put("mapValLxerabpzlyh","mapKeyZggcbwnkdya" );
		int mapValDvnsmtcfaoe = 105;
		
		int mapKeyFnizkjdmljs = 128;
		
		valYoyvmlchfbd.put("mapValDvnsmtcfaoe","mapKeyFnizkjdmljs" );
		
		    valPjmtagwuojq[0] = valYoyvmlchfbd;
		for (int i = 1; i < 5; i++)
		{
		    valPjmtagwuojq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valPjmtagwuojq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Hdyttfxsfkvzb 3Rqdy 6Cpraydn 9Myncuaeulc 11Pexejmtyohuy 12Hcyjuwfifdahm 6Qntphnf 7Qbmwrttz 3Qxnx 5Qlqzph 10Noufczgxsjz 11Dlnialovbxhj 5Qufysy 4Vsueu 7Fwatomxn 8Brirhapjt 12Gtfnmjhqrzpgl ");
					logger.info("Time for log - info 10Xdicppfrpwv 4Ujchz 9Srchiaxntm 5Vpvnvz 6Jzcqcjl 6Qcxrbcl 6Rahgudr 6Doilruj 5Ukzhcf 10Yuljtohcgvz 4Qlrru 4Vfzrk 12Pfzkhtfjxbqru 4Esrpt 12Imqzpzucklwkm 5Kmhzfp 9Lmapordxqv 11Aekfnvjpjwbc 11Kttktdzyhcfo 4Iuecv 8Wfpjyatjh 11Sqsdpimfvrqz 8Hdygdxrgb 12Bphdrwrlnthik 9Cyehfextff ");
					logger.info("Time for log - info 3Gmpk 12Rkvewkqtndpsv 11Kehmvxkrzqin ");
					logger.info("Time for log - info 9Mluuvvxqyf 7Hkqixtfg 7Ihvfzeke 5Sqhmki 5Ffjfxn 3Glaz 4Reobt 6Msenltx 8Fiulzfkgc 10Txlqezwnesy 11Gqogjrtxeouy 9Fishxxmnky 11Lxrmkctibfho 7Cigjfqhn 5Zdtewg 11Bnedcgmtpzsa 9Gwjhfnbgof 9Kiunygtpox 5Wrubfh 5Mcwvze 7Ovodcpjs 10Gdbwczpldyr 4Wqbuk 4Dvdpo 4Iklea 10Pqopoapsbbm 8Seeejtatv 10Kgoctsqbcfq 10Whrntkwfdoh ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Ijtv 7Inxbwqxj 9Labgedgrqv ");
					logger.warn("Time for log - warn 5Rfsvad 3Xzdj 3Gxds 9Rsqaetfqgx 8Tqwagqgai 9Fzckltkejt 3Agrx 11Kzcwemwndepd 10Jqhkgwsneku 6Lfuiqkl 12Orivqvrrrwqme 11Kiwrwspmrtcw 9Wuibwxfhqj 7Oxiblsbv 9Mdhfzepjxw 9Acefpfjwpb 5Soqroe 6Jqfkoio 5Shiesd 11Yxshfwiqbfqt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Tpuecjmbrj 4Dwvrd 7Sxjnwxkl 12Byrpudfuescmc 4Ixxuf 9Iqyxhtjpbz 10Nqrykdaakrm 8Lqjsjkbqp 3Zxim 10Prfkzfiwfig 11Imcfocfoesug 9Zpnzcxulrx 8Cdsqgtxcv 8Bbfgxpvff 4Pnntf 3Diaj 5Vlzypk ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cjexh.ehrl.mtwqa.ClsVshethruisurxt.metQbgbwpmyakda(context); return;
			case (1): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metTlqjnsfger(context); return;
			case (2): generated.fkhk.aid.ztzxu.ClsQjlasdqvzflfd.metSrhconsb(context); return;
			case (3): generated.rsu.hmuld.jzssz.bjyy.fod.ClsQixayqsiydaxm.metIpckuqrkv(context); return;
			case (4): generated.zdmfw.qfic.ClsQmanwrctuzecr.metEvpjjip(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirSquamgbfflo/dirKnxplugnlhb/dirOuhdtopgros/dirNedrncmtsfq/dirOmtkoqksbvx/dirUqyhtkwnrmg");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex26130)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numGlfuhhdtitv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			if (((Config.get().getRandom().nextInt(739) + 6) % 190204) == 0)
			{
				java.io.File file = new java.io.File("/dirRpsgkgeebve/dirTicpjcenfjk/dirCyqlbjspmir/dirLxtlxgcojoq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metYduwrchx(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		List<Object> valXzgkbqztuov = new LinkedList<Object>();
		List<Object> valTzhmujjjwsn = new LinkedList<Object>();
		int valBsffczrftea = 894;
		
		valTzhmujjjwsn.add(valBsffczrftea);
		
		valXzgkbqztuov.add(valTzhmujjjwsn);
		
		root.add(valXzgkbqztuov);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Bpyydnbgxy 8Wikrnkcsb 7Vpyinxmv 12Tiepzldpduuwg 11Fxagegxlkjql 4Zfuoy 8Jpndkvlxh 5Gnnrvo 5Ceesto 3Hbas 10Xvvndvpgnfn 3Gmdw 8Opjzpwgrt 8Cjppeotim 12Xalnhteweoiuh 3Rxsp 7Tytrebkk 5Cdmqwf 5Drtfne 4Wwtsy 10Ihwxtjmsagm 10Oerdxeseman 5Qbxmst 5Utzgab 8Ruiixndux 7Ceoegvqu 7Spyglhvd ");
					logger.info("Time for log - info 4Mryam 12Ccnggwogqextk 11Yhpqyudhlryq 4Czuli 11Iupfismxwukv 8Lqofrehag 10Bhymovdvmen 3Sfuz 7Aykhtfwd 8Vexzxmiiv 8Xikwhymes 5Avihzd 3Zjyw 4Ceofq 10Abbvajrotpv 7Hhprfrnc 5Owhkap 4Kjdrv 10Hdebzufywmu 12Sehoclgcesjec 6Yerqzsh 6Bzqdtik 11Prlnvwncrkjf ");
					logger.info("Time for log - info 4Ymttz 12Uffsihsmswazm 6Rrnlahq ");
					logger.info("Time for log - info 5Whfxaf 10Jnaqbfdfkcu 5Xnfipx 3Rbjs 4Sjzmw 9Rqeecyohqf 7Ttjxdncb 7Ipdlzxre 4Vdyop 11Pwqqodiwzzca 11Ngldsyomejjv 6Sfbrjur 12Cvzcdzmeyxjel 3Mrhk 4Gwtyh 12Zkutqroemvnfh 3Hzib 8Iuvhfgsje 12Puzrjslnetwqd 5Uthxnl 10Setpgqwmfva 3Zpjd 9Xkdwafctyk 7Wqssmbaz 9Gerdlfyspa 8Yzagdjrzg 4Njgrb 3Juth 11Jykixzfpddis ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Ggaodt 9Illolufyzj 11Oekavrdyhjgv 4Orkov 5Xjqljd 7Bkyrmypq 10Dpnrmaudynr 9Pyegmxmdtu 3Qxsu 10Mkzqlfuoomh 9Inehtomxtw 4Hwqrc ");
					logger.warn("Time for log - warn 12Byenmdfzbmqfc 11Vtytyhjtoqdr 3Sxkj 12Ooywuhdtvhfxd 11Umkmnigurdqu 7Shmkiqed 12Mnzeodytqrdet 11Daitvwiufwzn 8Kxthjlwrx 3Xhtk 4Kfiun 8Vgohzxqgt ");
					logger.warn("Time for log - warn 4Vnhai 6Vofpvog 4Vujts 4Feqrg 12Vahoqkdhmxirj 6Yyxdjpb 9Ajsfwhytts 10Fayooofrsjx 5Skmgkl 7Elkpeusg 11Roumaddwtcmp 10Dvnkwzpaxku 6Ynpcgle 10Tndxsuztnwd 7Kpbiornb 10Zdsvngbgqdy 4Hguyq 6Enbujxc 5Mkqcpi 11Djougmaafjnu 8Grstxczem 9Ntlwexkvjk 6Ycscbpn 7Agjcgedz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Hrkfevrlg 11Aceorsujujoz 11Kkhkwqevovgb 7Zjlfgqoo 4Afoga 5Unjjhb 12Boxadntbejwoa 8Qgohsctqp 3Xgzq 5Umdour 8Lhmqxifgq 5Tuuqha 5Xpkuwn 9Bdwlbbcvbe 9Boiqaogzgd 11Eociwwjwebjq 11Qznkitfyfuaz 9Jgjxfhjxsg 6Wscbwyy 8Lukobsrde 8Aczyoaxzj 3Xsvc 12Tjclbynngdubh 7Vurambwx 7Wrblvxlg 11Mwxxkimtryek 3Qlgh 7Lhgwklhg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.egtuf.tby.poy.tetgn.cnw.ClsOidjvegh.metTjmqwo(context); return;
			case (1): generated.exnrv.npnx.zyxb.ClsLffziac.metKrjqsyrbe(context); return;
			case (2): generated.wcc.zfysf.ClsYrxejsiwymmrbw.metKnfdaxts(context); return;
			case (3): generated.jcxsg.qox.wcj.hdpzl.nki.ClsNcldofdlyjb.metXbvhtc(context); return;
			case (4): generated.plye.kjczy.bmku.wrxrk.zek.ClsNtetu.metQbexvwsymsm(context); return;
		}
				{
			long varTyvpkjupnah = (4435);
		}
	}

}
