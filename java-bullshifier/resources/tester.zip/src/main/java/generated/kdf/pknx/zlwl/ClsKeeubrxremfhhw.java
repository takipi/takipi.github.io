package generated.kdf.pknx.zlwl;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsKeeubrxremfhhw
{
	 public static final int classId = 277;
	 static final Logger logger = LoggerFactory.getLogger(ClsKeeubrxremfhhw.class);

	public static void metOxjieq(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valYukdrdnzobl = new LinkedList<Object>();
		List<Object> valDnljqxsfgca = new LinkedList<Object>();
		String valLxdquhlowbo = "StrSmjtynhdevj";
		
		valDnljqxsfgca.add(valLxdquhlowbo);
		boolean valWzwhmnqmcci = true;
		
		valDnljqxsfgca.add(valWzwhmnqmcci);
		
		valYukdrdnzobl.add(valDnljqxsfgca);
		List<Object> valPvovzqqcxcu = new LinkedList<Object>();
		int valDhbhiycyygk = 747;
		
		valPvovzqqcxcu.add(valDhbhiycyygk);
		long valFcczziyueml = 4188370657054153787L;
		
		valPvovzqqcxcu.add(valFcczziyueml);
		
		valYukdrdnzobl.add(valPvovzqqcxcu);
		
		root.add(valYukdrdnzobl);
		Set<Object> valBrwcshlrbbv = new HashSet<Object>();
		Set<Object> valMqtmgvihzga = new HashSet<Object>();
		boolean valBscnwuuodsx = false;
		
		valMqtmgvihzga.add(valBscnwuuodsx);
		String valHbploskpflh = "StrOigpeaaqryg";
		
		valMqtmgvihzga.add(valHbploskpflh);
		
		valBrwcshlrbbv.add(valMqtmgvihzga);
		
		root.add(valBrwcshlrbbv);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Zpzhvbpsnnxzr 9Shvdzxrglh 8Dhnhuguuo 3Pwqn 11Pcpjuwajjoeu 12Dhzapfsgmvqhy ");
					logger.info("Time for log - info 11Fpiasbghcnzq 12Tfjykrooxqoac 8Cptqmbuyk 10Qnzhvdbiwhb 9Kdkeiqpwlv 6Dqvekle 12Wcrywhyctyugu ");
					logger.info("Time for log - info 7Jmtnxflr 9Mlwfxkybsy ");
					logger.info("Time for log - info 5Cpbfbh 5Whimie 6Qofpxzb 6Rrfoacv 11Lmpzirhcvnkx 3Ijyv 6Ffkulrz 9Lnkdzvrtts 3Okpw 6Svfwjgt 7Vgkdyrxp 7Nffisfko 7Aystjhrg 10Rljxulmnvzo 8Liijtnrut 6Iqfwvtt 12Lopmaobrlxkbg 10Nzhtinivazh 3Pacj 3Jbdt 12Avkyovpfybrhz 4Qdglc 5Jtevki 10Dywtqwcault 7Zucqjonz ");
					logger.info("Time for log - info 10Jpkruedufqq 6Hmmzmrv 10Qafnolvnllt 12Egryrztefnyhh 5Onrqoj 10Lfosxslubtx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Xvijsbk 7Bhtzbyqa 8Xfygovtqy 3Kljc 7Pyedvbia 8Mmaovuksr 7Hxhvzxtf 8Yyghvmsfa 12Tbrijehoevhjw 9Qwoyipjpto 11Tisqccsyognf 11Cdjsumucqmxv 5Dudhum 9Evlqrgnuwk 4Vlkgj 11Risohkztaspb 12Swwpkmoxywmeo 6Nexsvho 8Ntdnimmri 8Bmknflzfu 9Kkpdofsoop 4Bwfbe 9Inshlatdac ");
					logger.warn("Time for log - warn 4Zzhbr 9Bqtvldaywf 8Jxxtuvfjg 5Tszgpw 3Frzx 7Wjvecuny 3Phky 10Hjpwchlwenm 12Drfwggfbttsdj 4Rjzhq 3Pybl 7Gtmsidiu 5Kusxdv 6Wthbgmc 6Ibwhqbn 12Bfdiaxcuivdys 12Btrtuotjylxcx 7Oqloysej 7Nowmzdog 4Ilagi 11Lncwywqxkidj ");
					logger.warn("Time for log - warn 4Xzbor 8Grwaxmyvh 4Ygaao 6Qkgdzla 5Vytowm ");
					logger.warn("Time for log - warn 12Ujfzbiumgrnge 7Kjjovvsx 11Bgeqqjyqrjty 4Ixwaz 8Oxnqhheqp 3Keat 5Tcvtsg 6Lckpawe 9Jrgbseohke 4Ldoua 11Efsiyhwbitix 4Qpten 7Fmjgxjqy 4Fvhhy 5Xfqqqg ");
					logger.warn("Time for log - warn 7Fnrdtaxh 11Sgjbaknudpri 11Rxlvawrbxddu 8Rsxxywhtl 6Bckgzlb 4Crvof 8Emtvzbevt 9Azpxyuukhl 6Whfgwja 10Gvicscdksrb 6Fxjiprz 8Ghwccsose 4Bjoxo 7Ecofvhmh 12Detharynhescm 9Qgnccqbjou 3Kqhl 9Isapzoxuti 11Mpojpjgrioqg 9Ncscltztkq 3Ouuk 12Corrjtilzlrbt 3Shjl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Eznw 3Guxu ");
					logger.error("Time for log - error 11Jfecxgcajflm 10Qfkckrxiwch 10Nfodubsohaf 5Slrshc 5Jlqyhz 10Njwcydkften 7Csfkpvtw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
			case (1): generated.zdmfw.qfic.ClsQmanwrctuzecr.metEvpjjip(context); return;
			case (2): generated.tmb.nbu.txg.feeq.pmbxg.ClsRpabqs.metVvwhfdzbbnjnmg(context); return;
			case (3): generated.cpb.wnddu.ClsLvopzbmgvjj.metJpplktwh(context); return;
			case (4): generated.lgws.kxkr.zse.myye.ClsAnryfbudqi.metYtmxrfk(context); return;
		}
				{
			int loopIndex24801 = 0;
			for (loopIndex24801 = 0; loopIndex24801 < 203; loopIndex24801++)
			{
				java.io.File file = new java.io.File("/dirEphwcpglzjz/dirUyqhjhnfaeu/dirAbuyhdxcjgk/dirHlwfdrnbciy/dirNskyxgurwmm/dirSsiqskenhyv/dirCotiowwhcmk/dirWsgxqluigce/dirGgnvrkwgucp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metSoxbamiezrzd(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valWplgtxqnzmz = new HashMap();
		Map<Object, Object> mapValGknvzqzmisu = new HashMap();
		String mapValMivpenedznf = "StrEwyokgeevdy";
		
		int mapKeyGrtkxihljun = 871;
		
		mapValGknvzqzmisu.put("mapValMivpenedznf","mapKeyGrtkxihljun" );
		
		Set<Object> mapKeyFposamdtqnn = new HashSet<Object>();
		int valJqahcqylclf = 190;
		
		mapKeyFposamdtqnn.add(valJqahcqylclf);
		boolean valVmmaafqgmpz = false;
		
		mapKeyFposamdtqnn.add(valVmmaafqgmpz);
		
		valWplgtxqnzmz.put("mapValGknvzqzmisu","mapKeyFposamdtqnn" );
		
		root.add(valWplgtxqnzmz);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Bvhz 11Quhkfdfbnhuv 10Lewofmtaroh 11Crddjrsbdaxb 4Xdegf 11Lyijncbaonbh 11Dvcrjcenkftq 8Bynmuwjew 4Vapyx 7Ppxthibo 9Cehdaaipqg 10Mbpjzdguycr 12Xuhrtwcyvdbvd 7Mgkkfecc 3Drqf 3Zmkc 10Rpukmwbttph 11Nhvezdqpjgul 9Bdrtybcdyy 3Qnlj 4Quaxi 8Lkdzqcjmj 5Eybbgm 3Rufg 7Xlbickel ");
					logger.warn("Time for log - warn 10Spemmmkxboq 11Ntcnnjwawfgy 9Ovszuvdayw 9Lsxeasztky 10Bfiuvbshumr 12Nrqexiphbbjic 3Xtfa 11Baxkuzdgcctd 11Rbssydqmksph 7Oskbtsho 5Epigwq 11Kijdflpuccyh 9Dghdxxiskh 4Iyrha 9Ikclpkqejt 11Rtwxxhpfyogf 4Tlcir 5Xigayb 9Pujbvmduah 12Hobibucbukltg 8Enksztbld 3Fryw 9Dxqbcimxot 7Kyymwrhb ");
					logger.warn("Time for log - warn 6Zavrdfn 6Ucjxlix 7Ppbepxvc 8Txqjomdjg 7Ehhamvri 12Awpypiltwklvn 11Xrxpaoeyfrxs 9Eufztbpoeo 11Jsizymchjqbj 3Oxnr 8Dmtegkebv 8Wcrakormr 10Iueyalakjkd 7Pbjgflvw ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Pfnjbvaijjeft 10Cgubuzgknnh 10Nwdrsckdzty 6Gbzudta 10Gfqawdgzxol 4Zpjnk 12Apbsylwnazeun 9Mzteskhsqo 5Difysd 7Euagawco 4Elcfw 6Gezorps 12Yzudcyoqbrbrs 4Uvirt 10Xsbbrszjjgp 5Tafzdt 4Zxxwz 3Gfqt 12Yiavfhquqlocv 8Zngremqvd 8Lparnzlzp 11Pgtyhfrvuxzq 8Bqggpbwzg 6Yaddyxb 3Qibd ");
					logger.error("Time for log - error 8Tqprdtchg 8Ikanpmixf 4Aftms 3Tvls 10Mxnjgfynrxk 10Agiddwdhgpc 9Wxuqpclrmr 6Tgxxtux 3Rotb 7Qhylpoxl 3Xnir 3Jdgc 10Fzmyqkpblhp 3Tcuz 7Hnutbxon 12Vqcltkvsgbpmj 5Zeezgv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ahr.cnut.ztcbc.ClsUicrpogixv.metNaysjnfmv(context); return;
			case (1): generated.livfd.xzg.uuzce.mske.ClsRchbllfcclbcum.metEtgfstyazysxtu(context); return;
			case (2): generated.svrd.bbp.ClsZenal.metIcwqskzzdn(context); return;
			case (3): generated.cqy.ffep.ClsWvinhicphnl.metWwbnpyd(context); return;
			case (4): generated.owqo.mlfkn.xvo.nivs.zcmac.ClsNuoghbmezp.metDtgdmwp(context); return;
		}
				{
		}
	}

}
