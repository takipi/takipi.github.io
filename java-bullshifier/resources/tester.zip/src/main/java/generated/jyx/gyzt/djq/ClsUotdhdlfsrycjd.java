package generated.jyx.gyzt.djq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsUotdhdlfsrycjd
{
	 public static final int classId = 262;
	 static final Logger logger = LoggerFactory.getLogger(ClsUotdhdlfsrycjd.class);

	public static void metSxrrezlofh(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValIlkkhdlvgds = new LinkedList<Object>();
		Set<Object> valPvbzzywnthw = new HashSet<Object>();
		int valFeeftnhqyyb = 294;
		
		valPvbzzywnthw.add(valFeeftnhqyyb);
		
		mapValIlkkhdlvgds.add(valPvbzzywnthw);
		List<Object> valQasfizhygdz = new LinkedList<Object>();
		int valAtlcijpzlxe = 421;
		
		valQasfizhygdz.add(valAtlcijpzlxe);
		String valRziyautusqt = "StrXwswkxxxbtr";
		
		valQasfizhygdz.add(valRziyautusqt);
		
		mapValIlkkhdlvgds.add(valQasfizhygdz);
		
		Set<Object> mapKeyScdnelyxgqr = new HashSet<Object>();
		List<Object> valKudbtgfzvkv = new LinkedList<Object>();
		boolean valXbvjfdwzfdd = false;
		
		valKudbtgfzvkv.add(valXbvjfdwzfdd);
		long valGrsawiyqllg = -4729831691431126121L;
		
		valKudbtgfzvkv.add(valGrsawiyqllg);
		
		mapKeyScdnelyxgqr.add(valKudbtgfzvkv);
		
		root.put("mapValIlkkhdlvgds","mapKeyScdnelyxgqr" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Frztubcjjkow 11Rlzhnhjvqqmo 11Lratgmjggtpy 4Gxafx 3Ubkx 11Qgbtbcjwsfzg 8Egsedpqgo 4Zgfoh 11Vqzrbyqzmcnh 12Kfzbrrjplugyb 12Ccryshbibcass 4Zspzk 5Nlzkrc 12Qsvopdedhtyqe 5Hsrhzx 10Ybetftsihzh 5Maunrv 8Bhobwsvoy 10Vswgjelgpch 7Cwlzylvn 8Irxtcofhn 11Clsmmbattuwx 5Dmgosp 12Dornmzzjfvqnz 9Zibppwqudv 11Emjjpqjnaftb 6Hjeadpu 11Iwgpdkaepdvu 9Lxvnlgnhxq 10Yauhpbkzvgz 6Nbuznvi ");
					logger.info("Time for log - info 8Gikpyvfho 6Qveqoye 11Xtllscyojufe 7Fbhaqfhq 4Ikdiz 5Oqmdnh 10Ywsdoifgpdz 10Gytlkhovedq 5Nwegww 5Vygbgg ");
					logger.info("Time for log - info 8Fvwzcfdtk 5Yvuhrg 6Jssynbt 9Nyolizlend ");
					logger.info("Time for log - info 4Hlqjo 9Ynvnyjfsko 6Lyospwn 4Nykgy 9Napwzxgjvl 12Acwsgigxrabfy 6Zcfnomz 8Meikzijdi 11Iuxlcxqsruvg 3Mewz 11Eupmygzhpktd 9Akrgndzcet 9Vvhdbkqckp 8Hwdjtzwss 4Jvjgg 12Auyirwepfjnyx 9Aigmunjpvf 3Adax 11Ncleksfiffyy 8Ljdfhkbdr 4Hqfwb 8Djentcvqf 5Fxfrea 6Awntwxy 12Yrtnnvlzmtyeu ");
					logger.info("Time for log - info 12Cgbovwmcybzjy 10Ubmpbgqazsg 9Jgevxakeyq 3Tfeu 9Ksobthldpl 11Gywrntmviygw 4Uwpia 3Aksv 5Dzjbpm 8Lqcbbozxi 9Wbussvdybw 10Owbmsfmvfxz 3Jpas 9Lntrxyecxg 9Mlpoojhvjr 9Vgikrtupmk 7Jdeqqstz 4Mssvw 10Vjzaxunquuq 7Rhaalxkc 7Hlgnglaq 6Vgjecjw 5Mmruan 11Zxrwskwnifre 3Hdgx 5Tigovl 9Nvsitqabbm 9Pofrmpidst 3Qifj 5Gmsxda 12Abcjpaojqaaey ");
					logger.info("Time for log - info 4Wkjjo 12Gagqujdtqanzs 4Phdgd 4Pyiyd 9Lqvueefwnf 9Uevwtqlipx 9Yktrmqytdv 6Nvvixvr 4Cmtvw 9Pccxtxjsce 9Stycclycfj 8Ykbbgaxvs 7Ikjbhfea 7Tsufwddt 11Kybchlssrixs 7Grszpkwp 11Olqetjcthxbm 12Xakpbnazstutt 12Lyyqdjtgrervv 6Palhkpp 8Ynpzbdkuu 11Rnfdhyodhpvi 5Psxtsn 10Byridkvsnun ");
					logger.info("Time for log - info 10Blceefasfbn 4Obkhc 6Ekckeot 3Uajh 6Mitobkl 11Pzkmfiibgwrd 6Wldywbn ");
					logger.info("Time for log - info 6Gwrhxtn 10Tkufeebjelk 5Itjiqq 12Iwfhmwnlokjlu 7Pfcmkaln 9Tauutqkkus 3Nmdr 4Mqtyp 4Nrbpk 11Qdaepwabpggd 12Tpnjlicegtpkf 5Ivcslp 11Hwecozogitgo 7Xcywqvkp 7Mdbhcijr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Gtlildct 7Iahipfht 12Qfmqmsjjvtcrs 9Kzcchhrkkh 8Vgswkpnzn 8Fmtcqxsex 10Vzcekkjlwvk 9Vopzbggwuh 6Lftbqiw 9Hnqayrstgd 12Fixvfyemqgrnb 8Ijpodpzgy 12Zwwiceniscdme 10Wmpergsqxna 11Ifhgcunvhudl 12Avnnyuhjnhjgk 8Qbrqecvkw 12Tojeadvgrzeys ");
					logger.warn("Time for log - warn 4Oicta 5Pvitcv 10Ryhaykcwdcc 3Iemy 4Qapif 9Foomdsadgg 7Cwjckzir 8Qfjygktee 12Tykvxnlemdfuq 9Gdpycryrxc 11Drqbzfttovou 5Srzmfv 11Hcskdyhppzcg 4Wsjef ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hehz.xzg.akn.rdsvf.ClsKsukcv.metIqhal(context); return;
			case (1): generated.zmpxh.humct.jpc.zcr.uswj.ClsMmunby.metAhzyvaxwwvb(context); return;
			case (2): generated.vqvzb.mlzv.dxgr.ClsUgxxgr.metEqbgkl(context); return;
			case (3): generated.tvv.ioy.ClsEqfmidfypp.metObdbtlzhg(context); return;
			case (4): generated.qllkh.klb.qyy.ClsQoiukvt.metLuzzruyzhoym(context); return;
		}
				{
		}
	}


	public static void metIkkxju(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valGtpspevbmzx = new Object[7];
		Object[] valFbuuhubwxif = new Object[7];
		String valLszfcorppmz = "StrYymnwyemgyc";
		
		    valFbuuhubwxif[0] = valLszfcorppmz;
		for (int i = 1; i < 7; i++)
		{
		    valFbuuhubwxif[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valGtpspevbmzx[0] = valFbuuhubwxif;
		for (int i = 1; i < 7; i++)
		{
		    valGtpspevbmzx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valGtpspevbmzx);
		Map<Object, Object> valMxntuaqignh = new HashMap();
		List<Object> mapValVwkilhaqxma = new LinkedList<Object>();
		boolean valWsagiiidkrq = false;
		
		mapValVwkilhaqxma.add(valWsagiiidkrq);
		
		Object[] mapKeyJskhhratpbm = new Object[2];
		boolean valUfpmhbauuog = true;
		
		    mapKeyJskhhratpbm[0] = valUfpmhbauuog;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyJskhhratpbm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valMxntuaqignh.put("mapValVwkilhaqxma","mapKeyJskhhratpbm" );
		Object[] mapValVdremgjlfpv = new Object[6];
		int valCpwslkjzuhv = 309;
		
		    mapValVdremgjlfpv[0] = valCpwslkjzuhv;
		for (int i = 1; i < 6; i++)
		{
		    mapValVdremgjlfpv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyEcvtnhbnnqp = new HashMap();
		String mapValXszmzmxxnsh = "StrYfnhtqkkrqc";
		
		long mapKeyUdmdmtspnws = 5266074973203757635L;
		
		mapKeyEcvtnhbnnqp.put("mapValXszmzmxxnsh","mapKeyUdmdmtspnws" );
		long mapValHgfhlnqspse = 5860311985586076713L;
		
		int mapKeyRhucuockirq = 921;
		
		mapKeyEcvtnhbnnqp.put("mapValHgfhlnqspse","mapKeyRhucuockirq" );
		
		valMxntuaqignh.put("mapValVdremgjlfpv","mapKeyEcvtnhbnnqp" );
		
		root.add(valMxntuaqignh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Akrfjyxazu 8Hwoydbrdm 12Xtjjusaqcsxtd 7Dopguols 8Kzzupspbw 3Nlll 9Mhnovdmgnh 12Oddvoajecmbgn 10Ibpgvusfbiz 6Vyryryw 10Pfysxjjyjrf 11Hxtvrabrdpnq 5Wmiopo 9Veuvpgehyp 12Nbdeuuvortvkc 7Spmolbnz 11Rznwpmesisyg 4Kdjkp 4Elcor 7Tqwgkhyk 4Nreiy 7Cvoiiyef 9Wqszmwoyaa ");
					logger.info("Time for log - info 9Ajerapmpjq 6Cebykzk 9Dzpoamevkv 6Hqznqrz 4Pwryo 3Onpj 6Txlygxw 3Tujn 10Glsfpesxwnn 3Knid 10Wvcfmnliwbv 10Ogjgymuugfh 8Syjjawgkw ");
					logger.info("Time for log - info 6Pdwczcg 4Zomvd 5Mmkzuz 12Agfyttkoqwtqc 3Dxew 5Cpufbk 9Qjxkoenhda 3Gtiq 5Weebih 3Aham 9Mtpniyxrfo 9Zzjltnfrvj 9Gyzeubtzqp 3Gxdj 9Jrfjoppphu 9Hpspabbaor 4Hiuat 10Yrnfsdwutmi 8Ujueaythj 11Dqnluekbviki ");
					logger.info("Time for log - info 3Vgyz 9Wjwdfaypyg 7Jumjxztx 5Cqrwtt 12Ppmtgqvyjlxpq 6Tpydcmk 10Bhfuyxgsoqu 12Vivseediipcbq 3Uwnq 6Djinzhl 10Ghmigdclnsz 4Wjkpr 4Zjxgi 12Yzpkaekgcojmg 8Mbvwktyjh 3Iifo 7Zibvvtyp 8Akkodugwt 11Rpgzypaofcrp 8Twddpiuff 4Lfzuo 8Czayvmyho 11Hebfscpkvubw 5Jdjpch 12Svojyhuvykfqe 11Tpwqawuvnccd 11Ojswtkxwvlzn 4Fpqyi 8Eqtddaywp 9Tgvqwmosht 12Zrvucmzwormve ");
					logger.info("Time for log - info 12Nhgejxptanbnu 9Itpnudodpw 4Sniys 10Amjvybeouyh 5Gkbcyd 9Dmdmzmsqxx ");
					logger.info("Time for log - info 6Bxbmbyx 6Ndcshxz 5Nzrnth 9Zfzxlamecz 3Qmwt 9Adujqyrvqc 11Ocgqqhrlcctp 12Sxnlcawddihea 3Ysgi 4Gxuxh 12Jbqreoxlaccrv 5Myuxkl 6Kscdyou 8Mzdrrnfrh 9Ginkwyyoti 11Ahwuhaltgefv 10Jpzqhhmeagz 9Mvoyqsvubr 12Dsrqnpmrpoqmw 11Gohnoxakasfb 6Tvjfbdm 10Dueuskfuzaj 9Zybszffiwf 8Mcyylkrii 5Nlakwy 3Uuxy 12Sbqvsehjjvqig ");
					logger.info("Time for log - info 8Jockpxwsh 11Egtjghzcqdtc 10Lwjauhdgcqm 11Nbyknawpoged 3Vyxr 12Eqoquifusjrag 4Cbdoi 10Guczxyqkyvv 4Biyxo 6Xgsmyss 12Iavqgydjudetj 9Vtyrdanxvs 4Doxfm 10Bjjxovpplfd 11Suyfeaqvnfis 4Dyrhq 8Noguipjbc 8Epdgaeruc 12Lvjhnrmmlbxqh 4Iurhk 7Yepcpnio 8Sbkfvbhbk 4Rqnya 6Tbcvmsw 12Hzzvzjhwtpmsl 12Akkoohehxitpg 5Wqilqh 7Zektgovg 11Wubuefijymvc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Bkaowpmdaje 3Unzh 3Ddnt 8Ursdltmue 7Ozwyfhig 6Sxgskpw 5Cjdjdw 8Cvppumekz 8Tpnidtfjm 7Thfgxvbe 3Pool 7Vghtawum 8Byhjdzszm 12Zccncxbmgqkwa 11Evuwgdfawuqn 8Zlpspdarq 7Foixvypq 10Jloezyudkaz 5Mpckuk 4Msfuq 9Dknaqzjffd 4Rdasp 9Xkbmegamvx 5Wewhrv 11Lcvvsbksipnv ");
					logger.warn("Time for log - warn 4Usajn 5Wbtxlk 10Tgndkpigewu 7Bihjziju 4Wliqe 5Tkgzwd 10Ztwxizzhlit 9Bqnogffozo 6Aiirrxp 10Srtpmuraimg 8Wkoowpeyy 9Uxfacfswmo 5Swjsbi 11Zxqwvyuvsgri 3Kmro 8Givewryni 9Zjkhauplxz 5Czugqf 10Efddbzzrpiq ");
					logger.warn("Time for log - warn 11Bcrwkncbdcsz 11Deudtesmiwmi 10Lbrjsmjnbrk 9Wrlxwwyrnt 12Bxkfdlkcqvkox 5Xhzhwo 10Agmhgncozof 9Icdhvpmuze 7Fwohwvtk 6Styzzma 3Lcfc 3Tzgt 9Ntdssffocs 4Bmplj 5Isfzpu 11Ultfvjzadxlt 8Jzctxoohp 9Arlzasqong 11Rkhbjqheyktq 4Qimof 7Tzbpfyva 5Ictekm 11Aotbtdzxzalq 9Kibdhsubzi 5Rfwpsa 8Omoyyytgq 8Ybvpcbmlj 4Gamvo 8Uokfepnwj 3Gdsl 10Glkxxgaaxzj ");
					logger.warn("Time for log - warn 9Plqbhssoor 6Hqgzttv 3Ihnl 5Orgeag 3Caua 9Gnzyofhejn 8Regebszho 4Zwlsf 9Vzehnlantf 12Nafvlodpdyhdj 8Cgymskhxi 7Exolezou 10Tdixikzkjlf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Hsrtxwyuiqo 3Srqh 8Nfjwnsrps 8Tfpwopgsv 4Ehplk ");
					logger.error("Time for log - error 4Brlft 3Dgft 11Szsvvgoozqas 3Ejoj 11Oogdsgqrykpn 6Tuqrndz 8Ialmcijau 9Hgawoxphrk 12Oekqzhpsiugfs ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bkbep.bjvph.skry.qijli.gfl.ClsFlycqobnxjszt.metGocmomhxeq(context); return;
			case (1): generated.hbqjp.kifli.leg.jlyd.ClsYgtwztbknhdmc.metHsrmkfyvnv(context); return;
			case (2): generated.qikh.hgtag.amhgk.ClsEpqxnohalceif.metUhwjekipowr(context); return;
			case (3): generated.rkfhx.ntcs.qoe.lasd.nzzym.ClsDftkqmvmp.metEliwmlxsgnolka(context); return;
			case (4): generated.bcbrr.mrpx.ClsJcswauwrr.metIydcpeyrd(context); return;
		}
				{
			long varEoiwvjvmcoh = (Config.get().getRandom().nextInt(120) + 8);
			long whileIndex24555 = 0;
			
			while (whileIndex24555-- > 0)
			{
				java.io.File file = new java.io.File("/dirVxkfskqrsuv/dirIpljvienunq/dirNpbwejqluos/dirFdrjfjqtmvj/dirAflyhjmhdbg/dirLgtzprntzmg/dirZvquxypdugj/dirWvzafkaigji");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metYizmohxnia(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valMuemkizmjit = new HashSet<Object>();
		Object[] valYeyqekfgvou = new Object[5];
		long valDekikzbmvpj = -8957827865593242820L;
		
		    valYeyqekfgvou[0] = valDekikzbmvpj;
		for (int i = 1; i < 5; i++)
		{
		    valYeyqekfgvou[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valMuemkizmjit.add(valYeyqekfgvou);
		List<Object> valRgzzliecbdx = new LinkedList<Object>();
		int valKdfuykdepme = 895;
		
		valRgzzliecbdx.add(valKdfuykdepme);
		
		valMuemkizmjit.add(valRgzzliecbdx);
		
		root.add(valMuemkizmjit);
		Set<Object> valFetnkvjzyvn = new HashSet<Object>();
		Map<Object, Object> valXlbaheayvnn = new HashMap();
		int mapValJcrbplhllil = 788;
		
		int mapKeyWisfgjyyiim = 378;
		
		valXlbaheayvnn.put("mapValJcrbplhllil","mapKeyWisfgjyyiim" );
		
		valFetnkvjzyvn.add(valXlbaheayvnn);
		
		root.add(valFetnkvjzyvn);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Jpmwqc 8Ruabmgxxv 7Eubchiju 10Miqaiwigxdr 3Cvgi 4Jccfu 3Lyuy 7Rqhvkjvu 10Selskfhpdzt 12Vbdulhwvsyvys 4Fnlxk 12Oogldzonjdojh 6Jlmxlcm 4Obpic 3Wpaq 9Qhkzeatflj 5Lldkia 10Celliyucqfo 5Tnguqv 6Xminupi 4Cxpzw 12Fzpdjfaowzwjq 10Fsiraniqcjr 3Rxbr ");
					logger.info("Time for log - info 5Pkbizv 9Tocwhlxylx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Fzkzoulkls 11Jspqrmegcddl 8Krqegdiqg 10Mzwdjmtzcib 10Tzgvvfbmrvx 4Tclsv 7Dxqftmxt 5Qgdxiz 11Acysczardrpq 9Xmtprmuxxa 9Ortdfctlaj ");
					logger.warn("Time for log - warn 9Lgthgwumcy 7Pghpbdsp 3Ycrg 10Syjoerkitey 3Qhlo 12Tpxyfbnpxnvza 7Cjvkydoa 6Jksrnlk 10Rtqxzjofcai 7Wxvhhayq 11Pektogasjotn ");
					logger.warn("Time for log - warn 11Jutbnfwfeadh 10Aiwrwqfdpzu 11Milbfvmdnzsa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Ttgsmoz 4Ymfjh 9Fyvqpddpgs 9Zckpsljjfw 8Lzoqieoie 11Iowgqlfohuoz 3Xywb 9Qcmguizgju 4Mgfit 6Vverqqr 4Emzls 4Flcnf 10Ceucdphbwxq 12Oiokwhmcaywkz 8Vkbbqaeov 7Dgkrexbp 3Zbty 11Hxzpllhrviue 10Nekpemsrayf 4Tcskc 5Wkxfpk 5Vpplyx 4Nxsxl 8Bykxgbboy 8Uiutwqpzf 9Quaveyvezy 7Ukynuyra ");
					logger.error("Time for log - error 6Edicvdi 8Ehutsocop 3Mnpo 11Vdvwubpqauyi 10Ociaxhgmohz 5Ckbpfy 4Jqfwx 10Ywevityqvje 3Zdmw 6Paswomc 7Lslhvoen 5Nvoabu 3Xseu 8Awahfnpoe 6Sbdohgi 4Gjbgp 3Ihfz 3Tetz 3Bfbr 3Giqt 8Yqnfqsfcx 9Ivlgjawqfi 12Edekkisdcvdtf 11Yygsftdjjojm 5Dcnsid 11Hbfktgzoenuk ");
					logger.error("Time for log - error 10Naotxbhakhf 6Ntoqoom 5Nfkimd 11Vyqukaqqejku 11Hkesnqooufjw 12Sbprsimzegsjc 10Wuwbftfmsoc 5Cksscp 5Avfjwl 3Plqt 7Wtbvdreu 3Jtny 4Kyrcb 12Pninwkvtybomr 8Wzcdpgixr 10Hxuafjbfzel 8Stbfmsmes 3Kimt 11Wmyxdonasjdd 3Dbsr 10Ewghyntxwcy 11Uzctaqogsoaa 3Mmfc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kklo.eog.twpb.eja.vmrt.ClsCtkkdlrnk.metMzowgzzffz(context); return;
			case (1): generated.byxi.uzy.rgdf.nzlsj.fbg.ClsCwwdznsfknncdl.metRvqiqhyiwopqx(context); return;
			case (2): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metEqiixejyhymhk(context); return;
			case (3): generated.svrd.bbp.ClsZenal.metIcwqskzzdn(context); return;
			case (4): generated.rsu.hmuld.jzssz.bjyy.fod.ClsQixayqsiydaxm.metIpckuqrkv(context); return;
		}
				{
			if (((152) % 213060) == 0)
			{
				try
				{
					Integer.parseInt("numHmljzerifmp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((4538) - (9106) % 150292) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirIfhjjfkquni/dirDdxtopsvpzz/dirBvbiaqsvpjf/dirTahxwmrtqsr/dirFpuatpfzulp/dirBsffsexsxgr/dirDdwrpsctemq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex24559 = 0;
			for (loopIndex24559 = 0; loopIndex24559 < 4540; loopIndex24559++)
			{
				try
				{
					Integer.parseInt("numBnlgxgxanxg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numFdmolyzswvj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
