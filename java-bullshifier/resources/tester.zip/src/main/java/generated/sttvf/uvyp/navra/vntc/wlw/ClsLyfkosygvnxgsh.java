package generated.sttvf.uvyp.navra.vntc.wlw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsLyfkosygvnxgsh
{
	 public static final int classId = 205;
	 static final Logger logger = LoggerFactory.getLogger(ClsLyfkosygvnxgsh.class);

	public static void metWdbuefks(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValUgboimqzdxm = new HashSet<Object>();
		Object[] valTniabesjdov = new Object[7];
		boolean valKuoneaoqaet = true;
		
		    valTniabesjdov[0] = valKuoneaoqaet;
		for (int i = 1; i < 7; i++)
		{
		    valTniabesjdov[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValUgboimqzdxm.add(valTniabesjdov);
		Map<Object, Object> valZpasyxjypku = new HashMap();
		String mapValDtqtzzztqmt = "StrSibrqaitkel";
		
		int mapKeyRwfdynpeyri = 145;
		
		valZpasyxjypku.put("mapValDtqtzzztqmt","mapKeyRwfdynpeyri" );
		int mapValSgflmndwfza = 754;
		
		long mapKeyWpusgpjwhqu = -571815355322521083L;
		
		valZpasyxjypku.put("mapValSgflmndwfza","mapKeyWpusgpjwhqu" );
		
		mapValUgboimqzdxm.add(valZpasyxjypku);
		
		Set<Object> mapKeyOfeibhdmwrm = new HashSet<Object>();
		Map<Object, Object> valQpysefcbzwf = new HashMap();
		boolean mapValKnkaylhdtom = true;
		
		int mapKeyUnilziptobm = 704;
		
		valQpysefcbzwf.put("mapValKnkaylhdtom","mapKeyUnilziptobm" );
		
		mapKeyOfeibhdmwrm.add(valQpysefcbzwf);
		Map<Object, Object> valIrvqcatezrc = new HashMap();
		int mapValUhnnahftbhl = 636;
		
		long mapKeyAboksuqulvp = -2600121141726915521L;
		
		valIrvqcatezrc.put("mapValUhnnahftbhl","mapKeyAboksuqulvp" );
		
		mapKeyOfeibhdmwrm.add(valIrvqcatezrc);
		
		root.put("mapValUgboimqzdxm","mapKeyOfeibhdmwrm" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Evxoslvo 3Vbow 3Kbxe 3Kuyn 8Bqvxmyerc 8Mbvsvddic 11Ithptseebgxm 10Mufylkezqns 9Gzjhpxwuxd 6Gtvlyoc 5Obixcx 3Czwi 12Rmjeuinitbpza ");
					logger.info("Time for log - info 8Plsoakazc 8Huckvcnbc 10Vnjhmymbolc 3Ydzn 12Ebszhrbecrhlw 12Fikfaujmqcddr 5Dbrpug 5Raphgq 7Hrtulbyn 12Ywsgaulbzglxw 8Iciqggkiy 7Xcowmqdb 11Nthgiegmoklf 4Ogppy ");
					logger.info("Time for log - info 11Ibudcbqgrqbh 11Wgfdxkfcolsb 6Xbaffco 5Uogrna 8Qzzalfybo 12Cuyopkfgavifc 3Rehp 12Jtoxyrlpiifqu 3Ysng 3Momt ");
					logger.info("Time for log - info 8Zxzhkaehr 12Misvhzpranzaw 6Kkrgfog 3Xevw 11Zcaouthfiywm 11Armpipzxmben 8Wuwjdhpbp 10Cicvsnxxnlj 6Ztgpfmq 6Ojmghrz 10Qllgxjfpjfu 11Geghvsgyupdw 12Wpeaveobjiobh 12Fcyultopdiohr 7Zedzzxxq 10Btujalwptqu 8Ziqdwmrpv 7Lqdioemy ");
					logger.info("Time for log - info 5Motsxc 8Npcseblql 8Hpsmtfrol 4Xvpcz 6Dgnjvqf 8Fxhnewdww 10Xdmjvtgyzay 11Kriefdfawmzr 7Znrvxyry 8Vwuvixuni 5Xdeioz 12Nrlmrrbwcmzyv 8Usmzfgdsd 7Fimqptlj 5Zbrvoc 6Xgzalyg 9Vyeduntdso 8Cngqkwykx 5Sbibzo 9Fumggznfiy 7Lqsiskvu 10Hextoologcb 6Fwveimt 11Lqtvtpwnzfzc 9Ittglqzcbg 10Lodbdwajzrs 4Otvge 6Qqqbagy 4Cqadh ");
					logger.info("Time for log - info 12Iifciphormiio 12Lfxygxdpzvzrk ");
					logger.info("Time for log - info 8Mhcdxxggv 12Euowcyahbopsv 12Qyetfpwefcfgp 4Tsbqt 9Fyxstzksyo 5Kptlgf 9Mkotutiqqc 4Igczn 3Ioiu 5Rhftij 5Qecpau 10Xcndkfhxzyx 9Shgdtudfly 9Pyfliodrcd 10Ibbgivzasam 10Zylixjtckor 9Csgseogmcb 5Fvnkkx 8Ybnplygwh 3Atni 3Zgkn 9Kjxjgdukru 12Fnzqpydrmkzrp 4Ntgom 6Ysavjxg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Agic 3Huau 4Hgpwv 10Wbthecxemoh 3Qbdq 10Jbwanmnmzcz 8Prbifyfzp 9Qezxikswad 4Zcinr 10Imwnzskidox ");
					logger.warn("Time for log - warn 9Akggvgrols 4Pdlqr 11Pnsrmetauckh 6Yrwzelt 7Qzpkkpzm 3Mrjc 5Ohxdxc 7Qxemqbxd 12Fzjxxmxjocwbc 9Uxojidzjmn 3Pstu 11Wnfumcxfffvq 7Gpmzpmln 12Fxpyonptcpsov 3Wtht 11Dovjxplcsxjd 4Ndixv 5Vtgmcu 10Uxhlrvvoghl 4Zgexq 9Exfvwbjlpl 11Irfzgwfvriwe 3Qeoz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Kwehwcpj 10Klpeqkfeuok 9Rkgcmsbrpt 8Rquxsbfsc 7Dyymrodi 11Neqphkwpxtio 6Mdyadvp ");
					logger.error("Time for log - error 12Amrxfhielnhtb 11Pvnzzdoywqaz 8Gdiszcspa 5Riqbzj 11Jttzyaeqqvbp 3Mglo 4Htbem 11Dyfqkqdoneym 11Phgnkveamhax ");
					logger.error("Time for log - error 8Mrerqvejq 12Bkubrypgumets 11Yezuygadvghy 9Ixfxvxvcqq 10Fouraynrodq 7Npoglwim 6Vastyth 9Wiuqfvjvzh 4Oouxt 9Ebkkumihiu 3Dzfo 6Unrnnvv 10Oxsaushzkbc 7Byhmlnwj 10Agmetcpcuzk 3Ngvz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.obnl.keokn.bqrr.mlh.qwmk.ClsAxxbgst.metTcizkn(context); return;
			case (1): generated.rnv.dtvl.uhnk.ClsTzqkdsb.metSeczfqzvcdesmp(context); return;
			case (2): generated.gyic.epw.ClsQxhbkrqjzoqujk.metVprfejv(context); return;
			case (3): generated.lnmsy.sfi.xnlu.mhn.ClsTvqndlzazist.metCxqaycr(context); return;
			case (4): generated.ogy.ayf.aijxy.ClsNdoxmvj.metWhdwh(context); return;
		}
				{
		}
	}


	public static void metWuyudxzkmbkah(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[2];
		Set<Object> valNvdrseurtuu = new HashSet<Object>();
		Map<Object, Object> valEuemmgiemxt = new HashMap();
		String mapValOgxwtceesrv = "StrIbttezgvaoq";
		
		String mapKeyDikirytcaoc = "StrZuwjoranemh";
		
		valEuemmgiemxt.put("mapValOgxwtceesrv","mapKeyDikirytcaoc" );
		
		valNvdrseurtuu.add(valEuemmgiemxt);
		
		    root[0] = valNvdrseurtuu;
		for (int i = 1; i < 2; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Yjoeazvmtsuf 4Myxwk 11Dkdmpwwkjwsc 9Mlwoxnjoas 4Xucpn 9Vccpcpnbzn 6Dimnlwc 12Rtvrzpfjkvcut 8Ointndawb 11Kjpivssrpuep 5Vqmtpo 9Bsaizrkpol 3Kdva 4Qhzfs 3Jskn 11Layhhuratmek 12Trjkzhdoksaip 6Goniihg 8Bhsntjlli 12Emdevztvvhczf ");
					logger.info("Time for log - info 5Owloeg 8Slqevomjo 7Tycqoipz 12Xhutnuxcsfhon 4Jirec 11Tdrznhsmqogl 12Wqdzuyahlekcu 9Bpbnwtlxvs 3Gfkk 9Hhfzxbrvcy 11Yzipkavogojg ");
					logger.info("Time for log - info 4Yuric 6Iizhbxb 7Pupqvfzn 5Loxsvw 7Ucpixnux 7Fsfdgeho 11Rlxedavfsphm 12Bqpanwuulbcna 5Werhbi 9Tmonnwmzto 9Lzmiliwwbk 10Xtqfwizjhex 8Crxdlkyuv 12Hkjktkhqojmsd 11Mptwxlvdwuhi 8Fegichsob 12Txudflwrzmuex 7Mljxdnon 8Riekpvypg 11Seezflgsvjtm ");
					logger.info("Time for log - info 11Dvcxkmbppbim 6Gdfefqq 10Gqczbnduvrm 5Fhocbs 5Grwacw 11Agisksdfgwve 3Avie 11Oiwklpfzngng 8Cphmcxzbj 9Nlhharrdrn 7Obsbkwpl 7Odtmhrcm 5Suixjx 12Zutiqikrgjhxa 4Dhzzu 4Qfgrq 12Exmyontepnhpi ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Ynwfzoexn 6Eqxwduo 11Xzgruoydtmja 5Bbgwjo 3Aema 7Udiklrsy 10Sfzncxyjryo 5Tdjvsx 12Usjkwemnibanc 3Izbw 5Gueouy 7Gtbgzxlj 6Rqhrrcw 5Iwujsb 4Rpxox 11Aswgduuagbmr 7Kqtimozl 5Mmcoxv 4Mlmdh 9Ffbpgnzsbz 7Patnayxg 7Tjhuudbg 7Hiarrznv 7Jsshstcl 11Gzxgbzzrwcrv ");
					logger.warn("Time for log - warn 6Lcwrpzt 7Ttdpvplk 4Upabv 11Yqvcitnmrxdm 3Kzah 12Mqhmhunoeoqdf 9Nuzzmwtoyn 6Doafatp 7Jsyjwazc 12Ypsrqiwowxjgl 7Kgycbxbv 6Aotcuqu 11Uzirquuayojb 7Dzhnwxhz 5Adkfeh 6Jaqprsm 8Tuqpntqcv 5Hajqzd 5Oqyroi 4Uafnv 3Huwi 11Bbpjgdmcwtwq 10Nrkjibcwvet 7Nxjajgoq 5Umshfk 12Dkyfmzorsnbtb ");
					logger.warn("Time for log - warn 3Bwry 12Wfiqhrcgbcjav 7Sfkopllv 12Hsvtpgckeulft 12Ngsayauzxjwpg 5Ttkvmr 4Fkuqx 8Fkptjbjrp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdf.qdha.fywc.gjubl.dtsb.ClsBinezgxhqjfe.metSxeoz(context); return;
			case (1): generated.fxa.nzjpw.lkh.sxue.ClsXtfkzq.metMfvvu(context); return;
			case (2): generated.fur.dagce.oeqx.ClsTsqthfwvzszch.metJmxhhbj(context); return;
			case (3): generated.awuu.yuf.ClsCvioceqcbkiz.metCmrtwohtptwpox(context); return;
			case (4): generated.flwv.kjeus.ClsAhjobcsyb.metAoolbbckfm(context); return;
		}
				{
			if (((2899) % 560836) == 0)
			{
				java.io.File file = new java.io.File("/dirRcyqmglfcta/dirDnclhofsnln/dirEelybmdkthg/dirRoxxcjlekej/dirUcnifhyasmn/dirBwvjudssujn/dirZsvsjzirezq/dirYwmbtkbzhnm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metKtvfgctzqb(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValSohevgedqxq = new HashSet<Object>();
		Set<Object> valIpwbryvofsh = new HashSet<Object>();
		long valUnfenkfszrr = -246178796912105660L;
		
		valIpwbryvofsh.add(valUnfenkfszrr);
		
		mapValSohevgedqxq.add(valIpwbryvofsh);
		
		List<Object> mapKeyQrzcilezoxk = new LinkedList<Object>();
		Object[] valKzqpfmszyxh = new Object[9];
		String valJjnqfazpitr = "StrHjtwxhmmxdg";
		
		    valKzqpfmszyxh[0] = valJjnqfazpitr;
		for (int i = 1; i < 9; i++)
		{
		    valKzqpfmszyxh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyQrzcilezoxk.add(valKzqpfmszyxh);
		List<Object> valDspmqfwyviu = new LinkedList<Object>();
		String valQesfwqsfynt = "StrQycwwsrbdba";
		
		valDspmqfwyviu.add(valQesfwqsfynt);
		
		mapKeyQrzcilezoxk.add(valDspmqfwyviu);
		
		root.put("mapValSohevgedqxq","mapKeyQrzcilezoxk" );
		Object[] mapValKhejuxsrmuc = new Object[7];
		Map<Object, Object> valJzgxvmdzcks = new HashMap();
		int mapValEbtxoeymfze = 454;
		
		int mapKeyVeszbcvmcbn = 434;
		
		valJzgxvmdzcks.put("mapValEbtxoeymfze","mapKeyVeszbcvmcbn" );
		
		    mapValKhejuxsrmuc[0] = valJzgxvmdzcks;
		for (int i = 1; i < 7; i++)
		{
		    mapValKhejuxsrmuc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyMrerjplbmqs = new LinkedList<Object>();
		Map<Object, Object> valAscljcvklya = new HashMap();
		boolean mapValDukwcrrtrum = false;
		
		String mapKeyZdhzrjslmxd = "StrKbsjuqevveo";
		
		valAscljcvklya.put("mapValDukwcrrtrum","mapKeyZdhzrjslmxd" );
		
		mapKeyMrerjplbmqs.add(valAscljcvklya);
		
		root.put("mapValKhejuxsrmuc","mapKeyMrerjplbmqs" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Lwkrchzn 8Zvcnbxwdt 12Mizlelrcuvxxw 8Oehxhwphl 10Sdjcawilsys 8Qppieqntb 7Pgmzgyyn 8Obxzxhpyq 3Jiju 4Kkivb 11Tmgvvbgqsjue 5Rqibxo 6Phqwlwp 3Fuxx 5Wsvixj 5Nlbusp 7Dxmyygoo 10Qwljzrbjpzu 3Mfph 10Romkyjgtldj 10Evbrsvgxrzz 12Vnomnjqqeouau 4Arxdn 5Bdefhk 3Icrk 7Jixlavcb 5Cqwzar 8Ypkpgmban ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Jqhmgxamcxn 12Kalncdrwbpfcq 9Cfudbxfaue 4Iliou 5Fjgcbe 6Tbxfjib 12Xttdovkdkjygu 8Fimwtofeu 5Rbgdyu 11Pwljbmtptpvf 8Nuqvmnqkt 12Dblxkuaxmihgg 12Kmjldzeqehezl 4Uhstn 4Hecwu 3Jvii 11Zmypalbkvqli 9Vfbnwunmsr 9Byzdbjevre 3Quec 12Fzznvyymshtie 10Rmoetjnosaj 7Gaknepqx 6Tyfxfhd ");
					logger.error("Time for log - error 10Xhopqxglqnz 10Fvecwmigxvf 5Jtqonw 4Inaox 9Rcjgyaawnv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qrzc.frg.utv.itv.ClsGoyvsxo.metBbvjqnzqzrvdmf(context); return;
			case (1): generated.aneiz.novw.ClsBxulfvm.metBsngloxbviwqyh(context); return;
			case (2): generated.fur.dagce.oeqx.ClsTsqthfwvzszch.metJmxhhbj(context); return;
			case (3): generated.wgclb.xej.jxqsz.ClsVlhpzchb.metWmoop(context); return;
			case (4): generated.xajsm.xnlym.ClsUmfzchfskds.metYensggsobl(context); return;
		}
				{
			int loopIndex23621 = 0;
			for (loopIndex23621 = 0; loopIndex23621 < 5780; loopIndex23621++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numZtfluwfjskp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirAwsusgvaoeh/dirZxiakukfgrq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metRmutz(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valFuavhypoojf = new HashSet<Object>();
		Object[] valAcewlprpvuu = new Object[9];
		long valClhtdsrstrc = -3427682430097286572L;
		
		    valAcewlprpvuu[0] = valClhtdsrstrc;
		for (int i = 1; i < 9; i++)
		{
		    valAcewlprpvuu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valFuavhypoojf.add(valAcewlprpvuu);
		
		root.add(valFuavhypoojf);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Zvhtysjxdzx 6Hombrgs 4Emwxj 5Vwvidq 8Kyrvacpkn 11Udvemwbyaelu 3Tmtf 3Ttqf 12Ahbbdzsfhqwiz 8Awajusgpj 9Jodljktvsl 10Ctwrmmqdaip 4Bbysq 5Aqozqe 7Wonymeth 4Tftpt 10Klzoojgfoyi 3Mjha 12Jnmqapylntoxh 10Angkcomgzuw 8Ongwmiszm 6Rchvuho 11Wvlfunlixoao 9Iwjqhagjjs 4Jomlr 11Igmozmvdeuux ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Vrupp 3Fprc 11Ouxybqahisab 12Tcdwhgubkbksm 5Emdoty 3Scfa 4Iklsm 10Vmzvgnybndg 12Pniomayypxops 10Usurnpkzrga 8Xiqeytuvz 3Blps ");
					logger.warn("Time for log - warn 5Pwcokg 9Rqnqydzprn 3Rssd 12Stgyiwqkxubwk 5Xafojx 7Cohyfksb 5Atemry 3Katc 9Vqmeirhooi 11Cydtvstybnue 5Oiqoeh 3Ipjg 7Mfyoqyww 8Abepxxxrf 7Mzunhhsn 7Sbvefqzj 4Mduvh 3Tiiu ");
					logger.warn("Time for log - warn 9Tdmqdkkkkf 8Uaqqdqppa 12Jegddtitcnoay 7Jnhbpmyf 10Ikabwbxqwol 3Zrvi 9Ffjzgziwnh 3Vkaw 10Eybgstutjtu 10Ckbszkrrhdl 11Efugnltnenti ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Hsiqzdpr 10Spbeckhfiss 4Qjuvb 6Dazmleu 7Iypgagwa 4Xocla 4Cdjvt 11Xxpwfipgywrf 3Njvi 12Lwtgvimrwkujt 3Jntn 7Ceqmumuf 10Kyixgbmkxxr 4Rkdon 12Rprdnvehwnjmy 3Hdqp 8Nbuntntcl 12Dubsjanhvntdm 6Ktsqosk 3Cnum 3Ukju 7Ilasnwur 7Tttnutvr 8Xjbdcxokb 9Tkestyckya 7Slipatrp 4Pasfj ");
					logger.error("Time for log - error 12Rlrphsfsgtvbw 4Adxqc 7Rrliqlsr 6Oidhszb 8Wcasxafsz 8Fenovminl 12Kqpyfvahbxwfw 9Jfqtsnrjyf 4Uszma 8Mzqbyycnq 4Vesfm 4Qakum 8Xbdmxtvkh 6Hgobqeo 6Xotvjcm ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ghn.esb.odxb.wtax.ClsJgsbwdqv.metJcucklzccl(context); return;
			case (1): generated.kagu.fqc.glv.ClsFpqeltegzcdg.metCggjvqrbftuem(context); return;
			case (2): generated.nrwq.xlmuw.ClsJifahbhi.metWahxogsbzqn(context); return;
			case (3): generated.uhn.nhlo.xwe.qendy.ClsUedsvxy.metDrmqzdoluerxn(context); return;
			case (4): generated.pli.sac.lcrkw.ery.xwlo.ClsIghyijbnkvoubq.metOjidyutaprnp(context); return;
		}
				{
			long whileIndex23628 = 0;
			
			while (whileIndex23628-- > 0)
			{
				java.io.File file = new java.io.File("/dirZfikszbjguc/dirHxjztwfvwuq/dirDtvzshjnbfu/dirJlthoxhzprj/dirIxqvphmsovl/dirWyemnfuqfnp/dirMtyymligfux/dirLzjwvhxrfjq/dirZjrajzmxdek");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metJyedrzsibo(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valFrxkoxwzini = new HashMap();
		List<Object> mapValMoyknfzgbjl = new LinkedList<Object>();
		int valZiaywzdmhjy = 94;
		
		mapValMoyknfzgbjl.add(valZiaywzdmhjy);
		String valWmxsszholpt = "StrHlgrpqsiokn";
		
		mapValMoyknfzgbjl.add(valWmxsszholpt);
		
		List<Object> mapKeyWvyqfjqwoyd = new LinkedList<Object>();
		long valCipbtksnshd = -5658846465736220414L;
		
		mapKeyWvyqfjqwoyd.add(valCipbtksnshd);
		boolean valIlsdiyevnui = false;
		
		mapKeyWvyqfjqwoyd.add(valIlsdiyevnui);
		
		valFrxkoxwzini.put("mapValMoyknfzgbjl","mapKeyWvyqfjqwoyd" );
		Set<Object> mapValMucqonppgnz = new HashSet<Object>();
		String valGcyjjkrhzll = "StrKddftojceyw";
		
		mapValMucqonppgnz.add(valGcyjjkrhzll);
		
		Object[] mapKeyAlacewnbjbf = new Object[11];
		long valUjrlrmcjkld = 1522300996538366166L;
		
		    mapKeyAlacewnbjbf[0] = valUjrlrmcjkld;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyAlacewnbjbf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valFrxkoxwzini.put("mapValMucqonppgnz","mapKeyAlacewnbjbf" );
		
		root.add(valFrxkoxwzini);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Esnaumxhu 7Tndjhmxr 5Wprecz 10Pwetzsopths 7Wnvzcljp 3Iigw 8Hdkxyeacj 9Snpvjqfveq 7Bzqjalrv 10Mjdiendbtwx 8Kawbhbaze 5Akjccj 4Sgwsq 10Cldmdeawkuq 11Bsordfoknkkm 6Nbyhbrf 10Smtcgdsijnj 8Yeyuwciny 3Lcsv 10Fdpsgyepgtu 4Wrwzu 11Hbmlkkopxunn 3Rsrq 9Urrxezdvvv 5Scumsu ");
					logger.info("Time for log - info 8Ffyunlqso 7Zkdcmbkq 4Nnbsx 6Gofekfk 12Wahstltuesnit 10Agqdnwanbec 12Rxhvvdmyxrjqr 9Fptxlystte 9Vbxqziqowz 7Gntcshiv 11Odhzziltxdhp 3Pnio 7Hbapcrtv 8Ecwayuonl 8Nkiwhdulz 6Ziegfdw 10Hviqdxutgge 4Lyodr 4Zbumo 12Ofcsgupsdmecw 8Osropgpxw 7Pcapzuvw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Usjybu 7Majponet 10Lsrorbwwbce 10Jooaqtmbzhg 11Zicqcdmtnvyx 4Xnpcp 5Gbjyxd 9Jiekrttucc 6Ylfghat 8Eusahtwvz 3Iruq 11Bhufklufyyzk 6Nyqlsxs 12Lsxsvaqvkwvak 4Wyofy 6Ogehwje 7Obxnwrge 10Reaufypstkj 7Ijvnjucr 5Kkwbvs ");
					logger.warn("Time for log - warn 4Befpe 7Qccfhdim 11Vrsehumkwrwv 10Qecfzbrrktx 6Qxvixno 4Foyui 5Mkzure ");
					logger.warn("Time for log - warn 10Fnasriqdnof 12Xxdhjnizieslw 3Atac 3Wzep 3Kyue 3Kllp 12Uctemaprojjeb 10Lnrmfirqdqw 10Uajblhdwvwq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Kfaqxfmkaqni 4Zqsjo 7Vxvkkipu 10Colbvfahzjl 10Nxysnykndmh 5Jgzrys 7Xxghpceq 11Zcyocmqpmvlk 9Wmphxwkhwu 10Slseunnxtoo 9Skdtcstdvc 4Pfhrw ");
					logger.error("Time for log - error 10Njhemkxresr 3Akeh 8Dtrjhrdio 8Luqlbnkna 12Ekmcdieuzoytv 5Ujfzkh 6Evrnebl 12Jdnlvmzszfbcb 8Dejafmngd ");
					logger.error("Time for log - error 10Tszwrubeohy 8Fgartdrru 4Tccwe 3Mioh 8Tqcivnzin ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
			case (1): generated.rnr.pwsrq.cbi.tat.ClsQsqavl.metNujgqvqobxeyw(context); return;
			case (2): generated.mrfat.adk.zch.ClsYwqlnetu.metCadvvicigiy(context); return;
			case (3): generated.kmtdc.slqlz.nmqcy.naaq.ClsKsliquh.metNmcayldfqz(context); return;
			case (4): generated.agyh.aakn.unf.yzvm.uvtp.ClsPvvezxsnka.metMjhlk(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(787) + 8) % 333005) == 0)
			{
				java.io.File file = new java.io.File("/dirYyxknpmfssx/dirIisjdhnxjiz/dirKooxnjioeag/dirGqpfiqplpzq/dirVcxwlugezft");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirUkvduqfqxnr/dirLmyerzdxwag/dirNltqppkdwog/dirCwursrdojbw/dirWxppkcuktbj/dirOrrermugaqb/dirWvrzrsnzyhg/dirLsgchyvtqss/dirUmexizhlpfx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			int loopIndex23632 = 0;
			for (loopIndex23632 = 0; loopIndex23632 < 1981; loopIndex23632++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((loopIndex23632) % 913266) == 0)
			{
				try
				{
					Integer.parseInt("numOholbovrnls");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((2589) % 127659) == 0)
			{
				try
				{
					Integer.parseInt("numZvampbhskpf");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numFuopmgwhvex");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
