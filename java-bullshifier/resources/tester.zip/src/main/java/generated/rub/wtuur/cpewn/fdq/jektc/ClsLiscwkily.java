package generated.rub.wtuur.cpewn.fdq.jektc;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsLiscwkily
{
	 public static final int classId = 394;
	 static final Logger logger = LoggerFactory.getLogger(ClsLiscwkily.class);

	public static void metHunahadvlqsm(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValUvdfgxpqebw = new HashSet<Object>();
		Set<Object> valNrjrgazylnf = new HashSet<Object>();
		long valVigyczkitrp = 2488115548561895382L;
		
		valNrjrgazylnf.add(valVigyczkitrp);
		long valKchabzyxpbx = 7726788513601051855L;
		
		valNrjrgazylnf.add(valKchabzyxpbx);
		
		mapValUvdfgxpqebw.add(valNrjrgazylnf);
		Object[] valKvokivwkkst = new Object[10];
		long valLwdsyrhzwjd = -963258682906822615L;
		
		    valKvokivwkkst[0] = valLwdsyrhzwjd;
		for (int i = 1; i < 10; i++)
		{
		    valKvokivwkkst[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValUvdfgxpqebw.add(valKvokivwkkst);
		
		Map<Object, Object> mapKeyBqxgfcqqvpg = new HashMap();
		Object[] mapValRncnucpvbwe = new Object[5];
		long valZigjwshngxj = 2448430137241911663L;
		
		    mapValRncnucpvbwe[0] = valZigjwshngxj;
		for (int i = 1; i < 5; i++)
		{
		    mapValRncnucpvbwe[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyCobxxjomtmt = new LinkedList<Object>();
		long valGgcprpaqaia = -1936124944219828164L;
		
		mapKeyCobxxjomtmt.add(valGgcprpaqaia);
		long valGlazujpedcw = -3317979020329256440L;
		
		mapKeyCobxxjomtmt.add(valGlazujpedcw);
		
		mapKeyBqxgfcqqvpg.put("mapValRncnucpvbwe","mapKeyCobxxjomtmt" );
		
		root.put("mapValUvdfgxpqebw","mapKeyBqxgfcqqvpg" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Wzfnohendaxly 9Wnuuytwegc 11Riciajeoqlho ");
					logger.info("Time for log - info 7Debwloav 12Tleuczzgyaksn 9Hswczhxlka 11Wedvhwpzxthm 6Jyopwds 5Kxshil 11Feveeyehvbph 5Tkktbs 7Kjhfvvat 7Mnljsbvy 11Lmyohbgyhcqd 9Tvskwfzjqj 8Bkxeozvlt 4Nhrux 5Nwyhoj 10Fzbaoizvyup 7Shgtorku 9Pvvkqgxevf 12Xkvtidpicxxxm ");
					logger.info("Time for log - info 12Hocevbukwbbrw 6Ixpnwio 9Fbvnhizcgg 6Fnqjruq 11Krnrfnqbxmzu 3Exwb 12Jqmmybzuymhfa 9Uwopltciwb 4Isjoo 7Krfzbzlh 7Mcobwjbg 11Kpqqzhjyeomt 9Flquvaouij ");
					logger.info("Time for log - info 10Yjiwnnbmnis 10Lmfrkesxsnx 11Sitfapqiayqh 10Qjkbkgtvbam 9Xghiaogdne 12Mxesqlvnalmyh 3Enfr 5Rrfqnp 12Meumketurxcrq 6Nuoogjs 6Nmffird 11Evdpojuhnizs 10Ooeqdrwteto 4Yzijy 6Okqylao 9Yhrepcwrlr 11Lkukckbcaozf 11Gyhhvlflamlh 12Ipwhpbldkoxhy 4Hsopf 11Mvemngwngvku 9Jutiauvued 6Eibuwna 12Risernhgcfxwm 7Jelvsnrd 4Qvkzj 8Cdphkwsdc 4Ztljt ");
					logger.info("Time for log - info 5Fcgpgs 6Fbtqtxj 7Mvmbrirx 10Vzqifwlwlzl 6Stdcmii 12Wfakxseaadsuo 8Nyogxqfmo 7Unmbvjxd 5Xvgelv 7Izgenlca 5Ozodkm 4Xjerz 7Zvtuphlq 9Wcutujitnx 3Ricb 12Exqukedoigbev 10Zjlawmhjrsm 6Fbuqkvp 5Pljzkj 10Juprnewmmss 8Qtwiciita ");
					logger.info("Time for log - info 6Gnpvwnc 7Vahbjfnv 11Bzvsoiirgvfs 9Ukrgwwivah 9Xxkxkpgwms 10Dpudsazwfqm 7Lvspbqxk ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Iukpgelouoaiu 5Nlkvfq 11Xajwullyklqw 4Omolq 10Rhvpzrqtadh 7Ptgogtod 9Ymjdzyfwcv 12Ocpcwefrsgpmj 8Qnuvaetcq ");
					logger.warn("Time for log - warn 5Xsfkch 3Hilp 5Zjtcmd 5Omfvzu 11Iugvputkpinp 4Pectc 7Merkbfev 5Oqhojn 8Apzmtnjvc 11Sxehoddgvjey ");
					logger.warn("Time for log - warn 6Aeaujsh 6Yksbvdf 4Trlav 10Zmahkrtpnxy 8Txnotijfw 4Ytpqy 4Krnxq 9Fbuihhjjff 4Zlatt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vbpvl.ppexe.hnrdr.zcxzm.ClsCvshjbmkqrb.metJcfyp(context); return;
			case (1): generated.lsv.svu.ClsVsswgqo.metKnakkpce(context); return;
			case (2): generated.qer.bwl.ClsCbeyhqqy.metMimivk(context); return;
			case (3): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metLiijz(context); return;
			case (4): generated.enb.ktdil.ClsEqcfzlhpy.metDsnfgxxtqarhp(context); return;
		}
				{
			int loopIndex26679 = 0;
			for (loopIndex26679 = 0; loopIndex26679 < 4851; loopIndex26679++)
			{
				java.io.File file = new java.io.File("/dirZwuzmqeapdl/dirCxajlthsrgc/dirBurnjohprdl/dirXqrqsnlkhtz");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numVygpvrcakoi");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numLcbwvlfjlio");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metWcbvsgslh(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Object[] valAsjrihbroiq = new Object[6];
		Object[] valLwjwhkvwigp = new Object[8];
		boolean valReypyvgceaq = true;
		
		    valLwjwhkvwigp[0] = valReypyvgceaq;
		for (int i = 1; i < 8; i++)
		{
		    valLwjwhkvwigp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valAsjrihbroiq[0] = valLwjwhkvwigp;
		for (int i = 1; i < 6; i++)
		{
		    valAsjrihbroiq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valAsjrihbroiq);
		Map<Object, Object> valMdekxxdilcr = new HashMap();
		List<Object> mapValTrfrfozabfm = new LinkedList<Object>();
		boolean valGiyffhzjiub = false;
		
		mapValTrfrfozabfm.add(valGiyffhzjiub);
		
		Map<Object, Object> mapKeyTlyupvcrslb = new HashMap();
		long mapValCodtsmmsefc = 6845189347636459414L;
		
		int mapKeyUjrequrjdsk = 924;
		
		mapKeyTlyupvcrslb.put("mapValCodtsmmsefc","mapKeyUjrequrjdsk" );
		
		valMdekxxdilcr.put("mapValTrfrfozabfm","mapKeyTlyupvcrslb" );
		List<Object> mapValRsoepotnqwe = new LinkedList<Object>();
		int valGorzmqnmobz = 493;
		
		mapValRsoepotnqwe.add(valGorzmqnmobz);
		boolean valCqfzlykgsgg = true;
		
		mapValRsoepotnqwe.add(valCqfzlykgsgg);
		
		List<Object> mapKeyPqarhvjwzyn = new LinkedList<Object>();
		int valMghiizhccyv = 349;
		
		mapKeyPqarhvjwzyn.add(valMghiizhccyv);
		boolean valCsvrexqsiic = true;
		
		mapKeyPqarhvjwzyn.add(valCsvrexqsiic);
		
		valMdekxxdilcr.put("mapValRsoepotnqwe","mapKeyPqarhvjwzyn" );
		
		root.add(valMdekxxdilcr);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Digciblo 10Xyusdeasaum 6Wuqcltl 9Tkrtrgolhn 3Tkag 8Munyzgpjz 5Cmpmls 12Zxslxgfqdkets 9Arixmdlxtb 7Venffzbc 5Ihqeir 10Ussmiithlcb 5Jxcgzk 3Yhfd 12Nbgkiavnbbpet ");
					logger.info("Time for log - info 6Lahsxmy 11Ucsahbuwoond 4Oszsc 9Pywukfksez 8Gyhhxhqhe 11Xeisnhxfigko 10Mlytxndzgjs 5Kgmudg 12Qtobmbafuvtsh 10Zpwgugtnmqu 3Rzzm 3Pdqi 4Ncuua 12Zktdxhtrqwxqr ");
					logger.info("Time for log - info 10Qftxyaidwsy 12Pxbunyfyjweym 5Oukypz 6Llqnlgr 8Fwihwgugw 7Xnzbrchi 3Dfjf 10Gbfmkkfodfc 10Wcfhxipqpry 10Hjwvfjefewd 3Henx 12Dzztoacjugpcg 10Mxxcmwblspn 9Ckuqbgwhdd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Pckbjxhx 11Eqapuiutihvr 5Djdhbv 10Pctsacfzghy 8Fagvlqwji 11Rjrjdcryjllo 5Rqwgkd 8Ocgsqajtk 6Rxaniyz 7Omyyytuj 7Ppjnvilx 3Piwg 6Itutyal 11Jtzoiyswksxo 7Eoowcmhz 12Pvmmwbiutxjqe 6Ljyhkgi 4Lpbrt 3Dwsh 9Cbtqwswnjf 4Dhamz 8Txcrewxjo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Sbdviq 8Qircrkzoj 12Lglytanuwhmmy 4Ndoev 4Vtglj 6Niiklrl 6Zwutvig 9Tgrbnqwwzt 3Sbwk 7Bifjbtzz 8Scuqztfza 8Dcwgdcvco 3Ixkr 9Byfbrzbyff 10Mutwtilvese 10Xblxxtrladp 7Ohcxqhev 10Roqwpuvkvxp 4Tvxlu 3Fctx 7Eoejfgtj 5Wiynzu 9Ajpbkydrfj 3Mzfq 8Rndqjihwd 3Ukwz ");
					logger.error("Time for log - error 8Hizklmcfz 5Okswoj 8Kaaceqrsk 11Arwmmewmoqwn 7Ksvrmcaa 7Svzkzamt ");
					logger.error("Time for log - error 11Fdarfuukhizx 10Oosjijepmzl 5Wfrorw 10Jhwldrpofxy 11Pvawafcgdeik 6Xjvphls 12Zeguactorzwlw 10Gfsmryjochz 4Qvljg 3Tvkg 5Hkirrv 6Cccobmu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pxdt.vcuzq.tfk.bjngo.ClsCaopcwu.metNrjzvdamjddqk(context); return;
			case (1): generated.mvrs.ywr.ahvi.avyw.whash.ClsQifjwldjrqu.metVglylwmvni(context); return;
			case (2): generated.lraiq.fcmvy.qwp.rkzex.eokht.ClsJupuz.metTywqcdpv(context); return;
			case (3): generated.vna.rvrp.nspt.ClsOdrnbbdzkkwwtm.metAigotoanishmlc(context); return;
			case (4): generated.yhl.ykh.hog.zsc.cal.ClsJuxvzfsp.metBdpuovhti(context); return;
		}
				{
			if (((7209) + (4091) % 264576) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metAyhva(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Object[] mapValXzffevehexy = new Object[2];
		Set<Object> valWhrfwbpjqgi = new HashSet<Object>();
		long valIoinalcgvdu = 2787416895042739736L;
		
		valWhrfwbpjqgi.add(valIoinalcgvdu);
		
		    mapValXzffevehexy[0] = valWhrfwbpjqgi;
		for (int i = 1; i < 2; i++)
		{
		    mapValXzffevehexy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyBlrkoglfmmz = new HashMap();
		Set<Object> mapValEpbwzoyctey = new HashSet<Object>();
		long valWwfludhaeye = -8429755170597304520L;
		
		mapValEpbwzoyctey.add(valWwfludhaeye);
		int valYophcyyjthf = 751;
		
		mapValEpbwzoyctey.add(valYophcyyjthf);
		
		Map<Object, Object> mapKeySgovwyijaqz = new HashMap();
		long mapValTxkfdhjhufj = 8771065757126711894L;
		
		int mapKeyBdbabjjamwa = 824;
		
		mapKeySgovwyijaqz.put("mapValTxkfdhjhufj","mapKeyBdbabjjamwa" );
		long mapValQxsjzxraxzc = -6220242319589803316L;
		
		boolean mapKeyPmolcdkrqsw = true;
		
		mapKeySgovwyijaqz.put("mapValQxsjzxraxzc","mapKeyPmolcdkrqsw" );
		
		mapKeyBlrkoglfmmz.put("mapValEpbwzoyctey","mapKeySgovwyijaqz" );
		
		root.put("mapValXzffevehexy","mapKeyBlrkoglfmmz" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Qvae 6Dtkerem 12Znrweqizqrqsw 5Jibrdm 12Mygrggaftrhje 7Bsnwwsdp ");
					logger.info("Time for log - info 6Mrufyqc 11Pybsnchvvloh 9Qoejtbhzue 6Yendsyr 6Xqavbso 9Fuczffjzdz 12Gxzscfxkrerdu 8Jkkzpbbjz 5Vbetrp 7Quqjedmk 11Lpopqzoluoje 12Degreidhvpiyi 10Vvgwgzjosyw 11Czbveetfgbga 7Omagssnk 6Vkxqhzy 5Xezoxe 10Bfqfbmgwsdr 3Zrjk 8Hojnilrem ");
					logger.info("Time for log - info 4Emsax 3Bjcr 5Mjxohu 12Cpfmsrjbwdztg 3Htym 9Qizlazythv 9Upmqfnohtg 6Ndthdrw 4Osedn 7Tifnxjkr ");
					logger.info("Time for log - info 8Lbmnwhkyk 12Hsjarbnsalegr 9Gzonugmvhm ");
					logger.info("Time for log - info 10Gzpqrixcvqv 10Vlbuuvguchd 11Nlfdmczlnrih 3Jqgq 5Bwkbgy 7Boriysie 10Oxxjyfbnwzj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Xqrhg 8Rqlmrgxkb 6Xtkysli 8Asgyzkljt 6Sumapjg 4Hczbh 9Buyslgpzkr 10Tljmtyqfveq 11Uqhxkagvtabb 3Bcgj ");
					logger.warn("Time for log - warn 3Jiog 6Qhyrwho 8Kdnbuuzcn 10Fxorccdojee 5Swjhxl 9Qvgpszbfhv 5Iskfof 9Dlsuzahiyd 6Uzulwek 6Dhcmrhc 10Ncwhildzvkk 3Rxia 5Thnboy 11Amxetamushcv 10Weanhqxqodt 10Axcowfuuiij 5Ypsnio 5Jkuqqv 10Pmekgvigwtz 5Obpsqg 12Ddkxuuawyiuud 9Mknbipxbnl ");
					logger.warn("Time for log - warn 4Plhkw 9Ozbzpnnhdb 4Snegv 4Muqdy 7Vsehrqjr 11Cyiajzdeyrey 8Pmpzqyjaz ");
					logger.warn("Time for log - warn 11Egvtprueiykc 7Etvwzgck 6Vkutrub 12Nphyxmvxwpftr 7Ycgrxuye 5Cosytg 10Tpufgrnftka 7Nxxpjdve 7Xkfusvsm 6Ujqytuz 10Cqzfdcvsaqs 4Dnzgx 10Jznuiiwjucl 7Urozquyw 7Prfiroic 12Nsbnrevwkhcfm 11Swdwvfcbqafn 6Wcixevi 8Rnnpvcyss ");
					logger.warn("Time for log - warn 9Isnwmccivl 5Vqwmrv 10Ecvbrdgxoen 10Ycpnwgqyqcv 10Ptvdlcmjngk 11Kaphqixcydyg 8Enytuqhqz 4Iwwvf 10Sfpzjacwnbz 9Tyaxnclutq 6Mmmvoxx 6Vqwzxsi 10Xlrxmtfloce 3Xlgh 9Nyjinuogho 6Lcwguah 3Ztvj 10Cdyxllewikl 10Hkfglrhgdwf 12Kitsaqoovvwye 12Fngaxiboamgim ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Kjvn 9Fbeoofobdk 6Swzmanc 11Snujzsoplsii 10Mjyxgspjnve 12Xijcreemalauh 8Petivjnmr 3Cegt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rzcpj.imb.axphv.psemq.ykmed.ClsJszqdkpwcikmae.metWknjcygccn(context); return;
			case (1): generated.hbd.gdsbg.cmv.qvo.ClsZtgxvnjsll.metQvkbrrhkdtwqhx(context); return;
			case (2): generated.qllkh.klb.qyy.ClsQoiukvt.metPsvdtxokgqj(context); return;
			case (3): generated.ctymn.uic.kza.ClsBochsrrjh.metGygnvmjatcdvgy(context); return;
			case (4): generated.zdn.ayby.ClsMelkmphvwjkgwh.metAcvmturnoh(context); return;
		}
				{
			long whileIndex26690 = 0;
			
			while (whileIndex26690-- > 0)
			{
				try
				{
					Integer.parseInt("numHlktqwbadsu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex26691 = 0;
			for (loopIndex26691 = 0; loopIndex26691 < 37; loopIndex26691++)
			{
				try
				{
					Integer.parseInt("numPvdatupuvuz");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metFxfyfwekmvvpv(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valHeysyhizrzo = new HashSet<Object>();
		Set<Object> valTytmtoxaotw = new HashSet<Object>();
		boolean valNgekopbxnsu = false;
		
		valTytmtoxaotw.add(valNgekopbxnsu);
		int valGaexyzhuvth = 832;
		
		valTytmtoxaotw.add(valGaexyzhuvth);
		
		valHeysyhizrzo.add(valTytmtoxaotw);
		
		root.add(valHeysyhizrzo);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Qxhiytpyho 11Edxuuxuewqih 4Ldxfg 9Swrwpzvaoc 6Vedcrdx 3Ffzc 3Drvp 12Nribsusqsarql 11Mkdmssiifare 12Lpdidrskqtdij 12Aplqnnylshape 12Mvsbjxckoudud 12Hqohutpdofzrw 9Ioyykeaich ");
					logger.info("Time for log - info 11Gwxqdeylibld 9Bjoishqqei 11Iciqsspsnhpo 7Iyttdpqz 5Jbuzoe 12Cnnshedrpwjgm 9Ggsuylhbke ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Hfle 12Emoveelgjvamp 6Jogmjpe 9Ezgpmnwjzo 7Bvyonzah 6Apkajzn 8Olppiwraz 8Adcbvpxuz 11Tsciddzcincj 6Viaiibg 8Qbdrcwxvf 8Oglsjwyrm 5Dfgnmw 8Xqgmdznbk 3Zhjs ");
					logger.warn("Time for log - warn 12Nnrkulkleioms 6Wwfgnpy 9Fjtjympmxi 4Huvtp 11Lwvvaqpdfeip 7Qrbbcxvs 5Vdoqcg 12Annmwetslvjvp 8Hvyxukgnk 11Fzttcdcrpovr 4Fkuwl 5Wpkoty 3Rlfi 7Bobdahfz 8Ybttcpyym 9Kfpdgzufoo 9Comxlbveik 7Widoqwld 4Yakxc 11Yroxbkvaclxu 8Hsiygdthv 4Hpkby 9Ewbtexilyk 6Yynocfh 8Kepkkcxez 12Emfwqdhdbdofw 3Tiyn ");
					logger.warn("Time for log - warn 8Vqxcccdib 11Agqtmerdrvff 9Epfhrgddmj 6Bodvgha 6Bxxecga 11Qlmjusfthmlf 11Tkqeczmaybsv 10Ayqhahvzzgp 5Hhboui 4Yfczz 5Zektdg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Skkww 5Wmtwch 4Cwjwz 9Qhlawsbzqr 8Jfltqogpx 7Eellfpdr 3Cnyg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ajbel.dvbe.pmx.gfhen.qjvpo.ClsFwkvrnv.metMgmvesnfqhsp(context); return;
			case (1): generated.joeal.ovr.nvb.kqkl.kegr.ClsNehitk.metFbsmcfuayzyy(context); return;
			case (2): generated.rnt.ihen.ClsUnbfdq.metKnfoolueiovk(context); return;
			case (3): generated.vyk.nsacl.bsfy.saukt.ClsKpfdsyokiohmf.metQwjpvac(context); return;
			case (4): generated.lnvho.rhfct.ClsGgdasahuvsgcd.metDrqoq(context); return;
		}
				{
			int loopIndex26695 = 0;
			for (loopIndex26695 = 0; loopIndex26695 < 9214; loopIndex26695++)
			{
				java.io.File file = new java.io.File("/dirUnxwvgbtjpg/dirOffhprkibwo/dirBucwyqcpcqn/dirTjjwcseiizv/dirSjrbpfnpgfe/dirObsvzbndhgl/dirNktcowkhdrx/dirAavnsdkeovn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex26700)
			{
			}
			
		}
	}

}
