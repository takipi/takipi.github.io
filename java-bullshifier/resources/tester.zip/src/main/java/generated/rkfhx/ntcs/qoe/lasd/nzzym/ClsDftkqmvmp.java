package generated.rkfhx.ntcs.qoe.lasd.nzzym;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDftkqmvmp
{
	 public static final int classId = 155;
	 static final Logger logger = LoggerFactory.getLogger(ClsDftkqmvmp.class);

	public static void metVydzwrio(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valEkutvzbcpqp = new HashSet<Object>();
		Map<Object, Object> valDgvmveuzanb = new HashMap();
		String mapValHddxwfsipkt = "StrVeqokpscmcp";
		
		boolean mapKeyDfkainzgzja = false;
		
		valDgvmveuzanb.put("mapValHddxwfsipkt","mapKeyDfkainzgzja" );
		
		valEkutvzbcpqp.add(valDgvmveuzanb);
		
		root.add(valEkutvzbcpqp);
		List<Object> valTazybthcxxf = new LinkedList<Object>();
		Object[] valLajofdlxrnt = new Object[11];
		long valGizntemrkfp = 6576941632523059025L;
		
		    valLajofdlxrnt[0] = valGizntemrkfp;
		for (int i = 1; i < 11; i++)
		{
		    valLajofdlxrnt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valTazybthcxxf.add(valLajofdlxrnt);
		Object[] valFmxxogaprua = new Object[7];
		String valLzcdtynuznv = "StrMztmbgdmhlj";
		
		    valFmxxogaprua[0] = valLzcdtynuznv;
		for (int i = 1; i < 7; i++)
		{
		    valFmxxogaprua[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valTazybthcxxf.add(valFmxxogaprua);
		
		root.add(valTazybthcxxf);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Kwavlw 4Kagfy 3Vcrd 3Xpwv 9Cpolppyrdc 11Buseafmfbskc 12Bmgtdcvgvvfdo 11Exeaojrjztbo 8Fgjpwsscq 4Xztod 10Atdfhabpfrh 10Fystuekfgee 6Izathia 12Snewaowvjhwjn 7Tktqgcre 10Olndigfxlid 5Wvavzf ");
					logger.warn("Time for log - warn 10Mwwrqmysqlh 7Zovovhee 8Jxegtcxgt 3Uudg 10Xeehixjotds 8Dlsmytrxy 10Izmjgwyobby 12Qemughjmapqdg 7Rymnshai 3Eqzv 8Utblqvrps 7Urhruwqu 12Sqgbizunrmcmg 11Ojsxutnksxjv 4Anfzq 7Kuikojfk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Fispathbfhzh 12Gmgqksbbmylfa 9Ycdpqeqkdq 5Grqidp 11Nvyzknqlntsc 9Bzshsuaydw 4Scndt 4Nyaaw 10Elyyzgkawiv 10Xiuttiybpoa 5Vwfpmt 11Hlsuohcnxndz 11Aehwnjjaicdw 7Ughununs 10Tdfsabsensb 4Qeblc 6Jdexvbt 3Mbrk 8Ieivxiykj 9Tkytrbnmuj 12Rxpwwdcqmzlto 12Wfdbfogpnpbwq 7Thgdecpq 6Iwdbjuh 8Yyptjeizz 9Fzktjllkct ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.livfd.xzg.uuzce.mske.ClsRchbllfcclbcum.metKxxmloahvtx(context); return;
			case (1): generated.fzd.qgqjp.ClsVzqqvdhb.metMsjbhqpplani(context); return;
			case (2): generated.naf.suq.ClsSzodbxxywsfz.metUkmntmbfb(context); return;
			case (3): generated.ndkx.exo.qju.brvd.ClsMxlcse.metCkdfdkkppxv(context); return;
			case (4): generated.wzzy.rguqw.bfm.ClsCumedne.metJavfokczruv(context); return;
		}
				{
			int loopIndex22810 = 0;
			for (loopIndex22810 = 0; loopIndex22810 < 456; loopIndex22810++)
			{
				try
				{
					Integer.parseInt("numChfauaepfzj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex22811 = 0;
			for (loopIndex22811 = 0; loopIndex22811 < 1684; loopIndex22811++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex22812 = 0;
			for (loopIndex22812 = 0; loopIndex22812 < 6512; loopIndex22812++)
			{
				try
				{
					Integer.parseInt("numLkrmyllwivu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metVsewe(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valRbdcdybdagc = new HashMap();
		Map<Object, Object> mapValPcjwmktuwzd = new HashMap();
		long mapValMqscljnluqe = -1085557117900455975L;
		
		String mapKeyXleqlettiml = "StrCvwwondappj";
		
		mapValPcjwmktuwzd.put("mapValMqscljnluqe","mapKeyXleqlettiml" );
		boolean mapValAfwhhtymoaw = false;
		
		boolean mapKeyIojnmllayue = true;
		
		mapValPcjwmktuwzd.put("mapValAfwhhtymoaw","mapKeyIojnmllayue" );
		
		Object[] mapKeyXynglcudaoc = new Object[9];
		int valYmecbrljqvk = 907;
		
		    mapKeyXynglcudaoc[0] = valYmecbrljqvk;
		for (int i = 1; i < 9; i++)
		{
		    mapKeyXynglcudaoc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valRbdcdybdagc.put("mapValPcjwmktuwzd","mapKeyXynglcudaoc" );
		
		root.add(valRbdcdybdagc);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Ssgicsw 7Agqpqmoi 8Fxatilxgo 9Nosvyvyfpi 8Ajjualuzm 12Olkgtmsjfqirz 10Dnhzbornvrh 6Rgzvplf 7Mxstoavo ");
					logger.info("Time for log - info 11Qxvdubtrilaz 7Nqveuwpl 5Jelpph 9Sxakusrsyb 9Teslrlwtgd 3Gslp 6Dvemcka 10Ocsjzuayvsj 5Wzeojy 12Tlejpilhizhvk 7Rzuqqqio 3Ytif 8Cjghvxujp 9Nmglzzuuao 9Dhwqmyuvcw 7Cuhkjdxw ");
					logger.info("Time for log - info 4Nkdor 12Sfrktcwehofvs 4Bamln 3Bebf 4Yqayd 5Rvdles 10Vewhdkxjxpf 10Ejjuohdapvi 9Bzeakmbcew 6Dauraen 10Raqwxfncnks 6Xwbvwut 4Lizws ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Yjcfnelixcyrr 10Wrxfqthtmpb 3Tpud ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Rdbi 8Scohjwmul 6Jgnktla 9Hwqlbsuxho 11Jksvuvcqhjmq 6Lxnbxsw 12Tdphrfvsxvnzl 3Iuly 4Jauhu 6Zqlcbsd 12Tnnvytisvlmlk 5Kmheev 5Mujzyj 10Tpnlomfywzc 10Lsnwtzvmnpz 4Bquim ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zadtu.owlhb.qsd.bfzb.ClsWgiwrqnvyw.metJmapoligglq(context); return;
			case (1): generated.pfjp.usowt.ClsIsioyesmm.metEsxosbsfuwm(context); return;
			case (2): generated.fhy.qnk.brj.xhy.ClsYgumeudbf.metVozkhelpekwnp(context); return;
			case (3): generated.hioa.tbao.juo.tlh.zgppg.ClsZtwfn.metIybrdbhypesv(context); return;
			case (4): generated.qspb.cjle.nfu.jdnb.hwx.ClsNgqnidoia.metUiocavtovwi(context); return;
		}
				{
			long whileIndex22818 = 0;
			
			while (whileIndex22818-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varCtltejpezaa = (Config.get().getRandom().nextInt(190) + 0) + (Config.get().getRandom().nextInt(270) + 8);
		}
	}


	public static void metEliwmlxsgnolka(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valZfxmuajxqec = new HashMap();
		Set<Object> mapValDgldntnbwzw = new HashSet<Object>();
		long valVeggwuksgww = 8727038936984702413L;
		
		mapValDgldntnbwzw.add(valVeggwuksgww);
		
		Map<Object, Object> mapKeyViqhrwoddgf = new HashMap();
		long mapValLmvsftimbsw = 869792368005436422L;
		
		String mapKeyDvbjuslokuf = "StrNbdocuebnjn";
		
		mapKeyViqhrwoddgf.put("mapValLmvsftimbsw","mapKeyDvbjuslokuf" );
		int mapValHsuksrknvxu = 780;
		
		boolean mapKeyObwzrzfddds = true;
		
		mapKeyViqhrwoddgf.put("mapValHsuksrknvxu","mapKeyObwzrzfddds" );
		
		valZfxmuajxqec.put("mapValDgldntnbwzw","mapKeyViqhrwoddgf" );
		Map<Object, Object> mapValHwkufejzutk = new HashMap();
		String mapValJlzbdpdmanz = "StrKydkzpytfmu";
		
		String mapKeyLigulpdxwjd = "StrRnbudsnerpt";
		
		mapValHwkufejzutk.put("mapValJlzbdpdmanz","mapKeyLigulpdxwjd" );
		boolean mapValNnuonjoliuj = false;
		
		int mapKeyCoxzrstzdqs = 699;
		
		mapValHwkufejzutk.put("mapValNnuonjoliuj","mapKeyCoxzrstzdqs" );
		
		Object[] mapKeyYfsfolicxpv = new Object[10];
		boolean valJlnonsummpi = false;
		
		    mapKeyYfsfolicxpv[0] = valJlnonsummpi;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyYfsfolicxpv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZfxmuajxqec.put("mapValHwkufejzutk","mapKeyYfsfolicxpv" );
		
		root.add(valZfxmuajxqec);
		Map<Object, Object> valRezlwfliqbu = new HashMap();
		Set<Object> mapValAujjmwrnrit = new HashSet<Object>();
		String valFctwrlorcmj = "StrRahcjoxkoiu";
		
		mapValAujjmwrnrit.add(valFctwrlorcmj);
		String valCnlysdthlps = "StrQksfwmkijvn";
		
		mapValAujjmwrnrit.add(valCnlysdthlps);
		
		Map<Object, Object> mapKeyRtreiktfoiz = new HashMap();
		long mapValVqufydmnaep = -7958189452441560470L;
		
		int mapKeyFbikpmufvzy = 756;
		
		mapKeyRtreiktfoiz.put("mapValVqufydmnaep","mapKeyFbikpmufvzy" );
		int mapValNkpvbapjdqq = 655;
		
		int mapKeyXfklwfwgehs = 335;
		
		mapKeyRtreiktfoiz.put("mapValNkpvbapjdqq","mapKeyXfklwfwgehs" );
		
		valRezlwfliqbu.put("mapValAujjmwrnrit","mapKeyRtreiktfoiz" );
		Object[] mapValZpydiuaadlr = new Object[5];
		int valBenumylsytq = 853;
		
		    mapValZpydiuaadlr[0] = valBenumylsytq;
		for (int i = 1; i < 5; i++)
		{
		    mapValZpydiuaadlr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Map<Object, Object> mapKeyRuyknbqnjwl = new HashMap();
		int mapValQetvpbyeiun = 888;
		
		String mapKeyYmwqbbuqnfm = "StrEefvpninbix";
		
		mapKeyRuyknbqnjwl.put("mapValQetvpbyeiun","mapKeyYmwqbbuqnfm" );
		
		valRezlwfliqbu.put("mapValZpydiuaadlr","mapKeyRuyknbqnjwl" );
		
		root.add(valRezlwfliqbu);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Yvbk 9Hpurargzdk 4Qvazw 6Nnlfthx 11Qhqufnnvdcmz 6Afvtsux ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Nzcetunxefy 8Lgwpkfijr 3Popx 5Urmdmp 10Nyqmmazxgvl 3Zbla 5Fxgzmz 11Ydfgjtokbfrq 9Rxljrvewxh 12Pvmlfcywrftza 8Dqsunvtvm 7Dzzwdaki 7Xjfummka 6Umcodmx 3Doek 10Fuzlvjsoyki ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Fidbdeiytyngv 9Jwaahmhfic 6Fbllhxt 6Rvbnluo 11Aheekkrwnplq 9Vmsocudehq 11Ufoilkldxicl 3Zdfg 9Utleobkuxo 11Wbfvapgtobcr 11Higjsvfucesr 12Exmqfqlaycfks 7Ombpcowh 11Tqgfaqftgomx 4Svqic 11Biffjaxlbbdz 4Qmvua 12Punfkpuskdwjs 12Bmydusbssepnh 11Moagfwkjptmk 3Oybq 10Ryqwhhnsoab 3Jlhx 8Eylinrgge ");
					logger.error("Time for log - error 3Faaw 10Tclqnysfimy 10Vbghrfzriro 12Xqauqxuukrant 5Rxwwkw 10Ajyekylyhii 3Hfjx 7Zevhnsdp 6Sokxgnn 8Slqryaydv 9Jfnxoxtdla 8Bgqarydlo 12Tslgeellgrtch 12Znuwbddpsnnpq 3Weuk 8Vysyzvgar 3Seqb 4Aaylk 4Cutwp 11Ypeuvpqcjfjn 4Rlald 3Ekvv 12Bnkumrgwupiqc ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xcud.xbp.eztj.gexk.ClsTupoxajhjshtec.metEsfpmpnsdd(context); return;
			case (1): generated.hjt.myuvv.hkc.tfpi.ClsJfukwmizredp.metYduwrchx(context); return;
			case (2): generated.mfs.dojso.dpce.wrahj.ClsUayolgnak.metOsxqvqfsqlaj(context); return;
			case (3): generated.yfyks.sksk.asgi.ClsXzaehxcicrdskw.metUnjvim(context); return;
			case (4): generated.iwmr.swhrn.ClsOqphojsm.metZpnazknfwlswat(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex22826)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirKqscvtybgdx/dirKjbtwnkfnko/dirOjgnzpguznp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((Config.get().getRandom().nextInt(962) + 3) % 832967) == 0)
			{
				try
				{
					Integer.parseInt("numYrafrrurokr");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex22824 = 0;
			for (loopIndex22824 = 0; loopIndex22824 < 2427; loopIndex22824++)
			{
				try
				{
					Integer.parseInt("numXgveebunkfe");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
