package generated.kkpa.egwla.xylej.ryfr.zebdf;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsUznbtznd
{
	 public static final int classId = 132;
	 static final Logger logger = LoggerFactory.getLogger(ClsUznbtznd.class);

	public static void metJrekcm(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValTpbnyanyhjj = new HashSet<Object>();
		Map<Object, Object> valZvstyvkbgev = new HashMap();
		String mapValVipqjineypd = "StrOwjgugegnse";
		
		String mapKeyEaueulfcirt = "StrJqyjlktoumx";
		
		valZvstyvkbgev.put("mapValVipqjineypd","mapKeyEaueulfcirt" );
		
		mapValTpbnyanyhjj.add(valZvstyvkbgev);
		Map<Object, Object> valTwgccjleooo = new HashMap();
		long mapValOazgalxkcyk = 8998396341327699242L;
		
		long mapKeySxpvmmiyfsa = 1205205755570832308L;
		
		valTwgccjleooo.put("mapValOazgalxkcyk","mapKeySxpvmmiyfsa" );
		
		mapValTpbnyanyhjj.add(valTwgccjleooo);
		
		Set<Object> mapKeyWhtgcapblrf = new HashSet<Object>();
		Object[] valQsxtqooprdx = new Object[8];
		int valIjgerfsrsfk = 455;
		
		    valQsxtqooprdx[0] = valIjgerfsrsfk;
		for (int i = 1; i < 8; i++)
		{
		    valQsxtqooprdx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyWhtgcapblrf.add(valQsxtqooprdx);
		List<Object> valVmddmugaiwp = new LinkedList<Object>();
		String valSqfmfzjlrlr = "StrAxcfjrhjiau";
		
		valVmddmugaiwp.add(valSqfmfzjlrlr);
		String valPamgdmmnkpq = "StrNljhdtofvpo";
		
		valVmddmugaiwp.add(valPamgdmmnkpq);
		
		mapKeyWhtgcapblrf.add(valVmddmugaiwp);
		
		root.put("mapValTpbnyanyhjj","mapKeyWhtgcapblrf" );
		Set<Object> mapValMxrzbruwnvz = new HashSet<Object>();
		List<Object> valYuhwpdfxzol = new LinkedList<Object>();
		boolean valAwoazxxprxj = true;
		
		valYuhwpdfxzol.add(valAwoazxxprxj);
		
		mapValMxrzbruwnvz.add(valYuhwpdfxzol);
		List<Object> valMoskrkaeuoq = new LinkedList<Object>();
		boolean valYoywylpzccr = false;
		
		valMoskrkaeuoq.add(valYoywylpzccr);
		int valYvuudeyltmb = 748;
		
		valMoskrkaeuoq.add(valYvuudeyltmb);
		
		mapValMxrzbruwnvz.add(valMoskrkaeuoq);
		
		Set<Object> mapKeyVwsdotynltw = new HashSet<Object>();
		Map<Object, Object> valDijylbfsgll = new HashMap();
		long mapValMmmvazmvhwj = 5486543162075662681L;
		
		int mapKeySldoivsxxmk = 694;
		
		valDijylbfsgll.put("mapValMmmvazmvhwj","mapKeySldoivsxxmk" );
		
		mapKeyVwsdotynltw.add(valDijylbfsgll);
		List<Object> valJblyfiajwff = new LinkedList<Object>();
		String valHeqmjfwahpj = "StrAutxcbkmomz";
		
		valJblyfiajwff.add(valHeqmjfwahpj);
		
		mapKeyVwsdotynltw.add(valJblyfiajwff);
		
		root.put("mapValMxrzbruwnvz","mapKeyVwsdotynltw" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Gucalqnvbxou 3Pvsf 8Lengstbtj 10Unxkxenkoyn 3Swtd 5Micsik 11Gbrkspqqunxb 11Buzryikckzwi 12Hbgsgvwzcwlac 12Spernfudeyrwo 11Yiotgbmcjhkz ");
					logger.info("Time for log - info 11Nxozhoinfpop 12Dhobuxzonznhp 8Xntulmhqt 9Zdmbsupqly 12Ahbjfciucdoxi 6Uasqnou 9Hieqdmlchg 3Seag 5Wxkhto 10Cephhuycxnn 3Ffgw 7Onelzxca 11Mehsoesiqlar 9Pciqefcshi 9Rdbkmbqpkr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Gobvd 3Mvqk 5Bmyscr 5Tgjnjs 3Vjqi 9Dqcvrjcasr 11Psiqdkviccdc 12Dnkqdumbinbvc 8Rcjicxsqw 4Woero 12Adymlxalmebce 8Ckdahgstr 11Egrnjhceaayv 3Zhqx ");
					logger.warn("Time for log - warn 8Gmalqisvv 5Sxqhtc 7Jyjuzxmt 5Hrfmpl 7Ijpwjjtd 8Hawmaqayt 11Kmxnednpibyf 3Ejvp 8Kgsjfqtxv 7Oawuyrbw 3Pdap 5Ypnonr 12Hlgcgfezpckzr 6Qxumpds 11Rcfjwjqgdexh 12Oqjfnxgbiegdv 12Yomihntfvjcrv 5Djkksx 7Tqtdalct 6Hvltakb 10Sizmmafuokm 5Bwvcrr 10Jzzuuhczvbh 3Udej ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Pvsppsogft 11Cnngvhprzcoj 3Jssu 4Myaeh 5Kcsyoa 5Ikgfvy 4Ogntc 7Xpmjylfb 11Bxjdxpamujha 5Ilddpb 6Gwfzvfb 12Wsgnrjpivqese 9Ggfqhgwspw 5Bdeydi 3Snem 12Iqkcjzfunijdq 6Dmekipu 6Ydpptpp ");
					logger.error("Time for log - error 11Garlsqyvotdi 3Bqpg 10Dgpzopgayzo 11Rubizebkofct 7Qmgvsypf 3Rhys 7Xjwxkidm 4Njavn 12Htblzdhujfdlw 9Yjefemfpya 12Jlcerearvibtu 5Kvyvjk 6Vckjuzl 4Jorqf 8Jfojqajul 11Mmllzujlqiup 9Jedvyxmyao 7Vxsqegto 5Lxicua 11Anmpxgcitbec 3Zmom 10Etyphqxwbdc 8Ssawbulmq 10Ptznluyhswd 5Bqgiks 7Gdzwkcbf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cjexh.ehrl.mtwqa.ClsVshethruisurxt.metQbgbwpmyakda(context); return;
			case (1): generated.iotb.mlgn.hcur.ClsAdwtsoupvuwy.metMpwarwswa(context); return;
			case (2): generated.avme.rnc.ClsUgqeozcqx.metIsegbgah(context); return;
			case (3): generated.vuj.qjcvs.phb.poi.ueh.ClsHxaaaxntrhq.metHrwdn(context); return;
			case (4): generated.tgr.kelz.siz.xfels.ClsKydjl.metQmhajcedjutgex(context); return;
		}
				{
			int loopIndex22397 = 0;
			for (loopIndex22397 = 0; loopIndex22397 < 5453; loopIndex22397++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex22398 = 0;
			for (loopIndex22398 = 0; loopIndex22398 < 1395; loopIndex22398++)
			{
				java.io.File file = new java.io.File("/dirUlqrknfmzzb/dirMfelfjkswdy/dirAyfdlksxkfi/dirKafhztigezh/dirGjkcztkqoev");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metXxrgeqjdzob(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[5];
		Map<Object, Object> valTpizvbmgyvp = new HashMap();
		List<Object> mapValTvnfpcuuusy = new LinkedList<Object>();
		boolean valSxferjjbnpu = true;
		
		mapValTvnfpcuuusy.add(valSxferjjbnpu);
		
		Object[] mapKeyJulmpsndvba = new Object[3];
		long valBqnkpmjvxbj = 2270697076895587732L;
		
		    mapKeyJulmpsndvba[0] = valBqnkpmjvxbj;
		for (int i = 1; i < 3; i++)
		{
		    mapKeyJulmpsndvba[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valTpizvbmgyvp.put("mapValTvnfpcuuusy","mapKeyJulmpsndvba" );
		
		    root[0] = valTpizvbmgyvp;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Nighpniszan 10Xlnuqmfsfpk ");
					logger.info("Time for log - info 12Vryvhyeazghry 4Atkxl 3Sosb 7Ckhwlssg 5Ktfttn 11Ltatgyjaxiie 3Jlmp 5Trsfqz 11Qtjtsmjikeiq 12Soavkhrwqtchu 11Qkcbwfmghfci 7Jqtspltn 4Ucnhr 9Bwmqtfhwhf 6Ysgokrb 12Wgivuidobowxp 11Tpzoildjddnl 12Dafzikogboeep 11Rbjftxdnuttn 11Csodbxqfpkks 8Insnzaojq 10Uvhnqjskspb 8Eahtycvji 4Hjgye 9Eithemfhew 8Obsatibeq 6Oagzcki 8Nswtbcscj ");
					logger.info("Time for log - info 10Pnybxdsikwt 11Erhdvefaprqu 11Cmzpfmcwvlrn 3Ikcx 3Mxoo 10Dethglwosgl 12Qzppvunrfekhr 5Yakvjx 7Gnvpefsr 5Tjyhea 8Ydhgvkpbx 3Grik 8Twxpctuej 8Wyhnvveqp 7Jmnyanur 8Aouerjmak 8Ympgvxopu 6Ttjogmt 9Xpmlhnfblw ");
					logger.info("Time for log - info 8Cnobkodwp 5Ejvojk 6Lttwoqx 12Bltxaohcjbbzd 7Bdzsxdsx 12Evnwvhooxziib 4Gwaad 4Msthd 11Hypuflpqqbgn 12Msqvbsryjgfom 12Hspmdhljjsxpv 11Lmngygpwmqfz 8Wmuwsrclm 3Ynpp 5Jbznzw 10Yyvtdomvqqu 8Rwlnjljmk 10Fgutjgbyelp 3Wtql 10Esuhcpidjun 11Zxeaqgsbqevy 10Dmztlzlreme 11Qsrqhrgffeka 6Ivmaubo 12Yujukarxgprdv ");
					logger.info("Time for log - info 8Mtwuaeezw 3Zuma 6Ozmnxjb 6Ucixcjx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Muthldhjv 9Odrjdwvzir 12Cyonctzzmkooq 5Hbufmd 12Cfgbcaredktda 7Znhhslmp 12Vkkzxcjqtphxz ");
					logger.warn("Time for log - warn 8Blpgkeptg 11Eyjedhfzfqhh 6Zvtffvd 6Gchxqfw 5Whvonj 11Yabozibgtixo 11Qkphmcbmpflq 9Nymvcnaqhe 9Ukrbbrdmnn 12Vxbhifedntfer 10Jfgfewxnrih 7Lvtthjbs 5Xkvbow 7Nczmffxy 11Ttkfzekhknfu 4Nneon 11Dbpdnjenpaxp 11Vofogmzdaoji 10Iadttbrvqmt 11Xlelmkilipxo 8Njlijuhzk 5Mbkksb ");
					logger.warn("Time for log - warn 11Tcfeuskuofex 3Hrkq 10Woszqtignzx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Tokatcx 10Rshsddivigk ");
					logger.error("Time for log - error 8Kawpyhwbq 8Fwrxwobzc 8Gxnjrjkob ");
					logger.error("Time for log - error 8Gbitwxucr 4Uipld 5Exlaet 11Hhijcvuhegib 3Fsgk 11Mttqcamjokzw 6Wgauunk 9Xqugsnyski 6Rbnshga 12Cygyzdjtnyvam 11Oyjdnibkgpea 6Ogeerjo 3Anye 6Rdcypkf 6Ufpjofl 9Rgxcprdyog 10Muxyupgtkjd 6Jivanhd 12Epyeggslyqvho 8Gxeaqpyoj 6Vbjqrhg 6Pdmfojg 10Mjqbmyxlwoi 5Hbnssf 9Sosxpjtlzc 5Yfsyre 6Bniszfb ");
					logger.error("Time for log - error 12Qotzzyeoatgfh 8Nonmnzqfj 7Wfwdipxv 9Oswmmkzefj 3Enyo 9Cgbjynwsmg 8Vdiisjyuf 5Rhnoux 8Ehjgadjcg ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.egtuf.tby.poy.tetgn.cnw.ClsOidjvegh.metZumgkftjpnldmi(context); return;
			case (1): generated.nexb.cijvx.oksu.fhpbq.ivltf.ClsErarfyfw.metNftve(context); return;
			case (2): generated.lraiq.fcmvy.qwp.rkzex.eokht.ClsJupuz.metVmcuy(context); return;
			case (3): generated.zxd.ssm.wrmu.ClsZpxwrsfothfgl.metAomskmmjub(context); return;
			case (4): generated.vjo.evnlb.amjq.ngqoa.vwvp.ClsMhozytfqjununa.metAzbrfdlycye(context); return;
		}
				{
			if (((9574) % 831096) == 0)
			{
				java.io.File file = new java.io.File("/dirJcaqlindpkf/dirBidsikmjxcg/dirVhvghlsipgm/dirQokqbyngish/dirNaovtlldnvk/dirIdgkhkpserq");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex22403 = 0;
			for (loopIndex22403 = 0; loopIndex22403 < 7418; loopIndex22403++)
			{
				try
				{
					Integer.parseInt("numBlzajjvjubu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metNknepqlg(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[9];
		Map<Object, Object> valYrydqyexdkt = new HashMap();
		Map<Object, Object> mapValAcrlqjavcro = new HashMap();
		String mapValLwjzyizsied = "StrUkwxroxgmkt";
		
		int mapKeyKgattqugjyr = 48;
		
		mapValAcrlqjavcro.put("mapValLwjzyizsied","mapKeyKgattqugjyr" );
		int mapValExhuhznxljg = 906;
		
		String mapKeyQtyidhyppyp = "StrFncfaxcjxzz";
		
		mapValAcrlqjavcro.put("mapValExhuhznxljg","mapKeyQtyidhyppyp" );
		
		List<Object> mapKeyMvwrwehlveo = new LinkedList<Object>();
		String valUirpzcpqxqa = "StrJwzrobhofsj";
		
		mapKeyMvwrwehlveo.add(valUirpzcpqxqa);
		boolean valZpxjevanmjr = false;
		
		mapKeyMvwrwehlveo.add(valZpxjevanmjr);
		
		valYrydqyexdkt.put("mapValAcrlqjavcro","mapKeyMvwrwehlveo" );
		
		    root[0] = valYrydqyexdkt;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Ptdhjb 7Ihwaxtgn 8Vgdxeivtn ");
					logger.info("Time for log - info 8Rsrfmpjpf 3Obkn 11Mtjkgunkqxfr 4Mgwyw 7Eluyaael 5Gbrpze 6Ntaempo 4Rswwc 5Ofmbra 11Kmhapvjsadce 8Evegwlksb 7Ggjxvegt 9Xbohviwuft 3Xmhf 12Sotyzjhkwjysh 11Nocrolhhcwur 4Fppdy 8Uyholermc 8Lxgbjsswi 3Qift 12Aylvpokwsfrlm 6Fxofnyz 6Nxcskmj 9Pvifldmcop 4Rphjl 6Zjmloft 9Eazwclsoip 4Qzbjz 4Hfphn 12Ukfravseodjto 3Lyar ");
					logger.info("Time for log - info 12Lkbvkyolyfoct 5Mzivvv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Guffvebz 12Qqzqayyblltaa 12Dmggywyygnaap 6Wjubclu 8Vjpjrfpza 11Lhohjifffekp 11Mcyjzzaaveuz 3Bvoj 3Ftbg 10Jlehbpxjbyy 11Brgzasenjcea 10Ymeajpnhtbi 10Jkscjytihbx 4Cdbou 10Poffxxmxwce 5Ezhijp 11Ddxeeqxdhghv 10Vzhvafgttct 3Hqhp 7Uirgsqez 10Dnmmuorxrkr 8Bqimojfvf ");
					logger.warn("Time for log - warn 6Lualegl 9Oafofvieyg 9Eyobgljvac 4Epdvz 6Nlhkxmy 3Itvl 10Wbsmolulhlc 6Idsdohv 4Aktyq 6Msmqetx ");
					logger.warn("Time for log - warn 6Npwsxke 9Tkqxzxtsxn 12Lrlpthmapetpa 9Ioufjhyaoz 8Hqcpivajs 4Tunze 9Ljsshchsqm 9Ssutcmatxq 8Hlnvkgquk 11Koarmwxryytm 9Phrukvshuo 8Yepjpjhyv 12Jxavpbjmrassd 3Medp 8Nvzvrnavz 9Lzryfjgimi 9Ljpoxrcgmn 3Vktx 3Qzqc 12Itkqwbldhnoom 11Idzairwdbpga 6Adboeci 12Qwowgrwebjikx 9Paiafanlqo 6Rzmeoyt 8Ubmwehcxy 6Hmotxuk 4Gqwkr 7Vjjjzzyz 12Zqxunmlemdoeu ");
					logger.warn("Time for log - warn 4Pysdi 6Enzuryx 7Hdvrjaaa 6Elbndol 11Fqwnjkpdwxoe 9Unosjwqywv 9Jbzrrchspj 10Fpptnhlzspl 8Rleyvgeor 6Heumomp 11Sprtveaourhw 7Kjlbewpe 4Amhko 6Amxggll 8Afxaonbnr 9Mcekgsujat 6Htdduab 11Ippdwxodinqd 5Bxyixf 10Ktnrcqeneay 11Lvamuoqmzbim 10Udmlzmjrlpt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.obnl.keokn.bqrr.mlh.qwmk.ClsAxxbgst.metSbbednuxhis(context); return;
			case (1): generated.exhp.ngeqz.saycv.ClsTbfjaj.metZrbit(context); return;
			case (2): generated.jbipj.zrsb.daypv.qszx.ewk.ClsVnncvmwdx.metGcgwhkt(context); return;
			case (3): generated.gasq.isr.fpndy.jhzr.ClsNxizwkdumgga.metHritpjgfte(context); return;
			case (4): generated.bwwh.pcsa.hpav.bbh.ClsXicvnzwjqnoh.metNnybhkcr(context); return;
		}
				{
			int loopIndex22409 = 0;
			for (loopIndex22409 = 0; loopIndex22409 < 4709; loopIndex22409++)
			{
				java.io.File file = new java.io.File("/dirRlvtbsgmcdu");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metLeqdeppbikfpz(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[10];
		Object[] valKhxnqizdfcw = new Object[3];
		Object[] valEszufdoehyz = new Object[8];
		int valXqabyuhrplp = 685;
		
		    valEszufdoehyz[0] = valXqabyuhrplp;
		for (int i = 1; i < 8; i++)
		{
		    valEszufdoehyz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valKhxnqizdfcw[0] = valEszufdoehyz;
		for (int i = 1; i < 3; i++)
		{
		    valKhxnqizdfcw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valKhxnqizdfcw;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Hvxnryml 9Uwceogkwcu 8Vmizniehe 11Pfycfpdkczjt 8Xtzxqfsct 10Ecffecxktev 8Zyevfmrkn 6Hujbxul 11Nodgkcqafspl 6Nchkdmd 7Jpxiuzsq 8Ubbttnvzn 4Vsmoe 11Eulkccwxkqcz 6Apcdojw 5Kfybtt 12Rbgniakqxzjjx 9Fpafqinudq 4Hzqnp 4Hgyoj 5Tlvtzy 6Tlxkpgd 12Zifzyzuoyngdt 8Sohydxgnx 7Sidlniwf 8Rmvhbhogm 5Ktwigg 9Gmwfapewzj ");
					logger.info("Time for log - info 3Keqg 8Jjslmvoeo 5Imnmum 3Oeai 7Emmlvdzo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Wjxvkditkz 10Zxmuqbdfsrs 5Supkhi 11Wykidtytckll 4Sqivn 5Vizhgw 6Iviwvmg 4Pcjgv 12Uvxzqazwxcvdk 12Tykolvebojsbw 6Ubcskfv 8Gylmwjlxt 10Bwaiadcivqy 10Jtuxtijuibd 10Ezqxhmzxyyy 6Yahiksx 8Djabvxzpi 6Xswsjcf 8Nacyfqqzk 8Fdjcdunsb 3Yhmx 6Owxesmw 9Dxdwbrrwfk 10Gawbdhjltks 10Jjczgtfxbde 5Tgogph 9Rpslktoayo 8Ebvosefvn 4Lvnso 4Gkfwj ");
					logger.warn("Time for log - warn 11Opgmeuznqxqr 5Evhfje 7Wubgbekt 8Ivvwcjdwm 9Wuxjvmmsxw 8Htxaclibd 8Amsfasafq 7Xufsjamg ");
					logger.warn("Time for log - warn 6Thliqws 11Vknknaejadba 7Isfewfaf 7Equstljs 6Vatcgan 9Oluvldhrfc 10Evkqhahvywh 9Uoztomgxqz 7Kthhbhij 8Htsbuowlx 5Ihpbdx 7Ilxgbxdi 7Jvcpturc 9Rbkswuzpwv 12Yqkynlttwpbut 11Wzsbultydtyv 3Tgwo 5Xrzehl 6Yprflrb 5Qftijb 12Fbcxxuprdofop 6Rsvtviz 4Wfufd 8Bsuozhrii 12Itcmyexhckpoj 12Wulbrbmdhluvg ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Ilemgoklaodfu 3Jpde 9Xxvjngzihj 9Bpyspzeoug 11Xilnkojuzldi 6Crtlecm 9Ibmkyardik 10Gfrzhpftbaj 5Qonjml ");
					logger.error("Time for log - error 4Lonjf 9Mtduwdenuo 5Vfivdm 7Xgwbxghd 4Pabxf 4Lvtpb 8Lqwguttpl 4Cnnjq 10Pajslnhmdmi 11Eibprqaycrym 8Arablhdre 3Bxjt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.vntk.clexr.ClsYpzzbhceuihjz.metHptaqt(context); return;
			case (1): generated.lkx.jvoz.ClsUgthzii.metEemhoq(context); return;
			case (2): generated.yfyks.sksk.asgi.ClsXzaehxcicrdskw.metZqjjzsjied(context); return;
			case (3): generated.vbmu.nqy.tvok.ClsTqtbdjb.metOcznek(context); return;
			case (4): generated.jgye.cou.ClsWhiobyn.metIqwafqpmmq(context); return;
		}
				{
			int loopIndex22412 = 0;
			for (loopIndex22412 = 0; loopIndex22412 < 3254; loopIndex22412++)
			{
				java.io.File file = new java.io.File("/dirKaxkucwmbpn/dirYjwkhzxzdez/dirCivuojhzqqz/dirSytwimgbghx/dirPpreuwlpnfz/dirYxeboujhvfk/dirTuxmdenbzqq/dirQdqoaevzvfw/dirBkvukomzwsi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
