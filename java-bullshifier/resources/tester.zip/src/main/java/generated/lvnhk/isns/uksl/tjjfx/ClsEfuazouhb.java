package generated.lvnhk.isns.uksl.tjjfx;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsEfuazouhb
{
	 public static final int classId = 481;
	 static final Logger logger = LoggerFactory.getLogger(ClsEfuazouhb.class);

	public static void metWdieisfxwfvz(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValMsoaupvwikm = new HashMap();
		Set<Object> mapValXixuqmswxyi = new HashSet<Object>();
		String valKedvjtqlphl = "StrGivbdtrkoip";
		
		mapValXixuqmswxyi.add(valKedvjtqlphl);
		int valXooeunspjqr = 156;
		
		mapValXixuqmswxyi.add(valXooeunspjqr);
		
		List<Object> mapKeyEzrtveiqyqk = new LinkedList<Object>();
		long valYkvxxcfafow = 7100492496268623509L;
		
		mapKeyEzrtveiqyqk.add(valYkvxxcfafow);
		
		mapValMsoaupvwikm.put("mapValXixuqmswxyi","mapKeyEzrtveiqyqk" );
		
		Set<Object> mapKeyLpkjofskixy = new HashSet<Object>();
		List<Object> valDdfpyhavwab = new LinkedList<Object>();
		String valAilravsqnhw = "StrTfphqqmvgtr";
		
		valDdfpyhavwab.add(valAilravsqnhw);
		
		mapKeyLpkjofskixy.add(valDdfpyhavwab);
		
		root.put("mapValMsoaupvwikm","mapKeyLpkjofskixy" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Zkvxgfha 8Qgexaofzu 8Gpyzhfpps 12Wkgyllmmgnkcl 9Lnbpbekqit 8Lghtluekh 8Fnxamseif 5Yeylpq 6Mfywerx 4Aikyp 8Zfrutntqh 10Qblmavkjtrp 9Nulmqiqftp 8Ewcvwfngl 10Sszgpmmqrhi 3Stwn 9Mdrrqoeyfs 3Hiba 9Kekpzcaofd 5Pzrasa 10Sygqtkludhc 5Wgbmto ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Cwnnrcklnkhss 8Nttooxgvd 8Ltceqvnxu 9Bshoyffiuo 6Duzbkwg 6Aaecfny 7Mqxrgxqq 3Duyo 11Ggmvxpftaqwi 12Epmlvtpgyextq 11Pxeuymcbpgyg 12Hchbypdbbjwwq 12Nffgwfotikman 11Rmdlpkvyutjj 9Fshoevqabn 3Vilk 5Fvhpzu 10Reqszdgzusa 4Sxaao 9Syzztkwdxu 10Vjfdfqkrdtk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Jobxxsxpjav 7Ghbyqotf 5Shlsly 7Xyjihzcw 12Vpmxhrxwauqbj ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aby.eyq.viq.flsc.ijccw.ClsKeovzqbtjs.metTizqtcinnozd(context); return;
			case (1): generated.hdrlt.jxdm.bjqs.pupxs.ClsZoyaigxdyb.metFgucuumqevet(context); return;
			case (2): generated.vbpvl.ppexe.hnrdr.zcxzm.ClsCvshjbmkqrb.metJcfyp(context); return;
			case (3): generated.evl.qnyx.qnt.hnkpr.mua.ClsPqzytqp.metApjoptaglnaty(context); return;
			case (4): generated.weide.dnna.unvd.vtw.pcbre.ClsExwicwtb.metHqnibperro(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirLsikmryklkg/dirQhbilhyitbp/dirPpkdiwuortr/dirSanoawxkbjc/dirKogibsshuja");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex28106)
			{
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirNrgyjfxvphb/dirLbwofdotpdi/dirAmtwhmkbzdb/dirHqvrqwknflk/dirPuvhidfkvod/dirQwutmhjazbr/dirJdbgxidnqsz/dirGvsnaifyizd/dirCicrycyarsp");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirIooqaowlylo/dirBarmmbovtyp/dirCjexyqmkpfd/dirBqjkbwptndu/dirHpbcjvzspqb/dirYdjzttrtvwl");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			if (((1023) - (3372) % 488094) == 0)
			{
				try
				{
					Integer.parseInt("numLytjsgarzdu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metLybrkriiked(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[9];
		Map<Object, Object> valMkmtfpdzwpf = new HashMap();
		Map<Object, Object> mapValFduveryxdrh = new HashMap();
		int mapValKzwqtzcbryu = 659;
		
		boolean mapKeyWjzuhhxkhpx = false;
		
		mapValFduveryxdrh.put("mapValKzwqtzcbryu","mapKeyWjzuhhxkhpx" );
		
		Set<Object> mapKeyUtjcjfmkizd = new HashSet<Object>();
		int valJpoafvtyrza = 501;
		
		mapKeyUtjcjfmkizd.add(valJpoafvtyrza);
		String valDnonqnbjmvq = "StrRmlqiwftmzr";
		
		mapKeyUtjcjfmkizd.add(valDnonqnbjmvq);
		
		valMkmtfpdzwpf.put("mapValFduveryxdrh","mapKeyUtjcjfmkizd" );
		
		    root[0] = valMkmtfpdzwpf;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Jqxperwjptho 10Pkspaenpxog 6Sltuxci 9Fsuugemiuc 11Xwkguvpfodit 4Uezjo 3Qnba 6Tcojeyt 10Hkbuajsarhu 6Akeunmf 7Oayfsfze 10Wfnlgquzion 10Boxgrucxstx ");
					logger.info("Time for log - info 12Akdjzhclvwkbf 8Tnfszgojp 6Amddtcn 10Nyfgfsexoba 5Terxzf 5Bathee 7Ekwnhgvh 3Joxp 12Jnzjsindngyhx 4Jdkvx 5Xoqtan 11Tuylyiedsvua 11Xdfqtfjakgdh 7Xspdjkgu 11Lrjamlmpvykj 6Bnmzmmg 11Qdgoefthysxp 3Ogaa 6Blbzpox 11Foxskscnyhhe 5Hwkkis 5Drexlw 11Lkfqpqaqeyfv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Nudctrvij 11Dfqenqbdqaue 6Uoxapag 11Udcwyhiusowa ");
					logger.warn("Time for log - warn 9Zhtrvspavh 7Vbwjfrsx 3Onwn 9Urptdsmnqs 10Euqukmwkbdb 4Cwfdt 11Xxgztzojiiss 9Htzqkrfwpb 8Jgqrgbtju 10Dsrjthksqlu 4Kfrwu 10Mgieuocnxdw ");
					logger.warn("Time for log - warn 9Gjzwljjgyb 4Qxwzo 9Ptxhaszzvc 9Rkytqsmpzd 8Edphevhhg 9Nijegzopct 6Atwybkd 9Xfsiwmgkcb 6Cjdplcf 8Ozyprxfvz 7Kzmaqeig 3Yggm 10Maibahfctwn 7Hkjdscbq 8Uicykinji 3Gwmz 9Dnorhvocse 5Xmgjlw 9Vkcgfjtgsm 6Tengxsd 8Dgpatwbux 11Plabyuppgrfi 8Xaivnbkvm 5Tdxmzm 9Tjohxhvqmm 3Khta 6Amjfcjd 5Zeqowk 5Zhlphy 3Fmtv 10Dqpjbxwkcrj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Ynqjtxgvla 8Sewylzsqu 7Ypgmaqkj 8Plxalvzax 8Qhagrpeyc 10Ohnmxvfqbtm 4Cjqsz 6Opxdhrd 3Efvw 7Oattdxeo 11Rktxthrbjxlc 8Ytvycbpwk 5Bzuazu 12Ibetzlzsecvdu 9Lmgoshvhuv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yyztd.kdvzo.xtlfe.sqo.ClsTrzriiwcgvlv.metXboobndjklmxey(context); return;
			case (1): generated.qspb.cjle.nfu.jdnb.hwx.ClsNgqnidoia.metQznahmdoj(context); return;
			case (2): generated.fkbuh.vawj.ClsXsqsadsvdke.metGrquryhkwyi(context); return;
			case (3): generated.eddt.homo.syk.wqll.dyeuq.ClsYzlmjqrjjp.metMqehtaaykikdy(context); return;
			case (4): generated.mbn.igyf.ivup.sglb.ukb.ClsQzhoqgskicnjw.metBwwaliwybesa(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metZyecchsshso(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[9];
		Object[] valCiwiwatzaxq = new Object[9];
		Object[] valTlzaetywfyi = new Object[2];
		boolean valWobaxlmytnk = true;
		
		    valTlzaetywfyi[0] = valWobaxlmytnk;
		for (int i = 1; i < 2; i++)
		{
		    valTlzaetywfyi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valCiwiwatzaxq[0] = valTlzaetywfyi;
		for (int i = 1; i < 9; i++)
		{
		    valCiwiwatzaxq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valCiwiwatzaxq;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Hpiqzvqcyz 11Wtdyjuiguljo 4Hbhuf 6Zoojumi 11Swnlpfidtlrc 12Tfgsylmduyvlf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Ynqiglayfe 9Wohitwytoc 4Xcaix 12Pjpiecihrdwpt 4Ifnxb 11Gkgayeneymfv 7Yfsygoqn 3Emnl 3Ahfg 3Wnfc 6Oouoitb 4Sjmqz 5Pykcdg 9Nhnsnmstkl 7Tusnlnfq 8Vjmfydhrn 8Eyqwkncgz 3Dxoz 3Hxhr 11Uhytsorcpidl 11Qirtoxlpnfgr 8Lmpkgthgf 9Zhtxzobaxv 5Sdjfat 5Haioim 12Bqkudqhjtaeet ");
					logger.error("Time for log - error 7Vpnzrmoq 8Vxwpxgvkb 4Wefuy 9Pxyeqekwci 3Nswr 12Pxsjtjeruoios 11Ycfyomzhjbmc 11Rcuxbrkpunem 8Ruzipkycv 9Fdxeyglhws 4Xuwpo 7Spzlhjdg 7Jlsqljgb 5Lxehin ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.iiben.ptjec.naa.begt.ClsJlkmiazt.metAcwvrl(context); return;
			case (1): generated.ojyuy.hdvu.yij.nuf.ClsJtdiu.metUymohzkoe(context); return;
			case (2): generated.enb.ktdil.ClsEqcfzlhpy.metDsnfgxxtqarhp(context); return;
			case (3): generated.jrx.knq.qgl.klpmp.wqhuy.ClsPrfpvgkjefvagy.metPasaujrwb(context); return;
			case (4): generated.vhk.matvp.xpri.ClsIidoitanl.metGxvhrbomkawxu(context); return;
		}
				{
			if (((1384) * (9099) % 410313) == 0)
			{
				java.io.File file = new java.io.File("/dirUmddssthlgh/dirYwqilysqhnh/dirFkrlaookzyh/dirScxxjpbqgcf/dirPjsugazndfo");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex28119 = 0;
			
			while (whileIndex28119-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metUvvxajcpzq(Context context) throws Exception
	{
				int methodId = 3;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valCxgquqhwwkn = new HashMap();
		Map<Object, Object> mapValWfpbfuwsrlw = new HashMap();
		String mapValAdmqbwtyqcj = "StrEutjcsamdfm";
		
		long mapKeyJslpucvsmfa = -314685012252930075L;
		
		mapValWfpbfuwsrlw.put("mapValAdmqbwtyqcj","mapKeyJslpucvsmfa" );
		long mapValVjwtoidjjdi = 5678995041600946561L;
		
		long mapKeyAvfrynjslss = -7341054409783350382L;
		
		mapValWfpbfuwsrlw.put("mapValVjwtoidjjdi","mapKeyAvfrynjslss" );
		
		Object[] mapKeySwrqtqnukfg = new Object[7];
		long valWjesxociesi = 5472611508745999348L;
		
		    mapKeySwrqtqnukfg[0] = valWjesxociesi;
		for (int i = 1; i < 7; i++)
		{
		    mapKeySwrqtqnukfg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valCxgquqhwwkn.put("mapValWfpbfuwsrlw","mapKeySwrqtqnukfg" );
		Map<Object, Object> mapValRohmxvwtwhd = new HashMap();
		String mapValQywqubrmjku = "StrRouzeghzsmx";
		
		long mapKeyGgufgggjygx = -8620518275814440514L;
		
		mapValRohmxvwtwhd.put("mapValQywqubrmjku","mapKeyGgufgggjygx" );
		
		List<Object> mapKeyKcfejaygspf = new LinkedList<Object>();
		boolean valDuyrhwiutat = false;
		
		mapKeyKcfejaygspf.add(valDuyrhwiutat);
		int valKqzfwjykdhr = 705;
		
		mapKeyKcfejaygspf.add(valKqzfwjykdhr);
		
		valCxgquqhwwkn.put("mapValRohmxvwtwhd","mapKeyKcfejaygspf" );
		
		root.add(valCxgquqhwwkn);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Fdyvuygij 9Dcobcmlrqv 11Hogivhprfhjs 10Qaxjgndlfte 7Povjdzwa 11Brvgfnonkyal 10Sgjeovfoqtf 8Bvcpawnqt 6Rkxccgd 11Yzotnlbuqtlo 5Odoixn 3Lzbv 6Lqtchbd ");
					logger.info("Time for log - info 12Raooggwyfdazd 11Bmvzcjatrmuy 9Jreyiwzaiu 5Xmjelc 5Dijybx 12Wwbgwzrliqbcf 3Verb 9Radpwaiphc 11Wtsafvmprzet 10Vouhbbcpodu 12Xhwwtkplfeilv 12Qursgoqewbncn 6Oavuezs 3Otvm 7Ovkhgbqs 7Yhstpyss 10Yxaxfxeuvma 4Gwpcl 7Meoitmjq 12Ceytgjotyrwsf ");
					logger.info("Time for log - info 7Tbmtwfmp 8Zhdgwtxjd 9Icvmghbpmc 11Haqhmtbewosb 7Exklbhrw 11Hqowllzohmfc 9Nuxyqnfpul 6Llgdmzc 4Siiyn 8Znrltzvmh 4Ablfm 6Oqabrwo 7Vupoyppq 5Awyynp 7Zbzwfube 7Jugfbsuh 8Snnmyjajq 11Ibnjaywnqjdt 12Ahtzlcpodajig 5Wmaqyy 4Hryqf 11Dsufbauqcrrg 3Uqxo 7Mxlfvsjg ");
					logger.info("Time for log - info 3Cnlg 7Ixjmfaqt 11Aknueuzdolnp 9Viluolqruf 5Vpcdwh 9Lthyywsjxi 11Bcfzpximzgyl 5Wfzqrw 9Uoredxbhpr 11Bugramtnzaax 11Qvkbmjbhmqsv 11Huclcmlbsfnk 6Izyaciq 4Cuscd 9Bldcxoqhwg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Oioyecsfrltnh 9Rpflbfxtcx 10Zkxzuvrqyxs 6Fnroxqa 10Jizufvasjpa 11Jgekdgmwwcnh 5Idomws 3Utfy 10Bcetgschwij 8Suiwsoefi 9Xwkakzlejg 8Fqwrvfwbz 7Uconldjl 6Bazptln ");
					logger.warn("Time for log - warn 10Wougxcoglbd 9Rasxvbdfbo 10Gyflfhgfwas 12Ncvturubtvotv 7Bbpswitz 7Xamliwvl 4Mqdip 3Cqlp 3Vkui 4Dkfpc 4Otzeh 3Oedb 8Mqseikjix 10Szqbmdxyqmx 3Crvf 12Txtwuihnmamtb 8Rwyqrooqb 11Uzayuczbhhut 9Mfawevxrck 5Ekggam 3Lmba 5Rvpsdv 5Vbfwsb 5Sywagk 9Qiqxvkyfkj 12Dycylhmldigly 11Fkqrvlgtgzhe 6Tkvmgwo 5Njvniy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Arhqbbpjcgcw 4Pgghj 4Jjvdh 7Ntkohivk 6Ydqeseq 7Usytnqgx ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gmk.vzs.crbap.ClsEkyhsmjeh.metBjlkuzsllrtdeq(context); return;
			case (1): generated.mrfat.adk.zch.ClsYwqlnetu.metCadvvicigiy(context); return;
			case (2): generated.eedk.kvsj.tzabg.tqpy.ClsBuuqqzvjfxdiao.metNctcsrlrsyxk(context); return;
			case (3): generated.zuqq.dis.ClsZotjz.metPhpym(context); return;
			case (4): generated.rsu.hmuld.jzssz.bjyy.fod.ClsQixayqsiydaxm.metIpckuqrkv(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex28129)
			{
			}
			
			int loopIndex28126 = 0;
			for (loopIndex28126 = 0; loopIndex28126 < 5484; loopIndex28126++)
			{
				try
				{
					Integer.parseInt("numNoiutbknxgj");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numDmeabiymxie");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
