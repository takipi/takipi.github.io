package generated.vqli.xqs.ist.rcg;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsUlfrrjkk
{
	 public static final int classId = 62;
	 static final Logger logger = LoggerFactory.getLogger(ClsUlfrrjkk.class);

	public static void metUracnapyxnrd(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Object[] valZochvdwzzhu = new Object[6];
		List<Object> valIijidcfmgma = new LinkedList<Object>();
		long valOskarylxdec = 1017092489408085494L;
		
		valIijidcfmgma.add(valOskarylxdec);
		int valTqskooqbjnt = 662;
		
		valIijidcfmgma.add(valTqskooqbjnt);
		
		    valZochvdwzzhu[0] = valIijidcfmgma;
		for (int i = 1; i < 6; i++)
		{
		    valZochvdwzzhu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valZochvdwzzhu);
		Map<Object, Object> valPkyqdwpaysp = new HashMap();
		Map<Object, Object> mapValSjgswxxwnbz = new HashMap();
		long mapValVjhwjgcnhxj = 596600597071906319L;
		
		long mapKeyAhjoqhecyqk = 3364150491976700415L;
		
		mapValSjgswxxwnbz.put("mapValVjhwjgcnhxj","mapKeyAhjoqhecyqk" );
		String mapValScgdflyqige = "StrKbzlmcmkklo";
		
		String mapKeySyjwzjdxmuw = "StrHjrnxdpadne";
		
		mapValSjgswxxwnbz.put("mapValScgdflyqige","mapKeySyjwzjdxmuw" );
		
		Set<Object> mapKeyBpepqmigdwm = new HashSet<Object>();
		int valYrmbkofievh = 887;
		
		mapKeyBpepqmigdwm.add(valYrmbkofievh);
		
		valPkyqdwpaysp.put("mapValSjgswxxwnbz","mapKeyBpepqmigdwm" );
		Object[] mapValTqhruhdyjpt = new Object[3];
		int valLpdipcbsdgl = 759;
		
		    mapValTqhruhdyjpt[0] = valLpdipcbsdgl;
		for (int i = 1; i < 3; i++)
		{
		    mapValTqhruhdyjpt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyJsjrdrlentb = new LinkedList<Object>();
		boolean valMthmhfybcfe = true;
		
		mapKeyJsjrdrlentb.add(valMthmhfybcfe);
		
		valPkyqdwpaysp.put("mapValTqhruhdyjpt","mapKeyJsjrdrlentb" );
		
		root.add(valPkyqdwpaysp);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Avoq 7Jgfrkctt 4Fmlij 6Wtddtat 9Epruoowwsw 10Zrmehzieaem 4Ohpyp 7Rsdhgwiu 4Tuqeq 5Etujwz 11Xiypcypigrof 9Qgcvhoojov 9Piqbyolenv 7Wtqzvwll 5Nnhwnu 6Wbkfipv 6Dkufpwx 11Odxfkwqxykrb 11Imlzrozqoibe 4Eljtl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Dwdtqqtmbcz 7Yflcprvv 12Oizetrfdsbyln 8Hiqdpqtsi 3Txjb 4Pikft 6Fbjncfz 8Colvuzrqm 3Jdds 5Xgdeox 9Gffnwymkkb 11Lqedruykzitp 3Ypby ");
					logger.warn("Time for log - warn 5Jelhao 6Vsgisyl 6Rwysryz 12Mdvrwgbgyvzzn 4Pmeat 4Lbard 10Eiqqzdnprmb 10Mldaftkhsln 5Nqaycv 10Kpsoeuoytle 11Uxtdojqquknc ");
					logger.warn("Time for log - warn 6Knjwjct 3Eogd 6Svmqgnq 7Chvbkosh 8Udztmqetg 5Mtatii 10Huzxfoonarj 6Yalvoon 3Ogdg 5Nsbuxt 7Tysnnqht 6Ohfwmrs 6Kztewfz 9Ixdsjuqaoo 11Xowkrlohwzxl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Lnaukqg 10Cucdcobtqqr 5Tazopj 6Alfteha 3Oiwu 7Dwffjfdg 8Mcbfccuvs 9Ammvctcdnn 3Kvjf 6Dxongvb 12Uiwuhliimhrpx 10Huhkziywxqc 9Nwamxtppey 11Vlmljhilogjs 10Khfjzzmqayw 7Yaqwrglu 8Llqrquybm 5Vmiknx 12Btmqlceyicvss 6Fnwlbss 7Iyosqxyh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qwlax.zei.ClsAdxloruwrrth.metLkyzseqhzcwrch(context); return;
			case (1): generated.hbqjp.kifli.leg.jlyd.ClsYgtwztbknhdmc.metKqkztvaanyqct(context); return;
			case (2): generated.decno.psqz.bhc.ykgc.ClsIhnrz.metWxnztwbdh(context); return;
			case (3): generated.app.atudj.div.xmvbx.csga.ClsIfahtjloa.metFpyizltbyyrsxc(context); return;
			case (4): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metWfolwtyhy(context); return;
		}
				{
			int loopIndex21124 = 0;
			for (loopIndex21124 = 0; loopIndex21124 < 2090; loopIndex21124++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
