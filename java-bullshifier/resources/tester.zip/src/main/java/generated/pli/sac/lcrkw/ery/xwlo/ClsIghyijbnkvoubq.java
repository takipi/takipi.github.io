package generated.pli.sac.lcrkw.ery.xwlo;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsIghyijbnkvoubq
{
	 public static final int classId = 200;
	 static final Logger logger = LoggerFactory.getLogger(ClsIghyijbnkvoubq.class);

	public static void metJbowqxymhh(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[3];
		Map<Object, Object> valJiarzjvfcwl = new HashMap();
		List<Object> mapValVlvoxksnoye = new LinkedList<Object>();
		long valEpwrfapioqe = -5657738828001274469L;
		
		mapValVlvoxksnoye.add(valEpwrfapioqe);
		
		Map<Object, Object> mapKeyMkamymnkmlb = new HashMap();
		int mapValUgczwwngqcy = 795;
		
		long mapKeySaalvnwirzw = 4293961138923539323L;
		
		mapKeyMkamymnkmlb.put("mapValUgczwwngqcy","mapKeySaalvnwirzw" );
		
		valJiarzjvfcwl.put("mapValVlvoxksnoye","mapKeyMkamymnkmlb" );
		
		    root[0] = valJiarzjvfcwl;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Vqouzxg 9Niusetzaam 8Grmenojks 4Eovpa 9Zjvjbljydv 9Wyrdrfhcww 10Ecaposyykem 4Uolal 5Pjogyc 10Pyvizpkhbfw 12Mjtkwkdolbpcw 6Bpencbk 10Tfohucfiyzp 11Xnrdfstcytap 7Lyefukof 12Oiayimzauejob 10Makgidwvryt 12Yhbdglbsqwzcf 11Hucumksklmof 11Wpakecojwwkq 3Rnvg 4Zdkkr 5Bvsjiu 12Ipotugtuktgar ");
					logger.info("Time for log - info 5Kjuvfe 7Nnocaswl 8Xoyzoqypy 10Miudgkzdgiw 10Dxowfbrswub 10Oemescosunk 7Rdyavajs 6Alcqxsi 9Xqkegjvwzu 3Bvkv 8Yjzpzxfsv 11Vgtxycryippy 9Ujemxusbkm 7Coyvmrpx 11Xytaynfqnjyx 4Acrib 4Qfsgg 6Nlywmgq 4Qnqab 11Kchmaulepazs 8Kihxideur 3Wffc 8Wpzjaapuu 8Wnuleutsl 12Hkevcysdrdmof 3Smlb ");
					logger.info("Time for log - info 9Halcgyqkpf 5Qpponj 6Xtladxg 8Tfywbulue 3Efzc 11Lwgfieyiissq 9Ttwtwcwaez 12Lslzkdcgsyirg 12Nhpgwohzqecgm 8Ykcyofhtl 12Vrjkphydnoxvb 6Tsehxjj 4Kdfng 5Uqdiky 8Kstefgzum 12Tnavydbnuoqes 11Vloidnckyyzq 11Yayddudmadpo 7Mzlsipqh 11Rtwkcipomilj 9Wmlybmohgl 7Shkuqbyd 11Suoqutoybzno ");
					logger.info("Time for log - info 10Uizgvwxkdjm 4Fosmz 8Ijsultcvk 3Ygtq 12Ospienjqrslpm 6Nwnecuz 4Wexvg 8Yiyzxwpdk 9Tysruezmqn 12Avhpbzcwpmodg 6Kirmrcd 7Wxonvzmh 5Gbptkp 11Uguvujphsbxm 4Sknep 3Qwan 12Jkkxtfwvvpuvm 5Hhtidt 5Kjtdnl 6Mgfhwyg 6Yodbwhb 4Osomb 8Mrnzbdamv 7Utbobmjg 8Eundvjqds 6Nkawqov ");
					logger.info("Time for log - info 6Xjrzfsw 3Ynlo 6Spbcqvx 7Nsmmgcvu 4Jrouc 12Zurxkxetdnhqo 4Ltfmp 8Rapzeflsm 6Lkpprhs 9Ojcdllprwg 9Wayhyzadup 8Eywljpwsr 7Irzjhoqg 11Tavqtwiqfsyw 5Rpfzyz 6Pdiyewy 8Czwouxwwf 12Askbfneuxkqci 8Gthprqgwr 4Ynmgs 12Sqknyswjtperq 9Gpmuvamrhj 10Fncyxxzrwge 10Dwxrzxcqqvz 4Aejjl 5Yglgax 6Iwikczs 9Niujrlpcjd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Dfjrc 9Bbpxrknxqc 3Lrqg 8Ceuadvqth 4Dlamt 4Qacxy 9Wstykxhzhk 4Ofdky 12Accqtemzpovhu 5Clwnsb 5Rgjmmh 8Dknbeatqf 11Pmpqlbrdmwlf 6Ecwjyok 8Krddcayms 12Mpsymbvaulrog 10Qfgdnifdtai 5Yjdnav 9Pktlfyzopc 11Yhidjkubsasp 3Qxrv 8Dbvzyyvru 7Usjjhgzf 9Uisaeuqdpv 4Dxtcv 4Hoqlt 8Pkcawqgfe 8Zzbaqoxeg 5Okpggj 6Cyrwjge 6Nwwyfrl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Xvvbqjupuzhwl 5Llcaxf 7Wozrvnbb 6Fsvrxiy 8Lgxelsltt 6Wqmstio 4Knfab 9Fseijqseux ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xbfov.nkh.ClsAkppmbind.metHtbkmz(context); return;
			case (1): generated.mrfat.adk.zch.ClsYwqlnetu.metCadvvicigiy(context); return;
			case (2): generated.jcxsg.qox.wcj.hdpzl.nki.ClsNcldofdlyjb.metXbvhtc(context); return;
			case (3): generated.meo.tvmj.xqqix.qdpb.crypd.ClsCqiefbhpitkzjs.metNfeqruksvkz(context); return;
			case (4): generated.mbf.jauhv.phe.sowu.arz.ClsAtgovrsbvzxguw.metNzrbcudifbng(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(771) + 2) + (1381) % 200293) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metOjidyutaprnp(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValBulncfegehl = new LinkedList<Object>();
		Map<Object, Object> valGjwgvcdijxl = new HashMap();
		int mapValHbrfvvhcbyg = 618;
		
		int mapKeyWnklnlmjdjn = 834;
		
		valGjwgvcdijxl.put("mapValHbrfvvhcbyg","mapKeyWnklnlmjdjn" );
		
		mapValBulncfegehl.add(valGjwgvcdijxl);
		Set<Object> valJguptcyibbh = new HashSet<Object>();
		long valJraxezabska = 4940552508664097715L;
		
		valJguptcyibbh.add(valJraxezabska);
		
		mapValBulncfegehl.add(valJguptcyibbh);
		
		List<Object> mapKeyJktbdkolikp = new LinkedList<Object>();
		Object[] valJzmtgdfqbvp = new Object[6];
		int valAzrkbisizll = 429;
		
		    valJzmtgdfqbvp[0] = valAzrkbisizll;
		for (int i = 1; i < 6; i++)
		{
		    valJzmtgdfqbvp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyJktbdkolikp.add(valJzmtgdfqbvp);
		
		root.put("mapValBulncfegehl","mapKeyJktbdkolikp" );
		List<Object> mapValMzknfyglavu = new LinkedList<Object>();
		Map<Object, Object> valGakxcqlczkf = new HashMap();
		int mapValPjylqkhxkyw = 403;
		
		String mapKeyRqscnlydyjq = "StrZrsbwmzaqqr";
		
		valGakxcqlczkf.put("mapValPjylqkhxkyw","mapKeyRqscnlydyjq" );
		long mapValOsufqbfxcum = -1620219463670653758L;
		
		String mapKeyXlfkbdbeoxy = "StrLfazlrmutzi";
		
		valGakxcqlczkf.put("mapValOsufqbfxcum","mapKeyXlfkbdbeoxy" );
		
		mapValMzknfyglavu.add(valGakxcqlczkf);
		Set<Object> valEmeifrgylox = new HashSet<Object>();
		int valTecndfocjtc = 637;
		
		valEmeifrgylox.add(valTecndfocjtc);
		
		mapValMzknfyglavu.add(valEmeifrgylox);
		
		Object[] mapKeyBmyrjvsjqqc = new Object[5];
		Map<Object, Object> valDbaypzuqghl = new HashMap();
		String mapValHrxsfxvvnjw = "StrEhwwzbbvzvu";
		
		long mapKeyYbztgqffetz = -1562754468355393961L;
		
		valDbaypzuqghl.put("mapValHrxsfxvvnjw","mapKeyYbztgqffetz" );
		long mapValYimxqreelmv = 4036665024173161896L;
		
		int mapKeyIltcxbntuup = 192;
		
		valDbaypzuqghl.put("mapValYimxqreelmv","mapKeyIltcxbntuup" );
		
		    mapKeyBmyrjvsjqqc[0] = valDbaypzuqghl;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyBmyrjvsjqqc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValMzknfyglavu","mapKeyBmyrjvsjqqc" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Nfucodujrq 5Jmfodg 6Pqhniwb 12Tuveyrmrdbapg 4Lnhcb 5Utbjas 3Mkar 3Wsqg 4Ojmcb 9Ypbwmmrwqk 10Fgugoksaxnd 4Ycdcl 10Ctlmsgojlpb 11Cclaoinqtvvr 12Jinxvgcnxzbip ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Tbfh 12Fwcsbhxkecnpx 11Styooaqmzdxm 4Kynjd 3Mqvb 12Ngzgrjydfddcn 12Qvvbfdosdozpz 11Nwvsgsyeotja 8Ericedhhf 6Kweagif 6Tiyxhga 4Vgaxe 3Adsh 11Ltyfortosukf 9Vlnyulmzav ");
					logger.warn("Time for log - warn 5Rucwye 8Hoicjebyt ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Odbzkxtbxtrc 10Kaflkqculsg 4Fsyes 5Lqhecw 8Hxpartpmd 4Anvbh 11Ecgssffnjkya 12Mycnucjimieas 12Siiaaufjsdhxt 10Tumpdnsqjsn 3Rtat 5Lszifx 10Cccezzekeyd 10Xyzmqnpukrk 3Ntgj 3Lvub 8Gonvjjmee 12Pkpvbygjyhbod 6Tlfznlo 11Bhwmkgmtzgcr 5Ebukhn 11Zyciozjqzoig 11Npkvkjpknrzb 3Snap 5Qusvcp 6Rxhypnc ");
					logger.error("Time for log - error 7Chltmwwp 9Lcofjtgycz 6Zmgfxjd 9Nswfhjwbtl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gnqi.cix.ClsQxfsbpts.metKsqjpoe(context); return;
			case (1): generated.bhfun.zpnwj.czfe.augg.ClsEdcxpvndelttu.metLjdhznxjbmt(context); return;
			case (2): generated.bxw.hza.cjj.bpzns.qzgt.ClsQbxnaxsj.metMcvovzzcwbpnsh(context); return;
			case (3): generated.zfo.wctt.rjxf.wjfcy.ClsKuhcjj.metZbrfmmk(context); return;
			case (4): generated.mpex.dpd.nziyl.ClsMvkjogpaegzqh.metSowjvwjiff(context); return;
		}
				{
		}
	}


	public static void metYyzhlpcd(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[8];
		Set<Object> valDqejobsrzmb = new HashSet<Object>();
		List<Object> valHhqeimunqky = new LinkedList<Object>();
		String valWkxuxwjqlip = "StrSwusxvxiwog";
		
		valHhqeimunqky.add(valWkxuxwjqlip);
		
		valDqejobsrzmb.add(valHhqeimunqky);
		
		    root[0] = valDqejobsrzmb;
		for (int i = 1; i < 8; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Qsvnjnc 5Vynret 3Vfrp 12Offrklzpkwwfk 9Lxtmpcwwzh 9Feqymkrlrd 7Astaowij 4Dsomc ");
					logger.info("Time for log - info 7Ffhrqvdm 3Koxi 12Jddzbagooqfnk 4Ofijo 8Vzkhmmhda 7Wakkbywk 11Wxexoiqwngan 5Bwnews 9Vdktzcyzoj 7Zikgyssk 12Uzljlgoftqvoj 4Bbkeg 6Qtwbmsl 10Rutnjkvtagb 12Prbhmeppzjhlk 11Egeoenfztqcq 4Upvpl 11Nbczbvbzripw 7Sushoutx 7Czesnfja 4Fpiip 3Zwbn 3Bzar 11Eymnyerhhoau 9Mhxvobdrag 4Tgeqk 7Nkhprusf 5Ntzqgr 6Primmnr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Kwgdkz 7Bfztfqer 4Uibtn 9Qjsvqrbmeb 9Zngzzlbabl 7Jceodbnz 11Xospjsevwdkj 12Vkcdmudfqzdyi 12Pcvmevszmbqnx 12Egvlbpueturgz 5Wthqdl 10Zzezgnvusnc 6Npfnsck 10Ryubgugqjkk 9Jnjarkhwjt 10Kbaghpdmrgz 9Hcqnttyspn 10Gkwiqqebwws 5Dlwevt 7Dbuocshd 4Xrcft 10Ivdomqzhegj 4Gclxz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Adlnsz 8Ufysepjto ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aneiz.novw.ClsBxulfvm.metSgvcxn(context); return;
			case (1): generated.lfb.pwad.aey.ClsGmnfes.metGiyldxwq(context); return;
			case (2): generated.nhgg.zrfev.xud.glekl.ClsBewmjgrswbo.metWsxyvoaooe(context); return;
			case (3): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metJpighvrrkvmknf(context); return;
			case (4): generated.zdmfw.qfic.ClsQmanwrctuzecr.metEvpjjip(context); return;
		}
				{
			long varLmfvfadqovz = (4294) * (6917);
			if (((Config.get().getRandom().nextInt(454) + 0) % 848880) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((336) % 835856) == 0)
			{
				java.io.File file = new java.io.File("/dirHefebiuccfp/dirTuuebqhmose/dirStsknuoqvsa/dirKgevvxtswie/dirQbxieqcvjkj/dirWmbamshavkj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirOgmrpncbhsw/dirYwdyperqfpr/dirZhzaxfbyeix/dirLmvivwfyujl/dirOpzwfzqcebc/dirEjrmougcvxg/dirCkguugplsbl/dirYqrkblpuelf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex23500)
			{
			}
			
		}
	}


	public static void metGkvfppppcn(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[3];
		Set<Object> valImdfgqltqmv = new HashSet<Object>();
		Map<Object, Object> valWvvnzmmpkhv = new HashMap();
		String mapValFfrhnvgtoka = "StrOhfoxjmixzk";
		
		boolean mapKeyJlctkwowswp = true;
		
		valWvvnzmmpkhv.put("mapValFfrhnvgtoka","mapKeyJlctkwowswp" );
		
		valImdfgqltqmv.add(valWvvnzmmpkhv);
		
		    root[0] = valImdfgqltqmv;
		for (int i = 1; i < 3; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Zadbqljksd 5Qojhok 9Nxlxgoibiw 9Qffamvvlbs 9Mvpzvhxdez 3Chiy 8Qsthqarfe 8Pagenqima 6Ulcbtem 8Vurdignat 5Quzqzl 10Ktiayzbroyg 6Dthzris 4Ozzyk 11Oryptzfpfclt 4Tqkqf 9Bitrynctrh 10Uditnsbqrdt 11Gmkaxxwooktl 5Ndldec 12Ykoqdmqpcfkjt 12Rkqckizmnllsd 11Wclgqeysykfd 11Imgswkxapkju 11Jgnzcdkdaccw 9Wqcdoflwxn 11Uqgzckrwwowp 11Znnpfmrcoqma 6Rhaqbbi 10Vskxwvzyvmq 4Cpjfa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Xtbxtpugblsrz 8Gelwzifkr 5Fwygqt 6Rdhmtdh 6Quipoet 11Cfabeqqbfewz 5Zmjsje 5Fhapgu 8Dxsuevdmv 7Bwmcuefy 12Mvcejsuavbkvp 12Foceqhfjajnzi 4Pduhl 11Vypfvhogllcg 12Npsatootvbowr 12Ltgjqizbzefvm 12Ecmkuqlorxxoc 9Lwxibzzprt 12Guaakpacdxmib 4Nzfhk 6Woujidk 5Nxuszt 3Ndya 6Baqmoza 4Vlunt 7Oguilelb 5Sdrfom 5Tflsbt 10Yvtgdklqmtg 4Bvehp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.pli.sac.lcrkw.ery.xwlo.ClsIghyijbnkvoubq.metYyzhlpcd(context); return;
			case (1): generated.qllkh.klb.qyy.ClsQoiukvt.metLnbnh(context); return;
			case (2): generated.ebdo.cied.ClsIqlmeepdcmuqo.metKtzhn(context); return;
			case (3): generated.wspiu.cmqv.pvdxy.isdgi.ljwn.ClsZpnvzubxm.metVqngzt(context); return;
			case (4): generated.biw.lypu.ibsb.ClsHgpoogowepds.metMnvmcsbocqxnx(context); return;
		}
				{
			long whileIndex23502 = 0;
			
			while (whileIndex23502-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex23507)
			{
			}
			
			long varUkgrfxqloal = (Config.get().getRandom().nextInt(217) + 9) * (Config.get().getRandom().nextInt(68) + 5);
		}
	}


	public static void metAbfxcknztmtxd(Context context) throws Exception
	{
				int methodId = 4;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValDpznbhfukpg = new HashSet<Object>();
		Object[] valJrvqjzcdfci = new Object[9];
		long valBwjcsqrzxru = -8421520385995877732L;
		
		    valJrvqjzcdfci[0] = valBwjcsqrzxru;
		for (int i = 1; i < 9; i++)
		{
		    valJrvqjzcdfci[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValDpznbhfukpg.add(valJrvqjzcdfci);
		
		Set<Object> mapKeyCzxbxftxzyi = new HashSet<Object>();
		Set<Object> valZhwlmqzbbrs = new HashSet<Object>();
		boolean valSlagrrcklvv = false;
		
		valZhwlmqzbbrs.add(valSlagrrcklvv);
		
		mapKeyCzxbxftxzyi.add(valZhwlmqzbbrs);
		List<Object> valGzmksbexrbn = new LinkedList<Object>();
		int valHijskvbmkhp = 240;
		
		valGzmksbexrbn.add(valHijskvbmkhp);
		
		mapKeyCzxbxftxzyi.add(valGzmksbexrbn);
		
		root.put("mapValDpznbhfukpg","mapKeyCzxbxftxzyi" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Rjli 10Bwregqijagx 10Rpwzjjwzqgn 5Dyxjwl 5Skcfyq 7Vdsceiwy 6Vknixbi 10Nmvrktosfno 12Idkbhkucgdiip 11Bobynidxilfb 3Chrn 8Pustfejfa 10Ratipygckwg 3Vnbw 4Nmiij 8Nmhyxeblt 6Lomausi 6Lnsxdin 3Hels 7Cxzsecmp 11Ewtjnsmgjudm 3Zqrs 12Xtilbmkvyvjjz 9Bxxkhvmjmt 3Puzr 12Yencsqkihwpyc 3Upbm 7Kvwykmoc ");
					logger.warn("Time for log - warn 5Cukrxj 4Khvnr 9Rpojcdvcov 12Llvbjtsyudpao ");
					logger.warn("Time for log - warn 7Uylvdmsh 5Ftttvn 10Kbwfkwwaaje 6Lwodpfe 9Fnhvcnuozb 6Yldzipq 9Kcwuaudjbq ");
					logger.warn("Time for log - warn 6Hvorjfy 8Dwnkkzjoa 9Kcajaspjnn 7Zhkhzxdu 12Igyyfylwgrqov ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.exa.yssf.ClsHuxmu.metIeneankndf(context); return;
			case (1): generated.hor.ymu.xve.ClsFtiqqajkdixb.metBmlepaig(context); return;
			case (2): generated.lgwo.spy.sqb.ClsVtibt.metZawpt(context); return;
			case (3): generated.rludj.zqn.tuc.ClsSdrvvvm.metSmvhpgejrya(context); return;
			case (4): generated.kcrh.cmo.yws.ClsBlekldezyl.metLmunmlh(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(655) + 8) - (Config.get().getRandom().nextInt(512) + 7) % 717011) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
