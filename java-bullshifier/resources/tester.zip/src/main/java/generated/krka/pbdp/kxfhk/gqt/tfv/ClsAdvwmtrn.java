package generated.krka.pbdp.kxfhk.gqt.tfv;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsAdvwmtrn
{
	 public static final int classId = 435;
	 static final Logger logger = LoggerFactory.getLogger(ClsAdvwmtrn.class);

	public static void metGbpohttt(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		List<Object> valLuqevbpyobw = new LinkedList<Object>();
		Set<Object> valEhtycqhyoaa = new HashSet<Object>();
		int valQgonqqglcmg = 280;
		
		valEhtycqhyoaa.add(valQgonqqglcmg);
		
		valLuqevbpyobw.add(valEhtycqhyoaa);
		
		root.add(valLuqevbpyobw);
		List<Object> valRbmlrwaedyo = new LinkedList<Object>();
		Object[] valBepzpxglxco = new Object[3];
		boolean valPvogjsuyimr = true;
		
		    valBepzpxglxco[0] = valPvogjsuyimr;
		for (int i = 1; i < 3; i++)
		{
		    valBepzpxglxco[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valRbmlrwaedyo.add(valBepzpxglxco);
		Object[] valGvvmxwtirpi = new Object[3];
		int valZnsoueqxqyw = 827;
		
		    valGvvmxwtirpi[0] = valZnsoueqxqyw;
		for (int i = 1; i < 3; i++)
		{
		    valGvvmxwtirpi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valRbmlrwaedyo.add(valGvvmxwtirpi);
		
		root.add(valRbmlrwaedyo);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Loagbhz 6Rnpkerq 8Fxjghfugk 10Ymrdnultpxr 5Rvphrc 5Ywccxl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Ljta 10Rdodqfbgznc 5Vjciep 12Mzetxuesnuibx 3Kgmz 6Youokjw ");
					logger.warn("Time for log - warn 9Emvlntliaf 3Pfgl 6Ulvinpc 11Mdcesutlbnle 11Iptxyxuiyilb 10Khkxjvezuxr 10Nkgjsvcpxrw 8Msryhitwh 9Jalukbfish 11Lnpzittxhejx 12Tcalmtnroycqw 7Rlteqhfq 6Jumxqjh 5Axzsjf 10Cizfgdqmfhl 4Rgaug ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Lfwyrjafrzj 10Uvzjosopyro 11Qkgqslapnhvq 9Datrojgjsc 12Citrlryfypbct 12Qvogorbshfaas 7Bnncopxm 8Rvxbbzrnp 5Yjgtvm 4Sjppj 3Swpn 8Ovwznzhzm 6Egwpkzo 4Tzugq 10Zabqbibfykf 12Qjlzvwlyqfctl 3Bujt 4Jacmd 12Ggzldlmydwclg 12Lrccelcogwmmb 4Kmljr 4Snuuw 12Bjxhelxicdmyd 11Rkwbkiuitxbu 6Evfcfzu 4Jrsdv 8Dgneyxiwi 5Czglpb 12Zjxifsexfvvag 3Wvxl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.idk.jvavb.vjuwp.iuzf.fawz.ClsRtwkffyfhbvpjl.metJglxxxadpzz(context); return;
			case (1): generated.vspck.scvf.gxvmo.ClsBudbedmvgnjpa.metHunirsyqpt(context); return;
			case (2): generated.axdim.stv.ClsSaegiqo.metKmdsuvjx(context); return;
			case (3): generated.exnrv.npnx.zyxb.ClsLffziac.metKrjqsyrbe(context); return;
			case (4): generated.uyus.ruq.fow.dvnw.ClsCysblmgtiyuxcr.metRytcxfzpgayhlo(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/dirKkeleauepgd/dirPeeobojjnys/dirUoacopkichy/dirVtygxqvbuvt/dirMjxuycakbnm/dirGfaheeblcjp/dirNfqixpqllua");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex27308)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metNwnntkt(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[11];
		Map<Object, Object> valOkjzblheixn = new HashMap();
		Set<Object> mapValWdgokwcvcwo = new HashSet<Object>();
		String valAcmqeabkviv = "StrKbqpcufzitr";
		
		mapValWdgokwcvcwo.add(valAcmqeabkviv);
		
		List<Object> mapKeyCedjhpikvwq = new LinkedList<Object>();
		long valVxbyogkvkjr = -7842651686251857968L;
		
		mapKeyCedjhpikvwq.add(valVxbyogkvkjr);
		
		valOkjzblheixn.put("mapValWdgokwcvcwo","mapKeyCedjhpikvwq" );
		Object[] mapValEsrviywngkm = new Object[8];
		int valTcjpfzaeukw = 46;
		
		    mapValEsrviywngkm[0] = valTcjpfzaeukw;
		for (int i = 1; i < 8; i++)
		{
		    mapValEsrviywngkm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyLppnnociveg = new Object[5];
		String valAzkcnhmfcyy = "StrJdzrodyntvd";
		
		    mapKeyLppnnociveg[0] = valAzkcnhmfcyy;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyLppnnociveg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valOkjzblheixn.put("mapValEsrviywngkm","mapKeyLppnnociveg" );
		
		    root[0] = valOkjzblheixn;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Bxmkmsafnejpn 6Ndalypj 8Lpjieboia 7Foiubdgf 3Zqeg 6Hkijpom 12Ngswtnclydclk 5Bpjtcb 6Qjjqkmn 5Djvfws 5Wjuzzz 7Vdekgdyv 3Pdaj 7Jyagxoff 4Rfdna ");
					logger.info("Time for log - info 11Sjxabmrinsoi 9Dpreratsne 6Rywnxgv 5Lsvbsf 8Wowcgujua 5Vfprns 9Ymsfzhnvdo ");
					logger.info("Time for log - info 8Evjomlqpm 5Kbbxme 11Fsugyaekjqhs 3Nnbs 6Hzhzsgj 7Jggdgyfo 8Sscblcryf 5Hsstml 9Utcqrbtatz 7Xwqtjzfo 7Fggdkrhn 3Wslk 10Ierkfyjrdpq 5Hmuyyh 11Stnyqugpfeht 5Nkzhkz 7Ljcgblkl 7Xsrrqnql 11Mnshclgahfcq 6Qtkpaya ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Yljkpogpv 5Xmahcm 7Qvcneafy 5Cqawkx 5Svtkmf 9Nkxpqjrojj 7Sjztwfnj 5Risvyp 4Djttu 5Gwhdod 5Bajorn 4Vulis 11Coxbfxkisxyy 12Cyvnvxadoyyld 6Vayjkbp 7Wdublkaj 7Zondeulb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.jdhkq.nnb.eopx.xiteo.ClsVoejnnonjnbn.metJpighvrrkvmknf(context); return;
			case (1): generated.kyd.fxg.ClsVvcevjvyz.metSjikefnlhdbobi(context); return;
			case (2): generated.dyn.peov.bqa.fptp.ClsXhblgjpkehiigi.metEiaaqrx(context); return;
			case (3): generated.gcr.qqx.juuh.caxx.ClsRlelgjq.metJcvcwuus(context); return;
			case (4): generated.wkucr.ukst.umm.xsqx.ClsEjxfeypurpufwd.metOatblxssahe(context); return;
		}
				{
			long whileIndex27312 = 0;
			
			while (whileIndex27312-- > 0)
			{
				java.io.File file = new java.io.File("/dirZgohxbnskqy/dirLzgscoyonav/dirUudhykvfire/dirJvnsknrhemt/dirSygnuvrbkdo/dirDjnpuycwdwz/dirXonxhxsrqym/dirCscccpvrykc/dirZxmoqsxgcrx");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varVtlzcwnupoc = (Config.get().getRandom().nextInt(273) + 3);
		}
	}


	public static void metDvriulzpcrhbb(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		List<Object> valEfvekqhznge = new LinkedList<Object>();
		List<Object> valIrcnssvyhaz = new LinkedList<Object>();
		int valRgzafjappes = 92;
		
		valIrcnssvyhaz.add(valRgzafjappes);
		String valBbqjaiymjue = "StrDovabwlkfak";
		
		valIrcnssvyhaz.add(valBbqjaiymjue);
		
		valEfvekqhznge.add(valIrcnssvyhaz);
		Set<Object> valLpuluqvkddt = new HashSet<Object>();
		boolean valMyypmhdxutf = false;
		
		valLpuluqvkddt.add(valMyypmhdxutf);
		
		valEfvekqhznge.add(valLpuluqvkddt);
		
		root.add(valEfvekqhznge);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Xgerkqjx 11Pvidpyvypcfw 4Slnnl 12Yvkmudyrhqpao 11Ctczvpjvhqos 5Uhpqsj 12Dlaomuylehfgt 5Rwtrli 6Xwghsru 9Oadnjupxji 4Qraqa 9Dylfwleaeq 8Suslfxvge 6Tzcvket 8Cbofnzcze 3Ywth 10Moilbzmffwv 6Ufcwpcg 9Jyhoocdabm 10Jrrazfityoe 5Hwbkgr ");
					logger.warn("Time for log - warn 9Qabxrlbhpd 6Yrrqcxu 6Cmshfzr 3Adkd 9Hwkccxvnoz 9Xpnpbgkjwl 9Heguaahpua 9Fahmyjebcp 7Lxekvqnz 7Brsidboj 10Leischvfnyy 8Cnzqglirr 3Qvjt 4Xtvvr 10Fmkzxdsdxha 5Doejjy 8Dglkcqqkw 6Aqifaoa 8Fewnagpdq 5Wjkjjq 3Ahkk 9Ujsgflhtwv 8Zaveqdlny 9Unkblsffzs 11Lmmqegkntdcn 3Zqhd 4Mkrcn 12Uqinlnglrfond 7Armkkzhm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Bmyrhb 11Fsgjugonrcvm 11Rpnfdrwtxuyk 7Wqcktxno 5Mouzzr 4Ypemu 11Avgkkhwtiksy 7Menpoilf 12Rtxjkfawsatkm 10Kutfdvktboz 9Gnipabtldo 12Awrgbmfhanuyx 11Nsmpurjoxxfs 11Khtmstmgzyci 6Drdsdkq ");
					logger.error("Time for log - error 6Hjkhwth 10Licnrapysye 11Ipqqwecqheju 12Ixlticztzsrmh 8Fmahqvblu 12Ocwzwsecwosct 12Wpmhliumwsuhv 12Cfxkpdkhzuuce 8Jxknwoaby 12Ooomvzzpdsidx 4Qxdyf 11Cduzmvxgeykt 8Mtdgnyjea 5Itcchx 10Bbfygsqwyrz 8Vcutdwubf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cmlwi.ajlk.yhine.aaz.ClsYxnwkcu.metTsnvquyweiwxo(context); return;
			case (1): generated.pef.kybz.yzpf.dzs.obqpv.ClsKizvnatyigi.metVpeqkkprfd(context); return;
			case (2): generated.inao.viw.ClsZkxazvlqxnvyzx.metYczqbc(context); return;
			case (3): generated.ecksk.wvb.ClsNtqfbmlui.metOzgvgztdgxgwck(context); return;
			case (4): generated.bwwh.pcsa.hpav.bbh.ClsXicvnzwjqnoh.metNnybhkcr(context); return;
		}
				{
			int loopIndex27316 = 0;
			for (loopIndex27316 = 0; loopIndex27316 < 6603; loopIndex27316++)
			{
				java.io.File file = new java.io.File("/dirErfjrkvafky/dirWzaayyahayy/dirUtcnupkrcgw/dirKqpjvjxjmka/dirVkwhjelklsv/dirRkdsfktzlpd/dirGehdklregxj/dirWfoqauntwqv/dirXukvjljvzpl");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
