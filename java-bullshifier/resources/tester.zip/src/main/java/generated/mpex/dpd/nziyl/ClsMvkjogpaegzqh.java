package generated.mpex.dpd.nziyl;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsMvkjogpaegzqh
{
	 public static final int classId = 291;
	 static final Logger logger = LoggerFactory.getLogger(ClsMvkjogpaegzqh.class);

	public static void metCcluioiaauedgi(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valMnxvhhfexzi = new Object[9];
		Map<Object, Object> valTfrjtmyzuvt = new HashMap();
		long mapValFqagbweoybb = -611999516974891453L;
		
		boolean mapKeyBdgkiovnwat = true;
		
		valTfrjtmyzuvt.put("mapValFqagbweoybb","mapKeyBdgkiovnwat" );
		boolean mapValHivxolbfeur = false;
		
		String mapKeyPulrdhxhvoh = "StrKtmwrgrmqcg";
		
		valTfrjtmyzuvt.put("mapValHivxolbfeur","mapKeyPulrdhxhvoh" );
		
		    valMnxvhhfexzi[0] = valTfrjtmyzuvt;
		for (int i = 1; i < 9; i++)
		{
		    valMnxvhhfexzi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valMnxvhhfexzi);
		List<Object> valHfgencdoeyx = new LinkedList<Object>();
		Object[] valOhanyeufxxy = new Object[10];
		long valHcqcaxiqhou = 5167252919908167892L;
		
		    valOhanyeufxxy[0] = valHcqcaxiqhou;
		for (int i = 1; i < 10; i++)
		{
		    valOhanyeufxxy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valHfgencdoeyx.add(valOhanyeufxxy);
		
		root.add(valHfgencdoeyx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Mybsr 10Wknfitshxws 7Bwthaceu 4Gcjgv 9Qruvyczwcv 5Pxrzaw 8Ofitbjkqr 8Hwnwvcbjp 11Aaupmexpkjaa 7Arnfrnfm 6Ajjmccc 12Eidphxoseyhjw 10Medrmgfojhu 6Asllpdw 10Ftoorotsoqd 10Tuyterigcuq 3Pqnx 9Bplrtdohih 8Emzcavywd 11Wysmdyunugoo 10Uvaqqqtctgc 8Lhqagoheq ");
					logger.info("Time for log - info 9Pjrjzsrhol 12Rfonlzxrxhnqb 4Oxven 10Iczkwysxlxm 9Tesnaxgxom 10Pykfcbatzmz 8Hosuqgpwx 5Cukiwo 5Fyrpip 8Qnfynjuls ");
					logger.info("Time for log - info 8Xqieahvsg 6Yhicubv 5Vdcpyk 7Gtdoataf 3Dccg 5Kggnun 10Cmrhngcjjuv 7Qcvesxre 12Aqoovncrtuaxz 12Dxgkqylgnnklo 12Dtpjrjlgbsuwo 4Nusns 10Vbwzsyrgjya 4Tzopc 10Xdjlelbxszz 3Rijn 11Jcefgqkurtti 11Rearvnaqdofn 8Haypgsvna 8Jfkumjcwq 11Eunmzzxreaox 6Cboqqrb ");
					logger.info("Time for log - info 6Nprhair 12Sjnejhiidarkw 11Vlumutuypntf 5Mlpidf 3Lzek 6Aumbrah 9Yfqswlxgrt 9Tgsgdsftmr 9Halgowlbrv 9Qmtalvipdu 6Eisgiri 7Hrgqkvez 8Cwlyxjrer 6Dfhtgrc 11Uimyhtliyysy 7Xebbkatb 10Fxwboqtcyaz 7Azdwbqfw 12Fwmehemsedvrs 11Rfpydixryhgf 12Gqpttsptyqlsi 12Tvnryrmdotpsl 4Qxxup 6Rfcrjfu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Oxufkdx 6Cpcwdfg 11Gczugvpiivnr 12Tbyvubhgaqhof 3Hxud 11Ksjjpofyhdfo 9Gdnjwtssmu 7Lmthxhjh 10Yehtsrvmskr 4Nyyeo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Rcpyb 5Gdwcnu 8Fliwxskfm 4Eyboz 4Evtox 10Btccqmrgebo 7Bkarnhow 9Pudxcxmjnr 3Dnfh 5Mywyog 8Iehhplolb 10Wiucdmliumk 3Lsaw 12Yezrggnmxzzql 7Fxhqhhkr 10Wbelonjdcdu 9Ujoridhaho 12Jhgfxnwaytlxe 9Comxdouytp 11Lgczunbjdijl 12Gybdyzcjpktuc 11Hjdipzcohjfw 8Wtidzlcae 8Plbztkgak 10Lymubhbrqrb 8Ckqvdsrii 9Rtrplkdrmx 12Oozgdppqywsvx ");
					logger.error("Time for log - error 8Qsjgmeqre 4Xjckt 11Mjwaubssqsir 7Ybaoqnsj 9Qmwezjpenm 10Prxtffoxqtn 12Qozuctqvuwxmt 11Ouwhmdlmmnyd 12Khjagnqzavqjv 11Wcpwmuszftrf 6Bwvlvag 3Aokc 7Fkmcvpvr ");
					logger.error("Time for log - error 8Hjlsrsyzw 7Utmaqztf 4Zupkw 6Ducjnbo 12Ghkideyexbaqv 11Eyihipesompd 9Nkzfxzoqng 11Ikxswqhtbcrk 11Cktqtmkufpji 11Qwnzajqsrtxd 9Qubolzggwd 10Mlcsaddolww 5Iojypw 8Gzvdxmoce 4Anpfw 6Fnzipkv 11Bayvbodgywxd 3Bzqt 5Ldbqpq 5Cqugsv 11Lichbicllbyw 4Zosvp 9Mbtuccultc 7Aqifhnwv 8Isgzincdv 5Dxzayq 7Vxlnwwsb 5Rwxqml ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.guq.may.fgxvf.ClsClatvr.metAkmzbyrocuy(context); return;
			case (1): generated.lzrmm.bjgfs.ClsQdamrbuivuq.metUnbxmbilwl(context); return;
			case (2): generated.hkyc.tzi.ClsYwknearnl.metPubmxeffq(context); return;
			case (3): generated.hadv.dozj.puo.ClsVowitvkgtx.metQjsinz(context); return;
			case (4): generated.zdmfw.qfic.ClsQmanwrctuzecr.metEvpjjip(context); return;
		}
				{
			int loopIndex24975 = 0;
			for (loopIndex24975 = 0; loopIndex24975 < 2986; loopIndex24975++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metPjytlkzwhuk(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valJnddpkqnnzw = new HashSet<Object>();
		List<Object> valLmcmaqvuvgd = new LinkedList<Object>();
		boolean valJsmvlunyuqn = true;
		
		valLmcmaqvuvgd.add(valJsmvlunyuqn);
		long valLnyisvrbsko = 2799342318445950809L;
		
		valLmcmaqvuvgd.add(valLnyisvrbsko);
		
		valJnddpkqnnzw.add(valLmcmaqvuvgd);
		List<Object> valDnayijazfgd = new LinkedList<Object>();
		long valHhuaivefyke = 3603777448047623447L;
		
		valDnayijazfgd.add(valHhuaivefyke);
		
		valJnddpkqnnzw.add(valDnayijazfgd);
		
		root.add(valJnddpkqnnzw);
		List<Object> valAdunbrdiwtl = new LinkedList<Object>();
		Object[] valFjqkfieveiy = new Object[3];
		int valFcdthpiqqjy = 80;
		
		    valFjqkfieveiy[0] = valFcdthpiqqjy;
		for (int i = 1; i < 3; i++)
		{
		    valFjqkfieveiy[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valAdunbrdiwtl.add(valFjqkfieveiy);
		Set<Object> valIufbruhnszv = new HashSet<Object>();
		boolean valQosuljhilbi = true;
		
		valIufbruhnszv.add(valQosuljhilbi);
		
		valAdunbrdiwtl.add(valIufbruhnszv);
		
		root.add(valAdunbrdiwtl);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Frdisxyq 10Rtnqkizrkor 11Euuiamoacrny 8Yytkbekwu 4Nluqw 8Kfcococdq 6Njihqvq 9Ipjpgarino 6Ykxhoix 7Yegvexfe 12Wofynqgqcbpve 11Ffmaswbpapfe 10Umalprklfhv 4Toajd 11Cuoxuvdxaakg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Txoxtuje 12Nofdvfmmufodg 5Pcupoo 5Jigsmx 3Xdaj 8Lhhwnuqoc 3Ocdo 12Dkwmyxvtnsyuh 4Qvhew 8Ffwllhtyj ");
					logger.warn("Time for log - warn 8Ffmziakth 8Bpvnqbldm 6Cgxtcdy 9Lyylcwxrtr 12Kohlaxehzeszy 5Qcrhwg 6Iqzjlre 6Qoxhqai 7Afnekviv 11Rzdxvmnjhnro 9Imrboxzqjf 6Nnrbsju 6Ybbxszm 10Nysvqqiygoa 10Fnditmedlfd 6Bckjxfe 6Ppmycwm 4Lzkjz 10Xqdeugwpdlz 10Anzzqbexbsw 8Wzndtqgao 7Ngvcakwu 12Wyqkkjarqvwxe 6Wccgvuo 11Aspjjzghiomn 5Dhgtsj 5Kamvae 6Cipuwdr 4Dsmqh 11Loddcdharqmq ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Wifpqwlotini 6Egtzuyx 8Uoavcfgxd 5Fpxnow 7Fhwpkwlk 6Vnuqgaz 6Wpvqiuv 5Ysvnmp 7Ebloizeg 9Rczsbckyxe 5Wkkfew 6Hrmaedh 7Ehfgdcmb 11Bvntjjhuitja 5Jprpdt 8Xxcroqznw 3Zhvj 3Stiy 12Donoedfqobaps 5Pneipy 7Wdjwtqvu 9Rpczkbzdyq 8Yytmzoczh 5Xazaeg 10Ljfmtrfuows 5Rlgyta 9Xcdnpwddvt 6Obawpgf 6Lxbzoxf ");
					logger.error("Time for log - error 5Kczegg 12Ovyodwwxmwjag 11Ecbzbtrwdxwt 11Kfjmbpbifggy 10Lbhlhuowecb 8Cubbiigbz 9Seigtxvhkh 10Vfucefiouhz 12Nvdhveacshmpi 3Doew 8Iyinqmxgi 4Gcpfj 6Vyjsrgz 6Jhgfgfi 8Aecavkrpi 6Ypwxnss 8Eozjfarox 6Wffaxlq 12Uxoccpjoloosm 12Tviujiglboavh 9Qpxawngkyd 5Vdnkds 9Xvbarvetrf 4Waknj 8Qlshejwqd ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tyk.hlfrx.jaeuw.vvzz.yws.ClsMwqznwnz.metWpheeqsxvjk(context); return;
			case (1): generated.gmk.vzs.crbap.ClsEkyhsmjeh.metLxmeq(context); return;
			case (2): generated.mao.kidk.mlsjr.hew.xst.ClsEfomkejxcxzr.metEruurpx(context); return;
			case (3): generated.fhy.qnk.brj.xhy.ClsYgumeudbf.metCzfoghkqm(context); return;
			case (4): generated.ncau.ibhi.ttuvu.ClsHlbobsu.metTahxaryiutr(context); return;
		}
				{
			long whileIndex24978 = 0;
			
			while (whileIndex24978-- > 0)
			{
				try
				{
					Integer.parseInt("numEddnvsohczv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			int loopIndex24979 = 0;
			for (loopIndex24979 = 0; loopIndex24979 < 7897; loopIndex24979++)
			{
				java.io.File file = new java.io.File("/dirKcvplvotpjs/dirRxosuhwclhx/dirJfkppfyeuhh/dirMhycmgenlfg/dirOnvbujzkhxg/dirVqetznzacrg/dirPrgnugdgskr");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metSowjvwjiff(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValZbgcxzuypys = new LinkedList<Object>();
		Map<Object, Object> valZxicvyaubwe = new HashMap();
		int mapValYsezzldtodu = 373;
		
		int mapKeyZkjhcwnhfdm = 117;
		
		valZxicvyaubwe.put("mapValYsezzldtodu","mapKeyZkjhcwnhfdm" );
		
		mapValZbgcxzuypys.add(valZxicvyaubwe);
		
		Set<Object> mapKeyAlmewoskmcc = new HashSet<Object>();
		List<Object> valTxuqxypmmtb = new LinkedList<Object>();
		int valPvynxwmqeue = 193;
		
		valTxuqxypmmtb.add(valPvynxwmqeue);
		
		mapKeyAlmewoskmcc.add(valTxuqxypmmtb);
		
		root.put("mapValZbgcxzuypys","mapKeyAlmewoskmcc" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Pvioscekz 8Lufawffgr 5Xpfkck 4Ppylv 6Htjfiha 10Vcemxwwukqz 12Wlwrpinbkpctl 8Cihuvgnez 12Abofdotlmuypu 7Hwntcoou 10Runlifcmknb 10Cbcnzinqvgy 3Qvvy 6Rtxyrbq 5Xjbvwg 10Umzsluobaly 5Jvumts 12Sxoutkpgjnihq 4Kbzie 6Zglspkh 4Bjbca 12Cinkzpqgfcrrs 12Jlryhcjrsvhnf 12Pdytjwctfydqd 11Shgkxqexjico ");
					logger.info("Time for log - info 9Qzkjhspwuq 11Iqvprdicxehi 12Ankasebgdfpbf 5Swahtf 11Xrkjlqkwyrmz 4Daqgm 6Nmbigjd 5Fuwdpa 6Qdisftm 7Idjmbyly ");
					logger.info("Time for log - info 12Dmgkynrfzgcpv 6Ttfidsh 10Sinpowzwrks 11Jpiqoxbadnzm 10Qgenehagqgf 8Fzubgafes 5Qlunzh 12Rvjzsaejjbmsd 12Tdefzkalpiyao 6Nenqtph 11Ajynbmmhpjuy 9Ftalrgjabd 3Turw 6Dqfivoy 6Eipfvmf 9Kdazvbdgjl 8Fmxkjgvql 5Ttmwzg 6Zwpoqqm 3Bttw ");
					logger.info("Time for log - info 11Qnmiotqfqvjz 6Ijevtzh 7Rsmlkzpz 6Cnlrafw 10Ngwlbtwmifk 5Egqyff ");
					logger.info("Time for log - info 5Cbrvcg 3Nvrr 11Tygmwwzbpakj 6Ytdskks 3Ikop 6Mhvcepi 3Ydkv 4Uuzen 4Yicxm 11Quujdsbccrld 4Ctjgx 3Rlqd 12Taemgphshkzam 8Apioryzth 4Ksrzf 4Xbhyr 11Leymhvoheiuc 4Mmumq 5Esudxi 6Bxoobqk 8Xvpsnpzbn ");
					logger.info("Time for log - info 5Sxuzwd 7Sdaomgwh 9Wyoylpgiqi 10Kiwmlfpnlje 4Kuabj 10Qaqrszcpuqi 6Avqbnli 3Rnam 11Wfxaiizbabih 12Xvkczaodxxyvk 12Itezkxzopcmgm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Tbmzhi 3Lxcj 8Wonmydmut 10Slcbbyhlize 7Mjzgbxgw ");
					logger.warn("Time for log - warn 8Bolbrnnrb 8Iciazbqhv 9Azxdiramdj 9Ifuuozrizk 4Exrbf 6Fogflse 5Nufjyu 12Edcthaghsjugi 5Spwezs 4Xotio 3Enok 10Mpkqenjurhk 7Lvjcmnrg 3Efkc 8Ctptsqzyg 5Lfhspf 7Laoxrsja 9Paxtfnuqgv 12Tzlwkbwbgsomw 12Lyqcbkpkxswpq 8Djggcwmko 8Yeopvwcik 10Zheljvrfgtt 9Teihzomqar 12Kcjjukwhddezb 11Lkzwuwczsvdm 9Hwtptkzclu 4Litjm 11Pzgaqtjgeicr ");
					logger.warn("Time for log - warn 9Bdhnqmwfwd 8Mxsemvfuu 3Wgly 9Veqmgcddcd 4Qwztf 11Ryqqmvzsmgix 7Zpeiqnej 3Sbio 5Bmqsbs 6Obethko 4Wwkij 6Sqvkrbd 8Gufjxucfg 3Nsjk 4Oasdl 9Ocdoeqjetz 11Joxbxttgjieb 10Mycxnsbtuhw 8Lxtcxmeos ");
					logger.warn("Time for log - warn 9Cfoppubqyk 5Frdvqb 11Wqntsqczsdcs 5Hrnlqk 8Bcnpzuphg 11Mgcnhbahxmuj 5Zrjntu 12Yqlykxunnjkpu 7Oobaqelh 12Inwjkbtwqjwwh 8Kryfahtyu 5Dbubbh 4Voyrw 12Elpfayqmidgjf 12Nzgkjwxwqnmqs 8Apazubbnk 12Ybouostxoztjo 9Rvwludbzen 11Mbcjktbqlsvr 9Kwkbvvqlqk 6Xunphms 8Pssmgpzxh 4Kncpt 3Lxsq 12Ughiqxsxytwna 4Yosim 10Iphlifsqrut 4Jnixc 7Umyqfpvl 8Oqxbywgqz ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cqy.ffep.ClsWvinhicphnl.metWwbnpyd(context); return;
			case (1): generated.evl.qnyx.qnt.hnkpr.mua.ClsPqzytqp.metUawoukuahbtfc(context); return;
			case (2): generated.crkmz.uuny.smq.vvmxn.khxb.ClsQbvzuhroxdituh.metAiybrixueywscr(context); return;
			case (3): generated.uxbqo.pcskv.udre.ClsKillneqmm.metIokufnwdnpfcxt(context); return;
			case (4): generated.hjt.myuvv.hkc.tfpi.ClsJfukwmizredp.metKzuep(context); return;
		}
				{
			int loopIndex24983 = 0;
			for (loopIndex24983 = 0; loopIndex24983 < 4471; loopIndex24983++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
