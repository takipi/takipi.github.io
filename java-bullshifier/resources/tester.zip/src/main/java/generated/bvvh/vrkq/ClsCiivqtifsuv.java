package generated.bvvh.vrkq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsCiivqtifsuv
{
	 public static final int classId = 334;
	 static final Logger logger = LoggerFactory.getLogger(ClsCiivqtifsuv.class);

	public static void metImwfpxpepgga(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValTrfaastovaa = new Object[8];
		List<Object> valOfwuhrezope = new LinkedList<Object>();
		long valEcmzzirxucg = -6588582511936975387L;
		
		valOfwuhrezope.add(valEcmzzirxucg);
		int valGeeibadjsyc = 951;
		
		valOfwuhrezope.add(valGeeibadjsyc);
		
		    mapValTrfaastovaa[0] = valOfwuhrezope;
		for (int i = 1; i < 8; i++)
		{
		    mapValTrfaastovaa[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyNdpzofpzvhj = new LinkedList<Object>();
		List<Object> valUdaedwdcqsh = new LinkedList<Object>();
		String valPsgayibzoyr = "StrYvjjbrgaftj";
		
		valUdaedwdcqsh.add(valPsgayibzoyr);
		String valLjskarxwqnu = "StrKrvhjjfrfzs";
		
		valUdaedwdcqsh.add(valLjskarxwqnu);
		
		mapKeyNdpzofpzvhj.add(valUdaedwdcqsh);
		
		root.put("mapValTrfaastovaa","mapKeyNdpzofpzvhj" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Jsdpptagr 7Unilgoxc 7Tnpzhpve 3Neud 11Woydobpfmpsx 11Agyexohqbjox 12Pvsddqqomsqcc 4Rbsmd 10Arhngerwbfj 10Rzlufsxzmiq 8Ymxcsrsva 6Eashvjy 9Evleywafrb 8Uepnsyrsu 6Ksfuyeu 8Kptwroyyu 10Egstwvrwsmg 5Gpttoe 11Myiasltfasxx 6Sbfovxj 9Mjjxnvuicc 3Lmzs 11Rwwjfotzcwdt 11Tpjvhklapkoa 8Mxcceasbh 8Bgevbbzkr 6Ecxxvlr ");
					logger.info("Time for log - info 3Xdbi 11Swuhtuqtulco 7Rrwfbejp 11Hnfsasoalgel 10Mttxrvylslm 8Pkadxzyzg 9Htthjgeviw 11Ptrvbkoyalac 11Wmibzlyvjyox 5Fkuxwb 4Yvnti 5Lxhqfp 5Utlpzt 11Hzeiigyslzec 8Zpastjdpu 5Ycorkl 5Svrxhz 6Gsswwbc 5Xvrjuj 11Eutksozwvhib ");
					logger.info("Time for log - info 10Yrjaqsihfnz 12Jdqnaxycflumh 4Ixqhz 9Jobwhrnsph 5Vwebwu 4Porew 12Deyjwmecvkdek 10Xjmbbhrjvas 10Lyxhzhqdatt 3Pgcr 8Hpuxseznv 4Toweh 9Mdprjypviu 8Secxwvzoj 11Yvurvrcfegvv 10Heloblwvjmg 6Ugvkxpq 9Iohgdhcukm 8Yxxygliat 8Ufrenjshb 12Ashjdpykedxku 4Tukhm 10Hwklarbmatz ");
					logger.info("Time for log - info 6Nyyvngy 7Creepczl 3Rwxl 12Etkkxttoiwdko 6Qlwcasu 12Gcqlnngmutodl 6Vwzqpgq 5Mtqmvv 12Axgyjfkivkhzm 3Huzv 6Hrprhgz 11Aocbzvmkftlo 6Qiezomh 7Gwongcxm 4Iacca 6Nrtpmuc 12Dssrtmvsxgbnk 11Atjdfopjtdtk ");
					logger.info("Time for log - info 10Tamvwygijhi 6Hjjbebt 7Gbhwnszv 3Jiee 3Ivww 11Ygdvbrrtgqxh 3Etdo 4Daibe 10Tfifnadtbyk 8Tuzjqpjag ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Pqhsh 6Tdhtfzg 4Ixosq 10Uakppplnfxh 3Mbcl 7Nltnobdq 8Itbdqxdfl 11Tvcvqxvwcaxy 12Haopepqqknjia 7Krrumhdd 3Uobz 7Vhdqxsej 7Pvyhrtmp 3Olrv 3Yjdq ");
					logger.warn("Time for log - warn 8Wfryymoso 7Eocuvbkw 9Cfbsrojcew 4Rveos 11Erbmtodtwmeo 12Zpbmaexvzklmw 7Gpxoclqg 4Jfxio 4Tzfhu 8Nsuvyxxkw 4Hdeqk 8Rvmujmizb 8Hupvtcosn 7Dotrvveb 11Yprgvldqdudr 10Rrfrurasjcz 4Mflgs 7Vmbsijgl 3Nnmw 8Yzyoqnvme 9Phdrkzdsig 8Fxdhyiegz 5Qqvren 3Bkbn 10Jqnfczswqzm ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.yfeni.otsaz.fkhen.upca.zzv.ClsWbxrghwufimrgi.metMmhojtteok(context); return;
			case (1): generated.mpex.dpd.nziyl.ClsMvkjogpaegzqh.metSowjvwjiff(context); return;
			case (2): generated.lgwo.spy.sqb.ClsVtibt.metZawpt(context); return;
			case (3): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metOcmdwdvovlzu(context); return;
			case (4): generated.aqqfv.gdkxm.pact.ClsAgtwrqa.metYkbdjrockaif(context); return;
		}
				{
		}
	}


	public static void metBcfndjmmnf(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValYiivkuzcddi = new HashSet<Object>();
		Object[] valBlunhkcfsox = new Object[3];
		String valBnarygnpzio = "StrRjwimfgvnlp";
		
		    valBlunhkcfsox[0] = valBnarygnpzio;
		for (int i = 1; i < 3; i++)
		{
		    valBlunhkcfsox[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValYiivkuzcddi.add(valBlunhkcfsox);
		
		Object[] mapKeyHsmbfwdpokv = new Object[10];
		List<Object> valVylwfvkgnxx = new LinkedList<Object>();
		int valCclenkggpqu = 635;
		
		valVylwfvkgnxx.add(valCclenkggpqu);
		long valFouuchdlslo = -8540062970064843505L;
		
		valVylwfvkgnxx.add(valFouuchdlslo);
		
		    mapKeyHsmbfwdpokv[0] = valVylwfvkgnxx;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyHsmbfwdpokv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValYiivkuzcddi","mapKeyHsmbfwdpokv" );
		Set<Object> mapValKijyybggpur = new HashSet<Object>();
		Map<Object, Object> valKhjiuwmeeps = new HashMap();
		long mapValCyiuazlcfkd = 8457611715530475171L;
		
		boolean mapKeyBsfogljawmg = false;
		
		valKhjiuwmeeps.put("mapValCyiuazlcfkd","mapKeyBsfogljawmg" );
		long mapValTruuozdxwdz = -4734301074491058581L;
		
		boolean mapKeyKmkfoatolyd = true;
		
		valKhjiuwmeeps.put("mapValTruuozdxwdz","mapKeyKmkfoatolyd" );
		
		mapValKijyybggpur.add(valKhjiuwmeeps);
		Object[] valPuwdfpzbukh = new Object[5];
		String valBklpklauock = "StrEgwandozkcl";
		
		    valPuwdfpzbukh[0] = valBklpklauock;
		for (int i = 1; i < 5; i++)
		{
		    valPuwdfpzbukh[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValKijyybggpur.add(valPuwdfpzbukh);
		
		List<Object> mapKeyOljjwvlnlrg = new LinkedList<Object>();
		List<Object> valSljropqzcxz = new LinkedList<Object>();
		int valQvaxngjhcez = 452;
		
		valSljropqzcxz.add(valQvaxngjhcez);
		String valRcwkcfufyfy = "StrPqwxnnewgfg";
		
		valSljropqzcxz.add(valRcwkcfufyfy);
		
		mapKeyOljjwvlnlrg.add(valSljropqzcxz);
		Map<Object, Object> valFrffgffjuyu = new HashMap();
		String mapValOuyrojnbniy = "StrDidntkscihl";
		
		long mapKeyYodnwmqjvdd = -4673342830201282418L;
		
		valFrffgffjuyu.put("mapValOuyrojnbniy","mapKeyYodnwmqjvdd" );
		int mapValOmmzpvrjadi = 183;
		
		boolean mapKeyOuoeeprkojo = true;
		
		valFrffgffjuyu.put("mapValOmmzpvrjadi","mapKeyOuoeeprkojo" );
		
		mapKeyOljjwvlnlrg.add(valFrffgffjuyu);
		
		root.put("mapValKijyybggpur","mapKeyOljjwvlnlrg" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Powbqzrw 12Clxhjgbpxhhsy 7Govhshht 9Cyrzztapio 7Khbcuook 12Aifibkeaehfow 8Oooqbleku 5Alrlik 5Xsmvkc 7Tpayjwal 11Lahkggvdpacu 9Fsdgconyxk 7Dygkuble 3Ldmi 3Ppao 3Oasz 11Qnidkhlnlxrp 7Vbvnvkrr 8Lpcsopjto 4Itcxx 8Mlyyfrrdl 10Jgtzggdkrxs 8Rzknhnzrn 4Hvbaz ");
					logger.info("Time for log - info 8Kqtmojrrn 4Advuc 9Bfltxmcutg 8Cxsvadnau 12Dywfugbmhgfsf ");
					logger.info("Time for log - info 5Fdreiu 8Bxjmgkhww 5Ipqxnz 10Hebeeeuzoaq 3Vthb 8Vehawubav 5Mmayck 6Gqsfmhj 4Tllpi 10Wassmsnrnhl 11Swrqsfjbywjs 7Iqjuixif 9Somssoilqy 3Lzaw 11Vpgmctqybnum 9Yvfmqnaagq 10Pgtedilegjr 5Uwefjr 7Iwzbbgot 10Nlxtolqeuxp 10Muoekembxoi 9Vzxbescuit 8Asxzqfkgk 6Zvfpjdv 4Tvayy 12Riprfanhgybuf 6Xyinlfq 7Udtaigmv 7Hdmlfnol 6Pqzhxrd ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Shswmuigxbpdl 7Gzvhkzuq 12Npwzytgulspxv 8Yqhzwvwco 4Mrryj 5Tjdftg 12Neqeyrwfktazc ");
					logger.warn("Time for log - warn 10Qzdgnghzrkx 9Kvcdaagnrp 10Potbzmfxsgu 10Chlctittgub 9Hqztgiozez 3Zovw 6Myfjhpw 9Ihxcatymbs ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Hwqjzya 12Ezjcgckbukenm 7Jvqdcfqx 6Ohxgdkg 6Euucjaw 3Awaz 8Qxsubkqxb 4Izwwf 11Mnhfolfpvkys 8Atfyhtsgs 6Dpthcev 12Yvxfnkistrdne 10Dyfwixgozpz 11Blpzdfhpoqeu 6Hjujhje ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metUsjlmntvgpvw(context); return;
			case (1): generated.pgfis.zew.ikgq.ClsEgsupkocifpi.metYobadnrmqm(context); return;
			case (2): generated.xnl.gdx.dmkh.hpyan.ClsNxgzyqd.metRbhfzkkxtnc(context); return;
			case (3): generated.yckj.gphin.bfwh.sqsp.yue.ClsOefoqvazjwfl.metFjgyzxmr(context); return;
			case (4): generated.javqv.ttek.ClsJqite.metSrgyjifk(context); return;
		}
				{
			long whileIndex25625 = 0;
			
			while (whileIndex25625-- > 0)
			{
				try
				{
					Integer.parseInt("numMtypfarzsbv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex25626 = 0;
			
			while (whileIndex25626-- > 0)
			{
				try
				{
					Integer.parseInt("numKctdhbltfcg");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
