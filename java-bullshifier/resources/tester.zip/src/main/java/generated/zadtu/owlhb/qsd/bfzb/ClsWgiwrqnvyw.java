package generated.zadtu.owlhb.qsd.bfzb;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsWgiwrqnvyw
{
	 public static final int classId = 100;
	 static final Logger logger = LoggerFactory.getLogger(ClsWgiwrqnvyw.class);

	public static void metBigqrgygmlibp(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValXphunenrvws = new HashMap();
		Object[] mapValArdfcdztosx = new Object[9];
		long valDsfjfxmdgvh = -4741139071618154444L;
		
		    mapValArdfcdztosx[0] = valDsfjfxmdgvh;
		for (int i = 1; i < 9; i++)
		{
		    mapValArdfcdztosx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyEibwpgntiua = new HashSet<Object>();
		String valKyeyuoqepmg = "StrLquuorttrvo";
		
		mapKeyEibwpgntiua.add(valKyeyuoqepmg);
		
		mapValXphunenrvws.put("mapValArdfcdztosx","mapKeyEibwpgntiua" );
		
		Map<Object, Object> mapKeyCuzjdzxkbbp = new HashMap();
		Map<Object, Object> mapValIrggpygprwl = new HashMap();
		boolean mapValUutoasqzaar = false;
		
		long mapKeyCogzodwqvdn = -8314498248358741947L;
		
		mapValIrggpygprwl.put("mapValUutoasqzaar","mapKeyCogzodwqvdn" );
		String mapValXudspuyauwf = "StrYbqealnzkfb";
		
		int mapKeyLyuicbjdsnk = 278;
		
		mapValIrggpygprwl.put("mapValXudspuyauwf","mapKeyLyuicbjdsnk" );
		
		Object[] mapKeyKvbnaajkwhk = new Object[5];
		String valGozlhnezlkh = "StrXaayqqkdepl";
		
		    mapKeyKvbnaajkwhk[0] = valGozlhnezlkh;
		for (int i = 1; i < 5; i++)
		{
		    mapKeyKvbnaajkwhk[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyCuzjdzxkbbp.put("mapValIrggpygprwl","mapKeyKvbnaajkwhk" );
		
		root.put("mapValXphunenrvws","mapKeyCuzjdzxkbbp" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 5Alprfw 11Nupbmsfbppqv 10Gwhpbrtmhoj 3Ixbr 4Ecnpx 12Phnactwgbdoku 9Gzpdbftfeh 5Eikrpt 5Ryfgyj 7Yrfamkdk 11Czexilzgzvhf 11Kfseafvwjvmd 4Ufasq 6Mtvaehg 10Lbjtdqrooin 7Fjozhxso 12Gcfgpfudpvzek 9Jcixojlmrw ");
					logger.info("Time for log - info 6Pzpnord 4Gscow 10Bfbebnkdfzb 12Cbskohmfbusdi 5Txcump 11Cmyghqstzxtg 9Rbavawkhbg 9Zkcvusbald 9Zxtdnbzakr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Pzbxwtjaftq 4Znxre 10Zfkahppncjs 10Bomqklcfzec 10Yfdmuhjdght 5Aalbsu 7Wagnzpro 8Jxvowljpe 5Pautfd 3Rtxs 4Rrjdh 4Qxvyg 5Ssofwq 11Gojepvsbdkwr 10Rylqmsusfar 3Aiet 6Pyygneh 7Myjyxqqz 3Hkfk 11Zfofexfmndkf 3Heuf 12Daypfbiyetadm 6Kcqqqjl 10Rtdmxhaddys 6Ndovbzg 5Hattiv 12Vxoaonfypplox 3Avkj 9Jzptaxbnfb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Stvsvqapb 8Oqowtgprw 7Dqogxviw 5Briswf 6Bftlyzj 12Alishmzysxmkl 3Bcjn 10Zwymbesqbjf 4Agkql 9Ethyruwmcy 6Xektlko 3Aviu 12Fcdxfrreyrqat 12Etqihfpqucbrm ");
					logger.error("Time for log - error 12Zjvzybhioozdv 10Klfjyeyxqpz 7Owmwuaiy 3Niir 4Fmpbi 6Zjaaxtx 3Gthc 10Stvhqypsmrw 9Wtjfmvbbaw 10Zoxwnuelppc 4Xtydp 9Dnxthfbqqv 3Sbls 3Kxwx 12Oerqzktzlnqnv 8Ladenkfbi 7Tknbvdpx ");
					logger.error("Time for log - error 3Winp 6Auoxwer 3Fdea 8Zgsqsnxqo 8Aitvdmiid 5Lczuvu 5Euaway 12Drgojiuvhomrs 7Pigoozch 6Mnlupwi 8Qqjhhpvbn 8Znqjdefws ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ajbel.dvbe.pmx.gfhen.qjvpo.ClsFwkvrnv.metXipxiwvyvncxvi(context); return;
			case (1): generated.aea.iom.ClsOvjtnlwnmq.metKhmaqmoiluaib(context); return;
			case (2): generated.kfvy.ymxa.end.hazk.nwqfn.ClsXakhsfoyrlse.metSihzklw(context); return;
			case (3): generated.mao.kidk.mlsjr.hew.xst.ClsEfomkejxcxzr.metEruurpx(context); return;
			case (4): generated.tmohp.pbwu.gfhxq.zdkm.ijx.ClsDimqu.metXkytsyqb(context); return;
		}
				{
			if (((6879) % 354844) == 0)
			{
				java.io.File file = new java.io.File("/dirJyystzpaflx/dirKlfxfhwrrum");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((6867) * (3735) % 802124) == 0)
			{
				try
				{
					Integer.parseInt("numUvdynwswfxh");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirDmgyujsdugf/dirTxhebpjwmyz/dirQalbikouwfu/dirCtbsughfbsm/dirBifqholrnub/dirRlxnvnwcgzy/dirJabpwkpgpkc/dirMzpcxzdnvwy");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varWqrsngqzyju = (1544);
		}
	}


	public static void metJmapoligglq(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		List<Object> valBldfkhyaibo = new LinkedList<Object>();
		Set<Object> valVsdgzvuxnya = new HashSet<Object>();
		boolean valXnilzthyrdh = true;
		
		valVsdgzvuxnya.add(valXnilzthyrdh);
		
		valBldfkhyaibo.add(valVsdgzvuxnya);
		
		root.add(valBldfkhyaibo);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Rpnogmktlug 12Toilmpaojpele 9Wrgzyfskcc 11Nintdtkoigon 10Jddofskzotk 5Pgbdnu 8Wtawdqkaz 4Bwubh 4Lscdp 6Xxmcimw 3Pvqk 9Lobmgeqewq 5Jwkknk 3Qdem 3Sxbe 10Axzzmwcpiwa 12Utmkuprlbemek 9Cmgiadecbb 4Afahr 9Fwmvxpzxwg 5Xpbcti 7Pudpxpup 9Anrsromlxm 10Szpugjrdhvo ");
					logger.info("Time for log - info 12Hndqvdotdzyyc 11Ckkemzayiwpv 9Himnfnsjvq 10Tuegtcpvnss 9Mgnanicsmu 9Yoomihmblv 12Aogcxefnlcfun 7Fdggphac 6Kpzpjvq 9Cpwjtzvktc 8Nfjhfziie 5Btjfpy 6Teuvtmc 6Tbkefvl 4Ixdzq 4Rqgze 8Ulvxiddyk 12Wsidqwnlyohqb 8Wodvzedkv 9Jboyeplkks 10Hjmqrwtwopr 9Gnwauyabjn 8Sjtfoewhq 8Dulmvnkbd 10Krxqgrcvlah 12Keooqwoubaadk 10Jmsosuxqxyi 5Ysfkxl 8Qlszodwki ");
					logger.info("Time for log - info 9Xdqildovip 9Hvszycuftr 9Xgseiqbzee 12Fwatuyvrtgncc 9Hhxxluzboe 12Udrpfyfqszfxu 8Yjnxjymom 11Jxlndpfixjyh 5Umlalx 12Mzjgpfjdhtzqh 3Oqei 11Ptthqrmnmqaf 11Ntftogcoruvs 4Jqwei 6Qzwmduo 5Sbxipv 3Eucp 10Bxhrsttpivh 3Foft ");
					logger.info("Time for log - info 3Iumu 3Ksof 10Zxrcxbopyrp 5Ppvlyn 9Dhqusguzna 3Pixu 3Qvhh 6Gcswkcn 8Rtldddzid 12Rhuswpsriiodk 7Btoerwlh 4Cqpja 11Hwsehcrjiuzk 5Gekxil 8Shnlrapdg 4Pkpip 9Radnwdrieh 4Uhchj 7Ltpdyvvl 7Bonhxytz 10Dphdgcwkphs 10Rontgvxmeau ");
					logger.info("Time for log - info 5Otkult 11Gsfgxveehgeh 5Lamlpr 9Hzgnkygyya 8Qeyiywmld 4Rwrsh 7Mueeitxi 11Wltohvtgplxy 4Tpjqe 3Twyw 12Uzwiqoilaanym 11Qwchltwxehxd 11Vglarswjkozh 12Bgzdydmoqonhi 3Twkt 12Evjpdfrwweyhk 9Bwvrnwihzv 9Fuirgrrapa 4Wbblc 6Syvdcfc 10Gdozbfphayn 5Aunowr 6Vngkhxg 5Wyhivg 6Xpqyjmm 10Hwuvxhfpjfj ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Nmlvzdp 10Tsnzcgqfjil 5Mbkljc 9Xphzrnocbh 4Iczas 4Btdlg 4Svjmz 8Kbhtrylmi 11Cidgmwefqmkx 6Vrcztmg 9Nqyzvowhwv 6Dejzoxf 11Ahfouyehmbjo 3Dcvk 3Khtj 5Wiezue 12Gqvuuqxeokhnq ");
					logger.error("Time for log - error 12Znjsvhayxrgsn 8Tqkjyywrk 12Qqbnzmzfilfbc 12Unncwxdpwjlgp 6Fhrhhuv 5Tpqllv 7Ergljwyl 11Yehjdqmmzvnd 9Fcyewnzzqh 12Gikmbmzmwxiec 6Euylcri 4Czglj 4Oqxwr 8Fxomuwzfc 12Paweyrweysoyz 7Zgmabsio 11Mqzzxvnwxufh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.laaxy.myh.ClsSglobn.metCwzfwuxvrtwmm(context); return;
			case (1): generated.egtuf.tby.poy.tetgn.cnw.ClsOidjvegh.metZumgkftjpnldmi(context); return;
			case (2): generated.nxf.wvris.vmp.ClsGllyounxce.metEovax(context); return;
			case (3): generated.ldtgt.vdfx.cdz.lkx.ClsLvvwnymti.metOdzdjwutrxtvu(context); return;
			case (4): generated.idk.jvavb.vjuwp.iuzf.fawz.ClsRtwkffyfhbvpjl.metFydywnh(context); return;
		}
				{
			if (((4462) % 295403) == 0)
			{
				try
				{
					Integer.parseInt("numVvxtejqldjd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metYrmyjlzzyyu(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valMwawtegwuzt = new HashMap();
		Map<Object, Object> mapValVvpsvimsnvk = new HashMap();
		boolean mapValLbegeyswsti = false;
		
		long mapKeyXapihaepzih = 1418797041478044662L;
		
		mapValVvpsvimsnvk.put("mapValLbegeyswsti","mapKeyXapihaepzih" );
		
		Map<Object, Object> mapKeyTwtowvpsvpe = new HashMap();
		String mapValFgtoynakaay = "StrAiwnhniknhj";
		
		int mapKeyHwhqlxxcqok = 124;
		
		mapKeyTwtowvpsvpe.put("mapValFgtoynakaay","mapKeyHwhqlxxcqok" );
		
		valMwawtegwuzt.put("mapValVvpsvimsnvk","mapKeyTwtowvpsvpe" );
		Map<Object, Object> mapValKgkrrqzorjg = new HashMap();
		boolean mapValEnffrnwwlwy = true;
		
		boolean mapKeyNcqomtewexr = false;
		
		mapValKgkrrqzorjg.put("mapValEnffrnwwlwy","mapKeyNcqomtewexr" );
		
		List<Object> mapKeyTfueopkkcuq = new LinkedList<Object>();
		String valPycmulvtquk = "StrWfwbarssdhp";
		
		mapKeyTfueopkkcuq.add(valPycmulvtquk);
		
		valMwawtegwuzt.put("mapValKgkrrqzorjg","mapKeyTfueopkkcuq" );
		
		root.add(valMwawtegwuzt);
		Object[] valExfabszdvib = new Object[4];
		Set<Object> valTgxhuvoutov = new HashSet<Object>();
		String valQiszixqzkow = "StrAmgvezxsgje";
		
		valTgxhuvoutov.add(valQiszixqzkow);
		
		    valExfabszdvib[0] = valTgxhuvoutov;
		for (int i = 1; i < 4; i++)
		{
		    valExfabszdvib[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valExfabszdvib);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Efjqy 3Renv 12Gamdxqofpnzrb 6Reolgjn 3Wmvb 11Vpjmneghvzqh 10Lxvhonlwtai 5Akfhva 8Gjcnvhpxm 4Shnml 12Csdnjgxwxtfwv 7Zgjqdodc 4Qplco 3Uqhr 11Gduooidykzcb 3Ymth 10Qsojcdbhnyt 8Iyiexbcdi 6Vzrerjx 12Felwxlhteqdzb 8Zkodbyjem 3Fkbv 11Zvygdyckmctj 6Koonraw 5Jjqruz 8Tjbnxkywq 3Crmy 6Rvthzhy 5Gfxrco 11Ruhjhbykzews ");
					logger.info("Time for log - info 11Brzjrpchzoqm 9Mekmthcack 11Wrrqwkfcjkap 9Coqkikfufd 11Hhudthadeews 6Tcwpjbe 7Vejzilwi 7Lffwwsko 7Zuamayio 10Dytfkkchhyn 11Ywfoufcsuvwb 4Vnmna 6Eeqlwmi 6Dkocfgr ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Nfphjc 10Luszizhmxne 5Saccmu 7Kktjwiio 3Msgc 4Dqxne 5Ngghkb 8Cthuybulg 8Dlgaufxci 5Fvxylx 6Zteycoj 6Wxamsje 6Hbaqasm 7Fzqtyxyb 6Uagyqfz 12Yxvmympxgzcar 4Ewfjd ");
					logger.warn("Time for log - warn 12Uhewcysszmary 12Brtkhlfligiws 9Ieligdhgxo 8Zoevdepjz 5Hunylc 12Sxcwusxoteyze 8Hqmrtjzkf 6Mdunkom 8Lomwwmwnt ");
					logger.warn("Time for log - warn 6Nnvbesp 3Tgjn 4Bgkhu 7Tnijvnkh 4Aoacx 8Uibzqjldg 8Nvvrbzchd 8Jhknydeyy 6Yvpyhqk 10Dsweiofkjwn ");
					logger.warn("Time for log - warn 9Acwplnfvqt 8Gfwcibgtj 10Kjbkuyftzfz 12Eouyplckykvvj 5Wsbies 6Okrwlzl 4Hgqir 6Ovmpnfo 11Dhtiwjwulmiq 12Jdvgqlouacjwa 12Lkbldngrblsot ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Lhwunarqqc 9Qmugzyfsvd 11Kcmfjebkhrzb 9Kdqjukxffe 10Kpehbyzubme 4Csbvx 3Jwcd 10Aylpgdkpans 7Gdonmvwd ");
					logger.error("Time for log - error 6Nxrcggb 11Dscedkffmrkp 9Xhxrkyxcrk 10Blwyhacedha 3Rozj 12Ydzakmbcfxbdb 4Fkwjy 11Vhspjewkutga 9Pdpcrqovxj 9Kifwgclvxn 8Rurdajsjz 12Lrsofalcyazbi 4Rlqst 12Ulpavppoitrvn 3Gvfs 11Rdrqvelzbeez 11Wtdetfmrcghv 12Ftzkudkkxtthx 3Hiut 11Avmyquuwjynb 8Drmbmqhpu 12Lwrkewmicwtum ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bad.yds.jib.otl.ClsBzgol.metFiipzeiyfjfs(context); return;
			case (1): generated.wrwx.jsm.hgij.abg.imgx.ClsRhzgz.metZwioh(context); return;
			case (2): generated.okso.ktog.gaxvz.tetmp.ClsRgfjzhrb.metLlvwdlebp(context); return;
			case (3): generated.enb.ktdil.ClsEqcfzlhpy.metPzfwhbxomd(context); return;
			case (4): generated.idk.jvavb.vjuwp.iuzf.fawz.ClsRtwkffyfhbvpjl.metFydywnh(context); return;
		}
				{
			long whileIndex21809 = 0;
			
			while (whileIndex21809-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				try
				{
					Integer.parseInt("numKdbsgoojcrv");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex21817)
			{
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
