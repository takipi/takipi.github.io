package generated.xcud.xbp.eztj.gexk;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsTupoxajhjshtec
{
	 public static final int classId = 290;
	 static final Logger logger = LoggerFactory.getLogger(ClsTupoxajhjshtec.class);

	public static void metEsfpmpnsdd(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[7];
		Set<Object> valHxyzjnmajzx = new HashSet<Object>();
		Map<Object, Object> valSbmubgpzlwm = new HashMap();
		long mapValQcytbqvixwr = -5813961474703244408L;
		
		String mapKeyKmxhtrhwkia = "StrJeddnrfxcwp";
		
		valSbmubgpzlwm.put("mapValQcytbqvixwr","mapKeyKmxhtrhwkia" );
		
		valHxyzjnmajzx.add(valSbmubgpzlwm);
		List<Object> valGzskxqnogxv = new LinkedList<Object>();
		String valLgctpzqhlxe = "StrZfppszdskfr";
		
		valGzskxqnogxv.add(valLgctpzqhlxe);
		long valIpcmvviswmh = 2317500792518202339L;
		
		valGzskxqnogxv.add(valIpcmvviswmh);
		
		valHxyzjnmajzx.add(valGzskxqnogxv);
		
		    root[0] = valHxyzjnmajzx;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Iopeqvwwzdtgt 12Zsdzgzekaegbk 12Nbpeztzarpplf 10Wfuzrajzkwh 4Wfbri 7Zqxvwrxj 11Dlycfkcftmkv 10Xeubhwtpqnl 7Xccekugs 9Vvoeradwul 5Tdtmsa 11Elorrbvtjlga 5Emccmw 10Ytlhkjcvnvc 9Ocnndvujjn 10Ojpxnjvcxro 5Jcfteb 6Twtfbio 4Evqfg 11Nuhrgadkygkh 4Ttygu 9Gwfcfffxyn 7Jpsjotui ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Gujahsrtulp 3Aumf 11Mnwwbzzzzucg 12Kmrtzdkvruqmw 10Rxhuamwcskd 6Tcvvojd 7Blezevpa 11Fboxbtgytbsj 5Enzwlg 12Cdfrqjboitsnc 11Sgumwdjtzupq 3Pbmg 12Vvqaceykzbuqu 10Pghdfdeazoj 10Foppmbxbzlf ");
					logger.warn("Time for log - warn 5Krvwyz 9Ywwptrrtwy 8Ezndxflwi 4Afmuk 7Yuejlkvh 6Gvzqrmx 4Pybiz 9Dsaugpgqwj 11Nrhafemfqjrr 10Vsfpgjwcxrf 11Ivhltcbwkxpx 4Ahndq 10Tgbovmqzico 12Rbzdgkoalmkxt 8Echszrmyp ");
					logger.warn("Time for log - warn 5Mydqzz 4Plicr 3Ciqp 3Jnzl 9Ptztljmztv 3Qhgq ");
					logger.warn("Time for log - warn 9Ukgwmulhsy 12Hjkghhgwrmgpq 10Rcrwmwcxnuf 3Mvtn 9Dgdwqxtthh 7Uogcejyy 7Nxowjwle 8Opwvtytkd 7Tqdqufnd 12Klqzzuldlbyta 4Osxpx 12Sombbunomavoq 6Yygkkdl 6Wgfubsc 9Zhrjxzsqrh 8Thenkgpcq 10Wrdmzxielwj 11Awdnhctqvixl 4Utien 9Aohbkqudpb 11Fwcjgyaogkon 6Xknyzxj 5Rofszc 11Ywlokrplblyw 12Bkoqsvzxlqukj 10Igyqufncsrm 7Hmcrqvsh 10Dzsrxxbsiyp 11Lsoxndgievmj 5Tmumzt ");
					logger.warn("Time for log - warn 9Kwscjaxccl 8Uriqijsin 6Yxwiwcd 4Snifm 12Ecbupheazgibs 4Wbnnr 3Hzlt 10Upzfirvmfpa 6Ytumvpi 10Feiulnubjjh 11Lfoqeykjtrin 8Innkkksgj 4Lojcy 12Gslwxircpsiwf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Vtmmkloyolfx 6Xrtgutu 3Xhgt 5Vurljr 11Jqbfbvnnqmjs 8Eorsuygbe 11Byodttbfidkj 7Jjkqxbci 12Eyicoqdjfumbj 10Ovlpdisvuxp 3Zrvt 3Mnrp 10Ktffcleluxf ");
					logger.error("Time for log - error 8Ctzrabaec 5Xnhgar 12Mjewqvchxhvwe 7Fhlehace 11Dhslnyzkklgd 6Eakncmv 11Rpzbxrltwply 3Uhkc 8Ysvllqpva 4Vycvt 3Wycz 4Fveew 8Rrfmxaauk 10Rrofqlibwwu 12Lhzvpxgonvjua 12Rbkshltmqvwyz 6Kvxfcud 8Felhkpfjv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gfiaw.wgvz.askqs.ClsGbqekumwdbwfn.metPejnumeutimyrt(context); return;
			case (1): generated.baxd.moelu.dfhna.pgrdw.pgae.ClsTifyecuw.metKuqddwkfbtsqxa(context); return;
			case (2): generated.kfjp.bzn.mda.sfyxf.ClsAguszlzt.metWsvlopnliexx(context); return;
			case (3): generated.rlg.pxdte.svn.clv.ClsMkagt.metEsbkjtdvlylqyw(context); return;
			case (4): generated.bxw.hza.cjj.bpzns.qzgt.ClsQbxnaxsj.metFribf(context); return;
		}
				{
			long varNvgzetykhrx = (5539) + (Config.get().getRandom().nextInt(155) + 5);
		}
	}

}
