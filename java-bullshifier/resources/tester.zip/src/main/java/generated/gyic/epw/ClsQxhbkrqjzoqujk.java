package generated.gyic.epw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQxhbkrqjzoqujk
{
	 public static final int classId = 407;
	 static final Logger logger = LoggerFactory.getLogger(ClsQxhbkrqjzoqujk.class);

	public static void metZjjvdqtoif(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		List<Object> mapValChzmhyslfnn = new LinkedList<Object>();
		List<Object> valRactjtuxnej = new LinkedList<Object>();
		long valEcxwupbvnev = 1954798686589134871L;
		
		valRactjtuxnej.add(valEcxwupbvnev);
		
		mapValChzmhyslfnn.add(valRactjtuxnej);
		
		Object[] mapKeyFjxkhbqtoix = new Object[6];
		List<Object> valJaxgzzspoci = new LinkedList<Object>();
		long valQkudjeqiuuu = -1972775867137122809L;
		
		valJaxgzzspoci.add(valQkudjeqiuuu);
		
		    mapKeyFjxkhbqtoix[0] = valJaxgzzspoci;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyFjxkhbqtoix[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValChzmhyslfnn","mapKeyFjxkhbqtoix" );
		List<Object> mapValUxrupjevliz = new LinkedList<Object>();
		Map<Object, Object> valWcpcsvifwje = new HashMap();
		long mapValVpojvryivpz = -4230992613068116308L;
		
		int mapKeyDtuavfwfvyz = 428;
		
		valWcpcsvifwje.put("mapValVpojvryivpz","mapKeyDtuavfwfvyz" );
		
		mapValUxrupjevliz.add(valWcpcsvifwje);
		
		Object[] mapKeyWmnhyhufebr = new Object[4];
		List<Object> valGkcdvjarhqw = new LinkedList<Object>();
		long valBzejulenlzb = 1743574734721025936L;
		
		valGkcdvjarhqw.add(valBzejulenlzb);
		boolean valIsqbjxyfnql = true;
		
		valGkcdvjarhqw.add(valIsqbjxyfnql);
		
		    mapKeyWmnhyhufebr[0] = valGkcdvjarhqw;
		for (int i = 1; i < 4; i++)
		{
		    mapKeyWmnhyhufebr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValUxrupjevliz","mapKeyWmnhyhufebr" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Scpotikjiyqq 6Telvywd 3Gufu 5Kakkui 12Qdaynpynwsvld 11Hvjvtwtqbtbt 7Hxbwjvwk 3Wvre 5Uewjxq 12Nzqtfxiddttqy 11Ghwpvthmcalj 4Lynvy 3Svff 4Vciit 12Vunbbtnbvhaiv 11Lzrmjtajgekc 6Vaxkbae 9Xxitoxrnkm ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Letokd 9Arechmaojm 8Gcaicyavp 11Udpmxwkfvahc 3Byjh 6Lirrqns 10Vjfnbcjirgu 6Zznzzjm 6Wlfgwcj 8Znccjmcyr ");
					logger.warn("Time for log - warn 4Gvwam 12Njsgsabrcwrpz 3Jahb 7Agazeovk 9Uvycjnwasp 11Bxhiakbwujas 5Yimwfc 6Ttyxsfx 6Xlsmlit 8Skahakabh 3Digl 5Nztegw 7Fxebwmfj 7Ouqlomzp 11Euqkrovyrtmk 9Izroqqwwcw 6Rsnlckd 8Bldqqakak 3Toxd 12Lewchchqzzyhj 3Ihrj ");
					logger.warn("Time for log - warn 6Fgjghqc 4Iskih 8Sjbtcqhqy 10Egdurhrojau 8Hsvkwuice 10Itztitomxgw 9Zpwldupuux 3Scyd 4Buvtu 10Wyhghkcskqw 11Haocrlvldiei ");
					logger.warn("Time for log - warn 7Wpksmsyt 11Rdlalgqhdmrj 11Wddpmpnrxjwv 10Yawifvyghix 12Psyntajlwzfwt 11Cnqassmuwnpe 12Pmoigaglaipym 4Uwcwo 12Skentucucrmne 7Hlzhatie 10Bkfacbnemoh 9Ehhpmsbrhh 6Tyaysxm 9Uqzzmegpfo 4Vkqqh 5Uwhukc 3Swot 7Gjhzlzvo 8Xfxdmfkip 3Sjzy 5Mhsfjf 6Fgfatpj 12Eoifpbclgjrrg 8Evdsxgvqd 12Wcnwfmuzssnwn ");
					logger.warn("Time for log - warn 10Mcgfhewalvz 7Nqnstnzz 6Semsuch ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Ezriqcpa 7Ohxudicv 3Qual 8Ximrewwtk 8Panwjymms 6Ksocwbg 8Ozkghinti 9Apnrjsjemr 4Ithne 5Bzfksp 10Xesskeatamk 10Yrjwtmvjsnh 3Pkzq 5Ygzptu 8Jhcwkmtpr 4Otxuo 4Ohtnj 12Qanhiqxtdhkxb 11Mfkagmqlzovl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
			case (1): generated.kjubh.rgz.earxz.ypjc.pmupv.ClsUctrmkk.metPxspawrgwl(context); return;
			case (2): generated.lfkk.ncy.gpf.ClsMafxzncfnwvsdj.metSxjirq(context); return;
			case (3): generated.dpe.jvo.jwdtk.ClsKqcmvv.metOqhxfxoow(context); return;
			case (4): generated.mbn.igyf.ivup.sglb.ukb.ClsQzhoqgskicnjw.metJqiotqpjksr(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numUklllwsffeq");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex26865)
			{
			}
			finally
			{
				java.io.File file = new java.io.File("/dirCqptvokeido/dirImxvrmpckpb/dirLvxlrflzirr/dirYggjokxgmur/dirVwwkzrekdgt/dirYwatjofvyhb/dirRgumnaootvk/dirApchehtgecx/dirCquxkuhcqwm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varQoyzputzyqv = (964) + (Config.get().getRandom().nextInt(744) + 2);
		}
	}


	public static void metLlbnuvvzsghg(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Object[] valHeregccbake = new Object[11];
		Object[] valQvihywjrilg = new Object[6];
		boolean valWgohhvtdmqg = true;
		
		    valQvihywjrilg[0] = valWgohhvtdmqg;
		for (int i = 1; i < 6; i++)
		{
		    valQvihywjrilg[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valHeregccbake[0] = valQvihywjrilg;
		for (int i = 1; i < 11; i++)
		{
		    valHeregccbake[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valHeregccbake);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Aepeyylfjxprf 6Fsxjpzw 3Dybv 11Gupkopegjpti 10Kasffbbvefu 10Frjvpvvbxre 12Eysozzfpkbygw 4Utuvy 9Lfqspvudsg 3Kqjb 6Idckgsp 11Bwaqsymglvhv 9Omawlyihjk 11Bxoeyjlsgmwn 5Iwniwh 4Uzcda 7Availlkz 4Xefns 3Bxyf 7Qnlwaebu 12Czwczzvwmrdrm 5Ojzwte 12Zmwrrazdflzeq 5Kdmoax 8Nubwwdqxa 9Rwkydowjne ");
					logger.info("Time for log - info 9Ryehtzplvt 8Uztofwmhx ");
					logger.info("Time for log - info 12Stczbjnnixuag 8Kdshcpzhd 3Bkib 6Wutyned 7Ivuxdtwi 5Rqrzfx 12Wuvxemrfyvlik 11Vwrvjaioeyvi 7Ptgloaey 12Qhncyozqfgaqk 4Hbzbk 7Cewkcrme 4Cfnfm 10Ymwdmotycqu 5Wahuzd 6Brhaswu 8Ufcxpnihm 5Igfbhd 5Bctmij ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Jift 9Dhzvgcvoyt 10Vxoskosetkq 7Rqwvmhiu 7Btxvdnzd 6Piuwcsr 11Gpqtoqfwccun 3Towv 4Vdjiy 4Pwvch 12Bmemqzrxbpvsg 11Oyyyawjuqggb 4Hkjkb 4Vylvo 7Zfqraguv 8Gazpythne 4Iqtzm 6Nbztgfu 7Vmeysfcu 4Yalut 11Zqziyfmyrfoe 12Wveehkksoteue 8Sxweczcqa 5Ugspxf 12Mafcolicpkqxf 12Rnbnhkdnegxzd 11Jyinluvhghyz 6Gekzmsj 9Hjbrvhodhb 8Rrvawuclm 6Ixvxrfp ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Lsmnoyyjusoxy 3Kwjl 4Qrjrm 10Qbjrzhuzjsp 12Znzxgamdmdeig 10Mxqdajbyjpq 7Oazyqpyh 10Xxqotvgttsu 4Ciuqu ");
					logger.error("Time for log - error 10Xfghlilgygp 10Scydgrvchiy 10Ibqxaaavytp 11Gvuxolyricem 9Xvwpxbsdvq 11Qcvtuyzbftin 7Tmscldyf 6Wozbegy 7Cmgyvlxk 11Qdoiaimimlky 10Rxigvqvxgbk 9Ltcoumsqjx 11Qslpglhesewq 8Svyijiwvs 11Ksfmlvzlfspv 10Pevnjkiceha 5Fxtyjf ");
					logger.error("Time for log - error 10Bwnsiytukve 7Hxoafppf 3Taip 6Otqvndg 11Wrjpxwfnopxi 4Lzqxt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hzldn.tyqka.jujr.chcpl.ClsNxkmsnjozqsvm.metQktcqw(context); return;
			case (1): generated.javqv.ttek.ClsJqite.metZuokvxyfddpvoh(context); return;
			case (2): generated.xam.emsw.ClsNwmpfankaxgqb.metPslpna(context); return;
			case (3): generated.gbss.lmi.dvqsw.ClsLptludgibvpvw.metZydcmbkku(context); return;
			case (4): generated.zvc.zkqw.sqxhe.ClsQioplriwzgyw.metLtxcprhjnjohkg(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(733) + 3) * (Config.get().getRandom().nextInt(837) + 3) % 825428) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((6705) % 958471) == 0)
			{
				java.io.File file = new java.io.File("/dirFqzvxytynrc/dirEebowxwoadi/dirPgyfhgmcdak/dirNuqkycwgvyr/dirAapoembbkra/dirWbhadlpaikp/dirBxkweixkrrp/dirVukuzgutrfp/dirYbqbdkblhiv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varBqtcpacolny = (Config.get().getRandom().nextInt(432) + 4) - (5649);
			int loopIndex26871 = 0;
			for (loopIndex26871 = 0; loopIndex26871 < 9612; loopIndex26871++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metGcqcxmaffuic(Context context) throws Exception
	{
				int methodId = 2;
		Object[] root = new Object[4];
		Map<Object, Object> valOftrdkbtjdn = new HashMap();
		Object[] mapValTcvvjgbbfpd = new Object[3];
		long valJgaxykeszul = 5983349110630976420L;
		
		    mapValTcvvjgbbfpd[0] = valJgaxykeszul;
		for (int i = 1; i < 3; i++)
		{
		    mapValTcvvjgbbfpd[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyVsmmycdahsq = new Object[6];
		long valZxxlibplldu = -5362473587415697449L;
		
		    mapKeyVsmmycdahsq[0] = valZxxlibplldu;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyVsmmycdahsq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valOftrdkbtjdn.put("mapValTcvvjgbbfpd","mapKeyVsmmycdahsq" );
		List<Object> mapValCuhqukylolr = new LinkedList<Object>();
		boolean valEpmcauvprvn = false;
		
		mapValCuhqukylolr.add(valEpmcauvprvn);
		
		List<Object> mapKeyJcqfexqhpag = new LinkedList<Object>();
		long valLopobnwcjqp = 141492521176225558L;
		
		mapKeyJcqfexqhpag.add(valLopobnwcjqp);
		boolean valBqzzwretzmp = true;
		
		mapKeyJcqfexqhpag.add(valBqzzwretzmp);
		
		valOftrdkbtjdn.put("mapValCuhqukylolr","mapKeyJcqfexqhpag" );
		
		    root[0] = valOftrdkbtjdn;
		for (int i = 1; i < 4; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Aamcwiqvtxyvk 5Ngpewf 10Vxzvubcjbpv 8Ssuoyfrzz 4Acnag 8Uuummqnub ");
					logger.warn("Time for log - warn 12Ksldywwfuhnwc 11Zyxjbiowmflj 7Giskrgif 11Leteulnxcgrr 11Djyxovnddlwv 9Mnjtijgset 6Pcyvjko 7Qsuoibpu 4Sonfb 9Mpmucpcfzy 9Klcoskkgnc 5Lgpzzl 4Iiqnm 10Alkuyakbivk 3Hoan 4Gcutu 10Seqlihyrohy 6Cjwvoql 10Rdzemtzivvf 10Sdrqrkdbxim 9Xhzylgaegv 7Apbdnymd 5Lsuqmr 5Oswkly 12Ceoghrgweiebd ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Tnrmvuutwkvb 5Ztzxhk 3Gppp 11Crfliglolais 9Wqubtlvllm 8Ryamucact 12Nskybpxibaeqm 12Hqhvxmnlagcmq 7Zyepxfjz 6Bfksphn 6Lraitxd 9Boxpcpnbdn 12Lufmqdsyzsqir ");
					logger.error("Time for log - error 10Pjikpvywibr 9Tigzyvxfgq 11Hhdbjpcdptbt 10Niolgmvbxyc 4Shxtw 6Vkzvbkl 3Qyyn 9Bwjlvwjthk 11Npryloutkvyc 9Aqriqxpqls 3Vwyt ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bftm.jkb.lcr.ctpvk.ClsYfbhukzct.metRdbrizfs(context); return;
			case (1): generated.uhn.nhlo.xwe.qendy.ClsUedsvxy.metDgnkkfe(context); return;
			case (2): generated.kibd.nddr.nknr.pccz.hryio.ClsBgthm.metFrmpvshfvh(context); return;
			case (3): generated.wier.vwsz.frtoe.zpo.ClsRwhkekxcsmjus.metDnxwcgye(context); return;
			case (4): generated.dyv.vxo.ClsWrwpfswr.metCedzccdg(context); return;
		}
				{
			if (((8340) - (545) % 970100) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((5265) % 872764) == 0)
			{
				try
				{
					Integer.parseInt("numJqwepychxre");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirThaercohfyn/dirLcpawbawjly/dirBkbmiahzjoc/dirPrhscobmsaw/dirUbrblkalezj/dirJmxueajlxjn/dirVkktovspomd");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varAyfhycepoan = (Config.get().getRandom().nextInt(726) + 1);
		}
	}


	public static void metCxlwimqqzxfd(Context context) throws Exception
	{
				int methodId = 3;
		Object[] root = new Object[7];
		Object[] valPsthyvauaop = new Object[10];
		Set<Object> valUofjfnzndng = new HashSet<Object>();
		int valMcfwnaytrmi = 902;
		
		valUofjfnzndng.add(valMcfwnaytrmi);
		
		    valPsthyvauaop[0] = valUofjfnzndng;
		for (int i = 1; i < 10; i++)
		{
		    valPsthyvauaop[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    root[0] = valPsthyvauaop;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Qoexn 7Sgdwhfnl 11Afxtadlxuqrq 8Klpokeshi 7Urrhlclp 8Aigfctubk 4Lxzgv 6Gvqrnku 5Tlxivl 8Wobqfnbfr 5Qufyhn 7Izwtcvzb 7Pycsjyyl 9Bhzbgkvble 6Gmkaids 9Wafxzzptsc 11Yxcsjecvaysr 8Ejnpvnklu 5Thfimz 11Mmensozewtxb 12Iwxcclyukazzo 11Lryqwzdqouho 4Oirtp 6Nqsgvpp ");
					logger.info("Time for log - info 9Xwwendpjnc 6Ktoipfw 10Wmtmelfhkfv 6Mpkysqv 12Dwhqjeaxcvmmy 11Sfodujxsjume 6Plvgqrj 4Grnub 6Ouuxmiw 6Rjiqeqw 12Uhslpyruvptfl 6Uaqsvzz 3Aykh 7Woflabtx 4Kodry ");
					logger.info("Time for log - info 6Sgoozye 6Vyncgbv 8Uyobhgdxy 7Spgztpiq 8Evlgbcauz 5Cwzfjr 6Ojmdlmi 10Cufzkmiauaw ");
					logger.info("Time for log - info 4Firyy 8Pophgqjrg 12Psxzylsbdvecd 8Chqqrszci 3Ewqm 5Tinjcb 6Zqzxfpx 6Dnlumlx 8Donzyzpsq 5Fgnwhn 12Kpsyiucianzva 10Zputlbrzggw 4Lobqa 4Myems 10Ofabumnnhrk 9Jyeszdcquc 11Qnhhakopptnd 10Rvrbkxsothb 3Qlcx 6Mikcnkb 8Witszhpfq 11Nfshsvrfvfma 4Prtur 9Togvtlmvou 4Vgxgw ");
					logger.info("Time for log - info 9Vyflgyqkbu 9Djvavovbfo 11Ukvuelkhjgxc 12Jvpkepqawskma 4Dgira 9Dgibxwenrb 7Lbeimkdg 7Sflvneyj 3Tikf 10Cgampqupaoe 3Jpwp 12Izntbzlbftmee 8Jvdmfnplt 10Btwwxgulhkf 3Woec 3Adwz 3Qukb 4Ciibm 5Nlnads 8Gkqhdixmk 9Mggssxzgup 3Vlfa 11Oemxqklwipcw 5Mslqrh 12Bwqebsqhlxooz 9Sacbqmuitg ");
					logger.info("Time for log - info 12Ecfmnekiydzhg 10Dqqnxzaspvb 7Kkeuozcp 11Yeujsmjqawqe 7Gardeoeg 9Dwsbcnycoo 4Vwtsh 9Xawdtrqwum 9Whrnxdizmb 3Fzbx 4Xoqms 8Fgidymybb 5Avrpvd 3Gupt 10Vatnrbqnysf 7Qznygwch 8Jalodzllk 8Mstizagqp 11Uebenoyowlpf ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Nhojvrzvgyhos 9Nxzuhgaqmd 9Ngbjjmxeev 5Yxpxxr 10Myrpyxbqfti 5Ujhhpq 11Pzcbufyejrma 11Stnwmzxvtlyo 5Whsngn 3Cezw 3Xtmp 5Zdrbbj 6Jlmcpba 5Zzlash 11Zpatmfkqkwyf 10Fsdgdfdevqc 12Funsrmobfinzg 11Rrulghrcympt 10Vijsiqdgwwm 10Nqerlqeuxfy 9Fncgsngefh 7Opecytro 10Ebudmcaodcj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Brqcmsxgsdfdt 6Ttaqgud 9Yceuxmbhvj 7Qibiwnit 7Gngorlyu 11Zqfxdjcpfnbk 11Nnmbqxpgfpdy 7Yioiytgo 12Uavfniknsxusv 11Cvulywtompxj 3Rpxt ");
					logger.error("Time for log - error 12Hppraveyapemw 9Vufypeirdb 11Jioqzdgmgzex 12Dqmyiwngnlxlg 12Loievvponuaik 6Fqljmqh 3Rclw 12Mcghzcsndqlrb 11Wqcyrlbetiok 7Imkuxijn 11Extzhuhqbjbz 4Ntavf 6Jdjhvbn 10Aixzeyuqiqs 3Endo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mao.kidk.mlsjr.hew.xst.ClsEfomkejxcxzr.metEruurpx(context); return;
			case (1): generated.lxmnm.hdgf.ClsBecbgmyq.metXxaphxbxrzzp(context); return;
			case (2): generated.uhn.nhlo.xwe.qendy.ClsUedsvxy.metTxsoh(context); return;
			case (3): generated.xhxl.owx.ClsJgljylyqsyfqzr.metWircnlydewe(context); return;
			case (4): generated.erjvc.bth.rgln.usqa.ClsYyzexetbgpowz.metQeqazcpvlygd(context); return;
		}
				{
			long whileIndex26885 = 0;
			
			while (whileIndex26885-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long whileIndex26886 = 0;
			
			while (whileIndex26886-- > 0)
			{
				java.io.File file = new java.io.File("/dirGlgszudjxex/dirOhhuuvohdde/dirXbfurjuncpe/dirMjnfnoehpkz/dirAqnhvkoxvve");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metVprfejv(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valKmocndvfjpu = new HashSet<Object>();
		Map<Object, Object> valThusczjdztk = new HashMap();
		long mapValHiotracvozi = -1257019538722468145L;
		
		long mapKeyCvmvrxtlfgq = 8313477941495912085L;
		
		valThusczjdztk.put("mapValHiotracvozi","mapKeyCvmvrxtlfgq" );
		int mapValDhucidzhsbh = 185;
		
		String mapKeyUcqoyhymkdg = "StrKlhtxltqdjl";
		
		valThusczjdztk.put("mapValDhucidzhsbh","mapKeyUcqoyhymkdg" );
		
		valKmocndvfjpu.add(valThusczjdztk);
		Object[] valZmdlijwmiwl = new Object[4];
		boolean valJjvpjajisef = true;
		
		    valZmdlijwmiwl[0] = valJjvpjajisef;
		for (int i = 1; i < 4; i++)
		{
		    valZmdlijwmiwl[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valKmocndvfjpu.add(valZmdlijwmiwl);
		
		root.add(valKmocndvfjpu);
		Set<Object> valNdvxvitpcsf = new HashSet<Object>();
		Object[] valEotfmwcxkux = new Object[6];
		String valMhdrsrhjbkl = "StrRrdronvehjw";
		
		    valEotfmwcxkux[0] = valMhdrsrhjbkl;
		for (int i = 1; i < 6; i++)
		{
		    valEotfmwcxkux[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valNdvxvitpcsf.add(valEotfmwcxkux);
		
		root.add(valNdvxvitpcsf);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Pikgvdfyrnza 11Xncvshuwugyp 6Esxfimq 11Emvjkcthcomq 9Vdqigblgyl 11Omyzeroxsikm 10Veqpwtffyra 3Ydmq 8Cpwqybloh 6Kpsltpa 4Twhxn 6Ykjyxcl 4Uwvfo 12Psuewlumezgfv 3Rqrz 11Pmnyfgkqfldg 4Avazz 12Mgnruimmgfpkb 12Zttslrotswvng 9Sibllpnwyk 12Cgdgoxmgpzgdw 5Woqoyp 12Xgawesivkdzzi ");
					logger.info("Time for log - info 9Txvjiljykx 9Cjwvbrwzik 3Btqm 10Brjbnbopqda 8Tazusimim 4Vuhmy 4Nzqjb 9Nyzamcmvlc 7Lewnqjyb 10Cphcxytjrdp 5Aqwweg 12Gelxjwzrhnegf 5Xetahd 3Lqyc 7Drfqapuq 9Xgdrlclkgz 9Owoixsccwg 8Mkmigqkuw 5Jembrc 9Atqdqtkkpm 8Jildzxbfs 3Igbk 7Cgztwipu 9Mwfwwjflzi 10Prajcbnhrjl ");
					logger.info("Time for log - info 8Xxstuwddk 9Igbcxugjeg 7Ensjnesh 12Txzrdgesbboor ");
					logger.info("Time for log - info 8Dohmmzere 4Yspbt 12Gsbzfnflwtclg 8Inzezpevn 3Vwnt 10Vqelzyxmzyl 10Qjzsjqopdwl 11Wnawnqssdevc 10Yxsdiouudlu 7Xqtdiyyn 12Dmpjscjjvcsut 3Rddm 12Wpygcyowqakhg 11Hfmjyhalbgup 5Ggmgrl ");
					logger.info("Time for log - info 3Wwkp 9Lkkakzdcwn 7Xbbksguu 9Lxskiewkar 11Aohrcihqidnl 11Mmdnqjsdfsrp 11Wwhxjzxwvwnl 3Ihrb 3Nion 6Iqrusxy 4Yqnlu 3Vjhp 10Mcsvrxwvoev 5Iabnuf 4Yuimc ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Mmauxam 7Ptlpkuwq 7Hkmxgsfe 7Xwbwqjml 6Jjislor 12Bntpoazdpucih 9Htbrejrokl 5Orqvoh 8Hxuqtsdbr 11Vxhyucdplggj 3Sqlf 4Epjrw 4Ovluq 8Swyrnwlki 5Fxcuzb 11Vprsrzstgzee 6Ehtqixy 9Ijssphwdsf 9Ublquxbmqt 5Lnfjvj 11Frtsgxixoeut ");
					logger.warn("Time for log - warn 11Ymrddnfqbnfw 4Jgqdt 3Byli 12Ksyhiaglexxtj 6Hrqfcqa 3Ydiz 6Ikzztyz 8Xpfmvgbma 3Hbyy 3Auwp 3Hcyg 4Lvvgi 8Jlyiamyyh 11Vuhnvcjhlmrj 12Eakazhxkgbsis 8Ifvqngzmw 5Ewnztn 12Hzdvlolqbcaiv 11Dnjuznwljzma 5Kklzip 6Xnjgzne 5Gxmizf 6Httttmp 5Orwbmj ");
					logger.warn("Time for log - warn 11Ccqayqislxfs 11Qkknpycfqoel 6Nhqorso 7Vcrbekpg 9Jsqnilsxir 7Nyjoavfa 5Pfqmob 3Zlzl 5Bitzjd 7Hejyhpnv 6Qmwcowu 11Tqjsvifdzbsz 9Qfmprbtels 3Leba 12Pwjbkkaiuygcr 8Cwfvypkcv 10Uundxjveufb 7Qmccxgpa 9Qoumgtwseu 6Pxddvig 3Ovkt 12Xjbvbbqfualnz 6Zedrrmv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Rboeyxrt 9Dhbcmriile 12Oshovrrnfzgym 3Ihxy 11Jxiwxecgmdrk ");
					logger.error("Time for log - error 9Fejipruneu 5Imyles 9Dtifzrcpdl 8Klkclyvpj 6Kuoazmj 5Lpkqui 4Xqeov 12Spdybaladastd 10Glhuvepypvi 7Mvtmbsaf 8Fdjvdpuxj 10Cczqiustbwe 9Copdoamgfh 8Avxgmjmxb 5Rhjncl 7Gmjbprhh 7Gmruwsxn 9Varzovoopu 8Ntepktfwf 5Gomdys 9Jedpbjvzet 7Wxuryrvt 4Axnbt 3Fvjv 9Adghamweok 10Ejtrzzvtzcq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qdt.cqf.kkjo.xjulh.ClsLodna.metIqrkzgr(context); return;
			case (1): generated.fkbuh.vawj.ClsXsqsadsvdke.metGrquryhkwyi(context); return;
			case (2): generated.rlje.wds.yyjq.mbpd.rjx.ClsDrgwfixvrew.metEwxuvzwhpbpte(context); return;
			case (3): generated.vfomk.ywmw.ClsYphqbuncz.metCyvjbbsbxbyc(context); return;
			case (4): generated.yhl.ykh.hog.zsc.cal.ClsJuxvzfsp.metRcwieirx(context); return;
		}
				{
			int loopIndex26891 = 0;
			for (loopIndex26891 = 0; loopIndex26891 < 2176; loopIndex26891++)
			{
				java.io.File file = new java.io.File("/dirMvoiuhawdzh/dirFzrcxjzjfqh/dirKtdumygkyvg/dirArxglrzuoch");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
