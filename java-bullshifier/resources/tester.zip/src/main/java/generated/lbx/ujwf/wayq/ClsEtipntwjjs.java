package generated.lbx.ujwf.wayq;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsEtipntwjjs
{
	 public static final int classId = 118;
	 static final Logger logger = LoggerFactory.getLogger(ClsEtipntwjjs.class);

	public static void metYkgppbepgd(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[11];
		Set<Object> valDlwfevlvcyc = new HashSet<Object>();
		Set<Object> valYjjambpmukg = new HashSet<Object>();
		boolean valScywpdoroqb = false;
		
		valYjjambpmukg.add(valScywpdoroqb);
		long valKzdqezirctl = -921046507206730235L;
		
		valYjjambpmukg.add(valKzdqezirctl);
		
		valDlwfevlvcyc.add(valYjjambpmukg);
		Object[] valHggebdgaobu = new Object[2];
		int valKtmhqgzuwmj = 822;
		
		    valHggebdgaobu[0] = valKtmhqgzuwmj;
		for (int i = 1; i < 2; i++)
		{
		    valHggebdgaobu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valDlwfevlvcyc.add(valHggebdgaobu);
		
		    root[0] = valDlwfevlvcyc;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Jgqia 4Yhcgp 10Asaxjnyudpe 4Gpyfq 7Elfebolb 6Qvyttat 12Vlaslfsbogwlp 12Dgjafmxjsavol 9Lusflfgdwu 3Ruek 7Lgufkhef 5Rdtujg 5Zzwman 9Ecbvadstyl 10Dnvllaxsmla 7Krammjwv 12Vqwkjhhoflrgu 10Ichjbbwltit 12Newrdiuwuefju 7Nixelvce 10Hrayvnkznrj 12Btouzlmskjzay 4Pdctv 4Nvhui 4Fvycl ");
					logger.info("Time for log - info 6Fqyqbky 8Bvtttynhz 6Qemrcva 3Taxi 12Lctxnpiktrcgk 8Voyatvxsr 8Gljxgvbnr 7Nfwdobfb 6Ocrihqn 12Yxzalnnkesedi 10Qqbubpgklby 12Opvwcjgpxdduc 7Luxuiftj 12Zfdroixearzkn 7Biwiwkue 12Dxygjvudgxngk 5Aqlkid 10Fgowsykrxgf 11Cxpmbfopbsjp 5Uruyht 5Ldmxsk 3Bffm 12Czclydduqulxv 11Dfizxnppmsic 5Kizsto 8Gqeztutaq ");
					logger.info("Time for log - info 6Djpoqvg 10Jdwuqsidxgp 6Negdkat ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 7Yoxqmiqa 4Zvrgi 6Vmmjyot 12Vvqhoakggtqig 8Zsilhrzov 10Zvezhogtjue 6Ncowvhi 5Mdsbcz 6Qmcvumz 5Unwpkd 5Niirkr 4Naprm 3Rmph 12Fzqkixoxekrxq 11Tegadrkafqlu 12Xiixizbmgltkn 4Rwiuv 3Qzno 3Cxil 5Mryowf 6Nmlohkc 12Mqzfhyzaecdop 6Vkyeojk 11Dzgxhservpoz 11Rpsnerkwlijd 4Tytfs 4Hjrhf 10Kzatvejkqpi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.mrz.embg.gydr.vls.fvllv.ClsYrxhq.metOlxzxxtvhnzlxg(context); return;
			case (1): generated.kkru.kkr.eff.wedv.ClsTciibuckxmwxc.metZvkldxpumowqam(context); return;
			case (2): generated.oucap.zcbrm.jbhm.yte.ClsEpzgpbjqjhr.metNxbcwnp(context); return;
			case (3): generated.pzq.iab.mjtpw.ClsXnxmjl.metNioiwefosyl(context); return;
			case (4): generated.pzq.iab.mjtpw.ClsXnxmjl.metNioiwefosyl(context); return;
		}
				{
			int loopIndex22153 = 0;
			for (loopIndex22153 = 0; loopIndex22153 < 230; loopIndex22153++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
