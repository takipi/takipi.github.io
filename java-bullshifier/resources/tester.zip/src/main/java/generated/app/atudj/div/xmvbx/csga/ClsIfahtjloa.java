package generated.app.atudj.div.xmvbx.csga;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsIfahtjloa
{
	 public static final int classId = 38;
	 static final Logger logger = LoggerFactory.getLogger(ClsIfahtjloa.class);

	public static void metFzrwltqx(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valBqvrcalyhft = new HashSet<Object>();
		Map<Object, Object> valGsdrhmbkatl = new HashMap();
		long mapValDthbbtahtsf = 5458202948568915020L;
		
		boolean mapKeyWcpmhrkwuin = false;
		
		valGsdrhmbkatl.put("mapValDthbbtahtsf","mapKeyWcpmhrkwuin" );
		String mapValMeuwgpigrlc = "StrXlwhycsvjhy";
		
		boolean mapKeyKowkgtjvcxi = false;
		
		valGsdrhmbkatl.put("mapValMeuwgpigrlc","mapKeyKowkgtjvcxi" );
		
		valBqvrcalyhft.add(valGsdrhmbkatl);
		
		root.add(valBqvrcalyhft);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Klroekkoy 5Fsspoz 6Lpvrkfr 4Novdg 7Vmlvvbmx 11Cmipnstjfzch 3Lwij 7Wepnfzyk 4Gnlyz 12Ucuygtuwrpvyr 8Nuatgcxyc 3Zepb 7Jkryhvbx 7Klsixsmb 12Whynejhfhqvbx 4Zzavy 9Wmaszucjuc 12Llfbcufnvzagn 6Lldabbz 3Ibqs 4Blxfd 10Tmskfurghtx ");
					logger.info("Time for log - info 6Ozktiwj 8Xunpvsefk 4Wtitl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Mautcyq 11Unkxerocfigc ");
					logger.error("Time for log - error 6Xdtdjgk 3Tmyp 11Ykrqjkubiltw 8Sgvciqubs 9Cjwrlvajsl 8Qhjhjcfau 4Nikob 10Tsorjgyiagf 5Jpjuyl 6Liotlce 12Thiecsmbtjqgx 3Odvg 10Haolnsmychr 7Uzemefpk 9Ayoaltjdjx 9Weiitvceaq 4Geggs 10Nngjnxoufom 8Kiucjnagg 6Koiwvds 3Nzdm 10Lykvtwrqtoo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kibd.nddr.nknr.pccz.hryio.ClsBgthm.metFrmpvshfvh(context); return;
			case (1): generated.xmh.glm.nii.qvkag.ClsSkjzsax.metErjcdmeigmr(context); return;
			case (2): generated.vqli.xqs.ist.rcg.ClsUlfrrjkk.metUracnapyxnrd(context); return;
			case (3): generated.ucgs.cys.qrt.ClsGwmfnzjfaj.metAenqjcf(context); return;
			case (4): generated.ulj.ogxe.vbwy.ClsQmshqdjff.metXvyria(context); return;
		}
				{
			long varKmgyniqusxn = (Config.get().getRandom().nextInt(614) + 2);
			if (((8216) % 264293) == 0)
			{
				java.io.File file = new java.io.File("/dirVcobnzivihn/dirMgzlvmezkqt/dirNbjzfipfdag/dirEmpanvltelb/dirGxpnxszqxjv/dirQlmxvxqkjhx/dirGdvjdcebdja");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metSmwloig(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[9];
		Map<Object, Object> valQoqsalerahe = new HashMap();
		Set<Object> mapValCevlykpesdk = new HashSet<Object>();
		long valEyhkaxmrgfk = -2961043005503152885L;
		
		mapValCevlykpesdk.add(valEyhkaxmrgfk);
		boolean valWjreqxbpclf = true;
		
		mapValCevlykpesdk.add(valWjreqxbpclf);
		
		Map<Object, Object> mapKeyQdmmimlhgrp = new HashMap();
		boolean mapValCbkponsfezr = false;
		
		boolean mapKeyOcxnrbleoki = false;
		
		mapKeyQdmmimlhgrp.put("mapValCbkponsfezr","mapKeyOcxnrbleoki" );
		
		valQoqsalerahe.put("mapValCevlykpesdk","mapKeyQdmmimlhgrp" );
		
		    root[0] = valQoqsalerahe;
		for (int i = 1; i < 9; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Sbbgcft 7Fbmndzhm 8Kosusjekm 7Naqacgob 11Jmbxwbffptmi 8Sjncgfmhy 5Hhcflg 12Arnfgcikgwqup 9Pjcpkfuamx 6Zfvsuuw 8Rptnckwim 9Krcaspapfi 5Urnrbv 8Qikltuhyx 9Agwkyxreqd 12Ohretlgccmcni ");
					logger.info("Time for log - info 7Ocsvacgv 8Ldlyhrjgd 11Mtbqzafdfbuo 3Mrtl 9Zfnqarlcyu 6Fkvhvgj 3Irot 7Zqaqleif 8Ajqrsaavd ");
					logger.info("Time for log - info 3Bkxi 5Ajkgah 4Oexbs 11Lssdpncirvyz 7Savlvjid 7Fekmrgsa 12Xgacnjfrrzuqd 4Ckapb 8Ilafvwhbi 8Zdmbtxiha 8Vslutswza 7Uhkerkmt 8Xmlbflwju 12Mesdqcxfbbcyl 5Ujecgl 5Wwmved 7Fodjhvev ");
					logger.info("Time for log - info 5Oxfzkn 4Zgubx 11Rzbiyhuyvghi 6Cviiyom 6Gdqubgb 6Vewufnw 3Ooms 12Vgcasbwjbonvv 9Iictkiheoc 8Egszoabfq 10Axnzoknaroj 4Iyttb 11Irqulpvlkcio 4Njkrr 12Mhfuqwkmrzooh 7Hsylpytr 3Hryi 8Kewudwpae 10Asqvtaktctc 8Xiwpqehrx 5Fwefqt 12Iguyvnkhswjnb 4Egiaq 8Ofibrahie 6Xnemeyx ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Thoawaooz 4Zlmsc ");
					logger.warn("Time for log - warn 7Qamkykac 9Nogaghafgy 12Qqftsqxsndecq 10Mvmdcskzmgc 3Cmvy 8Wvbconnyg 8Dphxckrcx 8Oiypmluaz 3Ycon 5Faqzks 9Evxpfigpfr 11Lpvseledyzip 10Jgyxnshrtcw 10Puzztkrqcfe 7Ywlrxigi ");
					logger.warn("Time for log - warn 3Ctnc 4Vvxta 5Udpwwc 4Jxjsq 10Evvqnuqjrhu 8Igoptxfvy 5Dpjayg 9Smbitxlemd 4Flzdd 11Byrleczqgqlr 8Dfnmykjnv 11Xfghxbvnivcz 7Tbsprsyo ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Ldyrmd 3Lajb 10Llugiumcksi 5Opxpyq 10Txjydfcsdiv 4Jobxg 7Lxxaqigl 6Xgwixls 6Upfmllf ");
					logger.error("Time for log - error 9Renczzirvv 3Ssnd 8Rpdcajzpq 9Conwdrklzi 12Ukinqdxledvyl 8Cdlivdxbu 6Yuaasdp 3Cgwf 9Mhaejvyytk 6Ngpvhns 10Gcowsqhewbb 12Vvnupjhwpgwzr 8Jvujddvpo 8Unmmtjfwy 12Tlqygcxbcdqtz 11Vvkdleociyny 12Gvcobqhvyeflp 8Toifqdmmv 11Rrtyivywpgyx 8Lrtdlopug 10Eyckkvuvfvd 6Rwhkwuo 12Lypxxqdyvfopo 9Csbmfewsyx 7Yrmmlenz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.wmjc.yywge.qivf.ClsNtnaiojgyo.metNewjeyyudocce(context); return;
			case (1): generated.hqq.wtuo.vap.ClsNidilkbt.metWxcpfhso(context); return;
			case (2): generated.cmlwi.ajlk.yhine.aaz.ClsYxnwkcu.metLfnugxqxocfhpv(context); return;
			case (3): generated.lhhp.jdgtq.lkhh.mkg.wzb.ClsZnuut.metLrcocicqjkqlv(context); return;
			case (4): generated.ongb.lkxvg.dfa.pkoz.kbky.ClsZpuulcqafhvqyy.metOzbahhdicun(context); return;
		}
				{
			long whileIndex2682 = 0;
			
			while (whileIndex2682-- > 0)
			{
				java.io.File file = new java.io.File("/dirOzccwjmmwmi/dirYugwyplglpi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metFpyizltbyyrsxc(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Map<Object, Object> valThrsjclcxov = new HashMap();
		Map<Object, Object> mapValIlkqhmkzvzs = new HashMap();
		String mapValRetmrnktqey = "StrNcutnpbgmjh";
		
		String mapKeyEccuthmjvaz = "StrXgfvszxgeei";
		
		mapValIlkqhmkzvzs.put("mapValRetmrnktqey","mapKeyEccuthmjvaz" );
		int mapValDjrzgrhbpwn = 741;
		
		String mapKeyYzyvdnvrtwe = "StrFtkekdljunp";
		
		mapValIlkqhmkzvzs.put("mapValDjrzgrhbpwn","mapKeyYzyvdnvrtwe" );
		
		List<Object> mapKeyVxrphlsepnj = new LinkedList<Object>();
		int valXclxezwrbzx = 681;
		
		mapKeyVxrphlsepnj.add(valXclxezwrbzx);
		
		valThrsjclcxov.put("mapValIlkqhmkzvzs","mapKeyVxrphlsepnj" );
		List<Object> mapValAqrbifezuli = new LinkedList<Object>();
		String valIvehztsvnju = "StrFfwftlggnrc";
		
		mapValAqrbifezuli.add(valIvehztsvnju);
		int valHrsagnpanlb = 360;
		
		mapValAqrbifezuli.add(valHrsagnpanlb);
		
		Set<Object> mapKeyGcmegjrosdz = new HashSet<Object>();
		long valSffhmwmxkwa = 4559657240092856849L;
		
		mapKeyGcmegjrosdz.add(valSffhmwmxkwa);
		long valQnvgcearxhy = -3235624755868642452L;
		
		mapKeyGcmegjrosdz.add(valQnvgcearxhy);
		
		valThrsjclcxov.put("mapValAqrbifezuli","mapKeyGcmegjrosdz" );
		
		root.add(valThrsjclcxov);
		Map<Object, Object> valYregnjaqbyd = new HashMap();
		Set<Object> mapValPjulzwthpex = new HashSet<Object>();
		int valOvmtbuzkhdz = 783;
		
		mapValPjulzwthpex.add(valOvmtbuzkhdz);
		
		Object[] mapKeyKhfimsexkhr = new Object[2];
		boolean valMhtpfgrgnlb = true;
		
		    mapKeyKhfimsexkhr[0] = valMhtpfgrgnlb;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyKhfimsexkhr[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valYregnjaqbyd.put("mapValPjulzwthpex","mapKeyKhfimsexkhr" );
		Map<Object, Object> mapValTpliwgnhmvj = new HashMap();
		int mapValNknspdrnvhl = 908;
		
		long mapKeyUaedyrelqfn = -6676922198944047391L;
		
		mapValTpliwgnhmvj.put("mapValNknspdrnvhl","mapKeyUaedyrelqfn" );
		boolean mapValZworzjwxzxf = true;
		
		boolean mapKeyIqcipthangg = true;
		
		mapValTpliwgnhmvj.put("mapValZworzjwxzxf","mapKeyIqcipthangg" );
		
		Map<Object, Object> mapKeyHliyevoobdo = new HashMap();
		int mapValEsytrtohoji = 600;
		
		long mapKeyFbzziyohxvr = 1663639964206140918L;
		
		mapKeyHliyevoobdo.put("mapValEsytrtohoji","mapKeyFbzziyohxvr" );
		
		valYregnjaqbyd.put("mapValTpliwgnhmvj","mapKeyHliyevoobdo" );
		
		root.add(valYregnjaqbyd);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Qfdeslnpugtip 3Mmwh 10Dmsgukjblza 12Lmvjsfgqoksfi 6Mkggoqg 3Egxs 7Rvksjojl 8Dpkugonyr 12Fnvmjszjyjxtj 10Mpzqxymoyaa 7Qhyjrzlt 12Zldybegzuaher 4Tpwyq 12Ydkibphynandp 10Xroauxcchhb 3Psng 9Wztfqbiowz 9Ttjqagxuxv 4Royam 10Iyfemquijeq 12Xbvgeabufquid 9Vgdyvnlicp 12Kcggkjmxktrbe 10Akfivtvrhte 7Qnulitil ");
					logger.info("Time for log - info 5Ctcfkm 9Zzabzocxvi 6Kjldetz 6Nazmbbd 8Mfouckooi 5Auidkq 11Ffrzbzgssqlu 10Fsnpbdvfdto 9Medmbzscml 12Iuiiousdbqhhy 9Zmynzrlawn 6Kgblqvs 8Wnpftwbmb ");
					logger.info("Time for log - info 8Nkabbpbew 11Garxveioevab 4Ieiou 6Uvhvyuu 8Tbyiacdac 7Nspdfgkj 11Glicfalwemhl 9Dqcaumvezl 3Jtfn 10Mkobtofkiyi 8Utoslgwhi 3Utbm 4Uhwmy 12Wkorhgtufuezi 10Cgtvhlvicwt 6Lldvldt 7Cqrxlswm 4Wswca 8Yzdqlzcvk 10Gymmfealzfu 6Klmeewb ");
					logger.info("Time for log - info 10Bxflmophszo 7Gytqiajm 5Ymwtla 3Iciu 7Kglsklbi 12Vmmjttczumvuk 11Dwenecsymuju 11Llvvbjcjbyvg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Bgqn 8Ybbhzcdhb 11Rdajwetxjjwp 12Rwmmxgdmknzdh 9Tftmdzfwht 10Kgzynhuxojh 9Syrianlqzg 7Dugozreu 3Dniw 12Lhcbjnidxqiqe 5Qiauoa 8Ztidrqkso 8Yrapmbjva 10Vuaumnngvfm 10Jjeqmowhexy 12Xgqthcveflkmt 12Gingftkyvxaoa 3Chsx 7Upqwfmyu 9Htyyriilpz 3Mvcb ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.bjkl.rwmim.scbu.axq.ClsFteiawx.metUpikxxqrqxf(context); return;
			case (1): generated.gcr.qqx.juuh.caxx.ClsRlelgjq.metJcvcwuus(context); return;
			case (2): generated.fkhk.aid.ztzxu.ClsQjlasdqvzflfd.metCcnwvtmpiltc(context); return;
			case (3): generated.mrfat.adk.zch.ClsYwqlnetu.metCadvvicigiy(context); return;
			case (4): generated.rjuw.mmbua.ClsRawvqxmhewbl.metBvnihykij(context); return;
		}
				{
			long varMxbqxxiubmx = (Config.get().getRandom().nextInt(273) + 6);
		}
	}


	public static void metRugafatcqgy(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		List<Object> valHbgeqpnzizo = new LinkedList<Object>();
		Set<Object> valOgsosdsihla = new HashSet<Object>();
		int valFwoimznixly = 827;
		
		valOgsosdsihla.add(valFwoimznixly);
		
		valHbgeqpnzizo.add(valOgsosdsihla);
		
		root.add(valHbgeqpnzizo);
		Object[] valRebjgtevawq = new Object[5];
		Set<Object> valAfaoeuzsjyz = new HashSet<Object>();
		String valPsyawtpxscc = "StrClbigsfbqdj";
		
		valAfaoeuzsjyz.add(valPsyawtpxscc);
		boolean valEjdippdhdsh = false;
		
		valAfaoeuzsjyz.add(valEjdippdhdsh);
		
		    valRebjgtevawq[0] = valAfaoeuzsjyz;
		for (int i = 1; i < 5; i++)
		{
		    valRebjgtevawq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valRebjgtevawq);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Wqckv 6Howolyn 11Kgzonkcgzjgl 8Eyzoypfxl 11Zxrikaqssnyo 7Pcbltstp 10Wmzkxxnnyvn 10Eknlhbawbwy 8Plrsomvyz 8Wrnrjbajg ");
					logger.info("Time for log - info 10Sjvqvcbergb 7Tjqpawrf 9Rtbbttzdzi 5Yvfgxj 8Xirnahgbb 3Upmh 4Wqfim 9Hksbwepuck 7Phdfdzti 11Cchejeujgyos 9Erkvgiafty 12Njhnxoigfdwyn 3Cwqm 11Kmojelvvcwid 11Xshmmqmlmktn 6Gfybrnm 3Soej 7Shdgakzt 6Emaabha 8Zhpibvcdw 9Ciufqlxblj 12Fbqsjvdkoudse 8Usjevyvyx 5Mchseq 10Oqysigecjhf 8Zacvfqmzf 4Esrjw 11Zohpucvhgrvy ");
					logger.info("Time for log - info 5Ifzciv 10Bvsotlsspwd 12Emnjippewissi 11Uyvcrkghtdkj 5Bxpuhl 7Yroslkte 5Muhgbx 9Pectzorxhs 8Bofcciqrv 11Bhhpyvqvumzs 11Coadzvvnfaqk 6Xzccivr 6Qxvszga 5Doevuc 11Vcjjalhwlkjv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Bsysqpent 8Nfdhwbjuc 12Tmnfysnjqslxa 5Jridxh 5Tcarlk 8Eqjarpunn 8Gohrulgvd 4Advky 10Utfqftckkuj 3Ufaw 3Pwkg 8Rbujjbnvv 12Mjmhdhvwfwqls 8Lruxgybsv 6Mrjaris 12Gloikbzhsptzt 6Jegcsxj 11Gswyjcfxxwke 9Vfzyvepvof 5Mxjrfr 7Pnoflrlg 4Noguy 11Lzmqfppimcxm 7Ioaxgodg 6Ervcswu 7Plkctlhm 6Jetrkpm 5Kczymb 11Bsucjtwhnjem 12Jgxwvwbyvmizy 3Ghdk ");
					logger.warn("Time for log - warn 9Vgktzvfusv 3Ujqy 3Ndmi 3Neap 3Clye ");
					logger.warn("Time for log - warn 6Yrttjmv 3Ygqe 10Cpjhrmqrbop 4Zdkqq 3Mkur 10Rlzvblbakcs 12Rlwyabwrbbpio 4Frvhb 9Yjbprnuhar 8Fkqivoyap 10Ecayxmhryza 12Cdeomembjinqa 12Didrifkatxfgq 9Tnppsgzqqh 9Xljqvfjtaj 10Wjxncaefwhm 5Ovgixc 11Hzxhdwuvciej 3Tlcs ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Buoqwv 7Qivqjggq 3Wjrq 3Frke 7Xaljybqz 8Gcfyjiwtv 12Hrygqagrllzcv 6Hdyyolx 5Zgohli 9Ozatvxqsqe 5Wmszxh 11Dihvkdpeqqld 11Olpigxrlfyws 11Nrhotmcxqxho 3Gtdp 7Sfpeoacr 3Hanx 9Jibaiejgve 9Zgzyrdmhjt 5Vcvfvh 12Weznrdnbneovb 6Pnwzjuj 3Spsv 8Xdkpxzkol 3Ekcq 6Tjctjea 3Wolx 8Zhsoldydd 5Xfdlxq ");
					logger.error("Time for log - error 11Selsgwsvpgkm 11Xuwgxvzgxexd 9Wdekhooxhw 11Ljyonrwixdzx 11Aiqjrljumxlp 4Oehag 8Tfvkywnlj 4Booyn 10Rdulgragvwz 7Jgyrgxfk 7Rnrtgvge 12Eltfiaerlujjs 6Slueykh 9Mqqpsifdgb 7Ztnuhplz ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qjqzm.vzrn.zbzow.ClsDltypnpb.metUfpufoucpqucye(context); return;
			case (1): generated.lfkk.ncy.gpf.ClsMafxzncfnwvsdj.metSxjirq(context); return;
			case (2): generated.wtc.bgb.gahv.mul.rts.ClsUeuxdzs.metPhxms(context); return;
			case (3): generated.zuj.yzx.nga.pvup.ClsJyskqhfglgbk.metUwrvr(context); return;
			case (4): generated.awuu.yuf.ClsCvioceqcbkiz.metCmrtwohtptwpox(context); return;
		}
				{
			if (((6002) % 728860) == 0)
			{
				try
				{
					Integer.parseInt("numFdvvznpgorp");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((Config.get().getRandom().nextInt(227) + 5) % 473900) == 0)
			{
				java.io.File file = new java.io.File("/dirDzxngnvgpsj/dirNremohnolal");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numZenurcbdgyu");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex2689 = 0;
			
			while (whileIndex2689-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metYzbiexwszx(Context context) throws Exception
	{
				int methodId = 4;
		List<Object> root = new LinkedList<Object>();
		List<Object> valFkjymnxsrep = new LinkedList<Object>();
		Map<Object, Object> valGadooqmisww = new HashMap();
		long mapValYuowjogblre = -511845938907041374L;
		
		boolean mapKeyYdvjwffcfwj = false;
		
		valGadooqmisww.put("mapValYuowjogblre","mapKeyYdvjwffcfwj" );
		
		valFkjymnxsrep.add(valGadooqmisww);
		Set<Object> valSozxvmspwaz = new HashSet<Object>();
		String valKwskcxvvsnl = "StrBthjzszaebq";
		
		valSozxvmspwaz.add(valKwskcxvvsnl);
		
		valFkjymnxsrep.add(valSozxvmspwaz);
		
		root.add(valFkjymnxsrep);
		Object[] valKcjrbgpdtdv = new Object[5];
		List<Object> valHvrewuozqut = new LinkedList<Object>();
		boolean valSjrgrwgwmfz = false;
		
		valHvrewuozqut.add(valSjrgrwgwmfz);
		int valPzyvzgfskdn = 809;
		
		valHvrewuozqut.add(valPzyvzgfskdn);
		
		    valKcjrbgpdtdv[0] = valHvrewuozqut;
		for (int i = 1; i < 5; i++)
		{
		    valKcjrbgpdtdv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valKcjrbgpdtdv);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Lius 4Sgvjm 7Kqhlwtqi 11Reejojlkbfwb 5Mlsvft 11Vnqivkkokrkr 12Qielbierdyjgv 10Fxeyirgiovv 10Dtnsvbcvxuc 3Gqvd 6Xsrvevn 12Twjzpfzhvymhs 11Uzsusjwvyxza 9Psheqawkrv 4Clzoj 3Loim 6Yfmndti 5Fvpmrq 7Nyjxvbyp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Kmwqpf 11Hqjizlmebxlm 5Twfslg 9Wxczjaqxgh 6Izvwxpl 5Eszjxq 12Obuvukumntcpi 11Oaybpiananwy 10Gwdiduymmgh 8Lcttjyxnl 7Aihhnmgy ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.olnh.vng.ClsLcraqevyogmja.metHrpnbihsknjv(context); return;
			case (1): generated.hehz.xzg.akn.rdsvf.ClsKsukcv.metYviizisnunbnph(context); return;
			case (2): generated.mao.kidk.mlsjr.hew.xst.ClsEfomkejxcxzr.metEruurpx(context); return;
			case (3): generated.qyalc.lus.ClsKvouelboluo.metVctwjruk(context); return;
			case (4): generated.ongb.lkxvg.dfa.pkoz.kbky.ClsZpuulcqafhvqyy.metSvcpwlc(context); return;
		}
				{
			try
			{
				java.io.File file = new java.io.File("/");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex2701)
			{
			}
			
			long whileIndex2698 = 0;
			
			while (whileIndex2698-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
