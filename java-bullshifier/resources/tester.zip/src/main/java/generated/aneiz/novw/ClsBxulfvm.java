package generated.aneiz.novw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBxulfvm
{
	 public static final int classId = 258;
	 static final Logger logger = LoggerFactory.getLogger(ClsBxulfvm.class);

	public static void metBsngloxbviwqyh(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Object[] mapValPwacmpkhcbz = new Object[9];
		List<Object> valLsioczkuejl = new LinkedList<Object>();
		long valZfcsoudxrzc = -5124004628433953541L;
		
		valLsioczkuejl.add(valZfcsoudxrzc);
		int valFjawitsmoqz = 539;
		
		valLsioczkuejl.add(valFjawitsmoqz);
		
		    mapValPwacmpkhcbz[0] = valLsioczkuejl;
		for (int i = 1; i < 9; i++)
		{
		    mapValPwacmpkhcbz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyFccdzdhbbqf = new LinkedList<Object>();
		Object[] valNlhbvohaxud = new Object[10];
		long valTcgsuqtubef = 8586199791695354130L;
		
		    valNlhbvohaxud[0] = valTcgsuqtubef;
		for (int i = 1; i < 10; i++)
		{
		    valNlhbvohaxud[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyFccdzdhbbqf.add(valNlhbvohaxud);
		Map<Object, Object> valLiwkwfnxtwr = new HashMap();
		String mapValRhjylwabbad = "StrMyecayfvtmq";
		
		boolean mapKeyTobyeufgxzz = false;
		
		valLiwkwfnxtwr.put("mapValRhjylwabbad","mapKeyTobyeufgxzz" );
		long mapValMgunqqktibg = -4817809310208708188L;
		
		boolean mapKeyQsudipxjfqu = false;
		
		valLiwkwfnxtwr.put("mapValMgunqqktibg","mapKeyQsudipxjfqu" );
		
		mapKeyFccdzdhbbqf.add(valLiwkwfnxtwr);
		
		root.put("mapValPwacmpkhcbz","mapKeyFccdzdhbbqf" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Pzalswvpvi 7Zjmvisph 11Lcntfayvlbcd 10Msfuzwtyckx 11Zbqkqfwfvzqw 7Wsfwjhjj 7Njxmctnx 8Zrktpwaxz 7Huurznwo 9Alycrsnulb 12Fhwtmtrjmqkrx 3Akcw 8Uwrxtwsmr 8Elvxgxoqn 3Twzw 8Olomhctxq 7Doajgfvt 12Ixubwhtincwnh 6Ikdybcb 3Fveh 3Slzz 12Ezpfzdbaxgpjl 5Wwtoal 11Zvkeiftsobqt ");
					logger.info("Time for log - info 4Xywia 7Yyuqykqb 4Jxslq ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Hkygmy 4Hfknk 10Jrdsaabhrql 4Fiqgm 8Yzstwmnkd 9Zfsdyygpdf 12Zctuyfgvbfxab 6Zvnaool 5Rahusq 12Noskpwfpxiaie 8Evyfeprjr 10Mregraiwpmw 3Efaf 8Zvpwzjhyo 3Gomg 12Aplwiusqcvoih 5Eougas 4Icxrp 10Raopwyytfux 10Jciidbwcifb 8Bbyuevqez 4Lhbdz 3Jdvl 12Mtfvofiwkcstl 7Mtlahizw 7Cgxoohjo 3Lhka 5Smvmgd 6Pytbsve ");
					logger.warn("Time for log - warn 3Xgso 10Yavxtblqgar 4Bmomz 5Hhibuh 5Nhlund 5Buuzuf 11Ckmyboqxqzmv 12Kxvwukugstots 11Msoubilmqnhj 5Tszacj 5Lsabjr 3Amwr 8Rcowirttx 9Zkrfmeiaju 9Vtpdxrlzlg 10Brkevdorksd 6Gwtljxk 11Xnymmbwkquqp 11Cmdrmwmainve 5Dezevp ");
					logger.warn("Time for log - warn 8Wnokhkltq 9Klboawwtev 8Owqhoreuo 3Qwmz 12Dsvbhrbafgwrk 12Oyefyiuexowym 7Onbfnrgy 3Blte 9Wvoqivutwv 9Fnmftclueg 8Zmswbgcrx 5Qkiuiv 7Jozepvay 11Oahxlgckgnmm 12Fotwdxprorpig 11Agbecoitexkh 3Vksy 10Dzhmvnftilb 9Omtesxuywu 10Dxtzlbdegns 5Lujebw 4Ovbem ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 7Fbteboza 6Kfhuker 7Snwuvswn 11Okwmgxjiidww 12Ubstfslhkbona 4Lahkx 6Vwcvvsj 8Rwdwfhxvf ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lvnhk.isns.uksl.tjjfx.ClsEfuazouhb.metZyecchsshso(context); return;
			case (1): generated.eyfa.ouw.cbeis.ClsNevyjjntax.metQvyozodgmv(context); return;
			case (2): generated.kibd.nddr.nknr.pccz.hryio.ClsBgthm.metFrmpvshfvh(context); return;
			case (3): generated.oue.dqjq.ClsSjudu.metTjdrwpi(context); return;
			case (4): generated.ghn.esb.odxb.wtax.ClsJgsbwdqv.metPazubjuncrdr(context); return;
		}
				{
			long varOxhzgcqrgpe = (Config.get().getRandom().nextInt(501) + 5);
		}
	}


	public static void metSgvcxn(Context context) throws Exception
	{
				int methodId = 1;
		Object[] root = new Object[5];
		List<Object> valGleskwdbvsm = new LinkedList<Object>();
		List<Object> valJufjsrfefwg = new LinkedList<Object>();
		long valCylrbgxlmun = 8391516621931326917L;
		
		valJufjsrfefwg.add(valCylrbgxlmun);
		String valJyyfxrunrxv = "StrIbpigtenweg";
		
		valJufjsrfefwg.add(valJyyfxrunrxv);
		
		valGleskwdbvsm.add(valJufjsrfefwg);
		
		    root[0] = valGleskwdbvsm;
		for (int i = 1; i < 5; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Aegxfaz 3Lrzk 10Suldiwwjtfa 12Rhozvbldcgxqh 3Yhgs 7Qmvhdibi 7Jrcgmgsf 8Xrisnchrj 3Gexw 3Jnfs 12Agnmebdugeqci 7Utqpekmc 4Lnyqm 9Qobmcujriv 11Hedtqmksntcg 4Lpcjf 9Kddsgicxjm ");
					logger.info("Time for log - info 6Cxwuwol 10Nykqulekeem 9Qtrsfaixbo 8Nzqvxdppx 11Icojuawrtzqh 11Lgjockemwbje 4Dreeb 6Qcauurz 7Whkcjifh 8Yjfpfufmt 8Fymvfwzmj 8Jjskdbxjh 5Pbeguo 7Aksnwcdu 8Dkthmuifx 4Fxsxv 8Oewpzqtal 12Rdukzkqesfzjz 7Annlteon 9Anijezffbm 4Peeup 11Zwjjcqhcupco 12Ryfhbfgdenycp ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Joxznjgsv 5Zltsdt 5Iyxbnb 8Ezdzmtqfo 6Wynogle 4Ctslm 3Nhqc 5Acvniy 8Pvhesdgci 7Gfuattlu 7Bzibwigp 4Aweut 6Geiustq 3Vmst 10Yiwwkftfuik 7Zqynwybz 5Umsbgw 4Xaumx 8Rvasqjeen 6Qvadkhh 8Rejbokaem 11Zaissbgdlxnh 4Rmamt 9Nxpdnmgcbi 11Wngajaxoczzl 12Lbtilvreqzhfx 8Emdpvtkcr 5Bqfffw ");
					logger.warn("Time for log - warn 9Uxsbntxbad 4Zauwc 4Btxpv 8Evjkccyns 3Ysuc 6Begiuuf 8Bugldvlwp 11Yrwshbqrrbwk 5Filwzd 4Wafnb 9Aasnkzmhfm 8Ghdcivmzh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Csyeo 12Xfwvmcdavzvcj 7Uenliatt 4Kjaud 8Yvcysubpn 3Gioe 10Pznwjpkqshc 6Fmktymm 5Aldvul 12Rgptspflhdzvt 10Xokpqdrirzl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lxrj.lts.csk.iew.ClsCagmzsja.metOondcg(context); return;
			case (1): generated.budq.anwwr.qie.tcx.ClsAvdrojvr.metCbwya(context); return;
			case (2): generated.cwxj.lmfzj.egfdm.ClsTwbdwdairow.metHhffvvxhy(context); return;
			case (3): generated.avpz.xulx.yey.mrdy.ery.ClsVwwfgnwmvvmf.metFklslbzkstpawh(context); return;
			case (4): generated.rjuw.mmbua.ClsRawvqxmhewbl.metOsciin(context); return;
		}
				{
			long varBdzqtkdvxdd = (1064) + (Config.get().getRandom().nextInt(970) + 7);
			long varFpwryemxygl = (Config.get().getRandom().nextInt(119) + 3) + (Config.get().getRandom().nextInt(243) + 1);
		}
	}

}
