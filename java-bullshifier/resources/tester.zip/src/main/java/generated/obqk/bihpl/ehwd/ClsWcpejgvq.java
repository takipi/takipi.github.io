package generated.obqk.bihpl.ehwd;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsWcpejgvq
{
	 public static final int classId = 289;
	 static final Logger logger = LoggerFactory.getLogger(ClsWcpejgvq.class);

	public static void metUrpeeajbj(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValCpqoxujlwoa = new HashMap();
		Set<Object> mapValPcevcgivyeh = new HashSet<Object>();
		int valRmdvqmnshsv = 153;
		
		mapValPcevcgivyeh.add(valRmdvqmnshsv);
		int valOisdgeqtygk = 669;
		
		mapValPcevcgivyeh.add(valOisdgeqtygk);
		
		Set<Object> mapKeyUawwummakem = new HashSet<Object>();
		String valTploxfmvtuj = "StrVsuelbtviob";
		
		mapKeyUawwummakem.add(valTploxfmvtuj);
		
		mapValCpqoxujlwoa.put("mapValPcevcgivyeh","mapKeyUawwummakem" );
		Map<Object, Object> mapValGelilhqmiuh = new HashMap();
		int mapValMbtdpukhbhy = 195;
		
		int mapKeyFrdilwrteyr = 691;
		
		mapValGelilhqmiuh.put("mapValMbtdpukhbhy","mapKeyFrdilwrteyr" );
		
		Object[] mapKeySndlzbiyqds = new Object[6];
		long valKdxjkowuegb = 3161949891287500175L;
		
		    mapKeySndlzbiyqds[0] = valKdxjkowuegb;
		for (int i = 1; i < 6; i++)
		{
		    mapKeySndlzbiyqds[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValCpqoxujlwoa.put("mapValGelilhqmiuh","mapKeySndlzbiyqds" );
		
		Object[] mapKeyMhmrcquanho = new Object[6];
		Set<Object> valYrxswmckyqq = new HashSet<Object>();
		int valBeidxehczzl = 719;
		
		valYrxswmckyqq.add(valBeidxehczzl);
		boolean valQsyvovjihmj = false;
		
		valYrxswmckyqq.add(valQsyvovjihmj);
		
		    mapKeyMhmrcquanho[0] = valYrxswmckyqq;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyMhmrcquanho[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValCpqoxujlwoa","mapKeyMhmrcquanho" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Wfvakmjqfcj 8Lxkmniqeh 4Bfdzs 10Skxlvnqriwn 7Lnvdottz 5Hgcmzl 3Qwwg 8Vnlzxyoet 6Feuobsx 12Llidqymioaftj 7Cfozyika 3Ulua 5Crcbdn 6Ecohcmz 8Bsvgmdrks ");
					logger.info("Time for log - info 5Udvrtc 5Okxiau 5Kqtjyd 9Edkethpqom 7Ctwepknl 4Csshs 10Vunzroftrhb 6Booqibm 6Jlwduig 4Uvpmh 12Oqxeyxctqvchi 3Sdnk 3Phgi ");
					logger.info("Time for log - info 10Gpccbotrmpf 4Cjvlc 4Iufdd 4Cjvkp 5Udatzm 8Tvsmxevuq 6Kmiabdy 12Koiguqggnxiyb 9Pxyiiheljy 5Qdsmtu 7Eemqsoxu 8Fgquobxdq 7Khkaftam ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Hvql 8Ltqtzqrmx 7Ugrqxvue 3Gbzj 9Kkdfxtkdnv 12Endgkvpaqonra 6Aiwkdvr 11Yqraprqttrwn 8Jrpdkdyar 8Bygtrucgt 9Buagukomjk 9Oeupkjszfy 7Opnwucuf 5Uxvizm 6Willigd 8Ctdpxysdx 11Qitfetqjtxyb 6Kimibjs ");
					logger.warn("Time for log - warn 8Zrkverifp 10Gsbgcectlia 10Cpplnlowgha 5Srnbum 9Trfbmjasef ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Ktwjwjurnnmqx 4Qjtyv 3Gjqo 6Oteywxa 9Uqepziakgo 8Ejxsnsrcs 6Reknomd 5Owfzkc 3Gsut 7Xkggfplh ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.xhxl.owx.ClsJgljylyqsyfqzr.metGtdhlptpf(context); return;
			case (1): generated.kcrh.cmo.yws.ClsBlekldezyl.metOblagvlrzevtay(context); return;
			case (2): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metTlqjnsfger(context); return;
			case (3): generated.fflc.jdncn.ClsHubvnnx.metSnkfjhjtib(context); return;
			case (4): generated.wzc.atz.bifi.ClsLhmqhmqzzzccj.metTthfpespngis(context); return;
		}
				{
			if (((5834) % 488765) == 0)
			{
				java.io.File file = new java.io.File("/dirWnwetdgdgcl/dirYubcerobear/dirMhbnnqozwue/dirEpgbuhorecf/dirYxwqrifpkwx/dirKzwexbylnwb/dirPksdkowstkt/dirOkqgyewpdtj");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((3900) + (501) % 116186) == 0)
			{
				try
				{
					Integer.parseInt("numHmnmgiginbs");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
