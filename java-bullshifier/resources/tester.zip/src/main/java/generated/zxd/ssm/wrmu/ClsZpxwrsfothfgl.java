package generated.zxd.ssm.wrmu;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsZpxwrsfothfgl
{
	 public static final int classId = 285;
	 static final Logger logger = LoggerFactory.getLogger(ClsZpxwrsfothfgl.class);

	public static void metAomskmmjub(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Object[] valHcgxrnxtcuc = new Object[9];
		Set<Object> valFmnunooepth = new HashSet<Object>();
		boolean valMrsngopjmpu = true;
		
		valFmnunooepth.add(valMrsngopjmpu);
		
		    valHcgxrnxtcuc[0] = valFmnunooepth;
		for (int i = 1; i < 9; i++)
		{
		    valHcgxrnxtcuc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valHcgxrnxtcuc);
		Object[] valKtfvkzxbgno = new Object[10];
		Object[] valQfzvcjwhqiz = new Object[11];
		boolean valCiqsghuzitj = false;
		
		    valQfzvcjwhqiz[0] = valCiqsghuzitj;
		for (int i = 1; i < 11; i++)
		{
		    valQfzvcjwhqiz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valKtfvkzxbgno[0] = valQfzvcjwhqiz;
		for (int i = 1; i < 10; i++)
		{
		    valKtfvkzxbgno[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valKtfvkzxbgno);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Zgebong 5Uevxlv 6Vokxpdc 9Mzbdnxslwp 3Snvy 5Jwxyof 9Vpnzpleqph 3Lyzk 3Nfmm 7Dnxyzzse 7Owxsokxa 4Ybbjq 12Vtrzhsxfbnkbt 9Zumgypykdj 4Zpupc ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 10Rjvrhjlkjtg 11Xihiqrdauwxu 9Zrugzfvarx 10Pkbokpbhvyj 4Cbnal 11Zeiecyblauln 11Cafqxhqzyxzt ");
					logger.error("Time for log - error 10Inxqtfptcai 6Guvrpjy 7Tgtewgeq 12Ctprplzgktccg 10Ujzdjtnafsr 6Fdbvyhf 12Lweyqccqbruxu 8Tkfdhbiis 10Bjpgylekbuo 11Vxfdylqriqsf 9Hpkrxrvydf 7Ymvniwpq 4Vhlhd 5Pdxlxt 5Tnnsab 7Eqwggzmn 3Jrpi 8Bmobkmecs 5Tntybj 10Jusaryxdopb 8Yfzhnflpn 10Eogdqrchjgi ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qdml.hmlho.ClsQuiharvpvfv.metXrurj(context); return;
			case (1): generated.ktb.gfwx.clp.ClsOhfjxpce.metBhcnwfttekmyi(context); return;
			case (2): generated.xqg.mgvc.ecibz.ffs.ClsNwqoa.metLcfufswjvofrzb(context); return;
			case (3): generated.ocg.pnhd.assci.ClsEkxxqpavkqxkay.metDpnizequfd(context); return;
			case (4): generated.yvh.anu.xzpk.kfbih.ClsLfieczuv.metNoxbcgcr(context); return;
		}
				{
			int loopIndex24920 = 0;
			for (loopIndex24920 = 0; loopIndex24920 < 7768; loopIndex24920++)
			{
				try
				{
					Integer.parseInt("numZaztqxeyvhw");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long varVavvnpizems = (8368);
			varVavvnpizems = (Config.get().getRandom().nextInt(905) + 4);
		}
	}

}
