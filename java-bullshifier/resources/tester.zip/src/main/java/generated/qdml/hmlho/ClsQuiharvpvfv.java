package generated.qdml.hmlho;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsQuiharvpvfv
{
	 public static final int classId = 197;
	 static final Logger logger = LoggerFactory.getLogger(ClsQuiharvpvfv.class);

	public static void metXrurj(Context context) throws Exception
	{
				int methodId = 0;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValEnykcrngcov = new HashSet<Object>();
		Object[] valVbrbthyowci = new Object[7];
		boolean valUiskhfgpyvb = true;
		
		    valVbrbthyowci[0] = valUiskhfgpyvb;
		for (int i = 1; i < 7; i++)
		{
		    valVbrbthyowci[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValEnykcrngcov.add(valVbrbthyowci);
		
		Map<Object, Object> mapKeyYrhmydhqnlt = new HashMap();
		Map<Object, Object> mapValNffrvsfxtfm = new HashMap();
		String mapValAxjgkpzvxbx = "StrJxtrkabpdab";
		
		String mapKeyTdotbncmmlk = "StrYylaizbqtth";
		
		mapValNffrvsfxtfm.put("mapValAxjgkpzvxbx","mapKeyTdotbncmmlk" );
		boolean mapValHoqagoudmzz = true;
		
		boolean mapKeyQzevujzqvcq = false;
		
		mapValNffrvsfxtfm.put("mapValHoqagoudmzz","mapKeyQzevujzqvcq" );
		
		Object[] mapKeyKdfxhqseqys = new Object[10];
		int valBpdxnezoefi = 172;
		
		    mapKeyKdfxhqseqys[0] = valBpdxnezoefi;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyKdfxhqseqys[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapKeyYrhmydhqnlt.put("mapValNffrvsfxtfm","mapKeyKdfxhqseqys" );
		List<Object> mapValZajxpaqequv = new LinkedList<Object>();
		int valVlssxmqjbwy = 57;
		
		mapValZajxpaqequv.add(valVlssxmqjbwy);
		
		Map<Object, Object> mapKeySadtpismaoj = new HashMap();
		String mapValCbplovcgwgg = "StrXxfutocongi";
		
		String mapKeyUryqiuzggfp = "StrSsqayyzzoem";
		
		mapKeySadtpismaoj.put("mapValCbplovcgwgg","mapKeyUryqiuzggfp" );
		String mapValNpmcwzlzdiu = "StrYlewcvvxust";
		
		long mapKeyVgdwpssssvn = -5690428446476757568L;
		
		mapKeySadtpismaoj.put("mapValNpmcwzlzdiu","mapKeyVgdwpssssvn" );
		
		mapKeyYrhmydhqnlt.put("mapValZajxpaqequv","mapKeySadtpismaoj" );
		
		root.put("mapValEnykcrngcov","mapKeyYrhmydhqnlt" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Aovgxdsvxi 3Cyye 12Metxwoeaembdz 3Type 10Fopuqanddge 8Aldcfcqkc 6Vfqoonm 3Wzvd 12Gblnepmlbzcuq 5Cgrouz 11Jiveekvgoean 5Lsdyzr 10Xuccsxebqws 7Qtnnnpxp 9Filplvulao 5Psukxi 9Dazqlgzgak 9Bmqrjhvsux 3Rews 4Okmpa ");
					logger.info("Time for log - info 6Uamxqpj 5Tpzmdb 9Wrigeciyly 12Easgsqczusthg 7Ydluwxby 10Cibcnqrpddx 4Iunqm 3Riag 10Bkemnuxxilc 11Nswgzvvyxwto 12Hjyhvwzvwjwlr 7Boncuzwj 5Mbhxhz 4Cgkyh 4Gekdp 3Swqm 8Idsvhmsix 10Yyvhtxgxxub 7Hpunxdlh 7Mrcxzbkb 12Qtuktalgruwlv 7Hrtiznok 4Hkgvr 12Repmezzmjswko 8Vcmhpngzw ");
					logger.info("Time for log - info 12Mmuepneilvmbd 9Elhplxvvpa 3Lwzv 10Kvhmwyimaei 7Qfpakaau 8Zugowqgul 11Ouepxqzqhubc 4Uyxxb 5Qsxhwj 11Evdsuhpsacjd 4Bwero 12Ykpvhdmzextiw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 5Epimbm 4Lbzvt 7Lrhpwltq 11Nqxnldincace ");
					logger.warn("Time for log - warn 11Xtzhwhgxwgzm 11Mjfpbwkfirla 12Lqqummjqsddne 12Btiqfqodgkyzc 8Fyrgvotfp 12Sshaetwajrgzm 4Srjjz 7Dfbvhnyt 5Kqsewd ");
					logger.warn("Time for log - warn 12Qwtpfxjiujbdt 3Ifjj 10Novltkqriwz 12Zhrdtfscutuzc 12Zhphdclodwavb 4Aznho 7Xizctsjr 3Lzkx 5Wshqqw 5Azcvep 9Ibqukoqhjz 10Zxyswhqczma 11Pwxykdopvyfq 3Bcaq 11Hoguzytlfaba 12Vyzzfbmhgenfy 7Edzjuwxv 7Omkenmbp 4Syvhp 11Clxcwhxbsswa 9Nzpoufeutl 5Zxkmrl ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hadv.dozj.puo.ClsVowitvkgtx.metQjsinz(context); return;
			case (1): generated.tmb.nbu.txg.feeq.pmbxg.ClsRpabqs.metDstlswqrnqo(context); return;
			case (2): generated.hfhsc.dtsm.exj.akcxm.ClsEggbq.metGkdrqysenzt(context); return;
			case (3): generated.zfv.ypwo.wuncq.ClsFveqnpanl.metApyyqiuohqp(context); return;
			case (4): generated.npa.tuyd.ClsLxzuwxfsi.metNpvomn(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(82) + 8) - (1331) % 41869) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else
			{
				try
				{
					Integer.parseInt("numAyvxvjnvoqk");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}

}
