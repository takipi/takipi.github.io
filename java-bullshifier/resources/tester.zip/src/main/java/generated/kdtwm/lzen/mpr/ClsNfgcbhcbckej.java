package generated.kdtwm.lzen.mpr;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsNfgcbhcbckej
{
	 public static final int classId = 357;
	 static final Logger logger = LoggerFactory.getLogger(ClsNfgcbhcbckej.class);

	public static void metOxdvwdpnbz(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[10];
		List<Object> valZjrfhtamqbe = new LinkedList<Object>();
		Object[] valUfqlsbrzerf = new Object[4];
		String valCzqhxycabiy = "StrDhgieaulecx";
		
		    valUfqlsbrzerf[0] = valCzqhxycabiy;
		for (int i = 1; i < 4; i++)
		{
		    valUfqlsbrzerf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZjrfhtamqbe.add(valUfqlsbrzerf);
		Object[] valVlydtecynnb = new Object[3];
		int valMmemkkwhydt = 216;
		
		    valVlydtecynnb[0] = valMmemkkwhydt;
		for (int i = 1; i < 3; i++)
		{
		    valVlydtecynnb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valZjrfhtamqbe.add(valVlydtecynnb);
		
		    root[0] = valZjrfhtamqbe;
		for (int i = 1; i < 10; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Sjzvmdhgw 7Xblxtfrz 8Bsghtyitt 6Plvxvix 8Psayohmhr 10Vzptrqrvdcn 9Eiiljumzwd 6Mighsnc 6Rcfeofh 8Ndgsgjobs 5Adotiw 12Gbfxfytjlufgq 12Rjrrkevhnyoxy 4Vpcar 12Xnedsaovvqolb 8Dmpjrxmfq 9Itlafwesia 4Woqjv 3Roim 11Ljosycqhagxv 7Drgtbzdc 8Khbwszzge 11Obomnxqkpacq 12Ogpbrepuzsaon 11Nmvjdhfpfryh 10Tvanlroanox 3Yzok 6Pzsfrma 11Urehbpfndpyl 5Dmtgnh 10Obctnvfyuxm ");
					logger.info("Time for log - info 10Mttgjlpzasf 7Chvkxrfg 7Ialsevzv 3Fwfq 6Ynhibkg 6Zyyohec 11Npsgcqiufclp 9Vydmtbnses 9Uavsdtlegc 4Wgqdd 3Alhc 10Smjhbzcxoys 3Gtqt 10Xkvztnewybo 4Uqday 6Uhvmybe 8Kzrdvsbzd 7Kkvcybaf 4Jrxvm 12Pzexdmjvgocmy 11Fxyococbckyq 9Hlshthojdv 4Pdgts 11Mdhkfnlfkeio 6Gzucxqc ");
					logger.info("Time for log - info 11Nankopvhdjgg 5Rckfkc 6Ninxrjy 4Szobh 6Sdfoaoo 11Xutlipdbobfa 12Avapltatdctgr 11Xyqmjktvledz 4Xuile 5Ajelro 6Qnpysoz 9Hojxuvurxs 6Pmpdqzp 5Fzhmes 5Swydie 9Kqviqkurpz 4Qoiyf 4Bkxwk 12Eipbpbibzrzyo 12Ywvcetibaosbd 11Adhzlejvlbrm 9Geijukbkeo 8Yunjfbopj 11Xquyjozbrjab 9Zoaqefiwlt 11Nspvctojzzzf 11Zxpqxmlufdux ");
					logger.info("Time for log - info 8Tigwgulli 7Xyaoocqq 10Zwtfrtcwcjz 7Aoozzcwb 6Tznsgre 9Wrqpluxyaa 4Cbedl 9Bmvpqhsgkc 3Jiqo 3Crkr ");
					logger.info("Time for log - info 9Ewsqhncait 6Dzbdhbh 7Xhrzsvxa 4Szpoa 11Rknykedubais 7Ezwuhorf 11Ngjrgnzzrqwj 4Tvcct 10Cgyrwtzryay 11Vrdjkoddfalg 10Neqtkcphtor 8Gbxmrxzoa 8Gagmjnumf 10Mqtlkkjoigd 7Mtcgyzkc 12Ykdnrbgopvxux 7Vvkeoplv 9Hhskergwqi 9Pzgaygbzfe 7Nafjiqrb 8Yuimatcyo 12Mxupqnmjoemqa 9Ufybzrktpi 10Znqckmtzxqh 4Yljbs 3Qopg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Boexecdbue 10Xxfsivbpdlm 8Hnplrybem 9Ldydgyohjr 10Njdolpjbrot 6Nrlscyi 12Pyjhgmvzkwlgl 12Ueiolygmzfvdb 12Ekdrqbczsgxsl 5Wskzgl 12Mxwrwytkkztnb 10Tbtkffyyxin 11Iboydqpocfqs 8Svbdqjuvu 6Yitiobh 11Zhnylmhjzteh 12Ukbtrgpuydzzi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.aby.eyq.viq.flsc.ijccw.ClsKeovzqbtjs.metTizqtcinnozd(context); return;
			case (1): generated.fdt.uzdvv.nwv.pad.fynuz.ClsMxbvroaeedb.metBmwjzeehsyboz(context); return;
			case (2): generated.ukp.wkgj.kys.bbj.whcvs.ClsShqgniemg.metRrbombfiz(context); return;
			case (3): generated.naf.suq.ClsSzodbxxywsfz.metFhdpmoxdz(context); return;
			case (4): generated.uooez.nez.ipsx.tenui.ClsCrgtl.metHrkchutdgiq(context); return;
		}
				{
			int loopIndex26029 = 0;
			for (loopIndex26029 = 0; loopIndex26029 < 3173; loopIndex26029++)
			{
				java.io.File file = new java.io.File("/dirOarnburoawo/dirHyfsijbkeua/dirGjhmyzemptt/dirEaryjlobptb/dirZyktxidxblx/dirSjkpcphjqai");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirHdusgvbmahp/dirGznkrqshzrb/dirUhygprbpvnl/dirVndghgnuuqh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirQjtudhhffgi/dirXrvkirqensx/dirReeuwjcgkss/dirHinotaawhqs/dirTeupmxmqnqk/dirZhgjyromfuv");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metRvvjmdhdx(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Object[] mapValHjvoflkesde = new Object[8];
		Map<Object, Object> valAoymxzrxxnw = new HashMap();
		boolean mapValImgcaabcuzl = true;
		
		long mapKeyIausawcaghx = -8797000005945013072L;
		
		valAoymxzrxxnw.put("mapValImgcaabcuzl","mapKeyIausawcaghx" );
		
		    mapValHjvoflkesde[0] = valAoymxzrxxnw;
		for (int i = 1; i < 8; i++)
		{
		    mapValHjvoflkesde[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Object[] mapKeyHcldcdjxgfw = new Object[11];
		Set<Object> valJucelrtbdam = new HashSet<Object>();
		String valAlbqreigibq = "StrHwgauclqwfq";
		
		valJucelrtbdam.add(valAlbqreigibq);
		String valRumghbutzbk = "StrOhvalzwptvk";
		
		valJucelrtbdam.add(valRumghbutzbk);
		
		    mapKeyHcldcdjxgfw[0] = valJucelrtbdam;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyHcldcdjxgfw[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValHjvoflkesde","mapKeyHcldcdjxgfw" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Eljco 12Ngfxdziagnymb 6Jgxsnoy 4Cjimd 11Beapyvwntgvp 12Liyztrdrqoacr 4Vqrfp 6Kgfslbq 12Ogvkyijkiiepn 12Crmoqfwtqnogk 11Ufckmqmdlxtt 6Sooresv 6Fndsbss 4Icohz 6Vnitsom 5Pmggpk 9Sfxlvemmvj 9Dgoadrbjtd 8Vukjnaptf 4Euwxf 10Bitpddgbfqc 11Wvjsuxidflcj 8Jipneveqh 3Dgor 5Zbsbtx 8Cubgidmif 7Wizkfzlw 9Riwthdaydn ");
					logger.info("Time for log - info 11Ncevbyxagibs 5Vsquaa 3Wgta 8Flckygcri 10Pkisqmsuqrw 3Ntbw 5Kkfxsu 11Aliggrrxjuxv 6Hxnuthr 8Guxjdlfzi 12Vrawxxcplxfue 8Pfpzqgcqz 8Mqtycluvl 5Abcqwq 6Ksebnvg 9Fzcgnvtuvk 6Rkedtvr 8Dugfbdxfs 10Dghpqmftssp 11Tqcutxjpvxod 11Ovycfdeywgka 5Oloynj 5Oopgbp 3Dkeh 12Iqtoqqdhdhstg 11Jmehkayaobyl 10Byntlruujco 6Jtuksqo 12Hefpagncgsbmm 4Pxxnb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Psxbmwc 3Bdca 11Ddqmkypaealq ");
					logger.error("Time for log - error 7Vghovrtn 10Yzqjesxlfdc 4Ascnk 9Cscxneexxm 10Fgcryrzfxgm 3Lxnw 10Ztthwrcajwq 11Naehcgcvnuyu 7Iukhqzgc 12Gbehrqlvlyxny 4Tontq 3Bzyw 10Nzsvkvzhhhe 9Bduuuitltz 12Clbgzkondmxtl 11Ekzooddtipqd 4Hypgt 4Jshiv ");
					logger.error("Time for log - error 10Nqogohjjhnu 5Jyapqn 10Uqrxoihfboz 6Uydtmfl 4Dfadg 4Uygop 8Badslxfsx 7Fnthfstq 5Cmkoyy 10Yryfpdlmipf 11Qhnmllgclxpx 8Pkgaaslni 8Juxvqpngm 6Zewgwxz 3Gfuo 12Xdrjumtlltkqz 3Qnnc 11Mzqctrmzegbe ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.dpe.jvo.jwdtk.ClsKqcmvv.metOqhxfxoow(context); return;
			case (1): generated.hioa.tbao.juo.tlh.zgppg.ClsZtwfn.metIuvwdmma(context); return;
			case (2): generated.unn.flt.iyr.tjmvm.ClsFuxljnbiciwosz.metRgojbrkwjkezrx(context); return;
			case (3): generated.deuz.rvz.jsq.ClsHbyckyeswad.metNsroqeuzcfbif(context); return;
			case (4): generated.lxmnm.hdgf.ClsBecbgmyq.metXxaphxbxrzzp(context); return;
		}
				{
			int loopIndex26036 = 0;
			for (loopIndex26036 = 0; loopIndex26036 < 2395; loopIndex26036++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
