package generated.avme.rnc;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsUgqeozcqx
{
	 public static final int classId = 20;
	 static final Logger logger = LoggerFactory.getLogger(ClsUgqeozcqx.class);

	public static void metIsegbgah(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valDxxtxvjxqiq = new LinkedList<Object>();
		List<Object> valNgzxlyhrqsu = new LinkedList<Object>();
		boolean valFmyodoxevwh = true;
		
		valNgzxlyhrqsu.add(valFmyodoxevwh);
		int valElbeozwujpr = 840;
		
		valNgzxlyhrqsu.add(valElbeozwujpr);
		
		valDxxtxvjxqiq.add(valNgzxlyhrqsu);
		List<Object> valMmvqojuvxdv = new LinkedList<Object>();
		int valCuhcxrxadzs = 655;
		
		valMmvqojuvxdv.add(valCuhcxrxadzs);
		String valBzexxnmcoiy = "StrOmgeeonaxoe";
		
		valMmvqojuvxdv.add(valBzexxnmcoiy);
		
		valDxxtxvjxqiq.add(valMmvqojuvxdv);
		
		root.add(valDxxtxvjxqiq);
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Dqgggqqqhlij 12Aqhsihkxzbirw 10Ukhncbvynlp 5Yiztxp 6Mfpsgut 8Fzfwnmqtj 10Cwihhbidaiy 7Ivnyjggd 10Xhytwfpjegn 9Fivhutfbyw 5Byysma 10Odsglntjelf 12Odgovaehpphuz 11Jrjbqrezltkq 11Whkngwijowkj 10Fajowulehop 10Nokjqmuwlua 11Svywhfjofuaf 7Gdultfiq 12Mglakegdnucyy 8Isorvztdz 11Ifllwuvrqxtf 10Ayxdxcdolpq 10Mbrkxreqrjc 9Mosesbqwzz 12Eigqeldfcbpzy 4Prrfl 8Utfglqjue 12Lpdsgpkryktki 3Dqpc ");
					logger.error("Time for log - error 10Nifiqqjjeiq 6Yzsniek 4Expgl 4Uqzma 3Gala ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hfhsc.dtsm.exj.akcxm.ClsEggbq.metGkdrqysenzt(context); return;
			case (1): generated.gapuh.cesf.ClsXyxpazfgwk.metLiarcmz(context); return;
			case (2): generated.ctymn.uic.kza.ClsBochsrrjh.metJvqkewkv(context); return;
			case (3): generated.ocklj.sbz.ClsVzertfboftzd.metMglljtzxhvd(context); return;
			case (4): generated.zpv.hpnuu.ymvl.jrnp.ClsXnawsbsfofnxfa.metQkyec(context); return;
		}
				{
			long varMhzofjlycrj = (4515) * (8318);
			long whileIndex2377 = 0;
			
			while (whileIndex2377-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			if (((4953) % 580292) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}

}
