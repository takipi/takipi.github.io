package generated.wwtht.wyffd;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsDnoox
{
	 public static final int classId = 47;
	 static final Logger logger = LoggerFactory.getLogger(ClsDnoox.class);

	public static void metFwosjn(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[11];
		List<Object> valXiyvsongtlj = new LinkedList<Object>();
		List<Object> valOvzrezgsyiu = new LinkedList<Object>();
		int valHsgwznnnmmm = 628;
		
		valOvzrezgsyiu.add(valHsgwznnnmmm);
		
		valXiyvsongtlj.add(valOvzrezgsyiu);
		Object[] valSzqtaemgyyz = new Object[9];
		long valYgngyaimqjt = -8256520680020225127L;
		
		    valSzqtaemgyyz[0] = valYgngyaimqjt;
		for (int i = 1; i < 9; i++)
		{
		    valSzqtaemgyyz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valXiyvsongtlj.add(valSzqtaemgyyz);
		
		    root[0] = valXiyvsongtlj;
		for (int i = 1; i < 11; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Ljdldqlb 8Qjrunodpk 12Qkzwogmpbnyed 3Cjjz 5Ahsxjx 10Wclqmnjazpl 3Mcry 5Emaofq 4Jhlmq 9Jdchaeqtrt 11Rrlrtgcddaxj 11Bvwsfcxegmlb 7Sgzmwttv 10Sinxkzjghvi 5Pkoqfd 9Tuwdqqmvxe 4Rqjga 9Nanlspcdgh 5Gyfxbj 3Qcxc 6Nebhgbq 5Eeqxgq 10Voogpwnvokr 7Xxpibnhp 4Nuvuw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 11Tnzecsugezsn 8Aglxhdvcx 9Apuiwdwwvl 3Nqtm 4Nqsmp 9Acqbzlesxz 10Sjathejopra 3Frnq ");
					logger.warn("Time for log - warn 5Erqkbh 4Nzmxa 10Mxfwrtebnkb 10Vxerfzoxfun 11Xubspzzwzqob 8Mmgizcofz 7Cnxdpxbk 10Etrumerwbcd 4Sxgmo 6Tnsdwhz 10Owwrxdytqoc 11Cnyjdtdtnxwg 4Pqpfk 9Qbjxuccyry 9Blshszcktg 5Fudrzq 9Xeetatsspc 6Pmnzant 10Pomaetionuq 6Wwjfjci 5Vsrjoh ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Cvpxpucsc 7Cglewdvh 12Athlaooohyhce 7Iafwcwbs 9Nziopqzzfw 12Ahlxkbtezhobs 12Kjjjexsacrenw 6Xcjydpj 7Ppjswqvl 6Mewiqhf 7Mstvkpow 12Qvvtzqprzeyrf 3Jenh 9Zgsoxzvglr 5Cxdfqf 7Toxpzwgs 6Dvbxnso 7Exfioknx 4Dgzvd 3Iodn 3Nqic 6Lpbjavl 5Pfyypi 8Dfiyowljv 10Luanqciubob 8Zgolgipiy 11Bymmqcfcwjso ");
					logger.error("Time for log - error 3Fyyy 5Uzzbwx 5Hbrlpv ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gucbl.hxhv.qux.siytf.ClsVpdrty.metXdgufsukawoajk(context); return;
			case (1): generated.uooez.nez.ipsx.tenui.ClsCrgtl.metEgxtoauldfq(context); return;
			case (2): generated.qwlax.zei.ClsAdxloruwrrth.metHsjxayjzgkwe(context); return;
			case (3): generated.cymhf.zmxu.aqlat.ClsTwlvztmhvdbz.metXepcrhrku(context); return;
			case (4): generated.ydzsq.oryaq.elxyy.ClsOrteugmzafy.metJlrtydsoimw(context); return;
		}
				{
			long whileIndex2859 = 0;
			
			while (whileIndex2859-- > 0)
			{
				java.io.File file = new java.io.File("/dirIspcydgncan/dirArymckrofxg/dirWfmfvcxbmkr/dirGjilkdhaear/dirIcsopfjzblz/dirErvjkqqssui/dirGziiyftnrpm");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metAptucgpoeq(Context context) throws Exception
	{
				int methodId = 1;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valOpkypkamdam = new HashSet<Object>();
		Object[] valVlttkjwetzq = new Object[3];
		String valTbudgzkgxac = "StrFaqxikmcreb";
		
		    valVlttkjwetzq[0] = valTbudgzkgxac;
		for (int i = 1; i < 3; i++)
		{
		    valVlttkjwetzq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valOpkypkamdam.add(valVlttkjwetzq);
		
		root.add(valOpkypkamdam);
		Set<Object> valGyaintolqzb = new HashSet<Object>();
		Object[] valIyzqagqleii = new Object[9];
		long valPmhemwinsbo = 5015549845225804903L;
		
		    valIyzqagqleii[0] = valPmhemwinsbo;
		for (int i = 1; i < 9; i++)
		{
		    valIyzqagqleii[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valGyaintolqzb.add(valIyzqagqleii);
		Set<Object> valHciuujpcnka = new HashSet<Object>();
		boolean valNbggylyhhee = true;
		
		valHciuujpcnka.add(valNbggylyhhee);
		boolean valYhggaxvkfie = false;
		
		valHciuujpcnka.add(valYhggaxvkfie);
		
		valGyaintolqzb.add(valHciuujpcnka);
		
		root.add(valGyaintolqzb);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 10Ahzrfluzpvi 4Zdgfl 12Jtxqungytvhqn 8Nychagawv 3Qrvt 3Euft 11Tthtvavuxxck 10Qjuxqgxhqea 12Nfpnmplpqquvy ");
					logger.info("Time for log - info 9Yslvyvkxgz 9Scnbdfwdff 10Akhzgjarumi 4Kktov 12Ngelyluqmussf 3Ilgb 4Kqxcs 9Wbflquslec 3Yynw 12Lavpeeroyytvh 3Pmag 6Mnspjdr 7Xdtnimyj 12Ilyhepiptglnf 11Qfxnkxevxiol 11Akvaawneikvn 4Wviad 11Inxutciamfzf 10Menttpzvncv 8Ncnazpxus 12Zcqqwumgbpmjs 4Zysil 10Jimvolmfnbc 4Svctk 8Qrtcgoqak 10Dtidgqmyraj 11Mushwqmtvgyu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Zddwnekeg 10Oylxsjnunlv 4Encmn 7Ltydfhqc 8Ezzyqflix 10Gvxkyfrmkcy 12Dabmflnkyylcu 5Emiuyw 11Ninbhyolparj 6Rsisjmw 10Nwqtykzwkxf 6Grokzqn 8Zpqjghluy 4Bbxrb 7Kibwomjh 10Ijqyiaowoqj 5Iofxqj 5Xdwtlt ");
					logger.warn("Time for log - warn 10Aegjeklpuxj 8Wurixypyf 4Lnrax 9Nlpiyazvsa 9Oodvlwoflv 11Wuhloiovgfab 3Iwak 12Kdofwtbdzwbeb 4Wvykf 3Uaaz 8Mjwtohlam 8Zuwljoigr 8Uswbpzvqg 7Xegcftrd 10Pzpnczpaegp 9Eixmnkrrhe 6Opmxswy 4Pcewf 6Phpssol 5Tzwnbb 12Pdowtfnonqkxw 5Nrtapa ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 4Laijj 10Jldmhrebjem 3Mvax 12Hrnrqudftroyn 9Oqbrnspjzj 12Cifjlamxznskm 7Iwmdzalo 11Ucnqqlbjarle 7Wxgmmqkj 11Wgimbtvbvbae 6Qhvgour 9Mwtafcizgw 12Dkqzdzgivqhou 12Rfkznsenbtdac 12Pdthohvjzlxeu 5Cizlab 11Whmeveefaunt 12Opdvhewaguxhp 11Gqrmhfdhswcl 7Dwmqnenu 7Yurlynuh 3Wmlq 10Rsxcnyneton ");
					logger.error("Time for log - error 8Icjtwpkmi 7Rqqgezym 7Glfmfsck 4Dhxfn 11Ksjvycdeanxg 12Kkzbqwjkqoxjm 7Paxdokqw 3Hxnd 4Lligw 8Twstgcigs 12Giwjrfehcnjdp 10Lhkreoosjbe 4Ykbyx 11Nvwlfamqyvmb 7Ulsyjwjt 10Malkilfbxwc 7Zbomdgou 5Kekqio 12Vwpwihaxiwgav ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lfb.pwad.aey.ClsGmnfes.metGiyldxwq(context); return;
			case (1): generated.jrx.knq.qgl.klpmp.wqhuy.ClsPrfpvgkjefvagy.metUchdoaa(context); return;
			case (2): generated.decno.psqz.bhc.ykgc.ClsIhnrz.metNfknyrmpq(context); return;
			case (3): generated.fzd.qgqjp.ClsVzqqvdhb.metMsjbhqpplani(context); return;
			case (4): generated.miye.jljz.lus.ClsMvdumbmsqtl.metJmaluuekf(context); return;
		}
				{
			int loopIndex2862 = 0;
			for (loopIndex2862 = 0; loopIndex2862 < 7473; loopIndex2862++)
			{
				try
				{
					Integer.parseInt("numDcuymmzanjd");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex2863 = 0;
			
			while (whileIndex2863-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metYkogiuahq(Context context) throws Exception
	{
				int methodId = 2;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valTtqovwxktkw = new HashSet<Object>();
		List<Object> valQkduimijwjn = new LinkedList<Object>();
		String valIuhodeemclx = "StrMbfqqwcbvob";
		
		valQkduimijwjn.add(valIuhodeemclx);
		String valZixckyvfvmh = "StrDhbeqjbaugs";
		
		valQkduimijwjn.add(valZixckyvfvmh);
		
		valTtqovwxktkw.add(valQkduimijwjn);
		
		root.add(valTtqovwxktkw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Qxapbvtj 7Ugshfvsz 12Ibdaqqopkftxs 3Gaph 3Fwob 10Ctqsxtuhils 3Lnqo 3Hzcb 7Zawevjuc 9Szvbtcedpb 10Rrshehroopb 7Ivcbogap 6Syunjod 6Lepqmad 11Zeucqldrteto 3Fuoe 5Vyfjzz 12Hhvgcufznigll 12Zsfpgqnhiuyyf 8Kxevbdwql 9Fjakppjuow 12Pubvqlqxvcfep 7Lvargfmc 8Ssnjpwbmo 4Kzxjt 5Hrjlkh 11Bwzsdmfrgqlq 4Lobsg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 12Ldirsmetwacdq 12Updddaburnzfe 4Gclgx 12Jxuvxtifaddsq 4Tfycq 8Qouagezre 12Ogrxxgoofrrvg 6Mqcactx 10Uwbxsftgmew 3Miuj 10Odrsydkmapg 10Tkurszdaayp 5Qgqojp 5Hkqvtb 8Yjbqrehnc 10Ptgescxvutc ");
					logger.warn("Time for log - warn 9Rqncujextt 6Ugxztjj 4Bghav 7Syvxobow 11Ixssewgcygih 10Whlrgefyyxt 4Fyvjl 10Vrriebuhsxq 7Deuckwnu 11Wucfnyqsszyi 3Ubxz 12Pnermiqjtpqku 8Ktkduayvc 8Uthvcyhny 11Ywrdaeezhorg 4Rhzuu 8Aedxpwlib 7Nulcvrgz 3Ugoq 10Dkntidpskxf 9Jbeizswbmk 4Pitqp 4Upxan 11Gyrdkvfcaqjp 10Spprllzffgo 9Qfjolxkydt 4Ifqeb 12Wotiqolhadota ");
					logger.warn("Time for log - warn 6Jvzqstp 3Cahw 12Lwkjodybviipq 6Wkmmsfu 3Bmbb 11Bomkolgwzgbi 3Qvhq 12Bewfrpqktrayy 4Uizyt 6Dmmbwcu 12Vnqtnahwylhwj 9Mxitptluck 8Jppniijqp 9Oquspbcsch 3Xyti 5Tsdtfs 9Muiiarwaoj 10Iuyidnxolfn 12Dcldknuuhnwkq ");
					logger.warn("Time for log - warn 12Guhtqgcfjjmhv 3Bwle 11Qytmdlaknwrb 6Uzohalh 5Lzqopv ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Ryeikdphs 12Tprwounefpepu 3Wvta 11Yconeqbuoays 12Hmbpswvrlkbks 5Qvzgmk 11Virtcwuhctou 8Swelgcutu 4Odarr 5Cvegsi 6Heyrglr 4Vsyrv 4Umlse 4Cvope 5Izbagy 8Ywkpctjcb 7Llvzhkdc 5Ljagot 10Uxlmfcnxths 6Cmsmqau 3Vgzt 5Vgeqmt 12Jrahwuqnvkqcj 7Lkemrzdv 11Sznsvrvylheu 5Ikpvxy 10Fkenmxhbnna 10Iitiifcllfe 4Uweej 9Amlhpqxwli ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.psl.vgj.rgm.ikl.ClsWqomoi.metBvzuwktozvf(context); return;
			case (1): generated.dyzfj.ltbnu.ClsCnnhwt.metAwrkzvmc(context); return;
			case (2): generated.zic.glh.ClsJylyrkbuexopc.metXfvmhgsf(context); return;
			case (3): generated.ldtgt.vdfx.cdz.lkx.ClsLvvwnymti.metFkrjypkkw(context); return;
			case (4): generated.fkhk.aid.ztzxu.ClsQjlasdqvzflfd.metXgpgomawgjao(context); return;
		}
				{
			int loopIndex2867 = 0;
			for (loopIndex2867 = 0; loopIndex2867 < 9864; loopIndex2867++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex2869 = 0;
			for (loopIndex2869 = 0; loopIndex2869 < 4899; loopIndex2869++)
			{
				try
				{
					Integer.parseInt("numTmdbmyyhlyl");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metHucpfm(Context context) throws Exception
	{
				int methodId = 3;
		Set<Object> root = new HashSet<Object>();
		Object[] valEolwvedhjiq = new Object[6];
		List<Object> valWfsxdnjdqip = new LinkedList<Object>();
		int valYkdssyrchib = 487;
		
		valWfsxdnjdqip.add(valYkdssyrchib);
		boolean valTmrobiyqctt = false;
		
		valWfsxdnjdqip.add(valTmrobiyqctt);
		
		    valEolwvedhjiq[0] = valWfsxdnjdqip;
		for (int i = 1; i < 6; i++)
		{
		    valEolwvedhjiq[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valEolwvedhjiq);
		Object[] valHecvdwrifrt = new Object[5];
		Set<Object> valUqdofqpdepm = new HashSet<Object>();
		String valAmoohvbctac = "StrIbzjaozdwok";
		
		valUqdofqpdepm.add(valAmoohvbctac);
		
		    valHecvdwrifrt[0] = valUqdofqpdepm;
		for (int i = 1; i < 5; i++)
		{
		    valHecvdwrifrt[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valHecvdwrifrt);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Hhatzvfylibyl 3Nzvf 4Mokyq 9Brhgjpiihm 12Qtislwngtaiqu 3Vdus 8Coxbgkbmz 10Nlqedfukjju 11Uqkuuccktkag 6Tvcmqqq 12Gviwhbkipjgzy 9Xxwakwosxn 4Drquu 10Gnpljolynti 5Djgbji 4Aucaq 9Bsyagdkmkp 6Ehgzqio 12Vinrofkrztunx 7Tjpfvqct 7Cksorphi 4Awham 6Qjpguip 10Vkzhsnskeuy 3Xuak 12Zagwcewqrykmp 5Wxwajc 12Otsmepadcixbk 12Sahvjkowtzfoi 5Jxdqvo 12Bpwlyyylkrcos ");
					logger.info("Time for log - info 7Uzxdqdax 5Yckpom 7Oumyppqq 9Owmwvkvybj 7Vkekoxhl 6Wfgpbuh 8Prekmwixi ");
					logger.info("Time for log - info 12Ksyjsbslunjyc 3Iufv 3Nydz 8Boculrdpk 4Rndrs 5Ptnphj 5Phqrzw 5Gvnlkt 6Ezcpmki 10Cktoawqgqzo 4Ixzuo 12Hpfbexlzpsexn 4Yjnld 7Dxgchimw 5Rerrmh 4Sqwsf 3Akoe 6Dtwzhnc 10Qvplwzgozzj 4Pvako 11Xgzncjprwftm 5Qcoiez 9Bvvgxkslfh 9Iifypwibft 6Yzigmle 7Lxcxgxqn 8Xhifmtbdb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 9Drmbqvjvsh 12Idsfhhldgwvad 8Nxnulcdvo ");
					logger.warn("Time for log - warn 4Jqkvw 12Culdalzwafsly 12Euvplacseieuk 11Lkxlmqsncial 6Tbhfajs 8Smquwodpg 7Gmjppyke 5Osxspm 11Gkyxiohiqcql 9Crtzpcuzmk 6Flojjto 4Qqqvr 12Hnagndrfvptec 12Nasfockxvijin 11Ryxsgpjgofuv 11Qplssilomujo 5Volxap 12Cpzidjzfdkfrg 7Obvecajo 3Gnfe 4Obhfm 6Hupbktw ");
					logger.warn("Time for log - warn 3Qvui 12Dbbqaewsmgtce ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.ocmm.ezbtm.vxyei.kuseg.ClsUqzgoaq.metIufhbdjk(context); return;
			case (1): generated.crkmz.uuny.smq.vvmxn.khxb.ClsQbvzuhroxdituh.metJqalviosof(context); return;
			case (2): generated.nsbl.xxor.rsxq.aixva.einq.ClsJcyofzflum.metRqhzthy(context); return;
			case (3): generated.rorl.wuo.lqgdf.ClsUltodfmiuq.metQslafqderta(context); return;
			case (4): generated.dyv.vxo.ClsWrwpfswr.metTpeyljwzklrtjz(context); return;
		}
				{
			int loopIndex2873 = 0;
			for (loopIndex2873 = 0; loopIndex2873 < 4719; loopIndex2873++)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			int loopIndex2874 = 0;
			for (loopIndex2874 = 0; loopIndex2874 < 6011; loopIndex2874++)
			{
				java.io.File file = new java.io.File("/dirPhpyrtiwrat/dirKicgivzilhr/dirOoepahnjabt/dirNwhuesgaoxy/dirMtclemkmgxi/dirZjapxatyowv/dirXzkjxijyuae/dirQqnchwuvnql/dirFasnrwuywir");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}


	public static void metJgsxeyr(Context context) throws Exception
	{
				int methodId = 4;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValMkxxdkzdrkj = new HashMap();
		Map<Object, Object> mapValKdeygpjbqxg = new HashMap();
		boolean mapValChwgwmdoxka = false;
		
		boolean mapKeyZyolbsphupq = true;
		
		mapValKdeygpjbqxg.put("mapValChwgwmdoxka","mapKeyZyolbsphupq" );
		
		Map<Object, Object> mapKeyLqgfqxekwys = new HashMap();
		boolean mapValIgwkadfqbor = false;
		
		long mapKeyWeardpoflsa = -5543739942570636602L;
		
		mapKeyLqgfqxekwys.put("mapValIgwkadfqbor","mapKeyWeardpoflsa" );
		
		mapValMkxxdkzdrkj.put("mapValKdeygpjbqxg","mapKeyLqgfqxekwys" );
		Object[] mapValUxtonljyses = new Object[9];
		int valNlhvizeuxxu = 8;
		
		    mapValUxtonljyses[0] = valNlhvizeuxxu;
		for (int i = 1; i < 9; i++)
		{
		    mapValUxtonljyses[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyJigieecpgda = new LinkedList<Object>();
		long valUytuzkoyhih = 5925061685069254173L;
		
		mapKeyJigieecpgda.add(valUytuzkoyhih);
		String valOkhktiwzeox = "StrNmgkyjcizam";
		
		mapKeyJigieecpgda.add(valOkhktiwzeox);
		
		mapValMkxxdkzdrkj.put("mapValUxtonljyses","mapKeyJigieecpgda" );
		
		Object[] mapKeyZwfrdaiuqfi = new Object[6];
		Set<Object> valBvwmqusenfz = new HashSet<Object>();
		int valMpdeuuemyiu = 208;
		
		valBvwmqusenfz.add(valMpdeuuemyiu);
		
		    mapKeyZwfrdaiuqfi[0] = valBvwmqusenfz;
		for (int i = 1; i < 6; i++)
		{
		    mapKeyZwfrdaiuqfi[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValMkxxdkzdrkj","mapKeyZwfrdaiuqfi" );
		List<Object> mapValNxqagnigmmi = new LinkedList<Object>();
		Set<Object> valTcbfharokzz = new HashSet<Object>();
		boolean valEhvnwrkfdgx = true;
		
		valTcbfharokzz.add(valEhvnwrkfdgx);
		long valIfedtqqhmkm = 8992717686449802820L;
		
		valTcbfharokzz.add(valIfedtqqhmkm);
		
		mapValNxqagnigmmi.add(valTcbfharokzz);
		
		Set<Object> mapKeyWjybsnbpdpd = new HashSet<Object>();
		Map<Object, Object> valUjszzolzeib = new HashMap();
		int mapValSdmrcuaexnz = 248;
		
		boolean mapKeyLhweddaaeto = true;
		
		valUjszzolzeib.put("mapValSdmrcuaexnz","mapKeyLhweddaaeto" );
		
		mapKeyWjybsnbpdpd.add(valUjszzolzeib);
		List<Object> valWlvtmmxjtvm = new LinkedList<Object>();
		int valIbjqpqwczio = 830;
		
		valWlvtmmxjtvm.add(valIbjqpqwczio);
		String valPctnxcpmmxi = "StrDrrpvmgdooh";
		
		valWlvtmmxjtvm.add(valPctnxcpmmxi);
		
		mapKeyWjybsnbpdpd.add(valWlvtmmxjtvm);
		
		root.put("mapValNxqagnigmmi","mapKeyWjybsnbpdpd" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 6Jikaooo 3Fylb 5Ctynkx 7Mqmwejoz 10Ngniveywbjt 12Czqqzjdqfmjap 6Nbnzzmi 4Pjyzd 4Kmiru 4Enycm 11Wwlqmrdzhuxt 6Llplauo 10Jvmwqruohhz 9Ujdbchihzs 11Azpksyzbagne 8Gwpkgrxvb 5Ktqlck 4Kdopj 7Pjcbetpb ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Ozpugqo 4Abihe 12Grahhcesfhcwr 6Yqddzve 6Iqtxrmh 10Pdfjbmzkiwi 9Vgnvfjpbhr 6Czektcn 11Dmaoaixngdev 3Sduo 9Vpeijpfkyc 10Uctqlquzkuj 8Mnxrlrody 4Otrmo 6Ptnglzs 5Pkcumy 12Fqcshuqzszlft 11Shkkasdqouem 5Xtebng 6Qbdyqul 10Wmyzjwuxwrl ");
					logger.warn("Time for log - warn 4Hiuiq 12Qtebbjlkiuqgt 6Ozmjsnq 3Kgjr 7Bnlizngu 11Gqxzkvnurhsl 10Rmssxobmqbw 10Endpgkjohwb 5Zruflw 11Joydlercogsn 6Alhzjqt 12Adpwbbaobwprr 8Iwxaqwvjv 10Xvkbctakdlr ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Rfqbacz 10Cjtapirydcq 11Virytwoclqhn 9Qjdpbkjuzc 8Jrmydcwss 12Fqwpvabfniwbc 12Odrslwmynksec 8Koeplpoev 5Muhhot 11Vkfcddmsuffu 11Gcfdpqnrkgmb 3Rekm 3Bkdx 4Atdvl 9Fgjepeortl ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fxa.nzjpw.lkh.sxue.ClsXtfkzq.metMfvvu(context); return;
			case (1): generated.wzzy.rguqw.bfm.ClsCumedne.metNzmkdspqsroeb(context); return;
			case (2): generated.hioa.tbao.juo.tlh.zgppg.ClsZtwfn.metIuvwdmma(context); return;
			case (3): generated.gpnn.qul.pdexl.hxjph.zmndq.ClsIcvyndtrplxfkf.metWyrdoedscqrw(context); return;
			case (4): generated.rorl.wuo.lqgdf.ClsUltodfmiuq.metZqbkch(context); return;
		}
				{
			if (((7786) % 422065) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(252) + 7) - (Config.get().getRandom().nextInt(118) + 1) % 587934) == 0)
			{
				java.io.File file = new java.io.File("/dirQqdgttiwuml/dirTutnposufpl/dirOgxmoeynfzd/dirYbpvkabegso/dirKsnbintoycv/dirFzgkiabxflc/dirUdzvmfdzihq/dirYwbnngxvrfe");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex2887)
			{
			}
			
			long varRhkeeiioubg = (Config.get().getRandom().nextInt(354) + 0) + (4874);
		}
	}

}
