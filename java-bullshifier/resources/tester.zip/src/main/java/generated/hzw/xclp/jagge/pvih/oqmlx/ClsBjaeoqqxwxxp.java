package generated.hzw.xclp.jagge.pvih.oqmlx;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsBjaeoqqxwxxp
{
	 public static final int classId = 166;
	 static final Logger logger = LoggerFactory.getLogger(ClsBjaeoqqxwxxp.class);

	public static void metCokbroj(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valYknpxkqvurc = new HashMap();
		List<Object> mapValYqyegsqhdlp = new LinkedList<Object>();
		int valQeqogilytxv = 965;
		
		mapValYqyegsqhdlp.add(valQeqogilytxv);
		
		Map<Object, Object> mapKeyNoqbumojoyc = new HashMap();
		boolean mapValSxqxodybhiw = false;
		
		String mapKeyQvqxkqrpxrr = "StrCrzicdiycpy";
		
		mapKeyNoqbumojoyc.put("mapValSxqxodybhiw","mapKeyQvqxkqrpxrr" );
		long mapValIhxxlstweez = -2141018817904478174L;
		
		int mapKeySfbmhlxdcoe = 40;
		
		mapKeyNoqbumojoyc.put("mapValIhxxlstweez","mapKeySfbmhlxdcoe" );
		
		valYknpxkqvurc.put("mapValYqyegsqhdlp","mapKeyNoqbumojoyc" );
		
		root.add(valYknpxkqvurc);
		Object[] valZdcwzprsdib = new Object[6];
		Map<Object, Object> valHfxpucsshcp = new HashMap();
		String mapValYostxrddxfp = "StrSabnrlibswo";
		
		String mapKeyNhhlgpxgeyz = "StrYzzxfkqwqbb";
		
		valHfxpucsshcp.put("mapValYostxrddxfp","mapKeyNhhlgpxgeyz" );
		boolean mapValGcyleaaqfvi = true;
		
		long mapKeyFczouishugl = -7938223992351227136L;
		
		valHfxpucsshcp.put("mapValGcyleaaqfvi","mapKeyFczouishugl" );
		
		    valZdcwzprsdib[0] = valHfxpucsshcp;
		for (int i = 1; i < 6; i++)
		{
		    valZdcwzprsdib[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valZdcwzprsdib);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Lcngrmvi 12Swzruxvdpumjg 4Klbkt 3Elps 10Rqeionqgjyv ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Peszfkkxoif 8Kasisfuaj 10Svdmauogyhh 6Ofpeiuc 12Ezedvmlnvrdod 10Rztytxuimus 6Izaigpf 5Gdatbs 8Vabnglksq 10Gxjzkmjkocj 6Wbbwien 11Achgxdlsokmm 8Bdlthovml 5Mjsoqb 6Tcwwjfi 6Rfzpcoc 12Pmacuhscjyueh 11Ccaihtxcpkak 7Ijvvzttw 6Fgbrucx 7Dcbeczkf 4Hitvw ");
					logger.warn("Time for log - warn 12Ldajwhauqlyjf 7Cymojyvw 6Yjjydwu 11Swktsqaijjjg 12Ctaumvbbyhtok 10Rpdsyaahnlr 11Doeomxsrdkgl 12Jlczzycxwlfhm 8Jlpgxflbj 9Agcmmqmwdi 8Nwgdrcgni 5Mvrdkj 10Ttlzuyobkod 8Wjoelmebz 4Axmow 10Noumqljomll 9Fylwgbupux ");
					logger.warn("Time for log - warn 9Tgibbudhfg 9Crhphxloxb 12Xkmbuoiuxmhrc 6Kyeusov 7Wsxxbmhc 8Ytxnsqxxe 3Owta 7Drotawqc 8Lqfzvmuvw 6Wkoxjyn 6Drhkmxc 5Tcmjdc 6Imcczje 9Xvjkfrtsbz 6Damwwyv 10Ivznfxkzxuk 7Blnhflni 3Vyol 10Dvvznhyeymz 8Etauqoyrr 9Tkpfirfawx 9Askoxrqklk 5Dwvcnz 11Fnkjqrovxmal 4Hpqhb 10Pelgdxyahun 8Vdnijdktu 9Hmybisgnei 7Rohrhhom 7Eucwmhdi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Odczzhpuequzw 6Lsjvcti 11Ebimrzvzbxop 12Yngxpeitkbhto 8Dldwdygfw 6Msmzusf 7Tfnzceia 4Bzijf 9Dyfnzvnree 10Sbyhvrqgwqj 4Irokw 12Bwdidlcqhikwm 3Fwsd 3Nfwh 6Usrugsb 6Owrpjih 8Datfqmujd 12Hjbfkjstxjjyk 4Tilki ");
					logger.error("Time for log - error 4Clvjc 10Dpuilxcpufa 10Uetkwtxzvfo 4Ahopd 5Uhzfrc 10Hesnohtbhrb 12Ummwxizvqbter 6Zywcwum 9Fsmqzvdvjv 4Susxi 12Pdijoiefavqvh 4Drluh 9Kiscazmdov 7Qcmohmlh 8Dirvhgxrn ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qyalc.lus.ClsKvouelboluo.metUdahdrma(context); return;
			case (1): generated.hcl.ivd.nxcam.ClsQkvrtnftml.metLjxkhhsefadoic(context); return;
			case (2): generated.vere.yue.xag.ClsLhubirlwqfrd.metNbhkew(context); return;
			case (3): generated.yvbmb.hnmr.uqxw.ClsYomdrwntzuxawb.metPhyaooa(context); return;
			case (4): generated.bolg.tnlb.nmug.ClsHstaiufsowx.metPapexcx(context); return;
		}
				{
			int loopIndex22988 = 0;
			for (loopIndex22988 = 0; loopIndex22988 < 5959; loopIndex22988++)
			{
				java.io.File file = new java.io.File("/dirFeyyuapslyr/dirQeutyixpuog/dirMfgrcvqbfqk/dirHzeutkmqvqv/dirAcsyoctxnrd");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			try
			{
				try
				{
					Integer.parseInt("numDbmjrdhenyn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			catch (Exception ex22993)
			{
			}
			
			if (((loopIndex22988) % 868922) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			else if (((Config.get().getRandom().nextInt(839) + 2) + (7073) % 752891) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metPmkwxr(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valAiagreiyjmw = new HashSet<Object>();
		Set<Object> valCgkazccmglv = new HashSet<Object>();
		String valLmzhdynyskj = "StrArxphgbqklr";
		
		valCgkazccmglv.add(valLmzhdynyskj);
		String valBthmfbtmbpu = "StrMbdkywzpilg";
		
		valCgkazccmglv.add(valBthmfbtmbpu);
		
		valAiagreiyjmw.add(valCgkazccmglv);
		Set<Object> valZwhwjkmordy = new HashSet<Object>();
		int valPzlzetzfkiz = 405;
		
		valZwhwjkmordy.add(valPzlzetzfkiz);
		long valYhamzutmydp = 3455706786203986053L;
		
		valZwhwjkmordy.add(valYhamzutmydp);
		
		valAiagreiyjmw.add(valZwhwjkmordy);
		
		root.add(valAiagreiyjmw);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Toff 12Znfvgadrsbqhy 11Ejeokbplogjs 9Cedhhwwboj 8Xkwwtiwxn 5Obocpy 7Ppwqtnyx 12Myjsvzesuwupj 9Mnszhndvvs 9Dsegjvlidh 10Axmytljyvwh 12Sqiqknxjuohxk 7Twlpahjf 7Vfgpgdps 5Yhvvrf 5Jmhhhv 7Elyrhnea 10Jbdafhmiecr 9Huvzrdnguy 6Qgiburv 4Dxjpv 3Cjkh 8Cofyoprnh 4Jrlkt 3Fxww 6Jkurnzi 4Cqrom 10Sdycmbikirm ");
					logger.info("Time for log - info 10Gghzxwztbci 9Osgpqxcnaz 4Vbnyd 10Mmiwtabcsnt 10Vnekmfhetaz 7Idxvdhyg 9Oyilhyvhva 4Ofmww 10Fbnqktybpbq 3Cxrv 11Ukilmuepxeww 5Brrkci 10Yqdmuszhhmm 10Urbhpbrudww 12Bqqrqubknrael 8Eskgjufrq 6Tcvckit 4Exvfk 8Gicnifvyj 6Fkfyokr 10Jzfewfndbln 7Bujyotfd 10Hirwuahrmjg 12Zkmcgsegrjsfb 12Oekypsuocbvxg 7Nyhswvxk 9Qychyuwemp 5Ybhhon 8Uafnxbnnd 7Tjwfxokw 11Jsuxfkcsutxw ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 10Ebzilukpjpt 7Zxdwihjw 3Fpyh 11Ltwgbyfxbslz 4Tqfyo 7Hukejtue 3Rovh 4Odrhh 6Dwzuxsy 4Nfhkk 11Xxcbvfhbljod 4Tiklu 6Kflzyyc 5Xekhwz 9Xdnktighzn 4Lpwtv 3Fktr 12Fwuxfqxuztipo 12Zimsfgcajtkhy 8Wxxhcxnvk 4Ynrij 5Qdtgsu 5Qxvmzx 12Rovgkndxhqymh 3Jlnk 4Rkdoh 10Pjvlhdwrzrf 12Uukhlbimkqxyl 12Syldbhlgqvxem ");
					logger.warn("Time for log - warn 9Oxnweassyp 10Csyyklxdbzj 10Mlilneayakm 12Uqctlqwctahrs 9Jorbkqnfdu 3Glab 3Ywhm 6Qefzoqd 10Adyqjjwxlzg 9Dgizrtgfjm 5Vvdumx 7Fgbxacwg 10Ukkzgpxfmxu 10Zrqwrdaehif 12Vsynowyrfjasy 9Ufenaociug 3Excs 3Lbsm 5Abuoje 7Nfvvshbh 4Ivdqj ");
					logger.warn("Time for log - warn 11Fxnfttkaflus 12Rildqrykygucc 4Yfdsi 4Rytlf 11Ypqhnccelrbq 3Ixyp 8Eobiqvbru 3Lbio 8Ktrkqxrit ");
					logger.warn("Time for log - warn 9Dgfdkgpdge 10Cotbanciusv 10Srdccdnvpec 11Xrkhyjrafntq 7Baspvvqa 9Kfizbdybgd 4Hiylx 12Uwpmeaihbznnr 4Zmwex 11Bfuomphtnkvy 10Ykwakityxlb 8Ihwpbpxus 10Alfeenitbuj 8Uesdmznxc 9Ftyghmgumc 3Lwbt 3Ifzp 11Lnptaporsdvi 7Shvxuggn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 11Pxzfqiurjjlu 6Nfpkfab 3Qbgg 4Fpmcn 3Xfmb 3Evaf 8Afmsvsmap 11Agdaibbktgza 6Syogxti 5Uxiiqo 7Hideudzu 10Mfhkupljpgg 10Pagwcbpqtfm 11Szxfkpavmjlo 5Vwmbnv 10Xajllxcwpeh 7Kbhhxrat 8Mhmejdfns 12Ivbuqjcmmvfya 7Mewyllpn 5Vshyds ");
					logger.error("Time for log - error 7Ivbukscr 4Pmgpo 4Wuztn 12Aihcwjdwucioy 4Zfwyh 5Raczlt 9Mivsfmnfoz 3Kmhu 5Jqysen 3Mzed 11Cgvahoyiglkf 10Mefosmafvst 6Jveuipt 11Qauzaostxqxe 4Fgcwb 3Wdsm 11Yohhxdcgjpgv 3Uqdg 11Nnetklipdjhh 8Tdqhjefsc 5Lqfscb 6Ujgmvcd ");
					logger.error("Time for log - error 6Gwzvwmy 6Drvsmzy 10Hpmomppemgj 7Rjlaldtv 11Xlahhsgaicmn 3Adsu 7Yvpbiihi 3Prot 4Upitm 3Zvvw 12Kitzkomefnhyk 4Jiudu 10Itfysunleyg 10Cgfgogjdcrh 4Glbmu 8Dcgqhlobn 9Jkedxpdqth ");
					logger.error("Time for log - error 8Ypuctvfit 3Abqw 9Cmpmluutzh 10Kkfttooknrw 7Uawbsklh 12Rtxnocbcpmpli 6Xfvvinw 10Yupxiovsrkz 7Phjloszg 5Bgdbky 5Hyzuwk 11Aqewkmbsejdg 7Bibwaumo 5Gjewoj 10Jjivhusldez ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hvqh.qdnb.tawyn.ClsAaddylg.metCsnugb(context); return;
			case (1): generated.vvl.eygsr.pmv.fzat.xuhvb.ClsRspudgdgeelrz.metYhenylls(context); return;
			case (2): generated.zisqx.ukvca.wbokm.ClsZibjqxzov.metHqfpnzk(context); return;
			case (3): generated.tcpo.xhov.ClsRfokukcdi.metFyxdxe(context); return;
			case (4): generated.qyalc.lus.ClsKvouelboluo.metUdahdrma(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			finally
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			long varZrwilhvmzvi = (Config.get().getRandom().nextInt(322) + 1) - (8514);
			varZrwilhvmzvi = (1836) * (varZrwilhvmzvi);
		}
	}


	public static void metLyljj(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Map<Object, Object> valNozvufakkxo = new HashMap();
		Map<Object, Object> mapValXjfwsrtwjos = new HashMap();
		String mapValBfcztpvhner = "StrAdikcjqsjlv";
		
		String mapKeyTitznwrdshq = "StrDnrgcqjspxw";
		
		mapValXjfwsrtwjos.put("mapValBfcztpvhner","mapKeyTitznwrdshq" );
		
		Set<Object> mapKeyFctakijqogs = new HashSet<Object>();
		long valZjytuucfmbu = -5391791657090324074L;
		
		mapKeyFctakijqogs.add(valZjytuucfmbu);
		boolean valLgtdcinhmva = false;
		
		mapKeyFctakijqogs.add(valLgtdcinhmva);
		
		valNozvufakkxo.put("mapValXjfwsrtwjos","mapKeyFctakijqogs" );
		
		root.add(valNozvufakkxo);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 8Qhewdolrm 6Krtuxzj 5Xjcmur 3Fdcv 10Knkxwrmjgkw 9Oldzlgxzxm 11Vuezaqrzqigz 12Zvynnxhtiqwwf 12Ebvelzpjtteal 12Bfhbqjrfjvxvz 10Faqjfdnlscp ");
					logger.info("Time for log - info 10Gvofukycgrr 5Dwqwny 4Tuywg 5Xobtny 6Cvmgrzi 4Lactz 12Gcexhstnevgys 12Yvrpggyntdkge 5Boeuzo 5Qwbxfv 4Bqxau 9Vhiywtbtdi 9Pwprixtmzp 3Djgp 9Dwpisianjg 3Tidj 4Iunrq 7Pmerptia ");
					logger.info("Time for log - info 8Zapqfqulc 6Owvbbvm 4Yrlmg 6Subjnyg 5Pmregj 9Iqchyonsna 8Tayhtibpi 8Hxrqrmdtt 9Zkrenwmzga 12Cbgpqdblytltl 11Jgqevksdxtkl 11Eaugbmyadjcq 3Jhwv 3Ctns 12Adzubrnbvelah 11Hbcxtcftotyt 3Shzl 12Vtbpiikvjlkna 7Xudlhwuc 11Jzrvwlawesee 3Anns 3Ifjd 8Gohwnyxuh 8Arfeonzgz 9Xnalkaxuqi 12Imkbmhwifacrz 6Ynzngrb 6Hbeprlt 11Vvbyoxegtatw ");
					logger.info("Time for log - info 4Lsqmk 12Jzmevhljlglav 10Pugworndnja 3Itqq 11Cktqmnhcfghz 10Mnitgjajihn 4Dicus 3Junz 9Anhviiqciv 11Bxkgqxqcntad 12Zqmvhuprqpeoj 4Jwakx 3Uavo 12Bouqokcycfmzo 6Jcjwoys 3Htba 7Hvsxbmxi 12Gxvpcoybnnadi 11Skdaytiuzfea 9Timmctjvyk 8Pziewfane 7Svflbmcw 11Ixybphicibec 8Jtxuiysud 7Shyhdher 9Uupzrfwytj ");
					logger.info("Time for log - info 7Vbthbyuc 4Lrmix 10Ynzbxikqesg 7Hjrtqnsk 6Tlsttyg 7Rntzsdyg 4Luxpv 4Gznyj 11Dbemmvsxbown 5Mvllyr 5Irnbqi 4Ezvhb 10Uirmbqdlguc 4Nxqhg 12Lftuirmzubtxg 3Qlix 4Inbey 9Rocunaaahp 4Nfzyj 7Ktcxqsdv 10Fkhoybgkvuu 12Jsgoravuqbijy ");
					logger.info("Time for log - info 8Zssfynsbg 6Irmrgll 4Jkvfd 12Ouzqrramytmfh 10Ndkzvvygzth 3Quss 7Tvieongf 7Umkalfwa 10Scjnesdnmxp 9Xlyzavzfwd 7Fzbsjvga 8Zklzsdwil 12Jkcytnssrrdud 9Urciskhqha 7Yvmqwlrl 7Bewuokmo 3Rwpj 11Vdgcgwdcsytr 7Xumtcoai 9Jbmrwbiewm 12Gwbbxvcluzrul 10Xjohtzaizht 3Vsjh 10Xwfkagaetsw 10Vcyvrabpekp ");
					logger.info("Time for log - info 4Ulyzr 7Oermyxuy 11Bqemlzdtpiry 6Kkypcrb 9Ajofpzpypn 12Mnqqoqgpfpeay 10Lqoehjboknk 5Eyhyss 10Imoblrzjpwz 3Jlvf 10Ojdgmpacybg 6Fgzgsco 9Ylgmibtfts ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Thtsfzlfy 10Mhksbinibjb 6Moyngjl 3Lshh 10Ueduyfmnhce 3Bxpy ");
					logger.warn("Time for log - warn 3Rjnp 12Nliqhuwhnizud 12Gwfhmrrqdvxyh 9Mmcasmhqta 7Tqehvdaz 9Fthqwarejv 9Ktjehdxyaz 6Gvwabaz 7Rpulvlhh 9Twnhcnsrao 4Acqhr 7Xpjueqxt 6Zxaybgl ");
					logger.warn("Time for log - warn 9Eaybpkbtjf 3Jiqn 3Tpbs 4Mwsrk 9Jyuswdvdeb 7Xyklesjv 11Iqtzjjgjcyzn 8Amyowqkcb 11Eujbgjoaecgd 11Ogqzwlyixkrq 11Ffufqcmvduah ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Ymwcqq 12Uknbogvxuqfqz 12Uzdrpqcsfcfai 5Qbchrq 10Muwluowuwgx 5Phiqzm 3Ibgv 9Uvjwqqjhfn 4Egcre 4Kpimi 7Atxlfphg 7Raaejddi ");
					logger.error("Time for log - error 12Uzibcbhnwhhqh 4Ifqnf 6Dhwnrbs 12Lakshadsbgeoc ");
					logger.error("Time for log - error 4Grqyd 7Odhwmfkx 5Sjujnv 7Sgawdfkw ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hcdv.yknh.ClsEeaftdg.metXffnjwesvutru(context); return;
			case (1): generated.jyx.gyzt.djq.ClsUotdhdlfsrycjd.metSxrrezlofh(context); return;
			case (2): generated.rjuw.mmbua.ClsRawvqxmhewbl.metOsciin(context); return;
			case (3): generated.tjmm.euxn.jmtp.ClsNhugjkj.metQafbogfqlngiyk(context); return;
			case (4): generated.pgg.urfbp.dpry.ClsLqnnoewxwh.metEewtjghwbbijby(context); return;
		}
				{
			long whileIndex23005 = 0;
			
			while (whileIndex23005-- > 0)
			{
				try
				{
					Integer.parseInt("numGmhnrhhetju");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metAhluzg(Context context) throws Exception
	{
				int methodId = 3;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValMcijtokqmvw = new HashMap();
		Object[] mapValNpomgqbgpod = new Object[3];
		String valLspvuoilvzz = "StrXibxltrwbju";
		
		    mapValNpomgqbgpod[0] = valLspvuoilvzz;
		for (int i = 1; i < 3; i++)
		{
		    mapValNpomgqbgpod[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		Set<Object> mapKeyMbjgyrzcfhg = new HashSet<Object>();
		int valXbswwijfeup = 253;
		
		mapKeyMbjgyrzcfhg.add(valXbswwijfeup);
		int valPxlcmczncmv = 543;
		
		mapKeyMbjgyrzcfhg.add(valPxlcmczncmv);
		
		mapValMcijtokqmvw.put("mapValNpomgqbgpod","mapKeyMbjgyrzcfhg" );
		
		Object[] mapKeyNqfvdwhqanv = new Object[2];
		List<Object> valCtxlvikbgpw = new LinkedList<Object>();
		boolean valQqchglpwagy = false;
		
		valCtxlvikbgpw.add(valQqchglpwagy);
		String valPzxsedqmyuq = "StrYmxbwpaufyc";
		
		valCtxlvikbgpw.add(valPzxsedqmyuq);
		
		    mapKeyNqfvdwhqanv[0] = valCtxlvikbgpw;
		for (int i = 1; i < 2; i++)
		{
		    mapKeyNqfvdwhqanv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValMcijtokqmvw","mapKeyNqfvdwhqanv" );
		Map<Object, Object> mapValIljlidxbdjv = new HashMap();
		Map<Object, Object> mapValDkadqdheqzg = new HashMap();
		int mapValKwellwqpgms = 975;
		
		String mapKeyKhowuqxznev = "StrSeztwktekac";
		
		mapValDkadqdheqzg.put("mapValKwellwqpgms","mapKeyKhowuqxznev" );
		
		Set<Object> mapKeyBfyinouoktb = new HashSet<Object>();
		String valTlsovmpfkgb = "StrYfcjzwofzxg";
		
		mapKeyBfyinouoktb.add(valTlsovmpfkgb);
		
		mapValIljlidxbdjv.put("mapValDkadqdheqzg","mapKeyBfyinouoktb" );
		
		Set<Object> mapKeyDnlutnjqmby = new HashSet<Object>();
		Map<Object, Object> valFjgdvxlqfdc = new HashMap();
		String mapValFzheiroykai = "StrSojtlhuwsjt";
		
		boolean mapKeyVzhbbfcthnz = true;
		
		valFjgdvxlqfdc.put("mapValFzheiroykai","mapKeyVzhbbfcthnz" );
		
		mapKeyDnlutnjqmby.add(valFjgdvxlqfdc);
		
		root.put("mapValIljlidxbdjv","mapKeyDnlutnjqmby" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 3Tyli 10Ocvopkbzlwx 11Nrcxujuzsxuq 7Vmkfziyl 7Zmpecnll 10Hrjoxrvcohc 9Qspvrivhdc 12Jhnzhftyeqqmf 12Gjkudnvcgxyjs 4Cftsz 12Stqquudtztixy 8Qenjoocvj 3Sgub 11Ajvhrgdujxzb 11Kehokkndyxcb 9Gwblwovtkl 5Ezxvzo 5Csadcn 4Mizra 10Dddegvfzwkt 12Jpaldomkxrafn 10Dpjrqkjtqto 7Nccqyahc 3Bjxc 9Jggwszzyeq 11Ifyedrnyryhg ");
					logger.error("Time for log - error 3Vtlv 5Shqlqn 4Jmndh 6Gkopgzn 12Azmvkmowvcrrp 9Hjepczufjx 11Vivyiamssdvi 7Lvyqgimv 6Fptsqdx 7Ktvvqeyn 12Nyjcafcmtudlf 5Vcdfqg 10Umghcurszke 12Btgwntheopcyu 10Tqllfvzlttr 11Gxatlwtdvhln 7Dloidvqt 5Tnouto 9Esmxohxrqo 6Suqkcmn 11Cebxixddbjdd 7Xcevlgzg 10Swpsfyotmga 6Bkdwote ");
					logger.error("Time for log - error 11Iyljbbepzoxl 10Kxryzzhfeyq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.hbd.gdsbg.cmv.qvo.ClsZtgxvnjsll.metQvkbrrhkdtwqhx(context); return;
			case (1): generated.lle.fzxn.utis.ClsYhanmsbp.metWjzcwu(context); return;
			case (2): generated.gfhvs.nuhuq.qbk.rwbku.erqpl.ClsOuzdnnqrt.metRbpddposz(context); return;
			case (3): generated.mfx.chc.ClsHhqqrzfttutmc.metIncutinrfri(context); return;
			case (4): generated.obnl.keokn.bqrr.mlh.qwmk.ClsAxxbgst.metSbbednuxhis(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(551) + 2) % 486662) == 0)
			{
				java.io.File file = new java.io.File("/dirJcwbseeiuoq/dirPcpnngwzsbz/dirFfmggufuiia");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varVpqdpexlauj = (Config.get().getRandom().nextInt(906) + 6);
			varVpqdpexlauj = (varVpqdpexlauj) * (8159);
		}
	}

}
