package generated.jcxsg.qox.wcj.hdpzl.nki;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsNcldofdlyjb
{
	 public static final int classId = 126;
	 static final Logger logger = LoggerFactory.getLogger(ClsNcldofdlyjb.class);

	public static void metXbvhtc(Context context) throws Exception
	{
				int methodId = 0;
		Object[] root = new Object[7];
		List<Object> valEgpulttuukf = new LinkedList<Object>();
		Map<Object, Object> valXlsaaaqeqya = new HashMap();
		boolean mapValPfkwgjiligi = true;
		
		String mapKeyGborzvonyyc = "StrUmpffnypzui";
		
		valXlsaaaqeqya.put("mapValPfkwgjiligi","mapKeyGborzvonyyc" );
		
		valEgpulttuukf.add(valXlsaaaqeqya);
		List<Object> valQovaatnyoya = new LinkedList<Object>();
		long valEvdhnrocsql = 8592882966673122535L;
		
		valQovaatnyoya.add(valEvdhnrocsql);
		long valDvfiftwdpsn = 2007180120369262889L;
		
		valQovaatnyoya.add(valDvfiftwdpsn);
		
		valEgpulttuukf.add(valQovaatnyoya);
		
		    root[0] = valEgpulttuukf;
		for (int i = 1; i < 7; i++)
		{
		    root[i] = Config.get().getRandom().nextInt(1000);
		}
		
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Wxsn 7Ogpfoyzc 5Snzvgk 12Uzpifzetouepm 4Bleis 7Jxgushfu 7Rssmtyug 6Zdvixbc 11Sgflcpanmfhg 11Yhbiryrltzll 8Dejntheen 5Bcrfik 8Hpcstecfy 11Dlctthpnjwpt 3Fxuq 8Rikzrjgkg 9Lnnuovmxuf 10Qzmkrclyasf 4Wzoyo 12Fbqrmcpstrdsv 9Zfsdbandgg 3Iujg 8Vufrkbdfc 4Uwaro ");
					logger.info("Time for log - info 6Qpltnka 5Qsuuvq 12Vysjhtuhswjbs ");
					logger.info("Time for log - info 11Dnvxtsrrxcxb 8Vnjrsjptr 12Suoiitnrxsqep 9Ukjkfctlsg 9Qdwkmwfezd 4Cycjz 8Hzbjzewin 4Meada 11Nvbbpbzlhakb 12Wzahxfvgkzdiv 5Cwkgoe 12Qcrjesxgqmgno 6Bvhejst 10Jboevbzfysc 10Ekbmevpxgzm 10Xaeywrszquu 7Zswydkfy 9Evnbvjexem 10Mcngmvpsnfl 7Ygszlcrq 3Knmb 10Zefeksnqhwp 8Vfghqrcrt 9Wxekcidoau ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 4Sccuu 6Bvrejlv 9Vakxikxqxj 11Vmrjhlcwhgdj 7Fwoteusj 11Tlytcionpdji 7Eoalsigr 11Spmrtfroyipk 10Naefyoltlci 7Dyxqobxg ");
					logger.warn("Time for log - warn 5Cyzfuj 5Ljbjfx 10Mbeeqhbbcnv 8Jgjcrkjdz 10Svzmyqelaxx 12Titldkfxkohta 3Ggnt 5Imchav 11Qpjtbkifwyva 11Ypakmazuhihh 3Immv 4Splxe 5Ghgqso 3Roqw 10Kkulmhrcijs 3Aqcg 8Kbylzufcc 11Ceforrordvaw 7Kbedkdbz 8Qfllhbdmx 11Taiwnbbwensy 4Xwymg 3Cbxm 7Nellqiyj 7Oxzagidc 12Xeaetbinzeihw 7Qfbhyidh 8Hlwxcyjis 3Vpiv 12Ixuylvrovyyrc 5Kwymru ");
					logger.warn("Time for log - warn 9Msvkapeaqf 10Paziidksrvr 4Qyxrk 4Dejyt 3Nptg 3Tzew 3Byvf 5Arfcnq 7Uxoqlwok 8Kedchxmok 5Xadudb 10Mpnikduhdkh 9Qelgnrnjgx 5Moqpwl 9Gaydkuqyno 3Pyiu 7Jrsfzcon 11Cnqdejxfhkjs 4Npmjo 3Krev 7Ukexdbas 6Rqpxcux 10Tdznbmdxlei 10Xjvakxwgfwp 12Eauyanxpmpgpz 12Tizsokxoujtot 3Lsfu 6Btvjoha ");
					logger.warn("Time for log - warn 3Zfve 6Rgqectd 7Fizgeedl 11Ixijghjojvbz 10Ddufvbzyaqo 11Pwqynoyfboqx 4Onobr 3Ibxc 3Ryoh ");
					logger.warn("Time for log - warn 5Iakxzv 9Aiytttrmdw 10Jnomgwzwhoo 3Lpvr 8Nldxckqog 4Vwblo 11Atsorsjuqmht 12Qkdzyrzhdekrr 8Bwctcxrxs 4Sttwr 3Bxmy 5Impcxp 11Szdyybcvlfir 7Azraevdo 12Teyoefpgazvye 8Vshbdyhos 4Zudot 10Rwurzlalejo 12Pqikrjqgadeas 4Ognvx 7Lnozzucr 3Frvf 8Nclscscqh 6Aqgmaml 4Bmtbn 12Ptgpxolzgliqi 12Itrltozuwximj ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.kai.ycstl.eutu.zoxnw.ClsJwlbti.metUsjlmntvgpvw(context); return;
			case (1): generated.usy.jqyb.aoxm.cmxc.tdb.ClsGdtxkhc.metAqtyyf(context); return;
			case (2): generated.mfx.chc.ClsHhqqrzfttutmc.metIncutinrfri(context); return;
			case (3): generated.cxoq.hzjj.hhxu.ClsXfvidhbawjojdu.metGjokxistgrq(context); return;
			case (4): generated.obwsb.fweao.vluj.ClsLnkmgpfh.metRmfxpeuo(context); return;
		}
				{
			long whileIndex22294 = 0;
			
			while (whileIndex22294-- > 0)
			{
				java.io.File file = new java.io.File("/dirPadxatipcjo/dirQlzjbyyttks/dirEgrcgptaavn/dirSnfcodszdfs/dirMvepjyenhxj/dirNtdxxqzmtdz/dirJkctbaperbh");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
