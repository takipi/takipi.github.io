package generated.mbf.jauhv.phe.sowu.arz;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsAtgovrsbvzxguw
{
	 public static final int classId = 209;
	 static final Logger logger = LoggerFactory.getLogger(ClsAtgovrsbvzxguw.class);

	public static void metBpskpuvrln(Context context) throws Exception
	{
				int methodId = 0;
		Set<Object> root = new HashSet<Object>();
		Object[] valHfzfphpabdv = new Object[6];
		List<Object> valPgkycggceys = new LinkedList<Object>();
		String valRdrayogossm = "StrHyjjsghzlkn";
		
		valPgkycggceys.add(valRdrayogossm);
		long valFebvogruglr = 1023298182199920793L;
		
		valPgkycggceys.add(valFebvogruglr);
		
		    valHfzfphpabdv[0] = valPgkycggceys;
		for (int i = 1; i < 6; i++)
		{
		    valHfzfphpabdv[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valHfzfphpabdv);
		List<Object> valQclpudbiizo = new LinkedList<Object>();
		Map<Object, Object> valPuzmdqjtbig = new HashMap();
		long mapValTfpdvjxpaut = 5332846776817326921L;
		
		long mapKeyGjftkubraof = 5863952098165646898L;
		
		valPuzmdqjtbig.put("mapValTfpdvjxpaut","mapKeyGjftkubraof" );
		
		valQclpudbiizo.add(valPuzmdqjtbig);
		Set<Object> valOsxkwgozxzd = new HashSet<Object>();
		String valLldzpbpzkrw = "StrHetiiminbbc";
		
		valOsxkwgozxzd.add(valLldzpbpzkrw);
		
		valQclpudbiizo.add(valOsxkwgozxzd);
		
		root.add(valQclpudbiizo);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 7Rexpnpjp 8Dueojvjyc 6Mowduzv 12Glzyzsodfoomd ");
					logger.info("Time for log - info 3Ovfn 9Tqjulyalzc 3Hhme 8Kkpcpvayq 5Dqaqpb 11Psmxudeuwaxw 8Mzjtgygvx 11Tsmolrvtoneh 3Kghn 5Sgutzs 4Yfhqz 12Yihqxbsipvnma 11Qrxscwltweyc 5Lbenmn 4Hpvsv 12Wjkmllaqqonxu 12Ipqwtmcwzevqs 12Jeoaplgbfwael 3Qxfo ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Dydcevp 8Upeskuogg 7Vytbhert 9Ieufgtuutk 7Kyzxpwjz 5Dxqxtk 9Ktbirmovks 9Utyoknonjn 12Nyiupsvmjrbfr 4Yeycz 6Rzjhqhx 10Umqnhrsvvde 8Qutctlewx 11Ofxdlymiakym 8Gdrjxgqly 12Stvqllgxlaicp 6Crftork 11Dvcdvimmoyby 10Behnyhueibq 10Bjolovbfzyh 12Aueuqwltgsmir 3Anec 11Pkkvyfiaggdv 4Hnhqj 7Hnkeybis 6Oznntuf 4Vihow ");
					logger.warn("Time for log - warn 10Qxoamyzmbau 11Nlhwpaxgorgv 4Okdql 7Ujxvnjzt 12Ebjcshlwnmxda 5Dlvgoj 11Eaqamlvpgchh 6Cockicd 8Mjnoyqzvk 7Vhviwrsr 7Awarncmg 5Unhuzr 11Ntlhhhcnrusg 11Jdrhrbmejomm 11Uyijshncvemy 11Uuxkgpmjhhvy 11Cyzbiypqfffm 5Xpfert 10Grxcaqsemkb 11Cufkufjdqcik 5Wkmwuv 4Qcjvq 3Gkuy 11Wfcuqtnrbclm 9Kgmyyazoqg 4Ijfvf 3Qrvu 10Ewhbrinyjmk 10Axlewukgtnl 3Zmnf 4Wbgzf ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.lmq.wwll.mcjoz.ClsBqjxdpu.metYpiqwjcggcaa(context); return;
			case (1): generated.wvctc.whp.ftjy.ClsPwdcftvpjt.metAukww(context); return;
			case (2): generated.dnnlu.krjt.bhw.ClsLntkclh.metCanmcyztyd(context); return;
			case (3): generated.xajsm.xnlym.ClsUmfzchfskds.metCirgapizik(context); return;
			case (4): generated.mbf.jauhv.phe.sowu.arz.ClsAtgovrsbvzxguw.metBpskpuvrln(context); return;
		}
				{
			int loopIndex23717 = 0;
			for (loopIndex23717 = 0; loopIndex23717 < 9905; loopIndex23717++)
			{
				try
				{
					Integer.parseInt("numUkqtyjlckka");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metJlpvoow(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		Set<Object> valWkppgjwwmpx = new HashSet<Object>();
		Object[] valWwpyznbcizf = new Object[2];
		String valKgnyiswngxb = "StrCludnbfnwnj";
		
		    valWwpyznbcizf[0] = valKgnyiswngxb;
		for (int i = 1; i < 2; i++)
		{
		    valWwpyznbcizf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valWkppgjwwmpx.add(valWwpyznbcizf);
		
		root.add(valWkppgjwwmpx);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 11Zcdscqgolcmw 8Edapiqbkl 8Uedthdhkc 4Talzt ");
					logger.info("Time for log - info 6Zwwfgsk 7Fdxsihjf 8Mszhyweuw 6Tsrdzwv 11Algzjrylqxma ");
					logger.info("Time for log - info 6Gifwxdr 6Zczxptn 9Degznbxhds 11Zrvmcacoumgk 8Yqeghuuje 8Asdvzqroh 12Nkpatlhbdktfg 4Oatar ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Umaf 10Yimwjpiyzrj 3Feai 4Npxgm 5Gjvqoq 4Kvgyf 12Ehdqoencmtgsj 9Iifvklfpzg 3Jrmk 8Tigbvkjpd 11Lzyvrtinvavj 9Cwajtsewty 12Isrvfcwsfietj 12Ylhtzpyazvrpw 3Ivzu 6Eghvcmm 10Frjlunzbinm 8Ytalcvvhr 8Lbkxauovy 9Vqysdhflou 9Zwgfmqudxb ");
					logger.warn("Time for log - warn 12Eecbkdzqtfwkz 10Ewcwpnmoemk 6Gwmaswx 5Zvlaub 11Lfdqggwyysdk 11Gkutesqwuvzb 12Yixukltagjbkj 9Wrxxtipbty 11Ymggdfsujoly 8Juxadvxvw 4Sqjkx 7Fjkhziia 9Qcewpaolby 4Yvnwh 10Sxytjcbhgnu 3Kbap 3Fcjn 11Pbykjiiurmdu 7Keruqxpo 9Ujmrngmczi 12Clbfnjbttsgcv 11Pltpulijjgin 6Pbbiojt 7Vpugslzq 6Ymbqgki 7Bvompegy ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 5Pajioa 10Vdoilmpcmxp 10Calzcuhowvi 4Niywe 10Glxcesykquw 11Svmzmfhhauib 5Vdiufo 9Oauzboccfj 7Jhojcefb 10Zqzxdthsryb 5Fvpcfl 9Hvijedfcnx 3Kzqx 9Rlorcnloge 6Oyxlvar 3Tgqt 9Earuvjvdnp 4Easgq 9Drfntlbvjk 4Jeudr 10Lvxlnlwejri 9Zqxteoxxhe 5Gwqtxd 6Twazmdv 8Xqlbicrvv 12Hajxmryblfawh 5Ycpamh 9Ufqaxgowds 10Djiqwkkujux 6Gndmbxl 10Qiqhvzegrlt ");
					logger.error("Time for log - error 7Yudogede 10Erqtcpumhrq 3Rbwg 6Yyndyad 4Rcbaz 8Swmgozhnk 4Xgatd 7Qvmcbbni 7Makrambd 12Pwlogvbgamdiz 12Ygjividdrbydy 6Fakholw 8Okfmswjqp ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.rayp.ekfg.uust.ClsQhtttdalkvmcth.metYhiqkxerxikn(context); return;
			case (1): generated.jbipj.zrsb.daypv.qszx.ewk.ClsVnncvmwdx.metEgxuxcqraj(context); return;
			case (2): generated.iotb.mlgn.hcur.ClsAdwtsoupvuwy.metTfsczzma(context); return;
			case (3): generated.ylm.khpm.ClsVatpcobwyrfcqq.metCtpblisyzyecp(context); return;
			case (4): generated.uwqq.rznca.ubddn.auo.ClsOkthnaihqahfl.metJezqzyduxos(context); return;
		}
				{
			long varBzclmglawen = (Config.get().getRandom().nextInt(212) + 7) + (Config.get().getRandom().nextInt(879) + 6);
			varBzclmglawen = (varBzclmglawen);
		}
	}


	public static void metNzrbcudifbng(Context context) throws Exception
	{
				int methodId = 2;
		Map<Object, Object> root = new HashMap();
		Set<Object> mapValOsrjqkswddv = new HashSet<Object>();
		Map<Object, Object> valFdbbobxkreh = new HashMap();
		long mapValLwhuszktwmd = -8454488687528435010L;
		
		long mapKeyBeyybqhwoua = -7477931246944343560L;
		
		valFdbbobxkreh.put("mapValLwhuszktwmd","mapKeyBeyybqhwoua" );
		
		mapValOsrjqkswddv.add(valFdbbobxkreh);
		
		Set<Object> mapKeyMspkdcjyfza = new HashSet<Object>();
		Map<Object, Object> valRyrnwdgnqdw = new HashMap();
		int mapValObwqeixkkeb = 472;
		
		int mapKeyQfdbtjnxnxm = 579;
		
		valRyrnwdgnqdw.put("mapValObwqeixkkeb","mapKeyQfdbtjnxnxm" );
		
		mapKeyMspkdcjyfza.add(valRyrnwdgnqdw);
		
		root.put("mapValOsrjqkswddv","mapKeyMspkdcjyfza" );
		Map<Object, Object> mapValKmktiqqvcvy = new HashMap();
		Set<Object> mapValRyycmxlohzx = new HashSet<Object>();
		long valFgvphscstya = 6310676444514517807L;
		
		mapValRyycmxlohzx.add(valFgvphscstya);
		boolean valNjgjqlkidsj = true;
		
		mapValRyycmxlohzx.add(valNjgjqlkidsj);
		
		Object[] mapKeyZenvczivxay = new Object[10];
		int valXoetltsfhio = 341;
		
		    mapKeyZenvczivxay[0] = valXoetltsfhio;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyZenvczivxay[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValKmktiqqvcvy.put("mapValRyycmxlohzx","mapKeyZenvczivxay" );
		Set<Object> mapValIxjrltxtlza = new HashSet<Object>();
		long valRhjnngyxtik = -5275102251792478284L;
		
		mapValIxjrltxtlza.add(valRhjnngyxtik);
		boolean valAbcjsgkjmru = true;
		
		mapValIxjrltxtlza.add(valAbcjsgkjmru);
		
		List<Object> mapKeyHhnpshhbcte = new LinkedList<Object>();
		String valQulttmtcatd = "StrFzeuhgesbpq";
		
		mapKeyHhnpshhbcte.add(valQulttmtcatd);
		
		mapValKmktiqqvcvy.put("mapValIxjrltxtlza","mapKeyHhnpshhbcte" );
		
		Set<Object> mapKeyOazoyfnirfr = new HashSet<Object>();
		Set<Object> valIbpksvdidku = new HashSet<Object>();
		boolean valPzwhukdvrzu = true;
		
		valIbpksvdidku.add(valPzwhukdvrzu);
		boolean valHauermacubv = true;
		
		valIbpksvdidku.add(valHauermacubv);
		
		mapKeyOazoyfnirfr.add(valIbpksvdidku);
		
		root.put("mapValKmktiqqvcvy","mapKeyOazoyfnirfr" );
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 9Iqrmlyhypt 11Sdfoccttapnb ");
					logger.info("Time for log - info 11Xmxzwofephzx 5Ubayza 7Nhrklfno 5Ppdhxd 3Gdwy 10Edcoiwaemxn 8Congrhoow 10Dequnaxweos 4Iruui ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Sqesgdl 6Uhkwdin 3Msmr 4Vsubl 6Senznbi 10Gguhkiiqbrh 12Wnehocctjpwxb 4Afkws 10Oohrrrhddcf 8Nhtpbocmk 8Vcpkdkvjk 7Uiydbqig 9Zlpwcbsqyl 3Fnyl 12Bpzrqgdannjfb 3Zvja 7Uxhvtjqg 11Deeteickfzjq 10Ldgyxgjrqvk 9Wwaydkkpdj 10Vovvdingyky 6Mrkisei 8Kpkzsexjo 11Ntfqficncqtb 6Bnfdtof ");
					logger.warn("Time for log - warn 4Pjiea 5Fehgbf 10Yaysbapperu 10Pdyvhoqzbpo 7Otdgzjjh 3Prij 4Cegyf 6Bxpukko ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 8Uvxromfxj 4Crebo 9Jbnwzrcefg 10Znlyivkykkd 10Ulfbbgipowa 8Lnbcartqm 3Hwnk 3Dqmv 8Wgsnromxo 5Sjzjkv 11Oxuwfnsbntlj 3Vxwz 11Gbwvroraaxpc 8Idskpknde 8Obexinlwp 6Dpedlsl 8Hjfvhuetf 12Anuccktnldren 12Vmzyzyxqdtbiy 11Vvbhduychbuq ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.tgr.kelz.siz.xfels.ClsKydjl.metQmhajcedjutgex(context); return;
			case (1): generated.wtc.bgb.gahv.mul.rts.ClsUeuxdzs.metWowjsssr(context); return;
			case (2): generated.qwlax.zei.ClsAdxloruwrrth.metHsjxayjzgkwe(context); return;
			case (3): generated.kiqe.tmup.llmva.iyda.crt.ClsCkhcwacne.metEqiixejyhymhk(context); return;
			case (4): generated.mbn.igyf.ivup.sglb.ukb.ClsQzhoqgskicnjw.metJqiotqpjksr(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(986) + 5) - (6780) % 320864) == 0)
			{
				try
				{
					Integer.parseInt("numFgzvgitnhcl");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			else if (((6287) % 130033) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				java.io.File file = new java.io.File("/dirAfzgvudtboe/dirEpnmgpuvpil/dirHtpyvnkniak/dirDwxnxuazkmj/dirInyissxkduf/dirEpltmchddwi");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			catch (Exception ex23730)
			{
			}
			
			if (((1994) * (6159) % 353531) == 0)
			{
				java.io.File file = new java.io.File("/dirGwpxpuwvhhj/dirUjetwugntvg/dirGfzjiygotbb/dirOlegwwdthjx/dirFqtkknzxqdv/dirOoihesedvaa");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
		}
	}

}
