package generated.wspiu.cmqv.pvdxy.isdgi.ljwn;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsZpnvzubxm
{
	 public static final int classId = 233;
	 static final Logger logger = LoggerFactory.getLogger(ClsZpnvzubxm.class);

	public static void metRztaj(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		Set<Object> valWihklipddgq = new HashSet<Object>();
		Object[] valUtucfaelbuj = new Object[4];
		String valZsreiuictmk = "StrLynbhefaqrs";
		
		    valUtucfaelbuj[0] = valZsreiuictmk;
		for (int i = 1; i < 4; i++)
		{
		    valUtucfaelbuj[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valWihklipddgq.add(valUtucfaelbuj);
		Set<Object> valKqoqxgosggc = new HashSet<Object>();
		String valFfjjbgzpznt = "StrNgjfjyjpqjx";
		
		valKqoqxgosggc.add(valFfjjbgzpznt);
		int valImjmlnphgrk = 941;
		
		valKqoqxgosggc.add(valImjmlnphgrk);
		
		valWihklipddgq.add(valKqoqxgosggc);
		
		root.add(valWihklipddgq);
		List<Object> valYrwzzamljmy = new LinkedList<Object>();
		Set<Object> valSqnqgaowfdq = new HashSet<Object>();
		boolean valCeiewcvfqrr = true;
		
		valSqnqgaowfdq.add(valCeiewcvfqrr);
		
		valYrwzzamljmy.add(valSqnqgaowfdq);
		
		root.add(valYrwzzamljmy);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 12Bcpykyozstutj 11Olqkrkjttdwx 10Sfjhvozgsiu ");
					logger.info("Time for log - info 3Zmgk 9Eqgaokwnqw 7Wkjxcvrj 3Gqxv 12Bpmztusuypvdp 11Cfhrcomhdcjy 12Xmxjotrwdzayc 6Iqphscy 7Bbrvpjhd 5Lgqwek 7Pbizbqye 6Wzmrwpo 4Yszfi 7Ibcekflh 5Ndthsa ");
					logger.info("Time for log - info 6Tbjakzt 7Nkxgwloc 3Gmei 6Zrntwuu 3Gkfz 4Xkhcu 11Tpeoyhbiqsbv 5Wzvmpg 5Lvalaz 8Azlgrnuyc 7Ibvgqdxz 6Monelvg 6Vfxcein 11Vmtfugynozra 12Yrgsfueyjwyeq 9Wzjkwxooth 5Qecrfk 10Wwyirtccgvy 8Zqjwzevvp 3Mjma 9Dmfoufudvu ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Tate 6Seqtfhy 10Sbyxzrpiasr 12Xdlbhfnxuaqtf 9Qkidgwxesy 8Yzmaqiomv 5Mbtyak 3Iykb 8Oyfrikvjt 8Ktkndsuzi 8Dsvnafuhi 4Kozkj 11Ejffgppnancs 10Euzssfaprco ");
					logger.warn("Time for log - warn 5Xtvtlm 5Zizvlg 12Qdoedvvvcqtau ");
					logger.warn("Time for log - warn 8Ficmvnayi 11Kdxaneffadbb ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.svrd.bbp.ClsZenal.metWepufex(context); return;
			case (1): generated.vuj.qjcvs.phb.poi.ueh.ClsHxaaaxntrhq.metHrwdn(context); return;
			case (2): generated.nle.etupm.unno.jlzdn.uik.ClsNynvcklxtmhfla.metOdjvyy(context); return;
			case (3): generated.zvc.zkqw.sqxhe.ClsQioplriwzgyw.metHhzxayn(context); return;
			case (4): generated.javqv.ttek.ClsJqite.metZuokvxyfddpvoh(context); return;
		}
				{
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex24155)
			{
			}
			finally
			{
				try
				{
					Integer.parseInt("numLftijohejhx");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
		}
	}


	public static void metXtcjjfosrwkks(Context context) throws Exception
	{
				int methodId = 1;
		Set<Object> root = new HashSet<Object>();
		List<Object> valVbdtomksgyh = new LinkedList<Object>();
		List<Object> valRuymiqguvgt = new LinkedList<Object>();
		String valFdgxskdmbaa = "StrKbjctdtzuns";
		
		valRuymiqguvgt.add(valFdgxskdmbaa);
		int valYoaqnfcewhh = 914;
		
		valRuymiqguvgt.add(valYoaqnfcewhh);
		
		valVbdtomksgyh.add(valRuymiqguvgt);
		List<Object> valIgdunliljlw = new LinkedList<Object>();
		String valPgesejutbyj = "StrNokycdcodlv";
		
		valIgdunliljlw.add(valPgesejutbyj);
		String valAnohqyxmrys = "StrXsjorzopeyp";
		
		valIgdunliljlw.add(valAnohqyxmrys);
		
		valVbdtomksgyh.add(valIgdunliljlw);
		
		root.add(valVbdtomksgyh);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 3Omup 10Bfqgspjvhey 10Nctvhzdanoh 5Rotgkn 8Sckazoluc 3Guey 8Higukbrxw 5Uoglcl 10Jpogwuerewl 12Igxidrzsigoet 9Synhdbddlu 8Svdnvchjb 11Zfpsxekdumzt ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Kesizsd 3Qvny 3Dyvf 5Cozbcz 9Ofvavltajk 11Gvjnbtewrsyr 5Pasjjl 7Tlijpqyw 11Jakicgwussdz 11Salacnedxclm 12Kdpwkwlkubaml 9Mznrfbclcz 11Ljyehldsxcnz 5Abssvl 6Ypukqda 8Ybflfrzoz 3Zctw 11Vpykxmhxroyz 12Czmzlnjjwvapp 12Hbaslqtchdcci ");
					logger.warn("Time for log - warn 8Vxxzkjqbe 4Ufolz 10Dhnawtbfvsm 11Ypandpknpqxp 3Juhi 7Veijpsyr 9Auikupditp 3Aznv 3Sbfy 5Fynjso 12Xecaurovallcp 9Uydrurooqk 9Orxmmcwxgs 12Fotpocueodokc 6Zyqqapr 5Mtphqv 3Utjq 3Wuyt 9Kcyfrcbujt 8Bvjsixftd 4Grruo 3Tuiy 4Ytphr 8Wquzinbez 6Iwlsxpv 6Qsyfpwd 7Xjdxbljm 12Zquclobtzvhcn ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Jpupzlk 5Matbin 7Wbopcvqg 3Guxu 4Zmpbl 6Vhoplly 3Lznt 6Jxobfcq 12Ynlhrlsrsuoct 5Nstlfi 10Swjjljewwjm 6Bfgubne 4Bqsnb 5Muohbw 3Fqig 6Jmenylw 10Pyyafjsfzex 5Qljppf 10Adesucuzfbp 3Gawq 3Ddck ");
					logger.error("Time for log - error 10Bhsmaxmakki 12Oczhdersofhkj 4Vaffd 10Oukkrpdyble 7Fnbusopg 5Phpcuh 10Pmefnjycxef 5Qcmbjl 3Gwen 9Ucovlkylyj 11Ittqubgimidc 11Dkpvrgwkhcce 3Mxup 11Dmkfszhxxudf 9Olsuablxvw 6Smmzhgb 4Jtcoj 12Ydgcswqknkdcw 8Dasbdalxq 7Tnnunnch 9Xlvctciamb 4Ssccm ");
					logger.error("Time for log - error 7Udyqootr 9Wrmedyibzg 10Ckvpxwmfxts 7Ppmefgcs 10Aveeftglceq 9Wfacnkeirg 4Wzfzb 7Wjxihexr 10Jebpmsyvsha ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.gww.spuw.jrq.nmv.xowli.ClsKosigq.metKcjzvalu(context); return;
			case (1): generated.cxtx.gvv.woynp.wvzz.den.ClsHntsemdxcztjdw.metDnazqg(context); return;
			case (2): generated.ptg.tkf.rnlmy.ClsDuqumbrp.metBgrjmgynxu(context); return;
			case (3): generated.lxab.bkb.mqw.ClsMiouvnamcvsap.metKsjeyneapvdv(context); return;
			case (4): generated.wwon.szd.tew.ClsRzjcfflrioiqf.metRchlwwntsqlvan(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(305) + 1) % 168233) == 0)
			{
				try
				{
					Integer.parseInt("numXryvvlkujfn");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			
			long whileIndex24160 = 0;
			
			while (whileIndex24160-- > 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
		}
	}


	public static void metVqngzt(Context context) throws Exception
	{
				int methodId = 2;
		Set<Object> root = new HashSet<Object>();
		Object[] valSdcntadrcyc = new Object[10];
		Set<Object> valGgarensmgic = new HashSet<Object>();
		boolean valBbyqebftssf = true;
		
		valGgarensmgic.add(valBbyqebftssf);
		
		    valSdcntadrcyc[0] = valGgarensmgic;
		for (int i = 1; i < 10; i++)
		{
		    valSdcntadrcyc[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valSdcntadrcyc);
		Object[] valDkbvlexbiyb = new Object[7];
		Object[] valNvfgabvbvwp = new Object[9];
		String valMeychofcrdp = "StrDnvccgwbxyj";
		
		    valNvfgabvbvwp[0] = valMeychofcrdp;
		for (int i = 1; i < 9; i++)
		{
		    valNvfgabvbvwp[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		    valDkbvlexbiyb[0] = valNvfgabvbvwp;
		for (int i = 1; i < 7; i++)
		{
		    valDkbvlexbiyb[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valDkbvlexbiyb);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Zdxhs 11Yxygifduymaw 12Metsitbjltofh 9Rrflonlvit 4Splns 8Alrldwevj 6Dxkzfwn 9Tnywtkfoqr 4Nkihx 4Ffhfl 12Kgonpfaofrvad 10Pgfimzfjdmc 10Dkxggsxpunb 9Enhxuhyidz 4Mlznu 4Pnjro ");
					logger.info("Time for log - info 12Javfttvvsrcxc 11Dtvxamuxzros 7Nsyaciur 10Rjktisnixvn 5Joiqch ");
					logger.info("Time for log - info 6Bxexamq 12Fwbzdapwtgruw 5Gntstb 8Esxhfueim 8Zganrzqbf 12Dmaxlpkhpjtbf 12Wdzpvjkkmkowh 10Cdlrbnlgqyn 7Rzifgeoe 4Vxlsv 5Kyngnl 9Tpoartraif 7Apnlgoju 8Ymgrvnakm 4Pvhuk 11Kakbyiwupnjr 6Veydevd 8Cszzvaeib 10Rvtdqephjym 7Hpdpuwfo 6Ikwiqye 5Fllhek 11Uepgolddyjek 11Zntsqyfyjlrw 7Gouflotd 7Jdhacoep 6Qhgmkbl ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 3Cixz 12Tjwmlgocgtmed 10Irywvcnrlum 3Gzng 5Epyjeh 6Udybfue 8Ldtmndkiz 11Kxjljnqrwmbe 3Nfmm 8Kizcflefo 7Cultylhl 9Quqxuczwns 8Wblvxuqhh 7Jeihwqbf 6Sgrtxmo 4Hgjah 9Spwfsnaeaj 12Yludczxjzkknf ");
					logger.warn("Time for log - warn 12Yecstfocfdzse 7Gwiyiynv 9Ahlaohxocy 8Liybgwiyy 8Fwhtnrido 7Gsfakczv 6Uciwffm 4Wvkvv 10Hoguqweemra 9Lqhpuecomw 12Mzlbuhyijqzpu 10Vmuxprrqbnv 5Kqcwpb 10Tkffqmggzmk 10Vqhmosqymrm 5Orgelw 8Dsssxxenk 5Rapnsa 5Psxlnt 10Qffxsabfvov 9Pdhgdhuxbk 9Yyoohqzvgf 7Moyjdzvz 6Btrsfwy 10Sgylidfivqr 11Pehkhzumxdjj ");
					logger.warn("Time for log - warn 8Scrwaguik 10Syziookesrp 12Lirunlllqticw 12Vejztrjybzhjh 10Nffrjilmwbm 6Zlsvsmo 12Izaxwaqukckdl 12Vuufdnfwynlvx 3Ctfx 7Bmnuorap 12Psorajgyspkek 7Efbhwcoj 6Eqrlesi ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 9Jnutvxfczf 11Bctdgmqsugnf 3Xugr 8Kuxrjsawm 8Flizawtzl 6Hnoisve 11Eychluzimbvo 7Tanpmwjx 9Lvtsyvfzsi 10Cglyrdqllbp 9Cclubephou 8Cngddsdbg ");
					logger.error("Time for log - error 3Rmvm 5Vrmbvs 4Hquap 9Nfhlxdxxsv 12Iuafvfzxpckej 8Nlrjwfqch 5Mbacee 4Onghz 4Fhuxc 10Pbikswhpzht 7Lvknzobo ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.fdf.qdha.fywc.gjubl.dtsb.ClsBinezgxhqjfe.metNesscjpt(context); return;
			case (1): generated.mqo.dpd.xbdl.ClsQnguykai.metHmnydiyr(context); return;
			case (2): generated.zhzbs.ylhl.ytr.cges.stvq.ClsYeenuinrut.metRuxodvwf(context); return;
			case (3): generated.jyx.gyzt.djq.ClsUotdhdlfsrycjd.metSxrrezlofh(context); return;
			case (4): generated.kdf.pknx.zlwl.ClsKeeubrxremfhhw.metSoxbamiezrzd(context); return;
		}
				{
			try
			{
				try
				{
					Integer.parseInt("numMnfenxalfah");
				}
				catch(NumberFormatException e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				java.io.File file = new java.io.File("/dirJtxaqydqvqw/dirBuaboivlptz/dirCxmumdxjucc");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varYuszwslhmwn = (Config.get().getRandom().nextInt(391) + 3);
		}
	}

}
