package generated.hyq.yrx.ucb.jdut.ghw;

import helpers.Config;
import helpers.Context;
import java.util.*;
import java.util.logging.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;


public class ClsXwcyosgzsc
{
	 public static final int classId = 122;
	 static final Logger logger = LoggerFactory.getLogger(ClsXwcyosgzsc.class);

	public static void metMysukbgfyiodpv(Context context) throws Exception
	{
				int methodId = 0;
		List<Object> root = new LinkedList<Object>();
		List<Object> valJyiryffrfrg = new LinkedList<Object>();
		Object[] valMwfnevfnykm = new Object[5];
		long valRlivouxpnnx = -1102585828692592881L;
		
		    valMwfnevfnykm[0] = valRlivouxpnnx;
		for (int i = 1; i < 5; i++)
		{
		    valMwfnevfnykm[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		valJyiryffrfrg.add(valMwfnevfnykm);
		
		root.add(valJyiryffrfrg);
		Object[] valYaelniwjicf = new Object[8];
		Set<Object> valYqgaphtfjka = new HashSet<Object>();
		String valVhvjrothvej = "StrYvrbutlssro";
		
		valYqgaphtfjka.add(valVhvjrothvej);
		
		    valYaelniwjicf[0] = valYqgaphtfjka;
		for (int i = 1; i < 8; i++)
		{
		    valYaelniwjicf[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.add(valYaelniwjicf);
					if (Config.get().shouldWriteLogInfo(context))
			{
					logger.info("Time for log - info 4Acqjt 12Sjifsxvriwfqi 10Yzlonruugdd 4Wpnsk 4Mzzlm 4Nbarq 8Hnugwkepe 7Gnyrkxsu 12Qnglrcfbpahqj 9Kaykfeafyf 9Zliyeapbbj 9Vsalqqaooo 5Moosws 12Reinjykqnjeml 4Bgmmj 4Zuoai 12Asgunnbxisogx 10Junvccpdtzh 4Upnys 12Nhlklakpsjjvr 5Uwzkst 12Zwlpcgsytngtg 8Jwntxlkqk 7Kjelettj 12Wxkphwhcfphpl 6Qfbcdaf 4Qonxn 7Ssfettvr 12Mruzpnaketedv ");
					logger.info("Time for log - info 5Ivmldx 8Qqvvjbxil 8Gcgmkcyit 12Niescfwrbdajb 3Lzjq 6Dsykaad 4Frdqx 6Znouqnm 8Sagtyfgqt 7Ksnwzmhd 12Kmvsmxywyyblg 9Tmbsnncfeh 12Wqbybhgxitdhd 4Zihfb 6Uapyqzt 9Febqjrcaaa 11Gtqkuizbptty 5Rlpeya 5Ppuwfo 7Grcnzonh 7Xddnexoo 8Rfaxaydrt 6Prkhhen 12Tycwpeonnhnjw 8Nusdosmec ");
					logger.info("Time for log - info 11Oqikovfskkzf 3Vnku 3Bdod 11Fbcypilketfn 4Zojqm 12Xaoqtcafzpcog 11Qrvzzeowhnvf 11Fzjusjgyxtdx 9Gkcmqsorry 6Rkkarjy 10Oopkhgcffwx 8Zsbdijjjq 9Trtelsifgd 5Vetymy 12Yulsyqqhdzutg ");
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 8Akkjqlfhg 6Pjrojpl 6Blbfdge 11Sbacpmmknkvm 11Qcnzomeqejim 11Jjesyxwfyyar 11Iuvdlmnrwrxz 3Kwev 3Padx 5Hbgmia 7Hgbvotno 4Kyfud 3Prno 4Rcxkx 8Wrohhuhjx 5Moxnmv 9Kfgznekdfm 11Gquixoflbyeb ");
					logger.warn("Time for log - warn 4Zffmr 4Rgroi 5Jstxpn 5Rvtzsr 10Dtoavmcuvid ");
					logger.warn("Time for log - warn 10Lvykqavstuq 10Iukoywehepy 8Soqhzgtlg 3Ylba 12Iqllwpehxhqyg 6Zklsbym 10Soqzswgyitj ");
					logger.warn("Time for log - warn 7Vqejcvnr 4Cagal 6Wqzchxf 7Wygcydkx 6Wfglohc 10Txniyegtslv 9Qnnxwfpasi 6Pmreeln 3Gpyc 9Fdivnodzqk 8Qxppvuygp 10Erqcuzszlpq 10Vsndkcvvbqt 3Kicn 5Wpzkch 8Gdcwgndqj 4Oshwp 5Trfmuw 6Tviqxvx ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 6Lssneeh 6Chyojie 4Vpstl 11Cdxjymuhfmje 10Bijyaolflyx 8Ikimlgker 4Ttchq 12Ldvavfpokrfvn 8Rxcwdsgon 11Pkixrdhicfke 8Hqcbzphbl 9Cuwpqknrzz 6Ztkiwnb 7Qkoeqizh 5Plegbx 6Mavzoez 12Wvmgrddlyrjdr ");
					logger.error("Time for log - error 9Fvdgvgwxbn 8Xkpugnfrh 11Tfbzlodomkxx 3Clpz 4Lypev 3Nffx 11Tvhwhflthpnp 3Zgks 7Htaqlszo 5Jubywg 12Eihhbvrdfxjug 7Ahmlaytk 5Ifbcym 4Rzlyx 8Bvefkzfqm 6Isuhmux 6Ndfqofw 12Yhrjbqkaejzoy 5Hosmsd 3Bswr 7Pwixmspg 3Mdem 11Nhkfmfuyzdjd 11Bhelnbcpehom 11Raszaclwbwmk 9Tqnhwgfdzz 5Dshjxu ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.qcqbk.ovao.ClsTizdo.metOqeer(context); return;
			case (1): generated.uxbqo.pcskv.udre.ClsKillneqmm.metIokufnwdnpfcxt(context); return;
			case (2): generated.xpyaq.paxhs.ClsBkhbodffo.metTjpaow(context); return;
			case (3): generated.rnt.ihen.ClsUnbfdq.metGtesoym(context); return;
			case (4): generated.inao.viw.ClsZkxazvlqxnvyzx.metYczqbc(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(163) + 0) % 962263) == 0)
			{
				java.io.File file = new java.io.File("/dirCxuorshclcn");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else
			{
				java.io.File file = new java.io.File("/dirSxscaquolrr/dirAehgelrhvmx/dirHmivfmruvby/dirIxmcifogqpe");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			
			long varCixatnkyhhr = (Config.get().getRandom().nextInt(348) + 3);
		}
	}


	public static void metGxlvnhkhnqc(Context context) throws Exception
	{
				int methodId = 1;
		Map<Object, Object> root = new HashMap();
		Map<Object, Object> mapValLbhhsofkaym = new HashMap();
		Object[] mapValNcaaeqdwxyx = new Object[3];
		int valOyxbvoolver = 52;
		
		    mapValNcaaeqdwxyx[0] = valOyxbvoolver;
		for (int i = 1; i < 3; i++)
		{
		    mapValNcaaeqdwxyx[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		List<Object> mapKeyLxaniivvouq = new LinkedList<Object>();
		int valRdfypzufjdm = 499;
		
		mapKeyLxaniivvouq.add(valRdfypzufjdm);
		
		mapValLbhhsofkaym.put("mapValNcaaeqdwxyx","mapKeyLxaniivvouq" );
		
		Object[] mapKeyXtzjcoqbbcz = new Object[10];
		List<Object> valXanpwelzfya = new LinkedList<Object>();
		long valJvmvbwtvlhw = 7813346578716594333L;
		
		valXanpwelzfya.add(valJvmvbwtvlhw);
		long valNwiyykrdkxm = 9131935124893172094L;
		
		valXanpwelzfya.add(valNwiyykrdkxm);
		
		    mapKeyXtzjcoqbbcz[0] = valXanpwelzfya;
		for (int i = 1; i < 10; i++)
		{
		    mapKeyXtzjcoqbbcz[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		root.put("mapValLbhhsofkaym","mapKeyXtzjcoqbbcz" );
		Map<Object, Object> mapValJwbhgtowdqy = new HashMap();
		List<Object> mapValIjdcqvwsgvr = new LinkedList<Object>();
		boolean valTcugademjmu = false;
		
		mapValIjdcqvwsgvr.add(valTcugademjmu);
		String valZztjozbcchh = "StrXpbzccjqbef";
		
		mapValIjdcqvwsgvr.add(valZztjozbcchh);
		
		Object[] mapKeyTgxwdzbqewu = new Object[7];
		long valFnhgvhrhtny = -7749769133671456400L;
		
		    mapKeyTgxwdzbqewu[0] = valFnhgvhrhtny;
		for (int i = 1; i < 7; i++)
		{
		    mapKeyTgxwdzbqewu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValJwbhgtowdqy.put("mapValIjdcqvwsgvr","mapKeyTgxwdzbqewu" );
		List<Object> mapValQufmyyjwitv = new LinkedList<Object>();
		String valXpvinekashl = "StrEtvwhyhztoe";
		
		mapValQufmyyjwitv.add(valXpvinekashl);
		
		Object[] mapKeyVeijjqolimu = new Object[11];
		int valTqlatkdlvyk = 837;
		
		    mapKeyVeijjqolimu[0] = valTqlatkdlvyk;
		for (int i = 1; i < 11; i++)
		{
		    mapKeyVeijjqolimu[i] = Config.get().getRandom().nextInt(1000);
		}
		
		
		mapValJwbhgtowdqy.put("mapValQufmyyjwitv","mapKeyVeijjqolimu" );
		
		Set<Object> mapKeyLpyymcdjkuf = new HashSet<Object>();
		List<Object> valCqtracclvym = new LinkedList<Object>();
		boolean valArbqkdzjsri = false;
		
		valCqtracclvym.add(valArbqkdzjsri);
		
		mapKeyLpyymcdjkuf.add(valCqtracclvym);
		
		root.put("mapValJwbhgtowdqy","mapKeyLpyymcdjkuf" );
					if (Config.get().shouldWriteLogInfo(context))
			{
			}
		
			if (Config.get().shouldThrowSomething(methodId,classId))
			{
				if(Config.get().shouldThrow1000())
				{
					for (int i = 0; i < 1000; i++) 
			{
			   	try
				  {
				  	throw new IllegalStateException("Time for Illegal state exception, context is " + context);
		  		}
			   	catch (Exception e)
				  {
				  	e.printStackTrace();
			   	}
      }

				}
		
				if (Config.get().shouldWriteLogWarn(context))
				{
					logger.warn("Time for log - warn 6Woqdhmx 7Uaibdfqr 12Lkgkibwgtnoyy 5Koxxeo 11Pyenjakccius 3Awkh 11Ahtsrdvbktdu 11Qoxzfkgplkqu 12Hqgocuaxxlzdx 3Gnjx 11Lwbajgaxivfz 10Wiqtkadxveo 7Qcenckuh 4Vilyl 6Xhnnvmt 7Djxmfuqs 7Qxxzwews 12Nwmofuauvzzro 7Gaxdmruk 3Xrne 8Qqslqjfth 11Mzlaxkiyvbtj 8Eparccbni 5Cktefe 11Vggwamsoanpm 4Xjkah 11Utkgozjjpefx 11Jcgzgdofjzyc 11Mmkmtmyoznmg 10Hikdtzyysqf 4Yocus ");
					logger.warn("Time for log - warn 12Gvjeewserfmqp 7Ivtkyivg 10Mlsfowxascj 7Neghanhm 7Bbpxqkrf 11Osyrxlxozler 4Vgrkl 4Odxgj 9Dnkxkvpnya 6Ogfwlnk ");
				}
		
				if (Config.get().shouldWriteLogError(context))
				{
					logger.error("Time for log - error 12Fubxoshmwnxcf 11Occftofcjbkf 5Nwsuyw 12Luxoglqafiqhy 7Nyzpeqgr 11Fsmzgtxxwwyj 8Cwekbusrl 4Tcnfa 5Ydvfbw 4Sswwn 5Ewujlw 12Hbrnwytcjswzr 8Sfjzldqje 11Pcmticsvtads 11Bthswxecnihs 11Zgtnshzlggsw 10Oemzhhuvwef 10Ppyywvmfmis 10Grkaxwtavaz 5Mcdilx 4Zflwo 8Feyysskgd 11Vonldzoqijtw 11Cubdwjbgbynf 7Wmqngmgz ");
					logger.error("Time for log - error 11Laiuvnxlhrgt 8Qxxdznqhj 6Oldclel 3Uros 6Zosjato 3Ofan 7Jhrbyjpz 3Tkpj 12Fbvdbifquelxl 6Jtshysy 6Axgviac 9Vgapnnehqp 7Efynexin 8Povmsvurw 6Kdmnaut 12Xseltxfroifzq 12Miqcxtlagvigo 9Atiyrejtij 12Tmmuifrheexlu 8Kmobpbxcp 5Zqycmo 7Rdljglmh 5Petqir 10Mbupuiguwlf 7Ououvdlx 11Nnofziivoryq 7Rdtkcwjo 10Veuvuriuejy ");
				}
		
				if (Config.get().shouldThrowIllegal(context))
				{
						throw new IllegalStateException("Time for Illegal state exception, context is " + context);

				}
		
				if (Config.get().shouldThrowIO(context))
				{
						throw new IOException("Time for IO exception, context is " + context);

				}
		}
		
				if (Config.get().shouldSuicide())
				{
		System.out.println("shouldSuicide.. ");
						 System.exit(0);
				}
		
			if (Config.get().shouldRunAway(context))
			{
				return;
			}
		
		Config.get().updateContext(context);
		int methodToCall = Config.get().getRandom().nextInt(5);
		
		switch (methodToCall)
		{
			case (0): generated.cjexh.ehrl.mtwqa.ClsVshethruisurxt.metQbgbwpmyakda(context); return;
			case (1): generated.aqdnu.puvg.gdad.ClsIxzvdsuksw.metItvqgpv(context); return;
			case (2): generated.opcr.jgy.rftd.rkx.ClsJjouwg.metKtdrtpazip(context); return;
			case (3): generated.wxgmf.hjxrw.ClsYvfyyrknqfec.metWssrrvk(context); return;
			case (4): generated.nmwme.qnfne.zsgam.zytf.yqrto.ClsDkqpghfzzf.metLrvrrwj(context); return;
		}
				{
			if (((Config.get().getRandom().nextInt(69) + 0) % 221247) == 0)
			{
				java.io.File file = new java.io.File("/dirNnlelqbyplj/dirKazoqfswnvo/dirQtqjaoxhuwi/dirMnmixfrfkfm/dirTmelmvdsmht/dirBmiuqhoqyqp/dirQiwgujpydsf");
				
				if (file.canRead())
				{
					System.out.println("File exists");
				}
				else
				{
					System.out.println("File not exists");
				}
			}
			else if (((Config.get().getRandom().nextInt(483) + 1) + (9596) % 666736) == 0)
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			
			try
			{
				Object locker = new Object();
				
				synchronized (locker)
				{
					System.out.println("synchronized block");
				}
			}
			catch (Exception ex22220)
			{
			}
			
		}
	}

}
